#include <bits/stdc++.h>
#include <sys/time.h>

using namespace std;

#ifdef LOCAL
constexpr double TIME_SCALE = 0.7;
#else
constexpr double TIME_SCALE = 1.0;
#endif

constexpr double TL = 9.0 * TIME_SCALE;
constexpr int INF = 1e9;

double get_time() {
    timeval tv;
    gettimeofday(&tv, NULL);
    return (double)tv.tv_sec + tv.tv_usec * 1e-6;
}
double start_time = get_time();
double elapsed() { return get_time() - start_time; }


bool is_tl() {
    return elapsed() > TL;
}

#define INLINE   inline __attribute__ ((always_inline))
#define FOR(i,a,b)  for(int i=(a);i<(b);++i)
#define REP(i,a)    FOR(i,0,a)

struct RNG {
    unsigned int MT[624];
    int index;
    RNG(int seed = 1) {init(seed);}
    void init(int seed = 1) {MT[0] = seed; FOR(i, 1, 624) MT[i] = (1812433253UL * (MT[i-1] ^ (MT[i-1] >> 30)) + i); index = 0; }
    void generate() {
        const unsigned int MULT[] = {0, 2567483615UL};
        REP(i, 227) {unsigned int y = (MT[i] & 0x8000000UL) + (MT[i+1] & 0x7FFFFFFFUL); MT[i] = MT[i+397] ^ (y >> 1); MT[i] ^= MULT[y&1]; }
        FOR(i, 227, 623) {unsigned int y = (MT[i] & 0x8000000UL) + (MT[i+1] & 0x7FFFFFFFUL); MT[i] = MT[i-227] ^ (y >> 1); MT[i] ^= MULT[y&1]; }
        unsigned int y = (MT[623] & 0x8000000UL) + (MT[0] & 0x7FFFFFFFUL); MT[623] = MT[623-227] ^ (y >> 1); MT[623] ^= MULT[y&1];
    }
    unsigned int rand() { if (index == 0) generate(); unsigned int y = MT[index]; y ^= y >> 11; y ^= y << 7  & 2636928640UL; y ^= y << 15 & 4022730752UL; y ^= y >> 18; index = index == 623 ? 0 : index + 1; return y;}
    INLINE int next() {return rand(); }
    INLINE int next(int x) {return rand() % x; }
    INLINE int next(int a, int b) {return a + (rand() % (b - a)); }
    INLINE double next_double() {return (rand() + 0.5) * (1.0 / 4294967296.0); }
    INLINE double next_double(double a, double b) {return a + next_double() * (b - a); }
};
 
static RNG rng;


struct Bridgeman {
    int pos;
    int order_target;
    int bricks;
    int bridge_from = -1;
    int bridge_to = -1;
    int partner = -1;
};

struct Order {
    int from;
    int to;
};

int N, B, O;
int DISTS[100][100];

struct Distances {
    int from;
    vector<int> dist;
    vector<int> parent;
    Distances(int f, const vector<int>& d, const vector<int>& p) : from(f), dist(d), parent(p) {}
};

Distances bfs(int start, int max_w) {
    vector<int> dist(N, INF);
    vector<int> parent(N, -1);
    dist[start] = 0;
    queue<int> q;
    q.push(start);
    while (!q.empty()) {
        int v = q.front(); q.pop();
        for (int u = 0; u < N; ++u) {
            if (u != v && dist[u] == INF && DISTS[v][u] <= max_w) {
                dist[u] = dist[v] + 1;
                parent[u] = v;
                q.push(u);
            }
        }
    }
    return Distances(start, dist, parent);
}

Distances dist_dp(int start) {
    vector<int> dist(N, INF);
    vector<int> parent(N, -1);
    dist[start] = 0;
    while (true) {
        int updated = 0;
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < N; j++) {
                if (i == j) continue;
                int w = INF;
                if (DISTS[i][j] <= 50) w = 3;
                else if (DISTS[i][j] <= 100) w = 20;
                if (dist[j] > dist[i] + w) {
                    dist[j] = dist[i] + w;
                    parent[j] = i;
                    updated = 1;
                }
            }
        }
        if (!updated) break;
    }
    return Distances(start, dist, parent);
}

int TOTAL_SCORE = 0;

constexpr int CMD_MOVE = 1;
constexpr int CMD_UNPACK = 2;
constexpr int CMD_PACK = 3;
constexpr int CMD_TEAMUNPACK = 4;
constexpr int CMD_TEAMPACK = 5;
struct Command {
    int type;
    int id;
    int pos;
    int partner_id;

    Command() : type(0), id(-1), pos(-1), partner_id(-1) {}
    Command(int t, int i, int p, int pid = -1) : type(t), id(i), pos(p), partner_id(pid) {}
};

struct State {
    int turn;
    vector<Bridgeman> units;
    int connected[100][100];
};

int main() {
    ios_base::sync_with_stdio(false);cin.tie(0);

    cin >> N >> B >> O;
    cerr << "[DATA] N = " << N << "\n";
    cerr << "[DATA] B = " << B << "\n";
    cerr << "[DATA] O = " << O << "\n";


    for (int i = 0; i < N; ++i) {
        for (int j = 0; j < N; ++j) {
            cin >> DISTS[i][j];
        }
    }

    vector<Distances> all_dists;
    vector<Distances> dists_dp;
    for (int i = 0; i < N; ++i) {
        all_dists.push_back(bfs(i, 50));
        dists_dp.push_back(dist_dp(i));
    }

    State cur_state;
    cur_state.units.resize(B);
    int lastElapsedTime = 0;
    int lastIters = 1000;
    int totalIters = 0;
    for (int turn = 1; turn <= 1000; turn++) {
        int elapsedTime;
        std::cin >> elapsedTime;
        cerr << "Turn " << turn << ", elapsed: " << elapsedTime / 1000.0 << endl;

        for (int i = 0; i < B; i++) {
            cin >> cur_state.units[i].pos >> cur_state.units[i].bricks >> cur_state.units[i].order_target;
        }

        vector<Command> opt_commands;
        State opt_state;
        int global_opt_score = INF;

        vector<Order> orders(O);
        for (int i = 0; i < O; i++) {
            cin >> orders[i].from >> orders[i].to;
        }

        double timeDelta = (elapsedTime - lastElapsedTime) / 1000.0;
        if (timeDelta < 1e-3) {
            timeDelta = 1e-3;
        }
        double timePerIter = elapsedTime / 1000.0 / totalIters;
        double iterCountEstimate =  (TL - elapsedTime / 1000.0) / timePerIter / (1001 - turn);
        cerr << timePerIter << " seconds per iter, estimated iters left: " << iterCountEstimate << endl;
        iterCountEstimate = min(2000.0, iterCountEstimate);
        iterCountEstimate = max(1.0, iterCountEstimate);
        iterCountEstimate = iterCountEstimate * 0.8 + lastIters * 0.2;
        int iterCount = min(1500, max(1, (int)iterCountEstimate));
        lastElapsedTime = elapsedTime;
        lastIters = iterCount;
        totalIters += iterCount;
        cerr << "Iter count: " << iterCount << endl;
        for (int iter = 0; iter < iterCount; iter++) {
            vector<int> moved(B, 0);
            vector<int> order_taken(O, 0);
            vector<int> target(B, -1);

            State state = cur_state;
            vector<int> idx(B);
            iota(idx.begin(), idx.end(), 0);
            random_shuffle(idx.begin(), idx.end());
            // shuffle(idx.begin(), idx.end(), rng);
            vector<Command> commands;
            for (int i: idx) {
                if (state.units[i].order_target == -1) {
                    int opt_order = -1;
                    int opt_score = INF;
                    for (int j = 0; j < O; j++) {
                        if (order_taken[j]) continue;
                        // if (all_dists[units[i].pos].dist[orders[j].from] == INF) continue;
                        int d = dists_dp[state.units[i].pos].dist[orders[j].from];
                        // if (d == INF) continue;
                        int score = d;
                        // int score = d + dists_dp[orders[j].from].dist[orders[j].to];
                        if (score < opt_score) {
                            opt_order = j;
                            opt_score = score;
                        }
                    }
                    if (opt_order != -1) {
                        order_taken[opt_order] = 1;
                        target[i] = orders[opt_order].from;
                    }
                } else {
                    target[i] = state.units[i].order_target;
                }
            }

            for (int i: idx) {
                if (target[i] == -1 || state.units[i].bridge_from != -1 || state.units[i].bridge_to != -1) continue;
                for (int to = 0; to < N; to++) {
                    if (!state.connected[state.units[i].pos][to]) continue;
                    if (dists_dp[to].dist[target[i]] + 1 < dists_dp[state.units[i].pos].dist[target[i]]) {
                        commands.push_back(Command(CMD_MOVE, i, to));
                        state.units[i].pos = to;
                        moved[i] = 1;
                        break;
                    }
                }
            }



            for (int i: idx) {
                if (target[i] == -1 || moved[i] || state.units[i].bridge_from == -1 || state.units[i].partner != -1) continue;
                if (dists_dp[state.units[i].bridge_from].dist[target[i]] + 2 < dists_dp[state.units[i].pos].dist[target[i]] + 1) {
                    commands.push_back(Command(CMD_MOVE, i, state.units[i].bridge_from));
                    int old_i_pos = state.units[i].pos;
                    state.units[i].pos = state.units[i].bridge_from;
                    moved[i] = 1;
                    state.units[i].bridge_from = old_i_pos;
                }
            }

            for (int i: idx) {
                for (int j: idx) {
                    if (i >= j) continue;
                    if (target[i] == -1 && target[j] == -1) continue;
                    if (moved[i] || moved[j]) continue;
                    int d = DISTS[state.units[i].pos][state.units[j].pos];
                    if (d <= 50 || d > 100) continue;
                    if (state.units[i].bridge_from != -1 || state.units[i].bridge_to != -1) continue;
                    if (state.units[j].bridge_from != -1 || state.units[j].bridge_to != -1) continue;

                    assert(state.units[i].bricks == 50);
                    assert(state.units[j].bricks == 50);

                    auto get_dp = [&](int pos1, int pos2) {
                        int res = 0;
                        if (target[i] != -1) {
                            res += dists_dp[pos1].dist[target[i]];
                        }
                        if (target[j] != -1) {
                            res += dists_dp[pos2].dist[target[j]];
                        }
                        return res;
                    };

                    int cur_dp = get_dp(state.units[i].pos, state.units[j].pos);
                    int new_dp = get_dp(state.units[j].pos, state.units[i].pos) + 1;
                    if (new_dp < cur_dp) {
                        if (state.connected[state.units[i].pos][state.units[j].pos]) {
                            // cerr << "Team Moving " << i << " from " << state.units[i].pos << " to " << state.units[j].pos << endl;
                            commands.push_back(Command(CMD_MOVE, i, state.units[j].pos));
                            int old_i_pos = state.units[i].pos;
                            state.units[i].pos = state.units[j].pos;
                            
                            // cerr << "Team Moving " << j << " from " << state.units[j].pos << " to " << state.units[i].pos << endl;
                            commands.push_back(Command(CMD_MOVE, j, old_i_pos));
                            state.units[j].pos = old_i_pos;
                            moved[i] = moved[j] = 1;
                        } else {
                            commands.push_back(Command(CMD_TEAMUNPACK, i, -1, j));
                            state.units[i].partner = j;
                            state.units[j].partner = i;
                            state.units[i].bridge_to = state.units[j].pos;
                            state.units[j].bridge_to = state.units[i].pos;
                            state.connected[state.units[i].pos][state.units[j].pos] = true;
                            state.connected[state.units[j].pos][state.units[i].pos] = true;
                            moved[i] = moved[j] = 1;
                        }
                    }
                }
            }

            for (int i: idx) {
                if (target[i] == -1 || state.units[i].bridge_from != -1 || state.units[i].bridge_to != -1 || moved[i]) continue;
                assert(state.units[i].bricks == 50);

                int to = dists_dp[target[i]].parent[state.units[i].pos];
                if (DISTS[state.units[i].pos][to] > 50) to = all_dists[target[i]].parent[state.units[i].pos];
                if (to == -1) continue;
                if (!state.connected[state.units[i].pos][to]) {
                    commands.push_back(Command(CMD_UNPACK, i, to));
                    // commands.push_back("UNPACK " + to_string(i) + " " + to_string(to));
                    state.connected[state.units[i].pos][to] = true;
                    state.connected[to][state.units[i].pos] = true;
                    state.units[i].bridge_to = to;
                    moved[i] = 1;
                } else {
                    // cerr << "Moving " << i << " from " << units[i].pos << " to " << to << endl;
                    commands.push_back(Command(CMD_MOVE, i, to));
                    state.units[i].pos = to;
                    // commands.push_back("MOVE " + to_string(i) + " " + to_string(to));
                    moved[i] = 1;
                }
            }            

            for (int i: idx) {
                if (moved[i] || state.units[i].bridge_to == -1) continue;
                assert(state.connected[state.units[i].pos][state.units[i].bridge_to]);
                commands.push_back(Command(CMD_MOVE, i, state.units[i].bridge_to));
                int old_i_pos = state.units[i].pos;
                state.units[i].pos = state.units[i].bridge_to;
                moved[i] = 1;
                state.units[i].bridge_to = -1;
                state.units[i].bridge_from = old_i_pos;
                state.units[i].pos = target[i];
            }

            for (int i: idx) {
                if (moved[i] || state.units[i].bridge_from == -1) continue;
                assert(state.connected[state.units[i].bridge_from][state.units[i].pos]);

                if (state.units[i].partner != -1) {
                    int p = state.units[i].partner;
                    assert(!moved[p]);
                    assert(state.units[p].partner == i);
                    assert(state.units[i].bridge_from == state.units[p].pos);
                    assert(state.units[p].bridge_from == state.units[i].pos);
                    commands.push_back(Command(CMD_TEAMPACK, i, -1, p));
                    // commands.push_back("TEAMPACK " + to_string(i) + " " + to_string(p) + " " + to_string(50 - units[i].bricks));
                    moved[i] = 1;
                    moved[p] = 1;
                    // cerr << "disconnect " << units[i].bridge_from << " " << units[i].pos << endl;
                    state.connected[state.units[i].bridge_from][state.units[i].pos] = false;
                    state.connected[state.units[i].pos][state.units[i].bridge_from] = false;
                    state.units[i].bridge_from = state.units[p].bridge_from = -1;
                    state.units[i].partner = state.units[p].partner = -1;
                } else {
                    commands.push_back(Command(CMD_PACK, i, state.units[i].bridge_from));
                    // commands.push_back("PACK " + to_string(i) + " " + to_string(state.units[i].bridge_from));
                    state.connected[state.units[i].bridge_from][state.units[i].pos] = false;
                    state.connected[state.units[i].pos][state.units[i].bridge_from] = false;
                    moved[i] = 1;
                    state.units[i].bridge_from = -1;
                }
            }

            int total_score = 0;
            for (int i = 0; i < B; i++) {
                if (target[i] != -1) {
                    total_score += dists_dp[state.units[i].pos].dist[target[i]];
                }
            }
            if (total_score < global_opt_score) {
                global_opt_score = total_score;
                opt_commands = commands;
                opt_state = state;
            }
        }            

        for (int i = 0; i < (int) opt_commands.size(); ++i) {
            Command cmd = opt_commands[i];
            if (cmd.type == CMD_MOVE) {
                cout << "MOVE " << cmd.id << " " << cmd.pos;
            } else if (cmd.type == CMD_UNPACK) {
                cout << "UNPACK " << cmd.id << " " << cmd.pos;
            } else if (cmd.type == CMD_PACK) {
                cout << "PACK " << cmd.id << " " << cmd.pos;
            } else if (cmd.type == CMD_TEAMUNPACK) {
                cout << "TEAMUNPACK " << cmd.id << " " << cmd.partner_id << " 50";
            } else if (cmd.type == CMD_TEAMPACK) {
                cout << "TEAMPACK " << cmd.id << " " << cmd.partner_id << " " << (50 - cur_state.units[cmd.id].bricks);
            }
            if (i < (int) opt_commands.size() - 1) {
                cout << " | ";
            }
        }
        cur_state = opt_state;



       
        
        // for (int i = 0; i < B; i++) {
        //     if (units[i].pos == units[i].order_target) {
        //         TOTAL_SCORE++;
        //     }
        // }

        // for (int i = 0; i < (int) commands.size(); ++i) {
        //     cout << commands[i];
        //     // cerr << commands[i];
        //     if (i < (int) commands.size() - 1) {
        //         cout << " | ";
        //         // cerr << " | ";
        //     }
        // }
        cout << endl;
        // cerr << endl;
    }

    cerr << "[DATA] SCORE_PER_B = " << 1.0 * TOTAL_SCORE / B << "\n";

    return 0;
}