// solver_all_features.cpp
// Full heuristic solver: MST backbone + TEAM moves + PACK/TEAMPACK + proactive & reactive heuristics.
// Compile: g++ -O2 -std=c++17 solver_all_features.cpp -o solver

#include <bits/stdc++.h>
using namespace std;

struct Edge { int u,v,d; };
struct DSU {
    int n; vector<int> p;
    DSU(int n=0):n(n),p(n){ for(int i=0;i<n;i++) p[i]=i; }
    int find(int x){ return p[x]==x?x:p[x]=find(p[x]); }
    bool unite(int a,int b){ a=find(a); b=find(b); if(a==b) return false; p[b]=a; return true; }
};

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    const int INIT_CARRY = 50;
    const int MAX_CARRY = 60;
    int N,B,O;
    if(!(cin >> N)) return 0;
    cin >> B >> O;

    vector<vector<int>> dist(N, vector<int>(N));
    for(int i=0;i<N;i++){
        for(int j=0;j<N;j++){
            cin >> dist[i][j];
        }
    }

    // Precompute MST edges (Kruskal)
    vector<Edge> allEdges;
    for(int i=0;i<N;i++) for(int j=i+1;j<N;j++) allEdges.push_back({i,j,dist[i][j]});
    sort(allEdges.begin(), allEdges.end(), [](const Edge&a,const Edge&b){ return a.d < b.d; });
    DSU dsu(N);
    vector<Edge> mst;
    for(auto &e : allEdges){
        if(dsu.unite(e.u,e.v)){
            mst.push_back(e);
            if((int)mst.size() == N-1) break;
        }
    }

    // Local model of built bridges and bookkeeping
    vector<vector<bool>> built(N, vector<bool>(N,false));
    vector<vector<int>> lastUsed(N, vector<int>(N, -1000000)); // last turn when edge used
    int currentTurn = 0;

    string runTimeLine; getline(cin, runTimeLine); // eat endline

    // Helper: BFS next-hop on built graph
    auto bfs_next_hop = [&](int start, int target)->int{
        if(start==target) return start;
        vector<int> parent(N, -1);
        deque<int> dq;
        parent[start]=start; dq.push_back(start);
        while(!dq.empty()){
            int u=dq.front(); dq.pop_front();
            for(int v=0; v<N; ++v){
                if(!built[u][v]) continue;
                if(parent[v] != -1) continue;
                parent[v] = u;
                if(v==target){
                    int cur=v, prev=parent[cur];
                    while(prev != start){
                        cur = prev; prev = parent[cur];
                    }
                    return cur;
                }
                dq.push_back(v);
            }
        }
        return -1;
    };

    // Utility: find nearest order-from island reachable by built graph
    auto bfs_nearest_order_from = [&](int start, const vector<int>& orderFromCount)->pair<int,int>{
        // returns (foundIsland, nextHop) or (-1,-1)
        vector<int> parent(N, -1);
        deque<int> dq;
        parent[start]=start; dq.push_back(start);
        while(!dq.empty()){
            int u = dq.front(); dq.pop_front();
            if(orderFromCount[u] > 0) return {u, start}; // same node
            for(int v=0; v<N; ++v){
                if(!built[u][v]) continue;
                if(parent[v] != -1) continue;
                parent[v] = u;
                if(orderFromCount[v]>0){
                    int cur=v;
                    int prev=parent[cur];
                    while(prev != start){
                        cur = prev; prev = parent[cur];
                    }
                    return {v, cur};
                }
                dq.push_back(v);
            }
        }
        return {-1,-1};
    };

    // helper to mark built edge usage
    auto mark_used_edge = [&](int u,int v,int turn){
        built[u][v] = built[v][u] = true;
        lastUsed[u][v] = lastUsed[v][u] = turn;
    };

    // Helper to mark a PACK (edge removal)
    auto remove_edge = [&](int u,int v){
        built[u][v] = built[v][u] = false;
        // lastUsed stays as history
    };

    // Main loop
    while(true){
        // Read runTimeLine, with resilience to blank lines
        if(!getline(cin, runTimeLine)) break;
        if(runTimeLine.size() == 0){
            if(!getline(cin, runTimeLine)) break;
        }
        // parse time line but we don't need numeric value
        currentTurn++;

        // Read bridgemen state
        vector<int> pos(B), carry(B), targ(B);
        bool ok = true;
        for(int i=0;i<B;i++){
            if(!(cin >> pos[i] >> carry[i] >> targ[i])){
                ok = false; break;
            }
        }
        if(!ok) break;

        // Read O orders
        vector<pair<int,int>> orders;
        orders.reserve(O);
        for(int i=0;i<O;i++){
            int f,d; cin >> f >> d;
            orders.emplace_back(f,d);
        }
        // eat newline
        getline(cin, runTimeLine);

        // Build order origin counts
        vector<int> orderFromCount(N,0);
        for(auto &p: orders) orderFromCount[p.first]++;

        // Commands to emit
        vector<string> commands;
        vector<bool> usedThisTurn(B, false);

        // Utility lambdas for scheduling safe commands and internal simulation updates:
        auto cmd_MOVE = [&](int bid, int to){
            commands.push_back("MOVE " + to_string(bid) + " " + to_string(to));
            usedThisTurn[bid] = true;
            // we do NOT update pos[] here — tester will update next turn. But for local logic,
            // if we want to reason further in the same turn, we can simulate moving along built edges:
            // However to avoid inconsistencies we'll not mutate pos[].
        };
        auto cmd_UNPACK = [&](int bid, int to){
            commands.push_back("UNPACK " + to_string(bid) + " " + to_string(to));
            usedThisTurn[bid] = true;
            // update local model: reduce carry and mark built
            int u = pos[bid], v = to;
            int need = dist[u][v];
            carry[bid] -= need;
            if(carry[bid] < 0) carry[bid] = 0; // safety
            built[u][v] = built[v][u] = true;
            lastUsed[u][v] = lastUsed[v][u] = currentTurn;
        };
        auto cmd_TEAMUNPACK = [&](int b1, int b2, int len1){
            commands.push_back("TEAMUNPACK " + to_string(b1) + " " + to_string(b2) + " " + to_string(len1));
            usedThisTurn[b1] = usedThisTurn[b2] = true;
            int u = pos[b1], v = pos[b2];
            int need = dist[u][v];
            int len2 = need - len1;
            if(len2 < 0) len2 = 0;
            carry[b1] -= len1;
            carry[b2] -= len2;
            if(carry[b1] < 0) carry[b1]=0;
            if(carry[b2] < 0) carry[b2]=0;
            built[u][v] = built[v][u] = true;
            lastUsed[u][v] = lastUsed[v][u] = currentTurn;
        };
        auto cmd_PACK = [&](int bid, int to){
            commands.push_back("PACK " + to_string(bid) + " " + to_string(to));
            usedThisTurn[bid] = true;
            int u = pos[bid], v = to;
            int len = dist[u][v];
            // add len back but cap to MAX_CARRY
            carry[bid] += len;
            if(carry[bid] > MAX_CARRY) carry[bid] = MAX_CARRY;
            // remove edge locally
            built[u][v] = built[v][u] = false;
        };
        auto cmd_TEAMPACK = [&](int b1, int b2, int len1){
            commands.push_back("TEAMPACK " + to_string(b1) + " " + to_string(b2) + " " + to_string(len1));
            usedThisTurn[b1] = usedThisTurn[b2] = true;
            int u = pos[b1], v = pos[b2];
            int total = dist[u][v];
            int len2 = total - len1;
            carry[b1] += len1; if(carry[b1] > MAX_CARRY) carry[b1] = MAX_CARRY;
            carry[b2] += len2; if(carry[b2] > MAX_CARRY) carry[b2] = MAX_CARRY;
            built[u][v] = built[v][u] = false;
        };

        // ===== PHASE A: Serve agents who already have messages (high priority) =====
        for(int b=0;b<B;b++){
            if(usedThisTurn[b]) continue;
            if(targ[b] == -1) continue;
            int u = pos[b], v = targ[b];
            if(u == v) continue; // tester will clear target
            // 1) If built direct edge -> MOVE
            if(built[u][v]){
                cmd_MOVE(b, v);
                lastUsed[u][v] = lastUsed[v][u] = currentTurn;
                continue;
            }
            int need = dist[u][v];
            // 2) Can unpack alone?
            if(carry[b] >= need){
                cmd_UNPACK(b, v);
                continue;
            }
            // 3) Look for partner at v that is unused and can help
            int partner = -1;
            for(int j=0;j<B;j++){
                if(j==b) continue;
                if(usedThisTurn[j]) continue;
                if(pos[j] != v) continue;
                if(carry[b] + carry[j] >= need){
                    partner = j; break;
                }
            }
            if(partner != -1){
                int len1 = min(carry[b], need);
                if(len1 < 0) len1 = 0;
                cmd_TEAMUNPACK(b, partner, len1);
                continue;
            }
            // 4) If no partner at v, try to build a short interim hop toward v if possible
            // Find any node m such that dist[u][m] <= carry[b] and building u-m brings agent closer (compare euclidean hops)
            int bestM = -1, bestDist = INT_MAX;
            for(int m=0;m<N;m++){
                if(m==u) continue;
                if(built[u][m]) continue; // already built
                int dlen = dist[u][m];
                if(dlen > carry[b]) continue;
                // prefer m that reduces raw dist to target (dist[m][v] smaller)
                if(dist[m][v] < bestDist){
                    bestDist = dist[m][v];
                    bestM = m;
                }
            }
            if(bestM != -1){
                cmd_UNPACK(b, bestM);
                continue;
            }
            // 5) Finally, try to move along built network (if partial path exists)
            int nextHop = bfs_next_hop(u, v);
            if(nextHop != -1 && nextHop != u){
                cmd_MOVE(b, nextHop);
                lastUsed[u][nextHop] = lastUsed[nextHop][u] = currentTurn;
                continue;
            }
            // else: nothing we can do this turn for this agent
        }

        // ===== PHASE B: Try to build MST backbone edges that remain unbuilt =====
        // We will attempt a small number of MST builds per turn to avoid overusing agents.
        int mstBuildBudget = max(1, (int)min((int)mst.size(), B/2)); // simple throttle
        for(auto &e : mst){
            if(mstBuildBudget <= 0) break;
            int u = e.u, v = e.v;
            if(built[u][v]) continue;
            // If an agent is at u with enough carry, ask it to UNPACK
            int aAtU = -1;
            for(int i=0;i<B;i++){
                if(usedThisTurn[i]) continue;
                if(pos[i] == u && carry[i] >= e.d){
                    aAtU = i; break;
                }
            }
            if(aAtU != -1){
                cmd_UNPACK(aAtU, v);
                mstBuildBudget--;
                continue;
            }
            // If agent at v can unpack towards u
            int aAtV = -1;
            for(int i=0;i<B;i++){
                if(usedThisTurn[i]) continue;
                if(pos[i] == v && carry[i] >= e.d){
                    aAtV = i; break;
                }
            }
            if(aAtV != -1){
                cmd_UNPACK(aAtV, u);
                mstBuildBudget--;
                continue;
            }
            // TEAMUNPACK if two agents at u and v respectively with combined capacity
            int aid = -1, bid = -1;
            for(int i=0;i<B;i++){
                if(usedThisTurn[i]) continue;
                if(pos[i] == u) { aid = i; break;}
            }
            for(int j=0;j<B;j++){
                if(usedThisTurn[j]) continue;
                if(j==aid) continue;
                if(pos[j] == v){ bid = j; break; }
            }
            if(aid != -1 && bid != -1 && carry[aid] + carry[bid] >= e.d){
                int len1 = min(carry[aid], e.d);
                cmd_TEAMUNPACK(aid, bid, len1);
                mstBuildBudget--;
                continue;
            }
            // else skip this edge for now
        }

        // ===== PHASE C: Try to serve visible orders that are currently unserved by idle bridgemen =====
        // We try to assign idle bridgemen to pick up orders greedily by distance (raw dist or graph hops).
        // For each order, find the best idle bridgeman.
        vector<bool> orderHandled(orders.size(), false);
        for(size_t oid=0; oid<orders.size(); ++oid){
            int o = orders[oid].first, d = orders[oid].second;
            // is there an idle agent already on origin? If yes, it will take it automatically (no action needed).
            bool originHasIdleAgent = false;
            for(int i=0;i<B;i++){
                if(usedThisTurn[i]) continue;
                if(targ[i] != -1) continue;
                if(pos[i] == o) { originHasIdleAgent = true; break; }
            }
            if(originHasIdleAgent) { orderHandled[oid] = true; continue; }

            // else choose the idle bridgeman who can get to 'o' fastest:
            int bestAgent = -1; int bestScore = INT_MAX;
            for(int i=0;i<B;i++){
                if(usedThisTurn[i]) continue;
                if(targ[i] != -1) continue;
                int p = pos[i];
                // prefer already connected via built graph (0-edges cost); else raw dist
                int nexthop = bfs_next_hop(p, o);
                int score = INT_MAX;
                if(nexthop != -1){
                    // few hops -> low score (we don't compute exact hop count; approximate by 1)
                    score = 1;
                } else {
                    // if can unpack directly to origin, prefer it
                    if(carry[i] >= dist[p][o]) score = 2;
                    else score = 100000 + dist[p][o]; // far away and needs multi-step
                }
                if(score < bestScore){
                    bestScore = score; bestAgent = i;
                }
            }
            if(bestAgent != -1 && bestScore < 100000){
                // If bestAgent can move along built graph, move toward origin
                int p = pos[bestAgent];
                int nexthop = bfs_next_hop(p, o);
                if(nexthop != -1 && nexthop != p){
                    cmd_MOVE(bestAgent, nexthop);
                    lastUsed[p][nexthop] = lastUsed[nexthop][p] = currentTurn;
                    orderHandled[oid] = true;
                    continue;
                }
                // else if can UNPACK directly -> do so
                if(carry[bestAgent] >= dist[p][o] && !built[p][o]){
                    cmd_UNPACK(bestAgent, o);
                    orderHandled[oid] = true;
                    continue;
                }
            }
        }

        // ===== PHASE D: Proactive PACK/TEAMPACK for old unused edges to reclaim materials =====
        // Pack edges not used for a while (aging) if agents available at endpoints and packing fits their carry limit.
        int PACK_AGE = 180; // turns threshold to consider reclaiming (heuristic)
        // iterate built edges (prefer longer edges first to reclaim more material)
        vector<pair<int,pair<int,int>>> builtEdgesList;
        for(int i=0;i<N;i++) for(int j=i+1;j<N;j++){
            if(built[i][j]) builtEdgesList.push_back({dist[i][j],{i,j}});
        }
        sort(builtEdgesList.begin(), builtEdgesList.end(), greater<>()); // pack longer first
        for(auto &be : builtEdgesList){
            int u = be.second.first, v = be.second.second;
            if(currentTurn - lastUsed[u][v] < PACK_AGE) continue; // recently used
            // try single-agent PACK at endpoint if that agent is there, unused, and would not overflow
            bool packed = false;
            for(int i=0;i<B;i++){
                if(usedThisTurn[i]) continue;
                if(pos[i] == u){
                    int gain = dist[u][v];
                    if(carry[i] + gain <= MAX_CARRY){
                        cmd_PACK(i, v);
                        packed = true; break;
                    }
                }
                if(usedThisTurn[i]) continue;
                if(pos[i] == v){
                    int gain = dist[u][v];
                    if(carry[i] + gain <= MAX_CARRY){
                        cmd_PACK(i, u);
                        packed = true; break;
                    }
                }
            }
            if(packed) continue;
            // try TEAMPACK: find two unused agents at u and v that can take the split without overflowing
            int a=-1,b=-1;
            for(int i=0;i<B;i++){
                if(usedThisTurn[i]) continue;
                if(pos[i]==u) { a=i; break; }
            }
            for(int j=0;j<B;j++){
                if(usedThisTurn[j]) continue;
                if(j==a) continue;
                if(pos[j]==v) { b=j; break; }
            }
            if(a!=-1 && b!=-1){
                int total = dist[u][v];
                // choose len1 as min(total, MAX_CARRY - carry[a])
                int len1 = min(total, MAX_CARRY - carry[a]);
                int len2 = total - len1;
                if(len2 <= MAX_CARRY - carry[b]){
                    // safe to TEAMPACK
                    cmd_TEAMPACK(a,b,len1);
                    continue;
                } else {
                    // try other split
                    len2 = min(total, MAX_CARRY - carry[b]);
                    len1 = total - len2;
                    if(len1 <= MAX_CARRY - carry[a]){
                        cmd_TEAMPACK(a,b,len1);
                        continue;
                    }
                }
            }
        }

        // ===== PHASE E: Idle agents movement to gather near useful islands (origins or MST hubs) =====
        for(int i=0;i<B;i++){
            if(usedThisTurn[i]) continue;
            if(targ[i] != -1) continue;
            int cur = pos[i];
            // if we are already on an order origin -> stay to pick up
            if(orderFromCount[cur] > 0) continue;

            // prefer moving towards a nearby origin using built graph
            auto pna = bfs_nearest_order_from(cur, orderFromCount);
            int foundIsland = pna.first, nextHop = pna.second;
            if(foundIsland != -1){
                if(nextHop != cur){
                    // move toward nextHop
                    cmd_MOVE(i, nextHop);
                    lastUsed[cur][nextHop] = lastUsed[nextHop][cur] = currentTurn;
                    continue;
                } else {
                    // already same node? then stay
                    continue;
                }
            }

            // else, try to move toward nearest MST hub endpoint not built yet (to help building)
            // find MST edge endpoint that is unbuilt
            int goal = -1;
            for(auto &e : mst){
                if(!built[e.u][e.v]){
                    // pick the closer of e.u,e.v
                    int du = dist[cur][e.u], dv = dist[cur][e.v];
                    goal = (du < dv ? e.u : e.v);
                    break;
                }
            }
            if(goal != -1){
                int next = bfs_next_hop(cur, goal);
                if(next != -1 && next != cur){
                    cmd_MOVE(i, next);
                    lastUsed[cur][next] = lastUsed[next][cur] = currentTurn;
                    continue;
                } else {
                    // if we can unpack directly to goal and not used
                    if(!built[cur][goal] && carry[i] >= dist[cur][goal]){
                        cmd_UNPACK(i, goal);
                        continue;
                    }
                }
            }

            // otherwise remain idle
        }

        // ===== PHASE F: Final attempt to cover any remaining agents with targets (after new edges built this turn) =====
        for(int b=0;b<B;b++){
            if(usedThisTurn[b]) continue;
            if(targ[b] == -1) continue;
            int u = pos[b], v = targ[b];
            if(u==v) continue;
            if(built[u][v]){
                cmd_MOVE(b, v);
                lastUsed[u][v] = lastUsed[v][u] = currentTurn;
            } else {
                // last resort: if can pack/teampack somewhere nearby to get enough carry, skip for now
            }
        }

        // Output commands joined by '|'
        if(commands.empty()){
            cout << "\n" << flush;
        } else {
            for(size_t i=0;i<commands.size(); ++i){
                if(i) cout << "|";
                cout << commands[i];
            }
            cout << "\n" << flush;
        }

    } // end main loop

    return 0;
}
