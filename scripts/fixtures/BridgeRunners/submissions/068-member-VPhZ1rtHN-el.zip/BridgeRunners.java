import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

class BridgeRunners {

    private static int g_seed = 777778;

    private static int rand(int mod) {
        g_seed = (214013 * g_seed + 2531011);
        return ((g_seed >> 16) & 0x7FFF) % mod;
    }

    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        int N = Integer.parseInt(reader.readLine());
        int B = Integer.parseInt(reader.readLine());
        int O = Integer.parseInt(reader.readLine());

        int[][] dists = new int[N][N];
        boolean[][] connected = new boolean[N][N];
        for (int i = 0; i < N; i++) {
            String[] line = reader.readLine().split(" ");
            for (int j = 0; j < N; j++) {
                dists[i][j] = Integer.parseInt(line[j]);
            }
        }

        List<Bridgeman> bridgemen = IntStream.range(0, B)
                .mapToObj(i -> new Bridgeman(i))
                .collect(Collectors.toList());

        for (int turn = 1; turn <= 1000; turn++) {
            int elapsedTime = Integer.parseInt(reader.readLine());
            for (int i = 0; i < B; i++) {
                String[] line = reader.readLine().split(" ");
                bridgemen.get(i).position = Integer.parseInt(line[0]);
                bridgemen.get(i).bricks = Integer.parseInt(line[1]);
                bridgemen.get(i).target = Integer.parseInt(line[2]);
            }
            List<Order> orders = new ArrayList<>();
            for (int i = 0; i < O; i++) {
                String[] line = reader.readLine().split(" ");
                Order o = new Order(Integer.parseInt(line[0]), Integer.parseInt(line[1]));
                orders.add(o);
            }

            List<String> output = new ArrayList<>();
            for (Bridgeman b : bridgemen) {
                if (b.bridgeFrom == -1) { // unpack
                    List<Integer> targets = IntStream.range(0, N)
                            .filter(t -> t != b.position && !connected[b.position][t] && dists[b.position][t] <= b.bricks)
                            .boxed()
                            .collect(Collectors.toList());
                    if (!targets.isEmpty()) {
                        int t = targets.get(rand(targets.size()));
                        output.add("UNPACK " + b.id + " " + t);
                        b.bridgeFrom = b.position;
                        b.bridgeTo = t;
                        connected[b.bridgeFrom][b.bridgeTo] = true;
                        connected[b.bridgeTo][b.bridgeFrom] = true;
                    }
                } else if (b.bridgeFrom == b.position) { // MOVE
                    output.add("MOVE " + b.id + " " + b.bridgeTo);
                } else { // PACK
                    output.add("PACK " + b.id + " " + b.bridgeFrom);
                    connected[b.bridgeFrom][b.bridgeTo] = false;
                    connected[b.bridgeTo][b.bridgeFrom] = false;
                    b.bridgeFrom = -1;
                    b.bridgeTo = -1;
                }
            }

            System.out.println(String.join(" | ", output));
        }
    }
}

class Bridgeman {
    int id;
    int position;
    int target;
    int bricks;

    int bridgeFrom = -1;
    int bridgeTo = -1;

    public Bridgeman(int id) {
        this.id = id;
    }
}

class Order {
    int from;
    int to;

    public Order(int from, int to) {
        this.from = from;
        this.to = to;
    }
}