#ifndef LOCAL
#undef _GLIBCXX_DEBUG
#pragma GCC optimize("O3,inline")
#pragma GCC target("mmx,sse,sse2,sse3,ssse3,sse4.1,sse4.2,popcnt,cx16,sahf,fxsr,avx,xsave,pclmul")
#endif

// Common.hpp

#if defined(_WIN32)
#define PLATFORM_WINDOWS 1
#if defined(_WIN64)
#define ARCH_64 1
#else
#define ARCH_64 0
#endif
#else
#define PLATFORM_WINDOWS 0
#if defined(__x86_64__)
#define ARCH_64 1
#elif defined(__i386__)
#define ARCH_64 0
#else
#error "Can't determine if architecture is 32-bit or 64-bit"
#endif
#endif

#include <stddef.h>
#define __STDC_LIMIT_MACROS
#define __STDC_CONSTANT_MACROS
#define __STDC_FORMAT_MACROS
#include <inttypes.h>
#include <stdlib.h>
#include <stdarg.h>
#include <stdio.h>
#include <string.h>

#if PLATFORM_WINDOWS
#define PRIuZ "Iu"
#define PRIoZ "Io"
#define PRIxZ "Ix"
#define PRIXZ "IX"
#define PRIdT "Id"
#define PRIiT "Ii"
#define PRIoT "Io"
#define PRIxT "Ix"
#define PRIXT "IX"
#else
#define PRIuZ "zu"
#define PRIoZ "zo"
#define PRIxZ "zx"
#define PRIXZ "zX"
#define PRIdT "td"
#define PRIiT "ti"
#define PRIoT "to"
#define PRIxT "tx"
#define PRIXT "tX"
#endif

#include <string>
#include <vector>
#include <set>
#include <map>
#include <functional>
#include <memory>
#include <utility>
#include <algorithm>

// Xoshiro.hpp

#include <random>

template<typename T, size_t N, typename Derived>
class XoshiroBase
{
public:
    typedef T result_type;

    static constexpr T min() { return 0; }
    static constexpr T max() { return -1; }

    void seed()
    {
        std::seed_seq seq;
        seed(seq);
    }

private:
    void seedHelper(uint32_t value)
    {
        std::seed_seq seq{value};
        seed(seq);
    }

    void seedHelper(uint64_t value)
    {
        std::seed_seq seq{(uint32_t)value, (uint32_t)(value >> 32)};
        seed(seq);
    }

public:
    void seed(T value)
    {
        seedHelper(value);
    }

    template<class Sseq>
    void seed(Sseq& seq)
    {
        constexpr size_t M = sizeof(T) / sizeof(uint32_t);
        uint32_t seeds[N * M];
        seq.generate(seeds, seeds + N * M);
        for (size_t i = 0; i < N; i++)
        {
            T si = 0;
            for (size_t j = 0; j < M; j++)
            {
                si |= (T)seeds[i * M + j] << (32 * j);
            }
            s[i] = si;
        }
    }

    void discard(unsigned long long n)
    {
        Derived* pThis = static_cast<Derived*>(this);
        while (n > 0)
        {
            pThis->operator()();
            n--;
        }
    }

    bool operator==(const XoshiroBase& other) const
    {
        for (size_t i = 0; i < N; i++)
        {
            if (s[i] != other.s[i])
            {
                return false;
            }
        }
        return true;
    }

    bool operator!=(const XoshiroBase& other) const
    {
        return !(*this == other);
    }

protected:
    static T rotl(T x, int k)
    { return (x << k) | (x >> (sizeof(T) * 8 - k)); }

    T s[4];
};

class Xoshiro256PlusPlus : public XoshiroBase<uint64_t, 4, Xoshiro256PlusPlus>
{
public:
    Xoshiro256PlusPlus() { seed(); }
    explicit Xoshiro256PlusPlus(uint64_t value) { seed(value); }
    template<class Sseq>
    explicit Xoshiro256PlusPlus(Sseq& seq) { seed(seq); }

    uint64_t operator()()
    {
        uint64_t result = rotl(s[0] + s[3], 23) + s[0];

        uint64_t t = s[1] << 17;

        s[2] ^= s[0];
        s[3] ^= s[1];
        s[1] ^= s[2];
        s[0] ^= s[3];

        s[2] ^= t;

        s[3] = rotl(s[3], 45);

        return result;
    }
};

class Xoshiro256StarStar : public XoshiroBase<uint64_t, 4, Xoshiro256StarStar>
{
public:
    Xoshiro256StarStar() { seed(); }
    explicit Xoshiro256StarStar(uint64_t value) { seed(value); }
    template<class Sseq>
    explicit Xoshiro256StarStar(Sseq& seq) { seed(seq); }

    uint64_t operator()()
    {
        uint64_t result = rotl(s[1] * 5, 7) * 9;

        uint64_t t = s[1] << 17;

        s[2] ^= s[0];
        s[3] ^= s[1];
        s[1] ^= s[2];
        s[0] ^= s[3];

        s[2] ^= t;

        s[3] = rotl(s[3], 45);

        return result;
    }
};

class Xoshiro256Plus : public XoshiroBase<uint64_t, 4, Xoshiro256Plus>
{
public:
    Xoshiro256Plus() { seed(); }
    explicit Xoshiro256Plus(uint64_t value) { seed(value); }
    template<class Sseq>
    explicit Xoshiro256Plus(Sseq& seq) { seed(seq); }

    uint64_t operator()()
    {
        uint64_t result = s[0] + s[3];

        uint64_t t = s[1] << 17;

        s[2] ^= s[0];
        s[3] ^= s[1];
        s[1] ^= s[2];
        s[0] ^= s[3];

        s[2] ^= t;

        s[3] = rotl(s[3], 45);

        return result;
    }
};

class Xoroshiro128PlusPlus : public XoshiroBase<uint64_t, 2, Xoroshiro128PlusPlus>
{
public:
    Xoroshiro128PlusPlus() { seed(); }
    explicit Xoroshiro128PlusPlus(uint64_t value) { seed(value); }
    template<class Sseq>
    explicit Xoroshiro128PlusPlus(Sseq& seq) { seed(seq); }

    uint64_t operator()()
    {
        uint64_t result = rotl(s[0] + s[1], 17) + s[0];

        s[1] ^= s[0];
        s[0] = rotl(s[0], 49) ^ s[1] ^ (s[1] << 21);
        s[1] = rotl(s[1], 28);

        return result;
    }
};

class Xoroshiro128StarStar : public XoshiroBase<uint64_t, 2, Xoroshiro128StarStar>
{
public:
    Xoroshiro128StarStar() { seed(); }
    explicit Xoroshiro128StarStar(uint64_t value) { seed(value); }
    template<class Sseq>
    explicit Xoroshiro128StarStar(Sseq& seq) { seed(seq); }

    uint64_t operator()()
    {
        uint64_t result = rotl(s[0] * 5, 7) * 9;

        s[1] ^= s[0];
        s[0] = rotl(s[0], 24) ^ s[1] ^ (s[1] << 16);
        s[1] = rotl(s[1], 37);

        return result;
    }
};

class Xoroshiro128Plus : public XoshiroBase<uint64_t, 2, Xoroshiro128Plus>
{
public:
    Xoroshiro128Plus() { seed(); }
    explicit Xoroshiro128Plus(uint64_t value) { seed(value); }
    template<class Sseq>
    explicit Xoroshiro128Plus(Sseq& seq) { seed(seq); }

    uint64_t operator()()
    {
        uint64_t result = s[0] + s[1];

        s[1] ^= s[0];
        s[0] = rotl(s[0], 24) ^ s[1] ^ (s[1] << 16);
        s[1] = rotl(s[1], 37);

        return result;
    }
};

class Xoshiro128PlusPlus : public XoshiroBase<uint32_t, 4, Xoshiro128PlusPlus>
{
public:
    Xoshiro128PlusPlus() { seed(); }
    explicit Xoshiro128PlusPlus(uint32_t value) { seed(value); }
    template<class Sseq>
    explicit Xoshiro128PlusPlus(Sseq& seq) { seed(seq); }

    uint32_t operator()()
    {
        uint32_t result = rotl(s[0] + s[3], 7) + s[0];

        uint32_t t = s[1] << 9;

        s[2] ^= s[0];
        s[3] ^= s[1];
        s[1] ^= s[2];
        s[0] ^= s[3];

        s[2] ^= t;

        s[3] = rotl(s[3], 11);

        return result;
    }
};

class Xoshiro128StarStar : public XoshiroBase<uint32_t, 4, Xoshiro128StarStar>
{
public:
    Xoshiro128StarStar() { seed(); }
    explicit Xoshiro128StarStar(uint32_t value) { seed(value); }
    template<class Sseq>
    explicit Xoshiro128StarStar(Sseq& seq) { seed(seq); }

    uint32_t operator()()
    {
        uint32_t result = rotl(s[1] * 5, 7) * 9;

        uint32_t t = s[1] << 9;

        s[2] ^= s[0];
        s[3] ^= s[1];
        s[1] ^= s[2];
        s[0] ^= s[3];

        s[2] ^= t;

        s[3] = rotl(s[3], 11);

        return result;
    }
};

class Xoshiro128Plus : public XoshiroBase<uint32_t, 4, Xoshiro128Plus>
{
public:
    Xoshiro128Plus() { seed(); }
    explicit Xoshiro128Plus(uint32_t value) { seed(value); }
    template<class Sseq>
    explicit Xoshiro128Plus(Sseq& seq) { seed(seq); }

    uint32_t operator()()
    {
        uint32_t result = s[0] + s[3];

        uint32_t t = s[1] << 9;

        s[2] ^= s[0];
        s[3] ^= s[1];
        s[1] ^= s[2];
        s[0] ^= s[3];

        s[2] ^= t;

        s[3] = rotl(s[3], 11);

        return result;
    }
};

// FastRandom.hpp

#include <type_traits>

// fastRandom
//
// Generate a random number from 0 to range-1 without using division.
// Use as a faster alternative to std::uniform_int_distribution.
// Assumes that Gen returns a full 32 or 64 bits of random data.

template<typename Gen, typename = std::enable_if_t<std::is_same_v<typename Gen::result_type, uint64_t>>>
uint64_t fastRandom(uint64_t range, Gen& gen)
{
#if ARCH_64
    return ((__uint128_t)range * gen()) >> 64;
#else
    return gen() % range;
#endif
}

template<typename Gen, typename = std::enable_if_t<std::is_same_v<typename Gen::result_type, uint32_t>>>
uint32_t fastRandom(uint32_t range, Gen& gen)
{
    return ((uint64_t)range * gen()) >> 32;
}

// fastShuffle
//
// Shuffle the given range into a random order without using division.
// Use as a faster alternative to std::shuffle.
// Assumes that Gen returns a full 32 or 64 bits of random data.

template<class It, class Gen>
void fastShuffle(It first, It last, Gen& gen)
{
    size_t size = last - first;
    while (size > 1)
    {
        size_t pos = fastRandom(size, gen);
        size--;
        using std::swap;
        swap(*(first + pos), *(first + size));
    }
}

// fastRandomReal<T>
// fastRandomDouble
// fastRandomFloat
//
// 1 argument version: Generate a random real number between 0 and 1.
// 2 argument version: Generate a random real number between 0 and range.
// 3 argument version: Generate a random real number between low and high.
// Use as a faster alternative to std::uniform_real_distribution.
// Assumes that Gen returns a full 32 or 64 bits of random data.

template<typename RealType, typename Gen>
RealType fastRandomReal(Gen& gen)
{
    return (RealType)gen() * ((RealType)1 / (RealType)(typename Gen::result_type)-1);
}

template<typename RealType, typename Gen>
RealType fastRandomReal(RealType range, Gen& gen)
{
    return fastRandomReal<RealType>(gen) * range;
}

template<typename RealType, typename Gen>
RealType fastRandomReal(RealType low, RealType high, Gen& gen)
{
    return fastRandomReal<RealType>(gen) * (high - low) + low;
}

template<typename Gen>
double fastRandomDouble(Gen& gen)
{ return fastRandomReal<double>(gen); }

template<typename Gen>
double fastRandomDouble(double range, Gen& gen)
{ return fastRandomReal<double>(range, gen); }

template<typename Gen>
double fastRandomDouble(double low, double high, Gen& gen)
{ return fastRandomReal<double>(low, high, gen); }

template<typename Gen>
float fastRandomFloat(Gen& gen)
{ return fastRandomReal<float>(gen); }

template<typename Gen>
float fastRandomFloat(float range, Gen& gen)
{ return fastRandomReal<float>(range, gen); }

template<typename Gen>
float fastRandomFloat(float low, float high, Gen& gen)
{ return fastRandomReal<float>(low, high, gen); }

// TimeUtils.hpp

void sleepS(uint32_t durationS);
void sleepMS(uint32_t durationMS);

uint64_t getTimeS();
uint64_t getTimeMS();

// ProcessId.hpp

uint32_t getProcessId();

// ParseUtils.hpp

bool parseU32(const std::string& str, uint32_t* pValue = nullptr);
bool parseI32(const std::string& str, int32_t* pValue = nullptr);
bool parseU64(const std::string& str, uint64_t* pValue = nullptr);
bool parseI64(const std::string& str, int64_t* pValue = nullptr);
bool parseFloat(const std::string& str, float* pValue = nullptr);
bool parseDouble(const std::string& str, double* pValue = nullptr);
bool parseDurationS(const std::string& str, uint64_t* pDurationS = nullptr);
bool parseDurationMS(const std::string& str, uint64_t* pDurationMS = nullptr);

// TimeUtils.cpp

#if PLATFORM_WINDOWS
#include <windows.h>
#else
#include <time.h>
#endif

void sleepS(uint32_t durationS)
{
    sleepMS(durationS * 1000);
}

void sleepMS(uint32_t durationMS)
{
#if PLATFORM_WINDOWS
    Sleep(durationMS);
#else
    struct timespec req;
    memset(&req, 0, sizeof(req));
    req.tv_sec = (time_t)(durationMS / 1000);
    req.tv_nsec = (long)((durationMS % 1000) * 1000000);
    nanosleep(&req, nullptr);
#endif
}

uint64_t getTimeS()
{
#if PLATFORM_WINDOWS
    return (uint64_t)GetTickCount64() / UINT64_C(1000);
#else
    struct timespec ts;
    memset(&ts, 0, sizeof(ts));
    if (clock_gettime(CLOCK_MONOTONIC_RAW, &ts) != 0)
    {
        fprintf(stderr, "clock_gettime failed\n");
        exit(1);
    }
    uint64_t val = (uint64_t)ts.tv_sec;
    return val;
#endif
}

uint64_t getTimeMS()
{
#if PLATFORM_WINDOWS
    return (uint64_t)GetTickCount64();
#else
    struct timespec ts;
    memset(&ts, 0, sizeof(ts));
    if (clock_gettime(CLOCK_MONOTONIC_RAW, &ts) != 0)
    {
        fprintf(stderr, "clock_gettime failed\n");
        exit(1);
    }
    uint64_t val = (uint64_t)ts.tv_sec;
    val *= 1000;
    val += ((uint64_t)ts.tv_nsec) / 1000000;
    return val;
#endif
}

// ProcessId.cpp

#if PLATFORM_WINDOWS
#include <windows.h>
#else
#include <sys/types.h>
#include <unistd.h>
#endif

uint32_t getProcessId()
{
#if PLATFORM_WINDOWS
    return (uint32_t)GetCurrentProcessId();
#else
    return (uint32_t)getpid();
#endif
}

// ParseUtils.cpp

#include <limits>
#include <type_traits>

using std::string;

namespace
{
    template<typename T>
    bool parseIntImpl(const string& str, T* pValue)
    {
        T base = 10;
        size_t size = str.size();
        if (size == 0) return false;

        bool neg = false;
        size_t pos = 0;
        if (std::is_signed<T>::value && str[0] == '-')
        {
            if (size == 1) return false;
            neg = true;
            pos = 1;
        }

        T value = 0;
        for (; pos < size; pos++)
        {
            if (neg)
            {
                if (value < std::numeric_limits<T>::min() / base)
                {
                    return false;
                }
            }
            else
            {
                if (value > std::numeric_limits<T>::max() / base)
                {
                    return false;
                }
            }
            value *= base;
            char ch = str[pos];
            T digit;
            if (ch >= '0' && ch <= '9')
            {
                digit = ch - '0';
            }
            else if (ch >= 'a' && ch <= 'z')
            {
                digit = ch - 'a' + 10;
            }
            else if (ch >= 'A' && ch <= 'Z')
            {
                digit = ch - 'A' + 10;
            }
            else
            {
                return false;
            }
            if (digit >= base)
            {
                return false;
            }
            if (neg)
            {
                if (-digit < std::numeric_limits<T>::min() - value)
                {
                    return false;
                }
                value -= digit;
            }
            else
            {
                if (digit > std::numeric_limits<T>::max() - value)
                {
                    return false;
                }
                value += digit;
            }
        }
        if (pValue)
        {
            *pValue = value;
        }
        return true;
    }

    template<typename T, typename F>
    bool parseFloatImpl(const string& str, T* pValue, F&& f)
    {
        {
            size_t size = str.size();
            size_t pos = 0;
            if (size != 0 && str[0] == '-')
            {
                pos = 1;
            }
            bool gotDot = false;
            bool gotDigit = false;
            for (; pos < size; pos++)
            {
                char ch = str[pos];
                if (ch == '.')
                {
                    if (gotDot) return false;
                    gotDot = true;
                }
                else if (ch >= '0' && ch <= '9')
                {
                    gotDigit = true;
                }
                else
                {
                    return false;
                }
            }
            if (!gotDigit)
            {
                return false;
            }
        }
        const char* nptr = str.c_str();
        char* endptr = nullptr;
        errno = 0;
        auto value = f(nptr, &endptr);
        if (errno != 0 || *nptr == '\0' || *endptr != '\0')
        {
            return false;
        }
        if (pValue)
        {
            *pValue = (T)value;
        }
        return true;
    }
}

bool parseU32(const string& str, uint32_t* pValue)
{
    return parseIntImpl(str, pValue);
}

bool parseI32(const string& str, int32_t* pValue)
{
    return parseIntImpl(str, pValue);
}

bool parseU64(const string& str, uint64_t* pValue)
{
    return parseIntImpl(str, pValue);
}

bool parseI64(const string& str, int64_t* pValue)
{
    return parseIntImpl(str, pValue);
}

bool parseFloat(const string& str, float* pValue)
{
    return parseFloatImpl(str, pValue, strtof);
}

bool parseDouble(const string& str, double* pValue)
{
    return parseFloatImpl(str, pValue, strtod);
}

namespace
{
    bool parseDurationImpl(const string& str, bool wantMS, uint64_t* pDuration)
    {
        bool gotH = false;
        bool gotM = false;
        bool gotS = false;
        string strH;
        string strM;
        string strS;
        size_t size = str.size();
        size_t pos = 0;
        size_t start = pos;
        bool gotDot = false;
        while (pos < size)
        {
            char ch = str[pos++];
            if (ch >= '0' && ch <= '9')
            {
            }
            else if (ch == '.')
            {
                if (!wantMS || gotDot) return false;
                gotDot = true;
            }
            else if (ch == 'h')
            {
                if (gotDot || gotH || gotM || gotS) return false;
                if (pos - 1 == start) return false;
                gotH = true;
                strH = str.substr(start, pos - 1 - start);
                start = pos;
                gotDot = false;
            }
            else if (ch == 'm')
            {
                if (gotDot || gotM || gotS) return false;
                if (pos - 1 == start) return false;
                gotM = true;
                strM = str.substr(start, pos - 1 - start);
                start = pos;
                gotDot = false;
            }
            else if (ch == 's')
            {
                if (gotS) return false;
                if (pos - 1 == start) return false;
                gotS = true;
                strS = str.substr(start, pos - 1 - start);
                start = pos;
                gotDot = false;
            }
        }
        if (pos != start) return false;
        if (!gotH && !gotM && !gotS) return false;

        uint64_t h = 0;
        if (gotH)
        {
            if (!parseU64(strH, &h)) return false;
        }

        uint64_t m = 0;
        if (gotM)
        {
            if (!parseU64(strM, &m)) return false;
            if (gotH && m >= 60) return false;
        }

        uint64_t s = 0;
        uint64_t ms = 0;
        if (gotS)
        {
            auto dotPos = strS.find('.');
            if (dotPos == string::npos)
            {
                if (!parseU64(strS, &s)) return false;
            }
            else
            {
                string strBefore = strS.substr(0, dotPos);
                string strAfter = strS.substr(dotPos + 1);
                if (!strBefore.empty())
                {
                    if (!parseU64(strBefore, &s)) return false;
                }
                if (strAfter.empty()) return false;
                if (strAfter.size() > 3) return false;
                if (strAfter.size() > 0) ms += 100 * (strAfter[0] - '0');
                if (strAfter.size() > 1) ms += 10 * (strAfter[1] - '0');
                if (strAfter.size() > 2) ms += 1 * (strAfter[2] - '0');
            }
            if (gotM && s >= 60) return false;
            if (gotH && s >= 3600) return false;
        }

        uint64_t limit = std::numeric_limits<uint64_t>::max();
        if (wantMS) limit /= 1000;

        uint64_t duration = 0;

        if (h > (limit - duration) / (60 * 60)) return false;
        duration += h * 60 * 60;

        if (m > (limit - duration) / 60) return false;
        duration += m * 60;

        if (s > (limit - duration)) return false;
        duration += s;

        if (wantMS)
        {
            duration *= 1000;
            limit = std::numeric_limits<uint64_t>::max();

            if (ms > (limit - duration)) return false;
            duration += ms;
        }

        if (pDuration) *pDuration = duration;
        return true;
    }
}

bool parseDurationS(const string& str, uint64_t* pDurationS)
{
    return parseDurationImpl(str, false, pDurationS);
}

bool parseDurationMS(const string& str, uint64_t* pDurationMS)
{
    return parseDurationImpl(str, true, pDurationMS);
}

// solve.cpp

using std::string;
using std::vector;
using std::unique_ptr;

#define PROFILE 0

typedef Xoshiro256StarStar Gen;

constexpr const uint64_t minN = 25;
constexpr const uint64_t maxN = 80;
constexpr const uint64_t minB = 4;
constexpr const uint64_t maxB = 20;
constexpr const uint64_t minO = 4;
constexpr const uint64_t maxO = 10;

class Guy
{
public:
    uint8_t islandIdx;
    uint8_t carry;
    uint8_t destIdx;
};

class Order
{
public:
    uint8_t origIdx;
    uint8_t destIdx;
};

class Problem
{
public:
    uint64_t N;
    uint64_t B;
    uint64_t O;
    uint32_t dists[maxN][maxN];
    Guy guys[maxB];
    Order orders[maxO];
    uint64_t turn;
    uint64_t elapsedTime;
};

string readLine(FILE* f)
{
    string line;
    while (true)
    {
        int iCh = fgetc(f);
        if (iCh == EOF)
        {
            fprintf(stderr, "Unexpected end of input\n");
            exit(1);
        }
        char ch = (char)(unsigned char)iCh;
        if (ch == '\n') break;
        line.push_back(ch);
    }
    return line;
}

vector<string> split(const string& str, char splitCh)
{
    vector<string> strs(1);
    for (char ch : str)
    {
        if (ch == splitCh)
        {
            strs.emplace_back();
        }
        else
        {
            strs.back().push_back(ch);
        }
    }
    return strs;
}

void readProblem(FILE* f, Problem& problem)
{
    string strN = readLine(f);
    if (!parseU64(strN, &problem.N))
    {
        fprintf(stderr, "Error parsing N\n");
        exit(1);
    }
    if (problem.N < minN || problem.N > maxN)
    {
        fprintf(stderr, "N out of range\n");
        exit(1);
    }

    string strB = readLine(f);
    if (!parseU64(strB, &problem.B))
    {
        fprintf(stderr, "Error parsing B\n");
        exit(1);
    }
    if (problem.B < minB || problem.B > maxB)
    {
        fprintf(stderr, "B out of range\n");
        exit(1);
    }

    string strO = readLine(f);
    if (!parseU64(strO, &problem.O))
    {
        fprintf(stderr, "Error parsing O\n");
        exit(1);
    }
    if (problem.O < minO || problem.O > maxO)
    {
        fprintf(stderr, "O out of range\n");
        exit(1);
    }

    uint64_t N = problem.N;
    for (uint64_t islandIdxI = 0; islandIdxI < N; islandIdxI++)
    {
        string distLine = readLine(f);
        vector<string> distFields = split(distLine, ' ');
        if (distFields.size() != N)
        {
            fprintf(stderr, "Error parsing distances\n");
            exit(1);
        }
        
        for (uint64_t islandIdxJ = 0; islandIdxJ < N; islandIdxJ++)
        {
            if (!parseU32(distFields[islandIdxJ], &problem.dists[islandIdxI][islandIdxJ]))
            {
                fprintf(stderr, "Error parsing distance\n");
                exit(1);
            }
        }
    }
}

void readTurn(FILE* f, Problem& problem)
{
    string strElapsedTime = readLine(f);
    if (!parseU64(strElapsedTime, &problem.elapsedTime))
    {
        fprintf(stderr, "Error parsing elapsed time\n");
        exit(1);
    }

    uint64_t N = problem.N;
    uint64_t B = problem.B;
    uint64_t O = problem.O;

    for (uint64_t guyIdx = 0; guyIdx < B; guyIdx++)
    {
        string guyLine = readLine(f);
        vector<string> guyFields = split(guyLine, ' ');
        uint64_t islandIdx;
        uint64_t carry;
        int64_t destIdx;
        if (guyFields.size() != 3 ||
            !parseU64(guyFields[0], &islandIdx) ||
            !parseU64(guyFields[1], &carry) ||
            !parseI64(guyFields[2], &destIdx) ||
            islandIdx >= N ||
            carry > 60 ||
            destIdx >= (int64_t)N ||
            destIdx < -1)
        {
            fprintf(stderr, "Error parsing bridgeman\n");
            exit(1);
        }
        auto& guy = problem.guys[guyIdx];
        guy.islandIdx = (uint8_t)islandIdx;
        guy.carry = (uint8_t)carry;
        guy.destIdx = (uint8_t)destIdx;
    }

    for (uint64_t orderIdx = 0; orderIdx < O; orderIdx++)
    {
        string orderLine = readLine(f);
        vector<string> orderFields = split(orderLine, ' ');
        uint64_t origIdx;
        uint64_t destIdx;
        if (orderFields.size() != 2 ||
            !parseU64(orderFields[0], &origIdx) ||
            !parseU64(orderFields[1], &destIdx) ||
            origIdx >= N ||
            destIdx >= N)
        {
            fprintf(stderr, "Error parsing order\n");
            exit(1);
        }
        auto& order = problem.orders[orderIdx];
        order.origIdx = (uint8_t)origIdx;
        order.destIdx = (uint8_t)destIdx;
    }
}

enum class ActionType : uint8_t
{
    Move,
    Unpack,
    Pack,
    TeamUnpack,
    TeamPack
};

class Action
{
public:
    explicit Action(ActionType actionType_ = ActionType::Move,
                    uint8_t arg1_ = 0,
                    uint8_t arg2_ = 0,
                    uint8_t arg3_ = 0) :
        actionType(actionType_),
        arg1(arg1_),
        arg2(arg2_),
        arg3(arg3_)
    {
    }

    ActionType actionType;
    uint8_t arg1;
    uint8_t arg2;
    uint8_t arg3;
};

typedef vector<Action> Actions;

void writeAction(FILE* f, const Action& action)
{
    uint64_t argCount = 0;

    switch (action.actionType)
    {
    case ActionType::Move: fprintf(f, "MOVE"); argCount = 2; break;
    case ActionType::Unpack: fprintf(f, "UNPACK"); argCount = 2; break;
    case ActionType::Pack: fprintf(f, "PACK"); argCount = 2; break;
    case ActionType::TeamUnpack: fprintf(f, "TEAMUNPACK"); argCount = 3; break;
    case ActionType::TeamPack: fprintf(f, "TEAMPACK"); argCount = 3; break;
    default: ;
    }

    if (argCount >= 1) fprintf(f, " %" PRIu8 "", action.arg1);
    if (argCount >= 2) fprintf(f, " %" PRIu8 "", action.arg2);
    if (argCount >= 3) fprintf(f, " %" PRIu8 "", action.arg3);
}

void writeActions(FILE* f, const Actions& actions)
{
    uint64_t actionCount = actions.size();
    for (uint64_t actionIdx = 0; actionIdx < actionCount; actionIdx++)
    {
        if (actionIdx != 0) fprintf(f, "|");
        writeAction(f, actions[actionIdx]);
    }
    fprintf(f, "\n");
}

class Solver
{
public:
    Solver() {}
    virtual ~Solver() {}

    virtual void init(const Problem& problem) {}
    virtual Actions step(const Problem& problem) = 0;
};

class TrivialSolver : public Solver
{
public:
    virtual Actions step(const Problem& problem) override
    {
        return Actions();
    }
};

class SingleSolver : public Solver
{
public:
    class PathEntry
    {
    public:
        uint8_t dist;
        uint8_t nextIdx;
    };

    void findPaths(const Problem& problem)
    {
        uint64_t N = problem.N;
        vector<uint8_t> q;
        for (uint64_t destIdx = 0; destIdx < N; destIdx++)
        {
            for (uint64_t srcIdx = 0; srcIdx < N; srcIdx++)
            {
                paths[destIdx][srcIdx].dist = 255;
                paths[destIdx][srcIdx].nextIdx = 255;
            }

            paths[destIdx][destIdx].dist = 0;
            paths[destIdx][destIdx].nextIdx = destIdx;
            q.push_back(destIdx);

            for (uint64_t qIdx = 0; qIdx < q.size(); qIdx++)
            {
                uint64_t oldIdx = q[qIdx];
                uint8_t dist = paths[destIdx][oldIdx].dist + 1;
                for (uint64_t newIdx = 0; newIdx < N; newIdx++)
                {
                    if (problem.dists[oldIdx][newIdx] > 50) continue;
                    if (paths[destIdx][newIdx].dist != 255) continue;
                    paths[destIdx][newIdx].dist = dist;
                    paths[destIdx][newIdx].nextIdx = oldIdx;
                    q.push_back(newIdx);
                }
            }

            q.clear();
        }
    }

    virtual void init(const Problem& problem) override
    {
        findPaths(problem);

        uint64_t N = problem.N;
        uint64_t B = problem.B;

        for (uint64_t guyIdx = 0; guyIdx < B; guyIdx++)
        {
            guyIslands[guyIdx] = problem.guys[guyIdx].islandIdx;
            guyBridges[guyIdx] = 255;
        }

        for (uint64_t islandIdxI = 0; islandIdxI < N; islandIdxI++)
        {
            for (uint64_t islandIdxJ = 0; islandIdxJ < N; islandIdxJ++)
            {
                bridges[islandIdxI][islandIdxJ] = 0;
            }
        }
    }

    virtual Actions step(const Problem& problem) override
    {
        //fprintf(stderr, "======== turn %" PRIu64 " ========\n", problem.turn);
        uint64_t B = problem.B;
        uint64_t O = problem.O;

        uint8_t guyAssigned[maxB];
        uint8_t orderAssigned[maxO];

        for (uint64_t guyIdx = 0; guyIdx < B; guyIdx++)
        {
            guyAssigned[guyIdx] = 0;
        }
        for (uint64_t orderIdx = 0; orderIdx < O; orderIdx++)
        {
            orderAssigned[orderIdx] = 0;
        }

        uint8_t guyDests[maxB];
        for (uint64_t guyIdx = 0; guyIdx < B; guyIdx++)
        {
            guyDests[guyIdx] = problem.guys[guyIdx].destIdx;
        }
        for (uint64_t orderIdx = 0; orderIdx < O; orderIdx++)
        {
            auto& order = problem.orders[orderIdx];
            uint8_t origIdx = order.origIdx;
            for (uint64_t guyIdx = 0; guyIdx < B; guyIdx++)
            {
                if (guyDests[guyIdx] != 255) continue;
                uint8_t islandIdx = guyIslands[guyIdx];
                if (islandIdx == origIdx)
                {
                    guyDests[guyIdx] = order.destIdx;
                    orderAssigned[orderIdx] = 1;
                    break;
                }
            }
        }

        uint8_t targets[maxB];
        for (uint64_t guyIdx = 0; guyIdx < B; guyIdx++)
        {
            uint8_t islandIdx = guyIslands[guyIdx];
            uint8_t destIdx = guyDests[guyIdx];
            uint8_t targetIdx = islandIdx;
            if (destIdx != 255)
            {
                uint8_t nextIdx = paths[destIdx][islandIdx].nextIdx;
                if (nextIdx != 255)
                {
                    targetIdx = nextIdx;
                    //fprintf(stderr, "guy %" PRIu64 ", dest %" PRIu8 ", target %" PRIu8 "\n", guyIdx, destIdx, targetIdx);
                }
            }
            targets[guyIdx] = targetIdx;
        }

        while (true)
        {
            uint64_t bestDist = (uint64_t)-1;
            uint64_t bestGuyIdx = (uint64_t)-1;
            uint64_t bestOrderIdx = (uint64_t)-1;
            uint8_t bestNextIdx = 255;

            for (uint64_t guyIdx = 0; guyIdx < B; guyIdx++)
            {
                if (guyAssigned[guyIdx]) continue;
                if (guyDests[guyIdx] != 255) continue;
                uint8_t islandIdx = guyIslands[guyIdx];
                for (uint64_t orderIdx = 0; orderIdx < O; orderIdx++)
                {
                    if (orderAssigned[orderIdx]) continue;
                    auto& order = problem.orders[orderIdx];
                    uint8_t origIdx = order.origIdx;
                    uint64_t dist = paths[origIdx][islandIdx].dist;
                    uint8_t nextIdx = paths[origIdx][islandIdx].nextIdx;
                    dist *= 3;
                    uint8_t bridgeIdx = guyBridges[guyIdx];
                    if (bridgeIdx != 255)
                    {
                        if (bridgeIdx == nextIdx)
                        {
                            dist--;
                        }
                        else
                        {
                            dist++;
                        }
                    }
                    if (dist < bestDist)
                    {
                        bestDist = dist;
                        bestGuyIdx = guyIdx;
                        bestOrderIdx = orderIdx;
                        bestNextIdx = nextIdx;
                    }
                }
            }

            if (bestDist == (uint64_t)-1) break;
            
            targets[bestGuyIdx] = bestNextIdx;
            guyAssigned[bestGuyIdx] = 1;
            orderAssigned[bestOrderIdx] = 1;
            //fprintf(stderr, "guy %" PRIu64 ", order %" PRIu64 ", orig %" PRIu8 ", target %" PRIu8 "\n", bestGuyIdx, bestOrderIdx, problem.orders[bestOrderIdx].origIdx, bestNextIdx);
        }

        Actions actions;

        uint8_t acted[maxB];
        for (uint64_t guyIdx = 0; guyIdx < B; guyIdx++)
        {
            acted[guyIdx] = 0;
        }

        // Unpack

        for (uint64_t guyIdx = 0; guyIdx < B; guyIdx++)
        {
            uint8_t bridgeIdx = guyBridges[guyIdx];
            if (bridgeIdx != 255) continue;
            uint8_t targetIdx = targets[guyIdx];
            if (targetIdx == 255) continue;
            uint8_t islandIdx = guyIslands[guyIdx];
            if (islandIdx == targetIdx) continue;
            if (bridges[islandIdx][targetIdx]) continue;
            actions.emplace_back(ActionType::Unpack, guyIdx, targetIdx);
            //fprintf(stderr, "UNPACK %" PRIu64 ", %" PRIu8 "\n", guyIdx, targetIdx);
            guyBridges[guyIdx] = targetIdx;
            bridges[islandIdx][targetIdx] = 1;
            bridges[targetIdx][islandIdx] = 1;
            acted[guyIdx] = 1;
        }

        // Move

        for (uint64_t guyIdx = 0; guyIdx < B; guyIdx++)
        {
            if (acted[guyIdx]) continue;
            uint8_t targetIdx = targets[guyIdx];
            if (targetIdx == 255) continue;
            uint8_t islandIdx = guyIslands[guyIdx];
            if (islandIdx == targetIdx) continue;
            if (!bridges[islandIdx][targetIdx]) continue;
            uint8_t bridgeIdx = guyBridges[guyIdx];
            if (bridgeIdx != 255 && bridgeIdx != targetIdx) continue;
            actions.emplace_back(ActionType::Move, guyIdx, targetIdx);
            //fprintf(stderr, "MOVE %" PRIu64 ", %" PRIu8 "\n", guyIdx, targetIdx);
            guyIslands[guyIdx] = targetIdx;
            if (bridgeIdx == targetIdx)
            {
                guyBridges[guyIdx] = islandIdx;
            }
            acted[guyIdx] = 1;
        }

        // Pack

        for (uint64_t guyIdx = 0; guyIdx < B; guyIdx++)
        {
            if (acted[guyIdx]) continue;
            uint8_t bridgeIdx = guyBridges[guyIdx];
            if (bridgeIdx == 255) continue;
            uint8_t targetIdx = targets[guyIdx];
            if (bridgeIdx == targetIdx) continue;
            uint8_t islandIdx = guyIslands[guyIdx];
            actions.emplace_back(ActionType::Pack, guyIdx, bridgeIdx);
            //fprintf(stderr, "PACK %" PRIu64 ", %" PRIu8 "\n", guyIdx, bridgeIdx);
            guyBridges[guyIdx] = 255;
            bridges[islandIdx][bridgeIdx] = 0;
            bridges[bridgeIdx][islandIdx] = 0;
            acted[guyIdx] = 1;
        }

        return actions;
    }

private:
    PathEntry paths[maxN][maxN];
    uint8_t guyIslands[maxB];
    uint8_t guyBridges[maxB];
    uint8_t bridges[maxN][maxN];
};

class TeamSolver : public Solver
{
public:
    class PathEntry
    {
    public:
        uint8_t dist;
        uint8_t clusterDist;
        uint8_t nextIdx;
    };

    class Guy
    {
    public:
        uint8_t islandIdx;
        uint8_t bridgeIdx;
        uint8_t partnerIdx;
        uint8_t destIdx;
        uint8_t targetIdx;
        bool acted;
        bool stuck;
        bool stuckAssigned;
    };

    void findPaths(const Problem& problem)
    {
        uint64_t N = problem.N;
        vector<uint8_t> q;
        for (uint64_t destIdx = 0; destIdx < N; destIdx++)
        {
            for (uint64_t srcIdx = 0; srcIdx < N; srcIdx++)
            {
                auto& entry = paths[destIdx][srcIdx];
                entry.dist = 255;
                entry.clusterDist = 255;
                entry.nextIdx = 255;
            }

            {
                auto& entry = paths[destIdx][destIdx];
                entry.dist = 0;
                entry.clusterDist = 0;
                entry.nextIdx = destIdx;
                q.push_back(destIdx);
            }

            for (uint64_t qIdx = 0; qIdx < q.size(); qIdx++)
            {
                uint64_t oldIdx = q[qIdx];
                auto& oldEntry = paths[destIdx][oldIdx];
                uint8_t dist = oldEntry.dist;
                uint8_t clusterDist = oldEntry.clusterDist;
                for (uint64_t newIdx = 0; newIdx < N; newIdx++)
                {
                    uint8_t newDist;
                    uint8_t newClusterDist;

                    if (problem.dists[oldIdx][newIdx] <= 50)
                    {
                        newDist = dist + 1;
                        newClusterDist = clusterDist;
                    }
                    else if (problem.dists[oldIdx][newIdx] <= 100)
                    {
                        newDist = dist + 2;
                        newClusterDist = clusterDist + 1;
                    }
                    else
                    {
                        continue;
                    }

                    auto& newEntry = paths[destIdx][newIdx];
                    uint8_t curDist = newEntry.dist;
                    uint8_t curClusterDist = newEntry.clusterDist;
                    if (newClusterDist < curClusterDist ||
                        (newClusterDist == curClusterDist &&
                         newDist < curDist))
                    {
                        newEntry.dist = newDist;
                        newEntry.clusterDist = newClusterDist;
                        newEntry.nextIdx = oldIdx;
                        q.push_back(newIdx);
                    }
                }
            }

            q.clear();
        }
    }

    virtual void init(const Problem& problem) override
    {
        findPaths(problem);

        uint64_t N = problem.N;
        uint64_t B = problem.B;

        for (uint64_t guyIdx = 0; guyIdx < B; guyIdx++)
        {
            auto& guy = guys[guyIdx];
            guy.islandIdx = problem.guys[guyIdx].islandIdx;
            guy.bridgeIdx = 255;
            guy.partnerIdx = 255;
        }

        for (uint64_t islandIdxI = 0; islandIdxI < N; islandIdxI++)
        {
            for (uint64_t islandIdxJ = 0; islandIdxJ < N; islandIdxJ++)
            {
                bridges[islandIdxI][islandIdxJ] = 0;
            }
        }
    }

    virtual Actions step(const Problem& problem) override
    {
        //fprintf(stderr, "======== turn %" PRIu64 " ========\n", problem.turn);
        uint64_t N = problem.N;
        uint64_t B = problem.B;
        uint64_t O = problem.O;

        bool orderAssigned[maxO];
        for (uint64_t orderIdx = 0; orderIdx < O; orderIdx++)
        {
            orderAssigned[orderIdx] = false;
        }

        for (uint64_t guyIdx = 0; guyIdx < B; guyIdx++)
        {
            auto& guy = guys[guyIdx];
            uint8_t destIdx = problem.guys[guyIdx].destIdx;
            guy.destIdx = destIdx;
            guy.targetIdx = destIdx;
            guy.acted = false;
            guy.stuck = false;
            guy.stuckAssigned = false;
        }
        for (uint64_t orderIdx = 0; orderIdx < O; orderIdx++)
        {
            auto& order = problem.orders[orderIdx];
            for (uint64_t guyIdx = 0; guyIdx < B; guyIdx++)
            {
                auto& guy = guys[guyIdx];
                if (guy.destIdx != 255) continue;
                if (guy.islandIdx == order.origIdx)
                {
                    guy.destIdx = order.destIdx;
                    guy.targetIdx = order.destIdx;
                    orderAssigned[orderIdx] = true;
                    break;
                }
            }
        }

        for (uint64_t guyIdx = 0; guyIdx < B; guyIdx++)
        {
            auto& guy = guys[guyIdx];
            if (guy.destIdx == 255) continue;
            uint8_t clusterDist = paths[guy.destIdx][guy.islandIdx].clusterDist;
            if (clusterDist == 0) continue;
            uint8_t nextIdx = paths[guy.destIdx][guy.islandIdx].nextIdx;
            uint8_t nextClusterDist = paths[guy.destIdx][nextIdx].clusterDist;
            if (nextClusterDist == clusterDist) continue;
            guy.stuck = true;
        }

        while (true)
        {
            uint64_t bestTurnDist = (uint64_t)-1;
            uint64_t bestGuyIdx = (uint64_t)-1;
            uint64_t bestOrderIdx = (uint64_t)-1;
            uint64_t bestStuckIdx = (uint64_t)-1;
            uint64_t bestTargetIdx = (uint64_t)-1;

            for (uint64_t guyIdx = 0; guyIdx < B; guyIdx++)
            {
                auto& guy = guys[guyIdx];
                if (guy.targetIdx != 255) continue;

                for (uint64_t orderIdx = 0; orderIdx < O; orderIdx++)
                {
                    if (orderAssigned[orderIdx]) continue;
                    auto& order = problem.orders[orderIdx];
                    if (paths[order.origIdx][guy.islandIdx].clusterDist != 0) continue;
                    uint8_t moveDist = paths[order.origIdx][guy.islandIdx].dist;
                    uint64_t turnDist = (uint64_t)moveDist * 3;
                    if (guy.bridgeIdx != 255)
                    {
                        if (paths[order.origIdx][guy.bridgeIdx].dist < moveDist)
                        {
                            turnDist--;
                        }
                        else
                        {
                            turnDist++;
                        }
                    }
                    if (turnDist < bestTurnDist)
                    {
                        bestTurnDist = turnDist;
                        bestGuyIdx = guyIdx;
                        bestOrderIdx = orderIdx;
                        bestStuckIdx = (uint64_t)-1;
                        bestTargetIdx = order.origIdx;
                    }
                }

                for (uint64_t stuckIdx = 0; stuckIdx < B; stuckIdx++)
                {
                    auto& stuck = guys[stuckIdx];
                    if (!stuck.stuck) continue;
                    if (stuck.stuckAssigned) continue;
                    uint8_t nextIdx = paths[stuck.destIdx][stuck.islandIdx].nextIdx;
                    if (paths[nextIdx][guy.islandIdx].clusterDist != 0) continue;
                    uint8_t moveDist = paths[nextIdx][guy.islandIdx].dist;
                    uint64_t turnDist = (uint64_t)moveDist * 3;
                    turnDist += 3;
                    if (guy.bridgeIdx != 255)
                    {
                        if (paths[nextIdx][guy.bridgeIdx].dist < moveDist)
                        {
                            turnDist--;
                        }
                        else
                        {
                            turnDist++;
                        }
                    }
                    if (turnDist < bestTurnDist)
                    {
                        bestTurnDist = turnDist;
                        bestGuyIdx = guyIdx;
                        bestOrderIdx = (uint64_t)-1;
                        bestStuckIdx = stuckIdx;
                        if (nextIdx == guy.islandIdx)
                        {
                            bestTargetIdx = stuck.islandIdx;
                        }
                        else
                        {
                            bestTargetIdx = nextIdx;
                        }
                    }
                }
            }

            if (bestTurnDist == (uint64_t)-1) break;

            auto& guy = guys[bestGuyIdx];
            guy.targetIdx = bestTargetIdx;
            if (bestOrderIdx != (uint64_t)-1)
            {
                orderAssigned[bestOrderIdx] = true;
            }
            if (bestStuckIdx != (uint64_t)-1)
            {
                guys[bestStuckIdx].stuckAssigned = true;
            }

            //fprintf(stderr, "guy %" PRIu64 ", order %" PRIi64 ", stuck %" PRIi64 ", target %" PRIu64 "\n", bestGuyIdx, bestOrderIdx, bestStuckIdx, bestTargetIdx);
        }

        Actions actions;

        // Team unpack

        for (uint64_t guyIdxI = 0; guyIdxI < B; guyIdxI++)
        {
            auto& guyI = guys[guyIdxI];
            if (guyI.acted) continue;
            if (guyI.bridgeIdx != 255) continue;
            if (guyI.targetIdx == 255) continue;
            if (guyI.islandIdx == guyI.targetIdx) continue;
            uint8_t moveDistI = paths[guyI.targetIdx][guyI.islandIdx].dist;
            uint8_t clusterDistI = paths[guyI.targetIdx][guyI.islandIdx].clusterDist;
            bool foundBridgeI = false;
            for (uint64_t nextIdxI = 0; nextIdxI < N; nextIdxI++)
            {
                if (!bridges[guyI.islandIdx][nextIdxI]) continue;
                if (paths[guyI.targetIdx][nextIdxI].dist < moveDistI ||
                    paths[guyI.targetIdx][nextIdxI].clusterDist < clusterDistI)
                {
                    foundBridgeI = true;
                    break;
                }
            }
            if (foundBridgeI) continue;
            
            for (uint64_t guyIdxJ = guyIdxI + 1; guyIdxJ < B; guyIdxJ++)
            {
                auto& guyJ = guys[guyIdxJ];
                if (guyJ.acted) continue;
                if (guyJ.bridgeIdx != 255) continue;
                if (guyJ.targetIdx == 255) continue;
                if (guyJ.islandIdx == guyJ.targetIdx) continue;
                if (guyJ.islandIdx == guyI.islandIdx) continue;

                uint32_t dist = problem.dists[guyI.islandIdx][guyJ.islandIdx];
                if (dist <= 50 || dist > 100) continue;

                uint8_t moveDistJ = paths[guyJ.targetIdx][guyJ.islandIdx].dist;
                uint8_t clusterDistJ = paths[guyJ.targetIdx][guyJ.islandIdx].clusterDist;

                uint8_t newMoveDistI = paths[guyI.targetIdx][guyJ.islandIdx].dist;
                uint8_t newClusterDistI = paths[guyI.targetIdx][guyJ.islandIdx].clusterDist;

                uint8_t newMoveDistJ = paths[guyJ.targetIdx][guyI.islandIdx].dist;
                uint8_t newClusterDistJ = paths[guyJ.targetIdx][guyI.islandIdx].clusterDist;

                if (((newMoveDistI + 2 <= moveDistI && newClusterDistI <= clusterDistI) ||
                     newClusterDistI < clusterDistI) &&
                    ((newMoveDistJ + 2 <= moveDistJ && newClusterDistJ <= clusterDistJ) ||
                     newClusterDistJ < clusterDistJ))
                {
                    // ok
                }
                else
                {
                    continue;
                }

                bool foundBridgeJ = false;
                for (uint64_t nextIdxJ = 0; nextIdxJ < N; nextIdxJ++)
                {
                    if (!bridges[guyJ.islandIdx][nextIdxJ]) continue;
                    if (paths[guyJ.targetIdx][nextIdxJ].dist < moveDistJ ||
                        paths[guyJ.targetIdx][nextIdxJ].clusterDist < clusterDistJ)
                    {
                        foundBridgeJ = true;
                        break;
                    }
                }
                if (foundBridgeJ) continue;

                actions.emplace_back(ActionType::TeamUnpack, guyIdxI, guyIdxJ, 50);
                //fprintf(stderr, "TEAMUNPACK %" PRIu64 ", %" PRIu64 ", %" PRIu8 "\n", guyIdxI, guyIdxJ, (uint8_t)50);
                guyI.bridgeIdx = guyJ.islandIdx;
                guyJ.bridgeIdx = guyI.islandIdx;
                guyI.partnerIdx = guyIdxJ;
                guyJ.partnerIdx = guyIdxI;
                bridges[guyI.islandIdx][guyJ.islandIdx] = 1;
                bridges[guyJ.islandIdx][guyI.islandIdx] = 1;
                guyI.acted = true;
                guyJ.acted = true;
                break;
            }
        }

        // Unpack

        for (uint64_t guyIdx = 0; guyIdx < B; guyIdx++)
        {
            auto& guy = guys[guyIdx];
            if (guy.acted) continue;
            if (guy.bridgeIdx != 255) continue;
            if (guy.targetIdx == 255) continue;
            if (guy.islandIdx == guy.targetIdx) continue;
            uint8_t moveDist = paths[guy.targetIdx][guy.islandIdx].dist;
            uint8_t clusterDist = paths[guy.targetIdx][guy.islandIdx].clusterDist;
            bool foundBridge = false;
            for (uint64_t nextIdx = 0; nextIdx < N; nextIdx++)
            {
                if (!bridges[guy.islandIdx][nextIdx]) continue;
                uint8_t nextMoveDist = paths[guy.targetIdx][nextIdx].dist;
                uint8_t nextClusterDist = paths[guy.targetIdx][nextIdx].clusterDist;
                if (nextClusterDist < clusterDist ||
                    (nextClusterDist == clusterDist && nextMoveDist < moveDist))
                {
                    foundBridge = true;
                    break;
                }
            }
            if (foundBridge) continue;
            uint8_t nextIdx = paths[guy.targetIdx][guy.islandIdx].nextIdx;
            if (problem.dists[guy.islandIdx][nextIdx] > 50) continue;
            actions.emplace_back(ActionType::Unpack, guyIdx, nextIdx);
            //fprintf(stderr, "UNPACK %" PRIu64 ", %" PRIu8 "\n", guyIdx, nextIdx);
            guy.bridgeIdx = nextIdx;
            bridges[guy.islandIdx][nextIdx] = 1;
            bridges[nextIdx][guy.islandIdx] = 1;
            guy.acted = true;
        }

        // Team move
        
        for (uint64_t guyIdxI = 0; guyIdxI < B; guyIdxI++)
        {
            auto& guyI = guys[guyIdxI];
            if (guyI.acted) continue;
            if (guyI.targetIdx == 255) continue;
            if (guyI.islandIdx == guyI.targetIdx) continue;
            if (guyI.bridgeIdx == 255) continue;
            if (guyI.partnerIdx == 255) continue;

            uint64_t guyIdxJ = guyI.partnerIdx;
            auto& guyJ = guys[guyIdxJ];
            if (guyJ.acted) continue;
            if (guyJ.targetIdx == 255) continue;
            if (guyJ.islandIdx == guyJ.targetIdx) continue;
            //if (guyJ.bridgeIdx == 255) continue;
            //if (guyJ.partnerIdx == 255) continue;
            //if (guyJ.partnerIdx != guyIdxI) continue;

            uint8_t moveDistI = paths[guyI.targetIdx][guyI.islandIdx].dist;
            uint8_t clusterDistI = paths[guyI.targetIdx][guyI.islandIdx].clusterDist;
            uint8_t moveDistJ = paths[guyJ.targetIdx][guyJ.islandIdx].dist;
            uint8_t clusterDistJ = paths[guyJ.targetIdx][guyJ.islandIdx].clusterDist;

            uint8_t newMoveDistI = paths[guyI.targetIdx][guyJ.islandIdx].dist;
            uint8_t newClusterDistI = paths[guyI.targetIdx][guyJ.islandIdx].clusterDist;

            uint8_t newMoveDistJ = paths[guyJ.targetIdx][guyI.islandIdx].dist;
            uint8_t newClusterDistJ = paths[guyJ.targetIdx][guyI.islandIdx].clusterDist;

            if (((newMoveDistI + 2 <= moveDistI && newClusterDistI <= clusterDistI) ||
                 newClusterDistI < clusterDistI) &&
                ((newMoveDistJ + 2 <= moveDistJ && newClusterDistJ <= clusterDistJ) ||
                 newClusterDistJ < clusterDistJ))
            {
                // ok
            }
            else
            {
                continue;
            }

            actions.emplace_back(ActionType::Move, guyIdxI, guyJ.islandIdx);
            actions.emplace_back(ActionType::Move, guyIdxJ, guyI.islandIdx);
            //fprintf(stderr, "MOVE %" PRIu64 ", %" PRIu8 "\n", guyIdxI, guyJ.islandIdx);
            //fprintf(stderr, "MOVE %" PRIu64 ", %" PRIu8 "\n", guyIdxJ, guyI.islandIdx);
            guyI.bridgeIdx = guyI.islandIdx;
            guyJ.bridgeIdx = guyJ.islandIdx;
            std::swap(guyI.islandIdx, guyJ.islandIdx);
            guyI.acted = true;
            guyJ.acted = true;
        }

        // Move

        for (uint64_t guyIdx = 0; guyIdx < B; guyIdx++)
        {
            auto& guy = guys[guyIdx];
            if (guy.acted) continue;
            if (guy.targetIdx == 255) continue;
            if (guy.islandIdx == guy.targetIdx) continue;
            uint8_t moveDist = paths[guy.targetIdx][guy.islandIdx].dist;
            uint8_t clusterDist = paths[guy.targetIdx][guy.islandIdx].clusterDist;
            uint8_t bestMoveDist = 255;
            uint8_t bestClusterDist = 255;
            uint8_t bestNextIdx = 255;
            if (guy.bridgeIdx != 255)
            {
                if (guy.partnerIdx != 255) continue;
                bestMoveDist = paths[guy.targetIdx][guy.bridgeIdx].dist;
                bestClusterDist = paths[guy.targetIdx][guy.bridgeIdx].clusterDist;
                bestNextIdx = guy.bridgeIdx;
            }
            else
            {
                for (uint64_t nextIdx = 0; nextIdx < N; nextIdx++)
                {
                    if (!bridges[guy.islandIdx][nextIdx]) continue;
                    uint8_t nextMoveDist = paths[guy.targetIdx][nextIdx].dist;
                    uint8_t nextClusterDist = paths[guy.targetIdx][nextIdx].clusterDist;
                    if (nextClusterDist < bestClusterDist ||
                        (nextClusterDist == bestClusterDist && nextMoveDist < bestMoveDist))
                    {
                        bestMoveDist = nextMoveDist;
                        bestClusterDist = nextClusterDist;
                        bestNextIdx = nextIdx;
                    }
                }
            }

            if (bestClusterDist < clusterDist ||
                (bestClusterDist == clusterDist && bestMoveDist < moveDist))
            {
                // ok
            }
            else
            {
                continue;
            }

            actions.emplace_back(ActionType::Move, guyIdx, bestNextIdx);
            //fprintf(stderr, "MOVE %" PRIu64 ", %" PRIu8 "\n", guyIdx, bestNextIdx);
            if (guy.bridgeIdx == bestNextIdx)
            {
                guy.bridgeIdx = guy.islandIdx;
            }
            guy.islandIdx = bestNextIdx;
            guy.acted = true;
        }

        // Team pack

        for (uint64_t guyIdxI = 0; guyIdxI < B; guyIdxI++)
        {
            auto& guyI = guys[guyIdxI];
            if (guyI.acted) continue;
            if (guyI.bridgeIdx == 255) continue;
            if (guyI.partnerIdx == 255) continue;

            uint64_t guyIdxJ = guyI.partnerIdx;
            auto& guyJ = guys[guyIdxJ];
            if (guyJ.acted) continue;
            //if (guyI.bridgeIdx == 255) continue;
            //if (guyI.partnerIdx == 255) continue;
            //if (guyJ.partnerIdx != guyIdxI) continue;

            actions.emplace_back(ActionType::TeamPack, guyIdxI, guyIdxJ, 50);
            //fprintf(stderr, "TEAMPACK %" PRIu64 ", %" PRIu64 ", %" PRIu8 "\n", guyIdxI, guyIdxJ, (uint8_t)50);
            bridges[guyI.islandIdx][guyJ.islandIdx] = 0;
            bridges[guyJ.islandIdx][guyI.islandIdx] = 0;
            guyI.bridgeIdx = 255;
            guyJ.bridgeIdx = 255;
            guyI.partnerIdx = 255;
            guyJ.partnerIdx = 255;
            guyI.acted = true;
            guyJ.acted = true;
        }

        // Pack

        for (uint64_t guyIdx = 0; guyIdx < B; guyIdx++)
        {
            auto& guy = guys[guyIdx];
            if (guy.acted) continue;
            if (guy.bridgeIdx == 255) continue;
            if (guy.partnerIdx != 255) continue;
            if (guy.targetIdx != 255)
            {
                uint8_t moveDist = paths[guy.targetIdx][guy.islandIdx].dist;
                uint8_t nextMoveDist = paths[guy.targetIdx][guy.bridgeIdx].dist;
                if (nextMoveDist < moveDist) continue;
            }
            actions.emplace_back(ActionType::Pack, guyIdx, guy.bridgeIdx);
            //fprintf(stderr, "PACK %" PRIu64 ", %" PRIu8 "\n", guyIdx, guy.bridgeIdx);
            bridges[guy.islandIdx][guy.bridgeIdx] = 0;
            bridges[guy.bridgeIdx][guy.islandIdx] = 0;
            guy.bridgeIdx = 255;
            guy.acted = true;
        }

        return actions;
    }

private:
    PathEntry paths[maxN][maxN];
    Guy guys[maxB];
    uint8_t bridges[maxN][maxN];
};

class Team2Solver : public Solver
{
public:
    class PathEntry
    {
    public:
        uint8_t clusterDist;
        uint8_t moveDist;
        uint8_t nextIdx;
    };

    class Guy
    {
    public:
        uint8_t islandIdx;
        uint8_t bridgeIdx;
        uint8_t partnerIdx;
        uint8_t destIdx;
        uint8_t targetIdx;
        uint8_t nearIdx;
        uint8_t farIdx;
        bool acted;
        bool stuck;
        bool stuckAssigned;
    };

    uint64_t countClusters(const Problem& problem,
                           uint64_t maxDist)
    {
        uint64_t clusterCount = 0;
        uint64_t N = problem.N;
        vector<uint8_t> processed(N);
        vector<uint8_t> q;
        for (uint64_t islandIdx = 0; islandIdx < N; islandIdx++)
        {
            if (processed[islandIdx]) continue;
            clusterCount++;
            processed[islandIdx] = 1;
            q.push_back(islandIdx);
            for (uint64_t qIdx = 0; qIdx < q.size(); qIdx++)
            {
                uint64_t oldIdx = q[qIdx];
                for (uint64_t newIdx = 0; newIdx < N; newIdx++)
                {
                    if (processed[newIdx]) continue;
                    if (problem.dists[oldIdx][newIdx] > maxDist) continue;
                    processed[newIdx] = 1;
                    q.push_back(newIdx);
                }
            }
            q.clear();
        }
        return clusterCount;
    }

    void findPaths(const Problem& problem)
    {
        uint64_t N = problem.N;
        vector<uint8_t> q;
        for (uint64_t destIdx = 0; destIdx < N; destIdx++)
        {
            for (uint64_t srcIdx = 0; srcIdx < N; srcIdx++)
            {
                auto& entry = paths[destIdx][srcIdx];
                entry.clusterDist = 255;
                entry.moveDist = 255;
                entry.nextIdx = 255;
            }

            {
                auto& entry = paths[destIdx][destIdx];
                entry.clusterDist = 0;
                entry.moveDist = 0;
                entry.nextIdx = destIdx;
                q.push_back(destIdx);
            }

            for (uint64_t qIdx = 0; qIdx < q.size(); qIdx++)
            {
                uint64_t oldIdx = q[qIdx];
                auto& oldEntry = paths[destIdx][oldIdx];
                uint8_t clusterDist = oldEntry.clusterDist;
                uint8_t moveDist = oldEntry.moveDist;
                for (uint64_t newIdx = 0; newIdx < N; newIdx++)
                {
                    uint8_t newClusterDist;
                    uint8_t newMoveDist;

                    if (problem.dists[oldIdx][newIdx] <= 50)
                    {
                        newClusterDist = clusterDist;
                        newMoveDist = moveDist + 1;
                    }
                    else if (problem.dists[oldIdx][newIdx] <= 100)
                    {
                        newClusterDist = clusterDist + 1;
                        newMoveDist = moveDist + 2;
                    }
                    else
                    {
                        continue;
                    }

                    auto& newEntry = paths[destIdx][newIdx];
                    uint8_t curClusterDist = newEntry.clusterDist;
                    uint8_t curMoveDist = newEntry.moveDist;
                    if (newClusterDist < curClusterDist ||
                        (newClusterDist == curClusterDist &&
                         newMoveDist < curMoveDist))
                    {
                        newEntry.clusterDist = newClusterDist;
                        newEntry.moveDist = newMoveDist;
                        newEntry.nextIdx = oldIdx;
                        q.push_back(newIdx);
                    }
                }
            }

            q.clear();
        }
    }

    virtual void init(const Problem& problem) override
    {
        clusterCount = countClusters(problem, 50);

        findPaths(problem);

        uint64_t N = problem.N;
        uint64_t B = problem.B;

        for (uint64_t guyIdx = 0; guyIdx < B; guyIdx++)
        {
            auto& guy = guys[guyIdx];
            guy.islandIdx = problem.guys[guyIdx].islandIdx;
            guy.bridgeIdx = 255;
            guy.partnerIdx = 255;
        }

        for (uint64_t islandIdxI = 0; islandIdxI < N; islandIdxI++)
        {
            for (uint64_t islandIdxJ = 0; islandIdxJ < N; islandIdxJ++)
            {
                bridges[islandIdxI][islandIdxJ] = 0;
            }
        }
    }

    virtual Actions step(const Problem& problem) override
    {
        //if (clusterCount != 1) return Actions();
        //if (clusterCount == 1) return Actions();

        //fprintf(stderr, "======== turn %" PRIu64 " ========\n", problem.turn);
        uint64_t N = problem.N;
        uint64_t B = problem.B;
        uint64_t O = problem.O;

        bool orderAssigned[maxO];
        for (uint64_t orderIdx = 0; orderIdx < O; orderIdx++)
        {
            orderAssigned[orderIdx] = false;
        }

        for (uint64_t guyIdx = 0; guyIdx < B; guyIdx++)
        {
            auto& guy = guys[guyIdx];
            uint8_t destIdx = problem.guys[guyIdx].destIdx;
            guy.destIdx = destIdx;
            guy.targetIdx = destIdx;
            guy.nearIdx = 255;
            guy.farIdx = 255;
            guy.acted = false;
            guy.stuck = false;
            guy.stuckAssigned = false;
        }
        for (uint64_t orderIdx = 0; orderIdx < O; orderIdx++)
        {
            auto& order = problem.orders[orderIdx];
            for (uint64_t guyIdx = 0; guyIdx < B; guyIdx++)
            {
                auto& guy = guys[guyIdx];
                if (guy.destIdx != 255) continue;
                if (guy.islandIdx == order.origIdx)
                {
                    guy.destIdx = order.destIdx;
                    guy.targetIdx = order.destIdx;
                    orderAssigned[orderIdx] = true;
                    break;
                }
            }
        }

        for (uint64_t guyIdx = 0; guyIdx < B; guyIdx++)
        {
            auto& guy = guys[guyIdx];
            if (guy.destIdx == 255) continue;
            uint8_t clusterDist = paths[guy.destIdx][guy.islandIdx].clusterDist;
            if (clusterDist == 0) continue;
            uint8_t nextIdx = paths[guy.destIdx][guy.islandIdx].nextIdx;
            uint8_t nextClusterDist = paths[guy.destIdx][nextIdx].clusterDist;
            if (nextClusterDist == clusterDist) continue;
            guy.stuck = true;
        }

        for (uint64_t guyIdx = 0; guyIdx < B; guyIdx++)
        {
            auto& guy = guys[guyIdx];
            if (guy.destIdx == 255) continue;
            uint8_t clusterDist = paths[guy.destIdx][guy.islandIdx].clusterDist;
            if (clusterDist == 0) continue;
            uint8_t nearIdx = guy.islandIdx;
            uint8_t farIdx = paths[guy.destIdx][nearIdx].nextIdx;
            while (paths[guy.destIdx][farIdx].clusterDist == clusterDist)
            {
                nearIdx = farIdx;
                farIdx = paths[guy.destIdx][nearIdx].nextIdx;
            }
            guy.nearIdx = nearIdx;
            guy.farIdx = farIdx;
        }

        if (B - clusterCount <= 11)
        while (true)
        {
            uint64_t bestTurnDist = (uint64_t)-1;
            uint64_t bestGuyIdxI = (uint64_t)-1;
            uint64_t bestGuyIdxJ = (uint64_t)-1;

            for (uint64_t guyIdxI = 0; guyIdxI < B; guyIdxI++)
            {
                auto& guyI = guys[guyIdxI];
                if (guyI.stuckAssigned) continue;
                if (guyI.destIdx == 255) continue;
                if (paths[guyI.destIdx][guyI.islandIdx].clusterDist == 0) continue;

                uint8_t nearIdx = guyI.nearIdx;
                uint8_t farIdx = guyI.farIdx;

                uint8_t moveDistI = paths[nearIdx][guyI.islandIdx].moveDist;
                uint64_t turnDistI = (uint64_t)moveDistI * 3;
                if (guyI.bridgeIdx != 255)
                {
                    if (paths[nearIdx][guyI.bridgeIdx].moveDist < moveDistI)
                    {
                        turnDistI--;
                    }
                    else
                    {
                        turnDistI++;
                    }
                }

                for (uint64_t guyIdxJ = 0; guyIdxJ < B; guyIdxJ++)
                {
                    if (guyIdxJ == guyIdxI) continue;
                    auto& guyJ = guys[guyIdxJ];
                    if (guyJ.stuckAssigned) continue;
                    if (guyJ.destIdx == 255) continue;
                    if (paths[guyJ.destIdx][guyJ.islandIdx].clusterDist == 0) continue;

                    if (paths[farIdx][guyJ.islandIdx].clusterDist != 0) continue;
                    if (paths[guyJ.destIdx][nearIdx].clusterDist > paths[guyJ.destIdx][guyJ.islandIdx].clusterDist) continue;

                    uint8_t moveDistJ = paths[farIdx][guyJ.islandIdx].moveDist;
                    uint64_t turnDistJ = (uint64_t)moveDistJ * 3;
                    if (guyJ.bridgeIdx != 255)
                    {
                        if (paths[farIdx][guyJ.bridgeIdx].moveDist < moveDistJ)
                        {
                            turnDistJ--;
                        }
                        else
                        {
                            turnDistJ++;
                        }
                    }

                    uint64_t turnDist = std::max(turnDistI, turnDistJ);

                    if (turnDist < bestTurnDist)
                    {
                        bestTurnDist = turnDist;
                        bestGuyIdxI = guyIdxI;
                        bestGuyIdxJ = guyIdxJ;
                    }
                }
            }

            if (bestTurnDist == (uint64_t)-1) break;

            auto& guyI = guys[bestGuyIdxI];
            auto& guyJ = guys[bestGuyIdxJ];
            uint8_t nearIdx = guyI.nearIdx;
            uint8_t farIdx = guyI.farIdx;
            if (guyI.islandIdx == nearIdx)
            {
                guyI.targetIdx = farIdx;
            }
            else
            {
                guyI.targetIdx = nearIdx;
            }
            if (guyJ.islandIdx == farIdx)
            {
                guyJ.targetIdx = nearIdx;
            }
            else
            {
                guyJ.targetIdx = farIdx;
            }
            guyI.stuckAssigned = true;
            guyJ.stuckAssigned = true;
        }

        while (true)
        {
            uint64_t bestTurnDist = (uint64_t)-1;
            uint64_t bestGuyIdx = (uint64_t)-1;
            uint64_t bestOrderIdx = (uint64_t)-1;
            uint64_t bestStuckIdx = (uint64_t)-1;
            uint64_t bestTargetIdx = (uint64_t)-1;

            for (uint64_t guyIdx = 0; guyIdx < B; guyIdx++)
            {
                auto& guy = guys[guyIdx];
                if (guy.targetIdx != 255) continue;

                for (uint64_t orderIdx = 0; orderIdx < O; orderIdx++)
                {
                    if (orderAssigned[orderIdx]) continue;
                    auto& order = problem.orders[orderIdx];
                    if (paths[order.origIdx][guy.islandIdx].clusterDist != 0) continue;
                    uint8_t moveDist = paths[order.origIdx][guy.islandIdx].moveDist;
                    uint64_t turnDist = (uint64_t)moveDist * 3;
                    if (guy.bridgeIdx != 255)
                    {
                        if (paths[order.origIdx][guy.bridgeIdx].moveDist < moveDist)
                        {
                            turnDist--;
                        }
                        else
                        {
                            turnDist++;
                        }
                    }
                    if (turnDist < bestTurnDist)
                    {
                        bestTurnDist = turnDist;
                        bestGuyIdx = guyIdx;
                        bestOrderIdx = orderIdx;
                        bestStuckIdx = (uint64_t)-1;
                        bestTargetIdx = order.origIdx;
                    }
                }

                for (uint64_t stuckIdx = 0; stuckIdx < B; stuckIdx++)
                {
                    auto& stuck = guys[stuckIdx];
                    if (!stuck.stuck) continue;
                    if (stuck.stuckAssigned) continue;
                    uint8_t nextIdx = paths[stuck.destIdx][stuck.islandIdx].nextIdx;
                    if (paths[nextIdx][guy.islandIdx].clusterDist != 0) continue;
                    uint8_t moveDist = paths[nextIdx][guy.islandIdx].moveDist;
                    uint64_t turnDist = (uint64_t)moveDist * 3;
                    turnDist += 3;
                    if (guy.bridgeIdx != 255)
                    {
                        if (paths[nextIdx][guy.bridgeIdx].moveDist < moveDist)
                        {
                            turnDist--;
                        }
                        else
                        {
                            turnDist++;
                        }
                    }
                    if (turnDist < bestTurnDist)
                    {
                        bestTurnDist = turnDist;
                        bestGuyIdx = guyIdx;
                        bestOrderIdx = (uint64_t)-1;
                        bestStuckIdx = stuckIdx;
                        if (nextIdx == guy.islandIdx)
                        {
                            bestTargetIdx = stuck.islandIdx;
                        }
                        else
                        {
                            bestTargetIdx = nextIdx;
                        }
                    }
                }
            }

            if (bestTurnDist == (uint64_t)-1) break;

            auto& guy = guys[bestGuyIdx];
            guy.targetIdx = bestTargetIdx;
            if (bestOrderIdx != (uint64_t)-1)
            {
                orderAssigned[bestOrderIdx] = true;
            }
            if (bestStuckIdx != (uint64_t)-1)
            {
                guys[bestStuckIdx].stuckAssigned = true;
            }

            //fprintf(stderr, "guy %" PRIu64 ", order %" PRIi64 ", stuck %" PRIi64 ", target %" PRIu64 "\n", bestGuyIdx, bestOrderIdx, bestStuckIdx, bestTargetIdx);
        }

        Actions actions;

        // Team unpack

        for (uint64_t guyIdxI = 0; guyIdxI < B; guyIdxI++)
        {
            auto& guyI = guys[guyIdxI];
            if (guyI.acted) continue;
            if (guyI.bridgeIdx != 255) continue;
            if (guyI.targetIdx == 255) continue;
            if (guyI.islandIdx == guyI.targetIdx) continue;
            uint8_t clusterDistI = paths[guyI.targetIdx][guyI.islandIdx].clusterDist;
            uint8_t moveDistI = paths[guyI.targetIdx][guyI.islandIdx].moveDist;
            bool foundBridgeI = false;
            for (uint64_t nextIdxI = 0; nextIdxI < N; nextIdxI++)
            {
                if (!bridges[guyI.islandIdx][nextIdxI]) continue;
                uint8_t nextClusterDistI = paths[guyI.targetIdx][nextIdxI].clusterDist;
                uint8_t nextMoveDistI = paths[guyI.targetIdx][nextIdxI].moveDist;
                if (nextClusterDistI < clusterDistI ||
                    (nextClusterDistI == clusterDistI && nextMoveDistI < moveDistI))
                {
                    foundBridgeI = true;
                    break;
                }
            }
            if (foundBridgeI) continue;
            
            for (uint64_t guyIdxJ = guyIdxI + 1; guyIdxJ < B; guyIdxJ++)
            {
                auto& guyJ = guys[guyIdxJ];
                if (guyJ.acted) continue;
                if (guyJ.bridgeIdx != 255) continue;
                if (guyJ.targetIdx == 255) continue;
                if (guyJ.islandIdx == guyJ.targetIdx) continue;
                if (guyJ.islandIdx == guyI.islandIdx) continue;

                uint32_t dist = problem.dists[guyI.islandIdx][guyJ.islandIdx];
                if (dist <= 50 || dist > 100) continue;

                uint8_t clusterDistJ = paths[guyJ.targetIdx][guyJ.islandIdx].clusterDist;
                uint8_t moveDistJ = paths[guyJ.targetIdx][guyJ.islandIdx].moveDist;

                uint8_t newClusterDistI = paths[guyI.targetIdx][guyJ.islandIdx].clusterDist;
                uint8_t newMoveDistI = paths[guyI.targetIdx][guyJ.islandIdx].moveDist;

                uint8_t newClusterDistJ = paths[guyJ.targetIdx][guyI.islandIdx].clusterDist;
                uint8_t newMoveDistJ = paths[guyJ.targetIdx][guyI.islandIdx].moveDist;

#if 0
                if ((newClusterDistI < clusterDistI ||
                     (newClusterDistI == clusterDistI && newMoveDistI + 1 <= moveDistI)) &&
                    (newClusterDistJ < clusterDistJ ||
                     (newClusterDistJ == clusterDistJ && newMoveDistJ + 1 <= moveDistJ)))
                {
                    // ok
                }
                else
                {
                    continue;
                }
#endif

#if 1
                uint64_t value = 0;
                if (newClusterDistI < clusterDistI)
                {
                    value += 2;
                }
                else if (newClusterDistI == clusterDistI && newMoveDistI <= moveDistI)
                {
                    value += moveDistI - newMoveDistI;
                }
                else
                {
                    continue;
                }
                if (newClusterDistJ < clusterDistJ)
                {
                    value += 2;
                }
                else if (newClusterDistJ == clusterDistJ && newMoveDistJ <= moveDistJ)
                {
                    value += moveDistJ - newMoveDistJ;
                }
                else
                {
                    continue;
                }
                if (value < 3) continue;
#endif

                bool foundBridgeJ = false;
                for (uint64_t nextIdxJ = 0; nextIdxJ < N; nextIdxJ++)
                {
                    if (!bridges[guyJ.islandIdx][nextIdxJ]) continue;
                    uint8_t nextClusterDistJ = paths[guyJ.targetIdx][nextIdxJ].clusterDist;
                    uint8_t nextMoveDistJ = paths[guyJ.targetIdx][nextIdxJ].moveDist;
                    if (nextClusterDistJ < clusterDistJ ||
                        (nextClusterDistJ == clusterDistJ && nextMoveDistJ < moveDistJ))
                    {
                        foundBridgeJ = true;
                        break;
                    }
                }
                if (foundBridgeJ) continue;

                actions.emplace_back(ActionType::TeamUnpack, guyIdxI, guyIdxJ, 50);
                //fprintf(stderr, "TEAMUNPACK %" PRIu64 ", %" PRIu64 ", %" PRIu8 "\n", guyIdxI, guyIdxJ, (uint8_t)50);
                guyI.bridgeIdx = guyJ.islandIdx;
                guyJ.bridgeIdx = guyI.islandIdx;
                guyI.partnerIdx = guyIdxJ;
                guyJ.partnerIdx = guyIdxI;
                bridges[guyI.islandIdx][guyJ.islandIdx] = 1;
                bridges[guyJ.islandIdx][guyI.islandIdx] = 1;
                guyI.acted = true;
                guyJ.acted = true;
                break;
            }
        }

        // Unpack

        for (uint64_t guyIdx = 0; guyIdx < B; guyIdx++)
        {
            auto& guy = guys[guyIdx];
            if (guy.acted) continue;
            if (guy.bridgeIdx != 255) continue;
            if (guy.targetIdx == 255) continue;
            if (guy.islandIdx == guy.targetIdx) continue;
            uint8_t clusterDist = paths[guy.targetIdx][guy.islandIdx].clusterDist;
            uint8_t moveDist = paths[guy.targetIdx][guy.islandIdx].moveDist;
            bool foundBridge = false;
            for (uint64_t nextIdx = 0; nextIdx < N; nextIdx++)
            {
                if (!bridges[guy.islandIdx][nextIdx]) continue;
                uint8_t nextClusterDist = paths[guy.targetIdx][nextIdx].clusterDist;
                uint8_t nextMoveDist = paths[guy.targetIdx][nextIdx].moveDist;
                if (nextClusterDist < clusterDist ||
                    (nextClusterDist == clusterDist && nextMoveDist < moveDist))
                {
                    foundBridge = true;
                    break;
                }
            }
            if (foundBridge) continue;
            uint8_t nextIdx = paths[guy.targetIdx][guy.islandIdx].nextIdx;
            if (problem.dists[guy.islandIdx][nextIdx] > 50) continue;
            actions.emplace_back(ActionType::Unpack, guyIdx, nextIdx);
            //fprintf(stderr, "UNPACK %" PRIu64 ", %" PRIu8 "\n", guyIdx, nextIdx);
            guy.bridgeIdx = nextIdx;
            bridges[guy.islandIdx][nextIdx] = 1;
            bridges[nextIdx][guy.islandIdx] = 1;
            guy.acted = true;
        }

        // Team move
        
        for (uint64_t guyIdxI = 0; guyIdxI < B; guyIdxI++)
        {
            auto& guyI = guys[guyIdxI];
            if (guyI.acted) continue;
            if (guyI.targetIdx == 255) continue;
            if (guyI.islandIdx == guyI.targetIdx) continue;
            if (guyI.bridgeIdx == 255) continue;
            if (guyI.partnerIdx == 255) continue;

            uint64_t guyIdxJ = guyI.partnerIdx;
            auto& guyJ = guys[guyIdxJ];
            if (guyJ.acted) continue;
            if (guyJ.targetIdx == 255) continue;
            if (guyJ.islandIdx == guyJ.targetIdx) continue;
            //if (guyJ.bridgeIdx == 255) continue;
            //if (guyJ.partnerIdx == 255) continue;
            //if (guyJ.partnerIdx != guyIdxI) continue;

            uint8_t clusterDistI = paths[guyI.targetIdx][guyI.islandIdx].clusterDist;
            uint8_t moveDistI = paths[guyI.targetIdx][guyI.islandIdx].moveDist;

            uint8_t clusterDistJ = paths[guyJ.targetIdx][guyJ.islandIdx].clusterDist;
            uint8_t moveDistJ = paths[guyJ.targetIdx][guyJ.islandIdx].moveDist;

            uint8_t newClusterDistI = paths[guyI.targetIdx][guyJ.islandIdx].clusterDist;
            uint8_t newMoveDistI = paths[guyI.targetIdx][guyJ.islandIdx].moveDist;

            uint8_t newClusterDistJ = paths[guyJ.targetIdx][guyI.islandIdx].clusterDist;
            uint8_t newMoveDistJ = paths[guyJ.targetIdx][guyI.islandIdx].moveDist;

#if 0
            if ((newClusterDistI < clusterDistI ||
                 (newClusterDistI == clusterDistI && newMoveDistI + 1 <= moveDistI)) &&
                (newClusterDistJ < clusterDistJ ||
                 (newClusterDistJ == clusterDistJ && newMoveDistJ + 1 <= moveDistJ)))
            {
                // ok
            }
            else
            {
                continue;
            }
#endif

#if 1
            uint64_t value = 0;
            if (newClusterDistI < clusterDistI)
            {
                value += 2;
            }
            else if (newClusterDistI == clusterDistI && newMoveDistI <= moveDistI)
            {
                value += moveDistI - newMoveDistI;
            }
            else
            {
                continue;
            }
            if (newClusterDistJ < clusterDistJ)
            {
                value += 2;
            }
            else if (newClusterDistJ == clusterDistJ && newMoveDistJ <= moveDistJ)
            {
                value += moveDistJ - newMoveDistJ;
            }
            else
            {
                continue;
            }
            if (value < 3) continue;
#endif

            actions.emplace_back(ActionType::Move, guyIdxI, guyJ.islandIdx);
            actions.emplace_back(ActionType::Move, guyIdxJ, guyI.islandIdx);
            //fprintf(stderr, "MOVE %" PRIu64 ", %" PRIu8 "\n", guyIdxI, guyJ.islandIdx);
            //fprintf(stderr, "MOVE %" PRIu64 ", %" PRIu8 "\n", guyIdxJ, guyI.islandIdx);
            guyI.bridgeIdx = guyI.islandIdx;
            guyJ.bridgeIdx = guyJ.islandIdx;
            std::swap(guyI.islandIdx, guyJ.islandIdx);
            guyI.acted = true;
            guyJ.acted = true;
        }

        // Move

        for (uint64_t guyIdx = 0; guyIdx < B; guyIdx++)
        {
            auto& guy = guys[guyIdx];
            if (guy.acted) continue;
            if (guy.targetIdx == 255) continue;
            if (guy.islandIdx == guy.targetIdx) continue;
            uint8_t clusterDist = paths[guy.targetIdx][guy.islandIdx].clusterDist;
            uint8_t moveDist = paths[guy.targetIdx][guy.islandIdx].moveDist;
            uint8_t bestClusterDist = 255;
            uint8_t bestMoveDist = 255;
            uint8_t bestNextIdx = 255;
            if (guy.bridgeIdx != 255)
            {
                if (guy.partnerIdx != 255) continue;
                bestClusterDist = paths[guy.targetIdx][guy.bridgeIdx].clusterDist;
                bestMoveDist = paths[guy.targetIdx][guy.bridgeIdx].moveDist;
                bestNextIdx = guy.bridgeIdx;
            }
            else
            {
                for (uint64_t nextIdx = 0; nextIdx < N; nextIdx++)
                {
                    if (!bridges[guy.islandIdx][nextIdx]) continue;
                    uint8_t nextClusterDist = paths[guy.targetIdx][nextIdx].clusterDist;
                    uint8_t nextMoveDist = paths[guy.targetIdx][nextIdx].moveDist;
                    if (nextClusterDist < bestClusterDist ||
                        (nextClusterDist == bestClusterDist && nextMoveDist < bestMoveDist))
                    {
                        bestClusterDist = nextClusterDist;
                        bestMoveDist = nextMoveDist;
                        bestNextIdx = nextIdx;
                    }
                }
            }

            if (bestClusterDist < clusterDist ||
                (bestClusterDist == clusterDist && bestMoveDist < moveDist))
            {
                // ok
            }
            else
            {
                continue;
            }

            actions.emplace_back(ActionType::Move, guyIdx, bestNextIdx);
            //fprintf(stderr, "MOVE %" PRIu64 ", %" PRIu8 "\n", guyIdx, bestNextIdx);
            if (guy.bridgeIdx == bestNextIdx)
            {
                guy.bridgeIdx = guy.islandIdx;
            }
            guy.islandIdx = bestNextIdx;
            guy.acted = true;
        }

        // Team pack

        for (uint64_t guyIdxI = 0; guyIdxI < B; guyIdxI++)
        {
            auto& guyI = guys[guyIdxI];
            if (guyI.acted) continue;
            if (guyI.bridgeIdx == 255) continue;
            if (guyI.partnerIdx == 255) continue;

            uint64_t guyIdxJ = guyI.partnerIdx;
            auto& guyJ = guys[guyIdxJ];
            if (guyJ.acted) continue;
            //if (guyI.bridgeIdx == 255) continue;
            //if (guyI.partnerIdx == 255) continue;
            //if (guyJ.partnerIdx != guyIdxI) continue;

            actions.emplace_back(ActionType::TeamPack, guyIdxI, guyIdxJ, 50);
            //fprintf(stderr, "TEAMPACK %" PRIu64 ", %" PRIu64 ", %" PRIu8 "\n", guyIdxI, guyIdxJ, (uint8_t)50);
            bridges[guyI.islandIdx][guyJ.islandIdx] = 0;
            bridges[guyJ.islandIdx][guyI.islandIdx] = 0;
            guyI.bridgeIdx = 255;
            guyJ.bridgeIdx = 255;
            guyI.partnerIdx = 255;
            guyJ.partnerIdx = 255;
            guyI.acted = true;
            guyJ.acted = true;
        }

        // Pack

        for (uint64_t guyIdx = 0; guyIdx < B; guyIdx++)
        {
            auto& guy = guys[guyIdx];
            if (guy.acted) continue;
            if (guy.bridgeIdx == 255) continue;
            if (guy.partnerIdx != 255) continue;
            actions.emplace_back(ActionType::Pack, guyIdx, guy.bridgeIdx);
            //fprintf(stderr, "PACK %" PRIu64 ", %" PRIu8 "\n", guyIdx, guy.bridgeIdx);
            bridges[guy.islandIdx][guy.bridgeIdx] = 0;
            bridges[guy.bridgeIdx][guy.islandIdx] = 0;
            guy.bridgeIdx = 255;
            guy.acted = true;
        }

        return actions;
    }

private:
    uint64_t clusterCount;
    PathEntry paths[maxN][maxN];
    Guy guys[maxB];
    uint8_t bridges[maxN][maxN];
};

unique_ptr<Solver> createSolver(const string& solverName)
{
    unique_ptr<Solver> pSolver;

    if (solverName == "trivial") pSolver.reset(new TrivialSolver);
    else if (solverName == "single") pSolver.reset(new SingleSolver);
    else if (solverName == "team") pSolver.reset(new TeamSolver);
    else if (solverName == "team2") pSolver.reset(new Team2Solver);

    return pSolver;
}

constexpr const char* defaultSolverName = "team2";

void usage()
{
    printf("Usage: solve [<options>] [<solver>]\n");
    printf("  <solver>\n");
    printf("        Solver to use (default: %s)\n", defaultSolverName);
    printf("Options:\n");
    printf("  -h    Print usage information and exit\n");
    printf("\n");
    printf("Solver      Description\n");
    printf("----------  ------------------------------------------------------------\n");
    printf("trivial     Take no actions\n");
    printf("single      Simple solver working individually\n");
    printf("team        Simple solver working in teams\n");
    printf("team2       Don't get stuck\n");
}

int main(int argc, char *argv[])
{
    bool gotSolverName = false;

    bool help = false;
    string solverName(defaultSolverName);

    int iArg = 1;
    while (iArg < argc)
    {
        string strArg = argv[iArg++];

        if (strArg == "-h" || strArg == "--help")
        {
            help = true;
        }
        else if (!gotSolverName)
        {
            solverName = strArg;
            gotSolverName = true;
        }
        else
        {
            usage();
            return 1;
        }
    }

    if (help)
    {
        usage();
        return 0;
    }

    // Create solver

    unique_ptr<Solver> pSolver = createSolver(solverName);
    if (!pSolver)
    {
        printf("Unknown solver\n");
        return 1;
    }

    // Read input

    Problem problem;
    readProblem(stdin, problem);

    // Solve

    for (uint64_t turn = 0; turn < 1000; turn++)
    {
        readTurn(stdin, problem);

        problem.turn = turn;

        if (turn == 0)
        {
            pSolver->init(problem);
        }

        Actions actions = pSolver->step(problem);

        writeActions(stdout, actions);
        fflush(stdout);
    }

    sleepMS(1);

    return 0;
}
