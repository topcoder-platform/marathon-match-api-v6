#include <bits/stdc++.h>
#include <sys/time.h>

using namespace std;

double start;
double get_time() {
    timeval tv;
    gettimeofday(&tv, 0);
    return tv.tv_sec + tv.tv_usec * 1e-6;
}
int currtm() {
    return (int)(1000 * (get_time() - start));
}

static unsigned int g_seed = time(0);
int MYRAND_MAX = 0x7FFF + 1;
int myrand() {
    g_seed = (214013 * g_seed + 2531011);
    return (g_seed >> 16) & 0x7FFF;
}
long long large_rand() {
    return 1LL * myrand() * MYRAND_MAX + myrand();
}

long long ops = 0;
long long opt = 0;

struct Bridgeman {
    int pos;
    int carry;
    int target;  // -1 if none
};

struct Order {
    int from, to;
};

int N, B, O;

const int MXN = 80;

int dists[MXN][MXN];
int jumps_dists[MXN][MXN];
int component[MXN];
bool connected[MXN][MXN];
int heat[MXN][MXN];

const int MAX_REACH_LIMIT = 50;
const int INF = 1e9;
void init_graph() {
    for (int i = 0; i < N; ++i) {
        for (int j = 0; j < N; ++j) {
            jumps_dists[i][j] = INF;
        }
        jumps_dists[i][i] = 0;
    }
    for (int i = 0; i < N; ++i) {
        for (int j = 0; j < N; ++j) {
            if (i == j) continue;
            if (dists[i][j] <= MAX_REACH_LIMIT) {
                jumps_dists[i][j] = 1;
            } else if (dists[i][j] <= 2 * MAX_REACH_LIMIT) {
                jumps_dists[i][j] = 100;
            }
        }
    }
    for (int k = 0; k < N; ++k) {
        for (int i = 0; i < N; ++i) {
            for (int j = 0; j < N; ++j) {
                if (jumps_dists[i][k] != INF && jumps_dists[k][j] != INF) {
                    jumps_dists[i][j] =
                        min(jumps_dists[i][j], jumps_dists[i][k] + jumps_dists[k][j]);
                }
            }
        }
    }
    for (int i = 0; i < N; i++) {
        component[i] = -1;
    }
    int cc = 0;
    for (int i = 0; i < N; i++) {
        if (component[i] == -1) {
            for (int j = 0; j < N; j++) {
                if (jumps_dists[i][j] < 100) {
                    component[j] = cc;
                    cerr << "Component " << cc << " contains " << j << endl;
                }
            }
            cc++;
        }
    }
}

struct BridgePlan {
    int bridgeFrom = -1;
    int bridgeTo = -1;
    int bridgeVolume = -1;
    int bridgeBuddy = -1;
};

const int MXB = 20;
int goals[MXB];
int towards_targets[MXB];
BridgePlan plans[MXB];
int moved[MXB];

void assign_goals(const vector<Bridgeman> &bridgemans, const vector<Order> &orders,
                  const vector<int> &stuck_guys) {
    for (int i = 0; i < B; i++) {
        goals[i] = -1;
    }
    vector<pair<int, pair<int, int> > > content;
    for (int i = 0; i < B; i++) {
        auto &man = bridgemans[i];
        if (man.target != -1) {
            goals[i] = man.target;
        } else {
            for (const auto &o : orders) {
                int dist = jumps_dists[man.pos][o.from];
                content.push_back({dist, {i, o.from}});
            }
            for (int stuck_i : stuck_guys) {
                int stuck_guy_cell = towards_targets[stuck_i];
                if (stuck_guy_cell == -1) continue;
                int dist = jumps_dists[man.pos][stuck_guy_cell];
                content.push_back({dist, {i, stuck_guy_cell}});
            }
        }
    }
    vector<int> taken_content(N, 0);
    sort(content.begin(), content.end());
    for (auto &pp : content) {
        auto &p = pp.second;
        int i = p.first;
        int pos = p.second;
        if (taken_content[pos]) continue;
        if (goals[i] != -1) continue;
        taken_content[pos] = 1;
        goals[i] = pos;
    }
}

void move_towards_goal(const vector<Bridgeman> &bridgemans, vector<string> &actions) {
    for (int i = 0; i < B; ++i) {
        // If in the middle of a bridge action sequence
        if (plans[i].bridgeFrom != -1) continue;

        if (moved[i]) continue;
        auto &man = bridgemans[i];

        // No active bridge: decide goal and possibly unpack towards it
        int goal = goals[i];
        if (goal == -1 || goal == man.pos) {
            // no goal or already at the goal
            continue;
        }

        // Try to MOVE along existing bridge that gets closer to goal
        {
            int bestMove = -1;
            int cur = jumps_dists[man.pos][goal];
            int bestAfter = cur;
            for (int t = 0; t < N; ++t) {
                if (t == man.pos) continue;
                if (!connected[man.pos][t]) continue;
                int after = jumps_dists[t][goal];
                if (after < bestAfter) {
                    bestAfter = after;
                    bestMove = t;
                }
            }
            if (bestMove != -1) {
                actions.emplace_back("MOVE " + to_string(i) + " " + to_string(bestMove));
                moved[i] = 1;
                continue;
            }
        }
    }
}

void unpack_towards_goal(const vector<Bridgeman> &bridgemans, vector<string> &actions) {
    for (int i = 0; i < B; ++i) {
        // If in the middle of a bridge action sequence
        if (plans[i].bridgeFrom != -1) continue;
        if (moved[i]) continue;
        auto &man = bridgemans[i];

        // No active bridge: decide goal and possibly unpack towards it
        int goal = goals[i];
        if (goal == -1 || goal == man.pos) {
            // no goal or already at the goal
            continue;
        }

        // Try to find best neighbor t to unpack to, within carry, that reduces distance to goal
        int bestT = -1;
        int bestGoalDist = jumps_dists[man.pos][goal];
        for (int t = 0; t < N; ++t) {
            if (t == man.pos) continue;
            if (dists[man.pos][t] > man.carry) continue;
            if (connected[man.pos][t]) continue;  // cannot unpack where bridge already exists
            int tg = jumps_dists[t][goal];
            if (tg < bestGoalDist) {
                bestGoalDist = tg;
                bestT = t;
            }
        }

        if (bestT != -1) {
            actions.emplace_back("UNPACK " + to_string(i) + " " + to_string(bestT));
            moved[i] = 1;
            plans[i].bridgeFrom = man.pos;
            plans[i].bridgeTo = bestT;
            plans[i].bridgeVolume = dists[man.pos][bestT];
            plans[i].bridgeBuddy = -1;
            connected[man.pos][bestT] = true;
            connected[bestT][man.pos] = true;
            heat[man.pos][bestT] += 1;
            heat[bestT][man.pos] += 1;
            move_towards_goal(bridgemans, actions);  // try new bridge
            continue;
        }

        if (man.target == -1) {
            /// don't grab the guys if you have no message...
            continue;
        }

        // can I unpack as a cross-component team?
        int bestMan2 = -1;
        int bestMan2Dist = jumps_dists[man.pos][goal];
        for (int j = 0; j < B; j++) {
            if (j == i) continue;
            if (plans[j].bridgeFrom != -1) continue;
            if (moved[j]) continue;
            auto &man2 = bridgemans[j];
            if (component[man.pos] == component[man2.pos]) continue;
            if (dists[man.pos][man2.pos] > man.carry + man2.carry) continue;
            if (connected[man.pos][man2.pos])
                continue;  // cannot unpack where bridge already exists
            int tg = jumps_dists[man2.pos][goal];
            if (tg < bestMan2Dist) {
                bestMan2Dist = tg;
                bestMan2 = j;
            }
        }
        if (bestMan2 != -1) {
            auto &man2 = bridgemans[bestMan2];
            int my_dist = dists[man.pos][man2.pos] / 2;
            int his_dist = dists[man.pos][man2.pos] - my_dist;
            actions.emplace_back("TEAMUNPACK " + to_string(i) + " " + to_string(bestMan2) + " " +
                                 to_string(my_dist));
            moved[i] = 1;
            moved[bestMan2] = 1;
            plans[i].bridgeFrom = man.pos;
            plans[i].bridgeTo = man2.pos;
            plans[i].bridgeVolume = my_dist;
            plans[i].bridgeBuddy = bestMan2;
            plans[bestMan2].bridgeFrom = man2.pos;
            plans[bestMan2].bridgeTo = man.pos;
            plans[bestMan2].bridgeVolume = his_dist;
            plans[bestMan2].bridgeBuddy = i;
            connected[man.pos][man2.pos] = true;
            connected[man2.pos][man.pos] = true;
            heat[man.pos][man2.pos] += 1;
            heat[man2.pos][man.pos] += 1;
            continue;
        }
    }
}

void move_as_planned(const vector<Bridgeman> &bridgemans, vector<string> &actions) {
    for (int i = 0; i < B; ++i) {
        if (moved[i]) continue;
        auto &plan = plans[i];
        auto &man = bridgemans[i];

        // If in the middle of a bridge action sequence
        if (plan.bridgeFrom != -1) {
            if (man.pos == plan.bridgeFrom) {
                // Step 2: move across the bridge
                actions.emplace_back("MOVE " + to_string(i) + " " + to_string(plan.bridgeTo));
                moved[i] = 1;
            }
        }
    }
}

void pack_planned_bridges(const vector<Bridgeman> &bridgemans, vector<string> &actions) {
    for (int i = 0; i < B; ++i) {
        if (moved[i]) continue;
        auto &plan = plans[i];
        auto &man = bridgemans[i];

        // If in the middle of a bridge action sequence
        if (plan.bridgeTo != -1) {
            if (man.pos == plan.bridgeTo) {
                if (plan.bridgeBuddy == -1) {
                    // Step 3: pack the bridge to recover bricks
                    actions.emplace_back("PACK " + to_string(i) + " " + to_string(plan.bridgeFrom));
                    moved[i] = 1;
                    connected[plan.bridgeFrom][plan.bridgeTo] = false;
                    connected[plan.bridgeTo][plan.bridgeFrom] = false;
                    plan.bridgeFrom = -1;
                    plan.bridgeTo = -1;
                    plan.bridgeVolume = -1;
                    plan.bridgeBuddy = -1;
                } else {
                    int buddy = plan.bridgeBuddy;
                    auto &buddy_plan = plans[buddy];

                    actions.emplace_back("TEAMPACK " + to_string(i) + " " + to_string(buddy) + " " +
                                         to_string(plan.bridgeVolume));
                    moved[i] = 1;
                    moved[buddy] = 1;
                    connected[plan.bridgeFrom][plan.bridgeTo] = false;
                    connected[plan.bridgeTo][plan.bridgeFrom] = false;
                    plan.bridgeFrom = -1;
                    plan.bridgeTo = -1;
                    plan.bridgeVolume = -1;
                    plan.bridgeBuddy = -1;
                    buddy_plan.bridgeFrom = -1;
                    buddy_plan.bridgeTo = -1;
                    buddy_plan.bridgeVolume = -1;
                    buddy_plan.bridgeBuddy = -1;
                }
            }
        }
    }
}

vector<int> detect_stuck_guys(const vector<Bridgeman> &bridgemans) {
    vector<int> stuck_guys;
    for (int i = 0; i < B; ++i) {
        auto &man = bridgemans[i];
        if (man.target != -1) {
            if (component[man.pos] != component[man.target]) {
                stuck_guys.push_back(i);
            }
        }
    }
    return stuck_guys;
}

void assign_towards_targets(const vector<Bridgeman> &bridgemans) {
    for (int i = 0; i < B; ++i) {
        auto &man = bridgemans[i];
        if (man.target != -1) {
            int bestT = man.pos;
            int bestDist = jumps_dists[man.target][man.pos];
            for (int t = 0; t < N; ++t) {
                if (dists[man.pos][t] > 100) continue;
                if (jumps_dists[man.target][t] < bestDist) {
                    bestDist = jumps_dists[man.target][t];
                    bestT = t;
                }
            }
            towards_targets[i] = bestT;
        } else {
            towards_targets[i] = man.pos;
        }
    }
}

int main() {
    start = get_time();
    g_seed = 1337;

    ios::sync_with_stdio(false);
    cin.tie(0);

    cin >> N >> B >> O;

    for (int i = 0; i < N; ++i) {
        for (int j = 0; j < N; ++j) {
            cin >> dists[i][j];
        }
    }
    init_graph();

    for (int turn = 1; turn <= 1000; ++turn) {
        int elapsed;
        cin >> elapsed;

        vector<Bridgeman> bridgemans(B);
        for (int i = 0; i < B; ++i) {
            cin >> bridgemans[i].pos >> bridgemans[i].carry >> bridgemans[i].target;
        }
        vector<Order> orders(O);
        for (int i = 0; i < O; ++i) {
            cin >> orders[i].from >> orders[i].to;
        }

        for (int i = 0; i < B; ++i) {
            moved[i] = 0;
        }

        vector<string> actions;

        vector<int> stuck_guys = detect_stuck_guys(bridgemans);
        assign_towards_targets(bridgemans);
        assign_goals(bridgemans, orders, stuck_guys);

        move_towards_goal(bridgemans, actions);
        unpack_towards_goal(bridgemans, actions);
        move_as_planned(bridgemans, actions);
        move_towards_goal(bridgemans, actions);
        pack_planned_bridges(bridgemans, actions);

        for (size_t i = 0; i < actions.size(); ++i) {
            cout << actions[i];
            if (i + 1 < actions.size()) cout << " | ";
        }
        cout << std::endl;  // flush to satisfy interactive protocol
    }

    if (ops != 0) cerr << "OPS: " << ops << endl;
    if (opt != 0) cerr << "OPT: " << opt << endl;
    cerr << "Time = " << currtm() << " ms" << endl;

    return 0;
}
