#include <iostream>
#include <cstdlib>

#include <string>
#include <sstream>
#include <vector>
#include <queue>
#include <set>
#include <unordered_set>
#include <map>
#include <unordered_map>
#include <iostream>
#include <fstream>
#include <unistd.h>
#include <algorithm>
#include <numeric>
#include <cmath>
#include <cstdlib>
#include <cassert>
#include <cstring>
#include "sys/time.h"
using namespace std;
#define HERE (cerr << "LINE: " << __LINE__ << " " << __FUNCTION__ << endl)

#define DBG(x) cerr << #x << ": " << (x) << endl

struct timeval timer_begin, timer_end;
uint64_t tsc_begin;
//double sec_per_count = 1.0 / 2.7e9;
double sec_per_count = -1;
int timer_called;
inline uint64_t get_time_64() {
  uint32_t lo, hi;
  asm volatile ("rdtsc" : "=a" (lo), "=d" (hi));
  return (((uint64_t)hi << 32) | lo);
}

inline void timer_start() 
{
  timer_called++;
  gettimeofday(&timer_begin, NULL);
  tsc_begin = get_time_64();
}     
inline double timer_now() 
{
  if (sec_per_count < 0) {
    timer_called++;
    gettimeofday(&timer_end, NULL);         
    double duration = timer_end.tv_sec - timer_begin.tv_sec +
      (timer_end.tv_usec - timer_begin.tv_usec)/1000000.0;
    if (duration < 1e-3) {
      return duration;
    }
    uint64_t tsc_duration = get_time_64() - tsc_begin;
    sec_per_count = duration / tsc_duration;
    DBG(1/sec_per_count);
  }
  return (get_time_64() - tsc_begin) * sec_per_count;
}
void timer_stat() {
  DBG(1/sec_per_count);
  {
    timer_called++;
    gettimeofday(&timer_end, NULL);         
    double duration = timer_end.tv_sec - timer_begin.tv_sec +
      (timer_end.tv_usec - timer_begin.tv_usec)/1000000.0;
    uint64_t tsc_duration = get_time_64() - tsc_begin;
    DBG(duration);
    DBG(tsc_duration);
    DBG(tsc_duration / duration);
  }
}

template<class T>
using less_priority_queue = priority_queue<T,vector<T>,greater<T>>;

template<typename T>
void assign_min_max(T& min,T& max,const T& x) {
  if (x < min)
    min = x;
  if (x > max)
    max = x;
}
unsigned int hash_function(unsigned long p) {
  // xor32()
  p ^= p<<7;
  p ^= p>>1;
  p ^= p<<25;
  unsigned int c = __builtin_popcount(p);
  return p<<c | p>>(32-c);
}
uint64_t hash_function64(uint64_t p) {
  // xor64()
  p ^= p<<16;
  p ^= p>>7;
  p ^= p<<39;
  uint64_t c = __builtin_popcount(p);
  return p<<c | p>>(64-c);
}  

struct xor128_t {
  uint64_t x, y, z, w;

  xor128_t(int seed=0) : x(123456789^seed) , y(362436069), z(521288629), w(88675123) {
    for (int i=0; i<48; i++)
      get();
  }

  void init(int seed) {
    x = 123456789^seed;
    y = 362436069;
    z = 521288629;
    w = 88675123;

    for (int i=0; i<48; i++)
      get();
  }

  inline uint64_t get() {
    uint64_t t=(x^(x<<11)); x=y; y=z; z=w;
    return (w=(w^(w>>19))^(t^(t>>8)));
  }

  inline uint64_t get(unsigned int sz) {
    if (sz <= 1)
      return 0;

    uint64_t x;
    const uint64_t mask = (1<<(ilogb(sz-1)+1)) - 1;
    //cout << sz << " " << mask << endl;
    assert(mask >= (sz-1) && mask < 2*sz-1);
    do {
      x = get() & mask;
    } while (x >= sz);

    return x;
  }

  inline int64_t get(int beg,int end) {
    return get(end-beg) + beg;
  }

  double get_double() {
    static const double double_factor = 1.0 / (1.0 + 0xffffffffffffffffuLL);
    return get() * double_factor;
  }

  double get_norm() {
    double a = get_double();
    double b = get_double();

    return sqrt(-2*log(a)) * cos(2*M_PI*b);
  }

  double get_gamma(double a) {
    if (a < 1.0) {
      return get_gamma(1+a) * pow(get_double(), 1/a);
    }
    
    double d = a - 1/3.0;
    double c = 1/sqrt(9.0 * d);

    while (true) {
      double x = get_norm();
      double uni = 1 - get_double();
      double v = (1.0+c*x)*(1.0+c*x)*(1.0+c*x);
      if (v > 0 && log(uni) < 0.5 * x*x + d - d*v + d*log(v))
	return d*v;
    }
  }

  template<typename T> void shuffle(vector<T>& v,int partial=-1) {
    int sz = v.size();
    if (partial < 0 || partial > sz)
      partial = sz;

    for (int i=0; i<partial; i++) {
      swap(v[i], v[i + get(sz-i)]);
    }
  }
  
  template<typename T> T sample(const vector<T>& v) {
    assert(!v.empty());
    return v[get(v.size())];
  }
};

// Van der Corput sequence
double vdc(int i,int base) {
  double result = 0;
  double f = 1;

  while (i > 0) {
    f /= base;
    result += f * (i%base);
    i = i/base;
  }

  return result;
}

struct uf_t {
  vector <int16_t> parent;

  void clear() {
    parent.clear();
  }

  void add(int elm) {
    if (elm >= parent.size()) 
      parent.resize(elm+1, -1);
  }

  void merge(int a,int b) {
    add(a);
    add(b);

    int ia = a;
    int ib = b;

    if ((ia^ib)&1) swap(ia, ib);  // ok?
      
    int ra = root(ia);
    int rb = root(ib);

    if (ra != rb) {
      parent[ra] += parent[rb];
      parent[rb] = ra;
    }
  }

  int size(int elm) {
    return -parent[root(elm)];
  }

  int id(int elm) {
    return root(elm);
  }

  int root(int ia) {
    add(ia);
    return (parent[ia] < 0) ? ia : (parent[ia] = root(parent[ia]));
  }
};

struct reusable_set_t {
  typedef uint8_t mark_t;
  mark_t mark;
  vector<mark_t> v;
  reusable_set_t() {}
  reusable_set_t(int n) : v(n), mark(1) {}

  void insert(int x) { v[x] = mark; }
  void erase(int x) { v[x] = mark-1; }
  int count(int x) const { return (v[x] == mark); }
  void clear() {
    mark++;
    if (mark == 0) {
      fill(v.begin(), v.end(), 0);
      mark ++;
    }
  }
};

struct sa_t {
  double ini, fin, inv_T, progress;
  int num_call, num_accept, num_better;
  xor128_t rng;
  sa_t() {}
  sa_t(double ini, double fin) : ini(ini), fin(fin), num_accept(0), num_call(0), num_better(0) {
    set_progress(0);
  }

  void set_progress(double x) {
    progress = clamp(x, 0.0, 1.0);
    inv_T = 1 / (ini * pow(fin/ini, progress));
  }

  bool acceptable(double x) {
    //bool result = (x > 0) || rng.get_double() < exp(x*inv_T);
    //bool result = (x > 0) || log(1-rng.get_double()) < x*inv_T;
    double z = x*inv_T;
    bool result = (x > 0) || (z > -12 && log(1-rng.get_double()) < z);

    //num_call ++;
    //num_accept += result;
    //num_better += (x > 0);

    return result;
  }

  void show_log() const {
    cerr << "better/accept/call: "
	 << num_better
	 << "/" << num_accept
	 << "/" << num_call 
	 << " " << (double)num_accept/num_call << endl;
  }
};

template<typename T> ostream& operator<<(ostream& os, const vector<T>& v) {
  os << "[ ";
  for(typename vector<T>::const_iterator it=v.begin(); it!=v.end(); ++it)
    os << '\"' << *it << '\"' << (it+1==v.end() ? "" : ", "); os << " ]"; 
  return os; 
}
template<typename T> ostream& operator<<(ostream& os, const set<T>& v) {
  os << "{ ";
  for(typename set<T>::const_iterator it=v.begin(); it!=v.end(); ++it) {
    if (it != v.begin())
      os << ", ";
    os << *it; 
  }
  os << " }"; 
  return os; 
}
template<typename T1,typename T2> ostream& operator<<(ostream& os, const pair<T1,T2>& v) {
  os << "[ " << v.first << ", " << v.second << "]";
  return os; 
}
template<typename... Args>
string format(const string& fmt, Args... args) {
  int sz = snprintf(nullptr, 0, fmt.c_str(), args ...);
  char buf[sz+1];
  snprintf(buf, sz+1, fmt.c_str(), args ...);
  return buf;
}

template<typename T>
void make_vector_unique(vector<T>& v) {
  sort(v.begin(), v.end());
  v.erase(unique(v.begin(), v.end()), v.end());
}
template<typename T>
bool include_v(const vector<T>& v,const T& item) {
  return find(v.begin(), v.end(), item) != v.end();
}

const int G = 64;
int CP(int x,int y) { return (y+1)*G+(x+1); }
int CX(int p) { return p%G - 1; }
int CY(int p) { return p/G - 1; }
pair<int,int> CXY(int p) { return {CX(p), CY(p)}; }
string CS(int p) { return format("(%2d,%2d)", CX(p), CY(p)); }
string CSS(const vector<int>& ps) {
  string s;
  s += "{";
  for (int p : ps) {
    s += format("(%2d,%2d), ", CX(p), CY(p));
  }
  s += "}";
  return s;
}
const vector<int> DPS4 = { 1, -G, -1, G };
const vector<int> DPS8 = { 1, -G+1, -G, -G-1, -1, G-1, G, G+1 };
int MOD(int x,int m) {
  int y = x % m;
  if (y < 0) { y += m; }
  return y;
}
template<typename T> T pow2(const T& x) { return x*x; }
template<typename T> int sign(const T& x) {
  return ((x > (T)0) ? 1 : (x < (T)0) ? -1 : 0);
}
char OX(bool a) { return "xo"[a]; }

const double TIME_LIMIT = 5.0;

/* insert here */
#ifdef LOCAL
#include "./svg.hpp"
#endif

const int MAX_TURN = 1000;
const int MAX_PARTS = 60;
const int INITIAL_PARTS = 50;

struct bridgeman_t {
  int id;
  int island;
  int carry;
  int target;

  const string to_string() const {
    return format("B#%02d[@%02d c:%02d t:%02d]", id, island, carry, target);
  }
};

struct order_t {
  int from, to;
};

struct bridge_t {
  int a, b;
  vector<int> owners;
  bridge_t() {}
  bridge_t(int arg_a,int arg_b,const vector<int>& arg_owners) : a(arg_a), b(arg_b), owners(arg_owners) {
    if (a > b) { swap(a, b); }
  }

  const bool operator==(const bridge_t& bridge) const {
    return (a == bridge.a &&
            b == bridge.b &&
            owners == bridge.owners);
  }

  string to_string() const {
    stringstream ss;
    ss << "bridge:[" << a << "-" << b << " " << owners << "]";
    return ss.str();
  }
};

enum type_t {
  STAY,
  MOVE, UNPACK, PACK,
  TEAMUNPACK, TEAMPACK,
};
  
struct command_t {
  type_t type;
  int a, b, c;

  command_t() : type(STAY), a(-1), b(-1), c(-1) {}
  command_t(type_t type,int a,int b,int c) : type(type), a(a), b(b), c(c) {}

  string to_string() const {
    if (type == STAY) {
      return "";
    } else if (type == MOVE) {
      return format("MOVE %d %d", a, b);
    } else if (type == UNPACK) {
      return format("UNPACK %d %d", a, b);
    } else if (type == PACK) {
      return format("PACK %d %d", a, b);
    }
    
    return "asdf";
  }

  static command_t move(int bid,int island) { return command_t(type_t::MOVE, bid, island, -1); }
  static command_t pack(int bid,int island) { return command_t(type_t::PACK, bid, island, -1); }
  static command_t unpack(int bid,int island) { return command_t(type_t::UNPACK, bid, island, -1); }
};

struct testcase_t {
  int N, B, O;
  vector<int> dmat;

  void read_init(istream& is) {
    is >> N >> B >> O;
    DBG(N);
    DBG(B);
    DBG(O);

    for (int a=0; a<N; a++) {
      for (int b=0; b<N; b++) {
        int d;
        is >> d;
        dmat.push_back(d);
      }
    }
  }

  vector<vector<int>> dmps;
  vector<vector<int>> firsts;
  vector<vector<int>> adjs;
  vector<vector<int>> adjs2;
  void setup() {

    dmps.resize(N);
    firsts.resize(N);
    adjs.resize(N);
    adjs2.resize(N);

    uf_t uf;
    for (int a=0; a<N; a++) {
      for (int b=a+1; b<N; b++) {
        if (dmat[a*N+b] <= INITIAL_PARTS) {
          adjs[a].push_back(b);
          adjs[b].push_back(a);
          uf.merge(a, b);
        } else if (dmat[a*N+b] <= 2*INITIAL_PARTS) {
          adjs2[a].push_back(b);
          adjs2[b].push_back(a);
        }
      }
    }

#if 0
    for (int a=0; a<N; a++) {
      cerr << a << " " << adjs[a] << endl;
    }
#endif

    const int team_cost = 100;
    for (int a=0; a<N; a++) {
      auto& dmp(dmps[a]);
      auto& first(firsts[a]);
      dmp.resize(N, 1234567);
      first.resize(N, a);
      less_priority_queue<tuple<int,int,int,int>> que;
      que.push({0, a, a, -1});
      while (!que.empty()) {
        auto [d, p, prev, f] = que.top();
        que.pop();
        if (dmp[p] <= d) { continue; }
        dmp[p] = d;
        first[p] = f;
        for (int q : adjs[p]) {
          if (dmp[q] <= d+1) { continue; }
          que.push({d+1, q, p, (f < 0) ? q : f});
        }
        for (int q : adjs2[p]) {
          if (dmp[q] <= d+team_cost) { continue; }
          que.push({d+team_cost, q, p, (f < 0) ? q : f});
        }
      }
    }

#if 0
    for (int a=0; a<N; a++) {
      cerr << format("%2d: ", a);
      for (int b=0; b<N; b++) {
        cerr << format("%2d ", dmat[a*N+b]);        
      }
      cerr << endl;
    }

    for (int a=0; a<N; a++) {
      cerr << format("%2d: ", a);
      for (int b=0; b<N; b++) {
        cerr << format("%2d ", firsts[a][b]);        
      }
      cerr << endl;
    }
#endif

#if 0    
    cerr << "graph {" << endl;
    for (int a=0; a<N; a++) {
      cerr << format("  v%02d; ", a) << endl;
    }
    for (const auto& [a, b] : es) {
      cerr << format("  v%02d -- v%02d;", a, b) << endl;
    }
    cerr << "}" << endl;
#endif

    map<int,set<int>> clusters;
    for (int a=0; a<N; a++) {
      clusters[uf.root(a)].insert(a);
    }
    for (const auto& [k, v] : clusters) {
      //DBG(v);
    }
    
  }

};
testcase_t tc;

struct state_t {
  int elapsed_time;
  vector<bridgeman_t> bridgemen;
  vector<order_t> orders;

  vector<bridge_t> bridges;

  void read_turn(istream& is) {
    is >> elapsed_time;

    bridgemen.clear();
    for (int i=0; i<tc.B; i++) {
      bridgeman_t bm;
      is >> bm.island >> bm.carry >> bm.target;
      bm.id = i;
      bridgemen.push_back(bm);
    }

    orders.clear();
    for (int i=0; i<tc.O; i++) {
      order_t order;
      is >> order.from >> order.to;
      orders.push_back(order);
    }
  }

  void apply(const command_t& cmd) {
    if (cmd.type == type_t::MOVE) {
      int bid = cmd.a;
      
      int from = bridgemen[bid].island;
      int to = cmd.b;

      assert(has_bridge(from, to));
      bridgemen[bid].island = to;
    } else if (cmd.type == type_t::UNPACK) {
      int bid = cmd.a;
      
      int from = bridgemen[bid].island;
      int to = cmd.b;

      //assert(!has_bridge(from, to));
      if (!has_bridge(from, to)) {
        bridges.push_back({from, to, {bid}});
      }

    } else if (cmd.type == type_t::PACK) {
      int bid = cmd.a;
      
      int from = bridgemen[bid].island;
      int to = cmd.b;

      auto it = find(bridges.begin(), bridges.end(), bridge_t(from, to, {bid}));

      assert(it != bridges.end());

      bridges.erase(it);
    }
  }

  bool is_valid_command(const command_t& cmd) const {
    if (cmd.type == type_t::MOVE) {
      int bid = cmd.a;
      
      int from = bridgemen[bid].island;
      int to = cmd.b;

      return has_bridge(from, to);
    }

    return false;
  }

  bool has_bridge(int a,int b) const {
    if (a > b) { swap(a, b); }
    return find_if(bridges.begin(), bridges.end(), [&](const auto& bridge) {
      return bridge.a == a && bridge.b == b;
    }) != bridges.end();
  }

  int get_bridge_index(int a,int b) const {
    if (a > b) { swap(a, b); }
    for (int i=0; i<bridges.size(); i++) {
      const auto& bridge(bridges[i]);
      if (bridge.a == a && bridge.b == b) {
        return i;
      }
    }
    return -1;
  }

  int pack_target(int bid) const {
    const auto bridgeman(bridgemen[bid]);

    int from = bridgeman.island;
    int to = -1;
    for (const auto& bridge : bridges) {
      if (bridge.owners.size() != 1) { continue; }
      if (bridge.owners[0] != bid) { continue; }

      if (bridge.a == from) {
        to = bridge.b;
        break;
      } else if (bridge.b == from) {
        to = bridge.a;
        break;
      }
      cerr << "pack_failed: " << bridgemen[bid].to_string() << endl;
      DBG(bridge.to_string());
      
      assert(false);
    }

    return to;
  }
};

struct commands_t {
  vector<command_t> cmds;
  string msg;
  
  void output() const {
    vector<string> ss;
    for (const auto& cmd : cmds) {
      ss.push_back(cmd.to_string());
    }
    if (!msg.empty()) {
      ss.push_back(format("MSG %s", msg.c_str()));
    }

    for (int i=0; i<ss.size(); i++) {
      if (i > 0) { cout << "|"; }
      cout << ss[i];
    }
    cout << endl;
  }

  void append(const command_t& cmd) {
    cmds.push_back(cmd);
  }
};

struct solver_t {
  command_t simple_move_command(const state_t& st,int bid,int from,int to) {
    if (to < 0) { return {}; }
    
    const auto& bridgeman(st.bridgemen[bid]);

    // priority: pack -> move -> unpack
    auto bridge_idx = st.get_bridge_index(from, to);
    
    if (bridge_idx >= 0 &&
        (bridgeman.carry == INITIAL_PARTS || include_v(st.bridges[bridge_idx].owners, bid))) {
      return command_t::move(bid, to);
    } else if (bridgeman.carry == INITIAL_PARTS) {
      if (tc.dmat[from*tc.N+to] <= bridgeman.carry) {
        return command_t::unpack(bid, to);
      } else {
        return command_t(); // stay
      }
    } else {
      
      auto target = st.pack_target(bid);
      if (target >= 0) {
        return command_t::pack(bid, target);
      } else {
        return {};
      }
    }

    assert(false);
  }

  commands_t think(const state_t& st0) {
    commands_t cmds;

    for (const auto& bridge : st0.bridges) {
      //cerr << bridge.to_string() << endl;
    }

    auto st(st0);
    for (int bid=0; bid<tc.B; bid++) {
      const auto& bridgeman(st.bridgemen[bid]);
      //cerr << bridgeman.to_string() << " ----------" << endl;
      
      int from = bridgeman.island;      

      command_t cmd;
      if (bridgeman.target >= 0) {
        int to = tc.firsts[from][bridgeman.target];
        //cerr << format("B#%02d", bid) << " plan: " << from << "->" << bridgeman.target << endl;
        //cerr << format("B#%02d", bid) << " move: " << from << "->" << to << endl;

        assert(to >= 0);
        cmd = simple_move_command(st, bid, from, to);
      } else {
        int best_o = -1;
        int best_d = 1234567;
        for (int o=0; o<tc.O; o++) {
          const auto& order(st.orders[o]);
          int d = tc.dmps[from][order.from] + tc.dmps[order.from][order.to];
          if (d < best_d) {
            best_d = d;
            best_o = o;
          }
        }
        //cerr << format("B#%02d", bid) << " " << from << "->" << st.orders[best_o].from << "->" << st.orders[best_o].to << " " << best_d << endl;
        int to = tc.firsts[from][st.orders[best_o].from];

        cmd = simple_move_command(st, bid, from, to);
      }
      //cerr << cmd.to_string() << endl;
      cmds.append(cmd);
      st.apply(cmd);
    }
    
    cmds.msg = "Hello\\nworld!";

    return cmds;
  }
};

int main() {
  tc.read_init(cin);
  tc.setup();

  solver_t slv;
  state_t st;
  for (int t=0; t<MAX_TURN; t++) {
    //cerr << "turn: " << t << " ==============================" << endl;
    st.read_turn(cin);
    auto ret = slv.think(st);
    ret.output();

    for (const auto cmd : ret.cmds) {
      st.apply(cmd);
    }
    //DBG(st.bridges.size());
  }
}
