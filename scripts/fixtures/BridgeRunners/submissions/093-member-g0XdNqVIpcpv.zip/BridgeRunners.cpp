#include <bits/stdc++.h>

#define INLINE inline __attribute__((always_inline))
#define NOINLINE __attribute__((noinline))

using namespace std;

mt19937 rng(0);

typedef int8_t i8;
typedef int16_t i16;
typedef int32_t i32;
typedef int64_t i64;

typedef uint64_t u64;
typedef uint32_t u32;
typedef uint16_t u16;

#ifdef VERBOSE
template<typename First, typename... Rest> void logln_impl(First &&first, Rest &&...rest) {
    cerr << first;
    ((cerr << " " << rest), ...);
    cerr << "\n";
}

#define log(...) logln_impl(__VA_ARGS__)
#else
#define log(...)
#endif

#ifndef IDEA
#define IDEA 0
#endif

constexpr int INF = numeric_limits<int>::max();

int ORDER_DST[10];
int ORDER_SRC[10];
int ORDER_SRC_INV[80];

int DISTANCES[80][80];
int N, B, O;

// dijkstra precomputing for A*
int DIJKSTRA[80][80];
int DIJKSTRA_ROUTE[80][80];

u64 bridges_hashes[80][80];

void INIT_zobrist_for_bridges() {
    for (int i = 0; i < 80; i++) {
	for (int j = 0; j <= i; j++) {
	    auto v = uniform_int_distribution<u64>()(rng);
	    bridges_hashes[i][j] = v;
	    bridges_hashes[j][i] = v;
	}
    }
}

void run_dijkstra_once(int src) {
    fill_n(DIJKSTRA[src], 80, INF);
    DIJKSTRA[src][src] = 0;
    DIJKSTRA_ROUTE[src][src] = src; // self-loop

    struct Item {
	int node;
	int dist;
    };

    auto cmp = [](Item a, Item b) { return a.dist > b.dist; };
    priority_queue<Item, vector<Item>, decltype(cmp)> queue(cmp);
    queue.push({src, 0});

    while (!queue.empty()) {
	Item top = queue.top();
	queue.pop();

	// filter outdated entries
	if (top.dist > DIJKSTRA[src][top.node]) continue;

	for (int n = 0; n < N; n++) {
	    if (n == top.node) continue;
	    int edge_length = DISTANCES[top.node][n];
	    if (edge_length > 120) continue;
	    if (edge_length > 60) edge_length += 4000;

	    int new_dist = top.dist + edge_length;
	    // int new_dist = top.dist + 1;
	    if (new_dist < DIJKSTRA[src][n]) {
		queue.push({n, new_dist});
		DIJKSTRA[src][n] = new_dist;
		DIJKSTRA_ROUTE[src][n] = top.node;
	    }
	}
    }
}

void load_from_stdin() {
    cin >> N >> B >> O;
    assert(N >= 25 && N <= 80);
    assert(B >= 04 && B <= 20);
    assert(O >= 04 && O <= 10);

    for (int n = 0; n < N; n++) {
	for (int m = 0; m < N; m++) {
	    int dist;
	    cin >> dist;

	    if (n == m) assert(dist == 0);
	    else assert(dist > 0 && dist <= 354);

	    DISTANCES[n][m] = dist;
	}
    }

    for (int n = 0; n < N; n++) {
	run_dijkstra_once(n);
    }
}

struct Builder {
    i8 position;
    i8 target;
    i8 carry;

    INLINE u64 get_hash() const {
	// Use different prime multipliers for each field to ensure good distribution
	u64 h1 = static_cast<u64>(position) * 0x9e3779b97f4a7c15ULL;
	u64 h2 = static_cast<u64>(target) * 0x85ebca6b7f4a7c13ULL;
	u64 h3 = static_cast<u64>(carry) * 0x6ba658b97f4a7c11ULL;

	// XOR combine with bit rotations to avoid simple cancellation
	u64 result = h1 ^ (h2 << 8) ^ (h3 << 16);

	// Final mixing step - Knuth's multiplicative hash
	result *= 0x9e3779b97f4a7c15ULL;
	result ^= result >> 32;
	return result;
    }

    string repr() const { return "P:" + to_string(position) + " T:" + to_string(target) + " C:" + to_string(carry); }
};

struct Action {
    enum Type : i8 {
	MOVE,
	PACK,
	UNPACK,
	WAIT,
    };

    Type type;
    i8 value;

    string repr(int id) const {
	if (type == MOVE) return "MOVE " + to_string(id) + " " + to_string(value);
	if (type == PACK) return "PACK " + to_string(id) + " " + to_string(value);
	if (type == UNPACK) return "UNPACK " + to_string(id) + " " + to_string(value);
	return "";
    }
};

struct State {
    Builder builders[20];
    bitset<80> bridges[80];

    u64 hash;
    i8 orders_delivered;
    u16 orders_taken_bitmap;

    static State init() {
	State s;
	s.hash = 0;
	s.orders_delivered = 0;
	s.orders_taken_bitmap = 0;
	for (int i = 0; i < 80; i++) s.bridges[i].reset();
	return s;
    }

    void update_from_stdin() {
	int elapsed_time;
	cin >> elapsed_time;

	for (int b = 0; b < B; b++) {
	    int p, c, t;
	    cin >> p >> c >> t;
	    builders[b] = {(i8) p, (i8) t, (i8) c};
	}

	fill_n(ORDER_SRC_INV, 80, -1);
	for (int o = 0; o < O; o++) {
	    int orig, dest;
	    cin >> orig >> dest;
	    ORDER_SRC[o] = orig;
	    ORDER_DST[o] = dest;
	    ORDER_SRC_INV[orig] = dest;
	}
    }

    bool apply(const int builder_idx, const Action action) {
	if (action.type == Action::WAIT) return true;

	hash ^= builders[builder_idx].get_hash();
	i8 pos = builders[builder_idx].position;

	if (action.type == Action::PACK) {
	    if (bridges[pos][action.value] == 0) return false;

	    bridges[pos].reset(action.value);
	    bridges[action.value].reset(pos);
	    builders[builder_idx].carry += DISTANCES[pos][action.value];

	    if (builders[builder_idx].carry > 60) return false;
	    hash ^= bridges_hashes[pos][action.value];
	} else if (action.type == Action::UNPACK) {
	    if (builders[builder_idx].carry < DISTANCES[pos][action.value]) return false;
	    if (bridges[pos][action.value]) return false;
	    if (bridges[action.value][pos]) return false;

	    bridges[pos].set(action.value);
	    bridges[action.value].set(pos);
	    builders[builder_idx].carry -= DISTANCES[pos][action.value];
	    hash ^= bridges_hashes[pos][action.value];
	} else {
	    // MOVE
	    if (!bridges[pos][action.value]) return false;
	    builders[builder_idx].position = action.value;

	    if (builders[builder_idx].target == action.value) {
		builders[builder_idx].target = -1;
		orders_delivered++;
	    }

	    int ord_idx = ORDER_SRC_INV[action.value];
	    if (builders[builder_idx].target == -1 && ord_idx != -1 && !(orders_taken_bitmap & (1 << ord_idx))) {
		builders[builder_idx].target = ORDER_DST[ord_idx];
		orders_taken_bitmap |= (1 << ord_idx);
	    }
	}

	hash ^= builders[builder_idx].get_hash();
	return true; // success
    }

    int team_unpack(int b1, int b2) {
	int p1 = builders[b1].position;
	int p2 = builders[b2].position;
	int total_carry = builders[b1].carry + builders[b2].carry;

	assert(!bridges[p1][p2]);
	assert(total_carry >= DISTANCES[p1][p2]);

	bridges[p1].set(p2);
	bridges[p2].set(p1);

	int b1_pays = min((int) builders[b1].carry, DISTANCES[p1][p2]);
	int b2_pays = DISTANCES[p1][p2] - b1_pays;
	builders[b1].carry -= b1_pays;
	builders[b2].carry -= b2_pays;

	return b1_pays;
    }
};

vector<Action> get_legal_actions(const State &state, int builder_idx) {
    vector<Action> actions = {};
    i8 pos = state.builders[builder_idx].position;
    i8 carry = state.builders[builder_idx].carry;

    // MOVE
    for (i8 n = 0; n < N; n++) {
	if (n == pos) continue;

	int length = DISTANCES[pos][n];
	if (state.bridges[pos][n]) {
	    actions.push_back({Action::MOVE, n});

	    if (carry + length <= 60) actions.push_back({Action::PACK, n});
	} else if (carry >= length) actions.push_back({Action::UNPACK, n});
    }

    return actions;
}

struct BeamItem {
    int cost;
    State state;

    Action action;
    BeamItem *parent;

    bool operator<(const BeamItem &other) const { return cost < other.cost; }
};

template<int WIDTH> struct AutoBeam {
    int size;
    BeamItem items[WIDTH];

    void reset() { size = 0; }

    void insert(const BeamItem &item) {
	if (size < WIDTH) {
	    items[size++] = item;
	    if (size == WIDTH) make_heap(items, items + size);
	    return;
	}

	if (item.cost > items[0].cost) return;
	pop_heap(items, items + size);
	items[size - 1] = item;
	push_heap(items, items + size);
    }

    const BeamItem *get_best() {
	assert(size > 0);
	BeamItem *best = nullptr;
	int best_cost = INF;
	for (int i = 0; i < size; i++) {
	    if (items[i].cost < best_cost) {
		best_cost = items[i].cost;
		best = &items[i];
	    }
	}
	assert(best != nullptr);
	return best;
    }
};

constexpr int DEPTH = 14;
AutoBeam<32> BEAMS[DEPTH];

vector<Action> extract_route(const BeamItem *ptr) {
    assert(ptr != nullptr);

    vector<Action> actions;
    while (ptr->parent != nullptr) {
	actions.push_back(ptr->action);
	ptr = ptr->parent;
    }
    reverse(actions.begin(), actions.end());
    return actions;
}

vector<Action> PLANNED_ACTIONS[20];

vector<Action> find_bs_actions(const State &start_state, int builder_idx, int dest) {
    if (start_state.builders[builder_idx].position == dest) return {};
    auto get_cost = [&](const State &s) {
	return DIJKSTRA[s.builders[builder_idx].position][dest] * 10 + s.builders[builder_idx].carry;
    };

    BEAMS[0].reset();
    auto start_cost = get_cost(start_state);
    BEAMS[0].insert({.cost = start_cost, .state = start_state, .parent = nullptr});

    unordered_set<u64> visited;
    visited.insert(start_state.hash);

    const BeamItem *best_seen = nullptr;

    for (int d = 1; d < DEPTH; d++) {
	BEAMS[d].reset();

	for (int i = 0; i < BEAMS[d - 1].size; i++) {
	    BeamItem &top = BEAMS[d - 1].items[i];
	    if (best_seen == nullptr || top.cost < best_seen->cost) best_seen = &top;
	    if (top.state.builders[builder_idx].position == dest) return extract_route(&top);

	    State parent_state = top.state;

	    if (d > 1) {
		bool success = true;

		for (int b = builder_idx + 1; b < B; b++) {
		    if (PLANNED_ACTIONS[b].size() < d) continue;
		    Action a = PLANNED_ACTIONS[b][d - 1];
		    success = parent_state.apply(b, a);
		    if (!success) break;
		}
		if (!success) continue;

		for (int b = 0; b < builder_idx; b++) {
		    if (PLANNED_ACTIONS[b].size() < d) continue;
		    Action a = PLANNED_ACTIONS[b][d - 1];
		    success = parent_state.apply(b, a);
		    if (!success) break;
		}
		if (!success) continue;
	    }

	    auto actions = get_legal_actions(parent_state, builder_idx);
	    for (auto &action : actions) {
		State child = parent_state;
		bool success = child.apply(builder_idx, action);
		assert(success);

		if (d == 1 && action.type == Action::PACK) {
		    bool dont = false;
		    for (int b = 0; b < B; b++) {
			Builder &bb = child.builders[b];
			if (bb.position == action.value && child.bridges[action.value].none() && bb.carry < 40) {
			    if (uniform_real_distribution<double>(0.0, 1.0)(rng) < 0.1) continue;
			    dont = true;
			    break;
			}
		    }
		    if (dont) continue;
		}

		if (!visited.insert(child.hash).second) continue;
		BEAMS[d].insert({
			.cost = get_cost(child),
			.state = child,
			.action = action,
			.parent = &top,
		});
	    }
	}

	log("Beam depth", d, "with", BEAMS[d].size, "states");
    }

    assert(best_seen != nullptr);
    for (int i = 0; i < BEAMS[DEPTH - 1].size; i++) {
	BeamItem &top = BEAMS[DEPTH - 1].items[i];
	if (top.cost < best_seen->cost) best_seen = &top;
    }
    return extract_route(best_seen);

    // if (BEAMS[DEPTH - 1].size == 0) return {};
    // auto best = BEAMS[DEPTH - 1].get_best();
    // if (best->cost >= start_cost) return {}; // stranded
    // return extract_route(best);
}

bool REACHABLE[20][20] = {};

bool is_reachable(const State &state, int b1, int b2) {
    int p1 = state.builders[b1].position;
    int p2 = state.builders[b2].position;

    unordered_set<int> visited;
    visited.insert(p1);

    queue<int> to_visit;
    to_visit.push(p1);

    while (!to_visit.empty()) {
	int top = to_visit.front();
	to_visit.pop();
	if (top == p2) return true;

	for (int n = 0; n < N; n++) {
	    if (DISTANCES[top][n] <= 50 || state.bridges[top][n]) {
		if (visited.insert(n).second) to_visit.push(n);
	    }
	}
    }

    return false;
}

void update_reachable(const State &state) {
    for (int b1 = 0; b1 < B; b1++) {
	for (int b2 = 0; b2 < B; b2++) {
	    if (REACHABLE[b1][b2]) continue;
	    REACHABLE[b1][b2] = is_reachable(state, b1, b2);
	    cerr << "REACHABLE[" << b1 << "][" << b2 << "] = " << REACHABLE[b1][b2] << " "
		 << DIJKSTRA[state.builders[b1].position][state.builders[b2].position] << endl;
	}
    }
}

int main() {
    INIT_zobrist_for_bridges();
    load_from_stdin();

    State state = State::init();

    int LAST_TARGET[B];
    fill_n(LAST_TARGET, B, -1);

    for (int turn = 0; turn < 1000; turn++) {
	stringstream msg;
	if (turn == 0 || !IDEA) state.update_from_stdin();
	// if (turn == 0) update_reachable(state);

	int PENALTY[O] = {};
	int SKIPACT[20] = {};

	// for (int b1 = 0; b1 < B; b1++) {
	//     for (int b2 = 0; b2 < b1; b2++) {
	// 	int p1 = state.builders[b1].position;
	// 	int p2 = state.builders[b2].position;
	// 	int tot_carry = state.builders[b1].carry + state.builders[b2].carry;
	// 	int dist = DISTANCES[p1][p2];
	// 	if (dist > 60 && tot_carry >= dist && !state.bridges[p1][p2] && DIJKSTRA[p1][p2] > 1000) {
	// 	    PLANNED_ACTIONS[b1] = {};
	// 	    PLANNED_ACTIONS[b2] = {};
	// 	    SKIPACT[b1] = 1;
	// 	    SKIPACT[b2] = 1;
	//
	// 	    int b1_pays = state.team_unpack(b1, b2);
	// 	    cout << "TEAMUNPACK " << b1 << " " << b2 << " " << b1_pays << " | ";
	// 	    goto FIN;
	// 	}
	//     }
	// }

    FIN:

	for (int b = 0; b < B; b++) {
	    PLANNED_ACTIONS[b] = {};
	    if (SKIPACT[b]) continue;

	    int pos = state.builders[b].position;
	    int target = state.builders[b].target;

	    if (target == -1) { // select a reachable order
		int best_o = -1;
		int best_dist = INF;
		for (int o = 0; o < O; o++) {
		    int src = ORDER_SRC[o];
		    int dist = PENALTY[o] + DIJKSTRA[pos][src];
		    if (dist < best_dist) {
			best_dist = dist;
			best_o = o;
		    }
		}
		assert(best_dist != INF);
		target = ORDER_SRC[best_o];
		PENALTY[best_o] += 50;
	    }

	    PLANNED_ACTIONS[b] = find_bs_actions(state, b, target);
	    LAST_TARGET[b] = target;

	    msg << b << " targets " << target << ":";
	    for (auto &a : PLANNED_ACTIONS[b]) msg << " " << (int) a.value;
	    msg << "\\n";

	    if (!PLANNED_ACTIONS[b].empty()) {
		Action first_action = PLANNED_ACTIONS[b][0];
		state.apply(b, first_action);
		cout << first_action.repr(b) << " | ";
	    }
	}

	cout << "MSG " << msg.str() << endl;
	if constexpr (IDEA) break;
    }

    return 0;
}
