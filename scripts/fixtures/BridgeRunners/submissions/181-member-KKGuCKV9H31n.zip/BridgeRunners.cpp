#include <iostream>
#include <vector>
#include <string>
#include <sstream>
#include <set>
#include <queue>
#include <map>
#include <algorithm>
#include <limits>
#include <cmath>
#include <functional>

using namespace std;

constexpr int MAX_TURNS = 1000;
constexpr int MAX_BRIDGE_LENGTH = 60;
constexpr double INF = 1e9;

struct Island {
    int id;
    vector<int> distances;
    set<int> connected_to;
    int message_activity = 0;
};

struct Bridgeman {
    int id;
    int current_island;
    int bridge_length;
    int message_target;
    bool busy = false;
};

struct Order {
    int origin, destination;
    double priority = 0.0;
};

int N, B, O;
vector<Island> islands;
vector<Bridgeman> bridgemen;
vector<Order> orders;
vector<vector<bool>> bridges;
vector<vector<int>> dist_matrix;
bool graph_changed = true;

void update_distances() {
    dist_matrix.assign(N, vector<int>(N, INF));
    for (int i = 0; i < N; i++) {
        priority_queue<pair<int, int>, vector<pair<int, int>>, greater<pair<int, int>>> pq;
        dist_matrix[i][i] = 0;
        pq.push({0, i});
        while (!pq.empty()) {
            int u = pq.top().second;
            int d = pq.top().first;
            pq.pop();
            if (d != dist_matrix[i][u]) continue;
            for (int v : islands[u].connected_to) {
                int new_dist = d + 1;
                if (new_dist < dist_matrix[i][v]) {
                    dist_matrix[i][v] = new_dist;
                    pq.push({new_dist, v});
                }
            }
        }
    }
}

void init() {
    cin >> N >> B >> O;
    islands.resize(N);
    bridges.assign(N, vector<bool>(N, false));
    for (int i = 0; i < N; i++) {
        islands[i].id = i;
        islands[i].distances.resize(N);
        for (int j = 0; j < N; j++) {
            cin >> islands[i].distances[j];
        }
    }
    bridgemen.resize(B);
    for (int i = 0; i < B; i++) {
        bridgemen[i].id = i;
        bridgemen[i].bridge_length = 50;
        bridgemen[i].message_target = -1;
    }
    update_distances();
}

void read_turn() {
    long long elapsed;
    cin >> elapsed;
    for (auto& island : islands) {
        island.message_activity = 0;
    }
    for (int i = 0; i < B; i++) {
        int island, carry, target;
        cin >> island >> carry >> target;
        bridgemen[i].current_island = island;
        bridgemen[i].bridge_length = carry;
        bridgemen[i].message_target = target;
        bridgemen[i].busy = false;
    }
    orders.clear();
    for (int i = 0; i < O; i++) {
        int orig, dest;
        cin >> orig >> dest;
        orders.push_back({orig, dest});
        islands[orig].message_activity++;
        islands[dest].message_activity++;
    }
    if (graph_changed) {
        update_distances();
        graph_changed = false;
    }
}

void update_bridge(int i, int j, bool exists) {
    if (bridges[i][j] != exists) {
        bridges[i][j] = exists;
        bridges[j][i] = exists;
        if (exists) {
            islands[i].connected_to.insert(j);
            islands[j].connected_to.insert(i);
        } else {
            islands[i].connected_to.erase(j);
            islands[j].connected_to.erase(i);
        }
        graph_changed = true;
    }
}

vector<int> find_path(int start, int end) {
    if (start == end) return {start};
    vector<int> prev(N, -1);
    vector<int> dist(N, INF);
    priority_queue<pair<int, int>, vector<pair<int, int>>, greater<pair<int, int>>> pq;
    dist[start] = 0;
    pq.push({0, start});
    prev[start] = start;
    while (!pq.empty()) {
        int u = pq.top().second;
        int d = pq.top().first;
        pq.pop();
        if (d != dist[u]) continue;
        if (u == end) break;
        for (int v : islands[u].connected_to) {
            int new_dist = d + 1;
            if (new_dist < dist[v]) {
                dist[v] = new_dist;
                prev[v] = u;
                pq.push({new_dist, v});
            }
        }
    }
    if (prev[end] == -1) return {};
    vector<int> path;
    for (int v = end; v != start; v = prev[v]) {
        path.push_back(v);
    }
    path.push_back(start);
    reverse(path.begin(), path.end());
    return path;
}

void calculate_priorities() {
    for (auto& order : orders) {
        double priority = 0.0;
        int d = islands[order.origin].distances[order.destination];
        priority += 1000.0 / (d + 1);
        priority += islands[order.origin].message_activity * 10;
        priority += islands[order.destination].message_activity * 10;
        priority += islands[order.origin].connected_to.size() * 5;
        priority += islands[order.destination].connected_to.size() * 5;
        order.priority = priority;
    }
    sort(orders.begin(), orders.end(), [](const Order& a, const Order& b) {
        return a.priority > b.priority;
    });
}

vector<int> assign_orders() {
    vector<int> free_bridgemen;
    for (int i = 0; i < B; i++) {
        if (bridgemen[i].message_target == -1) {
            free_bridgemen.push_back(i);
        }
    }
    vector<int> order_indices(orders.size());
    for (int i = 0; i < orders.size(); i++) order_indices[i] = i;
    sort(order_indices.begin(), order_indices.end(), [&](int a, int b) {
        return orders[a].priority > orders[b].priority;
    });

    vector<int> assignment(B, -1);
    if (free_bridgemen.empty()) return assignment;

    for (int o_idx : order_indices) {
        double min_cost = INF;
        int best_b = -1;
        for (int b_id : free_bridgemen) {
            int origin = orders[o_idx].origin;
            int dest = orders[o_idx].destination;
            double cost = dist_matrix[bridgemen[b_id].current_island][origin] + dist_matrix[origin][dest];
            if (cost >= INF) {
                cost = islands[bridgemen[b_id].current_island].distances[origin] + islands[origin].distances[dest] + 1000;
            }
            if (cost < min_cost) {
                min_cost = cost;
                best_b = b_id;
            }
        }
        if (best_b != -1) {
            assignment[best_b] = o_idx;
            free_bridgemen.erase(remove(free_bridgemen.begin(), free_bridgemen.end(), best_b), free_bridgemen.end());
        }
    }
    return assignment;
}

bool can_build_bridge(int bm_id, int target) {
    int current = bridgemen[bm_id].current_island;
    if (bridges[current][target]) return false;
    int d = islands[current].distances[target];
    return d <= bridgemen[bm_id].bridge_length && d <= MAX_BRIDGE_LENGTH;
}

bool can_team_build(int bm1_id, int bm2_id) {
    int i1 = bridgemen[bm1_id].current_island;
    int i2 = bridgemen[bm2_id].current_island;
    if (i1 == i2 || bridges[i1][i2]) return false;
    int d = islands[i1].distances[i2];
    return d <= MAX_BRIDGE_LENGTH && d <= bridgemen[bm1_id].bridge_length + bridgemen[bm2_id].bridge_length;
}

pair<int, double> best_bridge_target(int bm_id) {
    int current = bridgemen[bm_id].current_island;
    int best_target = -1;
    double best_score = -1;
    for (int target = 0; target < N; target++) {
        if (target == current || !can_build_bridge(bm_id, target)) continue;
        double score = islands[target].message_activity * 20;
        score += islands[target].connected_to.size() * 10;
        score += (MAX_BRIDGE_LENGTH - islands[current].distances[target]) * 2;
        for (const auto& order : orders) {
            if ((order.origin == current && order.destination == target) ||
                (order.origin == target && order.destination == current)) {
                score += 100;
            }
        }
        if (score > best_score) {
            best_score = score;
            best_target = target;
        }
    }
    return {best_target, best_score};
}

string decide_action(int bm_id, int assigned_order, const vector<bool>& assigned) {
    auto& bm = bridgemen[bm_id];
    if (bm.message_target != -1) {
        if (bm.current_island == bm.message_target) return "";
        vector<int> path = find_path(bm.current_island, bm.message_target);
        if (!path.empty() && path.size() > 1) {
            return "MOVE " + to_string(bm_id) + " " + to_string(path[1]);
        }
        int d = islands[bm.current_island].distances[bm.message_target];
        if (d <= bm.bridge_length && d <= MAX_BRIDGE_LENGTH) {
            return "UNPACK " + to_string(bm_id) + " " + to_string(bm.message_target);
        }
        for (int other = 0; other < B; other++) {
            if (other == bm_id || assigned[other] || bridgemen[other].current_island != bm.message_target) continue;
            if (can_team_build(bm_id, other)) {
                int total_d = islands[bm.current_island].distances[bm.message_target];
                int contribution = min(bm.bridge_length, total_d);
                contribution = max(contribution, total_d - bridgemen[other].bridge_length);
                return "TEAMUNPACK " + to_string(bm_id) + " " + to_string(other) + " " + to_string(contribution);
            }
        }
    } else if (assigned_order != -1) {
        int origin = orders[assigned_order].origin;
        if (bm.current_island == origin) return "";
        vector<int> path = find_path(bm.current_island, origin);
        if (!path.empty() && path.size() > 1) {
            return "MOVE " + to_string(bm_id) + " " + to_string(path[1]);
        }
        int d = islands[bm.current_island].distances[origin];
        if (d <= bm.bridge_length && d <= MAX_BRIDGE_LENGTH) {
            return "UNPACK " + to_string(bm_id) + " " + to_string(origin);
        }
        for (int other = 0; other < B; other++) {
            if (other == bm_id || assigned[other] || bridgemen[other].current_island != origin) continue;
            if (can_team_build(bm_id, other)) {
                int total_d = islands[bm.current_island].distances[origin];
                int contribution = min(bm.bridge_length, total_d);
                contribution = max(contribution, total_d - bridgemen[other].bridge_length);
                return "TEAMUNPACK " + to_string(bm_id) + " " + to_string(other) + " " + to_string(contribution);
            }
        }
    } else {
        auto [target, score] = best_bridge_target(bm_id);
        if (target != -1) {
            return "UNPACK " + to_string(bm_id) + " " + to_string(target);
        }
        int best_island = -1;
        int best_activity = -1;
        for (int i = 0; i < N; i++) {
            if (i != bm.current_island && bridges[bm.current_island][i] && islands[i].message_activity > best_activity) {
                best_activity = islands[i].message_activity;
                best_island = i;
            }
        }
        if (best_island != -1) {
            return "MOVE " + to_string(bm_id) + " " + to_string(best_island);
        }
    }
    return "";
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    init();
    for (int turn = 0; turn < MAX_TURNS; turn++) {
        read_turn();
        calculate_priorities();
        vector<int> assignment = assign_orders();
        vector<bool> assigned(B, false);
        vector<string> actions;
        for (int i = 0; i < B; i++) {
            if (assigned[i]) continue;
            string action = decide_action(i, assignment[i], assigned);
            if (action.empty()) continue;
            actions.push_back(action);
            istringstream iss(action);
            string cmd;
            iss >> cmd;
            if (cmd == "MOVE") {
                int bm_id, target;
                iss >> bm_id >> target;
                assigned[bm_id] = true;
            } else if (cmd == "UNPACK") {
                int bm_id, target;
                iss >> bm_id >> target;
                assigned[bm_id] = true;
                update_bridge(bridgemen[bm_id].current_island, target, true);
                bridgemen[bm_id].bridge_length -= islands[bridgemen[bm_id].current_island].distances[target];
            } else if (cmd == "TEAMUNPACK") {
                int bm1, bm2, len;
                iss >> bm1 >> bm2 >> len;
                assigned[bm1] = true;
                assigned[bm2] = true;
                update_bridge(bridgemen[bm1].current_island, bridgemen[bm2].current_island, true);
                bridgemen[bm1].bridge_length -= len;
                bridgemen[bm2].bridge_length -= islands[bridgemen[bm1].current_island].distances[bridgemen[bm2].current_island] - len;
            }
        }
        for (size_t i = 0; i < actions.size(); i++) {
            cout << actions[i];
            if (i < actions.size() - 1) cout << "|";
        }
        cout << endl;
    }
    return 0;
}