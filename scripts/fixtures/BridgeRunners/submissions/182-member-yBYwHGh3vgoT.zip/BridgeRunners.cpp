#include<bits/stdc++.h>
using namespace std;
using ll = long long;
const ll INF = 2e18 ;
#define debug(var) cerr << #var << " : " << var << endl;

static unsigned int x=123456789,y=362436069,z=521288629,w=88675123;
unsigned int rand32u(){unsigned int t;t=(x^(x<<11));x=y;y=z;z=w;return(w=(w^(w>>19))^(t^(t>>8)));}
ll random(ll MIN,ll MAX){return MIN+ll(rand32u()%(unsigned int)(MAX-MIN));}

class Bridgemen{
public:
    int ID ;
    int Position ;
    int Residue ;
    int Target ;
};
class Order {
public:
    int From ; 
    int To ;
};

int main() {
    //input
    int N, B, O;
    cin >> N >> B >> O;
    int dists[N][N];
    for (int i = 0; i < N; ++i) {
        for (int j = 0; j < N; ++j) {
            cin >> dists[i][j];
        }
    }
    
    auto skip = [&]()->void{
        int elapsedTime ;
        cin >> elapsedTime ;
        for(int i = 0 ; i < B ; i ++ ){
            int a,b,c;cin >> a >> b >> c ;
        }
        for(int i = 0 ; i < O ; i ++ ){
            int a,b;cin >> a >> b ;
        }
    };
    
    int turn = 0 ;
    while(true) {
        int elapsedTime ;
        cin >> elapsedTime ;
        Bridgemen bridgemen[B] ;
        Order orders[O] ;
        for (auto&b : bridgemen) {
            int c;
            cin >> b.Position >> b.Residue >> b.Target;
        }
        for (int i = 0 ; i < B ; i ++) {
            bridgemen[i].ID = i ;
        }
        for (auto&o : orders){
            cin >> o.From >> o.To ;
        }

        //from A to B
        //1. not throw any message(from) && e <= 50
        //2. e <= 50
        //3. e <= 100
        ll dp1[N][N] ;
        ll dp2[N][N] ;
        ll dp3[N][N] ;
        ll dp_tmp[N][N] ;
        for(int i = 0 ; i < N ; i ++ )for(int j = 0 ; j < N ; j ++ ) dp_tmp[i][j] = dp1[i][j] = dp2[i][j] = dp3[i][j] = INF ;
        //dp1
        for(int i = 0 ; i < N ; i ++ ){
            //from vertex i
            deque<int> dq ;
            dq.push_back(i) ;
            vector<bool> vst(N , false) ;
            for (auto&o : orders) {
                vst[o.From] = true ;
            }
            dp_tmp[i][i] = 0 ;
            if (vst[i]) {
                dp1[i][i] = 0 ;
                continue ;
            }
            vst[i] = true ;
            while (!dq.empty()) {
                int df = dq.front() ;
                dq.pop_front() ;
                for (int j = 0; j < N ; j ++) {
                    if(dists[df][j] <= 50 && !vst[j]) {
                        vst[j] = true ;
                        dp_tmp[i][j] = dp_tmp[i][df] + 1 ;
                        dq.push_back(j) ;
                    }
                }
            }
            for (auto&o : orders) {
                //iからo.Fromに行く
                for (int j = 0 ; j < N ; j ++ ) {
                    if(dists[j][o.From] <= 50){
                        dp1[i][o.From] = 
                    min(dp1[i][o.From] , dp_tmp[i][j] + 1) ;
                    }
                }
            }
        }
        
        //dp2
        for(int i = 0 ; i < N ; i ++ ){
            //from vertex i
            deque<int> dq ;
            dq.push_back(i) ;
            vector<bool> vst(N , false) ;
            dp2[i][i] = 0 ;
            vst[i] = true ;
            while (!dq.empty()) {
                int df = dq.front() ;
                dq.pop_front() ;
                for (int j = 0; j < N ; j ++) {
                    if(dists[df][j] <= 50 && !vst[j]) {
                        vst[j] = true ;
                        dp2[i][j] = dp2[i][df] + 1 ;
                        dq.push_back(j) ;
                    }
                }
            }
        }

        //dp3
        for(int i = 0 ; i < N ; i ++ ){
            //from vertex i
            deque<int> dq ;
            dq.push_back(i) ;
            vector<bool> vst(N , false) ;
            dp3[i][i] = 0 ;
            vst[i] = true ;
            while (!dq.empty()) {
                int df = dq.front() ;
                dq.pop_front() ;
                for (int j = 0; j < N ; j ++) {
                    if(dists[df][j] <= 100 && !vst[j]) {
                        vst[j] = true ;
                        dp3[i][j] = dp3[i][df] + 1 ;
                        dq.push_back(j) ;
                    }
                }
            }
        }

        //それぞれのメッセージについて、届ける最短ターンを計算する
        vector<vector<string>> output(200) ;
        for (auto& o : orders) {
            if (dp2[o.From][o.To] < INF) {
                //1人で事足りる
                //どの人に運んでもらうか選ぶ
                int bi = -1 ;
                ll bd = INF ;
                for (int i = 0 ; i < B ; i ++ ) {
                    if (bridgemen[i].Target != -1) continue ;
                    //この人は使えるか?
                    ll tmp = dp1[bridgemen[i].Position][o.From] + dp2[o.From][o.To] ;
                    if (tmp < bd && dp1[o.From][o.To] >= INF) {
                        bd = tmp ;
                        bi = i ;
                    }
                }
                if (bi == -1) continue ; //次のorderを実行なら実行できるかも
                int clock = 0 ;
                int nv = bridgemen[bi].Position ;
                output[clock*3].push_back("MSG Bridgemen " + to_string(bi) + " is going to " + to_string(o.From)) ;
                while (nv != o.From) {
                    //移動候補をすべてみる
                    for(int i = 0 ; i < N ; i ++ ) {
                        if(dp1[i][o.From] + 1 == dp1[nv][o.From] && dists[i][nv] <= 50) {
                            output[3*clock].push_back("UNPACK " + to_string(bi) + " " + to_string(i)) ;
                            output[3*clock+1].push_back("MOVE " + to_string(bi) + " " + to_string(i)) ;
                            output[3*clock+2].push_back("PACK " + to_string(bi) + " " + to_string(nv)) ;
                            nv = i ;
                            break ;
                        }
                    }
                    clock ++ ;
                }
                output[clock*3].push_back("MSG Bridgemen " + to_string(bi) + " is going to " + to_string(o.To)) ;
                while (nv != o.To) {
                    //移動候補をすべて見る
                    for(int i = 0 ; i < N ; i ++ ) {
                        if(dp2[i][o.To] + 1 == dp2[nv][o.To] && dists[i][nv] <= 50) {
                            output[3*clock].push_back("UNPACK " + to_string(bi) + " " + to_string(i)) ;
                            output[3*clock+1].push_back("MOVE " + to_string(bi) + " " + to_string(i)) ;
                            output[3*clock+2].push_back("PACK " + to_string(bi) + " " + to_string(nv)) ;
                            nv = i ;
                            break ;
                        }
                    }
                    clock ++ ;
                }
                break ;
            }
            else {
                //need 2 person
                continue ;
            }
        }

        //output
        int i = 0 ;
        for( ; i < 200 && turn < 1000 && !output[i].empty() ; i ++ , turn ++ ){
            if(i > 0) skip() ;
            for (size_t j = 0 ; j < output[i].size() ; j ++ ) {
                cout << output[i][j] << ((j + 1 < output[i].size())?"|":"") ;
            }
            cout << endl ;
        }
        if(i == 0) {
            //end
            int elapsedTime ;
            cin >> elapsedTime ;
            for (auto&b : bridgemen) {
                int c;
                cin >> b.Position >> b.Residue >> c;
            }
            for (int i = 0 ; i < B ; i ++) {
                bridgemen[i].ID = i ;
            }
            for (auto&o : orders){
                cin >> o.From >> o.To ;
            }
            for (int i = 0 ; i < N ; i ++ ){
                for (int k = 0 ; k < B ; k ++ ){
                    if(bridgemen[k].Position == i)continue ;
                    if(dists[bridgemen[k].Position][i] <= 50){
                        int j = 0 ;
                        for ( ; turn < 999 ; turn ++ ) {
                            if(j%2==0)cout << "UNPACK " << k << " " << i << endl ;
                            else      cout << "PACK "   << k << " " << bridgemen[k].Position << endl ;
                            cout << flush ;
                            skip() ;
                            j ++ ;
                        }
                        return 0;
                    }
                }
            }
            return 0;
        } 
    }



    return 0;
}
