using System;
using System.Collections.Generic;
using System.Linq;

class BridgeRunners
{
    static int g_seed = 777778;
    static int Rand(int mod)
    {
        g_seed = (214013 * g_seed + 2531011);
        return ((g_seed >> 16) & 0x7FFF) % mod;
    }

    static void Main(string[] args)
    {
        int N = int.Parse(Console.ReadLine());
        int B = int.Parse(Console.ReadLine());
        int O = int.Parse(Console.ReadLine());

        int[,] dists = new int[N, N];
        bool[,] connected = new bool[N, N];
        for (int i = 0; i < N; i++)
        {
            int[] line = Console.ReadLine().Split().Select(int.Parse).ToArray();
            for (int j = 0; j < N; j++) dists[i, j] = line[j];
        }

        List<Bridgeman> bridgemen = Enumerable.Range(0, B).Select(i => new Bridgeman { ID = i }).ToList();
        for (int turn = 1; turn <= 1000; turn++)
        {
            int elapsedTime = int.Parse(Console.ReadLine());
            for (int i = 0; i < B; i++)
            {
                int[] line = Console.ReadLine().Split().Select(int.Parse).ToArray();
                bridgemen[i].Position = line[0];
                bridgemen[i].Bricks = line[1];
                bridgemen[i].Target = line[2];
            }
            List<Order> orders = new List<Order>();
            for (int i = 0; i < O; i++)
            {
                int[] line = Console.ReadLine().Split().Select(int.Parse).ToArray();
                Order o = new Order { From = line[0], To = line[1] };
                orders.Add(o);
            }

            List<string> output = new List<string>();

            // Track which bridgemen are used for messages
            HashSet<int> usedBridgemen = new HashSet<int>();

            // First priority: Send any messages if possible
            foreach (Bridgeman b in bridgemen)
            {
                if (b.BridgeFrom == -1) // Available for message delivery
                {
                    foreach (var order in orders)
                    {
                        if (b.Position == order.From)
                        {
                            // Try to send this message
                            output.Add("MSG " + b.ID + " " + order.To);
                            usedBridgemen.Add(b.ID);
                            break; // Only one message per bridgeman per turn
                        }
                    }
                }
            }

            // Second priority: Regular bridge operations for unused bridgemen
            foreach (Bridgeman b in bridgemen)
            {
                if (usedBridgemen.Contains(b.ID)) continue; // Skip bridgemen already used for messages
                if (b.BridgeFrom == -1) // unpack
                {
                    List<int> targets = Enumerable.Range(0, N).Where(t => t != b.Position && !connected[b.Position, t] && dists[b.Position, t] <= b.Bricks).ToList();
                    if (targets.Count > 0)
                    {
                        // Smart target selection: prioritize order locations
                        HashSet<int> orderLocations = new HashSet<int>();
                        foreach (var order in orders)
                        {
                            orderLocations.Add(order.From);
                            orderLocations.Add(order.To);
                        }

                        // Find targets that are order locations
                        var orderTargets = targets.Where(t => orderLocations.Contains(t)).ToList();

                        int t;
                        if (orderTargets.Count > 0)
                        {
                            // Prefer order locations
                            t = orderTargets[Rand(orderTargets.Count)];
                        }
                        else
                        {
                            // Fall back to random if no order locations available
                            t = targets[Rand(targets.Count)];
                        }

                        output.Add("UNPACK " + b.ID + " " + t);
                        b.BridgeFrom = b.Position;
                        b.BridgeTo = t;
                        connected[b.BridgeFrom, b.BridgeTo] = true;
                        connected[b.BridgeTo, b.BridgeFrom] = true;
                    }
                }
                else if (b.BridgeFrom == b.Position) // MOVE
                {
                    output.Add("MOVE " + b.ID + " " + b.BridgeTo);
                }
                else // PACK
                {
                    output.Add("PACK " + b.ID + " " + b.BridgeFrom);
                    connected[b.BridgeFrom, b.BridgeTo] = false;
                    connected[b.BridgeTo, b.BridgeFrom] = false;
                    b.BridgeFrom = -1;
                    b.BridgeTo = -1;
                }
            }

            Console.WriteLine(string.Join(" | ", output));
        }
    }
}

class Bridgeman
{
    public int ID;
    public int Position;
    public int Target;
    public int Bricks;

    public int BridgeFrom = -1;
    public int BridgeTo = -1;
}

class Order
{
    public int From;
    public int To;
}