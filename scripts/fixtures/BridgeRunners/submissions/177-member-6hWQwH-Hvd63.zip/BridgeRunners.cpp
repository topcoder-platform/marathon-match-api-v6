#include <bits/stdc++.h>

using namespace std;

const int MAXN = 85;
const int INF = 1000000000;

int N, B, O, C;
int dists[MAXN][MAXN];
bool built[MAXN][MAXN];
int hop_dist[MAXN][MAXN]; // precomputed min hops in leap graph

class Bridgeman {
public:
    int ID;
    int Position;
    int Target;
    int Bricks;
    int BridgeFrom = -1;
    int BridgeTo = -1;
    int Goal = -1; // added for heuristic
};

struct Order {
    int From;
    int To;
};

int g_seed = 777778;
int Rand(int mod) {
    g_seed = (214013 * g_seed + 2531011);
    return ((g_seed >> 16) & 0x7FFF) % mod;
}

// BFS for min hop path, return next island or -1 if no path
int get_next_on_path(int start, int end_) {
    vector<int> parent(N, -1);
    vector<bool> visited(N, false);
    queue<int> q;
    q.push(start);
    visited[start] = true;
    while (!q.empty()) {
        int cur = q.front();
        q.pop();
        if (cur == end_) break;
        for (int j = 0; j < N; ++j) {
            if (j != cur && dists[cur][j] > 0 && dists[cur][j] <= C && !visited[j]) {
                q.push(j);
                visited[j] = true;
                parent[j] = cur;
            }
        }
    }
    if (!visited[end_]) return -1;
    // reconstruct next
    int cur = end_;
    while (parent[cur] != start && parent[cur] != -1) {
        cur = parent[cur];
    }
    return cur;
}

int main() {
    cin >> N >> B >> O;

    for (int i = 0; i < N; ++i) {
        for (int j = 0; j < N; ++j) {
            cin >> dists[i][j];
            built[i][j] = false;
        }
    }

    Bridgeman bridgemen[B];
    for (int i = 0; i < B; ++i) {
        bridgemen[i].ID = i;
    }

    // First turn to get C
    int elapsedTime;
    cin >> elapsedTime;
    for (int i = 0; i < B; ++i) {
        cin >> bridgemen[i].Position >> bridgemen[i].Bricks >> bridgemen[i].Target;
    }
    C = bridgemen[0].Bricks; // assume same

    vector<Order> orders(O);
    for (int i = 0; i < O; ++i) {
        cin >> orders[i].From >> orders[i].To;
    }

    // Precompute hop_dist with Floyd-Warshall
    for (int i = 0; i < N; ++i) {
        for (int j = 0; j < N; ++j) {
            if (i == j) hop_dist[i][j] = 0;
            else if (dists[i][j] > 0 && dists[i][j] <= C) hop_dist[i][j] = 1;
            else hop_dist[i][j] = INF;
        }
    }
    for (int k = 0; k < N; ++k) {
        for (int i = 0; i < N; ++i) {
            for (int j = 0; j < N; ++j) {
                if (hop_dist[i][k] < INF && hop_dist[k][j] < INF) {
                    hop_dist[i][j] = min(hop_dist[i][j], hop_dist[i][k] + hop_dist[k][j]);
                }
            }
        }
    }

    // Process for first turn
    {
        // Reset goals for free bridgemen
        vector<bool> order_assigned(O, false);
        vector<Bridgeman*> free_b;
        for (int i = 0; i < B; ++i) {
            if (bridgemen[i].Target != -1) {
                bridgemen[i].Goal = bridgemen[i].Target;
            } else {
                bridgemen[i].Goal = -1;
                free_b.push_back(&bridgemen[i]);
            }
        }

        // Assign orders to free bridgemen
        for (auto b : free_b) {
            int best_o = -1;
            int best_cost = INF;
            for (int o = 0; o < O; ++o) {
                if (order_assigned[o]) continue;
                int o_from = orders[o].From;
                int o_to = orders[o].To;
                if (hop_dist[b->Position][o_from] < INF && hop_dist[o_from][o_to] < INF) {
                    int cost = hop_dist[b->Position][o_from] + hop_dist[o_from][o_to];
                    if (cost < best_cost) {
                        best_cost = cost;
                        best_o = o;
                    }
                }
            }
            if (best_o != -1) {
                order_assigned[best_o] = true;
                b->Goal = orders[best_o].From; // go to orig first
            }
        }

        // Collect output actions
        vector<string> output;
        for (int i = 0; i < B; ++i) {
            auto& b = bridgemen[i];
            if (b.Goal == -1 || b.Position == b.Goal) continue; // no action

            int next_t = get_next_on_path(b.Position, b.Goal);
            if (next_t == -1) continue; // impossible, skip
            if (next_t == b.Position) continue; // safeguard

            if (b.BridgeTo == -1) {
                // Start leap or move if exists
                int from = b.Position;
                int to = next_t;
                if (built[from][to]) {
                    // MOVE directly
                    output.push_back("MOVE " + to_string(b.ID) + " " + to_string(to));
                    // no state change
                } else {
                    // UNPACK
                    if (dists[from][to] > b.Bricks) continue; // can't
                    output.push_back("UNPACK " + to_string(b.ID) + " " + to_string(to));
                    b.BridgeFrom = from;
                    b.BridgeTo = to;
                    built[from][to] = true;
                    built[to][from] = true;
                }
            } else if (b.Position == b.BridgeFrom) {
                // Move
                output.push_back("MOVE " + to_string(b.ID) + " " + to_string(b.BridgeTo));
            } else {
                // Pack
                output.push_back("PACK " + to_string(b.ID) + " " + to_string(b.BridgeFrom));
                built[b.BridgeFrom][b.BridgeTo] = false;
                built[b.BridgeTo][b.BridgeFrom] = false;
                b.BridgeFrom = -1;
                b.BridgeTo = -1;
            }
        }

        // Output
        for (size_t i = 0; i < output.size(); ++i) {
            cout << output[i];
            if (i < output.size() - 1) cout << "|";
        }
        cout << endl;
    }

    // Main loop for remaining turns
    for (int turn = 2; turn <= 1000; turn++) {
        cin >> elapsedTime;
        for (int i = 0; i < B; ++i) {
            cin >> bridgemen[i].Position >> bridgemen[i].Bricks >> bridgemen[i].Target;
        }
        orders.resize(O);
        for (int i = 0; i < O; ++i) {
            cin >> orders[i].From >> orders[i].To;
        }

        // Reset goals for free bridgemen
        vector<bool> order_assigned(O, false);
        vector<Bridgeman*> free_b;
        for (int i = 0; i < B; ++i) {
            if (bridgemen[i].Target != -1) {
                bridgemen[i].Goal = bridgemen[i].Target;
            } else {
                bridgemen[i].Goal = -1;
                free_b.push_back(&bridgemen[i]);
            }
        }

        // Assign orders to free bridgemen
        for (auto b : free_b) {
            int best_o = -1;
            int best_cost = INF;
            for (int o = 0; o < O; ++o) {
                if (order_assigned[o]) continue;
                int o_from = orders[o].From;
                int o_to = orders[o].To;
                if (hop_dist[b->Position][o_from] < INF && hop_dist[o_from][o_to] < INF) {
                    int cost = hop_dist[b->Position][o_from] + hop_dist[o_from][o_to];
                    if (cost < best_cost) {
                        best_cost = cost;
                        best_o = o;
                    }
                }
            }
            if (best_o != -1) {
                order_assigned[best_o] = true;
                b->Goal = orders[best_o].From; // go to orig first
            }
        }

        // Collect output actions
        vector<string> output;
        for (int i = 0; i < B; ++i) {
            auto& b = bridgemen[i];
            if (b.Goal == -1 || b.Position == b.Goal) continue; // no action

            int next_t = get_next_on_path(b.Position, b.Goal);
            if (next_t == -1) continue; // impossible, skip
            if (next_t == b.Position) continue; // safeguard

            if (b.BridgeTo == -1) {
                // Start leap or move if exists
                int from = b.Position;
                int to = next_t;
                if (built[from][to]) {
                    // MOVE directly
                    output.push_back("MOVE " + to_string(b.ID) + " " + to_string(to));
                    // no state change
                } else {
                    // UNPACK
                    if (dists[from][to] > b.Bricks) continue; // can't
                    output.push_back("UNPACK " + to_string(b.ID) + " " + to_string(to));
                    b.BridgeFrom = from;
                    b.BridgeTo = to;
                    built[from][to] = true;
                    built[to][from] = true;
                }
            } else if (b.Position == b.BridgeFrom) {
                // Move
                output.push_back("MOVE " + to_string(b.ID) + " " + to_string(b.BridgeTo));
            } else {
                // Pack
                output.push_back("PACK " + to_string(b.ID) + " " + to_string(b.BridgeFrom));
                built[b.BridgeFrom][b.BridgeTo] = false;
                built[b.BridgeTo][b.BridgeFrom] = false;
                b.BridgeFrom = -1;
                b.BridgeTo = -1;
            }
        }

        // Output
        for (size_t i = 0; i < output.size(); ++i) {
            cout << output[i];
            if (i < output.size() - 1) cout << "|";
        }
        cout << endl;
    }

    return 0;
}