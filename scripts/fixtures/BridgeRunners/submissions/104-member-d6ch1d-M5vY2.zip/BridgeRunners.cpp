#include <algorithm>
#include <iostream>
#include <limits>
#include <stdexcept>
#include <vector>
#include <chrono>
#include <random>
#include <array>
// #include <numeric>
#include <cassert>

using namespace std;
using namespace chrono;

// #define DBG

#ifdef DBG
#define DEBUG(x) x
#else
#define DEBUG(x)
#endif

// both messages and bridge lengths are resources that need to be transported
// message destination is clear
// bridge destination depends on where they most efficiently let men progress
// don't want to keep bridges alive forever, or too early
// so should depend on where men want to walk in the next N turns
// bridges are limited, so should try to combine several men's paths, even if it is a bit detour for some
// should also foresee when a mandatory link requires >50 length, to already collect that length
// more than 60 is never strictly necessary, but can provide shortcuts
// for each man and message destination, should check all reasonable paths
// find mandatory and alternative paths, maybe M shortest?
//
// above is nice, but too complex to write in 3 days
// can encourage efficiency by just giving bonus to placing bridge where someone else may use it too in this or next two turns
//
// if men leave their bridge behind, they will always get stuck at some point
// so bridges need ownership, at most two owners per bridge, with length owned
// new action can be for men to transfer bridge length, via (team)build and teamcollect
// men can lay bridge in multiple directions, but can not move away from bridge (partially) owned
//
// men with message can check minimum length needed to independently make path there
// if insufficient, need to find transfer
//
// all steps on path of man that has sufficient length can be considered 'to be build'
// others don't need to cover that bridge

// find shortest route with minimum required bridge length needed to independently complete route
// check this for all men
// select one man that is closest to its requirement, but fitting, and mark his route as 'planned'
// then recheck min max route for all other men, taking the planned sections as 0 requirement
// repeat until no more fitting can be found
//
// the remaining ones that have minimum below max capacity, need transfer from other man

// find for all carrying men the shortest route that fits with currently owned length
// if multiple found, take the route with least needed length
// remaining length becomes this man's slack
// these men can continue towards destination
//
// if carrying, but no route found, one or more steps must be beyond man's length
// find the route with minimum requirement
// if it is within max capacity, can try to find man to transfer his slack
// if cannot find, or beyond max capacity, can find other man taking same step in opposite direction, and align
//
// if not carrying message, and not busy with transferring, check distance to all orders fitting current length and divide up the orders
// 

constexpr int MAX_TURNS = 1000;
constexpr int MAX_ISLANDS = 80;
constexpr int MAX_MEN = 20;
constexpr int MAX_ORDERS = 10;
constexpr int MAX_CAPACITY = 60;
constexpr int MAX_BRIDGE_LENGTH = 2 * MAX_CAPACITY;

constexpr int DELIVERY_CF = 100;
constexpr int PICKUP_CF = 20;
constexpr double PICKUP_STEPS_CONSTANT = 20.0;

#define BE(x) x.begin(), x.end()
#define FORI(v,b,e) for( int v = b; v < e; v++ )

// fast random

uint32_t xorshift32_state = [](){ return random_device{}(); }();

uint32_t xorshift32()
{
    xorshift32_state ^= xorshift32_state << 13;
    xorshift32_state ^= xorshift32_state >> 17;
    xorshift32_state ^= xorshift32_state << 5;
    return xorshift32_state;
}

int get_random_int_between_0_and_n_exclusive( int n )
{
    return ( uint64_t( xorshift32() ) * uint64_t( n ) ) >> 32;
}

// time checking

struct EfficientTimeCheck
{
    constexpr static unsigned int INTERVAL = 15;

    const steady_clock::time_point limit;
    steady_clock::time_point last_now;
    unsigned int it = 0;

    EfficientTimeCheck( steady_clock::time_point _limit ) :
        limit( _limit ),
        last_now( steady_clock::now() )
    {}

    bool is_finished()
    {
        it++;
        if( ( it & INTERVAL ) == 0 )
        {
            last_now = steady_clock::now();
            return last_now > limit;
        }
        return false;
    }

    auto get_time_left() const
    {
        return limit - last_now;
    }
};

// stack vector

template< typename TYPE, size_t SIZE >
class StackVector
{
    array< TYPE, SIZE > data{};
    size_t sz = 0;

public:

    void set_from_vector( const vector<TYPE>& v )
    {
        sz = v.size();
        for( unsigned int i = 0; i < v.size(); i++ )
        {
            data[i] = v[i];
        } 
    }
    void clear() { sz = 0; }
    void push_back( TYPE&& v ) { data[sz++] = v; }
    void push_back( const TYPE& v ) { data[sz++] = v; }
    TYPE& operator[]( int idx ) { return data[idx]; }
    const TYPE& operator[]( int idx ) const { return data[idx]; }
    TYPE& back() { return data[sz-1]; }
    const TYPE& back() const { return data[sz-1]; }
    void pop_back() { sz--; }
    void resize( int s ) { sz = s; }
    int size() const { return sz; }
    bool empty() const { return sz == 0; }
    typename array< TYPE, SIZE >::iterator begin() { return data.begin(); }
    typename array< TYPE, SIZE >::const_iterator begin() const { return data.begin(); }
    typename array< TYPE, SIZE >::iterator end() { return data.begin()+sz; }
    typename array< TYPE, SIZE >::const_iterator end() const { return data.begin()+sz; }
    void erase( const typename array< TYPE, SIZE >::iterator& from, const typename array< TYPE, SIZE >::iterator& )
    {
        sz = distance( begin(), from );
    }
    bool operator==( const StackVector< TYPE, SIZE >& other )
    {
        if( sz != other.sz ) return false;
        for( unsigned int i = 0; i < sz; i++ ) if( data[i] != other.data[i] ) return false;
        return true;
    }
};

// MARK: state

struct Order
{
    int org;
    int dst;
};

struct Route
{
    int req;
    StackVector<int,MAX_ISLANDS> nodes;
};

enum class PlanType { WAIT, INDEP_ROUTE, INDEP_PICKUP };

struct Plan
{
    PlanType type = PlanType::WAIT;
    Route route;
};

struct Man
{
    int island;
    int carried = 50;
    int owned = 50;
    Order message = { -1, -1 };
    Plan plan;
};

// moves are done in sequence:
// team builds
// builds
// moves
// collects
// team collects

enum class MoveType { WAIT, MULTIBUILD, BUILD, MOVE, COLLECT, MULTICOLLECT };

struct Move
{
    MoveType type;
    int to;
    int with;
};

using Moves = vector<Move>;

struct DistIsl
{
    int dist;
    int island;
};

struct Owner
{
    int idx = -1;
    int length = 0;
};

struct Bridge
{
    // array<Owner,2> owner{};
    Owner owner{};
    bool is = false;
};

class State
{
public:

    array< array< int, MAX_ISLANDS >, MAX_ISLANDS > distance{};
    // array< array< int, MAX_ISLANDS >, MAX_ISLANDS > steps{};
    // array< DistIsl, MAX_ISLANDS > order_steps{};

    array< array< Bridge, MAX_ISLANDS >, MAX_ISLANDS > bridges{};
    array< Man, MAX_MEN > men{};
    int turn;
    int nr_delivered = 0;

    array< Order, MAX_ORDERS > orders{};
    int nr_islands;
    int nr_men;
    int nr_orders;
    int elapsed_time_ms;

    void read_init_input()
    {
        cin >> nr_islands >> nr_men >> nr_orders;
        FORI( f, 0, nr_islands )
        {
            FORI( t, 0, nr_islands )
            {
                cin >> distance[f][t];
            }            
        }

        // calculate_step_distances();
    }

    // the way picking up orders works:
    // - make all turn moves
    // - check if any men reached message destination -> deliver
    // - check if any men are on order origin islands -> pickup
    void read_turn_input( int _turn )
    {
        cin >> elapsed_time_ms;
        FORI( m, 0, nr_men )
        {
            int island, carried, dest;
            cin >> island >> carried >> dest;

            // verify that this matches expected state
            
            if( _turn > 0 )
                assert( island == men[m].island );
            else
                men[m].island = island;

            if( carried != men[m].carried )
            {
                DEBUG( cerr << m << " " << carried << " " << men[m].carried << endl; )
                throw runtime_error("Length mismatch");
            }
            if( men[m].message.dst != -1 && men[m].message.dst != dest )
            {
                DEBUG( cerr << m << " " << dest << " " << men[m].message.dst << endl; )
                throw runtime_error("Destination mismatch");
            }

            // note: if we just delivered in this turn, dst will have been set to -1 by apply_turn_moves
            if( men[m].message.dst == -1 && dest > -1 )
            {
                men[m].message.dst = dest;
                men[m].message.org = island;
            }
        }
        FORI( o, 0, nr_orders )
        {
            cin >> orders[o].org >> orders[o].dst;
        }
        turn = _turn;

        // calculate_order_distances();
    }

    // referee doesn't give bridge information
    void write_and_apply_moves( const Moves& moves )
    {
        DEBUG( cerr << "Build:   "; )
        FORI( m, 0, nr_men )
        {
            // if( moves[m].type == MoveType::BUILD && is_valid_build( moves[m], m ) )
            if( moves[m].type == MoveType::BUILD )
            {
                cout << "UNPACK " << m << " " << moves[m].to << "|";
                DEBUG( cerr << m << " (" << men[m].island << "->" << moves[m].to << ")   "; )
                // perform_build( m, moves[m] );
            }
        }
        DEBUG( cerr << endl << "Move:    "; )
        FORI( m, 0, nr_men )
        {
            // if( moves[m].type == MoveType::MOVE && is_valid_move( moves[m], m ) )
            if( moves[m].type == MoveType::MOVE )
            {
                cout << "MOVE " << m << " " << moves[m].to << "|";
                DEBUG( cerr << m << " (" << men[m].island << "->" << moves[m].to << ")   "; )
                // perform_step( m, moves[m] );
            }
        }
        DEBUG( cerr << endl << "Collect: "; )
        FORI( m, 0, nr_men )
        {
            // if( moves[m].type == MoveType::COLLECT && is_valid_collect( moves[m], m ) )
            if( moves[m].type == MoveType::COLLECT )
            {
                cout << "PACK " << m << " " << moves[m].to << "|";
                DEBUG( cerr << m << " (" << men[m].island << "->" << moves[m].to << ")   "; )
                // perform_collect( m, moves[m] );
            }
        }
        DEBUG( cerr << endl; )
        cout << "MSG done" << endl;
    }

    bool is_finished() const
    {
        return turn >= MAX_TURNS;
    }

    // MARK: sim

    void perform_builds( const Moves& moves )
    {
        FORI( m, 0, nr_men )
        {
            if( moves[m].type == MoveType::BUILD && is_valid_build( moves[m], m ) )
            {
                perform_build( m, moves[m] );
            }
        }
    }

    inline bool is_valid_build( const Move& mv, int man ) const
    {
        return !bridges[ men[man].island ][ mv.to ].is && distance[ men[man].island ][ mv.to ] <= men[man].carried;
    }

    void perform_build( int m, const Move& move )
    {
        bridges[ men[m].island ][ move.to ].is = true;
        bridges[ men[m].island ][ move.to ].owner.idx = m;
        bridges[ men[m].island ][ move.to ].owner.length = distance[ men[m].island ][ move.to ];

        bridges[ move.to ][ men[m].island ].is = true;
        bridges[ move.to ][ men[m].island ].owner.idx = m;
        bridges[ move.to ][ men[m].island ].owner.length = distance[ men[m].island ][ move.to ];

        men[m].carried -= distance[ men[m].island ][ move.to ];
    }

    void perform_steps( const Moves& moves )
    {
        FORI( m, 0, nr_men )
        {
            if( moves[m].type == MoveType::MOVE && is_valid_move( moves[m], m ) )
            {
                perform_step( m, moves[m] );
            }
        }
    }

    inline bool is_valid_move( const Move& mv, int man ) const
    {
        return bridges[ men[man].island ][ mv.to ].is;
    }

    void perform_step( int m, const Move& move )
    {
        men[m].island = move.to;

        // check message delivery (pickup will be handled by read_turn_input)
        // NOTE: for multi-turn SA, we'll need to sim pickup too

        if( move.to == men[m].message.dst )
        {
            nr_delivered++;
            men[m].message = { -1, -1 };
        }
    }

    void perform_collects( const Moves& moves )
    {
        FORI( m, 0, nr_men )
        {
            if( moves[m].type == MoveType::COLLECT && is_valid_collect( moves[m], m ) )
            {
                perform_collect( m, moves[m] );
            }
        }
    }

    inline bool is_valid_collect( const Move& mv, int man ) const
    {
        return bridges[ men[man].island ][ mv.to ].is && distance[ men[man].island ][ mv.to ] + men[man].carried <= MAX_CAPACITY;
    }

    void perform_collect( int m, const Move& move )
    {
        bridges[ men[m].island ][ move.to ].is = false;
        bridges[ men[m].island ][ move.to ].owner = { -1, 0 };

        bridges[ move.to ][ men[m].island ].is = false;
        bridges[ move.to ][ men[m].island ].owner = { -1, 0 };

        men[m].carried += distance[ men[m].island ][ move.to ];
    }

    // MARK: distance precomp

    // calculate distances in the graph in terms of the number of steps required
    // void calculate_step_distances()
    // {
    //     for( auto& row : steps )
    //     {
    //         for( int& cell : row )
    //         {
    //             cell = numeric_limits<int>::max();
    //         }
    //     }

    //     FORI( i, 0, nr_islands )
    //     {
    //         calculate_step_distance_from_island( i );
    //     }

    //     DEBUG(
    //     FORI( i, 0, nr_islands )
    //     {
    //         FORI( j, 0, nr_islands )
    //         {
    //             cerr << steps[i][j] << "  ";
    //         }
    //         cerr << endl;
    //     })
    // }

    // steps are x3 because in general it requires build, move, collect
    // void calculate_step_distance_from_island( int isl )
    // {
    //     vector<int> frontier{};
    //     frontier.reserve( MAX_ISLANDS );
    //     vector<int> next{};
    //     next.reserve( MAX_ISLANDS );

    //     frontier.push_back( isl );
    //     steps[isl][isl] = 0;

    //     int st = 0;
    //     while( !frontier.empty() )
    //     {
    //         st++;
    //         next.clear();

    //         for( int f : frontier )
    //         {
    //             FORI( i, 0, nr_islands )
    //             {
    //                 if( distance[f][i] <= MAX_CAPACITY && st < steps[isl][i] )
    //                 {
    //                     next.push_back(i);
    //                     steps[isl][i] = st;
    //                 }
    //             }
    //         }

    //         swap( frontier, next );
    //     }
    // }

    // for each island, distance to closest open order, and island of that order
    // void calculate_order_distances()
    // {
    //     FORI( i, 0, nr_islands )
    //     {
    //         order_steps[i] = { numeric_limits<int>::max(), -1 };
    //     }

    //     FORI( o, 0, nr_orders )
    //     {
    //         FORI( i, 0, nr_islands )
    //         {
    //             if( steps[ orders[o].org ][i] < order_steps[i].dist )
    //             {
    //                 order_steps[i].dist = steps[ orders[o].org ][i];
    //                 order_steps[i].island = orders[o].org;
    //             }
    //         }
    //     }

    //     DEBUG(
    //     FORI( i, 0, nr_islands )
    //     {
    //         cerr << order_steps[i].dist << " - " << order_steps[i].island << "   ";
    //     }
    //     cerr << endl; )
    // }

    // MARK: analyse

    Moves analyse_delivery_routes()
    {
        if( turn == 0 )
        {
            return Moves( nr_men );
        }

        auto start = steady_clock::now();

        FORI( m, 0, nr_men )
        {
            men[m].plan = {};
        }

        find_independent_deliveries();
        find_independent_pickups();

        auto moves = convert_plan_to_moves();

        cerr << duration_cast<microseconds>( steady_clock::now() - start ).count() << "us" << endl;

        return moves;
    }

    Moves convert_plan_to_moves()
    {
        Moves moves( nr_men );

        convert_all_builds( moves );
        convert_all_steps( moves );
        convert_all_collects( moves );

        return moves;
    }

    void convert_all_builds( Moves& moves )
    {
        FORI( m, 0, nr_men )
        {
            if( men[m].plan.type == PlanType::INDEP_ROUTE || men[m].plan.type == PlanType::INDEP_PICKUP )
            {
                if( men[m].plan.route.nodes.size() > 1 )
                {
                    int next_island = men[m].plan.route.nodes[1];

                    if( !bridges[ men[m].island ][ next_island ].is )
                    {
                        if( men[m].carried >= distance[ men[m].island ][ next_island ] )
                        {
                            moves[m].type = MoveType::BUILD;
                            moves[m].to = next_island;

                            if( !is_valid_build( moves[m], m ) )
                            {
                                cerr << "shit build" << endl;
                            }

                            perform_build( m, moves[m] );
                            men[m].plan.type = PlanType::WAIT;
                        }
                    }
                }
            }
        }
    }

    void convert_all_steps( Moves& moves )
    {
        FORI( m, 0, nr_men )
        {
            if( men[m].plan.type == PlanType::INDEP_ROUTE || men[m].plan.type == PlanType::INDEP_PICKUP )
            {
                if( men[m].plan.route.nodes.size() > 1 )
                {
                    int next_island = men[m].plan.route.nodes[1];

                    vector<int> owned;
                    FORI( i, 0, nr_islands )
                    {
                        if( bridges[ men[m].island ][i].is && i != next_island && bridges[ men[m].island ][i].owner.idx == m )
                        {
                            owned.push_back(i);
                        }
                    }

                    if( bridges[ men[m].island ][ next_island ].is )
                    {
                        if( owned.empty() )
                        {
                            moves[m].type = MoveType::MOVE;
                            moves[m].to = next_island;

                            if( !is_valid_move( moves[m], m ) )
                            {
                                cerr << "shit move" << endl;
                            }

                            perform_step( m, moves[m] );
                            men[m].plan.type = PlanType::WAIT;
                        }
                    }
                }
            }
        }
    }

    void convert_all_collects( Moves& moves )
    {
        FORI( m, 0, nr_men )
        {
            if( men[m].plan.type == PlanType::INDEP_ROUTE || men[m].plan.type == PlanType::INDEP_PICKUP )
            {
                if( men[m].plan.route.nodes.size() > 1 )
                {
                    int next_island = men[m].plan.route.nodes[1];

                    vector<int> owned;
                    FORI( i, 0, nr_islands )
                    {
                        if( bridges[ men[m].island ][i].is && i != next_island && bridges[ men[m].island ][i].owner.idx == m )
                        {
                            owned.push_back(i);
                        }
                    }

                    if( bridges[ men[m].island ][ next_island ].is )
                    {
                        if( !owned.empty() )
                        {
                            moves[m].type = MoveType::COLLECT;
                            moves[m].to = owned.front();

                            if( !is_valid_collect( moves[m], m ) )
                            {
                                cerr << "shit collect a" << endl;
                            }

                            perform_collect( m, moves[m] );
                            men[m].plan.type = PlanType::WAIT;
                        }
                    }
                    else
                    {
                        if( men[m].carried < distance[ men[m].island ][ next_island ] )
                        {
                            moves[m].type = MoveType::COLLECT;
                            moves[m].to = owned.front();

                            if( !is_valid_collect( moves[m], m ) )
                            {
                                cerr << "shit collect b" << endl;
                            }

                            perform_collect( m, moves[m] );
                            men[m].plan.type = PlanType::WAIT;
                        }
                    }
                }
            }
        }
    }

    void find_independent_deliveries()
    {
        FORI( m, 0, nr_men )
        {
            if( men[m].message.dst > -1 )
            {
                auto route = find_shortest_fitting_route( m, men[m].message.dst );
                if( !route.nodes.empty() )
                {
                    cerr << "Man " << m << ": route found, with length " << route.nodes.size() - 1 << " and slack " << men[m].owned - route.req << endl;
                    men[m].plan.type = PlanType::INDEP_ROUTE;
                    men[m].plan.route = route;
                }
                else
                {
                    cerr << "Man " << m << ": no route" << endl;
                }
            }
            else
            {
                cerr << "Man " << m << ": skip" << endl;
            }
        }
    }

    void find_independent_pickups()
    {
        vector<vector<int>> man_order_dist( nr_men, vector<int>( nr_orders, numeric_limits<int>::max() ) );
        FORI( m, 0, nr_men )
        {
            if( men[m].message.dst == -1 )
            {
                man_order_dist[m] = find_fitting_distances_to_all_orders( m );
            }
        }

        while( assign_greedy( man_order_dist ) )
        {
            // cerr << "try" << endl;
        }
        // cerr << "done" << endl;
    }

    bool assign_greedy( vector<vector<int>>& man_order_dist )
    {
        int closest = numeric_limits<int>::max();
        int man = -1;
        int order = -1;
        FORI( m, 0, nr_men )
        {
            FORI( o, 0, nr_orders )
            {
                if( man_order_dist[m][o] < closest )
                {
                    closest = man_order_dist[m][o];
                    man = m;
                    order = o;
                }
            }
        }

        if( man == -1 )
            return false;

        FORI( m, 0, nr_men )
        {
            man_order_dist[m][ order ] = numeric_limits<int>::max();
        }
        FORI( o, 0, nr_orders )
        {
            man_order_dist[ man ][o] = numeric_limits<int>::max();
        }

        men[man].plan.type = PlanType::INDEP_PICKUP;
        men[man].plan.route = find_shortest_fitting_route( man, orders[order].org );

        cerr << "Man " << man << ": pickup found, with length " << men[man].plan.route.nodes.size() - 1 << " and slack " << men[man].owned - men[man].plan.route.req << endl;

        return true;
    }

    struct ReqStep
    {
        int req;
        int steps;
    };

    Route find_shortest_fitting_route( int m, int tgt )
    {
        array<int,MAX_ISLANDS> req{};
        FORI( i, 0, nr_islands ) req[i] = 1000;
        req[ men[m].island ] = 0;

        vector<Route> final;
        final.reserve( 100 );

        vector<Route> routes;
        routes.reserve( 1000 );
        routes.push_back( {} );
        routes.back().req = 0;
        routes.back().nodes.push_back( men[m].island );

        vector<Route> next;
        next.reserve( 1000 );

        bool done = false;
        bool change = true;
        while( !done && change )
        {
            change = false;
            next.clear();

            for( auto rt : routes )
            {
                if( rt.nodes.back() == tgt )
                {
                    final.push_back( rt );
                    done = true;
                }
                else
                {
                    FORI( i, 0, nr_islands )
                    {
                        if( i != rt.nodes.back() && distance[ rt.nodes.back() ][i] <= men[m].owned )
                        {
                            int new_req = max( rt.req, distance[ rt.nodes.back() ][i] );
                            if( new_req < req[i] )
                            {
                                req[i] = new_req;
                                next.push_back( rt );
                                next.back().nodes.push_back(i);
                                next.back().req = new_req;
                                change = true;
                            }
                        }
                    }
                }
            } 

            swap( routes, next );
        }

        // DEBUG( cerr << m << " " << final.size() << endl;
        // FORI( r, 0, final.size() )
        // {
        //     cerr << final[r].req << ": ";
        //     FORI( n, 0, final[r].nodes.size() )
        //     {
        //         cerr << final[r].nodes[n] << " ";
        //     }
        //     cerr << endl;
        // } )

        if( final.empty() )
        {
            return {};
        }
        else
        {
            auto it = min_element( BE( final ), []( const auto& a, const auto& b ){ return a.req < b.req; } );
            return *it;
        }
    }

    vector<int> find_fitting_distances_to_all_orders( int m )
    {
        array<int,MAX_ISLANDS> dist{};
        fill_n( dist.begin(), nr_islands, numeric_limits<int>::max() );
        dist[ men[m].island ] = 0;

        vector<int> frontier;
        frontier.reserve( MAX_ISLANDS );
        frontier.push_back( men[m].island );

        vector<int> next;
        next.reserve( MAX_ISLANDS );

        int st = 0;
        while( !frontier.empty() )
        {
            st++;
            next.clear();

            for( auto f : frontier )
            {
                FORI( i, 0, nr_islands )
                {
                    if( i != f && distance[f][i] <= men[m].owned && st < dist[i] )
                    {
                        dist[i] = st;
                        next.push_back( i );
                    }
                }
            } 

            swap( frontier, next );
        }

        vector<int> order_dist( nr_orders );
        DEBUG( cerr << m << " - "; )
        FORI( o, 0, nr_orders )
        {
            order_dist[o] = dist[ orders[o].org ];
            DEBUG( cerr << order_dist[o] << "  "; )
        }
        DEBUG( cerr << endl; )
        return order_dist;
    }

    // find route with minimum maximum required length
    // only keep a route to a certain node, if it reached there with lower req or lower steps than other routes before
    // TODO: should we also discard all routes that went through that node before? could be more efficient
    // void find_route_with_min_max_length( int m )
    // {
    //     vector<ReqStep> islands( nr_islands, { numeric_limits<int>::max(), numeric_limits<int>::max() } );
    //     vector<Route> routes;

    //     routes.reserve( 1000 );
    //     routes.push_back( { 0, { men[m].island } } );

    //     islands[ men[m].island ] = { 0, 0 };

    //     vector<Route> next;
    //     next.reserve( 1000 );

    //     bool change = true;
    //     while( change )
    //     {
    //         change = false;

    //         next.clear();

    //         for( auto rt : routes )
    //         {
    //             if( rt.nodes.back() == men[m].message.dst )
    //             {
    //                 if( rt.req == islands[ men[m].message.dst ].req )
    //                 {
    //                     next.push_back( rt );
    //                 }
    //             }
    //             else
    //             {
    //                 FORI( i, 0, nr_islands )
    //                 {
    //                     if( i != rt.nodes.back() && distance[ rt.nodes.back() ][i] <= MAX_BRIDGE_LENGTH )
    //                     {
    //                         int new_req = max( rt.req, distance[ rt.nodes.back() ][i] );
    //                         if( new_req < islands[i].req || rt.nodes.size() < islands[i].steps )
    //                         {
    //                             change = true;
    //                             islands[i].req = new_req;
    //                             islands[i].steps = rt.nodes.size();
    //                             next.push_back( rt );
    //                             next.back().nodes.push_back(i);
    //                             next.back().req = new_req;
    //                         }
    //                     }
    //                 }
    //             }
    //         } 

    //         swap( routes, next );
    //     }

    //     DEBUG( cerr << m << " " << routes.size() << endl; )
    //     FORI( r, 0, routes.size() )
    //     {
    //         cerr << routes[r].req << ": ";
    //         FORI( n, 0, routes[r].nodes.size() )
    //         {
    //             cerr << routes[r].nodes[n] << " ";
    //         }
    //         cerr << endl;
    //     }

    // }


};

// Moves get_moves( const State& state )
// {
//     return Moves( state.nr_men );
// }

int main()
{
    State state{};
    state.read_init_input();

    for( int t = 0; t < MAX_TURNS; t++ )
    {
        state.read_turn_input(t);

        auto moves = state.analyse_delivery_routes();

        // auto moves = get_moves( state );

        state.write_and_apply_moves( moves );
    }

    return 0;
}