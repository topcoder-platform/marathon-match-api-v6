#ifndef _DEBUG
#pragma GCC optimize "-O3,omit-frame-pointer,inline,unroll-all-loops,fast-math"
#pragma GCC target("tune=native")
#endif

#include<bits/stdc++.h>

#pragma GCC target("popcnt")

using namespace std;

typedef long long ll;
typedef unsigned int ui;
typedef unsigned long long ull;
typedef vector<int> vi;
typedef vector<vi> vvi;
typedef pair<int, int> ii;
typedef vector<ii> vii;
const int INF = 1e8;
const double EPS = 1e-9;
#define FOR(i,n) for (int i=0;i<(n);++i)
#define all(a) (a).begin(),(a).end()
#define SZ(a) (int)(a).size()
#define DATA(a) {cerr << "[DATA] " << #a << " = " << (a) << '\n';}
#define SIGN(x) ( ((x) > 0) - ((x) < 0)  )

#ifdef _DEBUG
#include "c:/contests/libs/debug.h"
#else
#define dbg(...) 0
#define NDEBUG
#endif


// PARAMETROS
constexpr int TLIMIT = 9500 ;


struct Clock {
public:
    Clock(const int _tlimit):tlimit(_tlimit){start();}

    bool salir() const { return elapsed() > tlimit; }

    void start() { init_t = clock_::now();}

    int resta()const{
        return max(0,tlimit - elapsed());
    }

    double frac_elapsed()const{
        return (double)elapsed()/tlimit;
    }

    double frac_resta()const{
        return (double)resta()/tlimit;
    }

    int elapsed() const {
        return chrono::duration_cast<chrono::milliseconds>(clock_::now() - init_t).count();
    }

private:
    typedef chrono::steady_clock clock_;
    chrono::time_point<clock_> init_t;
    const int tlimit;
};

struct XorShift {
    unsigned int x, y, z, w;
    double nL[65536];
    XorShift() { reset(time(0)); }
    XorShift(ull seed){reset(seed);}

    inline void reset(ull seed) {
        struct splitmix64_state {
            ull s;
            ull splitmix64() {
                ull result = (s += 0x9E3779B97f4A7C15);
                result = (result ^ (result >> 30)) * 0xBF58476D1CE4E5B9;
                result = (result ^ (result >> 27)) * 0x94D049BB133111EB;
                return result ^ (result >> 31);
            }
        };

        splitmix64_state s { seed };

        x = (ui)s.splitmix64();
        y = (ui)s.splitmix64();
        z = (ui)s.splitmix64();
        w = (ui)s.splitmix64();

        const double n = 1 / (double)(2 * 65536);
        for (int i = 0; i < 65536; i++) {
            nL[i] = log(((double)i / 65536) + n);
        }
    }


    unsigned int next() { unsigned int t=x^x<<11; x=y; y=z; z=w; return w=w^w>>19^t^t>>8; }
    double nextLog() { return nL[next()&0xFFFF]; }
    int nextInt(int m) { return ((ll)next() * m)>>32; } // [0, m)
    int nextInt(int min, int max) { return min+nextInt(max-min+1); } // [min, max]
    ull nextInt64(){return ((ull)next() << 32ll) | (ull)next(); }
    double nextDouble() { return (double)next()/(1LL<<32); } // [0, 1]

    template <typename T>
    inline void rough_shuffle(const int n,T& lv) {
        for (int i = n; i > 0; --i) {
            int id = nextInt(i);
            swap(lv[id], lv[i-1]);
        }
    }

    template <typename T>
    inline void rough_shuffle(T& lv) {
        int n = SZ(lv);
        rough_shuffle(n,lv);
    }
};

XorShift rng(0);

enum Action_type { MOVE, UNPACK, PACK, TEAMUNPACK1, TEAMPACK1, TEAMUNPACK2, TEAMPACK2,TEAMMOVE,WAIT,NONE };

constexpr string_view to_string(Action_type a){
    switch (a){
    case MOVE:       return "MOVE";
    case UNPACK:     return "UNPACK";
    case PACK:       return "PACK";
    case TEAMUNPACK1: return "TEAMUNPACK";
    case TEAMPACK1:   return "TEAMPACK";
    case TEAMUNPACK2: return "TEAMUNPACK2";
    case TEAMPACK2:   return "TEAMPACK2";
    case NONE:       return "NONE";
    }
    return "UNKNOWN";
}
std::ostream& operator<<(std::ostream& os, Action_type a){
    return os << to_string(a);
}
struct Action{
    Action_type type = Action_type::NONE;
    int dest=-1,ln=-1;
    Action(){}
    Action(Action_type t, int d, int l=-1):type(t),dest(d),ln(l){}
};


constexpr int MXN = 80;
constexpr int MXB = 20;
constexpr int MXO = 10;
constexpr int CAP = 60;
int N,B,O;

int dist[MXN][MXN];
int estimated_tourns[MXN][MXN];
int mn_tourns[MXN][MXN][62];
int min_mx_edge[MXN][MXN];
bool connected[MXN][MXN];
int elapsed;
bool blocked[MXN][MXN];
vi vecinos[MXN],vecinos_largos[MXN];
int component_of_island[MXN];
int ncomponents;
vi islands_in_comp[MXN];
vector<int> ord_actions;

void set_blocked(int i,int j,bool val){
    blocked[i][j] = blocked[j][i] = val;
}

void set_connected(int u,int v,bool val){
    assert(connected[u][v]==!val);
    connected[u][v] = connected[v][u] = val;
}

class Bridgeman{
public:
    int id;
    int Position;
    int Target;
    int Bricks;
    Action action;

    bool do_action();
    void write_action()const;
};
class Order {
public:
    int From;
    int To;
};

Bridgeman bridgeman[MXB];
Order order[MXO];

bool Bridgeman::do_action(){
    if (action.type == MOVE){
        Position = action.dest;
        return Position == Target;
    }
    else if (action.type == UNPACK){
        assert(action.dest != -1);
        Bricks -= dist[Position][action.dest];
        assert(Bricks >= 0);
        set_connected(Position,action.dest,true);
    }else if (action.type == PACK){
        Bricks += dist[Position][action.dest];
        assert(Bricks<=CAP);
        set_connected(Position,action.dest,false);
    }else if (action.type == TEAMUNPACK1){
        assert(action.dest != -1 && action.dest!=id);
        int island_dest = bridgeman[action.dest].Position;
        assert(action.ln + bridgeman[action.dest].Bricks >= dist[Position][island_dest]);
        Bricks -= action.ln;
        assert(Bricks >= 0);
        bridgeman[action.dest].Bricks -= dist[Position][island_dest] - action.ln;
        assert(bridgeman[action.dest].Bricks >= 0);
        set_connected(Position,island_dest,true);
    }else if (action.type == TEAMPACK1){
        assert(action.dest != -1 && action.dest!=id);
        int island_dest = bridgeman[action.dest].Position;
        Bricks += action.ln;
        assert(Bricks <= CAP);
        bridgeman[action.dest].Bricks += dist[Position][island_dest] - action.ln;
        assert(bridgeman[action.dest].Bricks <= CAP);
        set_connected(Position,island_dest,false);
    }
    return false;
}

void Bridgeman::write_action() const{
    if (action.type == NONE || action.type == TEAMUNPACK2 || action.type == TEAMPACK2 || action.type==WAIT){
        return;
    }

    string out;
    out += to_string(action.type);
    out += " " + to_string(id) + " " + to_string(action.dest);
    if (action.type == TEAMPACK1 || action.type == TEAMUNPACK1){
        out += " " + to_string(action.ln);
    }
    out += '|';
    cout << out;
  // cerr << out;
}


void build_distances(){
    FOR(i,N) {fill(estimated_tourns[i],estimated_tourns[i]+N,INF);}
    FOR(i,N) {fill(min_mx_edge[i],min_mx_edge[i]+N,INF);}
    FOR(i,N)FOR(j,N){fill(mn_tourns[i][j],mn_tourns[i][j]+CAP+2,INF);}
    FOR(i,N)FOR(j,N){
        if (i==j){
            estimated_tourns[i][i]=0;
            fill(mn_tourns[i][i],mn_tourns[i][i]+CAP+2,0);
            min_mx_edge[i][i]=0;
            continue;
        }
        if (dist[i][j]<=50) estimated_tourns[i][j] = 2;
        else if (dist[i][j]<=100) estimated_tourns[i][j] = 4;
        else if (dist[i][j]<=120) estimated_tourns[i][j] = 7;
        min_mx_edge[i][j] = dist[i][j];
        for(int c=dist[i][j];c<=60;++c) mn_tourns[i][j][c] = 1;
        mn_tourns[i][j][61] = (dist[i][j] <= 120 ? 1:INF);
    }
    for (int k = 0; k < N; ++k) {
        for (int i = 0; i < N; ++i) {
            for (int j = 0; j < N; ++j) {
                estimated_tourns[i][j] = min(estimated_tourns[i][j],estimated_tourns[i][k] + estimated_tourns[k][j]);
                min_mx_edge[i][j] = min(min_mx_edge[i][j],max(min_mx_edge[i][k],min_mx_edge[k][j]));
                for(int c=1;c<=61;++c)
                    mn_tourns[i][j][c] = min(mn_tourns[i][j][c], mn_tourns[i][k][c] + mn_tourns[k][j][c]);
            }
        }
    }
}

void build_vecinos(){
    FOR(i,N){
        for(int j=i+1;j<N;++j){
            if (dist[i][j]>2*CAP) continue;
            if (dist[i][j]<=CAP){
                vecinos[i].push_back(j);
                vecinos[j].push_back(i);
            }
            vecinos_largos[i].push_back(j);
            vecinos_largos[j].push_back(i);
        }
    }
    FOR(i,N) sort(all(vecinos[i]),[i](int u,int v){return dist[i][u]<dist[i][v];});
    FOR(i,N) sort(all(vecinos_largos[i]),[i](int u,int v){return dist[i][u]<dist[i][v];});
}

void build_components(){
    FOR(i,N) component_of_island[i] = -1;

    function<void(int)> dfs = [&](int u){
        component_of_island[u] = ncomponents;
        for(int i:vecinos[u]){
            if (component_of_island[i] == -1) dfs(i);
        }
    };

    FOR(i,N){
        if (component_of_island[i]==-1){
            dfs(i);
            ++ncomponents;
        }
    }
    FOR(i,N) islands_in_comp[component_of_island[i]].push_back(i);
}

void pre(){
    build_distances();
    build_vecinos();
    build_components();
    FOR(b,B) bridgeman[b].id = b;
}

void read(){
    ios_base::sync_with_stdio(false); cin.tie(0);
    std::cin >> N >> B >> O;
    for (int i = 0; i < N; ++i) {
        for (int j = 0; j < N; ++j) {
            cin >> dist[i][j];
        }
    }

    DATA(N);
    DATA(B);
    DATA(O);
}

void read_round(){
    std::cin >> elapsed;
    for (int i = 0; i < B; ++i) {
        std::cin >> bridgeman[i].Position >> bridgeman[i].Bricks >> bridgeman[i].Target;
    }
    for (int i = 0; i < O; ++i) {
        std::cin >> order[i].From >> order[i].To;
    }
}

void clear_variables(){
    FOR(i,N) FOR(j,N) blocked[i][j]= false;
    FOR(i,B) bridgeman[i].action.type = NONE;
    ord_actions.clear();
}

void write(){
   // if (!msg.empty()) cerr << msg << endl;
    for(int b:ord_actions) bridgeman[b].write_action();
   // for(int i=SZ(ord_actions);i<B;++i) cout << "|";
    // cerr << endl;
    cout << endl;
}



inline int get_bridge_idx(int i1,int i2){
    if (i1>i2) swap(i1,i2);
    return i1 * MXN + i2;
}
inline ii from_bridge_idx(int idx){
    return {idx/MXN, idx%MXN};
}

pair<int,Action> dist_to_dest(int ib,int dest,int limit,const vector<int> &men){
    static constexpr int RM=2;
    int position = bridgeman[men[ib]].Position;
    int bricks = bridgeman[men[ib]].Bricks;
    if (mn_tourns[position][dest][61] >= limit) return {INF,{}};
    vvi D(N,vi(CAP+1));
    for(int n=0;n<N;++n) fill(D[n].begin(),D[n].end(),limit - mn_tourns[dest][n][61]);

    for(int br=0;br<=bricks;++br) D[position][br] = 0;
    struct State{
        int h,pos,brk,cost,r;
        array<int,RM> rm;
        Action first_action;
        State(int e,int _p,int _brk,int _cost,int _r,array<int,RM> _rm,Action act):h(e + _cost),pos(_p),brk(_brk),cost(_cost),r(_r),rm(_rm),first_action(act){}
        bool operator<(const State &other)const{
            if (h == other.h){
                return cost>other.cost || (cost==other.cost && brk<other.brk);
            }
            return h > other.h;
        }
    };
    priority_queue<State> q;
    q.emplace(0,position,bricks,0,0,array<int,RM>{-1,-1},Action());
    while(!q.empty()){
        auto s = q.top(); q.pop();
        if (s.pos == dest){
            return {s.cost,s.first_action};
        }
        for(int i:vecinos_largos[s.pos]){
            bool conectada = false;
            if (connected[s.pos][i]){
                int idx = get_bridge_idx(s.pos,i);
                if (!any_of(all(s.rm),[idx](int v){return idx==v;})){
                    conectada = true;
                    if (D[i][s.brk]>s.cost+1+s.r){ // uso un punte existente
                        State s2 = s;
                        s2.pos = i;
                        s2.cost += s.r+1;
                        s2.r++;
                        s2.h = estimated_tourns[i][dest]+s2.cost;
                        s2.first_action = (s.first_action.type == NONE ? Action(MOVE,i): s.first_action);
                        q.push(s2);
                        D[s2.pos][s2.brk] = s2.cost;
                    }
                    if (s.r==0 && s.rm.back()==-1 && s.brk + dist[s.pos][i] > CAP && D[i][CAP] > s.cost + 3){
                        int ayudante=-1;
                        for(int b=0;b<B;++b){
                            if (bridgeman[b].action.type==NONE &&  bridgeman[b].Position == i && bridgeman[b].Bricks + s.brk + dist[s.pos][i] <= 2*CAP){
                                ayudante = b;
                                break;
                            }
                        }
                        if (ayudante != -1){
                            auto s2 = s;
                            s2.brk = CAP;
                            s2.pos = i;
                            s2.cost += 3;
                            s2.r++;
                            s2.h = estimated_tourns[i][dest]+s2.cost;
                            s2.first_action = Action(TEAMMOVE,ayudante);
                            q.push(s2);
                            D[s2.pos][s2.brk] = s2.cost;
                        }
                    }
                    bool can_remove = s.rm.back()==-1 && !any_of(all(s.rm),[idx](int v){return idx==v;}) && (!blocked[s.pos][i] ) ;
                    // levanto un puente existente
                    if (can_remove && s.brk + dist[s.pos][i]<=CAP && D[s.pos][s.brk + dist[s.pos][i]] > s.cost+2+s.r){
                        int nbrk = s.brk + dist[s.pos][i];
                        auto s2 = s;
                        s2.cost += s.r+2;
                        s2.h = estimated_tourns[s.pos][dest]+s2.cost;
                        s2.brk = nbrk;
                        s2.r++;
                        s2.rm.back() = idx;
                        {int kk=RM-1; while(kk && s2.rm[kk-1]==-1){swap(s2.rm[kk-1],s2.rm[kk]); --kk;} }
                        s2.first_action = (s.first_action.type == NONE ? Action(PACK,i): s.first_action);
                        q.push(s2);
                        D[s.pos][nbrk] = s2.cost;
                    }
                    else if (can_remove && s.brk < CAP && s.brk + dist[s.pos][i]>CAP && D[s.pos][CAP] > s.cost+s.r+3){
                        int ayudante=-1;
                        for(int b=0;b<B;++b){
                            if (b!=men[ib] && (bridgeman[b].action.type==NONE ) && bridgeman[b].Position == i && s.brk + bridgeman[b].Bricks + dist[s.pos][i] <= 2*CAP){
                                ayudante = b;
                                break;
                            }
                        }
                        if (ayudante !=-1){// team!
                            auto s2 = s;
                            s2.brk = CAP;
                            s2.cost += s.r+3;
                            s2.r++;
                            s2.h = estimated_tourns[s.pos][dest]+s2.cost;
                            s2.first_action = (s.first_action.type == NONE ? Action(TEAMPACK1,ayudante,CAP-s.brk): s.first_action);
                            q.emplace(s2);
                            D[s2.pos][CAP] = s2.cost;
                        }
                    }
                }
            }
            if (!conectada){
                if (s.brk>=dist[s.pos][i]){
                    int nbrk = s.brk-dist[s.pos][i];
                    if (D[i][nbrk]>s.cost+2){ // pongo puente cruzo y sigo
                        auto s2 = s;
                        s2.pos=i;
                        s2.cost += 2;
                        s2.brk = nbrk;
                        s2.r++;
                        s2.h = estimated_tourns[i][dest]+s2.cost;
                        s2.first_action = (s.first_action.type == NONE ? Action(UNPACK,i): s.first_action);
                        q.push(s2);
                        D[s2.pos][s2.brk] = s2.cost;
                    }
                    if (D[i][s.brk]>s.cost+3){ // pongo puente cruzo y levanto
                        auto s2 = s;
                        s2.pos=i;
                        s2.cost += 3;
                        s2.r++;
                        s2.h = estimated_tourns[i][dest]+s2.cost;
                        s2.first_action = (s.first_action.type == NONE ? Action(UNPACK,i): s.first_action);
                        q.emplace(s2);
                        D[s2.pos][s2.brk] = s2.cost;
                    }
                }else{
                    int ayudante=-1;
                    int restan = -1;
                    for(int b=0;b<B;++b){
                        if (b!=men[ib] && (bridgeman[b].action.type==NONE ) && bridgeman[b].Position == i && s.brk + bridgeman[b].Bricks >= dist[s.pos][i]){
                            int restan_este = s.brk - max(0,dist[s.pos][i] - bridgeman[b].Bricks);
                            if (restan_este > restan){
                                restan = restan_este;
                                ayudante = b;
                            }
                        }
                    }
                    if (ayudante !=-1 && D[i][restan]>s.cost + 2  + (s.r+1)){// team!
                        auto s2 = s;
                        s2.pos=i;
                        s2.cost += 2 + (s.r+1);
                        s2.r++;
                        s2.brk = restan;
                        s2.h = estimated_tourns[i][dest]+s2.cost;
                        s2.first_action = (s.first_action.type == NONE ? Action(TEAMUNPACK1,ayudante,s.brk-restan): s.first_action);
                        q.emplace(s2);
                        D[s2.pos][s2.brk] = s2.cost;
                    }
                    if (ayudante!=-1 && dist[s.pos][i]<=CAP && D[i][dist[s.pos][i]] > s.cost + 3 + (s.r+1)){
                        auto s2 = s;
                        s2.pos=i;
                        s2.brk = dist[s.pos][i];
                        s2.cost += 3 + (s.r+1);
                        s2.r++;
                        s2.h = estimated_tourns[i][dest]+s2.cost;
                        s2.first_action = (s.first_action.type == NONE ? Action(TEAMUNPACK1,ayudante,s.brk-restan): s.first_action);
                        q.emplace(s2);
                        D[s2.pos][s2.brk] = s2.cost;
                    }
                }
            }
        }
    }
    return {INF,{}};
}


void solve_cargados(vi &men){
    if (men.empty()) return;

    if (false){
        for(int b:men){
            int pos = bridgeman[b].Position;
            int brk = bridgeman[b].Bricks;
            int target = bridgeman[b].Target;
            if (mn_tourns[target][pos][brk]<INF){
                int best = -1;
                bool con=false;
                for(int i=0;i<N;++i){
                    if (mn_tourns[target][i][brk]==mn_tourns[target][pos][brk]-1 && (connected[pos][i] || (best==-1 && dist[pos][i]<=brk))){
                        best = i;
                        con =connected[pos][i];
                        if (con) break;
                    }
                }
                assert(best != -1);
                bridgeman[b].action.dest = best;
                if (con){
                    bridgeman[b].action.type=MOVE;
                }
                else{
                    bridgeman[b].action.type=UNPACK;
                }
                bridgeman[b].do_action();
                ord_actions.push_back(b);
            }
        }
    }
    if (true){
        vi costo(B,INF);
        FOR(i,B){
            if (bridgeman[i].action.type!=NONE) continue;
            costo[i] = mn_tourns[bridgeman[i].Position][bridgeman[i].Target][bridgeman[i].Bricks];
        }
        sort(all(men),[&costo](int i,int j){return costo[i]<costo[j];});
    }
    for(int i=0;i<SZ(men);++i){
        int best_cost = INF;
        int best_j=-1;
        Action best_act;
        for(int j=0;j<SZ(men) ;++j){
            if (bridgeman[men[j]].action.type != NONE) continue;
            int target = bridgeman[men[j]].Target;
            auto [este,act] = dist_to_dest(j,target,best_cost,men);
            if (este < best_cost){
                best_cost = este;
                best_j = j;
                best_act = act;
            }
        }
        if (best_j == -1) break;
        int b = men[best_j];

        if (best_act.type == TEAMMOVE){
            int ayudante = best_act.dest;
            assert(bridgeman[ayudante].action.type == NONE);
            bridgeman[b].action.type = MOVE;
            bridgeman[b].action.dest = bridgeman[ayudante].Position;
            bridgeman[ayudante].action.type = MOVE;
            bridgeman[ayudante].action.dest = bridgeman[b].Position;
            bridgeman[ayudante].do_action();
            ord_actions.push_back(ayudante);
        }else{
            bridgeman[b].action = best_act;
        }
        ord_actions.push_back(men[best_j]);
        bridgeman[b].do_action();
        if (best_act.type==UNPACK){
            set_blocked(bridgeman[b].Position,best_act.dest,true);
        }else if (best_act.type==TEAMUNPACK1){
            int ayudante = best_act.dest;
            assert(bridgeman[ayudante].action.type == NONE);
            bridgeman[ayudante].action.type = TEAMUNPACK2;
        }else if (best_act.type==TEAMPACK1){
            int ayudante = best_act.dest;
            bridgeman[ayudante].action.type = TEAMPACK2;
        }
    }
}

void solve_vacios(vi &men){
    if (men.empty()) return;

    vi ordenes(O);
    iota(all(ordenes),0);
    {
        vii costo(B,{INF,-1});
        FOR(i,B){
            if (bridgeman[i].action.type!=NONE) continue;
            FOR(o,O){
                int este = mn_tourns[bridgeman[i].Position][order[o].From][bridgeman[i].Bricks] + mn_tourns[order[o].From][order[o].To][bridgeman[i].Bricks];
                if (este < costo[i].first){
                    costo[i] = {este,o};
                }
            }
        }
        sort(all(men),[&costo](int i,int j){return costo[i]<costo[j];});
        if (costo[men[0]].second!=-1){
            swap(ordenes[0],ordenes[costo[men[0]].second]);
        }
    }

    for(int i=0;i<SZ(men) && i<O;++i){
        int best_cost = INF;
        int best_j=-1;
        int best_k = -1;
        Action best_act;
        for(int j=0;j<SZ(men);++j){
            if (bridgeman[men[j]].action.type!=NONE)continue;
            for(int k=0;k+i<O;++k){
                int o_from = order[ordenes[k]].From;
                int o_to = order[ordenes[k]].To;
                auto [este,act] = dist_to_dest(j,o_from,best_cost - estimated_tourns[o_from][o_to],men);
                if (este + estimated_tourns[o_from][o_to] < best_cost){
                    best_cost = este + estimated_tourns[o_from][o_to];
                    best_j = j;
                    best_k = k;
                    best_act = act;
                }
            }
       //     if (best_j!=-1) break;
        }
        if (best_j==-1) break;
        int b = men[best_j];

        if (best_act.type==NONE) best_act.type = WAIT;
        if (best_act.type == TEAMMOVE){
            int ayudante = best_act.dest;
            assert(bridgeman[ayudante].action.type == NONE);
            bridgeman[b].action.type = MOVE;
            bridgeman[b].action.dest = bridgeman[ayudante].Position;
            bridgeman[ayudante].action.type = MOVE;
            bridgeman[ayudante].action.dest = bridgeman[b].Position;
            bridgeman[ayudante].do_action();
            ord_actions.push_back(ayudante);
        }else{
            bridgeman[b].action = best_act;
        }
        bridgeman[b].do_action();
        ord_actions.push_back(b);
        swap(ordenes[SZ(ordenes)-i-1],ordenes[best_k]);

        if (best_act.type==UNPACK){
            set_blocked(bridgeman[b].Position,best_act.dest,true);
        }else if (best_act.type==TEAMUNPACK1){
            int ayudante = best_act.dest;
            assert(bridgeman[ayudante].action.type == NONE);
            bridgeman[ayudante].action.type = TEAMUNPACK2;
            set_blocked(bridgeman[b].Position,bridgeman[ayudante].Position,true);
        }else if (best_act.type==TEAMPACK1){
            int ayudante = best_act.dest;
            assert(bridgeman[ayudante].action.type == NONE);
            bridgeman[ayudante].action.type = TEAMPACK2;
        }
    }
}

void solve_no_usados(){
    vi cargados,vacios;
    FOR(b,B){
        if (bridgeman[b].action.type==NONE){
            if (bridgeman[b].Target!=-1) cargados.push_back(b);
            else vacios.push_back(b);
        }
    }
    for(int b:cargados){
        int pos=bridgeman[b].Position;
        int bricks = bridgeman[b].Bricks;
        int target = bridgeman[b].Target;
        int cual=-1;
        for(int i:vecinos_largos[b]){
            if (mn_tourns[target][i] >= mn_tourns[target][pos])continue;
            if (connected[pos][i]){
                bridgeman[b].action.type = MOVE;
                bridgeman[b].action.dest = i;
                cual = -1;
                break;
            }
            if (dist[pos][i]<=bricks){
                cual = i;
            }
        }
        if (cual!=-1){
            bridgeman[b].action.type = UNPACK;
            bridgeman[b].action.dest = cual;
            bridgeman[b].do_action();
            ord_actions.push_back(b);
        }
    }
    /*
    for(int b:vacios){
        int pos=bridgeman[b].Position;
        int bricks = bridgeman[b].Bricks;
        int cual=-1;
        int cnt=0;
        for(int i:vecinos[b]){
            if (dist[pos][i]<=bricks && !connected[pos][i]){
                int este=0;
                FOR(b,B) este += bridgeman[b].Position == i;
                if (este > cnt){
                    cnt=este;
                    cual=i;
                }
            }
        }
        if (cual!=-1){
            bridgeman[b].action.type = UNPACK;
            bridgeman[b].action.dest = cual;
            bridgeman[b].do_action();
            ord_actions.push_back(b);
        }
    }
    */
}


int main() {
 //    freopen("5.in", "r", stdin);

    read();
    pre();
    int mxturn=0;
    for (int turn = 1; turn <= 1000; turn++) {
        read_round();
        clear_variables();
        if (elapsed > TLIMIT){
            if (turn==mxturn+1) {dbg(mxturn);}
            cout << endl;
            continue;
        }
        mxturn = turn;
        vi cargados,vacios;
        for(int i=0;i<B;++i){
            if (bridgeman[i].Target != -1) cargados.push_back(i);
            else vacios.push_back(i);
        }

        solve_cargados(cargados);
        solve_vacios(vacios);
      //  solve_no_usados();
        write();
    }
    dbg(mxturn);
    return 0;
}