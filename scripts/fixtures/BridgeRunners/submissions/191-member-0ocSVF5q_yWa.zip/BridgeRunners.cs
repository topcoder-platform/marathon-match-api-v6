using System;
using System.Collections.Generic;
using System.Linq;

class BridgeRunners
{
    static void Main(string[] args)
    {
        int N = int.Parse(Console.ReadLine());
        int B = int.Parse(Console.ReadLine());
        int O = int.Parse(Console.ReadLine());

        int[,] dists = new int[N, N];
        bool[,] connected = new bool[N, N];

        for (int i = 0; i < N; i++)
        {
            int[] line = Console.ReadLine().Split().Select(int.Parse).ToArray();
            for (int j = 0; j < N; j++)
                dists[i, j] = line[j];
        }

        List<Bridgeman> bridgemen = new List<Bridgeman>();
        for (int i = 0; i < B; i++)
        {
            bridgemen.Add(new Bridgeman { ID = i });
        }

        // Track order frequency for better bridge decisions
        Dictionary<string, int> orderFrequency = new Dictionary<string, int>();
        List<Order> allOrders = new List<Order>(); // Track all orders for completion checking
        Dictionary<string, int> bridgeUsage = new Dictionary<string, int>(); // Track bridge usage
        Dictionary<string, int> bridgeLastUsed = new Dictionary<string, int>(); // Last turn bridge was useful

        for (int turn = 1; turn <= 1000; turn++)
        {
            string elapsedTimeLine = Console.ReadLine();
            if (string.IsNullOrEmpty(elapsedTimeLine)) break;
            int elapsedTime = int.Parse(elapsedTimeLine);

            for (int i = 0; i < B; i++)
            {
                string bridgemanLine = Console.ReadLine();
                if (string.IsNullOrEmpty(bridgemanLine)) return;
                int[] line = bridgemanLine.Split().Select(int.Parse).ToArray();
                bridgemen[i].Position = line[0];
                bridgemen[i].Bricks = line[1];
                bridgemen[i].Target = line[2];
            }

            List<Order> orders = new List<Order>();
            for (int i = 0; i < O; i++)
            {
                string orderLine = Console.ReadLine();
                if (string.IsNullOrEmpty(orderLine)) break;
                int[] line = orderLine.Split().Select(int.Parse).ToArray();
                var order = new Order { From = line[0], To = line[1], Turn = turn };
                orders.Add(order);
                allOrders.Add(order);

                // Track order frequency
                var key = order.From + "," + order.To;
                if (!orderFrequency.ContainsKey(key)) orderFrequency[key] = 0;
                orderFrequency[key] = orderFrequency[key] + 1;
                var reverseKey = order.To + "," + order.From;
                if (!orderFrequency.ContainsKey(reverseKey)) orderFrequency[reverseKey] = 0;
                orderFrequency[reverseKey] = orderFrequency[reverseKey] + 1;
            }

            // Update bridge usage tracking
            foreach (var order in orders)
            {
                if (PathFinder.IsConnected(order.From, order.To, connected, N))
                {
                    bridgeLastUsed[order.From + "," + order.To] = turn;
                    bridgeLastUsed[order.To + "," + order.From] = turn;
                }
            }

            List<string> commands = new List<string>();
            HashSet<int> targetedNodes = new HashSet<int>(); // Prevent multiple bridgemen targeting same node

            foreach (Bridgeman b in bridgemen)
            {
                string command = "";

                if (b.BridgeFrom == -1) // Need to start building
                {
                    // Consider removing unused bridges first if low on bricks
                    bool shouldRemoveBridge = false;
                    int bridgeToRemove = -1;

                    if (b.Bricks < 30 && turn > 150) // More aggressive bridge removal when resources are scarce
                    {
                        for (int i = 0; i < N; i++)
                        {
                            if (connected[b.Position, i])
                            {
                                var key = b.Position + "," + i;
                                int lastUsed = bridgeLastUsed.ContainsKey(key) ? bridgeLastUsed[key] : 0;

                                if (turn - lastUsed > 30) // Unused for 30 turns
                                {
                                    shouldRemoveBridge = true;
                                    bridgeToRemove = i;
                                    break;
                                }
                            }
                        }
                    }

                    if (shouldRemoveBridge)
                    {
                        // Assign this bridgeman to pack the unused bridge
                        command = $"PACK {b.ID} {b.Position}";
                        connected[b.Position, bridgeToRemove] = false;
                        connected[bridgeToRemove, b.Position] = false;
                    }
                    else
                    {
                        // Find best target based on current orders
                        int bestTarget = -1;
                        int maxOrdersServed = 0;

                        List<int> candidates = new List<int>();
                        for (int t = 0; t < N; t++)
                        {
                            if (t != b.Position &&
                               !connected[b.Position, t] &&
                               !targetedNodes.Contains(t) &&
                               dists[b.Position, t] <= b.Bricks)
                            {
                                candidates.Add(t);
                            }
                        }

                    foreach (int candidate in candidates)
                    {
                        // Count current orders that would be directly fulfilled
                        int directOrders = 0;
                        foreach (Order o in orders)
                        {
                            if ((o.From == b.Position && o.To == candidate) ||
                                (o.From == candidate && o.To == b.Position))
                                directOrders++;
                        }

                        // Count orders that would become completable via new bridge (simplified)
                        int enabledOrders = 0;

                        // Prioritize older orders that are still unfulfilled
                        foreach (Order order in allOrders)
                        {
                            if (order.Turn >= turn - 20 && order.Turn <= turn)
                            {
                                // Heuristic: if either endpoint connects to the bridge, likely enables the order
                                if ((order.From == b.Position || order.To == b.Position ||
                                     order.From == candidate || order.To == candidate) &&
                                    !connected[order.From, order.To])
                                {
                                    enabledOrders++;
                                }
                            }
                        }

                        var freqKey = b.Position + "," + candidate;
                        int historicalFreq = orderFrequency.ContainsKey(freqKey) ? orderFrequency[freqKey] : 0;

                        // Score: direct impact + enabled orders + historical pattern
                        int totalScore = directOrders * 25 + enabledOrders * 8 + historicalFreq * 2;

                        // Time bonus for early game bridge building
                        if (turn <= 200)
                            totalScore += 3;

                        // Efficiency bonus for short bridges
                        if (dists[b.Position, candidate] < 20)
                            totalScore += 2;

                        if (totalScore > maxOrdersServed)
                        {
                            maxOrdersServed = totalScore;
                            bestTarget = candidate;
                        }
                    }

                    // If no orders match, pick closest target
                    if (bestTarget == -1 && candidates.Count > 0)
                    {
                        bestTarget = candidates[0];
                        int minDist = dists[b.Position, candidates[0]];
                        for (int j = 1; j < candidates.Count; j++)
                        {
                            if (dists[b.Position, candidates[j]] < minDist)
                            {
                                minDist = dists[b.Position, candidates[j]];
                                bestTarget = candidates[j];
                            }
                        }
                    }

                        if (bestTarget != -1)
                        {
                            command = $"UNPACK {b.ID} {bestTarget}";
                            b.BridgeFrom = b.Position;
                            b.BridgeTo = bestTarget;
                            connected[b.Position, bestTarget] = true;
                            connected[bestTarget, b.Position] = true;
                            targetedNodes.Add(bestTarget); // Mark as targeted
                        }
                    }
                }
                else if (b.BridgeFrom == b.Position) // Currently building, need to move
                {
                    command = $"MOVE {b.ID} {b.BridgeTo}";
                }
                else // At other end, need to pack
                {
                    command = $"PACK {b.ID} {b.BridgeFrom}";
                    connected[b.BridgeFrom, b.BridgeTo] = false;
                    connected[b.BridgeTo, b.BridgeFrom] = false;
                    b.BridgeFrom = -1;
                    b.BridgeTo = -1;
                }

                if (!string.IsNullOrEmpty(command))
                    commands.Add(command);
            }

            // Ensure valid output format
            var validCommands = commands.Where(c => !string.IsNullOrEmpty(c.Trim())).ToList();
            if (validCommands.Count > 0)
            {
                Console.WriteLine(string.Join(" | ", validCommands));
            }
            else
            {
                // Output empty line if no commands (required by format)
                Console.WriteLine("");
            }
        }
    }
}

class Bridgeman
{
    public int ID;
    public int Position;
    public int Target;
    public int Bricks;
    public int BridgeFrom = -1;
    public int BridgeTo = -1;
}

class Order
{
    public int From;
    public int To;
    public int Turn;
}

static class PathFinder
{
    public static bool IsConnected(int from, int to, bool[,] connected, int N)
    {
        if (from == to) return true;
        if (connected[from, to]) return true;

        // Simple BFS to check connectivity
        var visited = new bool[N];
        var queue = new Queue<int>();
        queue.Enqueue(from);
        visited[from] = true;

        while (queue.Count > 0)
        {
            int current = queue.Dequeue();
            if (current == to) return true;

            for (int next = 0; next < N; next++)
            {
                if (!visited[next] && connected[current, next])
                {
                    visited[next] = true;
                    queue.Enqueue(next);
                }
            }
        }

        return false;
    }

    public static int GetPathLength(int from, int to, bool[,] connected, int[,] distances, int N)
    {
        if (from == to) return 0;

        var dist = new int[N];
        var visited = new bool[N];

        for (int i = 0; i < N; i++)
            dist[i] = int.MaxValue;

        dist[from] = 0;

        for (int count = 0; count < N - 1; count++)
        {
            int u = -1;
            for (int v = 0; v < N; v++)
                if (!visited[v] && (u == -1 || dist[v] < dist[u]))
                    u = v;

            if (u == -1 || dist[u] == int.MaxValue) break;
            visited[u] = true;

            for (int v = 0; v < N; v++)
            {
                if (!visited[v] && connected[u, v] && dist[u] + distances[u, v] < dist[v])
                {
                    dist[v] = dist[u] + distances[u, v];
                }
            }
        }

        return dist[to] == int.MaxValue ? -1 : dist[to];
    }
}