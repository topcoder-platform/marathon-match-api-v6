'''
java -jar tester.jar -exec "python BridgeRunners.py" -showOrders -delay 1 -seed 1

T = ターン数1000
N = 島の数 (25〜80)
B = bridgemen の数 (4〜20)
O = 同時に見える注文(order)の数 (4〜10)
D = 各島の距離行列

初期状態
    各bridgemanは橋材を50持っており、最大60まで持てる
    どの島にいるかはランダムだが、必ず移動できることは保証される

各ターンの入力
    B 行：各bridgemanの状態
        islandID:   現在地
        carry:      持っている橋材の長さ
        target:     配達先のメッセージがある場合はその島ID、なければ -1

    O 行：現在受注可能な注文
        orig:   メッセージを受け取るべき島
        dest:   配達先

各ターンの出力
    1行 "|" 区切りで出力
    命令フォーマット：
        "MOVE bridgemanID islandID":    既存の橋を渡って移動
        "UNPACK bridgemanID islandID":  現在地から islandID へ新しい橋を建設
        "PACK bridgemanID islandID":    現在地から islandID への橋を撤去
        "TEAMUNPACK bridgemanID1 bridgemanID2 length1": 
            2人のいる島間に橋を建設。1人目が length1 を、2人目が残りを担当
        "TEAMPACK bridgemanID1 bridgemanID2 length1":   
            2人のいる島間の橋を撤去。1人目が length1 を、2人目が残りを担当
        "MSG any":  |は含められない。最後のMSGだけが可視化される

補足:
    同一島から複数注文が出る場合は順番が固定
    ある島のbridgemanがメッセージを受け取った瞬間、新しい注文が即座に出現する場合がある
    同一島に複数のbridgemanがいて即時取得可能な場合はIDが最小のbridgemanが優先

考察:
    ソロ、ペアを固定もしくは動的に設定して行動する
    2人での橋の構築方式から、swap移動を想定している？
        同じ島に移動しても良いが、橋のが回収がアンバランスになりそう
            距離>60だと回収が不可能になる
        距離>60の島には誰か立っていないと2度と行けないことになる
            そのようなケースはあまり無い、最大でも70程度
                最終盤はその島を捨てる作戦もあり得る
                50より大きいパターンはあるので、持つ量に偏りが作れると良い
                    swapせずに橋材渡しを2ターンで行える操作と考える
            2度と行けない制約より、離れた場所をswapでワープできる使い方
    注文が随時公開されるため、モンテカルロで注文だけ探索？
        オーダーは単にランダムなため、出ているものだけ考慮でも良いか
    今持っているオーダーに対する最適行動はビムサが良さそう
    オーダーを取って目的地に行くまでの時間がオーダー自体の評価値
    盤面評価
        持っているオーダーに対して目的地までの距離
        オーダーを取りに行く時間
    1人で移動できる島を連結成分として捉える
        2人いないと連結成分を渡れない小島が生成される時がある
        連結成分内に1人はいる必要がある
            少ない連結成分に多くいる必要もない
    自分で橋を作らずに誰かに相乗りすることもできる
        橋材を最小限だけ持って移動だけする人も存在できる
        橋の常設方針の方が重要なのでは
            MSTの総コスト<=所持橋材総量の場合、そのように作ってしまえる
                島もエージェントも多い場合

探索
    chokudaiサーチで、1ターンに1エージェントの行動をする

'''

import sys
from random import random, seed, randrange, choice, sample
from collections import deque, defaultdict, Counter
from heapq import heapify, heappush, heappop

class Agent:
    def __init__(self, id):
        self.id = id
        self.pos = 0
        self.target = 0
        self.bricks = 0
        self.nxt = -1
        self.prv = -1
        self.pair = -1

    def __repr__(self):
        return f"Agent(id: {self.id}, pos: {self.pos}, target: {self.target}, bricks: {self.bricks})"

class Order:
    def __init__(self, frm, to):
        self.frm = frm
        self.to = to

    def __repr__(self):
        return f"Order(frm: {self.frm}, to: {self.to})"

def main():
    N = int(input())    # 島の数
    M = int(input())    # エージェント数
    K = int(input())    # 表示オーダー数

    # 距離行列
    dists = [[int(i) for i in input().split()] for _ in range(N)]
    print(max([min([a for a in d if a!=0]) for d in dists]), file=sys.stderr)

    # i->jへの距離
    costs = [[1000 for _ in range(N)] for _ in range(N)]
    graph = [[] for _ in range(N)]
    for i in range(N):
        for j in range(N):
            if i==j: continue
            if dists[i][j]>100: continue
            graph[i].append((j, dists[i][j]))

    hq = []
    for s in range(N):
        costs[s][s] = 0
        heappush(hq, (0, s))
        while hq:
            d, u = heappop(hq)
            if costs[s][u]<d: continue
            for v, w in graph[u]:
                add = 1 if w<=50 else 500
                if costs[s][v] > d+add:
                    costs[s][v] = d+add
                    heappush(hq, (costs[s][v], v))

    agents = [Agent(i) for i in range(M)]
    orders = [Order(0, 0) for _ in range(K)]
    bridges = [[False]*N for _ in range(N)]

    for turn in range(1000):
        output = []
        elapsedTime = int(input())
        for a in agents:
            a.pos, a.bricks, a.target = [int(i) for i in input().split()]

        for order in orders:
            order.frm, order.to = list(map(int, input().split()))
        # print(orders, file=sys.stderr)

        # 0だけを制御する
        agent = agents[0]
        pair = -1
        if agent.nxt >= 0: # 橋を架けた後
            output.append(f"MOVE {agent.id} {agent.nxt}")
            bridges[agent.pos][agent.nxt] = True
            bridges[agent.nxt][agent.pos] = True
            agent.nxt = -1
            if agent.pair >= 0:
                output.append(f"MOVE {agent.pair} {agent.prv}")
                
        elif agent.prv >= 0:  # 渡った後
            if agent.pair < 0:
                output.append(f"PACK {agent.id} {agent.prv}")
                bridges[agent.pos][agent.prv] = False
                bridges[agent.prv][agent.pos] = False
                agent.bricks += dists[agent.pos][agent.prv]
                agent.prv = -1
            else:
                output.append(f"TEAMPACK {agent.id} {agent.pair} {50}")
                bridges[agent.pos][agent.prv] = False
                bridges[agent.prv][agent.pos] = False
                agent.bricks += 50
                agent.prv = -1
                agent.pair = -1
        else:   # 行先を決め、橋を架ける
            best = 1000
            if agent.target == -1:
                for order in orders:
                    if best > costs[order.frm][agent.pos]:
                        best = costs[order.frm][agent.pos]
                        agent.target = order.frm

            best = 1000
            bv = -1
            for v, w in graph[agent.pos]:
                pair = -1
                if w > agent.bricks: 
                    for a in agents:
                        if a.pos==v and w<=(a.bricks+agent.bricks):
                            pair = a.id
                            break
                    else: continue
                if best > costs[agent.target][v]:
                    best = costs[agent.target][v]
                    bv = v
            print(agents[0], costs[agent.target][agent.pos], file=sys.stderr)
            print(agents[0], costs[agent.target][bv], file=sys.stderr)

            v = bv
            w = dists[agent.pos][v]
            print(v, w, file=sys.stderr)
            agent.pair = -1
            if w > agent.bricks: 
                for a in agents:
                    if a.pos==v and w<=(a.bricks+agent.bricks):
                        agent.pair = a.id

            if agent.pair < 0:
                agent.prv = agent.pos
                agent.nxt = v
                output.append(f"UNPACK {agent.id} {agent.nxt}")
                agent.bricks -= dists[agent.pos][agent.nxt]
            else:
                agent.prv = agent.pos
                agent.nxt = v
                output.append(f"TEAMUNPACK {agent.id} {agent.pair} {50}")
                agent.bricks -= 50
        
        print(" | ".join(output))

if __name__ == "__main__":
    main()