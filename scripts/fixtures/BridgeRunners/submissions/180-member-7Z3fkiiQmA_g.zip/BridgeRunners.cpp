#include <bits/stdc++.h>
using namespace std;

const int MAXN = 81;
const int INF = 1000000000;
int N, B, O, C;
int dists[MAXN][MAXN];
bool built[MAXN][MAXN];
int hop_dist[MAXN][MAXN]; // precomputed min hops in possible graph

class Bridgeman {
public:
    int ID;
    int Position;
    int Target;
    int Bricks;
    int BridgeFrom = -1;
    int BridgeTo = -1;
    int Goal = -1;
    int connect_partner = -1;
    int connect_target = -1;
};

struct Order {
    int From;
    int To;
};

// Track deliveries to detect stuck
vector<int> delivery_turns;
int last_delivery_turn = -1;
int stuck_threshold = 20; // adjustable based on scatter

// BFS for min hop path, return next island or -1 if no path
int get_next_on_path(int start, int end_) {
    if (start == end_) return -1;
    vector<int> parent(N, -1);
    vector<bool> visited(N, false);
    queue<int> q;
    q.push(start);
    visited[start] = true;
    while (!q.empty()) {
        int cur = q.front();
        q.pop();
        if (cur == end_) break;
        for (int j = 0; j < N; ++j) {
            if (j != cur && (built[cur][j] || (dists[cur][j] > 0 && dists[cur][j] <= C)) && !visited[j]) {
                q.push(j);
                visited[j] = true;
                parent[j] = cur;
            }
        }
    }
    if (!visited[end_]) return -1;
    // reconstruct next from start
    int cur = end_;
    while (parent[cur] != start && parent[cur] != -1) {
        cur = parent[cur];
    }
    return cur;
}

// Find a central gathering point (e.g., island with most connections or min max dist)
int find_gathering_point() {
    int best_center = 0;
    int min_max_dist = INF;
    for (int center = 0; center < N; ++center) {
        int max_d = 0;
        for (int i = 0; i < N; ++i) {
            if (dists[center][i] > 0) {
                max_d = max(max_d, dists[center][i]);
            }
        }
        if (max_d < min_max_dist) {
            min_max_dist = max_d;
            best_center = center;
        }
    }
    return best_center;
}

int main() {
    cin >> N >> B >> O;
    for (int i = 0; i < N; ++i) {
        for (int j = 0; j < N; ++j) {
            cin >> dists[i][j];
            built[i][j] = false;
        }
    }
    Bridgeman bridgemen[B];
    for (int i = 0; i < B; ++i) {
        bridgemen[i].ID = i;
        bridgemen[i].connect_partner = -1;
        bridgemen[i].connect_target = -1;
    }
    // Main loop for all 1000 turns
    for (int turn = 1; turn <= 1000; ++turn) {
        int elapsedTime;
        cin >> elapsedTime;
        for (int i = 0; i < B; ++i) {
            cin >> bridgemen[i].Position >> bridgemen[i].Bricks >> bridgemen[i].Target;
        }
        if (turn == 1) {
            C = bridgemen[0].Bricks;
        }
        vector<Order> orders(O);
        for (int i = 0; i < O; ++i) {
            cin >> orders[i].From >> orders[i].To;
        }
        // Check for deliveries this turn (if any bridgeman target changed or something, but simplify: assume if O>0 possible)
        bool has_delivery = (O > 0);
        if (has_delivery) {
            last_delivery_turn = turn;
        } else if (turn - last_delivery_turn > stuck_threshold) {
            // Stuck: gather all free bridgemen to center
            int center = find_gathering_point();
            for (int i = 0; i < B; ++i) {
                auto& b = bridgemen[i];
                if (b.Target == -1 && b.Goal == -1 && b.connect_target == -1) {
                    b.Goal = center;
                }
            }
        }
        // Recompute hop_dist on current possible edges
        for (int i = 0; i < N; ++i) {
            for (int j = 0; j < N; ++j) {
                if (i == j) {
                    hop_dist[i][j] = 0;
                } else {
                    hop_dist[i][j] = (built[i][j] || (dists[i][j] > 0 && dists[i][j] <= C)) ? 1 : INF;
                }
            }
        }
        // Floyd-Warshall
        for (int k = 0; k < N; ++k) {
            for (int i = 0; i < N; ++i) {
                for (int j = 0; j < N; ++j) {
                    if (hop_dist[i][k] < INF && hop_dist[k][j] < INF) {
                        hop_dist[i][j] = min(hop_dist[i][j], hop_dist[i][k] + hop_dist[k][j]);
                    }
                }
            }
        }
        // Compute connected components
        vector<int> cc_id(N, -1);
        vector<bool> vis(N, false);
        int num_cc = 0;
        vector<vector<int>> cc_islands;
        for (int i = 0; i < N; ++i) {
            if (!vis[i]) {
                cc_islands.emplace_back();
                queue<int> q;
                q.push(i);
                vis[i] = true;
                cc_id[i] = num_cc;
                cc_islands[num_cc].push_back(i);
                while (!q.empty()) {
                    int u = q.front();
                    q.pop();
                    for (int v = 0; v < N; ++v) {
                        if (hop_dist[u][v] < INF && !vis[v]) {
                            vis[v] = true;
                            cc_id[v] = num_cc;
                            cc_islands[num_cc].push_back(v);
                            q.push(v);
                        }
                    }
                }
                num_cc++;
            }
        }
        cc_islands.resize(num_cc);
        // Check for ready connect pairs and add team actions
        vector<string> output;
        for (int i = 0; i < B; ++i) {
            auto& b = bridgemen[i];
            if (b.connect_partner != -1 && i < b.connect_partner) {
                int p = b.connect_partner;
                auto& bp = bridgemen[p];
                if (b.Position == b.connect_target && bp.Position == bp.connect_target &&
                    b.Target == -1 && bp.Target == -1) {
                    // Ready to team unpack
                    int pos1 = b.Position;
                    int pos2 = bp.Position;
                    if (pos1 == pos2) {
                        b.connect_partner = -1;
                        b.connect_target = -1;
                        bp.connect_partner = -1;
                        bp.connect_target = -1;
                        continue;
                    }
                    int d = dists[pos1][pos2];
                    int id1 = b.ID;
                    int id2 = p;
                    int c1 = b.Bricks;
                    int c2 = bp.Bricks;
                    if (d > c1 + c2 || d <= 0) {
                        // Cancel task
                        b.connect_partner = -1;
                        b.connect_target = -1;
                        bp.connect_partner = -1;
                        bp.connect_target = -1;
                        continue;
                    }
                    // Ensure len1 > 0 by always having the one with more bricks contribute more
                    if (c1 < c2) {
                        swap(id1, id2);
                        swap(c1, c2);
                    }
                    int len1 = max(1, d - c2); // Ensure at least 1 if possible
                    if (len1 > c1) {
                        // Cannot, cancel
                        b.connect_partner = -1;
                        b.connect_target = -1;
                        bp.connect_partner = -1;
                        bp.connect_target = -1;
                        continue;
                    }
                    string act = "TEAMUNPACK " + to_string(id1) + " " + to_string(id2) + " " + to_string(len1);
                    output.push_back(act);
                    built[pos1][pos2] = true;
                    built[pos2][pos1] = true;
                    b.connect_partner = -1;
                    b.connect_target = -1;
                    bp.connect_partner = -1;
                    bp.connect_target = -1;
                }
            }
        }
        // Set goals
        vector<Bridgeman*> free_b;
        for (int i = 0; i < B; ++i) {
            auto& b = bridgemen[i];
            if (b.Target != -1) {
                b.Goal = b.Target;
                b.connect_partner = -1;
                b.connect_target = -1;
            } else if (b.connect_target != -1) {
                b.Goal = b.connect_target;
            } else {
                b.Goal = -1;
            }
            if (b.Goal == -1) {
                free_b.push_back(&bridgemen[i]);
            }
        }
        // Assign free bridgemen to orders - assign multiple if needed, prioritize close ones
        vector<pair<int, pair<int, int>>> candidates;
        for (auto b_ptr : free_b) {
            int bid = b_ptr->ID;
            int pos = bridgemen[bid].Position;
            for (int o = 0; o < O; ++o) {
                int fr = orders[o].From;
                int to_ = orders[o].To;
                if (hop_dist[pos][fr] < INF && hop_dist[fr][to_] < INF) {
                    int cost = hop_dist[pos][fr]; // Prioritize getting to From, assume delivery happens when at From?
                    candidates.push_back({cost, {bid, o}});
                }
            }
        }
        sort(candidates.begin(), candidates.end());
        vector<bool> assigned_b(B, false);
        vector<bool> assigned_o(O, false);
        // Assign up to min(free_b.size(), O) but greedily
        for (auto& cand : candidates) {
            int bid = cand.second.first;
            int o = cand.second.second;
            if (assigned_b[bid] || assigned_o[o]) continue;
            assigned_b[bid] = true;
            assigned_o[o] = true;
            bridgemen[bid].Goal = orders[o].From;
        }
        // Recollect remaining free_b
        free_b.clear();
        for (int i = 0; i < B; ++i) {
            if (bridgemen[i].Goal == -1) {
                free_b.push_back(&bridgemen[i]);
            }
        }
        // If still multiple CCs and enough free, start a new connect task
        if (num_cc > 1 && free_b.size() >= 2) {
            vector<vector<Bridgeman*>> free_per_cc(num_cc);
            for (auto fb : free_b) {
                int poscc = cc_id[fb->Position];
                free_per_cc[poscc].push_back(fb);
            }
            int best_cost = INF;
            int best_ci = -1, best_cj = -1, best_a = -1, best_b = -1;
            Bridgeman* best_b1 = nullptr;
            Bridgeman* best_b2 = nullptr;
            for (int ci = 0; ci < num_cc; ++ci) {
                if (free_per_cc[ci].empty()) continue;
                for (int cj = ci + 1; cj < num_cc; ++cj) {
                    if (free_per_cc[cj].empty()) continue;
                    // Find min dist between cc_i and cc_j
                    int min_d = INF;
                    int cand_a = -1, cand_b = -1;
                    for (int u : cc_islands[ci]) {
                        for (int v : cc_islands[cj]) {
                            int dd = dists[u][v];
                            if (dd > 0 && dd < min_d && dd <= 2 * C) {
                                min_d = dd;
                                cand_a = u;
                                cand_b = v;
                            }
                        }
                    }
                    if (min_d == INF) continue;
                    // Find closest b1 in ci to cand_a
                    int min_c1 = INF;
                    Bridgeman* cand_b1 = nullptr;
                    for (auto bb : free_per_cc[ci]) {
                        int h = hop_dist[bb->Position][cand_a];
                        if (h < INF && h < min_c1) {
                            min_c1 = h;
                            cand_b1 = bb;
                        }
                    }
                    if (cand_b1 == nullptr) continue;
                    // Find closest b2 in cj to cand_b
                    int min_c2 = INF;
                    Bridgeman* cand_b2 = nullptr;
                    for (auto bb : free_per_cc[cj]) {
                        int h = hop_dist[bb->Position][cand_b];
                        if (h < INF && h < min_c2) {
                            min_c2 = h;
                            cand_b2 = bb;
                        }
                    }
                    if (cand_b2 == nullptr) continue;
                    // Check if can cover dist with their bricks
                    int dd = dists[cand_a][cand_b];
                    if (dd > bridgemen[cand_b1->ID].Bricks + bridgemen[cand_b2->ID].Bricks) continue;
                    int this_cost = min_c1 + min_c2 + 1;
                    if (this_cost < best_cost) {
                        best_cost = this_cost;
                        best_ci = ci;
                        best_cj = cj;
                        best_a = cand_a;
                        best_b = cand_b;
                        best_b1 = cand_b1;
                        best_b2 = cand_b2;
                    }
                }
            }
            if (best_cost < INF) {
                // Assign connect task
                best_b1->connect_target = best_a;
                best_b1->connect_partner = best_b2->ID;
                best_b1->Goal = best_a;
                best_b2->connect_target = best_b;
                best_b2->connect_partner = best_b1->ID;
                best_b2->Goal = best_b;
            }
        }
        // Collect actions for bridgemen with goals or ongoing bridges
        for (int i = 0; i < B; ++i) {
            auto& b = bridgemen[i];
            string action = "";
            if (b.BridgeTo != -1) {
                if (b.Position == b.BridgeFrom) {
                    action = "MOVE " + to_string(b.ID) + " " + to_string(b.BridgeTo);
                } else {
                    action = "PACK " + to_string(b.ID) + " " + to_string(b.BridgeFrom);
                    built[b.BridgeFrom][b.BridgeTo] = false;
                    built[b.BridgeTo][b.BridgeFrom] = false;
                    b.BridgeFrom = -1;
                    b.BridgeTo = -1;
                }
            } else {
                if (b.Goal == -1 || b.Position == b.Goal) continue;
                int next_t = get_next_on_path(b.Position, b.Goal);
                if (next_t == -1 || next_t == b.Position) continue;
                int fr = b.Position;
                int to_ = next_t;
                if (built[fr][to_]) {
                    action = "MOVE " + to_string(b.ID) + " " + to_string(to_);
                } else {
                    if (dists[fr][to_] > b.Bricks) continue;
                    action = "UNPACK " + to_string(b.ID) + " " + to_string(to_);
                    built[fr][to_] = true;
                    built[to_][fr] = true;
                    b.BridgeFrom = fr;
                    b.BridgeTo = to_;
                }
            }
            if (action != "") {
                output.push_back(action);
            }
        }
        // Output actions
        for (size_t k = 0; k < output.size(); ++k) {
            cout << output[k];
            if (k + 1 < output.size()) cout << "|";
        }
        cout << endl;
    }
    return 0;
}
