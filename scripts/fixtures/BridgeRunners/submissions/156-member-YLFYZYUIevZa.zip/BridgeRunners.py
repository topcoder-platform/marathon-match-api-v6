'''
java -jar tester.jar -exec "python BridgeRunners.py" -showOrders -delay 1 -seed 1
java -jar tester.jar -exec "python BridgeRunners.py" -novis -showOrders -delay 1 -seed 1

T = ターン数1000
N = 島の数 (25〜80)
B = bridgemen の数 (4〜20)
O = 同時に見える注文(order)の数 (4〜10)
D = 各島の距離行列

初期状態
    各bridgemanは橋材を50持っており、最大60まで持てる
    どの島にいるかはランダムだが、必ず移動できることは保証される

各ターンの入力
    B 行：各bridgemanの状態
        islandID:   現在地
        carry:      持っている橋材の長さ
        target:     配達先のメッセージがある場合はその島ID、なければ -1

    O 行：現在受注可能な注文
        orig:   メッセージを受け取るべき島
        dest:   配達先

各ターンの出力
    1行 "|" 区切りで出力
    命令フォーマット：
        "MOVE bridgemanID islandID":    既存の橋を渡って移動
        "UNPACK bridgemanID islandID":  現在地から islandID へ新しい橋を建設
        "PACK bridgemanID islandID":    現在地から islandID への橋を撤去
        "TEAMUNPACK bridgemanID1 bridgemanID2 length1": 
            2人のいる島間に橋を建設。1人目が length1 を、2人目が残りを担当
        "TEAMPACK bridgemanID1 bridgemanID2 length1":   
            2人のいる島間の橋を撤去。1人目が length1 を、2人目が残りを担当
        "MSG any":  |は含められない。最後のMSGだけが可視化される

補足:
    同一島から複数注文が出る場合は順番が固定
    ある島のbridgemanがメッセージを受け取った瞬間、新しい注文が即座に出現する場合がある
    同一島に複数のbridgemanがいて即時取得可能な場合はIDが最小のbridgemanが優先

考察:
    ソロ、ペアを固定もしくは動的に設定して行動する
    2人での橋の構築方式から、swap移動を想定している？
        同じ島に移動しても良いが、橋のが回収がアンバランスになりそう
            距離>60だと回収が不可能になる
        距離>60の島には誰か立っていないと2度と行けないことになる
            そのようなケースはあまり無い、最大でも70程度
                最終盤はその島を捨てる作戦もあり得る
                50より大きいパターンはあるので、持つ量に偏りが作れると良い
                    swapせずに橋材渡しを2ターンで行える操作と考える
            2度と行けない制約より、離れた場所をswapでワープできる使い方
    注文が随時公開されるため、モンテカルロで注文だけ探索？
        オーダーは単にランダムなため、出ているものだけ考慮でも良いか
    今持っているオーダーに対する最適行動はビムサが良さそう
    オーダーを取って目的地に行くまでの時間がオーダー自体の評価値
    盤面評価
        持っているオーダーに対して目的地までの距離
        オーダーを取りに行く時間
    1人で移動できる島を連結成分として捉える
        2人いないと連結成分を渡れない小島が生成される時がある
        連結成分内に1人はいる必要がある
            少ない連結成分に多くいる必要もない
    自分で橋を作らずに誰かに相乗りすることもできる
        橋材を最小限だけ持って移動だけする人も存在できる
        橋の常設方針の方が重要なのでは
            MSTの総コスト<=所持橋材総量の場合、そのように作ってしまえる
                島もエージェントも多い場合

    距離50以内のみで接続して連結成分を作る
    タスクを用意して割り当てられたらそれについて順番に動く
        1,オーダーを持っていれば完了位置へ動く
        2,フリーのエージェント間でタスク開始位置の割り当てをする
            オーダー開始位置へ動く
            フリーはマッチング待機
        エージェント同士をマッチングして、swapを狙う
            行き来したい連結成分が合致していたら優先
            それ以外はその場でswapが可能なら行う

    小さい連結成分に１つでもいれば、抜け出して橋回収して良い
        連結成分ごとに数を数えておく
        swap目的でない時に行う
    橋の状態管理を整理する
'''

import sys
from random import random, seed, randrange, choice, sample
from collections import deque, defaultdict, Counter
from heapq import heapify, heappush, heappop

N = int(input())    # 島の数
M = int(input())    # エージェント数
K = int(input())    # 表示オーダー数

# 距離行列
D = [[int(i) for i in input().split()] for _ in range(N)]

class DSU:
    def __init__(self, n):
        self._n = n
        self.parent_or_size = [-1] * n

    def merge(self, a, b):
        # assert 0 <= a < self._n
        # assert 0 <= b < self._n
        x, y = self.leader(a), self.leader(b)
        if x == y:
            return x
        if -self.parent_or_size[x] < -self.parent_or_size[y]:
            x, y = y, x
        self.parent_or_size[x] += self.parent_or_size[y]
        self.parent_or_size[y] = x
        return x

    def same(self, a, b):
        # assert 0 <= a < self._n
        # assert 0 <= b < self._n
        return self.leader(a) == self.leader(b)

    def leader(self, a):
        # assert 0 <= a < self._n
        stack = []
        while self.parent_or_size[a] >= 0:
            stack.append(a)
            a = self.parent_or_size[a]
        for i in stack:
            self.parent_or_size[i] = a
        return a

    def size(self, a):
        # assert 0 <= a < self._n
        return -self.parent_or_size[self.leader(a)]

    def groups(self):
        leader_buf = [self.leader(i) for i in range(self._n)]
        group_size = [0] * self._n
        for i in leader_buf:
            group_size[i] += 1
        result = [[] for _ in range(self._n)]
        for i in range(self._n):
            result[leader_buf[i]].append(i)
        result = [i for i in result if i]
        return result

class Agent:
    def __init__(self, id):
        self.id = id
        self.pos = 0
        self.target = 0
        self.bricks = 0
        self.nxt = -1
        self.prv = -1

    def __repr__(self):
        return f"Agent(id: {self.id}, pos: {self.pos}, target: {self.target}, bricks: {self.bricks})"

class Order:
    def __init__(self, frm, to):
        self.frm = frm
        self.to = to

    def __repr__(self):
        return f"Order(frm: {self.frm}, to: {self.to})"

class Solver:
    def __init__(self):
        self.elapsedTime = 0
        self.make_graph()
        self.make_group()
        self.make_costs()
        self.agents = [Agent(i) for i in range(M)]
        self.orders = [Order(0, 0) for _ in range(K)]
        self.bridges = [[0]*N for _ in range(N)]        # 0:なし, 1:あり, 2:使用される
        self.pair = [[i] for i in range(M)]
        self.cancel_pair = []

    def make_graph(self):   # 距離100以内のグラフ作成
        self.graph = [[] for _ in range(N)]
        for i in range(N):
            for j in range(N):
                if i==j: continue
                if D[i][j]>100: continue
                self.graph[i].append((j, D[i][j]))

    def make_group(self):   # 連結成分グループ分け構築
        self.uf = DSU(N)
        for i in range(N-1):
            for j in range(i+1, N):
                if D[i][j]>50: continue
                if self.uf.same(i, j): continue
                self.uf.merge(i, j)
                
        groups = self.uf.groups()
        leaders = [self.uf.leader(g[0]) for g in groups]

        self.group_pair = dict()    # 連結成分を渡れる島の組み合わせ
        for i in range(len(leaders)-1):
            a = leaders[i]
            for j in range(i+1, len(leaders)):
                b = leaders[j]
                self.group_pair[(a, b)] = []
                self.group_pair[(b, a)] = []
                for u in groups[i]:
                    for v, w in self.graph[u]:
                        if self.uf.leader(v)!=b: continue
                        self.group_pair[(a, b)].append((u, v))
                        self.group_pair[(b, a)].append((v, u))
        # print(self.group_pair, file=sys.stderr)
        
        # 連結成分のグラフと距離
        self.group_graph = [[] for _ in range(N)]
        self.group_dist = [[100]*N for _ in range(N)]
        for a in leaders:
            for b in leaders:
                if a==b: continue
                if len(self.group_pair[(a, b)])==0: continue
                self.group_graph[a].append(b)

        for s in leaders:
            self.group_dist[s][s] = 0
            q = deque()
            q.append(s)
            while q:
                u = q.popleft()
                for v in self.group_graph[u]:
                    if self.group_dist[s][v]<100: continue
                    self.group_dist[s][v] = self.group_dist[s][u]+1
                    q.append(v)

    def make_costs(self):   # 最短経路計算用
        self.costs = [[10000 for _ in range(N)] for _ in range(N)]
        for s in range(N):
            self.costs[s][s] = 0
            hq = []
            heappush(hq, (0, s))
            while hq:
                d, u = heappop(hq)
                if self.costs[s][u]<d: continue
                for v, w in self.graph[u]:
                    if self.uf.same(u, v)==False:   # 連結成分が別
                        a = self.uf.leader(u)
                        b = self.uf.leader(v)
                        # print((a, b), (u, v), self.group_pair[(a, b)], file=sys.stderr)
                        if self.group_pair[(a, b)][0] != (u, v):  continue
                    add = 1 if w<=50 else 100
                    if self.costs[s][v] > d+add:
                        self.costs[s][v] = d+add
                        heappush(hq, (self.costs[s][v], v))

    def input_process(self):    # 入力処理
        self.elapsedTime = int(input())
        for a in self.agents:
            a.pos, a.bricks, a.target = [int(i) for i in input().split()]

        for order in self.orders:
            order.frm, order.to = list(map(int, input().split()))

    def matching_order(self):   # オーダー起点とエージェントのマッチング
        free = [a for a in self.agents if a.target<0]

        edges = []  # エージェントとオーダー開始位置, 最悪でも200組
        for i in range(len(free)):
            pos = free[i].pos
            for j in range(len(self.orders)):
                frm = self.orders[j].frm
                to = self.orders[j].to
                edges.append((self.costs[frm][pos], i, j))
                # edges.append((self.costs[frm][pos]+self.costs[frm][to]//2, i, j))
        edges.sort()
        used = set()
        for c, i, j in edges:
            if free[i].target>=0: continue
            if j in used: continue
            free[i].target = self.orders[j].frm
            used.add(j)

        for agent in self.agents:
            a = self.uf.leader(agent.pos)
            b = self.uf.leader(agent.target)
            if a==b: continue
            if self.group_dist[a][b]>1:     # 直接行き来出来ない場合
                best = self.group_dist[b][a]
                for v in self.group_graph[a]:
                    if best>self.group_dist[b][v]:
                        best = self.group_dist[b][v]
                        agent.target = v
        
            # print(c, free[i].pos, self.orders[j].frm, file=sys.stderr)

    def matching_agent(self):   # エージェント同士のマッチング
        # self.pair = [[i] for i in range(M)]

        for i in range(len(self.pair))[::-1]:   # 既存のペア解消判定
            if len(self.pair[i])==1: continue
            if self.pair[i][0] not in self.cancel_pair: continue
            self.pair.append([self.pair[i].pop()])
        self.cancel_pair = []
                    
        for _ in range(M):  # 連結成分を移動したいエージェント同士のマッチング
            best = 200
            bi, bj = -1, -1
            for i in range(len(self.pair)-1, 0, -1):
                if len(self.pair[i])>=2: continue
                if self.agents[self.pair[i][0]].target<0: continue
                agent1 = self.agents[self.pair[i][0]]
                frm1 = self.uf.leader(agent1.pos)
                to1 = self.uf.leader(agent1.target)
                if frm1==to1: continue
                for j in range(i-1, -1, -1):
                    if len(self.pair[j])>=2: continue
                    if self.agents[self.pair[j][0]].target<0: continue
                    agent2 = self.agents[self.pair[j][0]]
                    frm2 = self.uf.leader(agent2.pos)
                    to2 = self.uf.leader(agent2.target)
                    if frm2==to2: continue
                    if to1!=frm2: continue      # 行きたい連結成分にいるか
                    if self.group_dist[frm1][frm2]>1: continue
                    if frm1==to2 and frm2==to1 and best>self.costs[agent1.pos][agent2.pos]:
                        best = self.costs[agent1.pos][agent2.pos]
                        bi, bj = i, j
            if bi>=0:
                self.pair[bj].append(self.pair[bi][0])
                self.pair[bi] = self.pair[-1]
                self.pair.pop()
            else: break

        for _ in range(M):  # 連結成分を移動したいエージェント優先
            best = 200
            bi, bj = -1, -1
            for i in range(len(self.pair)):
                if len(self.pair[i])>=2: continue
                agent1 = self.agents[self.pair[i][0]]
                frm1 = self.uf.leader(agent1.pos)
                to1 = self.uf.leader(agent1.target)
                if frm1==to1: continue
                for j in range(len(self.pair)):
                    if i==j: continue
                    if len(self.pair[j])>=2: continue
                    agent2 = self.agents[self.pair[j][0]]
                    frm2 = self.uf.leader(agent2.pos)
                    to2 = self.uf.leader(agent2.target) if agent2.target>=0 else -1
                    if frm2==to2: continue
                    if to1!=frm2: continue      # 行きたい連結成分にいるか
                    # if self.group_dist[frm1][frm2]>1: continue
                    if best>self.costs[agent1.pos][agent2.pos]:
                        best = self.costs[agent1.pos][agent2.pos]
                        bi, bj = i, j
            if bi>=0:
                self.pair[bj].append(self.pair[bi][0])
                self.pair[bi] = self.pair[-1]
                self.pair.pop()
            else: break

        for _ in range(M):  # 連結成分内で即時2人橋でswap
            best = -2
            bi, bj = -1, -1
            for i in range(len(self.pair)):
                if len(self.pair[i])>=2: continue
                agent1 = self.agents[self.pair[i][0]]
                if agent1.prv>=0: continue
                frm1 = self.uf.leader(agent1.pos)
                to1 = self.uf.leader(agent1.target)
                for j in range(len(self.pair)):
                    if i==j: continue
                    if len(self.pair[j])>=2: continue
                    agent2 = self.agents[self.pair[j][0]]
                    if agent2.prv>=0: continue
                    if D[agent1.pos][agent2.pos]<=50: continue
                    if D[agent1.pos][agent2.pos]>100: continue
                    frm2 = self.uf.leader(agent2.pos)
                    to2 = self.uf.leader(agent2.target) if agent2.target>=0 else frm2
                    if frm1!=frm2: continue
                    # if self.group_dist[frm1][frm2]>1: continue
                    # お互い距離が縮む時のみ連結成分内swap
                    if self.costs[agent1.target][agent2.pos]>=self.costs[agent1.target][agent1.pos]: continue
                    if self.costs[agent2.target][agent1.pos]>=self.costs[agent2.target][agent2.pos]: continue
                    score = 0
                    score += self.costs[agent1.target][agent2.pos]-self.costs[agent1.target][agent1.pos]
                    score += self.costs[agent2.target][agent1.pos]-self.costs[agent2.target][agent2.pos]
                    if best>score:
                        best = score
                        bi, bj = i, j
            if bi>=0:
                self.pair[bj].append(self.pair[bi][0])
                self.pair[bi] = self.pair[-1]
                self.pair.pop()
            else: break

        # 橋の数でソート
        self.pair.sort(key=lambda x: sum(int(self.agents[i].prv>=0) for i in x))

        # print(self.pair, file=sys.stderr)

    def solo_action(self, x):
        # print("solo_action", x, file=sys.stderr)
        agent = self.agents[x]
        frm = self.uf.leader(agent.pos)
        to = self.uf.leader(agent.target)
        
        bv = -1     # 次移動したい島
        if agent.target>=0:     # 目的地が無い場合処理しない
            if frm!=to:     # 隣接へ行くために近づいておく
                target1, target2 = self.group_pair[(frm, to)][0]
                if agent.pos==target1:
                    agent.target = target2
                else:
                    agent.target = target1
            best = self.costs[agent.target][agent.pos]
            for v, w in self.graph[agent.pos]:
                if w > agent.bricks and self.bridges[agent.pos][v]==0: continue
                # if self.costs[agent.target][v]==self.costs[agent.target][agent.pos]: continue
                if best > self.costs[agent.target][v]:
                    best = self.costs[agent.target][v]
                    bv = v
                    
        # 自分が作った橋をそのまま帰れば良いパターン
        if agent.prv>=0 and agent.prv==bv:
            agent.prv, agent.nxt = agent.nxt, agent.prv
        # 自分の橋が経路でない時は回収する
        if agent.nxt>=0 and agent.nxt!=bv: bv = -1
        if bv<0: 
            if agent.prv<0 and agent.nxt<0: return
            if agent.nxt!=agent.pos:    # 橋を架けていて渡る前
                if self.bridges[agent.pos][agent.nxt]>=2: return
                self.output.append(f"PACK {agent.id} {agent.nxt}")
                self.bridges[agent.pos][agent.nxt] = 0
                self.bridges[agent.nxt][agent.pos] = 0
                agent.bricks += D[agent.pos][agent.nxt]
                agent.nxt = -1
                agent.prv = -1
            else:               # 橋を架けていて渡った後
                if self.bridges[agent.pos][agent.prv]>=2: return
                self.output.append(f"PACK {agent.id} {agent.prv}")
                self.bridges[agent.pos][agent.prv] = 0
                self.bridges[agent.prv][agent.pos] = 0
                agent.bricks += D[agent.pos][agent.prv]
                agent.nxt = -1
                agent.prv = -1
            return
            
        if self.bridges[agent.pos][bv]>=1 and (agent.nxt<0 or agent.nxt==bv):
            self.output.append(f"MOVE {agent.id} {bv}")
            # self.bridges[agent.pos][bv] = 2
            # self.bridges[bv][agent.pos] = 2
            self.cancel_pair.append(x)
            return

        # 橋を架ける
        agent.prv = agent.pos
        agent.nxt = bv
        self.output.append(f"UNPACK {agent.id} {agent.nxt}")
        self.bridges[agent.pos][agent.nxt] = 1
        self.bridges[agent.nxt][agent.pos] = 1
        agent.bricks -= D[agent.pos][agent.nxt]

    def pair_action(self, x, y):
        # print("pair_action", x, y, file=sys.stderr)
        agent1 = self.agents[x]
        agent2 = self.agents[y]

        # 二人で架けた橋の撤去
        if (self.bridges[agent1.pos][agent2.pos]==1 and 
                agent1.prv==agent2.pos and agent2.prv==agent1.pos):
            self.output.append(f"TEAMPACK {agent1.id} {agent2.id} {50-agent1.bricks}")
            self.bridges[agent1.pos][agent2.pos] = 0
            self.bridges[agent2.pos][agent1.pos] = 0
            agent2.bricks = 50
            agent1.bricks = 50
            agent1.prv = -1
            agent2.prv = -1
            agent1.nxt = -1
            agent2.nxt = -1
            self.cancel_pair.append(x)
            self.cancel_pair.append(y)
            return

        target1, target2 = agent1.pos, agent2.pos
        if self.uf.leader(agent1.pos)!=self.uf.leader(agent2.pos):
            target1, target2 = self.group_pair[(self.uf.leader(agent1.pos), self.uf.leader(agent2.pos))][0]
        # print(target1, target2, file=sys.stderr)
        if agent1.pos!=target1 or agent2.pos!=target2:  # 連結成分を渡るための場所へ各自移動
            # if agent1.target<0 or agent2.target<0:  # 片方がフリー
            #     self.cancel_pair.append(x)
            #     self.cancel_pair.append(y)
            agent1.target = target1
            agent2.target = target2
            self.solo_action(x)
            self.solo_action(y)
            return
            
        # swap地点で最後の橋撤去処理
        if (agent1.nxt>=0 and agent1.nxt!=agent2.pos) or (agent2.nxt>=0 and agent2.nxt!=agent1.pos):
            agent1.target = target1
            agent2.target = target2
            self.solo_action(x)
            self.solo_action(y)
            return
        
        # 橋がある
        if self.bridges[agent1.pos][agent2.pos]>=1:
            # self.bridges[agent1.pos][agent2.pos] = 2
            # self.bridges[agent2.pos][agent1.pos] = 2
            self.output.append(f"MOVE {agent1.id} {agent2.pos}")
            self.output.append(f"MOVE {agent2.id} {agent1.pos}")
            if agent1.prv<0:
                self.cancel_pair.append(x)
                self.cancel_pair.append(y)
            return

        # 二人で橋を作る
        agent1.prv = agent1.pos
        agent1.nxt = agent2.pos
        agent2.prv = agent2.pos
        agent2.nxt = agent1.pos
        self.output.append(f"TEAMUNPACK {agent1.id} {agent2.id} {agent1.bricks}")
        self.bridges[agent1.pos][agent2.pos] = 1
        self.bridges[agent2.pos][agent1.pos] = 1
        agent2.bricks -= D[agent1.pos][agent2.pos]-agent1.bricks
        agent1.bricks -= agent1.bricks

    def action(self):
        self.output = []
        for pair in self.pair:
            if len(pair)>=2:   # 連結成分を跨ぐペア
                self.pair_action(pair[0], pair[1])
            else:
                self.solo_action(pair[0])

    def post_processing(self):
        for i in range(N):
            for j in range(N):
                if self.bridges[i][j]>=2:
                    self.bridges[i][j] = 1

def main():
    solver = Solver()

    for turn in range(1000):
        solver.input_process()
        solver.matching_order()
        solver.matching_agent()
        solver.action()
        # solver.post_processing()
        
        # solver.output.append(f"MSG {','.join(map(str, solver.pair))}")
        print(" | ".join(solver.output))
        # print(" | ".join(solver.output), file=sys.stderr)

if __name__ == "__main__":
    main()