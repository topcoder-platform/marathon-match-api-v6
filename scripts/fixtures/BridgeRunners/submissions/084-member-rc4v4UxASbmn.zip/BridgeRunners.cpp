#pragma GCC optimize "-O3,omit-frame-pointer,inline,unroll-all-loops,fast-math"
#pragma GCC target "tune=native"

#include <algorithm>
#include <array>
#include <bitset>
#include <cassert>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits>
#include <list>
#include <map>
#include <memory>
#include <optional>
#include <queue>
#include <random>
#include <set>
#include <sstream>
#include <stack>
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <vector>

bool isTopCoder = true;

// -------------------------------------------------------------- #1 BOLIERPLATE ------------------------------
#define F0(i, n) for (int i = 0; i < n; i++)
#define FR(i, n) for (int i = n - 1; i >= 0; i--)
#define F1(i, n) for (int i = 1; i <= n; i++)
#define FI(i, j, n) for (int j = i + 1; j < n; j++)
#define CL(a, x) memset(x, a, sizeof(x));
#define SZ(x) ((int)x.size())
#define ASZ(x) sizeof(x);
const float pi = acos(-1.0);
const int inf = 1000000000;
const float MAXD = 100000000000.0;
typedef long long ll;
typedef unsigned long long ull;
const float EPS = 1e-9;

//@see https://stackoverflow.com/questions/33333363/built-in-mod-vs-custom-mod-function-improve-the-performance-of-modulus-op/33333636#33333636
inline size_t fast_mod(const size_t i, const size_t c) { return i >= c ? i % c : i; }

using namespace std;
string resDir = "/Users/erikkvanli/Downloads/tests/resDir";
string resFileName = "";

struct Stopwatch {
  float TIME_LIMIT;
  chrono::high_resolution_clock::time_point start_time;

  Stopwatch(const float TIME_LIMIT = 1) : TIME_LIMIT(TIME_LIMIT * 1000000LL), start_time(chrono::high_resolution_clock::now()) {}

  int64_t elapsed_nanoseconds() const { return chrono::duration_cast<chrono::nanoseconds>(chrono::high_resolution_clock::now() - start_time).count(); }

  int64_t elapsed_milliseconds() const { return chrono::duration_cast<chrono::milliseconds>(chrono::high_resolution_clock::now() - start_time).count(); }

  float elapsed_fraction() const { return static_cast<float>(elapsed_nanoseconds()) / TIME_LIMIT; }

  bool timeout() const { return elapsed_nanoseconds() >= TIME_LIMIT; }
};

struct XRand {
  u_int32_t val;

  XRand(const u_int32_t v = 643263) : val(v) {}

  u_int32_t xorshift32() {
    val ^= val << 13;
    val ^= val >> 17;
    val ^= val << 5;
    return val;
  }

  u_int64_t next(const int m) { // [0, m)
    return static_cast<u_int64_t>(xorshift32()) * m >> 32;
  }

  float nextfloat() { // [0, 1)
    return static_cast<float>(xorshift32()) / (static_cast<u_int64_t>(1) << 32);
  }
};
XRand rnd;

bool fileExists(const string &filename) {
  ifstream file(filename);
  return file.good();
}

ofstream file;

int sign(int val) {
  if (val == 0)
    return 0;
  if (val < 0)
    return -1;
  return 1;
}

string filename = "/Users/erikkvanli/Downloads/ac32/0000.txt";
bool isLocal = fileExists(filename);

// -------------------------------------------------------------- #1 VARIABLES ------------------------------
// unordered_set<uint64_t> seen;
// unordered_map<uint64_t, int> mapSeen;
int forcedSeed = 0, evals = 0;
string seed = "-1";

// -------------------------------------------------------------- #2 CONSTANTS ------------------------------
const int MaxN = 80, MaxNN = MaxN * MaxN, NOTARGET = -1337, MaxCapacity = 60, MaxB = 20;

// -------------------------------------------------------------- #3 SIM ------------------------------------

struct Order {
  int from, to;
  bool claimed;
  bool wanted;
};

struct FinalAction {
  int type = 0;
  int b1 = 0;
  int b2 = 0;
  int length = 0;
};

struct ForcedAction {
  bool move;
  int from;
  int to;
};

struct Bridgeman {
  int id;
  int pos;
  int target = NOTARGET;
  bool noMessage = false;
  int bridge;
  int lastBuilt = -1;
  bool hasMoved = false;
  int otherBuilder = -1;

  // Saved after search used to reset
  int _lastBuilt = -1;
  bool _hasMoved = false;
  int _otherBuilder = -1;

  // Best found
  int _bestLastBuilt = -1;
  bool _bestHasMoved = false;
  int _bestOtherBuilder = -1;

  // During search
  int _cachedLastBuilt = -1;
  bool _cachedHasMoved = false;
  int _cachedOtherBuilder = -1;
};

vector<float> trainedValues;
vector<vector<float>> tv;
int N, B, O;
bitset<MaxN> visited;
vector<vector<int>> randomOrders;
vector<vector<int>> randomOOrders;

const int DijkstraSize = MaxN;
float dists[DijkstraSize * DijkstraSize];
int realDists[DijkstraSize * DijkstraSize];
bool connected[MaxN * MaxN]{false};
vector<int> neighbours[MaxN]{vector<int>()};
vector<int> searchNeigbours[MaxN]{vector<int>()};
Bridgeman bridgemen[20];
int minDists[MaxN];
int segmentMap[MaxN];
vector<vector<int>> segments;
Order orders[10];
int maxDepth = 6;

inline int getBuiltHash(int from, int to) { return (from < to) ? from + to * N : to + from * N; }

inline float &getDist(int from, int to) { return dists[from + to * DijkstraSize]; }

inline int &getRealDist(int from, int to) { return realDists[from + to * DijkstraSize]; }

struct DijkstraQueue {
  int x;
  float dist;
};

void dijkstra(int startX) {
  vector<DijkstraQueue> queue = {{startX, 1}};
  int amount = 0, idx = startX;
  getDist(idx, idx) = 0;
  while (queue.size() > 0) {
    vector<DijkstraQueue> next;
    F0 (i, queue.size()) {
      auto item = queue[i].x;
      F0 (neig, searchNeigbours[item].size()) {
        int j = searchNeigbours[item][neig];
        float depthAddon = 1;
        if (getRealDist(j, item) > 50)
          depthAddon = 5;

        float depth = queue[i].dist + depthAddon;
        int idx2 = j;
        if (getDist(idx, idx2) <= depth)
          continue; // faster paths exist
        getDist(idx, idx2) = depth;
        next.push_back({j, depth});
        amount++;
      }
    }

    queue = next;
  }
}

void initializeDistances() { // vector<vector<float>> &heatMap
  for (int i = 0; i < DijkstraSize; ++i) {
    for (int j = 0; j < DijkstraSize; ++j) {
      getDist(i, j) = inf;
    }
  }

  for (int x = 0; x < DijkstraSize; x++) {
    dijkstra(x);
  }
}

// -------------------------------------------------------------- #4 SEGMENTS ------------------------------------

void findSubSegments(bitset<MaxN> &seen, int id) {
  queue<int> viewport;
  viewport.push(id);
  vector<int> segment;
  while (viewport.size() > 0) {
    int first = viewport.front();
    segmentMap[first] = segments.size();
    segment.emplace_back(first);
    viewport.pop();
    F0 (i, neighbours[first].size()) {
      int &neig = neighbours[first][i];
      if (seen.test(neig))
        continue;
      if (getRealDist(neig, first) > 50)
        continue;
      viewport.push(neig);
      seen.set(neig);
    }
  }

  segments.emplace_back(segment);
}

void findSegements() {
  bitset<MaxN> seen;
  F0 (i, N) {
    if (seen.test(i))
      continue;
    findSubSegments(seen, i);
  }

  F0 (i, N) {
    F0 (j, neighbours[i].size()) {
      int &neig = neighbours[i][j];
      if (getRealDist(i, neig) > 50)
        continue;
      searchNeigbours[i].emplace_back(neig);
    }
  }

  cerr << "Set up segments: " << segments.size() << endl;

  // Find dists between segments
  F0 (i, segments.size()) {
    for (int j = i + 1; j < segments.size(); j++) {
      int a = -1;
      int b = -1;
      int bestDist = 1000;
      F0 (k, segments[i].size()) {
        F0 (l, segments[j].size()) {
          int d = getRealDist(segments[i][k], segments[j][l]);
          if (d < bestDist) {
            a = segments[i][k];
            b = segments[j][l];
            bestDist = d;
          }
        }
      }
      if (bestDist <= 100) {
        searchNeigbours[a].emplace_back(b);
        searchNeigbours[b].emplace_back(a);
      }
    }
  }
}

// -------------------------------------------------------------- #4 STATE ------------------------------------

struct State {
  Bridgeman stateMen[MaxB]{};
  Order stateOrders[10]{};
  bool stateConnected[MaxN * MaxN]{false};
  int delivered = 0;
  int depth = 0;
  int score = 0;
  bitset<MaxB> usedMen;
  vector<FinalAction> actions;

  int getUnclaimedOrder(int from) {
    int target = rnd.next(O);
    float bestD = inf;
    auto &order = randomOOrders[rnd.next(randomOOrders.size())];
    for (int i : order) {
      if (trainedValues[0] && stateOrders[i].wanted)
        continue;
      if (!stateOrders[i].claimed) {
        float d = getDist(stateOrders[i].from, from) - getDist(stateOrders[i].from, stateOrders[i].to) / (max(0.1, 200.0 * trainedValues[2]));
        if (d < bestD) {
          bestD = d;
          target = i;
        }
      }
    }
    if (stateOrders[target].wanted || stateOrders[target].claimed) {
      bestD = inf;
      for (int i : order) {
        if (!stateOrders[i].claimed) {
          float d = getDist(stateOrders[i].from, from) - getDist(stateOrders[i].from, stateOrders[i].to) / (max(0.1, 200.0 * trainedValues[2]));
          if (d < bestD) {
            bestD = d;
            target = i;
          }
        }
      }
    }
    stateOrders[target].wanted = true;
    return stateOrders[target].from;
  }

  bool canDualBuildBridge(int &from, int &to, int &bridge, int &bridge2, int length) { return getRealDist(from, to) <= length + bridge2; }

  bool canDualPackBridge(int &from, int &to, int &bridge, int &bridge2, int length) { return bridge + length <= MaxCapacity && bridge2 + getRealDist(from, to) - length <= MaxCapacity; }

  bool canPotentialDualBuildBridge(int &from, int &to, int &bridge) { return !stateConnected[from + to * N] && getRealDist(from, to) <= bridge + 60 && getRealDist(from, to) > bridge; }

  bool canPotentialDualPackBridge(int &from, int &to, int &bridge) { return stateConnected[from + to * N] && getRealDist(from, to) + bridge <= MaxCapacity + 60 && getRealDist(from, to) + bridge > MaxCapacity; }

  bool canSoloBuildBridge(int &from, int &to, int &bridge) { return !stateConnected[from + to * N] && getRealDist(from, to) <= bridge; }

  bool canSoloPackBridge(int &from, int &to, int &bridge) { return stateConnected[from + to * N] && getRealDist(from, to) + bridge <= MaxCapacity; }

  void addDualBridge(int from, int to, int &bridge, int &bridge2, int length) {
    stateConnected[from + to * N] = true;
    stateConnected[to + from * N] = true;
    bridge -= length;
    bridge2 -= getRealDist(from, to) - length;
  }

  void removeDualBridge(int from, int to, int &bridge, int &bridge2, int length) {
    stateConnected[from + to * N] = false;
    stateConnected[to + from * N] = false;
    bridge += length;
    bridge2 += getRealDist(from, to) - length;
  }

  void addBridge(int from, int to, int &bridge) {
    stateConnected[from + to * N] = true;
    stateConnected[to + from * N] = true;
    bridge -= getRealDist(from, to);
  }

  void removeBridge(int from, int to, int &bridge) {
    stateConnected[from + to * N] = false;
    stateConnected[to + from * N] = false;
    bridge += getRealDist(from, to);
  }

  inline bool canMove(int from, int to) { return stateConnected[from + to * N]; }

  void setAfterSearch() {
    F0 (i, B) {
      stateMen[i]._hasMoved = stateMen[i]._bestHasMoved;
      stateMen[i]._lastBuilt = stateMen[i]._bestLastBuilt;
      stateMen[i]._otherBuilder = stateMen[i]._bestOtherBuilder;
    }
  }

  void setBest() {
    F0 (i, B) {
      stateMen[i]._bestHasMoved = stateMen[i]._cachedHasMoved;
      stateMen[i]._bestLastBuilt = stateMen[i]._cachedLastBuilt;
      stateMen[i]._bestOtherBuilder = stateMen[i]._cachedOtherBuilder;
    }
  }

  void saveCache() {
    F0 (i, B) {
      stateMen[i]._cachedHasMoved = stateMen[i].hasMoved;
      stateMen[i]._cachedLastBuilt = stateMen[i].lastBuilt;
      stateMen[i]._cachedOtherBuilder = stateMen[i].otherBuilder;
    }
  }

  void reset() {
    F0 (i, O) {
      stateOrders[i].claimed = false;
      stateOrders[i].from = orders[i].from;
      stateOrders[i].to = orders[i].to;
      stateOrders[i].wanted = false;
    }
    actions.clear();
    depth = 0;
    score = 0;
    delivered = 0;
    F0 (i, N) {
      F0 (j, neighbours[i].size()) {
        stateConnected[i + neighbours[i][j] * N] = connected[i + neighbours[i][j] * N];
      }
    }
    F0 (i, B) {
      stateMen[i].hasMoved = stateMen[i]._hasMoved;
      stateMen[i].lastBuilt = stateMen[i]._lastBuilt;
      stateMen[i].otherBuilder = stateMen[i]._otherBuilder;
      stateMen[i].id = bridgemen[i].id;
      stateMen[i].bridge = bridgemen[i].bridge;
      stateMen[i].pos = bridgemen[i].pos;
      stateMen[i].target = bridgemen[i].target;
      stateMen[i].noMessage = bridgemen[i].target < 0;
      // cerr << "Set target: " << i << " t: " << stateMen[i].target << endl;
    }
  }

  void afterTurn() {
    bool useSet = false;
    F0 (i, B) {
      if (stateMen[i].pos == stateMen[i].target) {
        ++delivered;
        score += 1;
        useSet = true;
        stateMen[i].noMessage = true;
      }

      if (stateMen[i].noMessage) {
        F0 (j, O) {
          if (!stateOrders[j].claimed && stateOrders[j].from == stateMen[i].pos) {
            stateMen[i].target = stateOrders[j].to;
            stateMen[i].noMessage = false;
            stateOrders[j].claimed = true;
            break;
          }
        }
      }
    }
    if (useSet && depth != maxDepth - 1) {
      setTargets();
    }
    if (depth == 0) {
      saveCache();
    }
    ++depth;
  }

  void doRandomWait() {
    F0 (i, B) {
      if (usedMen.test(i))
        continue;
      if (stateMen[i].otherBuilder >= 0)
        continue; // Has to pack
      if (!stateMen[i].hasMoved)
        continue;
      if (stateMen[i].lastBuilt < 0)
        continue;
      if (rnd.nextfloat() < 0.05) {
        usedMen.set(i);
      }
    }
  }

  void moveCloser(bool allowSame) {
    F0 (i, B) {
      if (usedMen.test(i))
        continue;
      if (stateMen[i].otherBuilder >= 0 && stateMen[i].hasMoved)
        continue; // Has to pack
      int &pos = stateMen[i].pos;
      int bestD = getDist(pos, stateMen[i].target);
      int bestTarget = -1;
      // if (stateMen[i].otherBuilder >= 0)
      //   cerr << "ID: " << i << " OB:" << stateMen[i].otherBuilder << " MOV: " << stateMen[i].hasMoved << " LB: " << stateMen[i].lastBuilt << endl;
      F0 (j, neighbours[pos].size()) {
        int &nxt = neighbours[pos][j];
        // if (stateMen[i].otherBuilder >= 0 && getBuiltHash(pos, nxt) == stateMen[i].lastBuilt)
        //   cerr << "Should be good? " << stateMen[i].lastBuilt << " ABOVE: " << (stateMen[i].lastBuilt >= 0) << endl;
        if (!canMove(pos, nxt))
          continue;

        if (stateMen[i].lastBuilt >= 0 && getBuiltHash(pos, nxt) != stateMen[i].lastBuilt)
          continue;
        int d = getDist(nxt, stateMen[i].target);
        if (d < bestD || allowSame && d == bestD && rnd.nextfloat() < 0.1 || getBuiltHash(pos, nxt) == stateMen[i].lastBuilt && !stateMen[i].hasMoved || stateMen[i].otherBuilder >= 0) {
          bestD = d;
          bestTarget = nxt;
        }
      }
      if (bestTarget >= 0) {
        if (depth == 0) { // Same location move == WAIT
          actions.emplace_back(FinalAction({0, i, bestTarget, 0}));
        }
        // cerr << "Moving: " << i << " FROM POS: " << stateMen[i].pos << " TO POS: " << bestTarget << " PD: " << getDist(pos, stateMen[i].target) << " ND: " << bestD << " Target: " << stateMen[i].target << endl;
        stateMen[i].pos = bestTarget;
        usedMen.set(i);
        stateMen[i].hasMoved = true;
        // if (getBuiltHash(pos, bestTarget) == stateMen[i].lastBuilt) {
        // }
      }
    }
  }

  bool doBuild() {
    auto &order = randomOrders[rnd.next(randomOrders.size())];
    for (int i : order) {
      if (usedMen.test(i))
        continue;
      if (stateMen[i].lastBuilt >= 0)
        continue;
      int &pos = stateMen[i].pos;
      int bestD = getDist(pos, stateMen[i].target);
      int bestTarget = -1;
      F0 (j, searchNeigbours[pos].size()) {
        int &nxt = searchNeigbours[pos][j];
        if (!canSoloBuildBridge(pos, nxt, stateMen[i].bridge))
          continue;
        int d = getDist(nxt, stateMen[i].target);
        if (d < bestD || d < getDist(pos, stateMen[i].target) && rnd.nextfloat() < 0.5 && d == bestD) {
          bestD = d;
          bestTarget = nxt;
        }
      }
      if (bestTarget >= 0) {
        addBridge(pos, bestTarget, stateMen[i].bridge);
        stateMen[i].lastBuilt = getBuiltHash(pos, bestTarget);
        stateMen[i].hasMoved = false;
        usedMen.set(i);
        if (depth == 0) {
          actions.emplace_back(FinalAction({1, i, bestTarget, 0}));
        }

        return true;
      }
    }

    return false;
  }

  bool doDualBuild() {
    auto &order = randomOrders[rnd.next(randomOrders.size())];
    auto &order2 = randomOrders[rnd.next(randomOrders.size())];
    for (int i : order) {
      if (usedMen.test(i))
        continue;
      if (stateMen[i].lastBuilt >= 0)
        continue;
      int &pos = stateMen[i].pos;
      int bestD = getDist(pos, stateMen[i].target);
      int bestTarget = -1;
      int bestOther = -1;

      for (int j : order2) {
        int &nxt = stateMen[j].pos;
        if (j == i)
          continue;
        if (stateMen[j].lastBuilt >= 0)
          continue;
        if (usedMen.test(j))
          continue;
        if (getRealDist(pos, nxt) <= 50)
          continue;
        // if (getDist(pos, nxt) <= 100)
        //   continue;
        if (!canPotentialDualBuildBridge(pos, nxt, stateMen[i].bridge))
          continue;
        if (!canDualBuildBridge(pos, nxt, stateMen[i].bridge, stateMen[j].bridge, stateMen[i].bridge))
          continue;

        int otherBestD = getDist(nxt, stateMen[j].target);
        int otherD = getDist(pos, stateMen[j].target);

        int d = getDist(nxt, stateMen[i].target);
        if (d < bestD + (getDist(pos, nxt) <= 100 ? -rnd.next(3) : 1) && (otherD <= otherBestD + (getDist(pos, nxt) <= 100 ? -rnd.next(3) : 1) || rnd.nextfloat() < 0.1 * trainedValues[3])) {
          bestD = d;
          bestTarget = nxt;
          bestOther = j;
        }
      }
      if (bestTarget >= 0) {
        if (depth == 0) {
          actions.emplace_back(FinalAction({3, i, bestOther, 50}));
        }

        addDualBridge(pos, bestTarget, stateMen[i].bridge, stateMen[bestOther].bridge, 50);

        stateMen[i].lastBuilt = getBuiltHash(pos, bestTarget);
        stateMen[bestOther].lastBuilt = getBuiltHash(pos, bestTarget);
        stateMen[i].otherBuilder = bestOther;
        stateMen[i].hasMoved = false;
        stateMen[bestOther].otherBuilder = i;
        stateMen[bestOther].hasMoved = false;
        usedMen.set(i);
        usedMen.set(bestOther);

        return true;
      }
    }

    return false;
  }

  void packBridges() {
    F0 (i, B) {
      if (usedMen.test(i))
        continue;
      if (stateMen[i].lastBuilt < 0)
        continue;

      int &pos = stateMen[i].pos;
      F0 (j, searchNeigbours[pos].size()) {
        int &nxt = searchNeigbours[pos][j];
        if (getBuiltHash(pos, nxt) != stateMen[i].lastBuilt)
          continue;
        stateMen[i].lastBuilt = -1;
        stateMen[i].hasMoved = false;
        if (depth == 0) {
          actions.emplace_back(FinalAction({2, i, nxt, 0}));
        }

        removeBridge(pos, nxt, stateMen[i].bridge);
        break;
      }
    }
  }

  void packDoubleBridges() {
    F0 (i, B) {
      if (usedMen.test(i))
        continue;
      if (stateMen[i].lastBuilt < 0)
        continue;
      if (!stateMen[i].hasMoved)
        continue;
      if (stateMen[i].otherBuilder < 0)
        continue;

      int &pos = stateMen[i].pos;

      F0 (j, neighbours[pos].size()) {
        int &nxt = neighbours[pos][j];
        if (getBuiltHash(pos, nxt) != stateMen[i].lastBuilt)
          continue;
        if (!canDualPackBridge(pos, nxt, stateMen[i].bridge, stateMen[stateMen[i].otherBuilder].bridge, 50 - stateMen[i].bridge))
          continue;
        if (depth == 0) {
          actions.emplace_back(FinalAction({4, i, stateMen[i].otherBuilder, 50 - stateMen[i].bridge}));
        }

        removeDualBridge(pos, nxt, stateMen[i].bridge, stateMen[stateMen[i].otherBuilder].bridge, 50 - stateMen[i].bridge);

        usedMen.set(i);
        usedMen.set(stateMen[i].otherBuilder);
        stateMen[stateMen[i].otherBuilder].lastBuilt = -1;
        stateMen[stateMen[i].otherBuilder].otherBuilder = -1;
        stateMen[stateMen[i].otherBuilder].hasMoved = false;
        stateMen[i].otherBuilder = -1;
        stateMen[i].lastBuilt = -1;
        stateMen[i].hasMoved = false;

        break;
      }
    }
  }

  void setTargets() {
    F0 (i, O) {
      if (!stateOrders[i].claimed)
        stateOrders[i].wanted = false;
    }
    auto &order = randomOrders[rnd.next(randomOrders.size())];
    for (int i : order) {
      // cerr << "P Target: " << i << " " << stateMen[i].target << endl;
      if (!stateMen[i].noMessage)
        continue;
      stateMen[i].target = getUnclaimedOrder(stateMen[i].pos);
      stateMen[i].noMessage = true;
    }

    // F0 (i, B) {
    //   // cerr << "ACT Target: " << i << " " << stateMen[i].target << endl;
    // }
  }

  float getScore() {
    float s = score * 10;

    F0 (i, B) {
      if (stateMen[i].target >= 0) {
        s -= getDist(stateMen[i].target, stateMen[i].pos);
      }
    }

    // F0 (i, B) {
    //   if (stateMen[i].target < 0) {
    //     s += (50 - getDist(getUnclaimedOrder(stateMen[i].pos), stateMen[i].pos)) / 2.0;
    //   }
    // }

    return s;
  }

  void doTurn() {
    usedMen.reset();

    moveCloser(false);
    packDoubleBridges();
    while (doDualBuild()) {
      moveCloser(false);
    }
    doRandomWait();
    while (doBuild()) {
      moveCloser(true);
    }
    packBridges();

    afterTurn();
  }
};

// -------------------------------------------------------------- #5 MAIN --------------------------------

void runSpeedTests();

int main(int argc, char *argv[]) {
#ifdef SPEED_TEST
  runSpeedTests();
  return 0;
#endif

  tv = vector<vector<float>>{
      // TRAINBELOW
      {1.2938092654452806, 0.8252608133621112, 1.1271997052971874, 0.8732665485859994},
  };
  trainedValues = tv[0];
  // READ

  std::cin >> N >> B >> O;
  random_device rd;
  mt19937 g(rd());
  F0 (i, 100) {
    vector<int> order;
    F0 (j, B) {
      order.emplace_back(j);
    }

    shuffle(order.begin(), order.end(), g);
    randomOrders.emplace_back(order);
  }

  F0 (i, 100) {
    vector<int> order;
    F0 (j, O) {
      order.emplace_back(j);
    }

    shuffle(order.begin(), order.end(), g);
    randomOOrders.emplace_back(order);
  }

  F0 (i, N) {
    neighbours[i] = vector<int>();
    minDists[i] = inf;
  }
  for (int i = 0; i < N; ++i) {
    for (int j = 0; j < N; ++j) {
      connected[i + j * N] = false;
      std::cin >> getRealDist(i, j);
      // cerr << realDists[i][j] << endl;
      if (i != j)
        minDists[i] = min(minDists[i], getRealDist(i, j));
      if (getRealDist(i, j) <= 120 && i != j) {
        // cerr << "NEIG: " << i << " TO: " << j << " Dist: " << getRealDist(i, j) << endl;
        neighbours[i].emplace_back(j);
      }
    }

    // cerr << "MIN: " << i << " " << minDists[i] << endl;
  }

  findSegements();
  initializeDistances();
  State s;
  maxDepth = segments.size() + 4 + 40 / B;

  for (int turn = 1; turn <= 1000; turn++) {
    int elapsedTime;
    std::cin >> elapsedTime;

    for (int i = 0; i < B; ++i) {
      bridgemen[i].id = i;
      std::cin >> bridgemen[i].pos >> bridgemen[i].bridge >> bridgemen[i].target;
      // cerr << "IO target: " << i << " T: " << bridgemen[i].target << endl;
    }
    for (int i = 0; i < O; ++i) {
      std::cin >> orders[i].from >> orders[i].to;
      orders[i].claimed = false;
    }

    // F0 (i, N) {
    //   F0 (j, neighbours[i].size()) {
    //     if (connected[neighbours[i][j] + i * N])
    //       cerr << "Connected on turn: " << turn << " : " << i << " TO " << neighbours[i][j] << endl;
    //   }
    // }
    std::vector<FinalAction> output;
    float bestScore = -1000000;
    Stopwatch sw(max(1, ((isLocal ? 4500 : 9750) - elapsedTime) / (1000 - turn + 1)));
    int evals = 0;

    F0 (times, 15000) {
      if ((times & 63) == 0 && sw.timeout())
        break;
      evals++;
      s.reset();
      float score = 0;
      s.setTargets();
      F0 (i, maxDepth) {
        s.doTurn();
        score += s.getScore();
      }
      // float score = s.getScore();
      if (score > bestScore) {
        bestScore = score;
        output = s.actions;
        s.setBest();
        // F0 (i, B) {
        //   cerr << "Pos: " << i << " P: " << s.stateMen[i].pos << " Targ: " << s.stateMen[i].target << endl;
        // }
      }
    }

    s.setAfterSearch();
    // cerr << "SW: " << sw.elapsed_milliseconds() << " Actual: " << elapsedTime << " BestScore: " << bestScore << " Evals: " << evals << endl;
    int idx = -1;
    for (auto item : output) {
      idx++;
      if (item.type == 0) {
        cout << "MOVE " << item.b1 << " " << item.b2;
      } else if (item.type == 1) {
        cout << "UNPACK " << item.b1 << " " << item.b2;
        connected[bridgemen[item.b1].pos + item.b2 * N] = true;
        connected[item.b2 + bridgemen[item.b1].pos * N] = true;
        // cerr << "Building? " << bridgemen[item.b1].pos << " " << item.b2 << endl;
      } else if (item.type == 2) {
        cout << "PACK " << item.b1 << " " << item.b2;
        connected[bridgemen[item.b1].pos + item.b2 * N] = false;
        connected[item.b2 + bridgemen[item.b1].pos * N] = false;
      } else if (item.type == 3) {
        cout << "TEAMUNPACK " << item.b1 << " " << item.b2 << " " << item.length;
        connected[bridgemen[item.b1].pos + bridgemen[item.b2].pos * N] = true;
        connected[bridgemen[item.b2].pos + bridgemen[item.b1].pos * N] = true;
      } else if (item.type == 4) {
        cout << "TEAMPACK " << item.b1 << " " << item.b2 << " " << item.length;
        connected[bridgemen[item.b1].pos + bridgemen[item.b2].pos * N] = false;
        connected[bridgemen[item.b2].pos + bridgemen[item.b1].pos * N] = false;
      }
      if (idx < output.size() - 1) {
        std::cout << " | ";
      }
    }
    std::cout << std::endl;
  }

  return 0;
}

void runSpeedTests() {
  cout << "Starting doTurn speed tests..." << endl;

  N = 20;
  B = 10;
  O = 5;
  F0 (i, N)
    F0 (j, N)
      getRealDist(i, j) = abs(i - j) + 1;
  F0 (i, N)
    F0 (j, N)
      connected[i + j * N] = false;

  tv = vector<vector<float>>{
      {1.2938092654452806, 0.8252608133621112, 1.1271997052971874, 0.8732665485859994},
  };
  trainedValues = tv[0];

  random_device rd;
  mt19937 g(rd());
  F0 (i, 100) {
    vector<int> order;
    F0 (j, B) {
      order.emplace_back(j);
    }
    shuffle(order.begin(), order.end(), g);
    randomOrders.emplace_back(order);
  }

  State testState;
  testState.reset();
  F0 (i, B) {
    testState.stateMen[i].pos = i % N;
    testState.stateMen[i].bridge = 50;
    testState.stateMen[i].target = (i + 10) % N;
  }
  F0 (i, O) {
    testState.stateOrders[i].from = i % N;
    testState.stateOrders[i].to = (i + 5) % N;
    testState.stateOrders[i].claimed = false;
  }

  auto start = chrono::high_resolution_clock::now();
  int iterations = 0;
  int resetCounter = 0;

  while (true) {
    testState.doTurn();
    iterations++;
    resetCounter++;

    if (resetCounter >= 10) {
      testState.reset();
      F0 (i, B) {
        testState.stateMen[i].pos = i % N;
        testState.stateMen[i].bridge = 50;
        testState.stateMen[i].target = (i + 10) % N;
      }
      resetCounter = 0;
    }

    auto current = chrono::high_resolution_clock::now();
    auto elapsed = chrono::duration_cast<chrono::milliseconds>(current - start).count();

    if (elapsed >= 1000) {
      cout << "Baseline doTurn speed: " << iterations << " iterations in " << elapsed << "ms" << endl;
      cout << "Rate: " << (iterations * 1000.0 / elapsed) << " iterations/second" << endl;
      break;
    }
  }
}

void runSpeedTestsIfMain() {
#ifdef SPEED_TEST
  runSpeedTests();
#endif
}
