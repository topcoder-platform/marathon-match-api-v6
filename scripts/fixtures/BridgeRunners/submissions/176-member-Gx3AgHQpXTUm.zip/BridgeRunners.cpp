#include <bits/stdc++.h>

using namespace std;

const int INF = 1e9;

struct Edge {
    int u, v, w;
};

struct Bridgeman {
    int ID;
    int Position;
    int carryingTo;
    int Bricks;
};

vector<int> get_path(const vector<vector<bool>>& built, int start, int end, int N) {
    vector<int> dist(N, -1);
    vector<int> parent(N, -1);
    queue<int> q;
    q.push(start);
    dist[start] = 0;
    while (!q.empty()) {
        int u = q.front(); q.pop();
        if (u == end) break;
        for (int v = 0; v < N; v++) {
            if (built[u][v] && dist[v] == -1) {
                dist[v] = dist[u] + 1;
                parent[v] = u;
                q.push(v);
            }
        }
    }
    if (dist[end] == -1) return {};
    vector<int> path;
    for (int v = end; v != -1; v = parent[v]) path.push_back(v);
    reverse(path.begin(), path.end());
    return path;
}

void sim_handle(vector<Bridgeman>& bm, vector<pair<int, int>>& local_orders, int B) {
    // deliver
    for (int bid = 0; bid < B; bid++) {
        if (bm[bid].carryingTo == bm[bid].Position) {
            bm[bid].carryingTo = -1;
        }
    }
    // pick
    bool ch = true;
    while (ch) {
        ch = false;
        for (size_t oid = 0; oid < local_orders.size(); oid++) {
            for (int bid = 0; bid < B; bid++) {
                if (bm[bid].carryingTo != -1) continue;
                if (bm[bid].Position != local_orders[oid].first) continue;
                bm[bid].carryingTo = local_orders[oid].second;
                local_orders.erase(local_orders.begin() + oid);
                ch = true;
                break;
            }
            if (ch) break;
        }
    }
}

int main() {
    int N, B, O;
    cin >> N >> B >> O;

    vector<vector<int>> length_mat(N, vector<int>(N));
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < N; j++) {
            cin >> length_mat[i][j];
        }
    }

    // Compute MST edges
    vector<pair<int, int>> mst_edges;
    {
        vector<Edge> edges;
        for (int i = 0; i < N; i++) {
            for (int j = i + 1; j < N; j++) {
                int d = length_mat[i][j];
                if (d > 0 && d <= 120) {  // Slightly higher to be safe
                    edges.push_back({i, j, d});
                }
            }
        }
        sort(edges.begin(), edges.end(), [](const Edge& a, const Edge& b) { return a.w < b.w; });
        vector<int> par(N);
        for (int i = 0; i < N; i++) par[i] = i;
        auto f = [&](auto&& self, int x) -> int { return par[x] == x ? x : par[x] = self(self, par[x]); };
        for (auto& e : edges) {
            int fu = f(f, e.u), fv = f(f, e.v);
            if (fu != fv) {
                par[fu] = fv;
                mst_edges.push_back({e.u, e.v});
            }
        }
    }

    vector<vector<bool>> built(N, vector<bool>(N, false));
    vector<int> parent(N);
    auto find = [&](auto&& self, int x) -> int {
        if (parent[x] != x) parent[x] = self(self, parent[x]);
        return parent[x];
    };
    auto union_set = [&](int x, int y) {
        x = find(find, x);
        y = find(find, y);
        if (x != y) parent[x] = y;
    };
    auto update_union = [&]() {
        for (int i = 0; i < N; i++) parent[i] = i;
        for (int i = 0; i < N; i++) {
            for (int j = i + 1; j < N; j++) {
                if (built[i][j]) union_set(i, j);
            }
        }
    };

    while (true) {
        int time;
        if (!(cin >> time)) break;

        vector<Bridgeman> bm(B);
        for (int i = 0; i < B; i++) {
            cin >> bm[i].Position >> bm[i].Bricks >> bm[i].carryingTo;
            bm[i].ID = i;
        }

        vector<pair<int, int>> curr_orders(O);
        for (int i = 0; i < O; i++) {
            cin >> curr_orders[i].first >> curr_orders[i].second;
        }

        update_union();

        vector<string> commands;
        vector<bool> moved(B, false);
        vector<pair<int, int>> local_orders = curr_orders;

        // assign targets
        vector<int> target(B, -1);
        for (int i = 0; i < B; i++) {
            if (bm[i].carryingTo != -1) target[i] = bm[i].carryingTo;
        }

        vector<bool> assigned(O, false);

        // assign connected
        for (int i = 0; i < B; i++) {
            if (target[i] != -1) continue;
            int pos = bm[i].Position;
            int best_d = INF;
            int best_o = -1;
            for (int o = 0; o < O; o++) {
                if (assigned[o]) continue;
                int from = curr_orders[o].first;
                vector<int> path = get_path(built, pos, from, N);
                int d = path.empty() ? INF : (int)path.size() - 1;
                if (d < best_d) {
                    best_d = d;
                    best_o = o;
                }
            }
            if (best_o != -1 && best_d < INF) {
                assigned[best_o] = true;
                target[i] = curr_orders[best_o].first;
            }
        }

        // assign disconnected
        vector<int> unassigned_o;
        for (int o = 0; o < O; o++) if (!assigned[o]) unassigned_o.push_back(o);
        for (int i = 0; i < B; i++) {
            if (target[i] != -1) continue;
            int pos = bm[i].Position;
            int c1 = find(find, pos);
            int best_conn = INF;
            int best_o = -1;
            for (int oo : unassigned_o) {
                int o = oo;
                int from = curr_orders[o].first;
                int c2 = find(find, from);
                if (c1 == c2) continue;
                int min_e = INF;
                for (int a = 0; a < N; a++) if (find(find, a) == c1) {
                    for (int b = 0; b < N; b++) if (find(find, b) == c2) {
                        min_e = min(min_e, length_mat[a][b]);
                    }
                }
                if (min_e < best_conn) {
                    best_conn = min_e;
                    best_o = o;
                }
            }
            if (best_o != -1) {
                target[i] = curr_orders[best_o].first;
                assigned[best_o] = true;
                unassigned_o.erase(remove(unassigned_o.begin(), unassigned_o.end(), best_o), unassigned_o.end());
            }
        }

        // needed pairs
        vector<pair<int, int>> needed_pairs;
        for (int i = 0; i < B; i++) {
            if (target[i] != -1) {
                needed_pairs.push_back({bm[i].Position, target[i]});
            }
        }

        // packing to recover bricks
        bool changed = true;
        while (changed) {
            changed = false;
            for (int i = 0; i < B; i++) {
                if (moved[i]) continue;
                int pos = bm[i].Position;
                vector<pair<int, int>> packable;
                for (int v = 0; v < N; v++) {
                    if (built[pos][v] && bm[i].Bricks + length_mat[pos][v] <= 60 && length_mat[pos][v] <= 60) {
                        packable.push_back({length_mat[pos][v], v});
                    }
                }
                if (packable.empty()) continue;
                sort(packable.rbegin(), packable.rend());
                bool packed = false;
                for (auto& p : packable) {
                    int d = p.first;
                    int v = p.second;
                    built[pos][v] = false;
                    built[v][pos] = false;
                    update_union();
                    bool safe = true;
                    for (auto np : needed_pairs) {
                        if (find(find, np.first) != find(find, np.second)) {
                            safe = false;
                            break;
                        }
                    }
                    if (safe) {
                        string cmd = "PACK " + to_string(i) + " " + to_string(v);
                        commands.push_back(cmd);
                        bm[i].Bricks += d;
                        moved[i] = true;
                        changed = true;
                        packed = true;
                        sim_handle(bm, local_orders, B);
                    } else {
                        built[pos][v] = true;
                        built[v][pos] = true;
                        update_union();
                    }
                    if (packed) break;
                }
            }
        }

        // proactive teampack with moving
        changed = true;
        while (changed) {
            changed = false;
            vector<pair<int, pair<int, int>>> candidates;
            for (int i = 0; i < N; i++) {
                for (int j = i + 1; j < N; j++) {
                    if (built[i][j] && length_mat[i][j] > 60) {
                        built[i][j] = built[j][i] = false;
                        update_union();
                        bool safe = true;
                        for (auto np : needed_pairs) {
                            if (find(find, np.first) != find(find, np.second)) safe = false;
                        }
                        built[i][j] = built[j][i] = true;
                        update_union();
                        if (safe) candidates.push_back({length_mat[i][j], {i, j}});
                    }
                }
            }
            if (candidates.empty()) continue;
            sort(candidates.rbegin(), candidates.rend());
            for (auto& cand : candidates) {
                int d = cand.first;
                int a = cand.second.first;
                int b = cand.second.second;
                int best_cost1 = INF, best_cost2 = INF;
                int chosen_bid1 = -1, chosen_bid2 = -1;
                for (int j = 0; j < B; j++) {
                    if (moved[j]) continue;
                    int p = bm[j].Position;
                    vector<int> ppath = get_path(built, p, a, N);
                    if (!ppath.empty()) {
                        int cost = ppath.size() - 1;
                        if (cost < best_cost1) {
                            best_cost1 = cost;
                            chosen_bid1 = j;
                        }
                    }
                    ppath = get_path(built, p, b, N);
                    if (!ppath.empty()) {
                        int cost = ppath.size() - 1;
                        if (cost < best_cost2) {
                            best_cost2 = cost;
                            chosen_bid2 = j;
                        }
                    }
                }
                if (chosen_bid1 == -1 || chosen_bid2 == -1) continue;
                if (chosen_bid1 == chosen_bid2) {
                    if (best_cost1 <= best_cost2) {
                        // keep for a, find second for b
                        int second_cost = INF;
                        int second_bid = -1;
                        for (int j = 0; j < B; j++) {
                            if (moved[j] || j == chosen_bid1) continue;
                            int p = bm[j].Position;
                            vector<int> ppath = get_path(built, p, b, N);
                            if (ppath.empty()) continue;
                            int cost = ppath.size() - 1;
                            if (cost < second_cost) {
                                second_cost = cost;
                                second_bid = j;
                            }
                        }
                        if (second_bid == -1) continue;
                        chosen_bid2 = second_bid;
                        best_cost2 = second_cost;
                    } else {
                        // keep for b, second for a
                        int second_cost = INF;
                        int second_bid = -1;
                        for (int j = 0; j < B; j++) {
                            if (moved[j] || j == chosen_bid2) continue;
                            int p = bm[j].Position;
                            vector<int> ppath = get_path(built, p, a, N);
                            if (ppath.empty()) continue;
                            int cost = ppath.size() - 1;
                            if (cost < second_cost) {
                                second_cost = cost;
                                second_bid = j;
                            }
                        }
                        if (second_bid == -1) continue;
                        chosen_bid1 = second_bid;
                        best_cost1 = second_cost;
                    }
                }
                int max1 = 60 - bm[chosen_bid1].Bricks;
                int max2 = 60 - bm[chosen_bid2].Bricks;
                if (max1 + max2 < d) continue;
                if (best_cost1 == 0 && best_cost2 == 0) {
                    int len1 = min(max1, d);
                    string cmd = "TEAMPACK " + to_string(chosen_bid1) + " " + to_string(chosen_bid2) + " " + to_string(len1);
                    commands.push_back(cmd);
                    bm[chosen_bid1].Bricks += len1;
                    bm[chosen_bid2].Bricks += d - len1;
                    built[a][b] = built[b][a] = false;
                    update_union();
                    moved[chosen_bid1] = true;
                    moved[chosen_bid2] = true;
                    changed = true;
                    sim_handle(bm, local_orders, B);
                } else {
                    if (best_cost1 > 0) {
                        vector<int> ppath = get_path(built, bm[chosen_bid1].Position, a, N);
                        int next = ppath[1];
                        string cmd = "MOVE " + to_string(chosen_bid1) + " " + to_string(next);
                        commands.push_back(cmd);
                        bm[chosen_bid1].Position = next;
                        moved[chosen_bid1] = true;
                        changed = true;
                        sim_handle(bm, local_orders, B);
                    }
                    if (best_cost2 > 0) {
                        vector<int> ppath = get_path(built, bm[chosen_bid2].Position, b, N);
                        int next = ppath[1];
                        string cmd = "MOVE " + to_string(chosen_bid2) + " " + to_string(next);
                        commands.push_back(cmd);
                        bm[chosen_bid2].Position = next;
                        moved[chosen_bid2] = true;
                        changed = true;
                        sim_handle(bm, local_orders, B);
                    }
                }
                if (changed) break;
            }
        }

        // handle actions for orders
        changed = true;
        while (changed) {
            changed = false;
            for (int i = 0; i < B; i++) {
                if (moved[i] || target[i] == -1) continue;
                int pos = bm[i].Position;
                int dest = target[i];
                if (pos == dest) continue;
                vector<int> path = get_path(built, pos, dest, N);
                if (!path.empty()) {
                    int next = path[1];
                    string cmd = "MOVE " + to_string(i) + " " + to_string(next);
                    commands.push_back(cmd);
                    bm[i].Position = next;
                    moved[i] = true;
                    sim_handle(bm, local_orders, B);
                    changed = true;
                } else {
                    int c1 = find(find, pos);
                    int c2 = find(find, dest);
                    int best_d = INF;
                    int best_a = -1, best_b = -1;
                    for (int a = 0; a < N; a++) if (find(find, a) == c1) {
                        for (int b = 0; b < N; b++) if (find(find, b) == c2) {
                            if (length_mat[a][b] < best_d) {
                                best_d = length_mat[a][b];
                                best_a = a;
                                best_b = b;
                            }
                        }
                    }
                    if (best_d == INF) continue;
                    bool built_it = false;
                    if (best_d <= 60) {
                        int chosen_bid = -1;
                        int chosen_side = -1;
                        int best_cost = INF;
                        for (int j = 0; j < B; j++) {
                            if (moved[j]) continue;
                            int p = bm[j].Position;
                            if (bm[j].Bricks < best_d) continue;
                            vector<int> ppath;
                            int cost = INF;
                            if (find(find, p) == c1) {
                                ppath = get_path(built, p, best_a, N);
                                if (!ppath.empty()) cost = (int)ppath.size() - 1;
                                if (cost < best_cost) {
                                    best_cost = cost;
                                    chosen_bid = j;
                                    chosen_side = 1;
                                }
                            } else if (find(find, p) == c2) {
                                ppath = get_path(built, p, best_b, N);
                                if (!ppath.empty()) cost = (int)ppath.size() - 1;
                                if (cost < best_cost) {
                                    best_cost = cost;
                                    chosen_bid = j;
                                    chosen_side = 2;
                                }
                            }
                        }
                        if (chosen_bid != -1) {
                            if (best_cost == 0) {
                                int from_isl = (chosen_side == 1) ? best_a : best_b;
                                int to_isl = (chosen_side == 1) ? best_b : best_a;
                                string cmd = "UNPACK " + to_string(chosen_bid) + " " + to_string(to_isl);
                                commands.push_back(cmd);
                                bm[chosen_bid].Bricks -= best_d;
                                built[from_isl][to_isl] = true;
                                built[to_isl][from_isl] = true;
                                update_union();
                                moved[chosen_bid] = true;
                                built_it = true;
                                sim_handle(bm, local_orders, B);
                            } else {
                                int tgt = (chosen_side == 1) ? best_a : best_b;
                                vector<int> ppath = get_path(built, bm[chosen_bid].Position, tgt, N);
                                int next = ppath[1];
                                string cmd = "MOVE " + to_string(chosen_bid) + " " + to_string(next);
                                commands.push_back(cmd);
                                bm[chosen_bid].Position = next;
                                moved[chosen_bid] = true;
                                sim_handle(bm, local_orders, B);
                            }
                            changed = true;
                        }
                    }
                    if (!built_it) {
                        int chosen_bid1 = -1, chosen_bid2 = -1;
                        int best_cost1 = INF, best_cost2 = INF;
                        int bricks1 = 0, bricks2 = 0;
                        for (int j = 0; j < B; j++) {
                            if (moved[j]) continue;
                            int p = bm[j].Position;
                            vector<int> ppath;
                            int cost = INF;
                            if (find(find, p) == c1) {
                                ppath = get_path(built, p, best_a, N);
                                if (!ppath.empty()) cost = (int)ppath.size() - 1;
                                if (cost < best_cost1) {
                                    best_cost1 = cost;
                                    chosen_bid1 = j;
                                    bricks1 = bm[j].Bricks;
                                }
                            } else if (find(find, p) == c2) {
                                ppath = get_path(built, p, best_b, N);
                                if (!ppath.empty()) cost = (int)ppath.size() - 1;
                                if (cost < best_cost2) {
                                    best_cost2 = cost;
                                    chosen_bid2 = j;
                                    bricks2 = bm[j].Bricks;
                                }
                            }
                        }
                        if (chosen_bid1 != -1 && chosen_bid2 != -1 && bricks1 + bricks2 >= best_d) {
                            if (best_cost1 == 0 && best_cost2 == 0) {
                                int len1 = min(bricks1, best_d);
                                string cmd = "TEAMUNPACK " + to_string(chosen_bid1) + " " + to_string(chosen_bid2) + " " + to_string(len1);
                                commands.push_back(cmd);
                                bm[chosen_bid1].Bricks -= len1;
                                bm[chosen_bid2].Bricks -= best_d - len1;
                                built[best_a][best_b] = true;
                                built[best_b][best_a] = true;
                                update_union();
                                moved[chosen_bid1] = true;
                                moved[chosen_bid2] = true;
                                sim_handle(bm, local_orders, B);
                            } else {
                                if (best_cost1 > 0) {
                                    vector<int> ppath = get_path(built, bm[chosen_bid1].Position, best_a, N);
                                    int next = ppath[1];
                                    string cmd = "MOVE " + to_string(chosen_bid1) + " " + to_string(next);
                                    commands.push_back(cmd);
                                    bm[chosen_bid1].Position = next;
                                    moved[chosen_bid1] = true;
                                    sim_handle(bm, local_orders, B);
                                }
                                if (best_cost2 > 0) {
                                    vector<int> ppath = get_path(built, bm[chosen_bid2].Position, best_b, N);
                                    int next = ppath[1];
                                    string cmd = "MOVE " + to_string(chosen_bid2) + " " + to_string(next);
                                    commands.push_back(cmd);
                                    bm[chosen_bid2].Position = next;
                                    moved[chosen_bid2] = true;
                                    sim_handle(bm, local_orders, B);
                                }
                            }
                            changed = true;
                        }
                    }
                }
            }
        }

        // proactive building
        changed = true;
        while (changed) {
            changed = false;
            for (auto& e : mst_edges) {
                int u = e.first, v = e.second;
                if (built[u][v]) continue;
                if (find(find, u) == find(find, v)) continue;
                int best_d = length_mat[u][v];
                int best_a = u, best_b = v;
                bool built_it = false;
                if (best_d <= 60) {
                    int chosen_bid = -1;
                    int chosen_side = -1;
                    int best_cost = INF;
                    for (int j = 0; j < B; j++) {
                        if (moved[j]) continue;
                        int p = bm[j].Position;
                        if (bm[j].Bricks < best_d) continue;
                        vector<int> ppath;
                        int cost = INF;
                        if (find(find, p) == find(find, best_a)) {
                            ppath = get_path(built, p, best_a, N);
                            if (!ppath.empty()) cost = (int)ppath.size() - 1;
                            if (cost < best_cost) {
                                best_cost = cost;
                                chosen_bid = j;
                                chosen_side = 1;
                            }
                        } else if (find(find, p) == find(find, best_b)) {
                            ppath = get_path(built, p, best_b, N);
                            if (!ppath.empty()) cost = (int)ppath.size() - 1;
                            if (cost < best_cost) {
                                best_cost = cost;
                                chosen_bid = j;
                                chosen_side = 2;
                            }
                        }
                    }
                    if (chosen_bid != -1) {
                        if (best_cost == 0) {
                            int from_isl = (chosen_side == 1) ? best_a : best_b;
                            int to_isl = (chosen_side == 1) ? best_b : best_a;
                            string cmd = "UNPACK " + to_string(chosen_bid) + " " + to_string(to_isl);
                            commands.push_back(cmd);
                            bm[chosen_bid].Bricks -= best_d;
                            built[from_isl][to_isl] = true;
                            built[to_isl][from_isl] = true;
                            update_union();
                            moved[chosen_bid] = true;
                            built_it = true;
                            sim_handle(bm, local_orders, B);
                        } else {
                            int tgt = (chosen_side == 1) ? best_a : best_b;
                            vector<int> ppath = get_path(built, bm[chosen_bid].Position, tgt, N);
                            int next = ppath[1];
                            string cmd = "MOVE " + to_string(chosen_bid) + " " + to_string(next);
                            commands.push_back(cmd);
                            bm[chosen_bid].Position = next;
                            moved[chosen_bid] = true;
                            sim_handle(bm, local_orders, B);
                        }
                        changed = true;
                    }
                }
                if (!built_it) {
                    int chosen_bid1 = -1, chosen_bid2 = -1;
                    int best_cost1 = INF, best_cost2 = INF;
                    int bricks1 = 0, bricks2 = 0;
                    for (int j = 0; j < B; j++) {
                        if (moved[j]) continue;
                        int p = bm[j].Position;
                        vector<int> ppath;
                        int cost = INF;
                        if (find(find, p) == find(find, best_a)) {
                            ppath = get_path(built, p, best_a, N);
                            if (!ppath.empty()) cost = (int)ppath.size() - 1;
                            if (cost < best_cost1) {
                                best_cost1 = cost;
                                chosen_bid1 = j;
                                bricks1 = bm[j].Bricks;
                            }
                        } else if (find(find, p) == find(find, best_b)) {
                            ppath = get_path(built, p, best_b, N);
                            if (!ppath.empty()) cost = (int)ppath.size() - 1;
                            if (cost < best_cost2) {
                                best_cost2 = cost;
                                chosen_bid2 = j;
                                bricks2 = bm[j].Bricks;
                            }
                        }
                    }
                    if (chosen_bid1 != -1 && chosen_bid2 != -1 && bricks1 + bricks2 >= best_d) {
                        if (best_cost1 == 0 && best_cost2 == 0) {
                            int len1 = min(bricks1, best_d);
                            string cmd = "TEAMUNPACK " + to_string(chosen_bid1) + " " + to_string(chosen_bid2) + " " + to_string(len1);
                            commands.push_back(cmd);
                            bm[chosen_bid1].Bricks -= len1;
                            bm[chosen_bid2].Bricks -= best_d - len1;
                            built[best_a][best_b] = true;
                            built[best_b][best_a] = true;
                            update_union();
                            moved[chosen_bid1] = true;
                            moved[chosen_bid2] = true;
                            sim_handle(bm, local_orders, B);
                        } else {
                            if (best_cost1 > 0) {
                                vector<int> ppath = get_path(built, bm[chosen_bid1].Position, best_a, N);
                                int next = ppath[1];
                                string cmd = "MOVE " + to_string(chosen_bid1) + " " + to_string(next);
                                commands.push_back(cmd);
                                bm[chosen_bid1].Position = next;
                                moved[chosen_bid1] = true;
                                sim_handle(bm, local_orders, B);
                            }
                            if (best_cost2 > 0) {
                                vector<int> ppath = get_path(built, bm[chosen_bid2].Position, best_b, N);
                                int next = ppath[1];
                                string cmd = "MOVE " + to_string(chosen_bid2) + " " + to_string(next);
                                commands.push_back(cmd);
                                bm[chosen_bid2].Position = next;
                                moved[chosen_bid2] = true;
                                sim_handle(bm, local_orders, B);
                            }
                        }
                        changed = true;
                    }
                }
                if (changed) break;
            }
        }

        // output
        string out;
        for (size_t k = 0; k < commands.size(); k++) {
            if (k > 0) out += "|";
            out += commands[k];
        }
        cout << out << endl;
    }

    return 0;
}