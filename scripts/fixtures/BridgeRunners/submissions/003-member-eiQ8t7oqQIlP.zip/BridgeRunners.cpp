#include <iostream>
#include <vector>
#include <string>
#include <sstream>
#include <numeric>
#include <algorithm>
#include <cmath>

class Bridgeman {
public:
    int ID;
    int Position;
    int Target;
    int Bricks;
    int BridgeFrom = -1;
    int BridgeTo = -1;
    int teamEffort = -1;
    int teamMate = -1;
};

class Order {
public:
    int From;
    int To;
};

static int g_seed = 777778;
static int Rand(int mod) {
    g_seed = (214013 * g_seed + 2531011);
    return ((g_seed >> 16) & 0x7FFF) % mod;
}

int dists[128][128];
int solo_dist[128][128];
int INF = 1000000;
using namespace std;

int main() {
    int N, B, O;
    std::cin >> N >> B >> O;

    bool connected[N][N];
    for (int i = 0; i < N; ++i) {
        for (int j = 0; j < N; ++j) {
            connected[i][j]=false;
            std::cin >> dists[i][j];
            //cerr << i << " " << j << " " << dists[i][j] << endl;
        }
    }
    for (int i = 0; i < N; ++i) for (int j = 0; j < N; ++j) {
        solo_dist[i][j] = INF;
        if (dists[i][j] <= 50) solo_dist[i][j] = 1;
    }
    for (int i = 0; i < N; ++i) solo_dist[i][i] = 0;
    for (int k = 0; k < N; ++k) for (int i = 0; i < N; ++i) if (solo_dist[i][k] != INF) for (int j = 0; j < N; ++j) solo_dist[i][j] = min(solo_dist[i][j], solo_dist[i][k] + solo_dist[k][j]);


    Bridgeman bridgemen[B];
    for (int i = 0; i < B; ++i) {
        bridgemen[i].ID = i;
    }

    for (int turn = 1; turn <= 1000; turn++) {
        int elapsedTime;
        std::cin >> elapsedTime;
        for (int i = 0; i < B; ++i) {
            std::cin >> bridgemen[i].Position >> bridgemen[i].Bricks >> bridgemen[i].Target;
        }
        std::vector<Order> orders(O);
        for (int i = 0; i < O; ++i) {
            std::cin >> orders[i].From >> orders[i].To;
        }

        std::vector<std::string> output;
        // does it help to swap?
        for (int i = 0; i < B; ++i) for (int j = 0; j < B; ++j) if (i != j) if (bridgemen[i].Bricks + bridgemen[j].Bricks >= dists[bridgemen[i].Position][bridgemen[j].Position]) 
        if (bridgemen[i].BridgeFrom == -1 && bridgemen[j].BridgeFrom == -1)
        if (
            (bridgemen[i].Target != -1 && bridgemen[j].Target == -1 && solo_dist[bridgemen[i].Position][bridgemen[i].Target] >= INF && solo_dist[bridgemen[j].Position][bridgemen[i].Target] < INF) || 
            ((bridgemen[i].Target != -1 && bridgemen[j].Target != -1 && solo_dist[bridgemen[i].Position][bridgemen[i].Target] >= INF && solo_dist[bridgemen[j].Position][bridgemen[i].Target] < INF
            && solo_dist[bridgemen[j].Position][bridgemen[j].Target >= INF] &&  solo_dist[bridgemen[i].Position][bridgemen[j].Target] < INF
            ))
            )

        if (bridgemen[i].teamEffort == -1 && bridgemen[j].teamEffort == -1)
        {
            cerr << "Possible to swap\n";
            output.push_back("TEAMUNPACK " + std::to_string(bridgemen[i].ID) + " " + std::to_string(bridgemen[j].ID)+ " 50");
            bridgemen[i].teamEffort = 1;
            bridgemen[j].teamEffort = 1;
            bridgemen[i].teamMate = j;
            bridgemen[j].teamMate = i;

        }
        for (auto& b : bridgemen) {
            if (b.teamEffort == 1) {
                b.teamEffort = 2; 
                continue;
            } else
            if (b.teamEffort == 2) {
                output.push_back("MOVE " + std::to_string(b.ID) + " " + std::to_string(bridgemen[b.teamMate].Position));
                b.teamEffort = 3;
                continue;
            } else
            if (b.teamEffort == 3) {
                if (b.ID < bridgemen[b.teamMate].ID)
                output.push_back("TEAMPACK " + to_string(b.ID) + " " + to_string(bridgemen[b.teamMate].ID) + " " + to_string(50 - b.Bricks));
                b.teamEffort = -1;
            } else
            if (b.BridgeFrom == -1) { // unpack
                std::vector<int> targets;

                std::vector<int> closer_targets;
                std::vector<int> pick_targets;
                vector<int> aim_closer;

                int pick_task = -1, hard_work = 0;

                for (int i = 0; i < O; ++i) if (solo_dist[orders[i].From][orders[i].To] != INF && solo_dist[b.Position][orders[i].From] != INF) {
                    int difficulty = solo_dist[b.Position][orders[i].From];//+ solo_dist[orders[i].From][orders[i].To];
                    if (pick_task == -1 || difficulty < hard_work) { hard_work = difficulty; pick_task = orders[i].From;}
                }

                for (int t = 0; t < N; ++t) {
                    if (t != b.Position && !connected[b.Position][t] && dists[b.Position][t] <= b.Bricks) {
                        targets.push_back(t);
                        if (b.Target != -1)
                        if (solo_dist[t][b.Target] < solo_dist[b.Position][b.Target]) closer_targets.push_back(t);
                        if (pick_task != -1) 
                        if (solo_dist[t][pick_task] < solo_dist[b.Position][pick_task]) pick_targets.push_back(t);
                        if (b.Target != -1) if (dists[t][b.Target] < dists[b.Position][b.Target]) aim_closer.push_back(t);
                    }
                }
                //targets.clear();
                if (aim_closer.size() > 0) targets = aim_closer;
                if (pick_targets.size() > 0) targets = pick_targets;
                if (closer_targets.size() > 0) targets = closer_targets;
                if (!targets.empty()) {
                    int t = targets[Rand(targets.size())];
                    output.push_back("UNPACK " + std::to_string(b.ID) + " " + std::to_string(t));
                    b.BridgeFrom = b.Position;
                    b.BridgeTo = t;
                    connected[b.BridgeFrom][b.BridgeTo] = true;
                    connected[b.BridgeTo][b.BridgeFrom] = true;
                }
            } else if (b.BridgeFrom == b.Position) { // MOVE
                output.push_back("MOVE " + std::to_string(b.ID) + " " + std::to_string(b.BridgeTo));
            } else { // PACK
                output.push_back("PACK " + std::to_string(b.ID) + " " + std::to_string(b.BridgeFrom));
                connected[b.BridgeFrom][b.BridgeTo] = false;
                connected[b.BridgeTo][b.BridgeFrom] = false;
                b.BridgeFrom = -1;
                b.BridgeTo = -1;
            }
        }

        for (size_t i = 0; i < output.size(); ++i) {
            std::cout << output[i];
            if (i < output.size() - 1) {
                std::cout << " | ";
            }
        }
        std::cout << std::endl;
    }

    return 0;
}