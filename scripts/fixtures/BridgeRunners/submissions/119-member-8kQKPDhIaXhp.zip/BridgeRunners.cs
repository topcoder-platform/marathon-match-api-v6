﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;

class Order
{
    public int From;
    public int To;
}





class Edge
{
    public int To;
    public long Cost;
    public Edge(int to, long cost) { To = to; Cost = cost; }
}

struct NodeDist
{
    public int V;
    public long D;
    public NodeDist(int v, long d) { V = v; D = d; }
}

class MinHeap
{
    List<NodeDist> a = new List<NodeDist>();
    public int Count { get { return a.Count; } }
    void Swap(int i, int j) { var t = a[i]; a[i] = a[j]; a[j] = t; }
    public void Push(NodeDist nd)
    {
        a.Add(nd);
        int i = a.Count - 1;
        while (i > 0)
        {
            int p = (i - 1) >> 1;
            if (a[p].D <= a[i].D) break;
            Swap(p, i);
            i = p;
        }
    }
    public NodeDist Pop()
    {
        var ret = a[0];
        int n = a.Count - 1;
        a[0] = a[n];
        a.RemoveAt(n);
        n = a.Count;
        int i = 0;
        while (true)
        {
            int l = i * 2 + 1, r = l + 1, smallest = i;
            if (l < n && a[l].D < a[smallest].D) smallest = l;
            if (r < n && a[r].D < a[smallest].D) smallest = r;
            if (smallest == i) break;
            Swap(i, smallest);
            i = smallest;
        }
        return ret;
    }
}

class AllPairsDijkstra
{
    public long[,] distAll;
    public int[,] parentAll;
    const long INF = (long)9e18;
    public int DMAX = 100;

    public void Dijkstra(int n, List<Edge>[] adj, int src, long[] dist, int[] parent)
    {
        for (int i = 0; i < n; i++) { dist[i] = INF; parent[i] = -1; }
        dist[src] = 0;
        var pq = new MinHeap();
        pq.Push(new NodeDist(src, 0));
        while (pq.Count > 0)
        {
            var cur = pq.Pop();
            int v = cur.V;
            long d = cur.D;
            if (d != dist[v]) continue;
            foreach (var e in adj[v])
            {
                long nd = d + e.Cost;
                if (nd < dist[e.To])
                {
                    dist[e.To] = nd;
                    parent[e.To] = v;
                    pq.Push(new NodeDist(e.To, nd));
                }
            }
        }
    }

    public List<int> ReconstructPath(int src, int tgt, int[] parent)
    {
        var path = new List<int>();
        if (parent[tgt] == -1 && src != tgt) return path; // vide = pas de chemin
        for (int v = tgt; v != -1; v = parent[v]) path.Add(v);
        path.Reverse();
        return path;
    }

    public void Start(int N, int O, int B, int[,] dists)
    {

        var adj = new List<Edge>[N];
        for (int i = 0; i < N; i++)
        {
            adj[i] = new List<Edge>();
            for (int j = 0; j < N; j++)
            {
                int u = i;
                int v = j;
                long w = dists[u, v];
                if(w <= DMAX)adj[u].Add(new Edge(v, w));
                // si graphe non orienté :
                // adj[v].Add(new Edge(u, w));
            }

        }

        distAll = new long[N, N];
        parentAll = new int[N, N];

        for (int s = 0; s < N; s++)
        {
            long[] dist = new long[N];
            int[] parent = new int[N];
            Dijkstra(N, adj, s, dist, parent);
            for (int t = 0; t < N; t++)
            {
                distAll[s, t] = dist[t];
                parentAll[s, t] = parent[t];
            }
        }




    }


}

class Bridgeman
{
    public int ID;
    public int Position;
    public int Target;
    public int Bricks;

    public int BridgeFrom = -1;
    public int BridgeTo = -1;
    public int step = 0;
    public int ind_path = 0;
    public List<int> path = new List<int>();
    public int main_step = 0;
    public Order order;
    public AllPairsDijkstra adjikstra = null;
    public  bool have_unpack = false;
    public bool helper = false;
    public int num_helper = -1;
    public bool in_help = false;
    public int num_in_help = -1;
    public bool construct_help = false;
    public int step_help = 0;
    public int step_in_help = 0;
    public int pos_construct = -1;
}

static class Ext
{
    public static T[] GetRow<T>(this T[,] matrix, int row)
    {
        int cols = matrix.GetLength(1);
        T[] result = new T[cols];
        for (int i = 0; i < cols; i++) result[i] = matrix[row, i];
        return result;
    }
}

class Elem
{
    public int action;
    public int BridgemanID;
    public int BridgemanID2;
    public int length;
    public int islandID;
    static int g_seed = 777778;
    static int Rand(int mod)
    {
        g_seed = (214013 * g_seed + 2531011);
        return ((g_seed >> 16) & 0x7FFF) % mod;
    }
    
    public Elem() { }
    public Elem(int a, int bid, int bid2, int l, int isl)
    {
        action = a;
        BridgemanID = bid;
        BridgemanID2 = bid2;
        length = l;
        islandID = isl;
    }

    public static Elem GenerateAction(List<Bridgeman> bridgemen, int N, int B)
    {
        int action=-1;
        int BridgemanID;
        int BridgemanID2=-1;
        int length=0;
        int islandID=-1;



        action = Rand(5);
        BridgemanID = bridgemen[Rand(B)].ID;
        if (action < 3)
        {
            islandID = Rand(N);
        }
        else if (action >= 3)
        {
            islandID = Rand(N);
            Bridgeman other = bridgemen
            .Where(b => b.ID != BridgemanID)
            .OrderBy(_ => Guid.NewGuid()) // mélange aléatoire
            .FirstOrDefault();
            BridgemanID2 = other.ID;
            int lb = bridgemen.Where(b => b.ID == BridgemanID).First().Bricks;
            length = Rand(lb)+1;

        }

        Elem el = new Elem(action, BridgemanID, BridgemanID2, length, islandID);

        return el;
    

    }

    public static Elem GenerateActionFB1(int bid, List<Bridgeman> bridgemen, int N, int B)
    {
        int action = -1;
        int BridgemanID;
        int BridgemanID2 = 1000000;
        int length = 0;
        int islandID = 1000000;



        action = Rand(5);
        BridgemanID = bid;
        if (action < 3)
        {
            islandID = Rand(N);
        }
        else if (action >= 3)
        {
            islandID = Rand(N);
            Bridgeman other = bridgemen
            .Where(b => b.ID != BridgemanID)
            .OrderBy(_ => Guid.NewGuid()) // mélange aléatoire
            .FirstOrDefault();
            BridgemanID2 = other.ID;
            int lb = bridgemen.Where(b => b.ID == BridgemanID).First().Bricks;
            if(lb > 0)length = Rand(lb);
            if (length == 0) length = 1;

        }

        Elem el = new Elem(action, BridgemanID, BridgemanID2, length, islandID);

        return el;


    }

    public static Elem GenerateActionFB(int bid, List<Bridgeman> bridgemen, int N, int B, int[,] dists)
    {
        int action = Rand(5);
        int BridgemanID = bid;
        int BridgemanID2 = 1000000;
        int length = 0;
        int islandID = 1000000;

        if (action < 3)
        {
            islandID = Rand(N);
        }
        else
        {
            // pick partner
            var others = bridgemen.Where(b => b.ID != BridgemanID).ToList();
            if (others.Count == 0) { action = Rand(3); islandID = Rand(N); return new Elem(action, BridgemanID, 1000000, 0, islandID); }
            Bridgeman b1 = bridgemen.First(b => b.ID == BridgemanID);
            Bridgeman b2 = others[Rand(others.Count)];

            BridgemanID2 = b2.ID;
            int dist = dists[b1.Position, b2.Position];

            // valid dist?
            if (dist <= 1)
            {
                // impossible de faire team action quand dist <= 1
                action = Rand(3);
                islandID = Rand(N);
                return new Elem(action, BridgemanID, 1000000, 0, islandID);
            }

            int maxPrimary = Math.Min(b1.Bricks, dist - 1);                // primary ne doit pas couvrir tout seul
            int minPrimary = Math.Max(1, dist - b2.Bricks);                 // helper doit pouvoir couvrir le reste

            if (maxPrimary < minPrimary)
            {
                // aucune longueur possible -> downgrade (pas de team action réaliste)
                action = Rand(3);
                islandID = Rand(N);
                return new Elem(action, BridgemanID, 1000000, 0, islandID);
            }

            // choisir len entre minPrimary et maxPrimary
            int range = maxPrimary - minPrimary + 1;
            length = minPrimary + Rand(range); // minPrimary..maxPrimary
            islandID = Rand(N);
        }

        return new Elem(action, BridgemanID, BridgemanID2, length, islandID);
    }


}

class Player
{
    const long INF = (long)9e18;

    int N;
    int O;
    int B;
    int[,] dists;
    public int elapsedTime = 0;
    List<Bridgeman> bman;
    bool[] border;
    AllPairsDijkstra adijkstra;
    HashSet<Tuple<int, int>> horder = new HashSet<Tuple<int, int>>();
    public int INDBR = -1;
    public Player() { }

    public Player(int N, int O, int B, int[,] dists)
    {
        this.N = N;
        this.O = O;
        this.B = B;
        this.dists = dists;

        bman = Enumerable.Range(0, B).Select(i => new Bridgeman { ID = i }).ToList();
        for (int i = 0; i < B; ++i)
        {
            bman[i].order = new Order();
            bman[i].order.From = -1;
            bman[i].order.To = -1;
        }
        border = new bool[10];
        for (int i = 0; i < 10; ++i) border[i] = false;

        adijkstra = new AllPairsDijkstra();
        adijkstra.Start(N, O, B, dists);
    }

    public List<string> Simulation(bool[,] connected, List<Bridgeman> bridgemen, List<Order> orders)
    {
        for (int i = 0; i < B; ++i)
        {
            bman[i].path.Clear();
            bman[i].step = 0;
            bman[i].main_step = 0;
            bman[i].ind_path = 0;
            bridgemen[i].adjikstra = null;
        }

        int timeLimit = 5;
        int maxt = 0;
        Stopwatch stopwatch = Stopwatch.StartNew();

        List<Elem> best_action = new List<Elem>();
        int best_score = -100000000;
        while (stopwatch.ElapsedMilliseconds < timeLimit)
        {
            List<Elem> lelem = new List<Elem>();
            HashSet<int> usedThisTurn = new HashSet<int>();
            HashSet<Tuple<int, int>> unpack_hash = new HashSet<Tuple<int, int>>();
            HashSet<Tuple<int, int>> pack_hash = new HashSet<Tuple<int, int>>();
            int score = 0;
            for (int i = 0; i < B; ++i)
            {
                if (usedThisTurn.Contains(bridgemen[i].ID)) continue;
                Elem action_elem = Elem.GenerateActionFB(bridgemen[i].ID, bridgemen, N, B, dists);

                if (action_elem.action == 0)
                {
                    Bridgeman b1 = bridgemen.Where(b => b.ID == bridgemen[i].ID).First();
                    if (connected[action_elem.islandID, b1.Position] && b1.Position != action_elem.islandID &&
                       !pack_hash.Contains(Tuple.Create(action_elem.islandID, b1.Position)))
                    {
                        lelem.Add(action_elem);

                        if (b1.Target != -1)
                        {
                            score += 500 - dists[action_elem.islandID, b1.Target];

                        }
                        else
                        {
                            int mini = 1000000;
                            for (int o = 0; o < O; ++o)
                            {
                                int d = dists[b1.Position, orders[o].From];
                                if (d < mini)
                                {
                                    mini = d;
                                }
                            }
                            score += 100 - mini;
                        }
                        if (b1.Target == action_elem.islandID) score += 10000;
                    }
                    else continue;
                }
                else if (action_elem.action == 1)
                {
                    Bridgeman b1 = bridgemen.Where(b => b.ID == bridgemen[i].ID).First();
                    if (!connected[action_elem.islandID, b1.Position] && b1.Bricks >= dists[b1.Position, action_elem.islandID] &&
                        b1.Position != action_elem.islandID && !unpack_hash.Contains(Tuple.Create(action_elem.islandID, b1.Position)))
                    {
                        unpack_hash.Add(Tuple.Create(action_elem.islandID, b1.Position));
                        unpack_hash.Add(Tuple.Create(b1.Position, action_elem.islandID));
                        lelem.Add(action_elem);
                        score += 22;
                    }
                    else continue;
                }
                else if (action_elem.action == 2)
                {
                    Bridgeman b1 = bridgemen.Where(b => b.ID == bridgemen[i].ID).First();
                    if (connected[action_elem.islandID, b1.Position] && b1.Position != action_elem.islandID &&
                        !pack_hash.Contains(Tuple.Create(action_elem.islandID, b1.Position)))
                    {
                        if (b1.Bricks + dists[action_elem.islandID, b1.Position] > 60) continue;
                        lelem.Add(action_elem);
                        pack_hash.Add(Tuple.Create(action_elem.islandID, b1.Position));
                        pack_hash.Add(Tuple.Create(b1.Position, action_elem.islandID));
                        score += dists[action_elem.islandID, b1.Position] / 2;
                    }
                    else continue;
                }
                else if (action_elem.action == 3)
                {
                    if (usedThisTurn.Contains(action_elem.BridgemanID2)) continue;
                    Bridgeman b1 = bridgemen.Where(b => b.ID == bridgemen[i].ID).First();
                    Bridgeman b2 = bridgemen.Where(b => b.ID == action_elem.BridgemanID2).First();
                    int lb1 = b1.Bricks;
                    int lb2 = b2.Bricks;

                    if ((lb1 > 0) && (lb2 > 0) && (lb1 >= action_elem.length) && (lb2 >= (dists[b1.Position, b2.Position] - action_elem.length)) && ((action_elem.length + lb2) >= dists[b1.Position, b2.Position])
                        && b1.Position != b2.Position && !connected[b1.Position, b2.Position] && !unpack_hash.Contains(Tuple.Create(b1.Position, b2.Position)))
                    {
                        if (action_elem.length >= dists[b1.Position, b2.Position]) continue;
                        unpack_hash.Add(Tuple.Create(b1.Position, b2.Position));
                        unpack_hash.Add(Tuple.Create(b2.Position, b1.Position));
                        usedThisTurn.Add(action_elem.BridgemanID2);
                        lelem.Add(action_elem);
                        score += 20;
                    }
                    else continue;

                }
                else if (action_elem.action == 4)
                {
                    if (usedThisTurn.Contains(action_elem.BridgemanID2)) continue;
                    Bridgeman b1 = bridgemen.Where(b => b.ID == bridgemen[i].ID).First();
                    Bridgeman b2 = bridgemen.Where(b => b.ID == action_elem.BridgemanID2).First();
                    int lb1 = b1.Bricks;
                    int lb2 = b2.Bricks;

                    if (connected[b1.Position, b2.Position] && b1.Position != b2.Position && !pack_hash.Contains(Tuple.Create(b1.Position, b2.Position)))
                    {
                        if (action_elem.length >= dists[b1.Position, b2.Position]) continue;
                        if ((60 - lb1) < action_elem.length) continue;
                        if ((60 - lb2) < (dists[b1.Position, b2.Position] - action_elem.length)) continue;
                        pack_hash.Add(Tuple.Create(b1.Position, b2.Position));
                        pack_hash.Add(Tuple.Create(b2.Position, b1.Position));
                        usedThisTurn.Add(action_elem.BridgemanID2);
                        lelem.Add(action_elem);
                        score += 30;
                    }
                    else continue;

                }

                usedThisTurn.Add(bridgemen[i].ID);


            }

            if (score > best_score)
            {
                best_score = score;
                best_action = lelem;
            }

        }

        List<string> output = new List<string>();
        for (int i = 0; i < best_action.Count; ++i)
        {
            Elem action_elem = best_action[i];
            if (action_elem.action == 0)
            {
                output.Add("MOVE " + action_elem.BridgemanID + " " + action_elem.islandID);
                Bridgeman b1 = bridgemen.Where(b => b.ID == action_elem.BridgemanID).First();

            }
            else if (action_elem.action == 1)
            {
                output.Add("UNPACK " + action_elem.BridgemanID + " " + action_elem.islandID);
                Bridgeman b1 = bridgemen.Where(b => b.ID == action_elem.BridgemanID).First();
                b1.Bricks = Math.Max(0, b1.Bricks - action_elem.length);
                connected[b1.Position, action_elem.islandID] = true;
                connected[action_elem.islandID, b1.Position] = true;
            }
            else if (action_elem.action == 2)
            {
                output.Add("PACK " + action_elem.BridgemanID + " " + action_elem.islandID);
                Bridgeman b1 = bridgemen.Where(b => b.ID == action_elem.BridgemanID).First();
                b1.Bricks += action_elem.length;
                connected[b1.Position, action_elem.islandID] = false;
                connected[action_elem.islandID, b1.Position] = false;
            }
            else if (action_elem.action == 3)
            {
                output.Add("TEAMUNPACK " + action_elem.BridgemanID + " " + action_elem.BridgemanID2 + " " + action_elem.length);
                Bridgeman b1 = bridgemen.Where(b => b.ID == action_elem.BridgemanID).First();
                Bridgeman b2 = bridgemen.Where(b => b.ID == action_elem.BridgemanID2).First();

                /*int dist = dists[b1.Position, b2.Position];
                int len = action_elem.length;
                int lb1 = b1.Bricks;
                int lb2 = b2.Bricks;
                int neededFromB2 = dist - len;
                int total = lb1 + lb2;

                int id1 = action_elem.BridgemanID;
                int id2 = action_elem.BridgemanID2;

                // DEBUG log clair
                Console.Error.WriteLine($"TEAMUNPACK {id1} {id2} len={len} dist={dist} lb1={lb1} lb2={lb2} needB2={neededFromB2} total={total}");

                // validations détaillées
                if (len <= 0) { Console.Error.WriteLine("Invalid TEAMUNPACK: length <= 0"); continue; }
                if (b1.Position == b2.Position) { Console.Error.WriteLine("Invalid TEAMUNPACK: same position"); continue; }
                if (dist <= 0) { Console.Error.WriteLine("Invalid TEAMUNPACK: invalid distance"); continue; }
                if (len >= dist) { Console.Error.WriteLine("Invalid TEAMUNPACK: primary length >= distance (should be <)"); continue; }
                if (lb1 < len) { Console.Error.WriteLine($"Invalid TEAMUNPACK: primary ({id1}) lacks bricks ({lb1} < {len})"); continue; }
                if (lb2 < neededFromB2) { Console.Error.WriteLine($"Invalid TEAMUNPACK: partner ({id2}) lacks bricks ({lb2} < {neededFromB2})"); continue; }
                if (total < dist) { Console.Error.WriteLine($"Invalid TEAMUNPACK: not enough total ({total} < {dist})"); continue; }
                */

                b1.Bricks = Math.Max(0, b1.Bricks - action_elem.length);
                b2.Bricks = Math.Max(0, b2.Bricks - (dists[b1.Position, b2.Position] - action_elem.length));
                //Console.Error.WriteLine("--TEAMUNPACK " + action_elem.BridgemanID + " " + action_elem.BridgemanID2 + " " + action_elem.length + " " + b1.Bricks + "/" + b2.Bricks+"="+ dists[b1.Position, b2.Position]);
                connected[b1.Position, b2.Position] = true;
                connected[b2.Position, b1.Position] = true;
            }
            else if (action_elem.action == 4)
            {
                output.Add("TEAMPACK " + action_elem.BridgemanID + " " + action_elem.BridgemanID2 + " " + action_elem.length);
                Bridgeman b1 = bridgemen.Where(b => b.ID == action_elem.BridgemanID).First();
                Bridgeman b2 = bridgemen.Where(b => b.ID == action_elem.BridgemanID2).First();
                //Console.Error.WriteLine("--TEAMPACK " + action_elem.BridgemanID + " " + action_elem.BridgemanID2 + " " + action_elem.length + " " + b1.Bricks + "/" + b2.Bricks + "=" + dists[b1.Position, b2.Position] + ", " + action_elem.length + " + " + (dists[b1.Position, b2.Position] - action_elem.length));

                b1.Bricks += action_elem.length;
                b2.Bricks += dists[b1.Position, b2.Position] - action_elem.length;

                connected[b1.Position, b2.Position] = false;
                connected[b2.Position, b1.Position] = false;
            }


        }

        return output;

    }


    public List<String> SimulationD(bool[,] connected, List<Bridgeman> bridgemen, List<Order> orders)
    {
        if (INDBR != -1)
        {

            for (int i = 0; i < B; ++i)
            {
                bman[i].step = 0;
                bman[i].ind_path = 0;
                bman[i].path.Clear();
                bman[i].main_step = 0;
                bman[i].have_unpack = false;
                bman[i].helper = false;
                bman[i].num_helper = -1;
                bman[i].in_help = false;
                bman[i].num_in_help = -1;
                bman[i].construct_help = false;
                bman[i].step_help = 0;
                bman[i].step_in_help = 0;
                bman[i].pos_construct = -1;
                INDBR = -1;
                horder.Clear();
            }

        }

        for (int i = 0; i < B; ++i)
        {
            if (bridgemen[i].adjikstra == null)
            {
                bridgemen[i].adjikstra = new AllPairsDijkstra();
                bridgemen[i].adjikstra.DMAX = bridgemen[i].Bricks;
                bridgemen[i].adjikstra.Start(N, O, B, dists);
            }
        }

        //Init bridgeman
        for (int i = 0; i < O; ++i)
        {
            if (horder.Contains(Tuple.Create(orders[i].From, orders[i].To))) continue;
            long maxscore = -1000000;
            int indb = -1;
            for (int j = 0; j < B; ++j)
            {
                if (bridgemen[j].Target != -1 && bman[j].path.Count > 0) continue;
                if (bman[j].path.Count > 0) continue;
                long dist = bridgemen[j].adjikstra.distAll[bridgemen[j].Position, orders[i].From];// + bridgemen[j].adjikstra.distAll[orders[i].From, orders[i].To];
                //if (dist == INF || dist < 0) continue;
                long score = 1000 - dist + bridgemen[j].Bricks;
                if (score > maxscore)
                {
                    maxscore = score;
                    indb = j;
                }

            }

            if (indb != -1)
            {
                bman[indb].ind_path = 1;
                bman[indb].step = 0;
                bman[indb].main_step = 0;
                bman[indb].path = bridgemen[indb].adjikstra.ReconstructPath(bridgemen[indb].Position, orders[i].From, bridgemen[indb].adjikstra.parentAll.GetRow(bridgemen[indb].Position));
                bman[indb].order = new Order();
                bman[indb].order.From = orders[i].From;
                bman[indb].order.To = orders[i].To;
                border[i] = true;
                horder.Add(Tuple.Create(orders[i].From, orders[i].To));
            }

        }

        for (int i = 0; i < B; ++i)
        {
            if (bman[i].main_step == 0 && bman[i].step == 0 && bridgemen[i].Target != -1)
            {
                bman[i].main_step = 1;
                bman[i].path.Clear();
            }
        }

        for (int i = 0; i < B; ++i)
        {
            if (bman[i].main_step != 1) continue;
            if (bman[i].path.Count > 0) continue;
            if (bridgemen[i].Target == -1) continue;
            bman[i].ind_path = 1;
            bman[i].step = 0;
            /*bman[i].main_step = 1;
            bman[i].order = new Order();
            bman[i].order.From = -1;
            bman[i].order.To = -1;*/
            bman[i].path = bridgemen[i].adjikstra.ReconstructPath(bridgemen[i].Position, bridgemen[i].Target, bridgemen[i].adjikstra.parentAll.GetRow(bridgemen[i].Position));


        }

        List<string> output = new List<string>();

        for (int i = 0; i < B; ++i)
        {
            if (bman[i].path.Count == 1)
            {
                bman[i].path.Clear();
            }
            if (bman[i].path.Count == 0) continue;



            //verif step
            int STEP = bman[i].step;
            if (bman[i].step == 0)
            {
                //Console.Error.WriteLine("id=" + i + ", path=" + bman[i].path.Count + ", " + bman[i].ind_path);
                /*if(bridgemen[i].Bricks < dists[bridgemen[i].Position, bman[i].path[bman[i].ind_path]])
                {
                    STEP = -1;
                }
                else*/

                if(bman[i].ind_path >= bman[i].path.Count)
                {
                    STEP = -1;
                }
                else if (connected[bridgemen[i].Position, bman[i].path[bman[i].ind_path]])
                {
                    STEP++;
                }

            }

            if (bman[i].step == 1)
            {
                if (!connected[bridgemen[i].Position, bman[i].path[bman[i].ind_path]])
                {
                    STEP--;
                }

            }

            if (bman[i].step == 2)
            {
                if (!connected[bridgemen[i].Position, bman[i].path[bman[i].ind_path - 2]] || !bman[i].have_unpack)
                {
                    STEP = -1;
                }

            }

            //Console.Error.WriteLine("b" + i + ", STEP=" + STEP);

            if (STEP != -1)
            {
                if (STEP == 0)
                {
                    output.Add("UNPACK " + bridgemen[i].ID + " " + bman[i].path[bman[i].ind_path]);
                    bman[i].step = 1;
                    bman[i].have_unpack = true;
                    connected[bridgemen[i].Position, bman[i].path[bman[i].ind_path]] = true;
                    connected[bman[i].path[bman[i].ind_path], bridgemen[i].Position] = true;

                }
                else if (STEP == 1)
                {
                    output.Add("MOVE " + bridgemen[i].ID + " " + bman[i].path[bman[i].ind_path]);
                    bman[i].ind_path++;
                    bman[i].step = 2;
                }
                else if (STEP == 2)
                {
                    output.Add("PACK " + bridgemen[i].ID + " " + bman[i].path[bman[i].ind_path - 2]);
                    connected[bridgemen[i].Position, bman[i].path[bman[i].ind_path - 2]] = false;
                    connected[bman[i].path[bman[i].ind_path - 2], bridgemen[i].Position] = false;
                    bman[i].step = 0;
                    bman[i].have_unpack = false;
                    if (bman[i].main_step == 0 && bman[i].ind_path == bman[i].path.Count)// && horder.Contains(Tuple.Create(bman[i].order.From, bman[i].order.To)))
                    {
                        bman[i].main_step = 1;


                        bman[i].path.Clear();
                        bman[i].ind_path = 0;


                    }
                    else if (bman[i].main_step == 1 && bman[i].ind_path == bman[i].path.Count)
                    {
                        horder.Remove(Tuple.Create(bman[i].order.From, bman[i].order.To));
                        bman[i].main_step = 0;
                        bman[i].path.Clear();
                        bman[i].ind_path = 0;



                    }

                }




            }
            else
            {
                if (bman[i].main_step == 1 && bman[i].step == 2 && !bman[i].have_unpack && bman[i].ind_path == bman[i].path.Count)
                {
                    bman[i].main_step = 0;
                    bman[i].step = 0;
                    bman[i].path.Clear();
                    bman[i].ind_path = 0;
                    bman[i].have_unpack = false;
                }
                else if (bman[i].main_step == 1 && bman[i].step == 2 && !bman[i].have_unpack)
                {
                    bman[i].step = 0;
                }
            }

        }

        /*for(int i = 0;i < B; ++i)
        {
            Console.Error.WriteLine("id=" + bridgemen[i].ID + ", path=" + bman[i].ind_path + "/" + bman[i].path.Count + ", ms=" + bman[i].step + "/" + bman[i].main_step);
            for(int j = 0;j < bman[i].path.Count; ++j)
            {
                Console.Error.Write(bman[i].path[j] + " ");
            }
            Console.Error.WriteLine();
        }*/


        return output;

    }


    public List<String> SimulationH(bool[,] connected, List<Bridgeman> bridgemen, List<Order> orders)
    {

        for (int i = 0; i < B; ++i)
        {
            if (bman[i].helper || bman[i].in_help) continue;
            if (bridgemen[i].Position == bridgemen[i].Target) continue;
            if (bman[i].step == 0)
            {
                //if (!connected[bridgemen[i].Position, bman[i].path[bman[i].ind_path]] &&
                //    dists[bridgemen[i].Position, bman[i].path[bman[i].ind_path]] > bridgemen[i].Bricks &&
                if(bridgemen[i].Target != -1 &&  bman[i].path.Count == 0)
                {
                    int V = bridgemen[i].Target; // bman[i].path[bman[i].ind_path];

                    //help
                    int indb = -1;
                    long maxi = -1000000;
                    for(int j = 0;j < B; ++j)
                    {
                        if (i == j) continue;
                        long dist = bridgemen[j].adjikstra.distAll[bridgemen[j].Position, V];
                        long score = 1000 - dist;
                        if(score > maxi)
                        {
                            maxi = score;
                            indb = j;

                        }
                    }

                    if(indb != -1)
                    {
                        bman[indb].ind_path = 1;
                        bman[indb].step = 0;
                        bman[indb].main_step = 0;
                        bman[indb].path = bridgemen[indb].adjikstra.ReconstructPath(bridgemen[indb].Position, V, bridgemen[indb].adjikstra.parentAll.GetRow(bridgemen[indb].Position));
                        bman[indb].helper = true;
                        bman[indb].num_in_help = i;
                        bman[i].in_help = true;
                        bman[i].num_helper = indb;
                    }

                }

            }
                      
        }

        List<string> output = new List<string>();

        for (int i = 0; i < B; ++i)
        {
            if (bman[i].path.Count == 1)
            {
                bman[i].path.Clear();
            }
            if (bman[i].path.Count == 0) continue;

            if (!bman[i].helper) continue;
            if (bman[i].construct_help) continue;

                       
            //verif step
            int STEP = bman[i].step;
            if (bman[i].step == 0)
            {
                Console.Error.WriteLine("id=" + i + ", path=" + bman[i].path.Count + ", " + bman[i].ind_path);
                for (int ii = 0; ii < B; ++ii)
                {
                    Console.Error.WriteLine("id=" + bridgemen[ii].ID + ", path=" + bman[ii].ind_path + "/" + bman[ii].path.Count + ", ms=" + bman[ii].step + "/" + bman[ii].main_step);
                    for (int j = 0; j < bman[ii].path.Count; ++j)
                    {
                        Console.Error.Write(bman[ii].path[j] + " ");
                    }
                    Console.Error.WriteLine();
                }
                /*if(bridgemen[i].Bricks < dists[bridgemen[i].Position, bman[i].path[bman[i].ind_path]])
                {
                    STEP = -1;
                }
                else*/
                if (connected[bridgemen[i].Position, bman[i].path[bman[i].ind_path]])
                {
                    STEP++;
                }

            }

            if (bman[i].step == 1)
            {
                if (!connected[bridgemen[i].Position, bman[i].path[bman[i].ind_path]])
                {
                    STEP--;
                }

            }

            if (bman[i].step == 2)
            {
                if (!connected[bridgemen[i].Position, bman[i].path[bman[i].ind_path - 2]] || !bman[i].have_unpack)
                {
                    STEP = -1;
                }

            }

            //Console.Error.WriteLine("b" + i + ", STEP=" + STEP);

            if (STEP != -1)
            {
                if (STEP == 0)
                {
                    output.Add("UNPACK " + bridgemen[i].ID + " " + bman[i].path[bman[i].ind_path]);
                    bman[i].step = 1;
                    bman[i].have_unpack = true;
                    connected[bridgemen[i].Position, bman[i].path[bman[i].ind_path]] = true;
                    connected[bman[i].path[bman[i].ind_path], bridgemen[i].Position] = true;

                }
                else if (STEP == 1)
                {
                    output.Add("MOVE " + bridgemen[i].ID + " " + bman[i].path[bman[i].ind_path]);
                    bman[i].ind_path++;
                    bman[i].step = 2;
                }
                else if (STEP == 2)
                {
                    output.Add("PACK " + bridgemen[i].ID + " " + bman[i].path[bman[i].ind_path - 2]);
                    connected[bridgemen[i].Position, bman[i].path[bman[i].ind_path - 2]] = false;
                    connected[bman[i].path[bman[i].ind_path - 2], bridgemen[i].Position] = false;
                    bman[i].step = 0;
                    bman[i].have_unpack = false;
                    if (bman[i].main_step == 0 && bman[i].ind_path == bman[i].path.Count)// && horder.Contains(Tuple.Create(bman[i].order.From, bman[i].order.To)))
                    {
                        bman[i].construct_help = true;
                        bman[i].step_help = 0;
                        bman[INDBR].construct_help = true;
                        bman[INDBR].step_help = 0;

                    }
                    

                }




            }
            /*else
            {
                if (bman[i].main_step == 1 && bman[i].step == 2 && !bman[i].have_unpack && bman[i].ind_path == bman[i].path.Count)
                {
                    bman[i].main_step = 0;
                    bman[i].step = 0;
                    bman[i].path.Clear();
                    bman[i].ind_path = 0;
                    bman[i].have_unpack = false;
                }
                else if (bman[i].main_step == 1 && bman[i].step == 2 && !bman[i].have_unpack)
                {
                    bman[i].step = 0;
                }
            }*/

        }


        for (int i = 0; i < B; ++i)
        {
            if (!bman[i].helper) continue;
            if (!bman[i].construct_help) continue;

            int STEP = bman[i].step_help;

            if(bman[i].step_help == 0)
            {
                if (connected[bridgemen[i].Position, bman[INDBR].Position])
                {
                    STEP++;
                }
            }

            if (bman[i].step_help == 1)
            {
                if (!connected[bridgemen[i].Position, bman[INDBR].Position])
                {
                    STEP--;
                }

            }

            if (bman[i].step_help == 2)
            {
                if (!connected[bridgemen[i].Position, bman[INDBR].Position] || !bman[i].have_unpack)
                {
                    STEP = -1;
                }

            }

            if(STEP != -1)
            {
                if (STEP == 0)
                {
                    output.Add("TEAMUNPACK " + bridgemen[i].ID + " " + bman[INDBR].ID + " " + (int)(dists[bridgemen[i].Position, bman[INDBR].Position]/2) );
                    bman[i].step_help = 1;
                    bman[i].have_unpack = true;
                    connected[bridgemen[i].Position, bman[INDBR].Position] = true;
                    connected[bman[INDBR].Position, bridgemen[i].Position] = true;

                }
                else if (STEP == 1)
                {
                    output.Add("MOVE " + bridgemen[i].ID + " " + bman[INDBR].Position);
                    output.Add("MOVE " + bman[INDBR].ID + " " + bridgemen[i].Position);
                    bman[i].step_help = 2;
                    bman[INDBR].step_help = 2;
                }
                else if (STEP == 2)
                {
                    output.Add("TEAMPACK " + bridgemen[i].ID + " " + bman[i].path[bman[i].ind_path - 2]);
                    connected[bridgemen[i].Position, bman[INDBR].Position] = false;
                    connected[bman[INDBR].Position, bridgemen[i].Position] = false;
                    bman[i].step_help = 0;
                    bman[i].have_unpack = false;
                    if (bman[i].main_step == 0 && bman[i].ind_path == bman[i].path.Count)// && horder.Contains(Tuple.Create(bman[i].order.From, bman[i].order.To)))
                    {
                        bman[i].construct_help = false;
                        bman[i].step_help = 0;
                        bman[INDBR].construct_help = false;
                        bman[INDBR].step_help = 0;

                        bman[i].helper = false;
                        bman[INDBR].in_help = false;
                        bman[i].num_in_help = -1;
                        bman[INDBR].in_help = false;
                        bman[INDBR].num_helper = -1;

                    }


                }

            }

        }





        return output;

    }

    public List<String> SimulationH2(bool[,] connected, List<Bridgeman> bridgemen, List<Order> orders)
    {
        //Console.Error.WriteLine("indbr0=" + INDBR);
        //INDBR = -1;
        //Console.Error.WriteLine("indbr1=" +INDBR);
        if (INDBR == -1)
        {

            for (int i = 0; i < B; ++i)
            {
                bman[i].step = 0;
                bman[i].ind_path = 0;
                bman[i].path.Clear();
                bman[i].main_step = 0;
                bman[i].have_unpack = false;
                bman[i].helper = false;
                bman[i].num_helper = -1;
                bman[i].in_help = false;
                bman[i].num_in_help = -1;
                bman[i].construct_help = false;
                bman[i].step_help = 0;
                bman[i].step_in_help = 0;
                bman[i].pos_construct = -1;

            }

            long maxib = -1000000;
            int indbr = -1;

            for (int i = 0; i < B; ++i)
            {
                if (bridgemen[i].Target != -1 && bman[i].path.Count == 0)
                {
                    int V = bridgemen[i].Target;

                    long dist = adijkstra.distAll[bridgemen[i].Position, V];
                    long score = 1000 - dist;

                    bool valid = false;
                    List<int> path = adijkstra.ReconstructPath(bridgemen[i].Position, bridgemen[i].Target, adijkstra.parentAll.GetRow(bridgemen[i].Position));
                    for (int p = 0; p < path.Count - 1; ++p)
                    {
                        long dista = dists[path[p], path[p + 1]];

                        if (dista > bridgemen[i].Bricks)
                        {
                            valid = true;
                        }
                    }

                    if (valid && score > maxib)
                    {
                        maxib = score;
                        indbr = i;

                    }


                }

            }

            bool get_back = true;
            //Console.Error.WriteLine("indbr=" + indbr);

            if (indbr != -1)
            {
                bman[indbr].ind_path = 1;
                bman[indbr].step = 0;
                bman[indbr].main_step = 0;
                bman[indbr].path = adijkstra.ReconstructPath(bridgemen[indbr].Position, bridgemen[indbr].Target, adijkstra.parentAll.GetRow(bridgemen[indbr].Position));
                //Console.Error.WriteLine("PATH=" + bman[indbr].path.Count);
                INDBR = indbr;

                HashSet<int> helpers = new HashSet<int>();
                for (int p = 0; p < bman[INDBR].path.Count - 1; ++p)
                {
                    long dist = dists[bman[INDBR].path[p], bman[INDBR].path[p + 1]];

                    if (dist > bridgemen[INDBR].Bricks)
                    {
                        long maxis = -1000000;
                        int indb = -1;
                        //calc helpers
                        for (int i = 0; i < B; ++i)
                        {
                            if (i == INDBR) continue;

                            long score = 1000 - bridgemen[i].adjikstra.distAll[bridgemen[i].Position, bman[INDBR].path[p + 1]];
                            if (score > maxis && score > 0)
                            {
                                maxis = score;
                                indb = i;
                            }

                        }

                        if (indb != -1 && !helpers.Contains(indb))
                        {
                            get_back = false;

                            bman[indb].ind_path = 1;
                            bman[indb].step = 0;
                            bman[indb].main_step = 0;
                            if (bridgemen[indb].Position != bman[INDBR].path[p + 1])
                            {
                                bman[indb].path = bridgemen[indb].adjikstra.ReconstructPath(bridgemen[indb].Position, bman[INDBR].path[p + 1], bridgemen[indb].adjikstra.parentAll.GetRow(bridgemen[indb].Position));
                            }
                            else
                            {
                                bman[indb].path.Clear();
                                bman[indb].construct_help = true;
                                bman[indb].step_help = 0;
                                bman[INDBR].construct_help = true;
                                bman[INDBR].step_help = 0;

                                
                                
                            }

                            //Console.Error.WriteLine("CH=" + indb + " " + INDBR);

                            bman[indb].helper = true;
                            bman[indb].num_in_help = INDBR;

                            bman[indb].pos_construct = bman[INDBR].path[p + 1];
                            bman[INDBR].in_help = true;
                            bman[INDBR].num_helper = indb;
                            helpers.Add(indb);

                        }


                    }

                }



            }

            if (get_back) return new List<string>();



        }


        /*Console.Error.WriteLine("INDBR=" + INDBR);
        for (int j = 0; j < bman[INDBR].path.Count; ++j)
        {
            Console.Error.Write(bman[INDBR].path[j] + " ");
        }
        Console.Error.WriteLine();*/

        List<string> output = new List<string>();
        /*for (int i = 0; i < B; ++i)
        {
            Console.Error.WriteLine("id=" + bridgemen[i].ID + ", brick=" + bridgemen[i].Bricks  + " " + bman[i].helper + " " + bman[i].construct_help + " " + bman[i].pos_construct + " steph" + bman[i].step_help + ", s="+bman[i].step);
        }*/

        HashSet<int> huse = new HashSet<int>();

        bool team_pack = false;
        bool move = false;
        for (int i = 0; i < B; ++i)
        {

            if (!bman[i].helper) continue;
            //Console.Error.WriteLine(i + " " + dists[bridgemen[i].Position, bridgemen[INDBR].Position]);
            if (!bman[i].construct_help) continue;
            //Console.Error.WriteLine(i + " ERROR=" + bridgemen[i].Position + " " + bman[i].pos_construct);
            if (bman[i].step_help < 2 && bridgemen[i].Position != bman[i].pos_construct) continue;
            if (i == INDBR) continue;

            int STEP = bman[i].step_help;

            if (bman[i].step_help == 0)
            {
                //((bridgemen[i].Bricks + bridgemen[INDBR].Bricks) < dists[bridgemen[i].Position, bridgemen[INDBR].Position]))
                if (connected[bridgemen[i].Position, bridgemen[INDBR].Position])
                    
                {
                    STEP++;
                }
            }

            if (bman[i].step_help == 1)
            {
                if (!connected[bridgemen[i].Position, bridgemen[INDBR].Position])
                {
                    STEP--;
                }

            }

            if (bman[i].step_help == 2)
            {
                if (!connected[bridgemen[i].Position, bridgemen[INDBR].Position] )//|| !bman[i].have_unpack)
                {
                    STEP = -1;
                }

            }

            if (STEP != -1)
            {
                if (STEP == 0 && dists[bridgemen[i].Position, bridgemen[INDBR].Position] <= 100 &&
                    bridgemen[INDBR].Bricks+ bridgemen[i].Bricks >= dists[bridgemen[i].Position, bridgemen[INDBR].Position] &&
                    bman[i].step_help == 0 && bman[INDBR].step_help == 0 && bman[INDBR].step != 2)
                {
                    //Console.Error.WriteLine("distance=" + dists[bridgemen[i].Position, bridgemen[INDBR].Position] + " / " + bridgemen[i].Bricks + " " +
                    //   bridgemen[INDBR].Bricks);
                    output.Add("TEAMUNPACK " + bridgemen[i].ID + " " + bman[INDBR].ID + " " + (int)((dists[bridgemen[i].Position, bridgemen[INDBR].Position]) / 2));
                    bman[i].step_help = 1;
                    bman[i].have_unpack = true;
                    bman[INDBR].step_help = 1;
                    bman[INDBR].have_unpack = true;
                    huse.Add(bridgemen[i].ID);
                    huse.Add(bridgemen[INDBR].ID);

                    connected[bridgemen[i].Position, bridgemen[INDBR].Position] = true;
                    connected[bridgemen[INDBR].Position, bridgemen[i].Position] = true;

                    break;

                }
                else if (STEP == 1)
                {
                    output.Add("MOVE " + bridgemen[i].ID + " " + bridgemen[INDBR].Position);
                    output.Add("MOVE " + bman[INDBR].ID + " " + bridgemen[i].Position);
                    move = true;
                    bman[i].step_help = 2;
                    bman[INDBR].step_help = 2;
                    bman[INDBR].ind_path++;

                    huse.Add(bridgemen[i].ID);
                    huse.Add(bridgemen[INDBR].ID);

                    break;
                }
                else if (STEP == 2)
                {
                    output.Add("TEAMPACK " + bridgemen[i].ID + " " + bridgemen[INDBR].ID + " " + (int)((dists[bridgemen[i].Position, bridgemen[INDBR].Position]) / 2));
                    connected[bridgemen[i].Position, bridgemen[INDBR].Position] = false;
                    connected[bridgemen[INDBR].Position, bridgemen[i].Position] = false;

                    huse.Add(bridgemen[i].ID);
                    huse.Add(bridgemen[INDBR].ID);

                    bman[i].step_help = 0;
                    bman[i].have_unpack = false;
                    bman[INDBR].step_help = 0;
                    bman[INDBR].have_unpack = false;
                    team_pack = true;
                    if (bman[i].ind_path == bman[i].path.Count)// && horder.Contains(Tuple.Create(bman[i].order.From, bman[i].order.To)))
                    {
                        bman[i].construct_help = false;
                        bman[i].step_help = 0;
                        bman[INDBR].construct_help = false;
                        bman[INDBR].step_help = 0;

                        bman[i].helper = false;
                        bman[INDBR].in_help = false;
                        bman[INDBR].num_helper = -1;
                        bman[i].num_in_help = -1;

                        bman[i].main_step = 0;
                        bman[i].step = 0;
                        bman[i].path.Clear();
                        bman[i].ind_path = 0;
                        bman[i].have_unpack = false;

                        

                    }

                    if(bman[INDBR].ind_path == bman[INDBR].path.Count)
                    {
                        bman[INDBR].construct_help = false;
                        bman[INDBR].step_help = 0;
                        bman[INDBR].in_help = false;
                        bman[INDBR].num_helper = -1;
                        bman[INDBR].main_step = 0;
                        bman[INDBR].step = 0;
                        bman[INDBR].path.Clear();
                        bman[INDBR].ind_path = 0;
                        bman[INDBR].have_unpack = false;
                        INDBR = -1;
                        break;
                    }

                    break;

                }
                               
            }

        }

        for (int i = 0;INDBR != -1 && i < B; ++i)
        {
            
            if (i != INDBR && !bman[i].helper) continue;
            //Console.Error.WriteLine("1pass=" + i);
            if (i != INDBR && bman[i].construct_help) continue;
            //Console.Error.WriteLine("2pass=" + i);
            if (i == INDBR && move) continue;
            if (i == INDBR && team_pack) continue;
            ///Console.Error.WriteLine("3pass=" + i);
            //Console.Error.WriteLine(i + " indPATH=" + bman[INDBR].ind_path + " " + bman[INDBR].path.Count);
            //Console.Error.WriteLine("indPATH=" + bman[INDBR].path[bman[INDBR].ind_path]);
            if (i == INDBR && bman[INDBR].ind_path < bman[INDBR].path.Count &&
                dists[bridgemen[INDBR].Position, bman[INDBR].path[bman[INDBR].ind_path]] > bridgemen[INDBR].Bricks &&
                !connected[bridgemen[INDBR].Position, bman[INDBR].path[bman[INDBR].ind_path]] && bman[i].step == 0) continue;
            //Console.Error.WriteLine("4pass=" + i);
            if (i != INDBR && bman[i].step < 2 && bman[i].ind_path == bman[i].path.Count) continue;
            //Console.Error.WriteLine("5pass=" + i);
            if (bman[i].path.Count == 0) continue;
            if (huse.Contains(i)) continue;
            //Console.Error.WriteLine("pass6=" + i);
            //verif step
            

            int STEP = bman[i].step;
            if (bman[i].step == 0)
            {
                /*Console.Error.WriteLine("id=" + i + ", path=" + bman[i].path.Count + ", " + bman[i].ind_path);
                for (int ii = 0; ii < B; ++ii)
                {
                    Console.Error.WriteLine("id=" + bridgemen[ii].ID + ", path=" + bman[ii].ind_path + "/" + bman[ii].path.Count + ", ms=" + bman[ii].step + "/" + bman[ii].main_step);
                    for (int j = 0; j < bman[ii].path.Count; ++j)
                    {
                        Console.Error.Write(bman[ii].path[j] + " ");
                    }
                    Console.Error.WriteLine();
                }*/
                /*if(bridgemen[i].Bricks < dists[bridgemen[i].Position, bman[i].path[bman[i].ind_path]])
                {
                    STEP = -1;
                }
                else*/
                if (connected[bridgemen[i].Position, bman[i].path[bman[i].ind_path]])
                {
                    STEP++;
                }

            }

            if (bman[i].step == 1)
            {
                if (!connected[bridgemen[i].Position, bman[i].path[bman[i].ind_path]])
                {
                    STEP--;
                }

            }

            if (bman[i].step == 2)
            {
                if (!connected[bridgemen[i].Position, bman[i].path[bman[i].ind_path - 2]] || !bman[i].have_unpack)
                {
                    STEP = -1;
                }

            }

            //Console.Error.WriteLine("b" + i + ", STEP=" + STEP);

            if (STEP != -1)
            {
                if (STEP == 0)
                {
                    output.Add("UNPACK " + bridgemen[i].ID + " " + bman[i].path[bman[i].ind_path]);
                    bman[i].step = 1;
                    bman[i].have_unpack = true;
                    connected[bridgemen[i].Position, bman[i].path[bman[i].ind_path]] = true;
                    connected[bman[i].path[bman[i].ind_path], bridgemen[i].Position] = true;

                }
                else if (STEP == 1)
                {
                    output.Add("MOVE " + bridgemen[i].ID + " " + bman[i].path[bman[i].ind_path]);
                    bman[i].ind_path++;
                    bman[i].step = 2;
                   
                }
                else if (STEP == 2)
                {
                    output.Add("PACK " + bridgemen[i].ID + " " + bman[i].path[bman[i].ind_path - 2]);
                    connected[bridgemen[i].Position, bman[i].path[bman[i].ind_path - 2]] = false;
                    connected[bman[i].path[bman[i].ind_path - 2], bridgemen[i].Position] = false;
                    bman[i].step = 0;
                    bman[i].have_unpack = false;
                    if (i != INDBR && bridgemen[i].Position == bman[i].pos_construct)// && horder.Contains(Tuple.Create(bman[i].order.From, bman[i].order.To)))
                    {
                        bman[i].construct_help = true;
                        bman[i].step_help = 0;
                        

                    }

                    if(bman[INDBR].ind_path == bman[INDBR].path.Count)
                    {
                        bman[INDBR].in_help = false;
                        bman[INDBR].num_helper = -1;
                        bman[INDBR].main_step = 0;
                        bman[INDBR].step = 0;
                        bman[INDBR].path.Clear();
                        bman[INDBR].ind_path = 0;
                        bman[INDBR].have_unpack = false;
                        INDBR = -1;
                        break;
                    }
                    /*if (i != INDBR && bman[INDBR].ind_path == bman[INDBR].path.Count)// && horder.Contains(Tuple.Create(bman[i].order.From, bman[i].order.To)))
                    {
                        bman[i].construct_help = false;
                        bman[i].step_help = 0;
                        bman[INDBR].construct_help = false;
                        bman[INDBR].step_help = 0;

                        bman[i].helper = false;
                        bman[INDBR].in_help = false;
                        bman[INDBR].num_helper = -1;
                        bman[i].num_in_help = -1;
                        INDBR = -1;

                    }*/


                }




            }
            /*else
            {
                if (bman[i].main_step == 1 && bman[i].step == 2 && !bman[i].have_unpack && bman[i].ind_path == bman[i].path.Count)
                {
                    bman[i].main_step = 0;
                    bman[i].step = 0;
                    bman[i].path.Clear();
                    bman[i].ind_path = 0;
                    bman[i].have_unpack = false;
                }
                else if (bman[i].main_step == 1 && bman[i].step == 2 && !bman[i].have_unpack)
                {
                    bman[i].step = 0;
                }
            }*/

        }


        





        return output;

    }

}

class BridgeRunners
{
    static int g_seed = 777778;
    static int Rand(int mod)
    {
        g_seed = (214013 * g_seed + 2531011);
        return ((g_seed >> 16) & 0x7FFF) % mod;
    }

    static void Main(string[] args)
    {
        int N = int.Parse(Console.ReadLine());
        int B = int.Parse(Console.ReadLine());
        int O = int.Parse(Console.ReadLine());

        int[,] dists = new int[N, N];
        bool[,] connected = new bool[N, N];
        for (int i = 0; i < N; i++)
        {
            int[] line = Console.ReadLine().Split().Select(int.Parse).ToArray();
            for (int j = 0; j < N; j++)
            {
                dists[i, j] = line[j];
                connected[i, j] = false;
            }
        }

        Console.Error.WriteLine("N=" + N + ", O=" + O + ", B=" + B);

        Player player = new Player(N, O, B, dists);
        int who_play = 1;

        List<Bridgeman> bridgemen = Enumerable.Range(0, B).Select(i => new Bridgeman { ID = i }).ToList();
        int count = 0; 
        for (int turn = 1; turn <= 1000; turn++)
        {
            int elapsedTime = int.Parse(Console.ReadLine());
            for (int i = 0; i < B; i++)
            {
                int[] line = Console.ReadLine().Split().Select(int.Parse).ToArray();
                bridgemen[i].Position = line[0];
                bridgemen[i].Bricks = line[1];
                /*if (turn == 1)
                {
                    Console.Error.WriteLine("id=" + bridgemen[i].ID + ", brick=" + bridgemen[i].Bricks);
                }*/
                bridgemen[i].Target = line[2];
            }
            List<Order> orders = new List<Order>();
            for (int i = 0; i < O; i++)
            {
                int[] line = Console.ReadLine().Split().Select(int.Parse).ToArray();
                Order o = new Order { From = line[0], To = line[1] };
                orders.Add(o);
            }

            List<string> output = new List<string>();

            if (who_play == 1)
            {
                output = player.SimulationD(connected, bridgemen, orders);
            }

            if (output.Count == 0 && who_play != 2)
            {
                who_play = 2;
                player.INDBR = -1;
                               
            }
            
            if (who_play == 2)
            {
                who_play = 2;
                output = player.SimulationH2(connected, bridgemen, orders);
                if (player.INDBR == -1) who_play = 1;
                if (output.Count == 0)
                {
                    output = player.SimulationD(connected, bridgemen, orders);
                    who_play = 1;
                    //Console.Error.WriteLine("anormal2");
                    
                }
                //else
                //    Console.Error.WriteLine("anormal");
            }

            if (output.Count == 0) count++;

            /*if(count == 5)
            {
                count = 0;
                output = player.Simulation(connected, bridgemen, orders);
                who_play = 1;
                player.INDBR = -1;
            }*/


            /*for (int i = 0;i < output.Count; ++i)
            {
                Console.Error.WriteLine(output[i]);
            }*/

            Console.WriteLine(string.Join(" | ", output));
            //Console.Error.WriteLine("-----------------------");
        }
    }
}

