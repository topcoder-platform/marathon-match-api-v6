import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class BridgeRunners {
    public static void main(String[] args) {
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(System.in))) {
            int N = Integer.parseInt(reader.readLine());
            int B = Integer.parseInt(reader.readLine());
            int O = Integer.parseInt(reader.readLine());
//            Utils.debug("N", N, "B", B, "O", O);
            Random rng = new Random(System.nanoTime());
            int[][] dists = new int[N][N];
            boolean[][] connected = new boolean[N][N];
            for (int i = 0; i < N; i++) {
                String[] line = reader.readLine().split(" ");
                for (int j = 0; j < N; j++) {
                    dists[i][j] = Integer.parseInt(line[j]);
                }
            }
            int[][] dists2 = new int[N][N];
            for (int i = 0; i < N; i++) {
                for (int j = 0; j < N; j++) {
                    if (j == i) {
                        dists2[i][j] = 0;
                        continue;
                    }
                    dists2[i][j] = dists[i][j] <= 50 ? 1 : (int) 1e8;
                }
            }
            warshallFloyd(N, dists2);
            int[][] dists3 = new int[N][N];
            for (int i = 0; i < N; i++) {
                for (int j = 0; j < N; j++) {
                    if (j == i) {
                        dists3[i][j] = 0;
                        continue;
                    }
                    dists3[i][j] = dists[i][j] <= 100 ? 1 : (int) 1e8;
                }
            }
            warshallFloyd(N, dists3);
            List<Bridgeman> bridgemen = IntStream.range(0, B).mapToObj(i -> new Bridgeman(i)).collect(Collectors.toList());
            for (int turn = 1; turn <= 1000; turn++) {
                int elapsedTime = Integer.parseInt(reader.readLine());
                for (int i = 0; i < B; i++) {
                    String[] line = reader.readLine().split(" ");
                    bridgemen.get(i).position = Integer.parseInt(line[0]);
                    bridgemen.get(i).bricks = Integer.parseInt(line[1]);
                    bridgemen.get(i).target = Integer.parseInt(line[2]);
                }
                List<Order> orders = new ArrayList<>();
                for (int i = 0; i < O; i++) {
                    String[] line = reader.readLine().split(" ");
                    Order o = new Order(Integer.parseInt(line[0]), Integer.parseInt(line[1]));
                    orders.add(o);
                }
                List<String> output = new ArrayList<>();
                boolean[] used = new boolean[B];
                List<Bridgeman> bm = bridgemen.stream().sorted((o1, o2) -> -Integer.compare(o1.target, o2.target)).collect(Collectors.toList());
                for (Bridgeman b : bm) {
                    if (used[b.id]) {
                        continue;
                    }
                    if (turn % 3 == 0 && b.bridgeFrom == -1) {
                        List<Integer> targets = IntStream.range(0, N).filter(t -> t != b.position && !connected[b.position][t] && (dists2[b.position][t] == 1 || dists3[b.position][t] == 1)).boxed().collect(Collectors.toList());
                        if (!targets.isEmpty()) {
                            ArrayList<Integer> bestTarget = new ArrayList<>();
                            int bestDist = (int) 1e9;
                            for (Integer t : targets) {
                                if (dists3[b.position][t] == 1 && bridgemen.stream().filter(b2 -> b2.position == t).findFirst().isPresent()) {
                                    Bridgeman b2 = bridgemen.stream().filter(b3 -> b3.position == t).findFirst().get();
                                    if (!(used[b2.id] || dists[b.position][t] <= b.bricks || b.position == b.bridgeFrom || b2.position == b2.bridgeFrom || used[b.id] || used[b2.id] || dists[b.position][t] > b.bricks + b2.bricks || connected[b.position][t])) {
                                        int dist2;
                                        if (b.target >= 0) {
                                            dist2 = dists2[t][b.target] < 1e7 ? dists2[t][b.target] : 4 * dists3[t][b.target];
                                        } else {
                                            int bestFrom = -1;
                                            int bestDist3 = (int) 1e9;
                                            for (Order order : orders) {
                                                int dist3 = dists2[t][order.from] < 1e7 ? dists2[t][order.from] : 4 * dists3[t][order.from];
                                                if (dist3 <= bestDist3) {
                                                    if (dist3 < bestDist3) {
                                                        bestDist3 = dist3;
                                                    }
                                                    bestFrom = order.from;
                                                }
                                            }
                                            dist2 = dists2[t][bestFrom] < 1e7 ? dists2[t][bestFrom] : 4 * dists3[t][bestFrom];
                                        }
                                        int dist = dists3[b.position][t] + dist2;
                                        if (dist <= bestDist) {
                                            if (dist < bestDist) {
                                                bestDist = dist;
                                                bestTarget.clear();
                                            }
                                            bestTarget.add((1 << 10) | t);
                                        }
                                    }
                                }
                                if (dists2[b.position][t] == 1 && dists[b.position][t] <= b.bricks) {
                                    if (!(used[b.id] || connected[b.position][t])) {
                                        int dist2;
                                        if (b.target >= 0) {
                                            dist2 = dists2[t][b.target] < 1e7 ? dists2[t][b.target] : 4 * dists3[t][b.target];
                                        } else {
                                            int bestFrom = -1;
                                            int bestDist3 = (int) 1e9;
                                            for (Order order : orders) {
                                                int dist3 = dists2[t][order.from] < 1e7 ? dists2[t][order.from] : 4 * dists3[t][order.from];
                                                if (dist3 <= bestDist3) {
                                                    if (dist3 < bestDist3) {
                                                        bestDist3 = dist3;
                                                    }
                                                    bestFrom = order.from;
                                                }
                                            }
                                            dist2 = dists2[t][bestFrom] < 1e7 ? dists2[t][bestFrom] : 4 * dists3[t][bestFrom];
                                        }
                                        int dist = dists2[b.position][t] + dist2;
                                        if (dist <= bestDist) {
                                            if (dist < bestDist) {
                                                bestDist = dist;
                                                bestTarget.clear();
                                            }
                                            bestTarget.add(t);
                                        }
                                    }
                                }
                            }
                            if (bestTarget.isEmpty()) {
                                continue;
                            }
                            int t = bestTarget.get(rng.nextInt(bestTarget.size()));
                            if ((t & (1 << 10)) == 0) {
                                output.add("UNPACK " + b.id + " " + t);
                                b.bridgeFrom = b.position;
                                b.bridgeTo = t;
                                b.id2 = -1;
                                b.len = -1;
                                connected[b.bridgeFrom][b.bridgeTo] = true;
                                connected[b.bridgeTo][b.bridgeFrom] = true;
                                used[b.id] = true;
                            } else {
                                final int t2 = t & ((1 << 10) - 1);
                                Bridgeman b2 = bridgemen.stream().filter(b3 -> b3.position == t2).findFirst().get();
                                output.add("TEAMUNPACK " + b.id + " " + b2.id + " " + b.bricks);
                                b.bridgeFrom = b.position;
                                b.bridgeTo = t2;
                                b.id2 = b2.id;
                                b.len = b.bricks;
                                b2.bridgeFrom = t2;
                                b2.bridgeTo = b.position;
                                b2.id2 = b.id;
                                b2.len = dists[b.position][b2.position] - b.len;
                                connected[b.bridgeFrom][b.bridgeTo] = true;
                                connected[b.bridgeTo][b.bridgeFrom] = true;
                                used[b.id] = true;
                                used[b2.id] = true;
                            }
                        }
                    } else if (turn % 3 == 1 && b.bridgeFrom == b.position) {
                        output.add("MOVE " + b.id + " " + b.bridgeTo);
                        used[b.id] = true;
                    } else if (turn % 3 == 2 && b.bridgeTo == b.position) {
                        if (b.id2 != -1) {
                            Bridgeman b2 = bridgemen.get(b.id2);
//                            if (b.len < 0) {
//                                Utils.debug("b.len(" + b.len + ") < 0");
//                            }
//                            if (b.len > 60 - b.bricks) {
//                                Utils.debug("b.len(" + b.len + ") > 60 - b.bricks(" + b.bricks + ")");
//                            }
//                            if (b.len > dists[b.position][b2.position]) {
//                                Utils.debug("b.len(" + b.len + ") > dists[b.position][b2.position](" + dists[b.position][b2.position] + ")");
//                            }
//                            if (b.len + 60 - b2.bricks < dists[b.position][b2.position]) {
//                                Utils.debug("b.len(" + b.len + ") + 60 - b2.bricks(" + b2.bricks + ") < dists[b.position][b2.position](" + dists[b.position][b2.position] + ")");
//                            }
                            output.add("TEAMPACK " + b.id + " " + b.id2 + " " + b.len);
                            connected[b.bridgeFrom][b.bridgeTo] = false;
                            connected[b.bridgeTo][b.bridgeFrom] = false;
                            b.bridgeFrom = -1;
                            b.bridgeTo = -1;
                            b2.bridgeFrom = -1;
                            b2.bridgeTo = -1;
                            b.id2 = -1;
                            b2.id2 = -1;
                            b.len = -1;
                            b2.len = -1;
                            used[b.id] = true;
                            used[b2.id] = true;
                        } else if (b.id2 == -1) {
                            output.add("PACK " + b.id + " " + b.bridgeFrom);
                            connected[b.bridgeFrom][b.bridgeTo] = false;
                            connected[b.bridgeTo][b.bridgeFrom] = false;
                            b.bridgeFrom = -1;
                            b.bridgeTo = -1;
                            b.id2 = -1;
                            b.len = -1;
                            used[b.id] = true;
                        }
                    } else {
                    }
                }
                System.out.println(String.join(" | ", output));
                System.out.flush();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void warshallFloyd(int N, int[][] d) {
        for (int k = 0; k < N; k++) {
            for (int from = 0; from < N; from++) {
                for (int to = 0; to < N; to++) {
                    d[from][to] = Math.min(d[from][to], d[from][k] + d[k][to]);
                }
            }
        }
    }
}

class Bridgeman {
    int id;
    int id2 = -1;
    int position;
    int target;
    int bricks;
    int len = -1;
    int bridgeFrom = -1;
    int bridgeTo = -1;

    public Bridgeman(int id) {
        this.id = id;
    }
}

class Order {
    int from;
    int to;

    public Order(int from, int to) {
        this.from = from;
        this.to = to;
    }
}

//class Utils {
//    private Utils() {
//    }
//
//    public static final void debug(Object... o) {
//        System.err.println(toString(o));
//        System.err.flush();
//    }
//
//    public static final String toString(Object... o) {
//        return Arrays.deepToString(o);
//    }
//
//    public static boolean isValid(int v, int min, int minUpper) {
//        return v >= min && v < minUpper;
//    }
//}