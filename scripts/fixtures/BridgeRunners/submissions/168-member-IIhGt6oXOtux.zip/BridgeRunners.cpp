// START FILE shared/Pragmas.h
#ifndef DONT_PRAGMAS
#pragma GCC optimize("Ofast,inline,unroll-loops,tracer")
#pragma GCC target("tune=native")
#endif
#pragma GCC target("avx2,fma,bmi,bmi2,popcnt,lzcnt")
// END FILE shared/Pragmas.h

// START FILE shared/Macros.h
#ifndef DEBUG
#define INLINE __attribute__((always_inline)) inline
#else
#define INLINE inline
#endif
// END FILE shared/Macros.h

// START FILE Config.h
#include <string>


using namespace std;

class Config {
public:
    inline static float maxGap;
    inline static float progressWeight0;
    inline static float nextDistWeight0;
    inline static float progressWeight1;
    inline static float nextDistWeight1;
    inline static float progressWeightn;
    inline static float nextDistWeightn;

    INLINE static float readFloat(const string& name, const float defaultValue) {
        const char* envVar = getenv(name.c_str());
        if (envVar == nullptr) return defaultValue;
        return atof(envVar);
    }

    INLINE static void init() {

        maxGap = readFloat("maxGap", 2.0f);
        progressWeight0 = readFloat("progressWeight0", 4.66463446204156f);
        nextDistWeight0 = readFloat("nextDistWeight0", 1.0207778392444355f);
        progressWeight1 = readFloat("progressWeight1", 1.2f);
        nextDistWeight1 = readFloat("nextDistWeight1", 2.431331934376569f);
        progressWeightn = readFloat("progressWeightn", 0.95f);
        nextDistWeightn = readFloat("nextDistWeightn", 1.84476845704282f);
    }
};
// END FILE Config.h

// START FILE shared/Types.h
#include <cstdint>
#include <ostream>

typedef uint64_t u64;
typedef uint32_t u32;
typedef uint16_t u16;
typedef uint8_t u8;

typedef int64_t i64;
typedef int32_t i32;
typedef int16_t i16;
typedef int8_t i8;

typedef double f64;
typedef float f32;

template<typename T>
struct Point {
    T x, y;

    Point() = default;

    constexpr Point(const T& x, const T& y): x(x), y(y) {
    }


    template<typename U>
    friend std::ostream& operator<<(std::ostream& os, const Point<U>& point);

    constexpr Point operator-(const Point& other) const {
        return Point(x - other.x, y - other.y);
    }

    constexpr Point operator+(const Point& other) const {
        return Point(x + other.x, y + other.y);
    }

    constexpr Point operator*(const T& scale) const {
        return Point(x * scale, y * scale);
    }

    constexpr Point operator/(const T& scale) const {
        return Point(x / scale, y / scale);
    }

    constexpr bool operator==(const Point& other) const {
        return x == other.x && y == other.y;
    }

    constexpr bool operator!=(const Point& other) const {
        return x != other.x || y != other.y;
    }
};

template<typename T>
std::ostream& operator<<(std::ostream& os, const Point<T>& point) {
    os << '(' << point.x << ", " << point.y << ')';
    return os;
}
// END FILE shared/Types.h

// START FILE shared/Time.h
extern "C" {
extern int gettimeofday(timeval*, void*);
}

inline u64 getTime() {
    timeval t;
    gettimeofday(&t, nullptr);
    return t.tv_sec * 1000000UL + t.tv_usec;
}

struct StopWatch {
    inline static u64 lastMeasurement = 0;

    static void init() {
#ifdef MEASURE_TIME
        lastMeasurement = getTime();
#endif
    }

    static u64 measure() {
#ifdef MEASURE_TIME
        const u64 now = getTime();
        const u64 interval = now - lastMeasurement;
        lastMeasurement = now;
        return interval;
#else
        return 0;
#endif
    }
};
// END FILE shared/Time.h

// START FILE Constants.h
using namespace std;

constexpr u64 MAX_TURN = 1000;

constexpr u64 MAX_N = 80;
constexpr u64 MAX_B = 20;
constexpr u64 MAX_O = 10;

constexpr u64 MAX_CARRY = 60;

constexpr u8 NO_MSG = 80;
static_assert(NO_MSG >= MAX_N);
// END FILE Constants.h

// START FILE shared/Vector.h
#include <initializer_list>
#include <random>
#include <stdexcept>
#include <iostream>

template<typename T, size_t N>
class Vector {
    size_t _size;
    T      _data[N];

public:
    Vector() : _size(0) {
    }

    Vector(std::initializer_list<T> list) : _size(0) {
#if DEBUG
        if (list.size() > N) throw std::runtime_error("initializer list too big");
#endif
        for (const T& value : list) {
            push_back(value);
        }
    }

    void push_back(const T& value) {
#if DEBUG
        if (full()) throw std::runtime_error("Vector is full");
#endif
        _data[_size++] = value;
    }

    void pop_back() {
#if DEBUG
        if (empty()) throw std::runtime_error("Vector is empty");
#endif
        --_size;
    }

    T popBackAndGet() {
#if DEBUG
        if (empty()) throw std::runtime_error("Vector is empty");
#endif
        return _data[--_size];
    }

    void removeAndReplaceWithLast(const size_t index) {
#if DEBUG
        if (index < 0 || size() <= index) throw std::runtime_error("index is outside range");
#endif
        _data[index] = back();
        pop_back();
    }

    T& front() {
#if DEBUG
        if (empty()) throw std::runtime_error("Vector is empty");
#endif
        return _data[0];
    }

    const T& front() const {
#if DEBUG
        if (empty()) throw std::runtime_error("Vector is empty");
#endif
        return _data[0];
    }

    T& back() {
#if DEBUG
        if (empty()) throw std::runtime_error("Vector is empty");
#endif
        return _data[_size - 1];
    }

    const T& back() const {
#if DEBUG
        if (empty()) throw std::runtime_error("Vector is empty");
#endif
        return _data[_size - 1];
    }

    T& operator[](const size_t index) {
#if DEBUG
        if (index < 0 || size() <= index) throw std::runtime_error("index is outside range");
#endif
        return _data[index];
    }

    const T& operator[](const size_t index) const {
#if DEBUG
        if (index < 0 || size() <= index) throw std::runtime_error("index is outside range");
#endif
        return _data[index];
    }

    [[nodiscard]] size_t size() const {
        return _size;
    }

    template<typename S>
    void setSize(const S size) {
#if DEBUG
        if (size < 0 || static_cast<S>(N) < size) throw std::runtime_error("size is outside range");
#endif
        _size = size;
    }

    void clear() {
        setSize(0);
    }

    [[nodiscard]] size_t capacity() const {
        return N;
    }

    [[nodiscard]] bool empty() const {
        return _size == 0;
    }

    [[nodiscard]] bool full() const {
        return _size == capacity();
    }

    const T& random(std::mt19937& rnd) const {
#if DEBUG
        if (empty()) throw std::runtime_error("Vector is empty");
#endif
        const size_t index = rnd() % size();
        return _data[index];
    }

    friend std::ostream& operator<<(std::ostream& out, const Vector& vector) {
        out << "[ ";
        for (auto v : vector) {
            out << v << " ";
        }
        out << ']';
        return out;
    }

    T* begin() {
        return _data;
    }

    T* end() {
        return _data + _size;
    }

    const T* begin() const {
        return _data;
    }

    const T* end() const {
        return _data + _size;
    }
};
// END FILE shared/Vector.h

// START FILE game/GameState.h
#include <array>
#include <queue>
#include <bitset>


using namespace std;

struct Action {
    enum Type: u8 {
        END_MOVE    = 0b0000'0000,
        MOVE        = 0b0010'0000,
        UNPACK      = 0b0100'0000,
        PACK        = 0b0110'0000,
        TEAM_UNPACK = 0b1000'0000,
        TEAM_PACK   = 0b1010'0000,
        MASK        = 0b1110'0000,
    };

    u8 val1;
    u8 val2;
    u8 val3;

    Action() = default;

    Action(const u8 val1, const u8 val2, const u8 val3)
        : val1(val1), val2(val2), val3(val3) {
    }

    static Action move(const u8 manId, const u8 islandId) {
        return Action(manId | MOVE, islandId, 0);
    }

    static Action unpack(const u8 manId, const u8 islandId) {
        return Action(manId | UNPACK, islandId, 0);
    }

    static Action pack(const u8 manId, const u8 islandId) {
        return Action(manId | PACK, islandId, 0);
    }

    static Action teamUnPack(const u8 manId1, const u8 manId2, const u8 length) {
        return Action(manId1 | TEAM_UNPACK, manId2, length);
    }

    static Action teamPack(const u8 manId1, const u8 manId2, const u8 length) {
        return Action(manId1 | TEAM_PACK, manId2, length);
    }

    static Action EndMove() {
        return Action(END_MOVE, 0, 0);
    }

    INLINE u8 manId() const {
        return val1 & ~MASK;
    }

    bool isEndMove() const {
        return val1 == 0;
    }

    friend ostream& operator<<(ostream& out, const Action& action) {
        const u8 type = action.val1 & MASK;
        const u64 manId = action.manId();
        const u64 v2 = action.val2;
        const u64 v3 = action.val3;
        if (type == MOVE) out << "MOVE " << manId << ' ' << v2;
        if (type == UNPACK) out << "UNPACK " << manId << ' ' << v2;
        if (type == PACK) out << "PACK " << manId << ' ' << v2;
        if (type == TEAM_UNPACK) out << "TEAMUNPACK " << manId << ' ' << v2 << ' ' << v3;
        if (type == TEAM_PACK) out << "TEAMPACK " << manId << ' ' << v2 << ' ' << v3;
        if (type == END_MOVE) out << "MSG .\n";
        else out << " | ";
        return out;
    }
};


struct Move {
    Vector<Action, MAX_B> actions;
};

struct Edge {
    u8 target;
    u8 tIndex;
    u16 dist;
};

class GameState {
public:
    typedef float EvalType;
    typedef u32 MoveIdType;


    inline static i64 N, B, O;

    inline static array<Vector<Edge, 8>, MAX_N> edges;
    inline static array<array<u16, MAX_N>, MAX_N> trueEdge;
    inline static array<array<u16, MAX_N>, MAX_N> allDists;
#if DEBUG
    inline static array<Point<u16>, MAX_N> islandPos;
#endif

    inline static array<array<u32, MAX_N>, MAX_B> zobPos;
    inline static array<array<u32, MAX_CARRY + 1>, MAX_B> zobCarry;
    inline static array<array<u32, NO_MSG + 1>, MAX_B> zobTarget;
    inline static array<array<u32, MAX_N>, MAX_N> zobBridge;
    inline static array<u32, MAX_B> zobAlreadyMoved;
    inline static u32 zobAllAlreadyMoved = 0;
    inline static array<u32, 32> zobScore;
    inline static array<pair<u8, u8>, MAX_O> orders;

    MoveIdType moveId;

    array<u8, MAX_B> pos;
    array<u8, MAX_B> carry;
    array<u8, MAX_B> targets;
    array<u8, MAX_N> bridges;
    u16 inactiveOrders = 0;

    u32 alreadyMoved = 0;
    u16 score = 0;
    u32 hash = 0;


public:
    INLINE static void initializeZobristHashes() {
        mt19937 rng(1);
        for (auto& arr : zobPos) initalizeZobristArray(arr, rng);
        for (auto& arr : zobCarry) initalizeZobristArray(arr, rng);
        for (auto& arr : zobTarget) initalizeZobristArray(arr, rng);
        initalizeZobristArray(zobAlreadyMoved, rng);
        initalizeZobristArray(zobScore, rng);

        for (u64 i = 0; i < MAX_N; ++i) {
            for (u64 j = i; j < MAX_N; ++j) {
                zobBridge[i][j] = zobBridge[j][i] = rng();
            }
        }
    }

    INLINE static void initializeDists() {
        for (u64 i = 0; i < N; ++i) {
            for (u64 j = 0; j < N; ++j) {
                allDists[i][j] = UINT16_MAX;
            }
            priority_queue<pair<u16, u8>, vector<pair<u16, u8>>, greater<>> Q;
            Q.push({0, i});
            allDists[i][i] = 0;
            while (!Q.empty()) {
                const auto [d, v] = Q.top();
                Q.pop();
                for (u64 e = 0; e < edges[v].size(); ++e) {
                    u64 w = edges[v][e].target;
                    u16 nDist = edges[v][e].dist;
                    if (nDist > 50) nDist *= 3;
                    nDist += d;
                    if (allDists[i][w] > nDist) {
                        allDists[i][w] = nDist;
                        Q.push({nDist, w});
                    }
                }
            }
        }
    }

private:
    template<u64 ZobristArraySize>
    INLINE static void initalizeZobristArray(array<u32, ZobristArraySize>& arr, mt19937& rng) {
        for (auto& value : arr) {
            value = rng();
        }
    }

public:
    INLINE void changePos(const u32 b, const u64 v, const u64 w) {
        hash ^= zobPos[b][v];
        pos[b] = w;
        hash ^= zobPos[b][w];
    }

    INLINE void lightApplyAction(const Action& action) {
        const u8 type = action.val1 & Action::MASK;
        const u64 manId = action.manId();
        const u64 v = pos[manId];
        const u64 v2 = action.val2;
        const u64 v3 = action.val3;

        if (type == Action::MOVE) {
            changePos(manId, v, v2);
        }
        if (type == Action::UNPACK) {
            const u64 target = v2;
            for (u64 e = 0; e < edges[v].size(); ++e) {
                const u64 w = edges[v][e].target;
                if (w == target) {
                    const auto wIndex = edges[v][e].tIndex;
                    addBridge(v, w, 1UL << e, 1UL << wIndex);
                }
            }
        }
        if (type == Action::PACK) {
            const u64 target = v2;
            for (u64 e = 0; e < edges[v].size(); ++e) {
                const u64 w = edges[v][e].target;
                if (w == v2) {
                    const auto wIndex = edges[v][e].tIndex;
                    removeBridge(v, w, 1 << e, 1 << wIndex);
                }
            }
        }
        if (type == Action::TEAM_UNPACK) {
            const u64 target = pos[v2];
            for (u64 e = 0; e < edges[v].size(); ++e) {
                const u64 w = edges[v][e].target;
                if (w == target) {
                    const auto wIndex = edges[v][e].tIndex;
                    addBridge(v, w, 1UL << e, 1UL << wIndex);
                }
            }
        }
        if (type == Action::TEAM_PACK) {
            const u64 target = pos[v2];
            for (u64 e = 0; e < edges[v].size(); ++e) {
                const u64 w = edges[v][e].target;
                if (w == target) {
                    const auto wIndex = edges[v][e].tIndex;
                    removeBridge(v, w, 1 << e, 1 << wIndex);
                }
            }
        }
        if (type == Action::END_MOVE) {
        }
    }

    INLINE void addBridge(const u64 v, const u64 w, const u64 vBridgeMask, const u64 wBridgeMask) {
        bridges[v] |= vBridgeMask;
        bridges[w] |= wBridgeMask;
        hash ^= zobBridge[v][w];
    }


    INLINE void removeBridge(const u64 v, const u64 w, const u64 vBridgeMask, const u64 wBridgeMask) {
        bridges[v] &= ~vBridgeMask;
        bridges[w] &= ~wBridgeMask;
        hash ^= zobBridge[v][w];
    }

    INLINE void changeCarry(const u64 b, const i8 dValue) {
        hash ^= zobCarry[b][carry[b]];
        carry[b] += dValue;
        hash ^= zobCarry[b][carry[b]];
    }

    INLINE void setAlreadyMoved(const u32 b) {
        alreadyMoved |= 1 << b;
    }


    INLINE void handleOrdersFor(const u32 b) {
        if (targets[b] != NO_MSG) {
            if (targets[b] == pos[b]) {
                hash ^= zobScore[score & 31];
                ++score;
                hash ^= zobScore[score & 31];
                hash ^= zobTarget[b][targets[b]];
                targets[b] = NO_MSG;
                hash ^= zobTarget[b][targets[b]];
            }
            return;
        }
        for (u64 o = 0; o < O; ++o) {
            if (inactiveOrders & (1 << o)) continue;
            if (pos[b] == orders[o].first) {
                hash ^= zobTarget[b][targets[b]];
                targets[b] = orders[o].second;
                hash ^= zobTarget[b][targets[b]];
                inactiveOrders |= (1 << o);
                return;;
            }
        }
    }

    INLINE void finalize() {
        alreadyMoved = 0; 
    }

    INLINE u32 calcHash() const {
        u32 h = 0;
        for (u64 b = 0; b < B; ++b) {

            const u64 v = pos[b];
            h ^= zobPos[b][v];
            h ^= zobCarry[b][carry[b]];
            h ^= zobTarget[b][targets[b]];
        }

        for (u64 v = 0; v < MAX_N; ++v) {
            for (u64 e = 0; e < edges[v].size(); ++e) {
                const u64 target = edges[v][e].target;
                const u64 tIndex = edges[v][e].tIndex;
                const u8 dist = edges[v][e].dist;
                if (target < v) continue;
                if ((bridges[v] & (1UL << e)) == 0) continue;
                h ^= zobBridge[v][target];
            }
        }

        h ^= zobScore[score & 31];
        return h;
    }


    [[nodiscard]] EvalType calcEval() const {
        EvalType eval = score * 4096;
        u32 carrySum = 0;
        array<float, MAX_O> orderDist;
        fill(orderDist.begin(), orderDist.end(), 4096);

        constexpr float DIRECT_DIST_MULT = 2.0f;
        constexpr float BUILT_DIST_MULT = 1.0f;
        constexpr float BUILDABLE_DIST_MULT = 1.5f;
        constexpr float CARRY_MULT = 0.01f;
        for (u64 b = 0; b < B; ++b) {
            const u64 v = pos[b];
            carrySum += carry[b];

            float targetDist;
            if (targets[b] == NO_MSG) {
                for (u64 o = 0; o < O; ++o) {
                    orderDist[o] = min(orderDist[o], DIRECT_DIST_MULT * allDists[v][orders[o].first]);
                }
            } else {
                targetDist = DIRECT_DIST_MULT * allDists[v][targets[b]];
            }

            for (u64 e = 0; e < edges[v].size(); ++e) {
                const u64 w = edges[v][e].target;
                const u16 dist = edges[v][e].dist;
                float mult = BUILT_DIST_MULT;
                if ((bridges[v] & (1UL << e)) == 0) {
                    if (dist <= carry[b]) {
                        mult = BUILDABLE_DIST_MULT;
                    } else {
                        continue;
                    }
                }
                if (targets[b] == NO_MSG) {
                    for (u64 o = 0; o < O; ++o) {
                        orderDist[o] = min(orderDist[o], mult * dist + DIRECT_DIST_MULT * allDists[w][orders[o].first]);
                    }
                } else {
                    targetDist = min(targetDist, mult * dist + DIRECT_DIST_MULT * allDists[w][targets[b]]);
                }
            }
            if (targets[b] != NO_MSG) {
                eval += 1024 - targetDist;
            }
        }
        eval += CARRY_MULT * static_cast<float>(carrySum);
        for (u64 o = 0; o < O; ++o) {
            if (inactiveOrders & (1 << o)) continue;
            eval -= orderDist[o];
        }
        return eval;
    }
};
// END FILE game/GameState.h

// START FILE agent/Agent.h
#include <cstdint>
#include <memory>




class Reader;
using namespace std;

class Agent {
    inline static u64 timeLeftCheckCounter = 0;

public:
    inline static bool _timeout = false;
    inline static uint64_t startTime = 0;
    inline static uint64_t maxRoundTime = 46000;
    inline static i32 turn = 0;

    array<u64, 8> turnEndTimes;
    u64 skip = 0;

    GameState gameState{};


    Reader& reader;
    ostream& output;
    ostream& error;

    Agent(Reader& reader, ostream& output, ostream& error) : reader(reader), output(output), error(error) {
    }


    static bool hasTimeLeft() {
#if DEBUG
        return true;
#else
        if (_timeout) return false;
        if (startTime + maxRoundTime < getTime()) {
            _timeout = true;
            return false;
        }
        return true;
#endif

    }

    void readInitialInput();
    void readTurnInput();
    void calculateOutput();
};
// END FILE agent/Agent.h

// START FILE shared/Bag.h
#include <limits>


template<typename T, size_t Size, typename IdType>
class Bag {
    static_assert(Size > 0 && Size - 1 <= std::numeric_limits<IdType>::max());
    T data[Size];
public: 
    Vector<IdType, Size> ids;

public:
    constexpr Bag() {
        for (IdType id = 0; ; ++id) {
            ids.push_back(id);
            if (id == Size - 1) break;
        }
    }

    constexpr T& operator[](const size_t id) {
#if DEBUG
        if (Size <= id) throw std::runtime_error("id is outside range");
#endif
        return data[id];
    }

    constexpr const T& operator[](const size_t id) const {
#if DEBUG
        if (Size <= id) throw std::runtime_error("id is outside range");
#endif
        return data[id];
    }

    constexpr T& addGetRef(const T& value) {
        IdType id = ids.pop_back();
        data[id] = value;
        return data[id];
    }

    constexpr IdType addGetId(const T& value) {
        IdType id = ids.popBackAndGet();
        data[id] = value;
        return id;
    }

    constexpr pair<IdType, T&> addGetIdAndRef(const T& value) {
        IdType id = ids.popBackAndGet();
        data[id] = value;
        return {id, data[id]};
    }

    void remove(const size_t id) {
        ids.push_back(id);
    }
};
// END FILE shared/Bag.h

// START FILE shared/Beam2.h
template<typename T, size_t Size>
class Beam2 {
    Vector<T, Size> beams[2];
    size_t currentBeamIndex = 0, nextBeamIndex = 1;

public:
    constexpr Vector<T, Size>& current() {
        return beams[currentBeamIndex];
    }

    constexpr Vector<T, Size>& current() const {
        return beams[currentBeamIndex];
    }

    constexpr Vector<T, Size>& next() {
        return beams[nextBeamIndex];
    }

    constexpr Vector<T, Size>& next() const {
        return beams[nextBeamIndex];
    }

    void swap() {
        currentBeamIndex = 1 - currentBeamIndex;
        nextBeamIndex = 1 - nextBeamIndex;
    }
};
// END FILE shared/Beam2.h

// START FILE shared/MoveTree.h
#include <cassert>

using namespace std;

template<typename T, size_t Capacity, typename IdType, typename ChildrenCounterType>
class MoveTree {
    struct Node {
        T value;
        IdType parentId;
        ChildrenCounterType children;
    };

    static_assert(Capacity > 0 && Capacity - 1 <= std::numeric_limits<IdType>::max());
    Node data[Capacity];
    Vector<IdType, Capacity> ids;

public:
    MoveTree() {
        data[0].children = 3;
        for (IdType id = Capacity - 1; id > 0; --id) {
            ids.push_back(id);
        }
    }

    [[nodiscard]] size_t size() const {
        return Capacity - ids.size();
    }

    T move(const IdType id) const {
        return data[id].value;
    }

    IdType parentId(const IdType id) const {
        return data[id].parentId;
    }

    IdType add(const T value, const IdType parentId) {
        const IdType id = ids.popBackAndGet();
        data[id] = Node{value, parentId, 1};
        ++data[parentId].children;
        return id;
    }

    void free(const IdType id) {
        assert(data[id].children > 0);
        --data[id].children;

        IdType idIt = id;
        while (data[idIt].children == 0) {
            ids.push_back(idIt);


            idIt = data[idIt].parentId;
            assert(data[idIt].children > 0);
            --data[idIt].children;
        }
    }

    void add1(const IdType id) {
        assert(data[id].children > 0);
        ++data[id].children;
    }
};
// END FILE shared/MoveTree.h

// START FILE game/BeamSearch.h
#include <algorithm>
#include <unordered_set>



typedef u16 IdType;

struct BeamElement {
    IdType gameStateId;
    GameState::EvalType eval;

    bool operator>(const BeamElement& other) const {
        return eval > other.eval;
    }
};

class BeamSearch {
    inline static Bag<GameState, 65536, IdType> gameStates;
    inline static Beam2<BeamElement, 65536> beams;
    inline static Vector<BeamElement, 65536> globalBeam;
    inline static array<Move, 2048> startingMoves;

    inline static MoveTree<Action, 1 << 23, GameState::MoveIdType, u8> movesTree;

    unordered_set<u32> cache;

public:
    inline static u64 DEPTH = 4;
    inline static u64 BEAM_KEEP = 32;
    constexpr static u64 GLOBAL_BEAM_KEEP = 128;

    explicit BeamSearch(const GameState& gameState) {
        while (!globalBeam.empty()) {
            movesTree.free(gameStates[globalBeam.back().gameStateId].moveId);
            gameStates.remove(globalBeam.back().gameStateId);
            globalBeam.pop_back();
        }
        cache.clear();
        movesTree.add1(0);
        const IdType gameStateId = gameStates.addGetId(gameState);
        beams.current().push_back({gameStateId, -1e9});
    }

    u64 reconstructMoves(ostream& output, ostream& error, GameState& gameState, u32 moveId) {
        vector<Action> actions;
        while (moveId != 0) {
            Action action = movesTree.move(moveId);
            actions.push_back(action);
            moveId = movesTree.parentId(moveId);
        }
        std::reverse(actions.begin(), actions.end());

        vector<Move> moves = {{}};
        Move nextMove;
        unordered_set<u32> used;
        for (const auto& action : actions) {
            if (action.isEndMove()) {
                moves.back().actions.push_back(action);
                moves.push_back(nextMove);
                nextMove = {};
                used.clear();
            } else {
                if (used.insert(action.manId()).second) {
                    moves.back().actions.push_back(action);
                } else {
                    nextMove.actions.push_back(action);
                }
            }
        }
        moves.pop_back(); 
        const u64 size = min(2UL, moves.size());
        for (u64 i = 0; i < size; ++i) {
            for (const auto& action : moves[i].actions) {
                output << action;
                error << action;
                gameState.lightApplyAction(action);
            }
        }
        return size;
    }

    inline static u64 depth = 0;

    GameState::MoveIdType start() {
        copyCurrentToGlobalBeam();
        for (u64 d = 0; d < DEPTH; ++d) {
            depth = d;
            for (u64 b = 0; b < GameState::B; ++b) {
                doOneIteration(b == GameState::B - 1);
                if (beams.next().empty()) {
                    break;
                }
                beams.swap();
                copyCurrentToGlobalBeam();
                beams.next().clear();
                const u64 sizesSum = globalBeam.size() + gameStates.ids.size();
                assert(sizesSum == 65536);
            }
            beams.current().clear();
            transferGlobalToCurrentBeam();
        }
        beams.current().clear();
        const auto bestBe = globalBeam.front();
        return gameStates[bestBe.gameStateId].moveId;
    }


    INLINE void conditionalInsert(const GameState& parentGameState, GameState& nextGameState, const IdType nextGameStateId,
                                  const Action& action, const GameState::EvalType prvEval) {
#if DEBUG
        assert(nextGameState.hash == nextGameState.calcHash());
#endif
        const auto hash = nextGameState.calcHash();
        if (!cache.insert(hash).second) {
            gameStates.remove(nextGameStateId);
            return;
        }
        const GameState::EvalType eval = nextGameState.calcEval();
        beams.next().push_back(BeamElement{nextGameStateId, eval});
        nextGameState.moveId = movesTree.add(action, nextGameState.moveId);
    }

    inline static array<Vector<u8, 4>, MAX_N> posRev;

    void doOneIteration(const bool finalize) {
        while (beams.current().size() > BEAM_KEEP) {
            movesTree.free(gameStates[beams.current().back().gameStateId].moveId);
            gameStates.remove(beams.current().back().gameStateId);
            beams.current().pop_back();
        }
        for (const auto& be : beams.current()) {
            const GameState& gameState = gameStates[be.gameStateId];
            for (u32 b = 0; b < GameState::B; ++b) {
                if (!posRev[gameState.pos[b]].full()) posRev[gameState.pos[b]].push_back(b);
            }

            for (u32 b = 0; b < GameState::B; ++b) {
                const u32 nextAlreadyMoved = gameState.alreadyMoved | (1U << b);
                if (gameState.alreadyMoved == nextAlreadyMoved) continue;
                const u64 v = gameState.pos[b];

                u8 canUseMask = 0;
                u8 mustUseCount = 0;
                if (posRev[v].size() == 1) {
                    for (u64 e = 0; e < GameState::edges[v].size(); ++e) {
                        const u64 w = GameState::edges[v][e].target;
                        const u64 vwBridgeMask = 1UL << e;
                        const u8 vwDist = GameState::edges[v][e].dist;
                        if ((gameState.bridges[v] & vwBridgeMask) == 0) continue;
                        if (vwDist <= 50 && gameState.carry[b] + vwDist > 60) continue;
                        if (vwDist > 50 && gameState.carry[b] + vwDist > 60) {
                            mustUseCount = 64;
                            break;
                        }
                        if (!posRev[w].empty()) continue;
                        canUseMask |= 1U << e;
                        ++mustUseCount;
                    }
                }
                if (mustUseCount == 0) canUseMask = -1;
                else if (mustUseCount >= 2) canUseMask = 0;

                for (u64 e = 0; e < GameState::edges[v].size(); ++e) {
                    const u64 w = GameState::edges[v][e].target;
                    const u64 wIndex = GameState::edges[v][e].tIndex;
                    const u8 vwDist = GameState::edges[v][e].dist;
                    const u64 vwBridgeMask = 1UL << e;
                    const u64 wvBridgeMask = 1UL << wIndex;

                    if (gameState.bridges[v] & vwBridgeMask) {
                        if (canUseMask & vwBridgeMask) {
                            const auto [nextGameStateId, nextGameState] = gameStates.addGetIdAndRef(gameState);
                            nextGameState.alreadyMoved = nextAlreadyMoved;
                            nextGameState.changePos(b, v, w);
                            nextGameState.handleOrdersFor(b);
                            conditionalInsert(gameState, nextGameState, nextGameStateId, Action::move(b, w), be.eval);
                        } else if (gameState.targets[b] != NO_MSG && !posRev[w].empty()) {
                            i64 bestAtW = -1;
                            for (const auto b2 : posRev[w]) {
                                if (nextAlreadyMoved & (1U << b2)) continue;
                                bestAtW = b2;
                                break;
                            }
                            if (bestAtW != -1) {
                                const auto [nextGameStateId, nextGameState] = gameStates.addGetIdAndRef(gameState);

                                nextGameState.alreadyMoved = nextAlreadyMoved | (1U << bestAtW);
                                nextGameState.changePos(b, v, w);
                                nextGameState.changePos(bestAtW, w, v);
                                nextGameState.handleOrdersFor(b);
                                nextGameState.handleOrdersFor(bestAtW);
                                nextGameState.moveId = movesTree.add(Action::move(b, w), nextGameState.moveId);
                                const auto tmpMoveId = nextGameState.moveId;
                                conditionalInsert(gameState, nextGameState, nextGameStateId, Action::move(bestAtW, v), be.eval);
                                movesTree.free(tmpMoveId);
                            }
                        }
                        if (vwDist + gameState.carry[b] <= 60) {
                            const auto [nextGameStateId, nextGameState] = gameStates.addGetIdAndRef(gameState);
                            nextGameState.alreadyMoved = nextAlreadyMoved;
                            nextGameState.removeBridge(v, w, vwBridgeMask, wvBridgeMask);
                            nextGameState.changeCarry(b, vwDist);
                            conditionalInsert(gameState, nextGameState, nextGameStateId, Action::pack(b, w), be.eval);
                        } else {
                            i64 bestAtW = -1;
                            const i32 bestAtWScore = 0;
                            for (auto b2 : posRev[w]) {
                                if ((nextAlreadyMoved & (1U << b2)) != 0) continue;
                                if (gameState.carry[b] + gameState.carry[b2] + vwDist > 120) continue;
                                i32 score = -gameState.carry[b2];
                                if (gameState.targets[b2] == NO_MSG) score += 20;
                                if (score >= bestAtWScore) bestAtW = b2;
                            }
                            if (bestAtW != -1) {
                                const auto [nextGameStateId, nextGameState] = gameStates.addGetIdAndRef(gameState);
                                nextGameState.alreadyMoved = nextAlreadyMoved | (1U << bestAtW);
                                nextGameState.removeBridge(v, w, vwBridgeMask, wvBridgeMask);
                                const auto bChange = 60 - gameState.carry[b];
                                nextGameState.changeCarry(b, bChange);
                                nextGameState.changeCarry(bestAtW, vwDist - bChange);
                                conditionalInsert(gameState, nextGameState, nextGameStateId,
                                    Action::teamPack(b, bestAtW, bChange), be.eval);
                            }
                        }
                    } else {
                        if (gameState.carry[b] >= vwDist) {
                            const auto [nextGameStateId, nextGameState] = gameStates.addGetIdAndRef(gameState);
                            nextGameState.alreadyMoved = nextAlreadyMoved;
                            nextGameState.addBridge(v, w, vwBridgeMask, wvBridgeMask);
                            nextGameState.changeCarry(b, -vwDist);
                            conditionalInsert(gameState, nextGameState, nextGameStateId, Action::unpack(b, w), be.eval);
                        } else if (!posRev[w].empty()) {
                            i64 bestAtW = -1;
                            const i32 bestAtWScore = 0;
                            for (auto b2 : posRev[w]) {
                                if ((nextAlreadyMoved & (1U << b2)) != 0) continue;
                                if (gameState.carry[b] + gameState.carry[b2] < vwDist) continue;
                                i32 score = gameState.carry[b2];
                                if (gameState.targets[b2] == NO_MSG) score += 20;
                                if (score >= bestAtWScore) bestAtW = b2;
                            }
                            if (bestAtW != -1) {
                                const auto [nextGameStateId, nextGameState] = gameStates.addGetIdAndRef(gameState);
                                nextGameState.alreadyMoved = nextAlreadyMoved | (1U << bestAtW);
                                nextGameState.addBridge(v, w, vwBridgeMask, wvBridgeMask);
                                const auto bCarry = gameState.carry[b];
                                nextGameState.changeCarry(b, -bCarry);
                                nextGameState.changeCarry(bestAtW, bCarry - vwDist);
                                conditionalInsert(gameState, nextGameState, nextGameStateId,
                                    Action::teamUnPack(b, bestAtW, bCarry), be.eval);
                            }
                        }
                    }
                }
            }

            for (u32 b = 0; b < GameState::B; ++b) {
                posRev[gameState.pos[b]].clear();
            }
        }
        sort(beams.next().begin(), beams.next().end(), greater<>());
    }

    template<typename T>
    static void cutBeam(T& beam, u64 keepN) {
        if (beam.size() > keepN) {
            std::nth_element(beam.begin(), beam.begin() + keepN, beam.end(), greater<BeamElement>());
            while (beam.size() > keepN) {
                movesTree.free(gameStates[beam.back().gameStateId].moveId);
                gameStates.remove(beam.popBackAndGet().gameStateId);
            }
        }
    }

    INLINE void copyCurrentToGlobalBeam() {
        const u64 globalSize = min(GLOBAL_BEAM_KEEP, beams.current().size());
        for (u64 i = 0; i < globalSize; ++i) {
            globalBeam.push_back(beams.current()[i]);
        }
        while (beams.current().size() > globalSize) {
            movesTree.free(gameStates[beams.current().back().gameStateId].moveId);
            gameStates.remove(beams.current().back().gameStateId);
            beams.current().pop_back();
        }
        if (beams.current().size() > BEAM_KEEP) {
            beams.current().setSize(BEAM_KEEP);
        }
    }


    INLINE void transferGlobalToCurrentBeam() {
        const u64 size = min(GLOBAL_BEAM_KEEP, globalBeam.size());
        cutBeam(globalBeam, size);
        std::sort(globalBeam.begin(), globalBeam.end(), greater<>());


        for (u64 i = 0; i < size; ++i) {
            beams.current().push_back(globalBeam[i]);
            GameState& gameState = gameStates[globalBeam[i].gameStateId];
            gameState.finalize();


            const auto prvMoveId = gameState.moveId;
            gameState.moveId = movesTree.add(Action::EndMove(), gameState.moveId);
            movesTree.free(prvMoveId);
        }

        if (beams.current().size() > BEAM_KEEP) {
            beams.current().setSize(BEAM_KEEP);
        }
    }
};
// END FILE game/BeamSearch.h

// START FILE io/Reader.h
#include <iostream>


using namespace std;

constexpr bool printOutInput = false;

class Reader {
public:
    virtual ~Reader() = default;
    virtual char readChar() =0;
    virtual string readString() = 0;
    virtual i64 readI64() = 0;
    virtual double readDouble() = 0;
};

/** Reads stdin with getchar_unlocked() which is not thread safe*/
class SingleThreadReader final : public Reader {
public:
    char readChar() override {
        char res;
        while (true) {
            res = getchar_unlocked();
            if (isspace(res)) break;
        }
        if (printOutInput) cerr << res << " ";
        return res;
    }

    string readString() override {
        string s;
        while (true) {
            const char c = getchar_unlocked();
            if (isspace(c)) break;
            s.push_back(c);
        }
        if (printOutInput) cerr << s << " ";
        return s;
    }

    i64 readI64() override {
        i64 num = 0;
        char ch = getchar_unlocked();
        while (true) {
            if (ch == '-') break;
            if ('0' <= ch && ch <= '9') break;
            ch = getchar_unlocked();
        }
        if (ch == '-') {
            while (true) {
                ch = getchar_unlocked();
                if (ch < '0' || '9' < ch) break;
                num = num * 10 - (ch - '0');
            }
        } else {
            num = ch - '0';
            while (true) {
                ch = getchar_unlocked();
                if (ch < '0' || '9' < ch) break;
                num = num * 10 + (ch - '0');
            }
        }
        if (printOutInput) cerr << num << " ";
        return num;
    }


    double readDouble() override {
        string s;
        while (true) {
            const char c = getchar_unlocked();
            if (isspace(c)) break;
            s.push_back(c);
        }
        double num = std::stod(s);
        if (printOutInput) cerr << num << " ";
        return num;
    }
};
// END FILE io/Reader.h

// START FILE agent/AgentInput.h
#include <cassert>
#include <iomanip>



INLINE void Agent::readInitialInput() {
    GameState::initializeZobristHashes();
    GameState::N = reader.readI64();
    startTime = getTime();
    GameState::B = reader.readI64();
    GameState::O = reader.readI64();

    struct TEdge {
        u8 v, w;
        u16 length;

        TEdge() = default;

        TEdge(const u8 v, const u8 w, const u16 length) : v(v), w(w), length(length) {
        }

        bool operator<(const TEdge& other) const {
            return length < other.length;
        }
    };

    Vector<TEdge, MAX_N * MAX_N> allEdges;
    for (u64 i = 0; i < GameState::N; ++i) {
#if DEBUG
        if (GameState::O >= 128) {
            GameState::islandPos[i].x = reader.readI64();
            GameState::islandPos[i].y = reader.readI64();
        }
#endif
        for (u64 j = 0; j < GameState::N; ++j) {
            GameState::trueEdge[i][j] = reader.readI64();
            if (i < j && GameState::trueEdge[i][j] <= 100) {
                allEdges.push_back(TEdge(i, j, GameState::trueEdge[i][j]));
            }
        }
    }
    sort(allEdges.begin(), allEdges.end());
    for (auto [v,w,length] : allEdges) {
        if (GameState::edges[v].full()) continue;
        if (GameState::edges[w].full()) continue;
        if (GameState::trueEdge[v][w] > 50) {
            bool found = false;
            for (u64 u = 0; u < GameState::N; ++u) {
                if (GameState::trueEdge[v][u] <= 50 && GameState::trueEdge[u][w] <= 50) {
                    found = true;
                    break;
                }
            }
            if (found) {
                continue;
            }
        }
        const u16 dist = GameState::trueEdge[v][w];
        const u8 vIndex = GameState::edges[v].size();
        const u8 wIndex = GameState::edges[w].size();
        GameState::edges[v].push_back({w, wIndex, dist});
        GameState::edges[w].push_back({v, vIndex, dist});
    }
    for (u64 i = 0; i < GameState::N; ++i) {
        assert(!GameState::edges[i].empty());
    }

#if DEBUG
    if (GameState::O >= 128) {
        GameState::O -= 128;
    }
#endif

    GameState::initializeDists();
    for (u64 b = 0; b < GameState::B; ++b) {
        GameState::zobAllAlreadyMoved ^= GameState::zobAlreadyMoved[b];
    }
}

INLINE void Agent::readTurnInput() {
    u64 time = reader.readI64() * 1000;
#ifndef DEBUG
    if (turn >= 9) {
        u64 avgTurnTime = (time - turnEndTimes[turn & 7]) / 8;
        turnEndTimes[turn & 7] = time;
        u64 expectedEndTime = time + (MAX_TURN - turn + 1) * avgTurnTime;
        error << "Turn " << turn << "\n";
        error << "Time " << time / 1000 << "\n";
        error << "Avg turn time " << avgTurnTime / 1000 << "\n";
        error << "Expected end time " << expectedEndTime / 1000 << "\n";
        if (expectedEndTime > 9'800'000) {
            if (BeamSearch::BEAM_KEEP >= 4) {
                BeamSearch::BEAM_KEEP -= 1;
                error << "BEAM_KEEP" << BeamSearch::BEAM_KEEP << "\n";
            }
            if (BeamSearch::BEAM_KEEP <= 20 && BeamSearch::DEPTH >= 4) {
                --BeamSearch::DEPTH;
            }
        } else if (expectedEndTime < 9'500'000 && turn % 8 == 0) {
            if (BeamSearch::BEAM_KEEP + 2 <= BeamSearch::GLOBAL_BEAM_KEEP) {
                BeamSearch::BEAM_KEEP += 1;
                error << "BEAM_KEEP" << BeamSearch::BEAM_KEEP << "\n";
            }
        }
    }
#endif


    for (u64 b = 0; b < GameState::B; ++b) {
        gameState.pos[b] = reader.readI64();
        gameState.carry[b] = reader.readI64();
        const i64 target = reader.readI64();
        gameState.targets[b] = target != -1 ? target : NO_MSG;
    }

    for (u64 o = 0; o < GameState::O; ++o) {
        GameState::orders[o].first = reader.readI64();
        GameState::orders[o].second = reader.readI64();
    }

    gameState.hash = gameState.calcHash();
    if (turn == 1) {
        for (u64 b = 0; b < GameState::B; ++b) {
            gameState.handleOrdersFor(b);
        }
    }
}
// END FILE agent/AgentInput.h

// START FILE game/AStar.h

// END FILE game/AStar.h

// START FILE agent/AgentOutput.h
INLINE void Agent::calculateOutput() {
    error << turn << " " << skip << endl;
    if (turn <= skip) return;
    BeamSearch beamSearch(gameState);
    const auto moveIdType = beamSearch.start();
    const u64 toSkip = beamSearch.reconstructMoves(output, error, gameState, moveIdType);
    skip += toSkip;
}
// END FILE agent/AgentOutput.h

// START FILE agent/Agent.cpp

// END FILE agent/Agent.cpp

// START FILE BridgeRunnersSubmit.cpp
#include <iostream>



using namespace std;

int main() {
    SingleThreadReader reader;
    Agent agent(reader, cout, cerr);

    Config::init();

    agent.readInitialInput();
    while (Agent::turn < MAX_TURN) {
        ++Agent::turn;
        Agent::_timeout = false;
        agent.readTurnInput();
        agent.calculateOutput();
        cout.flush();
        cerr.flush();
    }
}
// END FILE BridgeRunnersSubmit.cpp

