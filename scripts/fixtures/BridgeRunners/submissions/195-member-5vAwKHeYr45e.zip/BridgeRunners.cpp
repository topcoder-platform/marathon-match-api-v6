#include <iostream>
#include <vector>
#include <string>
#include <sstream>
#include <numeric>
#include <algorithm>
#include <cassert>

enum class Action {
    UNPACK,
    TEAMUNPACK,
    MOVE, 
    PACK,
    TEAMPACK,
    MSG,
    NONE
};

constexpr const char* action_strings[] = 
{"UNPACK", "TEAMUNPACK", "MOVE", "PACK", "TEAMPACK", "MSG", "NONE"};

inline std::ostream& operator<<(std::ostream& os, Action action) {
    return os << action_strings[static_cast<int>(action)];
}

// Stores full command info for all action types
struct Command {
    Action action;
    union {
        // Single actions: MOVE, UNPACK, PACK
        struct { int bridgeman_id; int island_id; } single;

        // Team actions: TEAMUNPACK, TEAMPACK
        struct {
            int bridgeman_id1; int bridgeman_id2; int length;
        } team;

        // Debug/Message action: MSG
        struct { char *msg; } dbg;
    } data;

    Command() = default;

    // Constructor for single actions: MOVE, UNPACK, PACK
    Command(Action act, int bridgeman_id, int island_id) : action(act) {
        data.single.bridgeman_id = bridgeman_id;
        data.single.island_id = island_id;
    }

    // Constructor for team actions: TEAMUNPACK, TEAMPACK
    Command(Action act, int bridgeman_id1, int bridgeman_id2, int length) : action(act) {
        data.team.bridgeman_id1 = bridgeman_id1;
        data.team.bridgeman_id2 = bridgeman_id2;
        data.team.length = length;
    }

    Command(Action act, char* msg) : action(act) {
        data.dbg.msg = msg;
    }

    Command(Action act) : action(act) {}


    friend std::ostream& operator<<(std::ostream& os, const Command& cmd) {
        if (cmd.action == Action::NONE) return os;

        os << cmd.action;
        switch (cmd.action) {
            case Action::MOVE:
            case Action::UNPACK:
            case Action::PACK:
                os << " " << cmd.data.single.bridgeman_id << " " << cmd.data.single.island_id;
                break;
            case Action::TEAMUNPACK:
            case Action::TEAMPACK:
                os << " " << cmd.data.team.bridgeman_id1 << " " << cmd.data.team.bridgeman_id2
                   << " " << cmd.data.team.length;
                break;
            case Action::MSG:
                os << " " << cmd.data.dbg.msg;
                break;
            case Action::NONE:
                break;
        }
        return os;
    }
};


int N, B, O;
int **dists;
bool **connected;
int *destinations; // How many bridgemen are targeting each island
int **bridges_needed;
std::vector<Command> output;

class Order {
public:
    int from;
    int to;
};

std::vector<Order> orders;

int reused_bridges = 0;

class Bridgeman {
public:
    int ID;
    int position;
    int target;
    int bricks;
    int bridge_from = -1;
    int bridge_to = -1;
    int destination = -1;
    int teammate_ID = -1;

    // Checks if island is reachable in one bridge
    // 0 - no, 1 - bridge can be built, 2 - already connected
    int is_one_bridge_away(const int island_id) const {
        if (connected[position][island_id]) return 2;
        if (dists[position][island_id] <= bricks) return 1;
        return 0;
    }

    Command move_to(const int island_id) {
        if (island_id == -1 || island_id == position) return Command(Action::NONE);

        // If a bridge already exists, use it
        if (connected[position][island_id]) {
            position = island_id;
            ++reused_bridges;
            return Command(Action::MOVE, ID, island_id);
        }
        else {
            // Build the bridge
            bridge_from = position;
            bridge_to = island_id;
            connected[bridge_from][bridge_to] = true;
            connected[bridge_to][bridge_from] = true;
            return Command(Action::UNPACK, ID, island_id);
        }
    }

    int choose_next_destination() {
        // Pick up a new order
        std::pair<int, int> best_order = {1e9, -1}; // {distance, island_id}
        auto best_it = orders.end();
        for (auto it = orders.begin(); it != orders.end(); ++it) {
            // Check self-reachability
            if (bridges_needed[position][it->from] == 1e9
                || bridges_needed[it->from][it->to] == 1e9) {
                continue;
            }
            auto candidate = std::make_pair(bridges_needed[position][it->from], it->from);
            if (candidate < best_order) {
                best_order = candidate;
                best_it = it;
            }
        }
        if (best_it != orders.end()) {
            orders.erase(best_it);
        }
        return best_order.second;
    }

    int next_move() {
        if (destination == -1 || destination == position) {
            // destination = choose_next_destination();
            // if (destination == -1 || destination == position) {
                return -1;
            // }
        }
        // Choose the move that will minimize actions to reach target
        std::pair<int, int> best_move = {1e9, -1}; // {actions_needed, island_id}
        for (int i = 0; i < N; ++i) {
            if (connected[position][i] == true || dists[position][i] <= bricks) {
                int moves = (connected[position][i] ? 1 : 3);
                moves += bridges_needed[i][destination] * 3;
                best_move = std::min(best_move, {moves, i});
            }
        }
        return best_move.second;
    }

    Command perform_teamunpack(Bridgeman &teammate) {
        if (connected[position][teammate.position]) {
            return Command(Action::NONE);
        }
        int length = dists[position][teammate.position];
        teammate_ID = teammate.ID;
        teammate.teammate_ID = ID;
        bridge_from = position;
        bridge_to = teammate.position;
        teammate.bridge_from = teammate.position;
        teammate.bridge_to = position;
        connected[bridge_from][bridge_to] = true;
        connected[bridge_to][bridge_from] = true;
        return Command(Action::TEAMUNPACK, ID, teammate.ID, length/2);
    }
};

std::vector<std::tuple<int, int, int, int>> get_all_teamunpacks(std::vector<Bridgeman> &available) {
    std::vector<std::tuple<int, int, int, int>> teamunpacks;
    for (int i = 0; i < (int)available.size(); ++i) {
        for (int j = i + 1; j < (int)available.size(); ++j) {
            int dist = dists[available[i].position][available[j].position];
            if (dist > 50 && dist <= 100) {
                int b1_diff = 1, b2_diff = 1;
                if (available[i].destination != -1) {
                    b1_diff = bridges_needed[available[i].position][available[i].destination]
                              - bridges_needed[available[j].position][available[i].destination];
                }
                if (available[j].destination != -1) {
                    b2_diff = bridges_needed[available[j].position][available[j].destination]
                              - bridges_needed[available[i].position][available[j].destination];
                }
                if (b1_diff > 0 || b2_diff > 0) {
                    teamunpacks.push_back(
                        {available[i].ID, available[j].ID, b1_diff, b2_diff});
                }
            }
        }
    }
    return teamunpacks;
}


// static int g_seed = 777778;
// static int Rand(int mod) {
//     g_seed = (214013 * g_seed + 2531011);
//     return ((g_seed >> 16) & 0x7FFF) % mod;
// }

int** bridge_apsp(const int max_bridge_len) {
    int **hop = new int*[N];
    for (int i = 0; i < N; ++i) {
        hop[i] = new int[N];
        for (int j = 0; j < N; ++j) {
            if (i == j) hop[i][j] = 0;
            else if (dists[i][j] <= max_bridge_len) hop[i][j] = 1;
            else if (dists[i][j] <= 2*max_bridge_len) hop[i][j] = N*N;
            else hop[i][j] = 1e9;
        }
    }
    for (int k = 0; k < N; ++k) {
        for (int i = 0; i < N; ++i) {
            for (int j = 0; j < N; ++j) {
                if (hop[i][j] > hop[i][k] + hop[k][j]) {
                    hop[i][j] = hop[i][k] + hop[k][j];
                }
            }
        }
    }
    return hop;
}

int main() {
    std::cin >> N >> B >> O;

    dists = new int*[N];
    connected = new bool*[N];
    bridges_needed = new int*[N];
    for (int i = 0; i < N; ++i) {
        dists[i] = new int[N];
        connected[i] = new bool[N];
        bridges_needed[i] = new int[N];
    }
    destinations = new int[N];
    std::fill(destinations, destinations + N, 0);

    for (int i = 0; i < N; ++i) {
        for (int j = 0; j < N; ++j) {
            connected[i][j]=false;
            std::cin >> dists[i][j];
        }
    }

    bridges_needed = bridge_apsp(50);

    Bridgeman bridgemen[B];
    for (int i = 0; i < B; ++i) {
        bridgemen[i].ID = i;
    }


    for (int turn = 1; turn <= 1000; turn++) {
        int elapsedTime;
        std::cin >> elapsedTime;
        for (int i = 0; i < B; ++i) {
            std::cin >> bridgemen[i].position >> bridgemen[i].bricks >> bridgemen[i].target;
            bridgemen[i].destination = bridgemen[i].target;
        }

        orders = std::vector<Order>(O);
        for (int i = 0; i < O; ++i) {
            std::cin >> orders[i].from >> orders[i].to;
        }

        // Update destinations
        std::fill(destinations, destinations + N, 0);
        for (auto &b : bridgemen) {
            if (b.target != -1) {
                destinations[b.target]++;
            }
        }

        // Update order pickups for bridgemen without targets
        for (auto &order : orders) {
            if (destinations[order.from] > 0) {
                destinations[order.from]--;
                continue;
            }

            std::pair<int,int> best = {1e9, -1}; // {distance, bridgeman_id}
            for (auto &b : bridgemen) {
                if (b.destination == -1) {
                    best = std::min(
                        best, {bridges_needed[b.position][order.from], b.ID});
                }
            }
            if (best.second != -1) {
                bridgemen[best.second].destination = order.from;
            }
        }

        output.clear();

        std::vector<Bridgeman> available_bridgemen;
        for (auto &b : bridgemen) {
            if (b.bridge_from == -1) {
                available_bridgemen.push_back(b);
            }
        }

        auto teamunpacks = get_all_teamunpacks(available_bridgemen);
        std::sort(teamunpacks.begin(), teamunpacks.end(), [](const auto &a, const auto &b) {
            int score_a = std::get<2>(a) + std::get<3>(a);
            int score_b = std::get<2>(b) + std::get<3>(b);
            return score_a > score_b;
        });

        std::vector<bool> busy(B, false);
        for (auto &tu : teamunpacks) {
            int b1_id = std::get<0>(tu), b2_id = std::get<1>(tu);
            int score = std::get<2>(tu) + std::get<3>(tu);
            if (score < 3 || busy[b1_id] || busy[b2_id]) continue;
            // std::cerr << "Teamunpack score: " << score << "\n";
            Command cmd = bridgemen[b1_id].perform_teamunpack(bridgemen[b2_id]);
            if (cmd.action == Action::NONE) continue;
            output.push_back(cmd);
            busy[b1_id] = true;
            busy[b2_id] = true;

            // Perform as many move actions as possible
            for (auto &b : available_bridgemen) {
                if (busy[b.ID]) continue;
                int island_id = bridgemen[b.ID].next_move();
                if (island_id != -1 && connected[b.position][island_id]) {
                    output.push_back(bridgemen[b.ID].move_to(island_id));
                    busy[b.ID] = true;
                }
            }
        }

        for (auto &b : bridgemen) {
            if (busy[b.ID]) continue;

            if (b.bridge_from == -1) { // unpack or move
                Command command = b.move_to(b.next_move());
                if (command.action != Action::NONE) {
                    output.push_back(command);
                }
            } else if (b.bridge_from == b.position) { // MOVE
                output.push_back(Command(Action::MOVE, b.ID, b.bridge_to));
            } else { // PACK
                // TEAMPACK
                if (dists[b.bridge_from][b.bridge_to] > 50) {
                    if (b.ID < b.teammate_ID) {
                        output.push_back(Command(Action::TEAMPACK, b.ID, b.teammate_ID, 50 - b.bricks));
                    }
                    continue;
                }

                // PACK
                // Check if bridge could be reused
                if (b.destination != -1
                    && (bridges_needed[b.position][b.destination]
                        >= bridges_needed[b.bridge_from][b.destination] + 1)) {

                    output.push_back(b.move_to(b.bridge_from));
                    std::swap(b.bridge_from, b.bridge_to);
                } else {
                    output.push_back(Command(Action::PACK, b.ID, b.bridge_from));
                }
            }
        }

        std::stable_sort(output.begin(), output.end(), [](const Command& a, const Command& b) {
            return static_cast<int>(a.action) < static_cast<int>(b.action);
        });

        auto pack_it = std::find_if(output.begin(), output.end(), [](const Command& cmd) {
            return cmd.action == Action::PACK;
        });

        auto teampack_it = std::find_if(output.begin(), output.end(), [](const Command& cmd) {
            return cmd.action == Action::TEAMPACK;
        });

        // Update connectivity after all pack commands
        for (auto it = pack_it; it != output.end() && it->action == Action::PACK; ++it) {
            auto b = &bridgemen[it->data.single.bridgeman_id];
            connected[b->bridge_from][b->bridge_to] = false;
            connected[b->bridge_to][b->bridge_from] = false;
            b->bridge_from = -1;
            b->bridge_to = -1;
        }

        for (auto it = teampack_it; it != output.end() && it->action == Action::TEAMPACK; ++it) {
            auto b1 = &bridgemen[it->data.team.bridgeman_id1];
            if (b1->bridge_from == -1) continue; // already packed
            auto b2 = &bridgemen[it->data.team.bridgeman_id2];
            connected[b1->bridge_from][b1->bridge_to] = false;
            connected[b1->bridge_to][b1->bridge_from] = false;
            b1->bridge_from = -1;
            b1->bridge_to = -1;
            b2->bridge_from = -1;
            b2->bridge_to = -1;
        }

        // for (size_t i = 0; i < output.size(); ++i) {
        //     std::cerr << output[i];
        //     if (i < output.size() - 1) {
        //         std::cerr << " | ";
        //     }
        // }
        // std::cerr << "\n";

        for (size_t i = 0; i < output.size(); ++i) {
            std::cout << output[i];
            if (i < output.size() - 1) {
                std::cout << " | ";
            }
        }
        std::cout << std::endl;
    }

    // std::cerr << "Reused bridges: " << reused_bridges << "\n";

    delete [] destinations;
    for (int i = 0; i < N; ++i) {
        delete [] dists[i];
        delete [] connected[i];
        delete [] bridges_needed[i];
    }
    delete [] dists;
    delete [] connected;
    delete [] bridges_needed;

    return 0;
}