#include <iostream>
#include <vector>
#include <string>
#include <sstream>
#include <numeric>
#include <algorithm>
#include <utility>
#include <set>
#include <queue>
#include <algorithm>

class Bridgeman {
public:
    int ID;
    int Position;
    int Target;
    int Bricks;
    int BridgeFrom = -1;
    int BridgeTo = -1;
};

class Order {
public:
    int From;
    int To;
};

static int g_seed = 777778;
static int Rand(int mod) {
    g_seed = (214013 * g_seed + 2531011);
    return ((g_seed >> 16) & 0x7FFF) % mod;
}



int main() {
    int N, B, O;
    std::cin >> N >> B >> O;

    int dists[N][N];
    bool connected[N][N];
    int distsBuildable[N][N];
    for (int i = 0; i < N; ++i) {
        for (int j = 0; j < N; ++j) {
            connected[i][j]=false;
            std::cin >> dists[i][j];
            if (i==j){distsBuildable[i][j]=0;}
            else if(dists[i][j]<=50){distsBuildable[i][j]=1;}
            else {distsBuildable[i][j]=999999;}
        }
    }
    //floyd warshall

    for (int k = 0; k < N; ++k) {
        for (int i = 0; i < N; ++i) {
            for (int j = 0; j < N; ++j) {
                distsBuildable[i][j] = std::min(distsBuildable[i][j], distsBuildable[i][k] + distsBuildable[k][j]); 
            }
        }
    }

    // for (int i = 0; i < N; ++i) {
    //         for (int j = 0; j < N; ++j) {
    //         std::cerr << "i:" << i << " j:" << j << " dist:" << distsBuildable[i][j] << std::endl;
    //     }
    // }
    Bridgeman bridgemen[B];
    for (int i = 0; i < B; ++i) {
        bridgemen[i].ID = i;
    }

    for (int turn = 1; turn <= 1000; turn++) {
        int elapsedTime;
        std::cin >> elapsedTime;
        for (int i = 0; i < B; ++i) {
            std::cin >> bridgemen[i].Position >> bridgemen[i].Bricks >> bridgemen[i].Target;
        }
        std::vector<Order> orders(O);
        for (int i = 0; i < O; ++i) {
            std::cin >> orders[i].From >> orders[i].To;
            //std::cerr << "o:"<<orders[i].From << " " <<  orders[i].To  << std::endl;
        }
        int cpt =0;
        std::vector<std::string> output;
        std::vector<int> freeBridgemens;
        for (auto& b : bridgemen) {
            if (b.BridgeFrom == -1) { // unpack
                //std::cerr << "----- " << b.ID << " -----" << std::endl;
                std::vector<int> targets;
                std::vector<int> moves;
                for (int t = 0; t < N; ++t) {
                    bool found = 0;

                    if (t != b.Position && !connected[b.Position][t] && dists[b.Position][t] <= b.Bricks ) {

                            targets.push_back(t);
                    }

                }
                if (!targets.empty()) {
                    bool found = 0;
                    int t =-1;
                    std::vector<std::pair<int,int>> evals;
                    for (auto tar:targets){
                        
                        if (b.Target !=-1){
                            int distObj = distsBuildable[tar][b.Target];
                            if(distObj< distsBuildable[b.Target][b.Position] && distObj<99999){
                                evals.push_back({tar,distObj});
                                found=1;}
                        }
                        else {
                            for (auto &o : orders)
                            {
                                if (tar == o.From )
                                {

                                    int distObj = distsBuildable[tar][b.Position];
                                    if (distObj<999999)evals.push_back({tar, distObj * 3});
                                    found = 1;
                                }
                                else {

                                    int distObj = distsBuildable[tar][o.From];
                                    if(distObj < distsBuildable[b.Position][o.From] && distObj<99999){
                                        evals.push_back({tar, distObj * 10});
                                        found = 1;
                                    }

                                }
                            }
                        }
                         
                    }
                    sort(evals.begin(),evals.end(),[](auto& a , auto& b){return a.second < b.second;});

                    if (found){
                        t = evals[0].first;
                    }
                    // else {
                    //     cpt++;
                    //     t = targets[Rand(targets.size())];
                    //     //freeBridgemens.push_back(b.ID);
                    // }
                    if (t!=-1){
                        output.push_back("UNPACK " + std::to_string(b.ID) + " " + std::to_string(t));
                        b.BridgeFrom = b.Position;
                        b.BridgeTo = t;
                        connected[b.BridgeFrom][b.BridgeTo] = true;
                        connected[b.BridgeTo][b.BridgeFrom] = true;
                    }
                    
                }
    
            
            } else if (b.BridgeFrom == b.Position) { // MOVE
                output.push_back("MOVE " + std::to_string(b.ID) + " " + std::to_string(b.BridgeTo));
            } else { // PACK
                output.push_back("PACK " + std::to_string(b.ID) + " " + std::to_string(b.BridgeFrom));
                connected[b.BridgeFrom][b.BridgeTo] = false;
                connected[b.BridgeTo][b.BridgeFrom] = false;
                b.BridgeFrom = -1;
                b.BridgeTo = -1;
            }
        }
        // for (int freeB: freeBridgemens){
        //     //std::cerr << freeB ;
        //     Bridgeman& b1 = bridgemen[freeB];
        //     for (int freeBAssist: freeBridgemens){
        //         //std::cerr << " " << freeB << std::endl;
        //         Bridgeman& b2 = bridgemen[freeBAssist];
        //         if (b1.Target!=-1 && freeBAssist!=freeB && b1.BridgeFrom == -1 && b2.BridgeFrom == -1){
        //             if (  dists[b1.Position][b2.Position] <= b1.Bricks+b2.Bricks && dists[b1.Position][b2.Position]>50){
        //                 std::cerr << "TEAMUNPACK " << b1.ID << " " << b2.ID <<  " " << b1.Bricks << std::endl;
        //                 output.push_back("TEAMUNPACK " + std::to_string(b1.ID) + " " + std::to_string(b2.ID) +  " " + std::to_string(b1.Bricks));
        //                 b1.BridgeFrom = b1.Position;
        //                 b1.BridgeTo = b2.Position;
        //                 connected[b1.BridgeFrom][b1.BridgeTo] = true;
        //                 connected[b1.BridgeTo][b1.BridgeFrom] = true;
        //             }
        //         }
                
        //     }
        // }

        for (size_t i = 0; i < output.size(); ++i) {
            std::cout << output[i];
            if (i < output.size() - 1) {
                std::cout << " | ";
            }
        }
        std::cout << std::endl;
        // std::cerr << cpt << std::endl;
    }

    return 0;
}