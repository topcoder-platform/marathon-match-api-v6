#include <bits/stdc++.h>
#include <sys/time.h>

using namespace std;

#ifdef LOCAL
constexpr double TIME_SCALE = 0.7;
#else
constexpr double TIME_SCALE = 1.0;
#endif

constexpr double TL = 9.0 * TIME_SCALE;
constexpr int INF = 1e9;

double get_time() {
    timeval tv;
    gettimeofday(&tv, NULL);
    return (double)tv.tv_sec + tv.tv_usec * 1e-6;
}
double start_time = get_time();
double elapsed() { return get_time() - start_time; }


bool is_tl() {
    return elapsed() > TL;
}

#define INLINE   inline __attribute__ ((always_inline))
#define FOR(i,a,b)  for(int i=(a);i<(b);++i)
#define REP(i,a)    FOR(i,0,a)

struct RNG {
    unsigned int MT[624];
    int index;
    RNG(int seed = 1) {init(seed);}
    void init(int seed = 1) {MT[0] = seed; FOR(i, 1, 624) MT[i] = (1812433253UL * (MT[i-1] ^ (MT[i-1] >> 30)) + i); index = 0; }
    void generate() {
        const unsigned int MULT[] = {0, 2567483615UL};
        REP(i, 227) {unsigned int y = (MT[i] & 0x8000000UL) + (MT[i+1] & 0x7FFFFFFFUL); MT[i] = MT[i+397] ^ (y >> 1); MT[i] ^= MULT[y&1]; }
        FOR(i, 227, 623) {unsigned int y = (MT[i] & 0x8000000UL) + (MT[i+1] & 0x7FFFFFFFUL); MT[i] = MT[i-227] ^ (y >> 1); MT[i] ^= MULT[y&1]; }
        unsigned int y = (MT[623] & 0x8000000UL) + (MT[0] & 0x7FFFFFFFUL); MT[623] = MT[623-227] ^ (y >> 1); MT[623] ^= MULT[y&1];
    }
    unsigned int rand() { if (index == 0) generate(); unsigned int y = MT[index]; y ^= y >> 11; y ^= y << 7  & 2636928640UL; y ^= y << 15 & 4022730752UL; y ^= y >> 18; index = index == 623 ? 0 : index + 1; return y;}
    INLINE int next() {return rand(); }
    INLINE int next(int x) {return rand() % x; }
    INLINE int next(int a, int b) {return a + (rand() % (b - a)); }
    INLINE double next_double() {return (rand() + 0.5) * (1.0 / 4294967296.0); }
    INLINE double next_double(double a, double b) {return a + next_double() * (b - a); }
};
 
static RNG rng;


struct Bridgeman {
    int pos;
    int order_target;
    int bricks;
    int bridge_from = -1;
    int bridge_to = -1;
    int partner = -1;
};

struct Order {
    int from;
    int to;
};

int N, B, O;
int DISTS[100][100];
int connected[100][100];

struct Distances {
    int from;
    vector<int> dist;
    vector<int> parent;
    Distances(int f, const vector<int>& d, const vector<int>& p) : from(f), dist(d), parent(p) {}
};

Distances bfs(int start, int max_w) {
    vector<int> dist(N, INF);
    vector<int> parent(N, -1);
    dist[start] = 0;
    queue<int> q;
    q.push(start);
    while (!q.empty()) {
        int v = q.front(); q.pop();
        for (int u = 0; u < N; ++u) {
            if (u != v && dist[u] == INF && DISTS[v][u] <= max_w) {
                dist[u] = dist[v] + 1;
                parent[u] = v;
                q.push(u);
            }
        }
    }
    return Distances(start, dist, parent);
}

Distances dist_dp(int start) {
    vector<int> dist(N, INF);
    vector<int> parent(N, -1);
    dist[start] = 0;
    while (true) {
        int updated = 0;
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < N; j++) {
                if (i == j) continue;
                int w = INF;
                if (DISTS[i][j] <= 50) w = 1;
                else if (DISTS[i][j] <= 100) w = 5;
                if (dist[j] > dist[i] + w) {
                    dist[j] = dist[i] + w;
                    parent[j] = i;
                    updated = 1;
                }
            }
        }
        if (!updated) break;
    }
    return Distances(start, dist, parent);
}

int main() {
    ios_base::sync_with_stdio(false);cin.tie(0);

    cin >> N >> B >> O;

    for (int i = 0; i < N; ++i) {
        for (int j = 0; j < N; ++j) {
            connected[i][j]=false;
            cin >> DISTS[i][j];
        }
    }

    vector<Distances> all_dists;
    vector<Distances> dists_dp;
    for (int i = 0; i < N; ++i) {
        all_dists.push_back(bfs(i, 50));
        dists_dp.push_back(dist_dp(i));
    }

  
    vector<Bridgeman> units(B);
    for (int turn = 1; turn <= 1000; turn++) {
        int elapsedTime;
        std::cin >> elapsedTime;
        cerr << "Turn " << turn << ", elapsed: " << elapsedTime / 1000.0 << endl;

        for (int i = 0; i < B; i++) {
            cin >> units[i].pos >> units[i].bricks >> units[i].order_target;
        }

        vector<Order> orders(O);
        for (int i = 0; i < O; i++) {
            cin >> orders[i].from >> orders[i].to;
        }

        vector<int> moved(B, 0);
        vector<int> order_taken(O, 0);
        vector<int> target(B, -1);

        vector<string> commands;
        for (int i = 0; i < B; i++) {
            if (units[i].order_target == -1) {
                int opt_order = -1;
                for (int j = 0; j < O; j++) {
                    if (order_taken[j]) continue;
                    int d = dists_dp[units[i].pos].dist[orders[j].from];
                    if (d == INF) continue;
                    if (opt_order == -1 || d <= dists_dp[units[i].pos].dist[orders[opt_order].from]) {
                        opt_order = j;
                    }
                }
                if (opt_order != -1) {
                    order_taken[opt_order] = 1;
                    target[i] = orders[opt_order].from;
                }
            } else {
                target[i] = units[i].order_target;
            }
        }

        for (int i = 0; i < B; i++) {
            if (target[i] == -1 || units[i].bridge_from != -1 || units[i].bridge_to != -1) continue;
            for (int to = 0; to < N; to++) {
                if (!connected[units[i].pos][to]) continue;
                if (dists_dp[to].dist[target[i]] + 1 < dists_dp[units[i].pos].dist[target[i]]) {
                    commands.push_back("MOVE " + to_string(i) + " " + to_string(to));
                    moved[i] = 1;
                    break;
                }
            }
        }

        for (int i = 0; i < B; i++) {
            if (target[i] == -1 || moved[i] || units[i].bridge_from == -1 || units[i].partner != -1) continue;
            if (dists_dp[units[i].bridge_from].dist[target[i]] < dists_dp[units[i].pos].dist[target[i]]) {
                commands.push_back("MOVE " + to_string(i) + " " + to_string(units[i].bridge_from));
                moved[i] = 1;
                units[i].bridge_from = units[i].pos;
            }
        }
        for (int i = 0; i < B; i++) {
            for (int j = 0; j < i; j++) {
                if (target[i] == -1 && target[j] == -1) continue;
                if (moved[i] || moved[j]) continue;
                int d = DISTS[units[i].pos][units[j].pos];
                if (d <= 50 || d > 100) continue;
                if (units[i].bridge_from != -1 || units[i].bridge_to != -1) continue;
                if (units[j].bridge_from != -1 || units[j].bridge_to != -1) continue;
                
                assert(units[i].bricks == 50);
                assert(units[j].bricks == 50);

                auto get_dp = [&](int pos1, int pos2) {
                    int res = 0;
                    if (target[i] != -1) {
                        res += dists_dp[pos1].dist[target[i]];
                    }
                    if (target[j] != -1) {
                        res += dists_dp[pos2].dist[target[j]];
                    }
                    return res;
                };

                int cur_dp = get_dp(units[i].pos, units[j].pos);
                int new_dp = get_dp(units[j].pos, units[i].pos) + 1;
                if (new_dp < cur_dp) {
                    if (connected[units[i].pos][units[j].pos]) {
                        cerr << "Team Moving " << i << " from " << units[i].pos << " to " << units[j].pos << endl;
                        commands.push_back("MOVE " + to_string(i) + " " + to_string(units[j].pos));
                        cerr << "Team Moving " << j << " from " << units[j].pos << " to " << units[i].pos << endl;
                        commands.push_back("MOVE " + to_string(j) + " " + to_string(units[i].pos));
                        moved[i] = moved[j] = 1;
                    } else {
                        commands.push_back("TEAMUNPACK " + to_string(i) + " " + to_string(j) + " 50");
                        units[i].partner = j;
                        units[j].partner = i;
                        units[i].bridge_to = units[j].pos;
                        units[j].bridge_to = units[i].pos;
                        connected[units[i].pos][units[j].pos] = true;
                        connected[units[j].pos][units[i].pos] = true;
                        moved[i] = moved[j] = 1;
                    }
                }
            }
        }

        for (int i = 0; i < B; i++) {
            if (target[i] == -1 || units[i].bridge_from != -1 || units[i].bridge_to != -1 || moved[i]) continue;
            assert(units[i].bricks == 50);
            
            int to = dists_dp[target[i]].parent[units[i].pos];
            if (DISTS[units[i].pos][to] > 50) to = all_dists[target[i]].parent[units[i].pos];
            if (to == -1) continue;
            if (!connected[units[i].pos][to]) {
                commands.push_back("UNPACK " + to_string(i) + " " + to_string(to));
                connected[units[i].pos][to] = true;
                connected[to][units[i].pos] = true;
                units[i].bridge_to = to;
                moved[i] = 1;
            } else {
                cerr << "Moving " << i << " from " << units[i].pos << " to " << to << endl;
                commands.push_back("MOVE " + to_string(i) + " " + to_string(to));
                moved[i] = 1;
            }
        }
        for (int i = 0; i < B; i++) {
            if (moved[i] || units[i].bridge_to == -1) continue;
            assert(connected[units[i].pos][units[i].bridge_to]);
            commands.push_back("MOVE " + to_string(i) + " " + to_string(units[i].bridge_to));
            moved[i] = 1;
            units[i].bridge_to = -1;
            units[i].bridge_from = units[i].pos;
            units[i].pos = target[i];
        }
        for (int i = 0; i < B; i++) {
            if (moved[i] || units[i].bridge_from == -1) continue;
            assert(connected[units[i].bridge_from][units[i].pos]);

            if (units[i].partner != -1) {
                int p = units[i].partner;
                assert(!moved[p]);
                assert(units[p].partner == i);
                assert(units[i].bridge_from == units[p].pos);
                assert(units[p].bridge_from == units[i].pos);
                commands.push_back("TEAMPACK " + to_string(i) + " " + to_string(p) + " " + to_string(50 - units[i].bricks));
                moved[i] = 1;
                moved[p] = 1;
                // cerr << "disconnect " << units[i].bridge_from << " " << units[i].pos << endl;
                connected[units[i].bridge_from][units[i].pos] = false;
                connected[units[i].pos][units[i].bridge_from] = false;
                units[i].bridge_from = units[p].bridge_from = -1;
                units[i].partner = units[p].partner = -1;
            } else {
                commands.push_back("PACK " + to_string(i) + " " + to_string(units[i].bridge_from));
                connected[units[i].bridge_from][units[i].pos] = false;
                connected[units[i].pos][units[i].bridge_from] = false;
                moved[i] = 1;
                units[i].bridge_from = -1;
            }
        }

        for (int i = 0; i < (int) commands.size(); ++i) {
            cout << commands[i];
            // cerr << commands[i];
            if (i < (int) commands.size() - 1) {
                cout << " | ";
                // cerr << " | ";
            }
        }
        cout << endl;
        // cerr << endl;
    }

    return 0;
}