#include <iostream>
#include <vector>
#include <string>
#include <sstream>
#include <numeric>
#include <algorithm>
#include <cassert>

enum class Action {
    UNPACK,
    TEAMUNPACK,
    MOVE, 
    PACK,
    TEAMPACK,
    MSG
};

constexpr const char* action_strings[] = 
{"UNPACK", "TEAMUNPACK", "MOVE", "PACK", "TEAMPACK", "MSG"};

inline std::ostream& operator<<(std::ostream& os, Action action) {
    return os << action_strings[static_cast<int>(action)];
}

// Stores full command info for all action types
struct Command {
    Action action;
    union {
        // Single actions: MOVE, UNPACK, PACK
        struct { int bridgeman_id; int island_id; } single;

        // Team actions: TEAMUNPACK, TEAMPACK
        struct { 
            int bridgeman_id1; int bridgeman_id2;
            int island_id; int length; // Only used for TEAMUNPACK
        } team;

        // Debug/Message action: MSG
        struct { char *msg; } dbg;
    } data;

    Command() = default;

    // Constructor for single actions: MOVE, UNPACK, PACK
    Command(Action act, int bridgeman_id, int island_id) : action(act) {
        data.single.bridgeman_id = bridgeman_id;
        data.single.island_id = island_id;
    }

    // Constructor for team actions: TEAMUNPACK, TEAMPACK
    Command(Action act, int bridgeman_id1, int bridgeman_id2, int island_id, int length = 0) : action(act) {
        data.team.bridgeman_id1 = bridgeman_id1;
        data.team.bridgeman_id2 = bridgeman_id2;
        data.team.island_id = island_id;
        data.team.length = length;
    }

    // Constructor for MSG
    Command(Action act, char* msg) : action(act) {
        data.dbg.msg = msg;
    }

    friend std::ostream& operator<<(std::ostream& os, const Command& cmd) {
        os << cmd.action;
        switch (cmd.action) {
            case Action::MOVE:
            case Action::UNPACK:
            case Action::PACK:
                os << " " << cmd.data.single.bridgeman_id << " " << cmd.data.single.island_id;
                break;
            case Action::TEAMUNPACK:
                os << " " << cmd.data.team.bridgeman_id1 << " " << cmd.data.team.bridgeman_id2
                   << " " << cmd.data.team.island_id << " " << cmd.data.team.length;
                break;
            case Action::TEAMPACK:
                os << " " << cmd.data.team.bridgeman_id1 << " " << cmd.data.team.bridgeman_id2
                   << " " << cmd.data.team.island_id;
                break;
            case Action::MSG:
                os << " " << cmd.data.dbg.msg;
                break;
        }
        return os;
    }
};


int N, B, O;
int **dists;
bool **connected;
int *destinations; // How many bridgemen are targeting each island
int **bridges_needed;
std::vector<Command> output;

class Order {
public:
    int from;
    int to;
};

std::vector<Order> orders;

class Bridgeman {
public:
    int ID;
    int position;
    int target;
    int bricks;
    int bridge_from = -1;
    int bridge_to = -1;

    // Checks if island is reachable
    // 0 - no, 1 - bridge can be built, 2 - already connected
    int is_island_reachable(const int island_id) const {
        if (connected[position][island_id]) return 2;
        if (dists[position][island_id] <= bricks) return 1;
        return 0;
    }

    // Assumes that the move is possible
    void move_to(const int island_id) {
        assert(bricks == 50);
        if (island_id == -1 || island_id == position) return;

        // If a bridge already exists, use it
        if (connected[position][island_id]) {
            position = island_id;
            output.push_back(Command(Action::MOVE, ID, island_id));
            return;
        }
        else {
            // Build the bridge
            output.push_back(Command(Action::UNPACK, ID, island_id));
            bridge_from = position;
            bridge_to = island_id;
            connected[bridge_from][bridge_to] = true;
            connected[bridge_to][bridge_from] = true;
        }
    }

    int choose_next_destination() {
        // Pick up a new order
        std::pair<int, int> best_order = {1e9, -1}; // {distance, island_id}
        auto best_it = orders.end();
        for (auto it = orders.begin(); it != orders.end(); ++it) {
            // Check self-reachability
            if (bridges_needed[position][it->from] == 1e9 
                || bridges_needed[it->from][it->to] == 1e9) {
                continue;
            }
            auto candidate = std::make_pair(bridges_needed[position][it->from], it->from);
            if (candidate < best_order) {
                best_order = candidate;
                best_it = it;
            }
        }
        if (best_it != orders.end()) {
            orders.erase(best_it);
        }
        return best_order.second;
    }

    int next_move() {
        if (target == -1 || target == position) {
            target = choose_next_destination();
        }
        if (target == -1 || target == position) {
            return -1;
        }
        // Choose the move that will minimize actions to reach target
        std::pair<int, int> best_move = {1e9, -1}; // {actions_needed, island_id}
        for (int i = 0; i < N; ++i) {
            if (connected[position][i] == true || dists[position][i] <= bricks) {
                int moves = (connected[position][i] ? 1 : 3);
                moves += bridges_needed[i][target] * 3;
                best_move = std::min(best_move, {moves, i});
            }
        }
        return best_move.second;
    }
};


static int g_seed = 777778;
static int Rand(int mod) {
    g_seed = (214013 * g_seed + 2531011);
    return ((g_seed >> 16) & 0x7FFF) % mod;
}

int** bridge_apsp(const int max_bridge_len) {
    int **hop = new int*[N];
    for (int i = 0; i < N; ++i) {
        hop[i] = new int[N];
        for (int j = 0; j < N; ++j) {
            if (i == j) hop[i][j] = 0;
            else if (dists[i][j] <= max_bridge_len) hop[i][j] = 1;
            else hop[i][j] = 1e9;
        }
    }
    for (int k = 0; k < N; ++k) {
        for (int i = 0; i < N; ++i) {
            for (int j = 0; j < N; ++j) {
                if (hop[i][j] > hop[i][k] + hop[k][j]) {
                    hop[i][j] = hop[i][k] + hop[k][j];
                }
            }
        }
    }
    return hop;
}

int main() {
    std::cin >> N >> B >> O;

    dists = new int*[N];
    connected = new bool*[N];
    bridges_needed = new int*[N];
    for (int i = 0; i < N; ++i) {
        dists[i] = new int[N];
        connected[i] = new bool[N];
        bridges_needed[i] = new int[N];
    }
    destinations = new int[N];
    std::fill(destinations, destinations + N, 0);

    for (int i = 0; i < N; ++i) {
        for (int j = 0; j < N; ++j) {
            connected[i][j]=false;
            std::cin >> dists[i][j];
        }
    }

    bridges_needed = bridge_apsp(50);

    Bridgeman bridgemen[B];
    for (int i = 0; i < B; ++i) {
        bridgemen[i].ID = i;
    }


    for (int turn = 1; turn <= 1000; turn++) {
        int elapsedTime;
        std::cin >> elapsedTime;
        for (int i = 0; i < B; ++i) {
            std::cin >> bridgemen[i].position >> bridgemen[i].bricks >> bridgemen[i].target;
        }
        // std::vector<Order> orders(O);
        orders.resize(O);
        for (int i = 0; i < O; ++i) {
            std::cin >> orders[i].from >> orders[i].to;
        }

        // Update destinations
        std::fill(destinations, destinations + N, 0);
        for (auto &b : bridgemen) {
            if (b.target != -1) {
                destinations[b.target]++;
            }
        }

        // Clear out orders that already have someone on the way to pick them up
        for (auto it = orders.begin(); it != orders.end(); ) {
            int cnt[N];
            std::copy(destinations, destinations + N, cnt);
            if (cnt[it->from] > 0) {
                it = orders.erase(it);
                cnt[it->from]--;
            } else {
                ++it;
            }
        }

        output.clear();

        // Give orders to bridgemen standing on islands
        for (auto it = orders.begin(); it != orders.end(); ) {
            bool assigned = false;
            for (auto &b : bridgemen) {
                if (b.position == it->from && b.target == -1) {
                    b.target = it->to;
                    std::cerr << "Order assigned\n";
                    assigned = true;
                    break;
                }
            }
            if (assigned) {
                it = orders.erase(it);
            } else {
                ++it;
            }
        }

        for (auto& b : bridgemen) {
            if (b.bridge_from == -1) { // unpack or move
                b.move_to(b.next_move());
                continue;

                // // If target is reachable, move there
                // if (b.target != -1 && b.is_island_reachable(b.target)) {
                //     std::cerr << "Target nearby\n";
                //     b.move_to(b.target);
                //     continue;
                // }

                // // If no order carried, take the first reachable order
                // if (b.target == -1) {
                //     bool has_order = false;
                //     for (auto it = orders.begin(); it != orders.end(); ++it) {
                //         if (b.is_island_reachable(it->from)) {
                //             b.move_to(it->from);
                //             b.target = it->to;
                //             orders.erase(it);
                //             has_order = true;
                //             std::cerr << "Move towards order\n";
                //             break;
                //         }
                //     }
                //     if (has_order) continue;
                // }

                // std::vector<int> targets;
                // for (int t = 0; t < N; ++t) {
                //     if (t != b.position && !connected[b.position][t] && dists[b.position][t] <= b.bricks) {
                //         targets.push_back(t);
                //     }
                // }
                // if (!targets.empty()) {
                //     int t = targets[Rand(targets.size())];
                //     output.push_back(Command(Action::UNPACK, b.ID, t));
                //     b.bridge_from = b.position;
                //     b.bridge_to = t;
                //     connected[b.bridge_from][b.bridge_to] = true;
                //     connected[b.bridge_to][b.bridge_from] = true;
                // }
            } else if (b.bridge_from == b.position) { // MOVE
                output.push_back(Command(Action::MOVE, b.ID, b.bridge_to));
            } else { // PACK
                output.push_back(Command(Action::PACK, b.ID, b.bridge_from));
            }
        }


        std::stable_sort(output.begin(), output.end(), [](const Command& a, const Command& b) {
            return static_cast<int>(a.action) < static_cast<int>(b.action);
        });

        auto pack_it = std::find_if(output.begin(), output.end(), [](const Command& cmd) {
            return cmd.action == Action::PACK;
        });

        // Update connectivity after all pack commands
        for (auto it = pack_it; it != output.end(); ++it) {
            auto b = &bridgemen[it->data.single.bridgeman_id];
            connected[b->bridge_from][b->bridge_to] = false;
            connected[b->bridge_to][b->bridge_from] = false;
            b->bridge_from = -1;
            b->bridge_to = -1;
        }

        for (size_t i = 0; i < output.size(); ++i) {
            std::cout << output[i];
            if (i < output.size() - 1) {
                std::cout << " | ";
            }
        }
        std::cout << std::endl;
    }

    delete [] destinations;
    for (int i = 0; i < N; ++i) {
        delete [] dists[i];
        delete [] connected[i];
        delete [] bridges_needed[i];
    }
    delete [] dists;
    delete [] connected;
    delete [] bridges_needed;

    return 0;
}