#include <iostream>
#include <vector>
#include <string>
#include <sstream>
#include <numeric>
#include <algorithm>
#include <utility>



class Bridgeman {
public:
    int ID;
    int Position;
    int Target;
    int Bricks;
    int BridgeFrom = -1;
    int BridgeTo = -1;
};

class Order {
public:
    int From;
    int To;
};

static int g_seed = 777778;
static int Rand(int mod) {
    g_seed = (214013 * g_seed + 2531011);
    return ((g_seed >> 16) & 0x7FFF) % mod;
}



int main() {
    int N, B, O;
    std::cin >> N >> B >> O;

    int dists[N][N];
    bool connected[N][N];

    for (int i = 0; i < N; ++i) {
        for (int j = 0; j < N; ++j) {
            connected[i][j]=false;
            std::cin >> dists[i][j];

        }
    }


    Bridgeman bridgemen[B];
    for (int i = 0; i < B; ++i) {
        bridgemen[i].ID = i;
    }

    for (int turn = 1; turn <= 1000; turn++) {
        int elapsedTime;
        std::cin >> elapsedTime;
        for (int i = 0; i < B; ++i) {
            std::cin >> bridgemen[i].Position >> bridgemen[i].Bricks >> bridgemen[i].Target;
        }
        std::vector<Order> orders(O);
        for (int i = 0; i < O; ++i) {
            std::cin >> orders[i].From >> orders[i].To;
            //std::cerr << "o:"<<orders[i].From << " " <<  orders[i].To  << std::endl;
        }
        int cpt =0;
        std::vector<std::string> output;
        for (auto& b : bridgemen) {
            if (b.BridgeFrom == -1) { // unpack
                //std::cerr << "----- " << b.ID << " -----" << std::endl;
                std::vector<int> targets;
                std::vector<int> moves;
                for (int t = 0; t < N; ++t) {
                    bool found = 0;

                    if (t != b.Position && !connected[b.Position][t] && dists[b.Position][t] <= b.Bricks ) {

                            targets.push_back(t);
                    }
                    if (t != b.Position && connected[b.Position][t] && dists[b.Position][t] <= b.Bricks ) {

                            moves.push_back(t);
                    }

                }
                if (!targets.empty()) {
                    bool found = 0;
                    int t =-1;
                    std::vector<std::pair<int,int>> evals;
                    
                    for (auto tar:targets){
                        
                        if (b.Target !=-1){
                            int distObj = dists[tar][b.Target];
                            if(distObj< dists[b.Target][b.Position]){
                                evals.push_back({tar,distObj});
                                found=1;}
                        }
                        else {
                            for (auto &o : orders)
                            {
                                if (tar == o.From)
                                {
                                    int distObj = dists[tar][b.Position];
                                    evals.push_back({tar, distObj * 3});
                                    found = 1;
                                }
                                else {
                                    int distObj = dists[tar][o.From];
                                    if(distObj< dists[b.Position][o.From]){
                                        evals.push_back({tar, distObj * 10});
                                        found = 1;
                                    }
                                }
                            }
                        }
                         
                    }
                    sort(evals.begin(),evals.end(),[](auto& a , auto& b){return a.second < b.second;});
                    // for (auto e: evals){
                    //     std::cerr << e.first << " " << e.second << std::endl; 
                    // }
                    if (found){
                        t = evals[0].first;
                    }
                    else {
                        cpt++;
                        t = targets[Rand(targets.size())];
                    }

                    output.push_back("UNPACK " + std::to_string(b.ID) + " " + std::to_string(t));
                    b.BridgeFrom = b.Position;
                    b.BridgeTo = t;
                    connected[b.BridgeFrom][b.BridgeTo] = true;
                    connected[b.BridgeTo][b.BridgeFrom] = true;
                }
                
            
            } else if (b.BridgeFrom == b.Position) { // MOVE
                output.push_back("MOVE " + std::to_string(b.ID) + " " + std::to_string(b.BridgeTo));
            } else { // PACK
                output.push_back("PACK " + std::to_string(b.ID) + " " + std::to_string(b.BridgeFrom));
                connected[b.BridgeFrom][b.BridgeTo] = false;
                connected[b.BridgeTo][b.BridgeFrom] = false;
                b.BridgeFrom = -1;
                b.BridgeTo = -1;
            }
        }

        for (size_t i = 0; i < output.size(); ++i) {
            std::cout << output[i];
            if (i < output.size() - 1) {
                std::cout << " | ";
            }
        }
        std::cout << std::endl;
        //std::cerr << cpt << std::endl;
    }

    return 0;
}