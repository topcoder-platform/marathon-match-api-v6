// Topcoder - Marathon Match 164 - BridgeRunners.
// Author: vdave, Hungary.

#define NOMINMAX
#define _CRT_SECURE_NO_WARNINGS

//#pragma GCC target "avx"

#include <algorithm>
#include <cstdio>
#include <cfloat>
#include <cstring>
#include <functional>
#include <iostream>
#include <map>
#include <random>
#include <set>
#include <sstream>
#include <string>
#include <utility>
#include <vector>
#include <unordered_map>
#include <unordered_set>

using namespace std;

#define TC_DEBUG

#ifdef TC_DEBUG
#define DEBUG(...) fprintf(fDebug, __VA_ARGS__)
#define GDEBUG(s, ...) { sprintf(sTmp, __VA_ARGS__); s.append(sTmp); }
#else
#define DEBUG(...)
#define GDEBUG(...)
#endif

// Platform specific stuff (timer, alignment, some intrinsics).

#ifdef _WIN32

// WIN32 platform definitions

#define ALIGN_SSE __declspec(align(64))
#define NOINLINE __declspec(noinline)

#include <ctime>
#include <intrin.h>
#include <windows.h>

typedef LARGE_INTEGER hp_timer_t;
LARGE_INTEGER gl_timer_freq;
double gl_timer_multiplier;

void InitTimer() {
	QueryPerformanceFrequency(&gl_timer_freq);
	gl_timer_multiplier = 1000000.0 / (double)gl_timer_freq.QuadPart;
}

void FetchTime(hp_timer_t* timer_value) {
	QueryPerformanceCounter(timer_value);
}

double GetElapsedMicros(hp_timer_t& timer_value_begin, hp_timer_t& timer_value_end) {
	return gl_timer_multiplier * (timer_value_end.QuadPart - timer_value_begin.QuadPart);
}

int __gcd(int a, int b) {
	if (b == 0) return a;
	return __gcd(b, a % b);
}

#else

// LINUX platform definitions

#define ALIGN_SSE __attribute__((aligned (64)))
#define NOINLINE
#define POPCOUNT(x) __builtin_popcount(x)

#include <sys/time.h>
#include <ctime>
#include <random>

typedef struct timeval hp_timer_t;

void InitTimer() {
}

void FetchTime(hp_timer_t* timer_value) {
	gettimeofday(timer_value, nullptr);
}

double GetElapsedMicros(hp_timer_t& timer_value_begin,
	hp_timer_t& timer_value_end) {
	return (timer_value_end.tv_sec * 1000000.0 + timer_value_end.tv_usec)
		- (timer_value_begin.tv_sec * 1000000.0 + timer_value_begin.tv_usec);
}

#endif

// Debug information for local runs.
bool dbgHasExtraInput;
int dbgSeed;
FILE* fDebug = stderr;
FILE* fTracking = nullptr;
char sTmp[65536];

// Global tweaking constants.
constexpr double kMaxRuntimeMicros = 9.6 * 1000.0 * 1000.0;
//constexpr int kDeltaX[4] = { 1, -1, 0, 0 };
//constexpr int kDeltaY[4] = { 0, 0, 1, -1 };

// Global randomness.
mt19937 randEngine;
std::uniform_real_distribution<double> randProb(0.0, 1.0);

// Time keeping.
hp_timer_t tBegin, tInit, tCurrent;
int currentRound, numIters;
int roundsPerTimeCheck = 1;
double estimatedProgress = 0.0;

// Problem-specific tweaking constants.
constexpr int kNumTurns = 1000;

// Input copied.
int N, B, O;
int D[128][128];

// The number of hops between two islands allowing hops of length up to 50. The value is
// -1 if the pair of islands are not reachable via max-50 bridges.
ALIGN_SSE char Dist50[128][128];
ALIGN_SSE char Dist50_Next[128][128];

// The number of components, the component assignments and the distance between components.
int numComp;
ALIGN_SSE char Comp50[128];
ALIGN_SSE char CompEdge[32][32];
ALIGN_SSE char DistComp[32][32];


// Cross-turn move and score tracking.
int moveCount;
int totalScore;

// Current connectivity.
bool C[128][128];

// Bridge material limits
constexpr int kDefaultMaterial = 50;
constexpr int kMaxMaterial = 60;
constexpr int kMaxBridge = 100;

// Bridgeman possible states.

// Bridgemen state.
struct BridgeMan {
	// Current position.
	short currentPos;
	// Target of the carried message, -1 if no message.
	short messageTarget;
	// Amount of bridge material carried.
	short cntMaterial;
	// The last constructed bridge, -1 if no outstanding bridges.
	short bridgeFrom, bridgeTo;
	// The target position of the bridgeman (via multiple hops).
	short targetPos;
	// The immediate intended next position for the bridgeman.
	short nextPos;
	// True if some action had already been made.
	bool madeAction;
	// If the bridgeman participates in some collaborative bridge building, reference to the details into sharedWork[].
	short sharedWorkIndex;
};
BridgeMan bmState[32];

// Planned collaborations to construct a bridge which crosses dist-50 components. The collaboration works as follows.
// 1) Person1 moves to targetPos1, simultaneously Person2 moves to targetPos2.
// 2) They construct a team bridge between the position.
// 3) They cross the bridge.
// 4) They pack the bridge materials to have 50 units each again.
// It may happen that once they are in the good position, the bridge already exists, then they can cross that and
// not pack it afterwards.
enum SharedBridgePhase {
	kMoveToPosition = 1,
	kBuildBridge = 2,
	kCrossNewBridge = 3,
	kCrossExistingBridge = 4,
	kDeconstructBridge = 5,
	kFinished = 6,
};
struct SharedBridge {
	short person1;
	short targetPos1;
	short person2;
	short targetPos2;
	SharedBridgePhase phase;
};
SharedBridge sharedWork[16];

// Available orders.
struct Order {
	int fromPos;
	int toPos;
};
Order nextOrders[16];
int orderByComp[16];

// BFS reachability execution.
int bfsR, bfsW;
ALIGN_SSE short bfsQueue[128];
ALIGN_SSE short bfsPrev[128];
ALIGN_SSE short bfsDist[128];
ALIGN_SSE char bfsVisited[128];


// Solver API.
class BridgeRunners {
public:
	void findSolution(int aN, int aB, int aO, const std::vector<std::vector<int>>& aD);
};


// Find the expected end time (compared to tBegin) on move 'moveCount'
double GetTargetEndMicros() {
	double moveFrac = 1.0 * (moveCount + 1) / kNumTurns;
	double initTime = GetElapsedMicros(tBegin, tInit);
	double nonInitTime = kMaxRuntimeMicros - initTime;
	double fracTime = moveFrac * nonInitTime;
	return initTime + fracTime;
}

// Display the test case summary to stderr for debugging.
void WriteSummary() {
	FetchTime(&tCurrent);
	DEBUG("Seed = %d, Score = %d\n", dbgSeed, totalScore);
	DEBUG("DATA_HEADER,Seed,N,B,O,Score,Runtime\n");
	DEBUG("DATA_EXPORT,%d,%d,%d,%d,%d,%.2lf\n", dbgSeed, N, B, O, totalScore, 0.001 * GetElapsedMicros(tBegin, tCurrent));
	fflush(fDebug);
}

// Runs a BFS on top of D[][] as the distance matrix from startIndex assuming at most maxDist distance between two consecutive islands.
void RunBFS(int startIndex, int maxDist, bool skipInit = false) {
	if (skipInit) {
		// Continue previous BFS run, skip initialization
	} else {
		for (int i = 0; i < N; ++i) {
			bfsVisited[i] = false;
		}
	}

	bfsR = 0;
	bfsW = 1;
	bfsQueue[0] = startIndex;
	bfsVisited[startIndex] = true;
	bfsPrev[startIndex] = -1;
	bfsDist[startIndex] = 0;
	while (bfsR < bfsW) {
		const int pos = bfsQueue[bfsR++];
		const int dist = bfsDist[pos];
		for (int j = 0; j < N; ++j) {
			if (bfsVisited[j]) continue;
			if (D[pos][j] > maxDist) continue;

			bfsVisited[j] = true;
			bfsQueue[bfsW++] = j;
			bfsPrev[j] = pos;
			bfsDist[j] = dist + 1;
		}
	}
}

// Run a BFS between components (numComp, CompEdge[][], DistComp[][]).
void RunCompBFS(int startIndex) {
	for (int i = 0; i < N; ++i) {
		bfsVisited[i] = false;
	}

	bfsR = 0;
	bfsW = 1;
	bfsQueue[0] = startIndex;
	bfsVisited[startIndex] = true;
	bfsPrev[startIndex] = -1;
	bfsDist[startIndex] = 0;
	while (bfsR < bfsW) {
		const int pos = bfsQueue[bfsR++];
		const int dist = bfsDist[pos];
		for (int j = 0; j < numComp; ++j) {
			if (bfsVisited[j]) continue;
			if (!CompEdge[pos][j]) continue;

			bfsVisited[j] = true;
			bfsQueue[bfsW++] = j;
			bfsPrev[j] = pos;
			bfsDist[j] = dist + 1;
		}
	}
}

// Count the number of connected components when only brides of length <= maxDist are allowed.
int CountComponents(int maxDist) {
	int cnt = 0;

	for (int i = 0; i < N; ++i) {
		bfsVisited[i] = false;
		if (maxDist == kDefaultMaterial) {
			Comp50[i] = -1;
		}
	}

	for (int i = 0; i < N; ++i) {
		if (!bfsVisited[i]) {
			RunBFS(i, maxDist, /*skipInit=*/ true);
			if (maxDist == kDefaultMaterial) {
				for (int j = 0; j < N; ++j) {
					if (bfsVisited[j] && Comp50[j] < 0) {
						Comp50[j] = cnt;
					}
				}
			}
			cnt++;
		}
	}

	if (maxDist == kDefaultMaterial) {
		numComp = cnt;
	}

	return cnt;
}

// Calculates the reachability between islands using only bridges with length <= 50.
void CalculateDist50() {
	int maxHops = 0;
	int sumHops = 0, numReachablePairs = 0;

	for (int i = 0; i < N; ++i) {
		for (int j = 0; j < N; ++j) {
			Dist50[i][j] = -1;
		}

		RunBFS(i, /*maxDist=*/ kDefaultMaterial);
		for (int j = 0; j < N; ++j) {
			if (bfsVisited[j]) {
				Dist50[i][j] = bfsDist[j];
				Dist50_Next[j][i] = bfsPrev[j];
				if (i != j) {
					maxHops = std::max(maxHops, (int) Dist50[i][j]);
					sumHops += Dist50[i][j];
					numReachablePairs++;
				}
			}
		}
	}

	DEBUG("Maximum hops: %d, Average hops: %.2lf\n", maxHops, 1.0 * sumHops / numReachablePairs);
}

// Calculate the long-bridge distances between components.
void CalculateDistComp() {
	for (int i = 0; i < numComp; ++i) {
		for (int j = 0; j < numComp; ++j) {
			CompEdge[i][j] = 0;
		}
	}

	for (int i = 0; i < N; ++i) {
		for (int j = 0; j < N; ++j) {
			const int ci = Comp50[i];
			const int cj = Comp50[j];
			if (ci == cj) continue;

			const int dist = D[i][j];
			if (dist > kMaxBridge) continue;

			// (i, j) is a feasible bridge between components #ci and #cj.
			CompEdge[ci][cj] = 1;
		}
	}

	for (int i = 0; i < numComp; ++i) {
		RunCompBFS(i);
		for (int j = 0; j < numComp; ++j) {
			DistComp[i][j] = bfsVisited[j] ? bfsDist[j] : -1;
		}
	}
}

// Reads the current state from the tester.
bool GetCurrentState() {
	int64_t unused_runtime;
	cin >> unused_runtime;

	for (int b = 0; b < B; ++b) {
		int bPos, bCarry, bMessage;
		cin >> bPos >> bCarry >> bMessage;

		if (bmState[b].currentPos != -1) {
			if (bmState[b].currentPos != bPos) {
				DEBUG("!!!ERROR!!! [R=%d] Incorrect position for man %d: %d vs %d\n", moveCount, b, bPos, bmState[b].currentPos);
			}
			if (bmState[b].cntMaterial != bCarry) {
				DEBUG("!!!ERROR!!! [R=%d] Incorrect material count for man %d: %d vs %d\n", moveCount, b, bCarry, bmState[b].cntMaterial);
			}
			if (bmState[b].messageTarget != -1 && bmState[b].messageTarget != bMessage) {
				DEBUG("!!!ERROR!!! [R=%d] Incorrect message target for man %d: %d vs %d\n", moveCount, b, bMessage, bmState[b].messageTarget);
			}
		}
		bmState[b].currentPos = bPos;
		bmState[b].cntMaterial = bCarry;
		bmState[b].messageTarget = bMessage;
		//DEBUG("[R=%d] Bridgeman #%d: at %d, carrying %d, message for %d\n", moveCount, b, bPos, bCarry, bMessage);
	}

	for (int i = 0; i < numComp; ++i) {
		orderByComp[i] = 0;
	}
	for (int o = 0; o < O; ++o) {
		cin >> nextOrders[o].fromPos >> nextOrders[o].toPos;
		orderByComp[(int) Comp50[(int) nextOrders[o].fromPos]]++;
	}

	return true;
}

// Out of 10,000 seeds 6,671 are 1-connected with bridges <= 50, 8,644 are 1-connected with bridges <= 60.

// * Can we have a fully connected set of islands and then just move without deconstructing bridges
//   * Maybe only for some core subset of islands in the middle?
// * Allow multiple pending bridges and only pack when needed for the destination.
// * Allow long bridges between existing components if benefits both sides
// * Plan ahead, try different order of bridgeman, or if a new bridge can be constructed to multiple destination, try to optimize.
// * Allow two pending bridges if picking up order, which will be delivered backwards.
// * Wait with PACKING the bridge one extra round if someone would use it.

// Calculates the next move for each bridgeman.
//
// 1) Bridgeman who have a message targeting the same component will move towards it.
// 2) Bridgeman who don't have a message are assigned an order or a pair.
// 3) Bridgeman who have a message targeting a different component are assigned some pair to cross components.
void CalculateNextMoves() {
	// Possible pairings.
	// Bridgeman with message - Bridgeman with message.
	// Bridgeman empty - Order in same component.
	// Bridgeman empty - Bridgeman with message on different component.
	// Bridgeman empty - Bridgeman with message on different component + Order in that component.

	// Clean up finished collaborations.
	for (int i = 0; i < 16; ++i) {
		auto& sw = sharedWork[i];
		if (sw.person1 < 0 || sw.person2 < 0) continue;
		auto& bm1 = bmState[sw.person1];
		auto& bm2 = bmState[sw.person2];
		if (bm1.sharedWorkIndex != i || bm2.sharedWorkIndex != i) {
			DEBUG("!!!ERROR!!! Inconsistent shared work # %d: %d (%d) + %d (%d)\n", i, sw.person1, bm1.sharedWorkIndex, sw.person2, bm1.sharedWorkIndex);
		}

		if (sw.phase == SharedBridgePhase::kFinished) {
			if (bm1.cntMaterial != kDefaultMaterial || bm2.cntMaterial != kDefaultMaterial || bm1.currentPos != sw.targetPos2 || bm2.currentPos != sw.targetPos1) {
				DEBUG("!!!ERROR!!! [R=%d] Shared Work Finished in inconsistent state (%d => %d now at %d @ %d, %d => %d now at %d @ %d)\n", moveCount,
						sw.person1, sw.targetPos2, bm1.currentPos, bm1.cntMaterial, sw.person2, sw.targetPos1, bm2.currentPos, bm2.cntMaterial);
			}

			bm1.sharedWorkIndex = -1;
			bm1.targetPos = -1;
			bm2.sharedWorkIndex = -1;
			bm2.targetPos = -1;
			sw.person1 = -1;
			sw.person2 = -1;
		}
	}

	// Assign a target position for each bridgeman in their own component.
	std::vector<int> bAssignable;
	for (int b = 0; b < B; ++b) {
		auto& bm = bmState[b];
		const int pos = bm.currentPos;
		const int comp = Comp50[pos];

		// If a bridgeman is already part of collaboration, do not change that.
		if (bm.sharedWorkIndex >= 0) continue;

		if (bm.messageTarget >= 0 && Comp50[bm.messageTarget] == comp) {
			bm.targetPos = bm.messageTarget;
		} else {
			bm.targetPos = bm.currentPos;
			bAssignable.push_back(b);
		}
	}

	struct PairData {
		int person1;
		int person2;
		int bridge1;
		int bridge2;
		int orderIndex;

		bool operator<(const PairData& other) const { return person1 < other.person1; }
	};
	std::vector<std::pair<int, PairData>> pairScores;
	for (int b : bAssignable) {
		auto& bm = bmState[b];
		const int pos = bm.currentPos;
		const int comp = Comp50[pos];

		if (bm.messageTarget >= 0) {
			// Bridgeman has a message for a different component, find possible pairings.
			const int compMsg = Comp50[bm.messageTarget];
			for (int bOther : bAssignable) {
				auto& bmOther = bmState[bOther];
				const int posOther = bmOther.currentPos;
				const int compOther = Comp50[posOther];

				// Don't pair bridgemen on same component or on too far away components (no direct long bridge possible).
				if (comp == compOther) continue;
				if (!CompEdge[comp][compOther]) continue;
				// If the first of the pair does not get closer to their message destination, don't consider pairing.
				if (DistComp[compOther][compMsg] >= DistComp[comp][compMsg]) continue;

				if (bmOther.messageTarget >= 0) {
					// Both have a message intended for a different component compared to their positions.
					const int compMsgOther = Comp50[bmOther.messageTarget];
					// If the second of the pair gets worse, don't consider pairing.
					if (DistComp[comp][compMsgOther] > DistComp[compOther][compMsgOther]) continue;

					// Find a suitable long bridge between the two components, find best score.
					int bridgePos1 = -1, bridgePos2 = -1, minScore = 999999;
					for (int pos1 = 0; pos1 < N; ++pos1) {
						if (Comp50[pos1] != comp) continue;
						for (int pos2 = 0; pos2 < N; ++pos2) {
							if (Comp50[pos2] != compOther) continue;
							if (D[pos1][pos2] > kMaxBridge) continue;

							const int maxDist = std::max(Dist50[pos][pos1], Dist50[posOther][pos2]);
							// TODO: Do more complex score calculation.
							int score = maxDist - (DistComp[comp][compMsgOther] < DistComp[compOther][compMsgOther] ? 10 : 0);
							if (score < minScore) {
								bridgePos1 = pos1;
								bridgePos2 = pos2;
								minScore = score;
							}
						}
					}

					if (bridgePos1 >= 0) {
						pairScores.push_back({minScore, PairData { .person1 = b, .person2 = bOther, .bridge1 = bridgePos1, .bridge2 = bridgePos2, .orderIndex = -1}});
					}
				} else {
					// Second person does not have a message, score depends on whether there is an order on the target component.
					// Find a suitable long bridge between the two components, find best score.
					int bridgePos1 = -1, bridgePos2 = -1, minScore = 999999;
					for (int pos1 = 0; pos1 < N; ++pos1) {
						if (Comp50[pos1] != comp) continue;
						for (int pos2 = 0; pos2 < N; ++pos2) {
							if (Comp50[pos2] != compOther) continue;
							if (D[pos1][pos2] > kMaxBridge) continue;

							const int maxDist = std::max(Dist50[pos][pos1], Dist50[posOther][pos2]);
							// TODO: Do more complex score calculation.
							int score = maxDist + (orderByComp[compOther] > 0 ? 5 : 0) - (orderByComp[comp] > 0 ? 5 : 0);
							if (score < minScore) {
								bridgePos1 = pos1;
								bridgePos2 = pos2;
								minScore = score;
							}
						}
					}

					if (bridgePos1 >= 0) {
						pairScores.push_back({minScore, PairData { .person1 = b, .person2 = bOther, .bridge1 = bridgePos1, .bridge2 = bridgePos2, .orderIndex = -1}});
					}
				}
			}
		} else {
			// Bridgeman has no message, find a suitable order on the same component.
			for (int oIndex = 0; oIndex < O; ++oIndex) {
				const auto& order = nextOrders[oIndex];
				const int fromComp = Comp50[order.fromPos];
				const int toComp = Comp50[order.toPos];

				if (fromComp != comp) continue;

				const int pickupDist = Dist50[bm.currentPos][order.fromPos];
				const int deliveryDist = fromComp == toComp ? Dist50[fromComp][toComp] : 15;
				pairScores.push_back({pickupDist + deliveryDist, PairData { .person1 = b, .person2 = -1, .orderIndex = oIndex}});
			}
		}
	}

	// Create the assignments (bridgeman pairs and bridgemen - order assignments).
	std::sort(pairScores.begin(), pairScores.end());
	uint32_t bmCovered = 0;
	uint32_t oCovered = 0;
	for (const auto& [score, data] : pairScores) {
		if (bmCovered & (1u << data.person1)) continue;
		if (data.person2 >= 0 && (bmCovered & (1u << data.person2))) continue;
		if (data.orderIndex >= 0 && (oCovered & (1u << data.orderIndex))) continue;

		bmCovered |= (1u << data.person1);
		if (data.person2 >= 0) bmCovered |= (1u << data.person2);
		if (data.orderIndex >=0) oCovered |= (1u << data.orderIndex);

		//DEBUG("[R=%d] Pairing (%d, %c %d) with (%d -> %d: %d): %d\n", moveCount, data.person1, data.person2 < 0 ? 'O' : 'P', data.person2 < 0 ? data.orderIndex : data.person2,
		//		data.bridge1, data.bridge2, D[data.bridge1][data.bridge2], score);

		auto& bm = bmState[data.person1];
		if (data.person2 >= 0) {
			auto& bmOther = bmState[data.person2];

			// Create a collaboration between two bridgeman to switch components.
			int workIndex = 0;
			while (sharedWork[workIndex].person1 >= 0) workIndex++;
			sharedWork[workIndex].person1 = data.person1;
			sharedWork[workIndex].person2 = data.person2;
			sharedWork[workIndex].targetPos1 = data.bridge1;
			sharedWork[workIndex].targetPos2 = data.bridge2;
			sharedWork[workIndex].phase = SharedBridgePhase::kMoveToPosition;
			bm.sharedWorkIndex = workIndex;
			bm.targetPos = data.bridge1;
			bmOther.sharedWorkIndex = workIndex;
			bmOther.targetPos = data.bridge2;
		} else if (data.orderIndex >= 0) {
			// Just assign an order to some empty bridgeman.
			bm.targetPos = nextOrders[data.orderIndex].fromPos;
		}
	}

	// Update collaboration state, if both people arrived to the correct location and packed their last bridge.
	for (int i = 0; i < 16; ++i) {
		auto& sw = sharedWork[i];
		if (sw.person1 < 0 || sw.person2 < 0) continue;
		auto& bm1 = bmState[sw.person1];
		auto& bm2 = bmState[sw.person2];
		if (bm1.sharedWorkIndex != i || bm2.sharedWorkIndex != i) {
			DEBUG("!!!ERROR!!! Inconsistent shared work # %d: %d (%d) + %d (%d)\n", i, sw.person1, bm1.sharedWorkIndex, sw.person2, bm1.sharedWorkIndex);
		}

		if (bm1.currentPos == sw.targetPos1 && bm2.currentPos == sw.targetPos2 && sw.phase == SharedBridgePhase::kMoveToPosition &&
				bm1.cntMaterial == kDefaultMaterial && bm2.cntMaterial == kDefaultMaterial)  {
			// They are on the correct endpoints, construct or cross the bridge.
			sw.phase = SharedBridgePhase::kBuildBridge;
		}
	}

	//DEBUG("[R=%d] TargetPos:", moveCount);
	//for (int b = 0; b < B; ++b) {
	//	DEBUG(" (%d: %d => %d)", b, bmState[b].currentPos, bmState[b].targetPos);
	//}
	//DEBUG("\n");
}

// Sends the actions for each of the bridgemen. In each round the order of actions are the following.
// 1) Construct new team bridges.
// 2) Construct new individual bridges.
// 3) Move people through existing bridges.
// 4) Pack individual bridges.
// 5) Pack team bridges.
bool SendMoves() {
	std::stringstream action;

	for (int b = 0; b < B; ++b) {
		bmState[b].madeAction = false;
	}

	// Construct long bridges (collaboration of two bridgemen).
	for (int i = 0; i < 16; ++i) {
		auto& sw = sharedWork[i];
		if (sw.person1 < 0 || sw.person2 < 0) continue;
		auto& bm1 = bmState[sw.person1];
		auto& bm2 = bmState[sw.person2];
		if (bm1.sharedWorkIndex != i || bm2.sharedWorkIndex != i) {
			DEBUG("!!!ERROR!!! Inconsistent shared work # %d: %d (%d) + %d (%d)\n", i, sw.person1, bm1.sharedWorkIndex, sw.person2, bm1.sharedWorkIndex);
		}

		if (sw.phase == SharedBridgePhase::kBuildBridge) {
			if (C[sw.targetPos1][sw.targetPos2]) {
				sw.phase = SharedBridgePhase::kCrossExistingBridge;
			} else {
				const int longD = D[sw.targetPos1][sw.targetPos2];
				action << "TEAMUNPACK " << sw.person1 << " " << sw.person2 << " " << longD / 2 << "|";
				C[sw.targetPos1][sw.targetPos2] = true;
				C[sw.targetPos2][sw.targetPos1] = true;
				bm1.madeAction = true;
				bm2.madeAction = true;
				bm1.cntMaterial -= longD / 2;
				bm2.cntMaterial -= longD - (longD / 2);
				sw.phase = SharedBridgePhase::kCrossNewBridge;
			}
		}
	}

	// For non-collaborative bridgeman, if they have an outstanding bridge, they may cross it or pack it. If they
	// don't have an outstanding bridge, they may cross an existing bridge or unpack a new bridge.
	for (int b = 0; b < B; ++b) {
		auto& bm = bmState[b];

		// Do not construct new bridges if not all material is there
		if (bm.cntMaterial != kDefaultMaterial) continue;
		if (bm.sharedWorkIndex >= 0 && sharedWork[bm.sharedWorkIndex].phase != SharedBridgePhase::kMoveToPosition) continue;

		// If already at the target, don't construct bridges.
		const int distToTarget = Dist50[bm.currentPos][bm.targetPos];
		if (distToTarget == 0) continue;

		// If there is an existing bridge, which takes closer to the target, take it.
		bool isGoodExistingBridge = false;
		for (int n = 0; n < N; ++n) {
			if (C[bm.currentPos][n] && Comp50[bm.currentPos] == Comp50[n] && Dist50[n][bm.targetPos] < Dist50[bm.currentPos][bm.targetPos]) {
				isGoodExistingBridge = true;
				break;
			}
		}
		if (isGoodExistingBridge) continue;

		// Construct a bridge to some arbitrary island, which gets closer to the target.
		const int from = bmState[b].currentPos;
		const int to = Dist50_Next[from][bm.targetPos];
		if (C[from][to]) {
			DEBUG("!!!ERROR!!! [R=%d] Bridgeman #%d tries to construct a bridge which already exists: (%d, %d) = %d > %d\n", moveCount, b, from, to, D[from][to], bmState[b].cntMaterial);
		} else if (D[from][to] > bmState[b].cntMaterial) {
				DEBUG("!!!ERROR!!! [R=%d] Bridgeman #%d tries to construct longer bridge than material: (%d, %d) = %d > %d\n", moveCount, b, from, to, D[from][to], bmState[b].cntMaterial);
		} else {
			action << "UNPACK " << b << " " << to << "|";
			bmState[b].madeAction = true;

			bmState[b].cntMaterial -= D[from][to];
			bmState[b].bridgeFrom = from;
			bmState[b].bridgeTo = to;
			C[from][to] = true;
			C[to][from] = true;
		}
	}

	// Cross bridges (both short and long).
	for (int b = 0; b < B; ++b) {
		auto& bm = bmState[b];
		if (bm.madeAction) continue;

		int crossTo = -1;
		if (bm.sharedWorkIndex >= 0 && sharedWork[bm.sharedWorkIndex].phase != SharedBridgePhase::kMoveToPosition) {
			// Cross, if it's the crossing phase.
			auto& sw = sharedWork[bm.sharedWorkIndex];
			if (sw.phase == SharedBridgePhase::kCrossExistingBridge || sw.phase == SharedBridgePhase::kCrossNewBridge) {
				crossTo = bm.currentPos == sw.targetPos1 ? sw.targetPos2 : sw.targetPos1;
			}
		} else if (bm.bridgeFrom >= 0) {
			// May only cross his own bridge, if it gets closer to the target.
			int optTo = bm.currentPos == bm.bridgeFrom ? bm.bridgeTo : bm.bridgeFrom;
			if (Dist50[optTo][bm.targetPos] < Dist50[bm.currentPos][bm.targetPos]) {
				// Cross its own bridge.
				crossTo = optTo;
			} else {
				// Do not cross its own bridge, will pack it later in this round.
			}
		} else {
			for (int n = 0; n < N; ++n) {
				if (C[bm.currentPos][n] && Comp50[bm.currentPos] == Comp50[n] && Dist50[n][bm.targetPos] < Dist50[bm.currentPos][bm.targetPos]) {
					crossTo = n;
					break;
				}
			}
		}

		if (crossTo >= 0) {
			// Bridgeman #b should move from currentPos to crossTo on some existing bridge.
			const int from = bmState[b].currentPos;
			if (C[from][crossTo]) {
				// Bridge already exists, traverse it.
				action << "MOVE " << b << " " << crossTo << "|";
				bmState[b].madeAction = true;

				bmState[b].currentPos = crossTo;
				bmState[b].nextPos = -1;

				// Possibly deliver a message.
				if (bmState[b].messageTarget == crossTo) {
					totalScore++;
					bmState[b].messageTarget = -1;
				}

				// Possibly pick up the next order.
				if (bmState[b].messageTarget == -1) {
					for (int o = 0; o < O; ++o) {
						if (nextOrders[o].fromPos == crossTo) {
							bmState[b].messageTarget = nextOrders[o].toPos;
							nextOrders[o].fromPos = -1;
							break;
						}
					}
				}
			} else {
				DEBUG("!!!ERROR!!! [R=%d] Bridgeman #%d tries to cross a bridge which does not exist: (%d, %d) = %d > %d\n", moveCount, b, from, crossTo, D[from][crossTo], bmState[b].cntMaterial);
			}
		}
	}

	// Pack short bridges, that can also happen if the
	for (int b = 0; b < B; ++b) {
		if (bmState[b].bridgeFrom < 0 || bmState[b].madeAction) continue;
		if (bmState[b].sharedWorkIndex >= 0 && sharedWork[bmState[b].sharedWorkIndex].phase != SharedBridgePhase::kMoveToPosition) continue;

		const int from = bmState[b].bridgeFrom == bmState[b].currentPos ? bmState[b].bridgeTo : bmState[b].bridgeFrom;
		const int to = bmState[b].currentPos;

		if (!C[from][to]) {
			DEBUG("!!!ERROR!!! [R=%d] Bridgeman #%d tries to deconstruct non-existent bridge: (%d, %d) = %d > %d\n", moveCount, b, from, to, D[from][to], bmState[b].cntMaterial);
		} else if (bmState[b].cntMaterial + D[from][to] > kMaxMaterial) {
			DEBUG("!!!ERROR!!! [R=%d] Bridgeman #%d tries to deconstruct too long bridge: (%d, %d) = %d + %d = %d\n", moveCount, b, from, to, D[from][to], bmState[b].cntMaterial, D[from][to] + bmState[b].cntMaterial);
		} else {
			if (bmState[b].currentPos == bmState[b].bridgeFrom) {
				DEBUG("[R=%d] Interesting PACK for %d\n", moveCount, b);
			}
			action << "PACK " << b << " " << from << "|";
			bmState[b].madeAction = true;

			bmState[b].cntMaterial += D[from][to];
			bmState[b].bridgeFrom = -1;
			bmState[b].bridgeTo = -1;
			C[from][to] = false;
			C[to][from] = false;
		}
	}

	// Pack long bridges (collaboration of two bridgemen).
	for (int i = 0; i < 16; ++i) {
		auto& sw = sharedWork[i];
		if (sw.person1 < 0 || sw.person2 < 0) continue;
		auto& bm1 = bmState[sw.person1];
		auto& bm2 = bmState[sw.person2];
		if (bm1.sharedWorkIndex != i || bm2.sharedWorkIndex != i) {
			DEBUG("!!!ERROR!!! Inconsistent shared work # %d: %d (%d) + %d (%d)\n", i, sw.person1, bm1.sharedWorkIndex, sw.person2, bm1.sharedWorkIndex);
		}

		if (sw.phase == SharedBridgePhase::kDeconstructBridge) {
			// They crossed the bridge already, need to team-pack it next.
			const int longD = D[sw.targetPos1][sw.targetPos2];
			action << "TEAMPACK " << sw.person1 << " " << sw.person2 << " " << longD / 2 << "|";
			bm1.cntMaterial += longD / 2;
			bm2.cntMaterial += longD - (longD / 2);
			C[sw.targetPos1][sw.targetPos2] = false;
			C[sw.targetPos2][sw.targetPos1] = false;
			sw.phase = SharedBridgePhase::kFinished;
		}
	}

	// Update collaboration state, if both people arrived to the correct target location (after crossing the bridge).
	for (int i = 0; i < 16; ++i) {
		auto& sw = sharedWork[i];
		if (sw.person1 < 0 || sw.person2 < 0) continue;
		auto& bm1 = bmState[sw.person1];
		auto& bm2 = bmState[sw.person2];
		if (bm1.sharedWorkIndex != i || bm2.sharedWorkIndex != i) {
			DEBUG("!!!ERROR!!! Inconsistent shared work # %d: %d (%d) + %d (%d)\n", i, sw.person1, bm1.sharedWorkIndex, sw.person2, bm1.sharedWorkIndex);
		}

		if (bm1.currentPos == sw.targetPos2 && bm2.currentPos == sw.targetPos1 && (sw.phase == SharedBridgePhase::kCrossNewBridge || sw.phase == SharedBridgePhase::kCrossExistingBridge)) {
			if (sw.phase == SharedBridgePhase::kCrossExistingBridge) {
				sw.phase = SharedBridgePhase::kFinished;
			} else {
				sw.phase = SharedBridgePhase::kDeconstructBridge;
			}
		}
	}


	std::string actionStr = action.str();
	cout << actionStr << endl;

	DEBUG("[R=%d]: %s\n", moveCount, actionStr.c_str());

	moveCount++;
	return true;
}

// MAIN SOLVER BEGINS HERE.

void BridgeRunners::findSolution(int aN, int aB, int aO, const std::vector<std::vector<int>>& aD) {
	// Initialize timing, randomness.
	InitTimer();
	FetchTime(&tBegin);
	randEngine.seed(0xdeadbeef);

	// Save input.
	N = aN;
	B = aB;
	O = aO;
	int minDist = 999999, maxDist = 0;
	for (int i = 0; i < N; ++i) {
		for (int j = 0; j < N; ++j) {
			D[i][j] = aD[i][j];
			C[i][j] = (i == j);
			if (i == j && D[i][i] != 0) {
				DEBUG("!!!ERROR!!! Distance (%d, %d) is not zero: %d\n", i, i, D[i][i]);
			}
			if (j < 0 && D[i][j] != D[j][i]) {
				DEBUG("!!!ERROR!!! Distance (%d, %d) inconsistent: %d, %d\n", i, j, D[i][j], D[j][i]);
			}
			if (i != j) {
				minDist = std::min(minDist, D[i][j]);
				maxDist = std::max(maxDist, D[i][j]);
			}
		}
	}
	DEBUG("Distances: [%d .. %d]\n", minDist, maxDist);

	// Calculate which of the bridge size (50, 60 or 100) is needed to make a single connected component.
	const bool cover50 = CountComponents(50) == 1;
	const bool cover60 = CountComponents(60) == 1;
	DEBUG("Bridge length for full coverage: %d\n", cover50 ? 50 : cover60 ? 60 : 100);

	// Calculate the components with distance <= 50.
	CalculateDist50();
	CalculateDistComp();

	for (int ci = 0; ci < numComp; ++ci) {
		for (int cj = 0; cj < numComp; ++cj) {
			DEBUG("Dist[Comp %d, Comp %d] = %d\n", ci, cj, DistComp[ci][cj]);
		}
	}

	for (int b = 0; b < B; ++b) {
		bmState[b].currentPos = -1;
		bmState[b].targetPos = -1;
		bmState[b].nextPos = -1;
		bmState[b].bridgeFrom = -1;
		bmState[b].sharedWorkIndex = -1;
	}

	for (int i = 0; i < 16; ++i) {
		sharedWork[i].person1 = -1;
		sharedWork[i].person2 = -1;
	}

	// Initialize current state.
	moveCount = 0;
	totalScore = 0;

	FetchTime(&tInit);
	DEBUG("Initialization time: %.3lf us.\n", GetElapsedMicros(tBegin, tInit));

	// SOLVE PROBLEM.
	while (moveCount < kNumTurns) {
		//DEBUG("======== TURN %d ==========\n", moveCount);

		// Reads the state of the archipelago from the tester.
		if (!GetCurrentState()) break;

		CalculateNextMoves();

		// Sends the decided series of actions to the tester.
		if (!SendMoves()) break;
	}

	WriteSummary();
}

// Tester wrapper.
int main(int argc, const char* argv[]) {
	dbgHasExtraInput = false;

#ifdef TC_DEBUG
	for (int i = 1; i < argc; ++i) {
		if (!strncmp(argv[i], "-s=", 3)) {
			dbgSeed = atoi(argv[i] + 3);
		}
		else if (!strncmp(argv[i], "-o=", 3)) {
			fDebug = fopen(argv[i] + 3, "wt");
		}
		else if (!strncmp(argv[i], "-t=", 3)) {
			fTracking = fopen(argv[i] + 3, "wt");
		}
		else if (!strncmp(argv[i], "-d", 2)) {
			dbgHasExtraInput = true;
		}
	}
	fprintf(fDebug, "=========== SEED: %d ===========\n", dbgSeed);
#endif

	int genN, genB, genO;
	cin >> genN >> genB >> genO;

	std::vector<std::vector<int>> genD;
	for (int i = 0; i < genN; ++i) {
		std::vector<int> dRow;
		for (int j = 0; j < genN; ++j) {
			int d;
			cin >> d;
			dRow.push_back(d);
		}
		genD.push_back(std::move(dRow));
	}

	BridgeRunners solver;
	solver.findSolution(genN, genB, genO, genD);

	if (fDebug != stderr) {
		fflush(fDebug);
		fclose(fDebug);
	}

	if (fTracking != nullptr) {
		fflush(fTracking);
		fclose(fTracking);
	}

	return 0;
}
