#include <bits/stdc++.h>


using namespace std;


const int N_TURNS = 1000;
const int BRICKS_ONE = 50;
const int BRICKS_TWO = 100;
const int INF = 1 << 28;


struct Bridgeman {
    int id, pos, target, bricks, waiting = 0, uBridge = -1, vBridge = -1;
    vector <tuple<int,int,int,int>> path;
};

struct Order {
    int source, target;
};


int nIslands, nBridgemen, nOrders, nComps, elapsedTime;

vector <vector<int>> dist, connected[N_TURNS], used[N_TURNS];
vector <vector<set<int>>> whenConnected;
vector <Bridgeman> bridgemen;
vector <Order> orders;

vector <int> comp;
vector <vector<int>> compDist;

vector <pair<int,int>> plansTeamUnpack[N_TURNS], plansCompMove[N_TURNS], plansTeamPack[N_TURNS];
vector <int> plansStopWaiting[N_TURNS];
set <pair<int,int>> futureCompBridges;

const int UNPACK = 0;
const int MOVE = 1;
const int PACK = 2;

vector <tuple<int,int,int,int>> bfs(int id, int tStart, int target) {
    int source = bridgemen[id].pos, bu = bridgemen[id].uBridge, bv = bridgemen[id].vBridge;

    assert(tStart < N_TURNS);

    if (minmax(bu, bv) == minmax(source, target)) {
        vector <tuple<int,int,int,int>> path = {
            {source, target, tStart + 1, PACK},
            {source, target, tStart, MOVE}
        };

        for (int t = tStart; t <= tStart + 1; t++) {
            if (connected[t][bu][bv]) {
                return {};
            }
        }

        if (tStart < N_TURNS - 1) {
            return path;
        } else {
            return {};
        }
    }

    vector <int> from(nIslands, -1), minTime(nIslands, N_TURNS);
    minTime[source] = tStart;

    priority_queue <pair<int,int>> q;
    q.push({-tStart, -source});

    while (!q.empty()) {
        auto [t, v] = q.top(); t *= -1; v *= -1;
        q.pop();

        assert(t < N_TURNS);

        if (t > minTime[v]) {
            continue;
        }

        if (v == target) {
            vector <tuple<int,int,int,int>> path;

            while (v != source) {
                bool build = !connected[minTime[v] - 1][from[v]][v] && minmax(bu, bv) != minmax(v, from[v]);

                if (build) {
                    path.push_back({from[v], v, minTime[v] - 1, PACK});
                }

                path.push_back({from[v], v, minTime[v] - build - 1, MOVE});

                if (build) {
                    path.push_back({from[v], v, minTime[v] - 3, UNPACK});
                }

                if ((bu == from[v] || bv == from[v]) && bu != v && bv != v) {
                    int tp = get<2>(path.back()) - 1;
                    path.push_back({bu, bv, tp, PACK});

                    for (int t = tStart; t <= tp; t++) {
                        if (connected[t][bu][bv]) {
                            return {};
                        }
                    }
                }

                v = from[v];
            }

            return path;
        }

        for (int u = 0; u < nIslands; u++) {
            int tm = t;
            if ((bu == v || bv == v) && bu != u && bv != u) {
                tm++;
            }

            if (tm == N_TURNS) {
                continue;
            }

            int d;
            if (connected[tm][v][u] || minmax(bu, bv) == minmax(u, v)) {
                d = 1;
            } else if (tm < N_TURNS - 1 && connected[tm + 1][v][u]) {
                d = 2;
            } else if (dist[v][u] <= BRICKS_ONE) {
                d = 3;
            } else {
                auto it = whenConnected[u][v].lower_bound(t + 2);
                if (it == whenConnected[u][v].end()) {
                    continue;
                }

                d = *it - tm + 1;
            }

            int tNew = tm + d;
            if (tNew < minTime[u]) {
                from[u] = v;
                minTime[u] = tNew;

                q.push({-tNew, -u});
            }
        }
    }

    return {};
}

void dfsComp(int v, int c) {
    comp[v] = c;

    for (int u = 0; u < nIslands; u++) if (comp[u] == -1 && dist[u][v] <= BRICKS_ONE) {
        dfsComp(u, c);
    }
}

void updateConnected(const Bridgeman &b, vector <tuple<int,int,int,int>> &path, int t, int updateTo = 1) {
    map <pair<int,int>,int> unpacked, packed;

    if (b.uBridge != -1) {
        unpacked[minmax(b.uBridge, b.vBridge)] = 0;
    }

    for (auto [u, v, tOp, type] : path) {
        if (type == UNPACK) {
            unpacked[minmax(u, v)] = tOp;
        } else if (type == PACK) {
            packed[minmax(u, v)] = tOp;
        }
    }

    for (auto [u, v, tOp, type] : path) {
        if (type == MOVE && !unpacked.count(minmax(u, v))) {
            int val = 2 * updateTo - 1;
            used[tOp][u][v] += val;
            used[tOp][v][u] += val;
        }
    }

    for (auto [e, l] : unpacked) {
        auto [u, v] = e;

        int r = packed[e];
        for (int t = l; t <= r; t++) {
            //assert(connected[t][u][v] != updateTo && connected[t][v][u] != updateTo);
            connected[t][u][v] = connected[t][v][u] = updateTo;

            if (updateTo) {
                whenConnected[u][v].insert(t);
                whenConnected[v][u].insert(t);
            } else {
                whenConnected[u][v].erase(t);
                whenConnected[v][u].erase(t);
            }
        }
    }
}

int getTimeFinished(const vector <tuple<int,int,int,int>> &path) {
    return get<2>(path[0]) + 1;
}

bool planCompExchange(int t, int uLongBest, int vLongBest, vector <int> &uStuck, vector <int> &vStuck) {
    auto getTimes = [&](int target, vector <int> &stuck) -> pair <int,int> {
        int tMin = INF, tMax = 0;
        for (int id : stuck) {
            if (bridgemen[id].pos == target) {
                tMin = 0;
                continue;
            }

            auto path = bfs(id, t, target);
            if (!path.empty()) {
                int tReach = getTimeFinished(path);
                tMin = min(tMin, tReach);
                tMax = max(tMax, tReach);
            }
        }

        return {tMin, tMax};
    };

    int iLong = -1, jLong = -1, bestTimeFinished = INF, bestTieBreak = INF;
    for (int i = 0; i < nIslands; i++) if (comp[i] == uLongBest) {
        for (int j = 0; j < nIslands; j++) if (comp[j] == vLongBest && dist[i][j] <= BRICKS_TWO) {
            auto [iMin, iMax] = getTimes(i, uStuck);
            auto [jMin, jMax] = getTimes(j, vStuck);

            if (iMin == INF || jMin == INF) {
                continue;
            }

            int timeFinished = max(iMax, jMax), tieBreak = max(iMin, jMin);
            if (make_pair(timeFinished, tieBreak) < make_pair(bestTimeFinished, bestTieBreak)) {
                iLong = i, jLong = j, bestTimeFinished = timeFinished, bestTieBreak = tieBreak;
            }
        }
    }

    if (iLong == -1) {
        return false;
    }

    auto processStuck = [&](int target, vector <int> &stuck) -> vector <pair<int,int>> {
        vector <pair<int,int>> res;
        for (int i = 0; i < (int) stuck.size(); i++) {
            int id = stuck[i];

            assert(comp[bridgemen[id].pos] == comp[target]);
            assert(!bridgemen[id].waiting);

            bridgemen[id].waiting = 1;

            int tHere = t;
            if (bridgemen[id].pos != target) {
                bridgemen[id].path = bfs(id, t, target);
                if (bridgemen[id].path.empty()) {
                    swap(stuck[i--], stuck.back());
                    stuck.pop_back();

                    continue;
                }

                tHere = getTimeFinished(bridgemen[id].path);
                updateConnected(bridgemen[id], bridgemen[id].path, t);
            }

            res.push_back({tHere, id});
        }

        sort(res.begin(), res.end());
        return res;
    };

    auto iRes = processStuck(iLong, uStuck);
    auto jRes = processStuck(jLong, vStuck);

    assert(!iRes.empty() && !jRes.empty());

    int tUnpack = max(iRes[0].first, jRes[0].first);
    int tPack = max({iRes.back().first, jRes.back().first, tUnpack + 2});

    if (tPack < N_TURNS) {
        pair <int,int> p = {iRes[0].second, jRes[0].second};

        futureCompBridges.insert(minmax(uLongBest, vLongBest));
        plansTeamUnpack[tUnpack].push_back(p);

        auto processRes = [&](vector <pair<int,int>> &res, int v) {
            for (int i = 0; i < (int) res.size(); i++) {
                auto [tHere, id] = res[i];

                if (i == 0) {
                    plansCompMove[tUnpack + 1].push_back({id, v});
                    plansStopWaiting[tPack].push_back(id);
                } else {
                    tHere = max(tHere, tUnpack);
                    plansCompMove[tHere].push_back({id, v});
                    plansStopWaiting[tHere].push_back(id);
                }
            }
        };

        processRes(iRes, jLong);
        processRes(jRes, iLong);

        plansTeamPack[tPack].push_back(p);

        for (int tm = tUnpack; tm <= tPack; tm++) {
            connected[tm][iLong][jLong] = connected[tm][jLong][iLong] = 1;

            whenConnected[iLong][jLong].insert(tm);
            whenConnected[jLong][iLong].insert(tm);
        }
    }

    return true;
}

void planOrderDelivery(int t) {
    while (true) {
        for (auto &b : bridgemen) if (!b.path.empty() && b.target != -1 && !b.waiting) {
            auto [uFirst, vFirst, tOpFirst, typeFirst] = b.path.back();
            if (t != tOpFirst) {
                continue;
            }

            bool anyUsed = false;
            for (int r = 0; r < (int) b.path.size(); r++) {
                auto [u, v, tOp, type] = b.path[r];
                if (type == PACK) {
                    int l = r - 1, tStart = t;
                    while (l >= 0) {
                        auto [ul, vl, tOpL, typeL] = b.path[l];
                        if (u == ul && v == vl && typeL == UNPACK) {
                            tStart = tOpL;
                            break;
                        }

                        l--;
                    }

                    for (int tm = tStart; tm <= tOp; tm++) {
                        if (used[tm][u][v]) {
                            anyUsed = true;
                            break;
                        }
                    }
                }
            }

            if (anyUsed) {
                continue;
            }

            updateConnected(b, b.path, t, 0);

            auto [uLast, vLast, tOpLast, typeLast] = b.path[0];

            auto path = bfs(b.id, t, b.target);
            if (path.empty() || (vLast == b.target && getTimeFinished(path) >= getTimeFinished(b.path))) {
                updateConnected(b, b.path, t);
            } else {
                b.path = path;
                updateConnected(b, path, t);
            }
        }

        int idBest = -1, costBest = INF;
        vector <tuple<int,int,int,int>> pathBest;

        for (auto &b : bridgemen) if (b.path.empty() && b.target != -1 && !b.waiting) {
            auto path = bfs(b.id, t, b.target);
            if (path.empty()) {
                continue;
            }

            int cost = getTimeFinished(path);
            if (cost < costBest) {
                idBest = b.id, costBest = cost, pathBest = path;
            }
        }

        if (idBest == -1) {
            break;
        }

        bridgemen[idBest].path = pathBest;
        updateConnected(bridgemen[idBest], pathBest, t);
    }
}

vector <int> planOrderPickup(int t, vector <int> &orderTaken) {
    vector <int> bridgemenLeft;
    for (auto &b : bridgemen) if (b.path.size() <= 1 && b.target == -1 && !b.waiting) {
        bridgemenLeft.push_back(b.id);
    }

    while (true) {
        int idBest = -1, orderBest = -1, costBest = INF;
        for (int id : bridgemenLeft) {
            for (int i = 0; i < nOrders; i++) if (!orderTaken[i]) {
                auto pathSource = bfs(id, t, orders[i].source);
                if (pathSource.empty()) {
                    continue;
                }

                int cost = getTimeFinished(pathSource);
                if (cost < costBest) {
                    idBest = id, orderBest = i, costBest = cost;
                }
            }
        }

        if (idBest == -1) {
            break;
        }

        auto path = bfs(idBest, t, orders[orderBest].source);
        assert(!path.empty());

        if (get<3>(path.back()) == UNPACK) {
            assert(path.size() >= 3);
            path.erase(path.begin(), path.end() - 3);
        } else {
            path.erase(path.begin(), path.end() - 1);
        }

        updateConnected(bridgemen[idBest], path, t);

        bridgemen[idBest].path = path;
        bridgemenLeft.erase(find(bridgemenLeft.begin(), bridgemenLeft.end(), idBest));

        orderTaken[orderBest] = 1;
    }

    return orderTaken;
}

vector <string> makeTurn(int t) {
    vector <string> output;

    if (elapsedTime > 9000) {
        return output;
    }

    vector <int> orderTaken(nOrders, 0);
    while (true) {
        planOrderDelivery(t);
        planOrderPickup(t, orderTaken);

        if (elapsedTime > 8000) {
            break;
        }

        vector <int> bridgemenStuck;
        for (auto &b : bridgemen) if (b.path.empty() && !b.waiting) {
            bridgemenStuck.push_back(b.id);
        }

        vector <int> freeOrdersPerComp(nComps, 0);
        for (int i = 0; i < nOrders; i++) if (!orderTaken[i]) {
            freeOrdersPerComp[comp[orders[i].source]]++;
        }

        int uLongBest = -1, vLongBest = -1, gainLongBest = 0;
        vector <int> uStuckBest, vStuckBest;

        for (int u = 0; u < nComps; u++) for (int v = u + 1; v < nComps; v++) {
            if (compDist[u][v] == 1 && !futureCompBridges.count(minmax(u, v))) {
                vector <int> uStuck, vStuck, uIdle, vIdle;
                for (int id : bridgemenStuck) {
                    int cSource = comp[bridgemen[id].pos];

                    if (bridgemen[id].target != -1) {
                        int cTarget = comp[bridgemen[id].target];
                        if (cSource == cTarget) {
                            continue;
                        }

                        if (cSource == u && compDist[v][cTarget] < compDist[u][cTarget]) {
                            uStuck.push_back(id);
                        } else if (cSource == v && compDist[u][cTarget] < compDist[v][cTarget]) {
                            vStuck.push_back(id);
                        }
                    } else if (cSource == u) {
                        uIdle.push_back(id);
                    } else if (cSource == v) {
                        vIdle.push_back(id);
                    }
                }

                copy(uIdle.begin(), uIdle.begin() + min((int) uIdle.size(), freeOrdersPerComp[v]), back_inserter(uStuck));
                copy(vIdle.begin(), vIdle.begin() + min((int) vIdle.size(), freeOrdersPerComp[u]), back_inserter(vStuck));

                int gain = uStuck.size() + vStuck.size();

                auto ensureNonEmpty = [&](int c, int cOther, vector <int> &stuck) {
                    if (stuck.empty()) {
                        int idBest = -1, distBest = INF;
                        for (auto &b : bridgemen) if (comp[b.pos] == c && b.path.empty() && !b.waiting) {
                            int d = INF;
                            for (int i = 0; i < nIslands; i++) if (comp[i] == c) {
                                for (int j = 0; j < nIslands; j++) if (comp[j] == cOther && dist[i][j] <= BRICKS_TWO) {
                                    d = min(d, dist[b.pos][i]);
                                }
                            }

                            if (d < distBest) {
                                idBest = b.id, distBest = d;
                            }
                        }

                        if (idBest != -1) {
                            stuck.push_back(idBest);
                        }
                    }
                };

                ensureNonEmpty(u, v, uStuck);
                ensureNonEmpty(v, u, vStuck);

                if (gain > gainLongBest && !uStuck.empty() && !vStuck.empty()) {
                    uLongBest = u, vLongBest = v, gainLongBest = gain, uStuckBest = uStuck, vStuckBest = vStuck;
                }
            }
        }

        if (uLongBest == -1) {
            break;
        }

        if (!planCompExchange(t, uLongBest, vLongBest, uStuckBest, vStuckBest)) {
            break;
        }
    }

    auto addMoves = [&](const string &type, vector <pair<int,int>> &plans) {
        for (auto [i, v] : plans) {
            output.push_back(type + " " + to_string(i) + " " + to_string(v));
        }
    };

    auto addTeamMoves = [&](const string &type, vector <pair<int,int>> &plans) {
        for (auto [i, j] : plans) {
            output.push_back("TEAM" + type + " " + to_string(i) + " " + to_string(j) + " " + to_string(BRICKS_ONE));
        }
    };

    vector <pair<int,int>> plansUnpack, plansMove, plansPack;
    for (auto &b : bridgemen) if (!b.path.empty()) {
        auto [u, v, tOp, type] = b.path.back();
        assert(tOp >= t);

        if (t != tOp) {
            continue;
        }

        pair <int,int> p = {b.id, u + v - b.pos};
        if (type == MOVE) {
            plansMove.push_back(p);
        } else if (type == UNPACK) {
            plansUnpack.push_back(p);
        } else if (type == PACK) {
            plansPack.push_back(p);
        }

        b.path.pop_back();
    }

    addMoves("UNPACK", plansUnpack);
    addTeamMoves("UNPACK", plansTeamUnpack[t]);

    addMoves("MOVE", plansMove);
    addMoves("MOVE", plansCompMove[t]);

    addMoves("PACK", plansPack);
    addTeamMoves("PACK", plansTeamPack[t]);

    for (auto [i, v] : plansUnpack) {
        assert(bridgemen[i].uBridge == -1 && bridgemen[i].vBridge == -1);
        bridgemen[i].uBridge = bridgemen[i].pos;
        bridgemen[i].vBridge = v;
    }

    for (auto [i, v] : plansPack) {
        assert(bridgemen[i].uBridge != -1 && bridgemen[i].vBridge != -1);
        assert(bridgemen[i].uBridge == v || bridgemen[i].vBridge == v);
        bridgemen[i].uBridge = bridgemen[i].vBridge = -1;
    }

    for (auto [i, j] : plansTeamPack[t]) {
        auto p = minmax(comp[bridgemen[i].pos], comp[bridgemen[j].pos]);
        assert(futureCompBridges.count(p));

        futureCompBridges.erase(p);
    }

    for (int i : plansStopWaiting[t]) {
        assert(bridgemen[i].waiting);
        bridgemen[i].waiting = 0;
    }

    return output;
}

int main() {
    cin >> nIslands >> nBridgemen >> nOrders;

    dist.resize(nIslands, vector <int> (nIslands, 0));
    for (int i = 0; i < nIslands; i++) for (int j = 0; j < nIslands; j++) {
        cin >> dist[i][j];
    }

    comp.resize(nIslands, -1);

    nComps = 0;
    for (int i = 0; i < nIslands; i++) if (comp[i] == -1) {
        dfsComp(i, nComps++);
    }

    compDist.resize(nComps, vector <int> (nComps, INF));
    for (int i = 0; i < nComps; i++) {
        compDist[i][i] = 0;
    }

    for (int i = 0; i < nIslands; i++) for (int j = i + 1; j < nIslands; j++) {
        if (comp[i] != comp[j] && dist[i][j] <= BRICKS_TWO) {
            compDist[comp[i]][comp[j]] = compDist[comp[j]][comp[i]] = 1;
        }
    }

    for (int k = 0; k < nComps; k++) for (int i = 0; i < nComps; i++) for (int j = 0; j < nComps; j++) {
        compDist[i][j] = min(compDist[i][j], compDist[i][k] + compDist[k][j]);
    }

    for (int t = 0; t < N_TURNS; t++) {
        connected[t] = used[t] = vector <vector<int>> (nIslands, vector <int> (nIslands, 0));
    }

    whenConnected.resize(nIslands, vector <set<int>> (nIslands));

    bridgemen.resize(nBridgemen);
    for (int i = 0; i < nBridgemen; i++) {
        bridgemen[i].id = i;
    }

    orders.resize(nOrders);
    for (int turn = 0; turn < N_TURNS; turn++) {
        cin >> elapsedTime;

        for (int i = 0; i < nBridgemen; i++) {
            cin >> bridgemen[i].pos >> bridgemen[i].bricks >> bridgemen[i].target;
        }

        for (int i = 0; i < nOrders; i++) {
            cin >> orders[i].source >> orders[i].target;
        }

        auto output = makeTurn(turn);
        for (int i = 0; i < (int) output.size(); i++) {
            cout << output[i];
            if (i < output.size() - 1) {
                cout << " | ";
            }
        }
        cout << endl;
    }

    return 0;
}