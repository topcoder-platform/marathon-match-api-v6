#define NDEBUG
#pragma GCC optimize("O3")
//#pragma GCC optimize("unroll-loops")
#define debug(...) ;
#define debug2(...) ;
#define debug_st(...) ;
#define debug_sa(...) ;
#define debug_bm(...) ;
#define debug_gd(...) ;
#define debug_hc(...) ;
#define debug_mn(...) ;

// XorShift法による乱数生成
unsigned int XorShift();
// 共通処理を宣言/定義する

#include <bits/stdc++.h>

namespace std {
using ll = long long;

static constexpr int kMaxTurn = 1000;  // 最大ターン数

static constexpr int kMaxN = 80;  // 島の最大数
static constexpr int kMaxB = 20;  // 工作員の最大数
static constexpr int kMaxO = 10;  // 表示される依頼の最大数

using IslandBit = bitset<kMaxN>;
using OrderBit = bitset<kMaxO>;

static constexpr int kInitCarryBridgeLen = 50;  // 工作員が運べる橋の長さの初期値
static constexpr int kMaxCarryBridgeLen = 60;   // 工作員が運べる最長の橋の長さ

// 工作員の情報
struct BridgeMan {
   BridgeMan() : island_id(-1), order_target_id(-1), carry_len(kInitCarryBridgeLen) {
   }

   int island_id;        // 現在いる島のID: [0, N)
   int order_target_id;  // 現在運んでいる依頼のターゲット島ID: [0, N), 運んでいない場合は-1
   int carry_len;        // 現在運んでいる橋の長さ
};

enum ActionType {
   kActionMove = 0,    // 移動
   kActionUnpack,      // 橋を架ける
   kActionPack,        // 橋を撤去する
   kActionTeamUnpack,  // チームで橋を架ける
   kActionTeamPack,    // チームで橋を撤去する
   kActionWait,        // 待機
   kActionIdle
};

struct Action {
   Action() : action_type_(kActionIdle), island_id_(-1), bridge_man_id1_(-1), bridge_man_id2_(-1), bridge_len_1_(-1) {
   }

   friend ostream& operator<<(ostream& os, const Action& action) {
      if (action.action_type_ == kActionMove) {
         os << "{Move BrMan=" << action.bridge_man_id1_ << " to land=" << action.island_id_ << "}";
      } else if (action.action_type_ == kActionUnpack) {
         os << "{Unpack BrMan=" << action.bridge_man_id1_ << " to land=" << action.island_id_ << "}";
      } else if (action.action_type_ == kActionPack) {
         os << "{Pack BrMan=" << action.bridge_man_id1_ << " to land=" << action.island_id_ << "}";
      } else if (action.action_type_ == kActionTeamUnpack) {
         os << "{TeamUnpack BrMan1=" << action.bridge_man_id1_ << " BrMan2=" << action.bridge_man_id2_ << " to land=" << action.island_id_ << " len1=" << action.bridge_len_1_ << "}";
      } else if (action.action_type_ == kActionTeamPack) {
         os << "{TeamPack BrMan1=" << action.bridge_man_id1_ << " BrMan2=" << action.bridge_man_id2_ << " to land=" << action.island_id_ << " len1=" << action.bridge_len_1_ << "}";
      } else if (action.action_type_ == kActionWait) {
         os << "{Wait BrMan=" << action.bridge_man_id1_ << "}";
      } else {
         os << "{Idle BrMan=" << action.bridge_man_id1_ << "}";
      }
      return os;
   }

   ActionType action_type_;
   int island_id_;
   int bridge_man_id1_;
   int bridge_man_id2_;
   int bridge_len_1_;
};

// 2次元座標
using Coord = pair<ll, ll>;

// 2点間の距離
ll CalcSquareDist(const Coord& p1, const Coord& p2);            // 二乗距離
double CalcEuclidDist(const Coord& p1, const Coord& p2);        // ユークリッド距離
ll CalcManhattanDist(const Coord& p1, const Coord& p2);         // マンハッタン距離
ll CalcChebyshevDist(const Coord& p1, const Coord& p2);         // チェビシェフ距離
double CalcLpDist(const Coord& p1, const Coord& p2, double p);  // Lp距離

// 最小化/最大化に合わせて最も悪い値を返す
static constexpr ll kInfVal = numeric_limits<ll>::max();
static constexpr int kIntInf = numeric_limits<int>::max();

// 要素 vec[i]が真になる要素のindexを取得する
template <class T>
vector<int> GetTrueIndex(const vector<T>& vec) {
   vector<int> index_list;

   for (int i = 0; i < (int)index_list.size(); i++) {
      if (vec[i]) index_list.emplace_back(i);
   }
   return index_list;
}

// 集合からランダムに要素を選択する(mt19937_64版)
template <class T>
T GetRandomElem(mt19937_64& mt, const vector<T>& list) {
   assert(!list.empty());
   auto ind = mt() % list.size();
   return list[ind];
}

// 集合からランダムに要素を選択する(XorShift版)
template <class T>
T GetRandomElem(const vector<T>& list) {
   assert(!list.empty());
   auto ind = XorShift() % list.size();
   return list[ind];
}

// 指定されたウェイトで要素をランダムに選択する
int GetRandomWeightedElem(const vector<int>& weight_list);

}  // namespace std



namespace std {
class BridgeManager {
  public:
   BridgeManager(int N, int B);

   // 橋を追加する
   // (追加ターン数, 工作員ID, 橋を架ける島のID, 橋を架ける島のID)
   void AddBridge(int turn, int bridge_man_id, int from, int to);

   // 橋を撤去する
   // (撤去ターン数, 工作員ID, 橋を撤去する島のID, 橋を撤去する島のID)
   void RemoveBridge(int turn, int bridge_man_id, int from, int to);

   // 橋を追加/撤去する
   // (追加ターン, 撤去ターン, 工作員ID, 橋を架ける島のID, 橋を架ける島のID)
   void AddRemoveBridge(int start_turn, int start_bridge_man_id, int end_turn, int end_bridge_man_id, int from, int to);

   // 橋を追加/撤去できるか判定する
   bool CanAddRemoveBridge(int start_turn, int start_bridge_man_id, int end_turn, int end_bridge_man_id, int from, int to) const;

   // turn t, 工作員idが行動する際に(from, to)間に橋があるかを返す
   bool HasBridge(int turn, int bridge_man_id, int from, int to) const;

   // 判定用の時刻を計算する
   inline int GetCheckTime(int turn, int bridge_man_id) const {
      return kMaxB * turn + bridge_man_id;
   }

  protected:
   int N_;
   int B_;

   // (from, to)間に架けられた橋の情報(開始時のcheck_time, 撤去時のcheck_time)
   map<pair<int, int>, vector<pair<int, int>>> bridge_map_;
};
}  // namespace std

// パラメタ管理

#include <bits/stdc++.h>

namespace std {

class Parameter {
  public:
   Parameter();

   // -- SA --
   // 最小/最大温度
   pair<int, int> GetSATemp() const;
   void SetSATemp(int min_temp, int max_temp);

   // -- Beam search --
   int GetBeamDepth() const;
   int GetBeamWidth() const;

   void SetBeamDepth(int depth);
   void SetBeamWidth(int width);

  protected:
   // -- SA --
   int sa_max_temp_;  // 最大温度
   int sa_min_temp_;  // 最大温度

   // -- Beam search --
   int beam_width_;  // ビーム幅
   int beam_depth_;  // ビーム深さ
};

}  // namespace std

#include <bits/stdc++.h>

namespace std {

// 探索情報を管理するクラス
class SearchInfo {
  public:
   SearchInfo();

   // 最善解の更新情報を記録する
   void BestUpdate() {
      best_update_iter_.emplace_back(iter_);
   }

   // 探索開始
   void SearchStart();

   // 探索時間上限(ms)を設定する
   void SetTerminateTime(const int ms) {
      terminate_time_ = ms;
   }

   // 経過時間を取得する
   int GetElapsedTime() const {
      auto e_time = chrono::system_clock::now() - start_time_;
      return chrono::duration_cast<chrono::milliseconds>(e_time).count();
   }

   // 探索終了条件が成立しているかチェックする
   const bool IsTerminate() const;

   // 探索ノード数を取得する
   int GetIter() const {
      return iter_;
   }

   void AddIter() {
      iter_++;
   }

   // 平均更新間隔を取得する
   int GetMeanUpdateInterval() const;

   // 最大更新間隔を取得する
   int GetMaxUpdateInterval() const;

   // 進捗状況[0, 1]を取得する
   double GetProgress() const {
      return GetElapsedTime() / (double)terminate_time_;
   }

  protected:
   int iter_;                      // 探索回数数
   vector<int> best_update_iter_;  // 最善解を更新時の探索回数数の履歴

   chrono::system_clock::time_point start_time_;  // 探索開始時間

   int terminate_time_;  // 探索時間上限(ms)
};
}  // namespace std


#include <bits/stdc++.h>

namespace std {

class State {
  public:
   State(int N, int B, int O);
   State operator=(const State& state);

   // 島間の距離を設定する
   void SetIslandDistTbl(const vector<vector<int>>& island_dist_tbl);

   // 状態をエラー出力する
   void Output() const;

   // 工作員/依頼の状態を設定する
   // @note turn数を+1する
   void SetTurnInfo(const vector<BridgeMan>& bridge_men_list, const vector<pair<int, int>>& order_list);

  protected:
   // 行動を反映する
   void ApplyAction(const Action& action);

   // 隣接リストを事前計算しておく
   void CalcAdjList();

   string GetString() const;

   // 島のクラスタ(長さ50以下で移動可能な連結成分)を計算する
   void CalcIslandClusters();

   // 島間の移動回数を計算する
   void CalcMoveCntTbl();

   // turnからbridge_manが(from, to)間を移動するのに必要な行動を計算する
   vector<Action> CalcSingleAddRemoveOneStep(int turn, int bridge_man_id, int from, int to) const;
   vector<Action> CalcSingleAddRemoveWalk(int turn, int bridge_man_id, int from, int to, const IslandBit& avoid_island_bit) const;

   // 工作員の行動を追加する
   bool AddSingleTurnAction(int bridge_man_id, const vector<Action>& action_list);

   int N_;  // 島の数
   int B_;  // 工作員の数
   int O_;  // 表示される依頼の数

   vector<vector<int>> island_dist_tbl_;  // island_dist_tbl_[i][j]: 島iから島jへの距離
   vector<vector<bool>> bridge_flg_;      // bridge_tbl_[i][j]: 島iと島jの間に橋があるか

   vector<BridgeMan> bridge_men_list_;  // 工作員の情報

   int turn_;  // 現在のターン

   vector<pair<int, int>> order_list_;                // order_list_[i]: 依頼(i番目に表示される依頼)の情報 (from, to)
   int finished_order_num_;                           // 完了した依頼数
   vector<array<Action, kMaxTurn>> turn_action_tbl_;  // turn_action_tbl_[b][t]: 工作員bがターンtに行う行動

   vector<vector<int>> single_adj_list_;  // 長さ50以下で移動可能な島の隣接リスト
   vector<vector<int>> team_adj_list_;    // 長さ51以上100以下で移動可能な島の隣接リスト

   vector<int> island_cluster_tbl_;  // island_cluster_tbl_[i]: 島iのクラスタ(工作員が単独)番号

   vector<vector<int>> single_move_cnt_tbl_;  // move_cnt_tbl_[from][to]: 島fromから島toへの移動回数(同一クラスタ内のみ移動する)

   BridgeManager bridge_manager_;
};

// Beam search用の比較演算子
bool operator>(const State& lhs, const State& rhs);
bool operator<(const State& lhs, const State& rhs);

}  // namespace std



namespace std {

class Judge
    : public State {
  public:
   Judge(const State& state);

   // 開始情報を送る
   // (経過時間, 工作員の情報, 依頼の情報)
   tuple<int, vector<BridgeMan>, vector<pair<int, int>>> StartTurn();

   // Judgeを初期化する
   void Init();

   // 行動情報を反映する
   void ApplyActions(const vector<Action>& action_list);

   int GetScore() const {
      return finished_order_num_;
   }

   // 工作員1人あたりの行動回数の平均値を返す
   tuple<double, double, double, double, double> GetActionResult() const {
      return {1.0 * move_cnt_ / B_, 1.0 * unpack_cnt_ / B_, 1.0 * pack_cnt_ / B_, 1.0 * team_unpack_cnt_ / B_, 1.0 * team_pack_cnt_ / B_};
   }

  protected:
   // 開始時情報を送る(ローカル/オンラインで処理が異なる)
   tuple<int, vector<BridgeMan>, vector<pair<int, int>>> StartTurnLocal();
   tuple<int, vector<BridgeMan>, vector<pair<int, int>>> StartTurnOnline();

   // 行動情報を反映する(ローカル/オンラインで処理が異なる)
   void ApplyActionsLocal(const vector<Action>& action_list);
   void ApplyActionsOnline(const vector<Action>& action_list);

   // 工作員を初期化する
   void InitBridgeMen();

   // 依頼を初期化する
   void InitOrders();

   // 依頼を処理する
   void HandleOrders();

   // 依頼を受領する
   void ReceiveOrders();

   list<pair<int, int>> all_order_list_;

   chrono::system_clock::time_point start_time_;

   // 統計情報
   int move_cnt_;
   int unpack_cnt_;
   int pack_cnt_;
   int team_unpack_cnt_;
   int team_pack_cnt_;
};

}  // namespace std



using namespace std;

namespace std {

class SinglePlayer
    : public State {
  public:
   SinglePlayer(const State& state);

   // 次の行動を決定する
   vector<Action> GetNextActions();

  protected:
   // 工作員の次の行動を決定する
   // @retval 対応する依頼番号(対応可能な依頼がない場合は-1)
   int SetNextBridgemanPlan(int bridge_man_id, const OrderBit& assigned_order_bit, const IslandBit& from_island);

   mutable mt19937_64 mt_;
};
}  // namespace std

// printデバッグ
// 参考「競技プログラミングで print デバッグ」(https://naskya.net/post/0002/)

// Stateクラス用

#ifndef DEBUG_MN_PRINT_HPP
#define DEBUG_MN_PRINT_HPP

#ifdef LOCAL
#define debug_mn(...) debug_print::multi_print_mn(#__VA_ARGS__, __VA_ARGS__)
#else
#define debug_mn(...) ;
#endif

#ifdef LOCAL

#include <algorithm>
#include <cctype>
#include <cstddef>
#include <iostream>
#include <iterator>
#include <string_view>
#include <type_traits>
#include <utility>

namespace debug_print {

template <class Tp>
auto has_cbegin(int) -> decltype(std::cbegin(std::declval<Tp>()), std::true_type{});
template <class Tp>
auto has_cbegin(...) -> std::false_type;
template <class Tp>
auto has_value_type(int) -> decltype(std::declval<typename Tp::value_type>(), std::true_type{});
template <class Tp>
auto has_value_type(...) -> std::false_type;

template <class Tp>
[[maybe_unused]] constexpr bool is_iteratable_container_v = decltype(has_cbegin<Tp>(int{}))::value;
template <class Tp>
[[maybe_unused]] constexpr bool is_container_v = decltype(has_value_type<Tp>(int{}))::value || is_iteratable_container_v<Tp>;

template <>
[[maybe_unused]] constexpr bool is_iteratable_container_v<std::string_view> = false;
template <>
[[maybe_unused]] constexpr bool is_container_v<std::string_view> = false;
#if (defined _GLIBCXX_STRING) || (defined _LIBCPP_STRING)
template <>
[[maybe_unused]] constexpr bool is_iteratable_container_v<std::string> = false;
template <>
[[maybe_unused]] constexpr bool is_container_v<std::string> = false;
#endif

template <class Tp, class... Ts>
struct first_element {
   using type = Tp;
};
template <class... Ts>
using first_t = typename first_element<Ts...>::type;

template <class Tp, std::enable_if_t<!decltype(has_value_type<Tp>(int{}))::value, std::nullptr_t> = nullptr>
auto check_elem(int) -> decltype(*std::cbegin(std::declval<Tp>()));
template <class Tp, std::enable_if_t<decltype(has_value_type<Tp>(int{}))::value, std::nullptr_t> = nullptr>
auto check_elem(int) -> typename Tp::value_type;
template <class Tp>
auto check_elem(...) -> void;

template <class Tp>
using elem_t = decltype(check_elem<Tp>(int{}));

template <class Tp>
[[maybe_unused]] constexpr bool is_multidim_container_v = is_container_v<Tp> && is_container_v<elem_t<Tp>>;

template <class Tp>
std::enable_if_t<!is_container_v<Tp>> out_mn(const Tp&);
void out_mn(const char&);
void out_mn(const char*);
void out_mn(const std::string_view&);

#if (defined _GLIBCXX_STRING) || (defined _LIBCPP_STRING)
void out_mn(const std::string&);
#endif

#ifdef __SIZEOF_INT128__
void out_mn(const __int128&);
void out_mn(const unsigned __int128&);
#endif

template <class Tp1, class Tp2>
void out_mn(const std::pair<Tp1, Tp2>&);

#if (defined _GLIBCXX_TUPLE) || (defined _LIBCPP_TUPLE)
template <class... Ts>
void out_mn(const std::tuple<Ts...>&);
#endif

#if (defined _GLIBCXX_STACK) || (defined _LIBCPP_STACK)
template <class... Ts>
void out_mn(std::stack<Ts...>);
#endif

#if (defined _GLIBCXX_QUEUE) || (defined _LIBCPP_QUEUE)
template <class... Ts>
void out_mn(std::queue<Ts...>);
template <class... Ts>
void out_mn(std::priority_queue<Ts...>);
#endif

template <class C>
std::enable_if_t<is_iteratable_container_v<C>> out_mn(const C&);

template <class Tp>
std::enable_if_t<!is_container_v<Tp>> out_mn(const Tp& arg) {
   std::cerr << arg;
}

void out_mn(const char& arg) {
   std::cerr << '\'' << arg << '\'';
}

void out_mn(const char* arg) {
   std::cerr << '\"' << arg << '\"';
}

void out_mn(const std::string_view& arg) {
   std::cerr << '\"' << arg << '\"';
}

#if (defined _GLIBCXX_STRING) || (defined _LIBCPP_STRING)
void out_mn(const std::string& arg) {
   std::cerr << '\"' << arg << '\"';
}
#endif

#ifdef __SIZEOF_INT128__
void out_mn(const __int128& arg) {
   int sign = (arg < 0) ? (-1) : 1;
   if (sign == -1)
      std::cerr << '-';
   __int128 base = sign;
   while (sign * arg >= sign * base * 10)
      base *= 10;
   while (base) {
      std::cerr << static_cast<char>('0' + (arg / base % 10));
      base /= 10;
   }
}

void out_mn(const unsigned __int128& arg) {
   unsigned __int128 base = 1;
   while (arg >= base * 10)
      base *= 10;
   while (base) {
      std::cerr << static_cast<char>('0' + (arg / base % 10));
      base /= 10;
   }
}
#endif

template <class Tp1, class Tp2>
void out_mn(const std::pair<Tp1, Tp2>& arg) {
   std::cerr << '(';
   out_mn(arg.first);
   std::cerr << ", ";
   out_mn(arg.second);
   std::cerr << ')';
}

#if (defined _GLIBCXX_TUPLE) || (defined _LIBCPP_TUPLE)
template <class T, std::size_t... Is>
void print_tuple(const T& arg, std::index_sequence<Is...>) {
   static_cast<void>(((std::cerr << (Is == 0 ? "" : ", "), out_mn(std::get<Is>(arg))), ...));
}

template <class... Ts>
void out_mn(const std::tuple<Ts...>& arg) {
   std::cerr << '(';
   print_tuple(arg, std::make_index_sequence<sizeof...(Ts)>());
   std::cerr << ')';
}
#endif

#if (defined _GLIBCXX_STACK) || (defined _LIBCPP_STACK)
template <class... Ts>
void out_mn(std::stack<Ts...> arg) {
   if (arg.empty()) {
      std::cerr << "<empty stack>";
      return;
   }
   std::cerr << "[ ";
   while (!arg.empty()) {
      out_mn(arg.top());
      std::cerr << ' ';
      arg.pop();
   }
   std::cerr << ']';
}
#endif

#if (defined _GLIBCXX_QUEUE) || (defined _LIBCPP_QUEUE)
template <class... Ts>
void out_mn(std::queue<Ts...> arg) {
   if (arg.empty()) {
      std::cerr << "<empty queue>";
      return;
   }
   std::cerr << "[ ";
   while (!arg.empty()) {
      out_mn(arg.front());
      std::cerr << ' ';
      arg.pop();
   }
   std::cerr << ']';
}
template <class... Ts>
void out_mn(std::priority_queue<Ts...> arg) {
   if (arg.empty()) {
      std::cerr << "<empty priority_queue>";
      return;
   }
   std::cerr << "[ ";
   while (!arg.empty()) {
      out_mn(arg.top());
      std::cerr << ' ';
      arg.pop();
   }
   std::cerr << ']';
}
#endif

template <class Container>
std::enable_if_t<is_iteratable_container_v<Container>> out_mn(const Container& arg) {
   if (std::distance(std::cbegin(arg), std::cend(arg)) == 0) {
      std::cerr << "<empty container>";
      return;
   }
   std::cerr << "[ ";
   std::for_each(std::cbegin(arg), std::cend(arg), [](const elem_t<Container>& elem) {
      out_mn(elem);
      std::cerr << ' ';
   });
   std::cerr << ']';
}

template <class Tp>
std::enable_if_t<!is_multidim_container_v<Tp>>
print(std::string_view name, const Tp& arg) {
   std::cerr << name << ": ";
   out_mn(arg);
   if constexpr (is_container_v<Tp>)
      std::cerr << '\n';
}

template <class Tp>
std::enable_if_t<is_multidim_container_v<Tp>>
print(std::string_view name, const Tp& arg) {
   std::cerr << name << ": ";
   if (std::distance(std::cbegin(arg), std::cend(arg)) == 0) {
      std::cerr << "<empty multidimensional container>\n";
      return;
   }
   std::for_each(std::cbegin(arg), std::cend(arg),
                 [&name, is_first_elem = true](const elem_t<Tp>& elem) mutable {
                    if (is_first_elem)
                       is_first_elem = false;
                    else
                       for (std::size_t i = 0; i < name.length() + 2; i++)
                          std::cerr << ' ';
                    out_mn(elem);
                    std::cerr << '\n';
                 });
}

template <class Tp, class... Ts>
void multi_print_mn(std::string_view names, const Tp& arg, const Ts&... args) {
   if constexpr (sizeof...(Ts) == 0) {
      names.remove_suffix(
          std::distance(
              names.crbegin(),
              std::find_if_not(names.crbegin(), names.crend(),
                               [](const char c) { return std::isspace(c); })));
      print(names, arg);
      if constexpr (!is_container_v<Tp>)
         std::cerr << '\n';
   } else {
      std::size_t comma_pos = 0;

      for (std::size_t i = 0, paren_depth = 0, inside_quote = false; i < names.length(); i++) {
         if (!inside_quote && paren_depth == 0 && i > 0 && names[i - 1] != '\'' && names[i] == ',') {
            comma_pos = i;
            break;
         }
         if (names[i] == '\"') {
            if (i > 0 && names[i - 1] == '\\') continue;
            inside_quote ^= true;
         }
         if (!inside_quote && names[i] == '(' && (i == 0 || names[i - 1] != '\''))
            paren_depth++;
         if (!inside_quote && names[i] == ')' && (i == 0 || names[i - 1] != '\''))
            paren_depth--;
      }

      const std::size_t first_varname_length = comma_pos - std::distance(
                                                               names.crend() - comma_pos,
                                                               std::find_if_not(
                                                                   names.crend() - comma_pos, names.crend(),
                                                                   [](const char c) { return std::isspace(c); }));
      print(names.substr(0, first_varname_length), arg);

      if constexpr (!is_container_v<Tp>) {
         if constexpr (is_container_v<first_t<Ts...>>)
            std::cerr << '\n';
         else
            std::cerr << " | ";
      }

      const std::size_t next_varname_begins_at = std::distance(
          names.cbegin(),
          std::find_if_not(
              names.cbegin() + comma_pos + 1, names.cend(),
              [](const char c) { return std::isspace(c); }));
      names.remove_prefix(next_varname_begins_at);

      multi_print_mn(names, args...);
   }
}
}  // namespace debug_print
#endif
#endif  // DEBUG_MN_PRINT_HPP


unsigned int XorShift() {
   // ref: https://qiita.com/drken/items/7c6ff2aa4d8fce1c9361#9-xorshift
   static unsigned int tx = 123456789, ty = 362436069, tz = 521288629, tw = 88675123;

   unsigned int tt = (tx ^ (tx << 11));

   tx = ty;
   ty = tz;
   tz = tw;

   return (tw = (tw ^ (tw >> 19)) ^ (tt ^ (tt >> 8)));
}

using namespace std;

// clang-format off
#define rep(i, n) for (int i = 0; (i) < (int)(n); (i)++)
#define repp(i, s, n) for (int i = s; (i) < (int)(n); (i)++)

#define ALL(v) begin(v),end(v)
#define RALL(v) rbegin(v),rend(v)

template<class T> bool chmax(T &a, const T &b) {if(a<b) {a=b; return true;} return false; }
template<class T> bool chmin(T &a, const T &b) {if(a>b) {a=b; return true;} return false; }
// clang-format on

ll std::CalcSquareDist(const Coord& p1, const Coord& p2) {
   const auto [x1, y1] = p1;
   const auto [x2, y2] = p2;

   ll dist = (x1 - x2) * (x1 - x2);
   dist += (y1 - y2) * (y1 - y2);

   return dist;
}

double std::CalcEuclidDist(const Coord& p1, const Coord& p2) {
   ll sq_dist = CalcSquareDist(p1, p2);
   double dist = sqrt(sq_dist);

   return dist;
}

ll std::CalcManhattanDist(const Coord& p1, const Coord& p2) {
   const auto [x1, y1] = p1;
   const auto [x2, y2] = p2;

   ll dist = abs(x1 - x2);
   dist += abs(y1 - y2);

   return dist;
}

ll std::CalcChebyshevDist(const Coord& p1, const Coord& p2) {
   const auto [x1, y1] = p1;
   const auto [x2, y2] = p2;

   ll dist_x = abs(x1 - x2);
   ll dist_y = abs(y1 - y2);
   ll dist = max(dist_x, dist_y);

   return dist;
}

double std::CalcLpDist(const Coord& p1, const Coord& p2, double p) {
   assert(p >= 1);
   const auto [x1, y1] = p1;
   const auto [x2, y2] = p2;

   double dist = pow(abs(x1 - x2), p);
   dist += pow(abs(y1 - y2), p);

   dist = pow(dist, 1.0 / p);
   return dist;
}

int std::GetRandomWeightedElem(const vector<int>& weight_list) {
   assert(!weight_list.empty());
   int sum = accumulate(ALL(weight_list), 0);
   assert(sum > 0);

   int rnd = XorShift() % sum;

   int cur = 0;
   rep(i, weight_list.size()) {
      cur += weight_list[i];
      if (cur > rnd) return i;
   }
   return weight_list.size() - 1;
}


// clang-format off
#define rep(i, n) for (int i = 0; (i) < (int)(n); (i)++)
#define repp(i, s, n) for (int i = s; (i) < (int)(n); (i)++)

#define ALL(v) begin(v),end(v)
#define RALL(v) rbegin(v),rend(v)

// clang-format on

using namespace std;

BridgeManager::BridgeManager(int N, int B) : N_(N), B_(B) {
}

void BridgeManager::AddBridge(int turn, int bridge_man_id, int from, int to) {
   assert(false);
}

void BridgeManager::RemoveBridge(int turn, int bridge_man_id, int from, int to) {
   assert(false);
}

bool BridgeManager::CanAddRemoveBridge(int start_turn, int start_bridge_man_id, int end_turn, int end_bridge_man_id, int from, int to) const {
   if (from > to) swap(from, to);
   if (!bridge_map_.count({from, to})) return true;
   // 期間が重複

   // ToDo: 検索を高速化する
   for (int b = start_bridge_man_id; b < B_; b++) {
      if (HasBridge(start_turn, b, from, to)) return false;
   }

   for (int turn = start_turn + 1; turn < end_turn; turn++) {
      rep(b, B_) if (HasBridge(turn, b, from, to)) return false;
   }

   for (int b = 0; b <= end_bridge_man_id; b++) {
      if (HasBridge(end_turn, b, from, to)) return false;
   }

   // for (const auto &[exist_start_turn, exist_end_turn] : bridge_map_.at({from, to})) {
   //    if (exist_start_turn <= end_turn && start_turn < exist_end_turn) {
   //       debug_sa(from, to, start_turn, end_turn, exist_start_turn, exist_end_turn);
   //       return false;
   //    }
   // }
   return true;
}

void BridgeManager::AddRemoveBridge(int start_turn, int start_bridge_man_id, int end_turn, int end_bridge_man_id, int from, int to) {
   if (from > to) swap(from, to);
   assert(CanAddRemoveBridge(start_turn, start_bridge_man_id, end_turn, end_bridge_man_id, from, to));

   vector<pair<int, int>> &info_list = bridge_map_[{from, to}];
   int start_check_time = GetCheckTime(start_turn, start_bridge_man_id);
   int end_check_time = GetCheckTime(end_turn, end_bridge_man_id);

   info_list.emplace_back(start_check_time, end_check_time);
   sort(ALL(info_list));
}

bool BridgeManager::HasBridge(int turn, int bridge_man_id, int from, int to) const {
   assert(0 <= from && from < N_);
   assert(0 <= to && to < N_);
   assert(from != to);

   if (from > to) swap(from, to);
   if (!bridge_map_.count({from, to})) return false;

   const auto &bridge_list = bridge_map_.at({from, to});
   if (bridge_list.empty()) return false;

   // ToDo: 後ろから見ていきstart_turn < turnならbreakするようにする
   int check_time = GetCheckTime(turn, bridge_man_id);

   for (const auto &[start_check_time, end_check_time] : bridge_list) {
      bool started = start_check_time <= check_time;
      bool not_ended = check_time < end_check_time;

      if (started && not_ended) return true;
   }

   return false;
}


using namespace std;

Parameter::Parameter()
    :                      // デフォルトパラメタ
      sa_max_temp_(3000),  // SA: 最大温度
      sa_min_temp_(0),     // SA: 最小温度
      beam_width_(3),      // Beam Search: ビーム幅
      beam_depth_(10)      // Beam Search: 探索深さ
{
}

pair<int, int> Parameter::GetSATemp() const {
   return {sa_min_temp_, sa_max_temp_};
}

void Parameter::SetSATemp(int min_temp, int max_temp) {
   sa_min_temp_ = min_temp;
   sa_max_temp_ = max_temp;
}

int Parameter::GetBeamDepth() const {
   return beam_depth_;
}

int Parameter::GetBeamWidth() const {
   return beam_width_;
}

void Parameter::SetBeamDepth(int depth) {
   beam_depth_ = depth;
}

void Parameter::SetBeamWidth(int width) {
   beam_width_ = width;
}


// clang-format off
#define rep(i, n) for (int i = 0; (i) < (int)(n); (i)++)
#define repp(i, s, n) for (int i = s; (i) < (int)(n); (i)++)

#define ALL(v) begin(v),end(v)
#define RALL(v) rbegin(v),rend(v)

// clang-format on

using namespace std;

SearchInfo::SearchInfo()
    : iter_(0), terminate_time_(numeric_limits<int>::max()) {
   start_time_ = chrono::system_clock::now();
}

void SearchInfo::SearchStart() {
   start_time_ = chrono::system_clock::now();
}

const bool SearchInfo::IsTerminate() const {
   auto e_time = chrono::system_clock::now() - start_time_;
   int e_time_ms = chrono::duration_cast<chrono::milliseconds>(e_time).count();

   if (e_time_ms >= terminate_time_) {
      return true;
   }

   return false;
}

int SearchInfo::GetMeanUpdateInterval() const {
   int size = (int)best_update_iter_.size();
   if (size < 2) {
      return 0;
   }

   int sum_interval = 0;

   for (int i = 1; i < size; i++) {
      int interval = best_update_iter_[i] - best_update_iter_[i - 1];
      sum_interval += interval;
   }

   return sum_interval / (size - 1);
}

// 最大更新間隔を取得する
int SearchInfo::GetMaxUpdateInterval() const {
   int size = (int)best_update_iter_.size();
   if (size < 2) {
      return 0;
   }

   int max_interval = -1;

   for (int i = 1; i < size; i++) {
      int interval = best_update_iter_[i] - best_update_iter_[i - 1];
      chmax(max_interval, interval);
   }

   return max_interval;
}




// clang-format off
#define rep(i, n) for (int i = 0; (i) < (int)(n); (i)++)
#define repp(i, s, n) for (int i = s; (i) < (int)(n); (i)++)

#define ALL(v) begin(v),end(v)
#define RALL(v) rbegin(v),rend(v)

// clang-format on

using namespace std;

bool operator>(const State &lhs, const State &rhs) {
   assert(false);
   return false;
}

bool operator<(const State &lhs, const State &rhs) {
   assert(false);
   return false;
}

State::State(int N, int B, int O) : N_(N), B_(B), O_(O), island_dist_tbl_(N, vector<int>(N, -1)), bridge_flg_(N, vector<bool>(N, false)), bridge_men_list_(B), turn_(-1), finished_order_num_(0), island_cluster_tbl_(N_, -1), bridge_manager_(N, B) {
   turn_action_tbl_.resize(B_);

   rep(b, B_) {
      rep(t, kMaxTurn) {
         turn_action_tbl_[b][t] = Action();
      }
   }
}

State State::operator=(const State &state) {
   // メンバ変数をコピー
   // Note: メンバ変数を追加した場合はここに追加する
   return *this;
}

string State::GetString() const {
   assert(false);

   string str;
   return str;
}

void State::Output() const {
   cerr << GetString() << endl;
}

void State::ApplyAction(const Action &action) {
   if (action.action_type_ == kActionMove) {
      // 移動する
      int bridge_man_id = action.bridge_man_id1_;
      assert(bridge_man_id != -1);

      BridgeMan &bridge_man = bridge_men_list_[bridge_man_id];

      int from = bridge_man.island_id;
      int to = action.island_id_;

      assert(0 <= from && from < N_);
      assert(0 <= to && to < N_);

      assert(from != to);
      assert(bridge_flg_[from][to] == true);
      assert(bridge_flg_[to][from] == true);

      bridge_man.island_id = to;
   } else if (action.action_type_ == kActionUnpack) {
      // 橋を架ける
      int bridge_man_id = action.bridge_man_id1_;
      assert(bridge_man_id != -1);

      BridgeMan &bridge_man = bridge_men_list_[bridge_man_id];

      int from = bridge_man.island_id;
      int to = action.island_id_;

      assert(0 <= from && from < N_);
      assert(0 <= to && to < N_);

      assert(from != to);
      assert(bridge_flg_[from][to] == false);
      assert(bridge_flg_[to][from] == false);

      int dist = island_dist_tbl_[from][to];
      assert(dist <= bridge_man.carry_len);

      bridge_man.carry_len -= dist;

      bridge_flg_[from][to] = true;
      bridge_flg_[to][from] = true;
   } else if (action.action_type_ == kActionPack) {
      // 橋を撤去する
      int bridge_man_id = action.bridge_man_id1_;
      assert(bridge_man_id != -1);

      BridgeMan &bridge_man = bridge_men_list_[bridge_man_id];

      int from = bridge_man.island_id;
      int to = action.island_id_;

      assert(0 <= from && from < N_);
      assert(0 <= to && to < N_);

      assert(from != to);
      assert(bridge_flg_[from][to] == true);
      assert(bridge_flg_[to][from] == true);

      int dist = island_dist_tbl_[from][to];
      assert(bridge_man.carry_len + dist <= kMaxCarryBridgeLen);

      bridge_man.carry_len += dist;

      bridge_flg_[from][to] = false;
      bridge_flg_[to][from] = false;
   } else if (action.action_type_ == kActionTeamUnpack) {
      // チームで橋を架ける
      int bridge_man_id_1 = action.bridge_man_id1_;
      int bridge_man_id_2 = action.bridge_man_id2_;
      assert(bridge_man_id_1 != -1);
      assert(bridge_man_id_2 != -1);

      BridgeMan &bridge_man_1 = bridge_men_list_[bridge_man_id_1];
      BridgeMan &bridge_man_2 = bridge_men_list_[bridge_man_id_2];

      int from = bridge_man_1.island_id;
      int to = action.island_id_;

      assert(0 <= from && from < N_);
      assert(0 <= to && to < N_);
      assert(from != to);

      assert(bridge_flg_[from][to] == false);
      assert(bridge_flg_[to][from] == false);

      int bridge_len_1 = action.bridge_len_1_;
      int bridge_len_2 = island_dist_tbl_[from][to] - bridge_len_1;

      assert(0 < bridge_len_1 && bridge_len_1 <= bridge_man_1.carry_len);
      assert(0 < bridge_len_2 && bridge_len_2 <= bridge_man_2.carry_len);

      bridge_man_1.carry_len -= bridge_len_1;
      bridge_man_2.carry_len -= bridge_len_2;

      bridge_flg_[from][to] = true;
      bridge_flg_[to][from] = true;
   } else if (action.action_type_ == kActionTeamPack) {
      // チームで橋を撤去する
      int bridge_man_id_1 = action.bridge_man_id1_;
      int bridge_man_id_2 = action.bridge_man_id2_;
      assert(bridge_man_id_1 != -1);
      assert(bridge_man_id_2 != -1);

      BridgeMan &bridge_man_1 = bridge_men_list_[bridge_man_id_1];
      BridgeMan &bridge_man_2 = bridge_men_list_[bridge_man_id_2];

      int from = bridge_man_1.island_id;
      int to = action.island_id_;

      assert(0 <= from && from < N_);
      assert(0 <= to && to < N_);
      assert(from != to);

      assert(bridge_flg_[from][to] == true);
      assert(bridge_flg_[to][from] == true);

      int bridge_len_1 = action.bridge_len_1_;
      int bridge_len_2 = island_dist_tbl_[from][to] - bridge_len_1;

      assert(bridge_man_1.carry_len + bridge_len_1 <= kMaxCarryBridgeLen);
      assert(bridge_man_2.carry_len + bridge_len_2 <= kMaxCarryBridgeLen);

      bridge_man_1.carry_len += bridge_len_1;
      bridge_man_2.carry_len += bridge_len_2;

      bridge_flg_[from][to] = false;
      bridge_flg_[to][from] = false;
   }
}

void State::SetIslandDistTbl(const vector<vector<int>> &island_dist_tbl) {
   assert((int)island_dist_tbl.size() == N_);

#ifdef LOCAL
   rep(i, N_) assert((int)island_dist_tbl[i].size() == N_);
#endif
   island_dist_tbl_ = island_dist_tbl;

   CalcIslandClusters();
   CalcAdjList();
   CalcMoveCntTbl();
}

void State::CalcMoveCntTbl() {
   single_move_cnt_tbl_.clear();
   single_move_cnt_tbl_.resize(N_, vector<int>(N_, kIntInf));

   auto bfs = [&](int start) {
      queue<int> que;
      que.push(start);
      single_move_cnt_tbl_[start][start] = 0;

      while (!que.empty()) {
         int v = que.front();
         que.pop();

         int cluster_v = island_cluster_tbl_[v];

         for (int u : single_adj_list_[v]) {
            assert(island_cluster_tbl_[u] == cluster_v);
            if (single_move_cnt_tbl_[start][u] != kIntInf) continue;

            single_move_cnt_tbl_[start][u] = single_move_cnt_tbl_[start][v] + 1;
            que.push(u);
         }
      }
   };

   rep(i, N_) {
      bfs(i);
   }
}

void State::CalcAdjList() {
   // 長さ50以下で移動可能な島の隣接リスト
   single_adj_list_.clear();
   single_adj_list_.resize(N_);

   rep(v, N_) {
      rep(u, v) {
         int dist = island_dist_tbl_[v][u];

         if (dist > 50) continue;

         single_adj_list_[v].emplace_back(u);
         single_adj_list_[u].emplace_back(v);
      }
   }

   // 長さ51以上100以下で移動可能な島の隣接リスト
   team_adj_list_.clear();
   team_adj_list_.resize(N_);

   rep(v, N_) {
      rep(u, v) {
         int dist = island_dist_tbl_[v][u];

         if (dist < 51 || dist > 100) continue;

         team_adj_list_[v].emplace_back(u);
         team_adj_list_[u].emplace_back(v);
      }
   }
}

void State::SetTurnInfo(const vector<BridgeMan> &bridge_men_list, const vector<pair<int, int>> &order_list) {
   turn_++;

   assert((int)bridge_men_list.size() == B_);
   bridge_men_list_ = bridge_men_list;

   order_list_ = order_list;
}

void State::CalcIslandClusters() {
   auto bfs = [&](int start, int cluster_id) {
      queue<int> que;
      que.push(start);

      assert(island_cluster_tbl_[start] == -1);
      island_cluster_tbl_[start] = cluster_id;

      while (!que.empty()) {
         int v = que.front();
         que.pop();

         rep(u, N_) {
            if (u == v) continue;

            int dist = island_dist_tbl_[v][u];
            if (dist > kInitCarryBridgeLen) continue;  // 初期状態の橋の長さで移動できない

            if (island_cluster_tbl_[u] != -1) continue;

            island_cluster_tbl_[u] = cluster_id;
            que.push(u);
         }
      }
   };

   int cluster_num = 0;

   rep(v, N_) {
      if (island_cluster_tbl_[v] != -1) continue;

      bfs(v, cluster_num);
      cluster_num++;
   }
}

vector<Action> State::CalcSingleAddRemoveOneStep(int turn, int bridge_man_id, int from, int to) const {
   assert(island_cluster_tbl_[from] == island_cluster_tbl_[to]);
   assert(single_move_cnt_tbl_[from][to] == 1);

   bool is_debug = false;

   const BridgeMan &bridge_man = bridge_men_list_[bridge_man_id];

   // 3ターン以内に橋が架けられることがあるかチェック
   int wait_turn = -1;

   rep(w, 3) {
      int t = turn + w;
      if (t >= kMaxTurn) break;

      if (is_debug) debug_st(turn, wait_turn, from, to, bridge_manager_.HasBridge(t, bridge_man_id, from, to));
      if (bridge_manager_.HasBridge(t, bridge_man_id, from, to)) {
         wait_turn = w;
         break;
      }
   }

   if (is_debug) debug_st(turn, wait_turn, from, to);

   vector<Action> action_list;

   if (wait_turn != -1) {
      // 3ターン以内に橋が架けられることがあるなら、橋が架けられるまで待つ
      rep(i, wait_turn) {
         Action action;
         action.action_type_ = kActionWait;
         action.island_id_ = from;
         action.bridge_man_id1_ = bridge_man_id;

         action_list.emplace_back(action);
      }

      Action action;
      action.action_type_ = kActionMove;
      action.island_id_ = to;
      action.bridge_man_id1_ = bridge_man_id;

      action_list.emplace_back(action);

      if (is_debug) debug_st(turn, action_list);
      return action_list;
   } else {
      // 橋をかける -> 移動 -> 橋を撤去する
      int dist = island_dist_tbl_[from][to];
      assert(dist <= bridge_man.carry_len);

      {
         Action action;
         action.action_type_ = kActionUnpack;
         action.island_id_ = to;
         action.bridge_man_id1_ = bridge_man_id;

         action_list.emplace_back(action);
      }
      {
         Action action;
         action.action_type_ = kActionMove;
         action.island_id_ = to;
         action.bridge_man_id1_ = bridge_man_id;

         action_list.emplace_back(action);
      }
      {
         Action action;
         action.action_type_ = kActionPack;
         action.island_id_ = from;
         action.bridge_man_id1_ = bridge_man_id;

         action_list.emplace_back(action);
      }
      if (is_debug) debug_st(turn, action_list);

      return action_list;
   }
}

vector<Action> State::CalcSingleAddRemoveWalk(int turn, int bridge_man_id, int from, int to, const IslandBit &avoid_island_bit) const {
   if (avoid_island_bit[to]) return {};

   int cur_island = from;
   int cur_turn = turn;

   auto get_next_island = [&](int cur_island, int to) {
      int cluster_cur = island_cluster_tbl_[cur_island];

      for (int next_island : single_adj_list_[cur_island]) {
         if (avoid_island_bit[next_island]) continue;

         int cluster_next = island_cluster_tbl_[next_island];
         if (cluster_next != cluster_cur) continue;  // 同じクラスタ内のみ

         if (single_move_cnt_tbl_[next_island][to] < single_move_cnt_tbl_[cur_island][to]) {
            return next_island;
         }
      }
      return -1;
   };

   vector<Action> action_list;

   while (cur_island != to) {
      int next_island = get_next_island(cur_island, to);
      if (next_island == -1) {
         break;
      }

      auto next_action_list = CalcSingleAddRemoveOneStep(cur_turn, bridge_man_id, cur_island, next_island);
      action_list.insert(action_list.end(), ALL(next_action_list));

      cur_island = next_island;
      cur_turn += next_action_list.size();

      if (cur_turn > kMaxTurn) {
         break;
      }
   }

   if (cur_island != to) action_list.clear();
   return action_list;
}

bool State::AddSingleTurnAction(int bridge_man_id, const vector<Action> &action_list) {
   int L = action_list.size();
   if (turn_ + L > kMaxTurn) return false;

   // 橋の状態を管理
   int cur_island = bridge_men_list_[bridge_man_id].island_id;

   bool is_debug = false;
   if (is_debug) debug_st(turn_, bridge_man_id, action_list);

   rep(i, L) {
      int action_turn = turn_ + i;
      const Action &action = action_list[i];

      if (action.action_type_ == kActionMove) {
         cur_island = action.island_id_;
      } else if (action.action_type_ == kActionUnpack) {
         // Unpack -> Move -> Packの順に行動することを仮定
         assert(i + 2 < L);
         assert(action_list[i + 1].action_type_ == kActionMove);
         assert(action_list[i + 2].action_type_ == kActionPack);
         int from = cur_island;
         int to = action.island_id_;

         bridge_manager_.AddRemoveBridge(action_turn, bridge_man_id, action_turn + 2, bridge_man_id, from, to);
      }
   }

   // 行動を追加
   rep(i, L) {
      int action_turn = turn_ + i;
      const Action &action = action_list[i];

      turn_action_tbl_[bridge_man_id][action_turn] = action;
   }

   return true;
}

// clang-format off
#define rep(i, n) for (int i = 0; (i) < (int)(n); (i)++)
#define repp(i, s, n) for (int i = s; (i) < (int)(n); (i)++)

#define ALL(v) begin(v),end(v)
#define RALL(v) rbegin(v),rend(v)

// clang-format on

using namespace std;

Judge::Judge(const State &state) : State(state), start_time_(chrono::system_clock::now()), move_cnt_(0), unpack_cnt_(0), pack_cnt_(0), team_unpack_cnt_(0), team_pack_cnt_(0) {
}

void Judge::Init() {
#ifndef LOCAL_JUDGE
   return;
#endif

   InitBridgeMen();
   InitOrders();

   HandleOrders();
   start_time_ = chrono::system_clock::now();
}

void Judge::InitBridgeMen() {
   int cluster_num = 0;

   rep(i, N_) chmax(cluster_num, island_cluster_tbl_[i]);
   cluster_num++;

   int M = min(B_, cluster_num);

   // 各クラスタに最低1人ずつ工作員を配置する
   rep(i, M) {
      vector<int> island_list;

      rep(j, N_) {
         if (island_cluster_tbl_[j] == i) {
            island_list.emplace_back(j);
         }
      }

      assert(!island_list.empty());
      int island_id = GetRandomElem(island_list);

      bridge_men_list_[i].island_id = island_id;
   }

   // のこりの工作員をランダムに配置する
   for (int i = M; i < B_; i++) {
      int island_id = XorShift() % N_;
      bridge_men_list_[i].island_id = island_id;
   }
}

void Judge::InitOrders() {
   all_order_list_.clear();

   int order_num = B_ * kMaxTurn + 11 + O_;

   rep(i, order_num) {
      int from = XorShift() % N_;
      int to = XorShift() % N_;
      while (to == from) {
         to = XorShift() % N_;
      }

      all_order_list_.emplace_back(from, to);
   }
}

void Judge::HandleOrders() {
#ifndef LOCAL_JUDGE
   return;
#endif

   rep(i, B_) {
      BridgeMan &bridge_man = bridge_men_list_[i];

      if (bridge_man.island_id == bridge_man.order_target_id) {
         // 依頼を完了した
         finished_order_num_++;
         bridge_man.order_target_id = -1;
      }
   }

   ReceiveOrders();
}

void Judge::ReceiveOrders() {
   auto take_order = [&]() -> bool {
      auto it = all_order_list_.begin();

      rep(i, O_) {
         assert(it != all_order_list_.end());
         const auto [from, to] = *it;

         rep(b, B_) {
            BridgeMan &bridge_man = bridge_men_list_[b];

            if (bridge_man.order_target_id != -1) continue;  // すでに依頼を受けている

            if (bridge_man.island_id != from) continue;  // 依頼の出発点にいない

            // 依頼を受ける
            bridge_man.order_target_id = to;
            all_order_list_.erase(it);
            return true;
         }

         it++;
      }
      return false;
   };

   while (take_order()) {
   }
}

tuple<int, vector<BridgeMan>, vector<pair<int, int>>> Judge::StartTurn() {
   turn_++;

#ifdef LOCAL_JUDGE
   return StartTurnLocal();
#else
   return StartTurnOnline();
#endif
}

tuple<int, vector<BridgeMan>, vector<pair<int, int>>> Judge::StartTurnLocal() {
   int e_time = chrono::duration_cast<chrono::milliseconds>(chrono::system_clock::now() - start_time_).count();

   vector<BridgeMan> bridge_men_list = bridge_men_list_;
   vector<pair<int, int>> order_list;

   for (auto it = all_order_list_.begin(); it != all_order_list_.end() && (int)order_list.size() < O_; it++) {
      order_list.emplace_back(*it);
   }

   order_list_ = order_list;

   return {e_time, bridge_men_list, order_list};
}

tuple<int, vector<BridgeMan>, vector<pair<int, int>>> Judge::StartTurnOnline() {
   int e_time;
   cin >> e_time;

   rep(i, B_) {
      int island_id, carry_len, target_id;
      cin >> island_id >> carry_len >> target_id;

      bridge_men_list_[i].island_id = island_id;
      bridge_men_list_[i].carry_len = carry_len;
      bridge_men_list_[i].order_target_id = target_id;
   }

   vector<BridgeMan> bridge_men_list = bridge_men_list_;
   vector<pair<int, int>> order_list;

   rep(i, O_) {
      int from, to;
      cin >> from >> to;
      order_list.emplace_back(from, to);
   }

   order_list_ = order_list;

   return {e_time, bridge_men_list, order_list};
}

void Judge::ApplyActions(const vector<Action> &action_list) {
#ifdef LOCAL_JUDGE
   ApplyActionsLocal(action_list);
#else
   ApplyActionsOnline(action_list);
#endif

   HandleOrders();
}

void Judge::ApplyActionsLocal(const vector<Action> &action_list) {
   int L = action_list.size();
   vector<bool> bridge_men_used(B_, false);

   rep(i, L) {
      const Action &action = action_list[i];
      ApplyAction(action);

      if (action.action_type_ == kActionMove) {
         assert(bridge_men_used[action.bridge_man_id1_] == false);
         bridge_men_used[action.bridge_man_id1_] = true;

         move_cnt_++;
      } else if (action.action_type_ == kActionUnpack) {
         assert(bridge_men_used[action.bridge_man_id1_] == false);
         bridge_men_used[action.bridge_man_id1_] = true;

         unpack_cnt_++;
      } else if (action.action_type_ == kActionPack) {
         assert(bridge_men_used[action.bridge_man_id1_] == false);
         bridge_men_used[action.bridge_man_id1_] = true;

         pack_cnt_++;
      } else if (action.action_type_ == kActionTeamUnpack) {
         // チームで橋を架ける
         assert(bridge_men_used[action.bridge_man_id1_] == false);
         assert(bridge_men_used[action.bridge_man_id2_] == false);
         bridge_men_used[action.bridge_man_id1_] = true;
         bridge_men_used[action.bridge_man_id2_] = true;

         team_unpack_cnt_++;
      } else if (action.action_type_ == kActionTeamPack) {
         // チームで橋を撤去する
         assert(bridge_men_used[action.bridge_man_id1_] == false);
         assert(bridge_men_used[action.bridge_man_id2_] == false);
         bridge_men_used[action.bridge_man_id1_] = true;
         bridge_men_used[action.bridge_man_id2_] = true;

         team_pack_cnt_++;
      }
   }
}

void Judge::ApplyActionsOnline(const vector<Action> &action_list) {
   int L = action_list.size();
   stringstream ss;

   vector<bool> bridge_men_used(B_, false);

   rep(i, L) {
      const Action &action = action_list[i];
      ApplyAction(action);

      if (action.action_type_ == kActionMove) {
         assert(bridge_men_used[action.bridge_man_id1_] == false);
         bridge_men_used[action.bridge_man_id1_] = true;

         ss << "MOVE " << action.bridge_man_id1_ << " " << action.island_id_;
         move_cnt_++;
      } else if (action.action_type_ == kActionUnpack) {
         assert(bridge_men_used[action.bridge_man_id1_] == false);
         bridge_men_used[action.bridge_man_id1_] = true;

         ss << "UNPACK " << action.bridge_man_id1_ << " " << action.island_id_;
         unpack_cnt_++;
      } else if (action.action_type_ == kActionPack) {
         assert(bridge_men_used[action.bridge_man_id1_] == false);
         bridge_men_used[action.bridge_man_id1_] = true;

         ss << "PACK " << action.bridge_man_id1_ << " " << action.island_id_;
         pack_cnt_++;
      } else if (action.action_type_ == kActionTeamUnpack) {
         // チームで橋を架ける
         assert(bridge_men_used[action.bridge_man_id1_] == false);
         assert(bridge_men_used[action.bridge_man_id2_] == false);
         bridge_men_used[action.bridge_man_id1_] = true;
         bridge_men_used[action.bridge_man_id2_] = true;

         ss << "TEAMUNPACK " << action.bridge_man_id1_ << " " << action.bridge_man_id2_ << " " << action.island_id_ << " " << action.bridge_len_1_;
         team_unpack_cnt_++;
      } else if (action.action_type_ == kActionTeamPack) {
         // チームで橋を撤去する
         assert(bridge_men_used[action.bridge_man_id1_] == false);
         assert(bridge_men_used[action.bridge_man_id2_] == false);
         bridge_men_used[action.bridge_man_id1_] = true;
         bridge_men_used[action.bridge_man_id2_] = true;

         ss << "TEAMPACK " << action.bridge_man_id1_ << " " << action.bridge_man_id2_ << " " << action.island_id_ << " " << action.bridge_len_1_;
         team_pack_cnt_++;
      }

      if (i != L - 1) ss << "|";
   }

   cout << ss.str() << endl;
}


// clang-format off
#define rep(i, n) for (int i = 0; (i) < (int)(n); (i)++)
#define repp(i, s, n) for (int i = s; (i) < (int)(n); (i)++)

#define ALL(v) begin(v),end(v)
#define RALL(v) rbegin(v),rend(v)

// clang-format on

using namespace std;

SinglePlayer::SinglePlayer(const State &state)
    : State(state), mt_(1234) {
}

vector<Action> SinglePlayer::GetNextActions() {
   IslandBit from_island_bit;
   OrderBit assigned_order_bit;

   // debug_gd(order_list_);

   rep(o, O_) {
      auto [from, to] = order_list_[o];

      if (from_island_bit[from]) {
         // すでに登場している目的地の依頼はskip
         assigned_order_bit[o] = true;
         continue;
      }

      from_island_bit[from] = true;
   }

   rep(b, B_) {
      int order_ind = SetNextBridgemanPlan(b, assigned_order_bit, from_island_bit);
      if (order_ind == -1) continue;

      assigned_order_bit[order_ind] = true;
   }

   vector<Action> action_list;

   rep(b, B_) {
      const Action &action = turn_action_tbl_[b][turn_];
      if (action.action_type_ == kActionIdle || action.action_type_ == kActionWait) continue;

      action_list.emplace_back(action);
   }

   return action_list;
}

int SinglePlayer::SetNextBridgemanPlan(int bridge_man_id, const OrderBit &assigned_order_bit, const IslandBit &from_island) {
   const Action &cur_turn_action = turn_action_tbl_[bridge_man_id][turn_];
   static IslandBit all_ok_island;

   if (cur_turn_action.action_type_ != kActionIdle) {
      // すでに行動が決まっている
      return -1;
   }

   const BridgeMan &bridge_man = bridge_men_list_[bridge_man_id];

   if (bridge_man.order_target_id != -1) {
      // すでに依頼を受けている
      int from = bridge_man.island_id;
      int to = bridge_man.order_target_id;
      auto action_list = CalcSingleAddRemoveWalk(turn_, bridge_man_id, from, to, all_ok_island);

      if (!action_list.empty()) {
         AddSingleTurnAction(bridge_man_id, action_list);
      }

      return -1;
   }

   int cur_island = bridge_man.island_id;
   int cur_cluster = island_cluster_tbl_[cur_island];

   rep(o, O_) {
      if (assigned_order_bit[o]) continue;

      auto [from, to] = order_list_[o];

      int from_cluster = island_cluster_tbl_[from];
      int to_cluster = island_cluster_tbl_[to];

      // debug_gd(bridge_man_id, o, from, to, cur_cluster, from_cluster, to_cluster);

      // 同じクラスタ内の依頼のみ
      if (from_cluster != cur_cluster) continue;
      if (to_cluster != cur_cluster) continue;

      IslandBit avoid_island = from_island;
      avoid_island[from] = false;

      auto action_visit_from = CalcSingleAddRemoveWalk(turn_, bridge_man_id, cur_island, from, avoid_island);
      if (action_visit_from.empty()) continue;

      int turn_from = turn_ + action_visit_from.size();
      auto action_from_to = CalcSingleAddRemoveWalk(turn_from, bridge_man_id, from, to, all_ok_island);
      if (action_from_to.empty()) continue;

      action_visit_from.insert(action_visit_from.end(), ALL(action_from_to));
      bool added = AddSingleTurnAction(bridge_man_id, action_visit_from);

      if (!added) continue;
      return o;
   }

   return -1;
}

#include <bits/stdc++.h>



using namespace std;

// clang-format off
#define rep(i, n) for (int i = 0; (i) < (int)(n); (i)++)
#define repp(i, s, n) for (int i = s; (i) < (int)(n); (i)++)

#define ALL(v) begin(v),end(v)
#define RALL(v) rbegin(v),rend(v)


template<class T> ostream& operator<<(ostream& os, vector<T>& vec){ rep(i, vec.size()) os << vec[i] << (i+1==(int)vec.size() ? "" : " "); return os;}
// clang-format on

pair<State, Judge> LoadProblem();
SearchInfo search_info;
Parameter param;

int main() {
   ios::sync_with_stdio(false);
   std::cin.tie(nullptr);

   auto [state, judge] = LoadProblem();
   SinglePlayer player(state);

   rep(turn, kMaxTurn) {
      debug_mn(turn);
      auto [e_time, bridge_men_list, order_list] = judge.StartTurn();

      player.SetTurnInfo(bridge_men_list, order_list);

      auto action_list = player.GetNextActions();
      judge.ApplyActions(action_list);
   }

   auto [mean_move_cnt, mean_unpack_cnt, mean_pack_cnt, mean_team_unpack_cnt, mean_team_pack_cnt] = judge.GetActionResult();

   cerr << "Result="
        << "dummy"
        << " ";
   cerr << "Score=" << judge.GetScore() << " ";

   cerr << std::fixed << std::setprecision(2);
   cerr << "MeanMoveCnt=" << mean_move_cnt << " ";
   cerr << "MeanUnpackCnt=" << mean_unpack_cnt << " ";
   cerr << "MeanPackCnt=" << mean_pack_cnt << " ";
   cerr << "MeanTeamUnpackCnt=" << mean_team_unpack_cnt << " ";
   cerr << "MeanTeamPackCnt=" << mean_team_pack_cnt << " ";
   cerr << endl;

   return 0;
}

pair<State, Judge> LoadProblem() {
#ifdef LOCAL_JUDGE
   cerr << "Running on LOCAL_JUDGE mode." << endl;

   string def_file_name;
   cin >> def_file_name;

   ifstream cin(def_file_name);
   assert(!cin.fail() && cin.is_open());
#endif

   int N, B, O;
   cin >> N >> B >> O;

   State state(N, B, O);

   vector<vector<int>> island_dist_tbl(N, vector<int>(N, -1));

   rep(i, N) rep(j, N) cin >> island_dist_tbl[i][j];
   state.SetIslandDistTbl(island_dist_tbl);

   Judge judge(state);
   judge.Init();

   return {state, judge};
}

