#include<bits/stdc++.h>
using namespace std;
using ll = long long;
const ll INF = 2e16 ;
const bool debug_mode = false ;
#define debug(var) cerr << #var << " : " << var << endl;

static unsigned int x=123456789,y=362436069,z=521288629,w=88675123;
unsigned int rand32u(){unsigned int t;t=(x^(x<<11));x=y;y=z;z=w;return(w=(w^(w>>19))^(t^(t>>8)));}
ll random(ll MIN,ll MAX){return MIN+ll(rand32u()%(unsigned int)(MAX-MIN));}

class Bridgemen{
public:
    int ID ;
    int Position ;
    int Residue ;
    int Target ;
};
class Order {
public:
    int From ; 
    int To ;
};
//UnionFind
struct UF{
    vector<int> par;
    UF(int n) : par(n){
        for(int i=0;i<n;i++)par[i]=-1;
    }
    int root(ll x){
        return (par[x] == -1) ? x : (par[x] = root(par[x]));
    }
    void comb(int x,int y){
        if(root(x)!=root(y)){
            par[root(x)]=root(y);
        }
    }
    bool same(int x,int y){
        return root(x)==root(y);
    }
};
template <typename T>
void err(T x) {
    if(debug_mode)cerr << x << endl;
} 
const int OUTPUT_LIMIT = 1000 ;
int main() {
    //input
    int N, B, O;
    cin >> N >> B >> O;
    vector<vector<int>> dists(N , vector<int>(N)) ;
    for (int i = 0; i < N; ++i) {
        for (int j = 0; j < N; ++j) {
            cin >> dists[i][j];
        }
    }
    
    auto skip = [&]()->void{
        int elapsedTime ;
        cin >> elapsedTime ;
        for(int i = 0 ; i < B ; i ++ ){
            int a,b,c;cin >> a >> b >> c ;
        }
        for(int i = 0 ; i < O ; i ++ ){
            int a,b;cin >> a >> b ;
        }
    };
    
    int turn = 0 ;
    vector<Order> orders(O) ;
    vector<Bridgemen> bridgemen(B) ;
    auto read = [&]() -> void {
        int elapsedTime ;
        cin >> elapsedTime ;
        for (auto&b : bridgemen) {
            cin >> b.Position >> b.Residue >> b.Target;
        }
        for (int i = 0 ; i < B ; i ++) {
            bridgemen[i].ID = i ;
        }
        for (auto&o : orders){
            cin >> o.From >> o.To ;
        }
    } ;

    //from A to B
    //1. not throw any message (connect1)
    //2. connect 1
    //3. not throw any message (connect2)
    //4. connect 2
    //calculate dp
    vector<vector<ll>> dp1(N , vector<ll>(N,INF)) ;
    vector<vector<ll>> dp2(N , vector<ll>(N,INF)) ;
    vector<vector<ll>> dp3(N , vector<ll>(N,INF)) ;
    vector<vector<ll>> dp4(N , vector<ll>(N,INF)) ;
    vector<vector<ll>> dp_tmp(N , vector<ll>(N,INF)) ;
    //group (distance <= 50)
    UF uf(N) ;
    for (int i = 0 ; i < N ; i ++ ) {
        for (int j = 0 ; j < N ; j ++ ) {
            if (dists[i][j] <= 50) {
                uf.comb(i , j) ;
            }
        }
    }
    auto connect1 = [&] (int i , int j) -> bool {
        return dists[i][j] <= 50 ;
    };
    auto connect2 = [&] (int i , int j) -> bool {
        return (dists[i][j] <= 50 || (100 >= dists[i][j] && dists[i][j] > 50 && !uf.same(i , j))) ;
    };
    //dp2
    for(int i = 0 ; i < N ; i ++ ){
        //from vertex i
        deque<int> dq ;
        dq.push_back(i) ;
        vector<bool> vst(N , false) ;
        dp2[i][i] = 0 ;
        vst[i] = true ;
        while (!dq.empty()) {
            int df = dq.front() ;
            dq.pop_front() ;
            for (int j = 0; j < N ; j ++) {
                if(connect1(df , j) && !vst[j]) {
                    vst[j] = true ;
                    dp2[i][j] = dp2[i][df] + 1 ;
                    dq.push_back(j) ;
                }
            }
        }
    }
    //dp4
    for (int i = 0 ; i < N ; i ++ ) {
        deque<int> dq ;
        dq.push_back(i) ;
        vector<bool> vst(N , false) ;
        dp4[i][i] = 0;
        vst[i] = true ;
        while (!dq.empty()) {
            int df = dq.front() ;
            dq.pop_front() ;
            for (int j = 0; j < N ; j ++) {
                if(connect2(df , j) && !vst[j]) {
                    vst[j] = true ;
                    dp4[i][j] = dp4[i][df] + 1 ;
                    dq.push_back(j) ;
                }
            }
        }
    }
    auto update_dp = [&]() -> void {
        for (int i = 0 ; i < N ; i ++ ) for(int j = 0 ; j < N ; j ++ ) dp_tmp[i][j] = dp1[i][j] = dp3[i][j] = INF ;

        //dp1
        for(int i = 0 ; i < N ; i ++ ){
            //from vertex i
            deque<int> dq ;
            dq.push_back(i) ;
            vector<bool> vst(N , false) ;
            for (auto&o : orders) {
                vst[o.From] = true ;
            }
            dp_tmp[i][i] = 0 ;
            if (vst[i]) {
                dp1[i][i] = 0 ;
                continue ;
            }
            vst[i] = true ;
            while (!dq.empty()) {
                int df = dq.front() ;
                dq.pop_front() ;
                for (int j = 0; j < N ; j ++) {
                    if(connect1(df , j) && !vst[j]) {
                        vst[j] = true ;
                        dp_tmp[i][j] = dp_tmp[i][df] + 1 ;
                        dq.push_back(j) ;
                    }
                }
            }
            for (auto&o : orders) {
                //iからo.Fromに行く
                for (int j = 0 ; j < N ; j ++ ) {
                    if(connect1(o.From , j)) {
                        dp1[i][o.From] = 
                    min(dp1[i][o.From] , dp_tmp[i][j] + 1) ;
                    }
                }
            }
        }
        
        //dp3
        dp_tmp.assign(N , vector<ll>(N,INF)) ;
        for(int i = 0 ; i < N ; i ++ ){
            //from vertex i
            deque<int> dq ;
            dq.push_back(i) ;
            vector<bool> vst(N , false) ;
            for (auto&o : orders) {
                vst[o.From] = true ;
            }
            dp_tmp[i][i] = 0 ;
            if (vst[i]) {
                dp3[i][i] = 0 ;
                continue ;
            }
            vst[i] = true ;
            while (!dq.empty()) {
                int df = dq.front() ;
                dq.pop_front() ;
                for (int j = 0; j < N ; j ++) {
                    if(connect2(df , j) && !vst[j]) {
                        vst[j] = true ;
                        dp_tmp[i][j] = dp_tmp[i][df] + 1 ;
                        dq.push_back(j) ;
                    }
                }
            }
            for (auto&o : orders) {
                //iからo.Fromに行く
                for (int j = 0 ; j < N ; j ++ ) {
                    if(connect2(j , o.From)){
                        dp3[i][o.From] = 
                    min(dp3[i][o.From] , dp_tmp[i][j] + 1) ;
                    }
                }
            }
        }
    };
    vector<vector<pair<string,vector<int>>>> output(OUTPUT_LIMIT) ;

    auto print_output = [&]() -> bool {
        int i = 0 ;
        for( ; turn < OUTPUT_LIMIT && !output[i].empty() ; i ++ , turn ++ ){
            if (i > 0) skip() ;
            for (size_t j = 0 ; j < output[i].size() ; j ++ ) {
                cout << output[i][j].first << " " ;
                for (size_t k = 0 ; k < output[i][j].second.size() ; k ++ ) {
                    cout << output[i][j].second[k] ;
                    if (k + 1 < output[i][j].second.size()) cout << ' ' ;
                }
                cout << ((j + 1 < output[i].size())?"|":"") ;
            }
            output[i].clear() ;
            cout << endl ;
        }
        if (turn == OUTPUT_LIMIT) exit(0) ;
        return i == 0 ;

    } ;
    while(true) {
        read() ;
        update_dp() ;
        //at first, move someone to "from"
        vector<set<pair<ll , ll>>> connected(OUTPUT_LIMIT) ;//if other bridgeman already built bridge
        for (auto&o : orders) {
            int best_bridgeman = -1 ;
            ll best_cost = INF ;
            for (auto&b : bridgemen) {
                if (b.Target != -1) continue ; //this bridgeman already received message
                ll tmp = dp1[b.Position][o.From];
                if (tmp < best_cost) {
                    best_cost = tmp ;
                    best_bridgeman = b.ID ;
                }
            }
            if (best_cost <= 2) {
                int clock = 0 ;
                int now_vertex = bridgemen[best_bridgeman].Position ;
                while (now_vertex != o.From) {
                    int next_vertex = -1 ;
                    ll min_cost = INF ;
                    for (int i = 0 ; i < N ; i ++ ) {
                        if (dp1[i][o.From] + 1 == dp1[now_vertex][o.From] && connect1(now_vertex , i)) {
                            if (dp1[i][o.From] < min_cost) {
                                min_cost = dp1[i][o.From] ;
                                next_vertex = i ;
                            }
                        }
                    }
                    //push to output
                    if (connected[clock / 3].find({now_vertex , next_vertex}) == connected[clock / 3] .end()){
                        output[clock].push_back({"UNPACK" , {best_bridgeman , next_vertex}}) ;
                        output[clock+1].push_back({"MOVE" , {best_bridgeman , next_vertex}}) ;
                        output[clock+2].push_back({"PACK" , {best_bridgeman , now_vertex}}) ;
                    } else {
                        output[clock+1].push_back({"MOVE" , {best_bridgeman , next_vertex}}) ;
                    }
                    connected [clock / 3] .insert ({now_vertex , next_vertex}) ;
                    connected [clock / 3] .insert ({next_vertex , now_vertex}) ;
                    clock += 3 ;
                    now_vertex = next_vertex ;
                }
                bridgemen[best_bridgeman].Target = o.From ;
            }
        }
        if(!print_output()) {
            read() ;
            update_dp() ;
        }

        vector<tuple<int,int,int>> todo ; //bring , trg_from , trg_to
        vector<int> final_clock(B,0) ;
        for (auto&b : bridgemen) {
            if (b.Target != -1) {
                //this message must be delivered in this turn
                todo.push_back({b.ID , b.Position , b.Target}) ;
            }
        }

        if(todo.empty()) {
            //find minimum cost path to deliver
            Order bo ;
            int bi = -1 ;
            ll bd = INF ;
            for (auto& o : orders) {
                if (dp2[o.From][o.To] < INF) {
                    for (int i = 0 ; i < B ; i ++ ) {
                        if (bridgemen[i].Target != -1) continue ; //this bridgeman already received message
                        ll tmp = dp1[bridgemen[i].Position][o.From] + dp2[o.From][o.To] ;
                        if (tmp < bd) {
                            bd = tmp ;
                            bi = i ;
                            bo = o ;
                        }
                    }
                }
            }
            if (bi != -1) {
                todo.push_back({bi , bo.From , bo.To}) ;
            }
            if (todo.empty()) {
                for (auto& o : orders) {
                    if (dp4[o.From][o.To] < INF ) {
                        for (int i = 0 ; i < B ; i ++ ) {
                            if (bridgemen[i].Target != -1) continue ; //this bridgeman already received message
                            ll tmp = dp3[bridgemen[i].Position][o.From] + dp4[o.From][o.To] ;
                            if (tmp < bd) {
                                bo = o ;
                                bd = tmp ;
                                bi = i ;
                            }
                        }
                    }
                }
                if (bi != -1) {
                    todo.push_back({bi , bo.From , bo.To}) ;
                }
            }
        }

        for (auto&c:connected) c.clear() ;
        bool morethan_one = (todo.size() > 1) ;
        vector<bool> visited(N , false) ;
        for (auto [bring , trg_from , trg_to] : todo) {
            if (morethan_one) {
                //todoに入っているものがすべてtrg_fromまで到達している場合のみ対応
                trg_from = bridgemen[bring].Position ;
            }
            err(to_string(bring) + " is going to deliver from " + to_string(trg_from) + " to " + to_string(trg_to)) ;
            int clock = final_clock[bring] ;
            //a. make path
            vector<int> path ;
            {
                int ni = bridgemen[bring].Position ;
                path.push_back(ni) ;
                //while going to trg_from, it is not allowed to throw other messages
                bool flg2 = true ;
                while (ni != trg_from) {
                    bool flg = true ;
                    for (int i = 0 ; i < N ; i ++ ) {
                        if (dp1[i][trg_from] + 1 == dp1[ni][trg_from] && connect1(ni , i)) {
                            ni = i ;
                            path.push_back(ni) ;flg = false ;
                            break ;
                        }
                    }
                    if (flg){
                        flg2 = false ;
                        break ;
                    }
                }
                if (flg2) {
                    while (ni != trg_to) {
                        bool flg = true ;
                        for (int i = 0 ; i < N ; i ++ ) {
                            if (dp2[i][trg_to] + 1 == dp2[ni][trg_to] && connect1(ni , i)) {
                                ni = i ;
                                path.push_back(ni) ;flg = false ;
                                break ;
                            }
                        }
                        if (flg) {
                            flg2 = false ;
                            break ;
                        }
                    }
                }
                if (!flg2) {
                    path.clear() ;
                    int ni = bridgemen[bring].Position ;
                    path.push_back(ni) ;
                    while (ni != trg_from) {
                        for (int i = 0 ; i < N ; i ++ ) {
                            if (dp3[i][trg_from] + 1 == dp3[ni][trg_from] && connect2(ni , i)) {
                                ni = i ;
                                path.push_back(ni) ;
                                break ;
                            }
                        }
                    }
                    while (ni != trg_to) {
                        for (int i = 0 ; i < N ; i ++ ) {
                            if (dp4[i][trg_to] + 1 == dp4[ni][trg_to] && connect2(ni , i)) {
                                ni = i ;
                                path.push_back(ni) ;
                                break ;
                            }
                        }
                    }
                }

            }
            //b. move
            for (int i = 0 ; i < path.size() - 1 ; i ++ ) {
                int a_i = path[i] ;
                int b_i = path[i+1] ;
                //from a_i to b_i
                if (dists[a_i][b_i] > 50) {
                    //need help to cross
                    //someone collect to b_i
                    int best_help = -1 ;
                    ll best_cost = INF ;
                    for (int i = 0 ; i < B ; i ++ ) {
                        if (i == bring) continue ;
                        ll tmp = dp2[bridgemen[i].Position][b_i] + final_clock[i] ;
                        if (tmp < best_cost) {
                            best_cost = tmp ;
                            best_help = i ;
                        }
                    }
                    int i = best_help ;
                    int nv = bridgemen[i].Position ;
                    int a_clock = final_clock[i] ;
                    while (nv != b_i) {
                        for (int j = 0 ; j < N ; j ++ ) {
                            if (dp2[j][b_i] + 1 == dp2[nv][b_i] && connect1(nv , j)) {
                                if (connected[a_clock/3].find({nv , j}) == connected[a_clock/3].end()) {
                                    output[a_clock].push_back({"UNPACK" , {i,j}}) ;
                                    output[a_clock+1].push_back({"MOVE" , {i,j}}) ;
                                    output[a_clock+2].push_back({"PACK" , {i,nv}}) ;
                                } else {
                                    output[a_clock+1].push_back({"MOVE" , {i,j}}) ;
                                }
                                if (bridgemen[i].Target == -1) visited[j] = true ;
                                connected[a_clock/3].insert({nv , j}) ;
                                connected[a_clock/3].insert({j , nv}) ;
                                a_clock += 3 ;
                                nv = j ;
                                break ;
                            }
                        }
                    }
                    clock = max(clock , a_clock) ;
                    if (connected[clock/3].find({a_i , b_i}) == connected[clock/3].end()) {
                        output[clock].push_back({"TEAMUNPACK" , {i,bring,50}}) ;
                        output[clock+1].push_back({"MOVE" , {i,a_i}}) ;
                        output[clock+1].push_back({"MOVE" , {bring,b_i}}) ;
                        output[clock+2].push_back({"TEAMPACK" , {i,bring,50}}) ;
                    } else {
                        output[clock+1].push_back({"MOVE" , {i,a_i}}) ;
                        output[clock+1].push_back({"MOVE" , {bring,b_i}}) ;
                    }
                    connected[clock/3].insert({a_i , b_i}) ;
                    connected[clock/3].insert({b_i , a_i}) ;
                    bridgemen[i].Position = a_i ;
                    bridgemen[bring].Position = b_i ;
                    clock += 3 ;
                    final_clock[i] = final_clock[bring] = clock ;
                } else {
                    if (connected[clock/3].find({a_i , b_i}) == connected[clock/3].end()) {
                        output[clock].push_back({"UNPACK" , {bring,b_i}}) ;
                        output[clock+1].push_back({"MOVE" , {bring,b_i}}) ;
                        output[clock+2].push_back({"PACK" , {bring,a_i}}) ;
                    }
                    else {
                        output[clock+1].push_back({"MOVE" , {bring,b_i}}) ;
                    }
                    connected[clock/3].insert({a_i , b_i}) ;
                    connected[clock/3].insert({b_i , a_i}) ;
                    bridgemen[bring].Position = b_i ;
                    clock += 3 ;
                    final_clock[bring] = clock ;
                }
            }
            err ("success: " + to_string(bring) + " could go to " + to_string(trg_to)) ;
        }
        int output_length = 0 ;
        while(output[output_length].size()) output_length ++ ;
        //use free bridgemen to recieve message
        for (auto& o : orders) {
            if (visited[o.From]) continue ;
            ll best_clock = INF ;
            int best_bridgeman = -1 ;
            for (int i = 0 ; i < B ; i ++ ) {
                ll tmp = dp1[bridgemen[i].Position][o.From] + final_clock[i] ;
                if (tmp < best_clock) {
                    best_clock = tmp ;
                    best_bridgeman = i ;
                }
            }
            if (best_bridgeman != -1) {
                int clock = final_clock[best_bridgeman] ;
                int nv = bridgemen[best_bridgeman].Position ;
                while (nv != o.From && clock < output_length) {
                    for (int j = 0 ; j < N ; j ++ ) {
                        if (dp1[j][o.From] + 1 == dp1[nv][o.From] && connect1(nv , j)) {
                            if (connected[clock/3].find({nv , j}) == connected[clock/3].end()) {
                                output[clock].push_back({"UNPACK" , {best_bridgeman,j}}) ;
                                output[clock+1].push_back({"MOVE" , {best_bridgeman,j}}) ;
                                output[clock+2].push_back({"PACK" , {best_bridgeman,nv}}) ;
                            }
                            else {
                                output[clock+1].push_back({"MOVE" , {best_bridgeman,j}}) ;
                            }
                            connected[clock/3].insert({nv , j}) ;
                            connected[clock/3].insert({j , nv}) ;
                            clock += 3 ;
                            nv = j ;
                            break ;
                        }
                    }
                }
                bridgemen[best_bridgeman].Position = o.From ;
                final_clock[best_bridgeman] = clock ;
                visited[o.From] = true ;
            }
        }

        //rust
        if(print_output() || turn == OUTPUT_LIMIT) {
            //end
            int elapsedTime ;
            cin >> elapsedTime ;
            for (auto&b : bridgemen) {
                int c;
                cin >> b.Position >> b.Residue >> c;
            }
            for (int i = 0 ; i < B ; i ++) {
                bridgemen[i].ID = i ;
            }
            for (auto&o : orders){
                cin >> o.From >> o.To ;
            }
            for (int i = 0 ; i < N ; i ++ ){
                for (int k = 0 ; k < B ; k ++ ){
                    if(bridgemen[k].Position == i)continue ;
                    if(dists[bridgemen[k].Position][i] <= 50){
                        int j = 0 ;
                        for ( ; turn < OUTPUT_LIMIT ; turn ++ ) {
                            if(j%2==0)cout << "UNPACK " << k << " " << i << endl ;
                            else      cout << "PACK "   << k << " " << bridgemen[k].Position << endl ;
                            cout << flush ;
                            skip() ;
                            j ++ ;
                        }
                        return 0;
                    }
                }
            }
            return 0;
        } 
    }



    return 0;
}
