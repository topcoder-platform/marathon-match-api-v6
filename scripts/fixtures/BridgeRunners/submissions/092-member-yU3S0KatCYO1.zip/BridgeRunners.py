import numpy as np

import sys

print(sys.version)

import sklearn
