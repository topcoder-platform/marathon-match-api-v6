#include <iostream>
#include <vector>
#include <string>
#include <sstream>
#include <numeric>
#include <algorithm>
using namespace std;

class Bridgeman {
public:
    int ID;
    int Position;
    int Target;
    int Bricks;
    int BridgeFrom = -1;
    int BridgeTo = -1;
};

class Order {
public:
    int From;
    int To;
};

static int g_seed = 777778;
static int Rand(int mod) {
    g_seed = (214013 * g_seed + 2531011);
    return ((g_seed >> 16) & 0x7FFF) % mod;
}

int main() {
    int N, B, O, cc=0;
    std::cin >> N >> B >> O;

    int dists[N][N], path[N][N], prv[N][N], c[N], blk[B];
    bool connected[N][N], was[N];
    for (int i = 0; i < N; ++i) {
        c[i] = -1;
        for (int j = 0; j < N; ++j) {
            connected[i][j]=false;
            std::cin >> dists[i][j];
        }
    }

    // Connect 50-components + calculate dists
    const int DINF=1000000;
    vector<pair<int,int>> pairs[N][N];
    for (int i=0; i<N; i++) {
        bool new_cc=(c[i]==-1);
        if (new_cc) c[i]=cc;
        for (int j=0; j<N; j++) {
          path[i][j]=DINF*100;
          prv[i][j]=-1;
          was[j]=false;
        }
        path[i][i]=0;
        prv[i][i]=i;
        while (true) {
            int best=-1;
            for (int j=0; j<N; j++) if (was[j]==false && (best==-1 || path[i][j]<path[i][best])) best=j;
            was[best]=true;
            if (best==-1) break;
            for (int j=0; j<N; j++) if (dists[best][j]<=50 && path[i][best]+1<path[i][j]) {
                path[i][j]=path[i][best]+1;
                if (new_cc && c[j]==-1 && path[i][j]<DINF) c[j]=cc;
                prv[i][j]=best;
            } else if (dists[best][j]<=100 && path[i][best]+DINF<path[i][j]) {
                path[i][j]=path[i][best]+DINF;
                prv[i][j]=best;
            }
        }
        if (new_cc) ++cc;
    }
    for (int i=0; i<N; i++) for (int j=0; j<N; j++)
        if (dists[i][j]>50 && dists[i][j]<=100 && c[i]!=c[j]) pairs[c[i]][c[j]].emplace_back(i,j);

    Bridgeman bridgemen[B];
    vector<int> q[B];
    for (int i = 0; i < B; ++i) {
        bridgemen[i].ID = i;
        blk[i] = -1;
    }

    //for (int i=0; i<N; i++) cerr << "c[" << i << "] = " << c[i] << '\n';

    for (int turn = 1; turn <= 1000; turn++) {
        int elapsedTime;
        std::cin >> elapsedTime;
        for (int i = 0; i < B; ++i) {
            std::cin >> bridgemen[i].Position >> bridgemen[i].Bricks >> bridgemen[i].Target;
            if (q[i].empty() && bridgemen[i].Target != -1 && bridgemen[i].Bricks >= 50) {
                int cx = c[bridgemen[i].Position];
                if (c[bridgemen[i].Target] == c[bridgemen[i].Position]) {
                    for (int x=bridgemen[i].Target; x!=bridgemen[i].Position; x=prv[bridgemen[i].Position][x]) {
                        //cerr << bridgemen[i].Target << " -> " << bridgemen[i].Position << " via " << x << '\n';
                        q[i].push_back(x);
                    }
                } else {
                    int best=DINF*100,wx=-1,wy=-1,wj=-1;
                    for (int j=i-1; j>=0; j--) if (q[j].empty() && bridgemen[j].Bricks >= 50) {
                        int cy = c[bridgemen[j].Position];
                        for (const auto& [vx, vy] : pairs[cx][cy]) {
                            int cur=max(path[bridgemen[i].Position][vx], path[bridgemen[j].Position][vy])+max(path[vy][bridgemen[j].Position], path[vx][bridgemen[i].Position]);
                            if (cur<best) {
                                best=cur;
                                wx=vx;
                                wy=vy;
                                wj=j;
                            }
                        }
                    }
                    if (wj!=-1) {
                        q[i].push_back(wy);
                        for (int x=wx; x!=bridgemen[i].Position; x=prv[bridgemen[i].Position][x]) q[i].push_back(x);
                        // TODO: clear and retarget j if needed
                        q[wj].push_back(wx);
                        for (int x=wy; x!=bridgemen[wj].Position; x=prv[bridgemen[wj].Position][x]) q[wj].push_back(x);
                        //cerr << "MEET " << i << " " << wj << " @ " << wx << "," << wy << '\n';
                    }
                }
            }
        }

        /*for (int i = 0; i < B; ++i) {
            cerr<<i<<":";
            for (int v: q[i]) cerr<<" " << v;
            cerr <<'\n';
        }*/

        // move to some message if empty?
        std::vector<Order> orders(O);
        for (int i = 0; i < O; ++i) {
            std::cin >> orders[i].From >> orders[i].To;
        }

        std::vector<std::string> output;
        vector<int> unblk;
        for (int i=0; i<N; i++) if (blk[i]>i) {
            if (q[i].empty()) {
                output.push_back("TEAMPACK " + to_string(i) + ' ' + to_string(blk[i]) + " 50");
                unblk.push_back(i);
                unblk.push_back(blk[i]);
                connected[bridgemen[i].Position][bridgemen[blk[i]].Position] = false;
                connected[bridgemen[blk[i]].Position][bridgemen[i].Position] = false;
            } else {
                output.push_back("MOVE " + std::to_string(bridgemen[i].ID) + " " + std::to_string(q[bridgemen[i].ID].back()));
                output.push_back("MOVE " + std::to_string(bridgemen[blk[i]].ID) + " " + std::to_string(q[bridgemen[blk[i]].ID].back()));
                q[bridgemen[i].ID].pop_back();
                q[bridgemen[blk[i]].ID].pop_back();
            }
        }
        for (int i=0; i<N; i++) if (blk[i]==-1) {
            Bridgeman& b = bridgemen[i];
            if (b.Bricks < 50 && b.BridgeFrom != b.Position) {
                // if combined else
                output.push_back("PACK " + std::to_string(b.ID) + " " + std::to_string(b.BridgeFrom));
                connected[b.BridgeFrom][b.BridgeTo] = false;
                connected[b.BridgeTo][b.BridgeFrom] = false;
                b.BridgeFrom = -1;
                b.BridgeTo = -1;
            } else if (!q[b.ID].empty()) {
                //cerr << "TRY " << b.ID << ": conn[" << b.Position << "][" << q[b.ID].back() << "] = " << int(connected[b.Position][q[b.ID].back()]) << '\n';
                if (connected[b.Position][q[b.ID].back()]) {
                    output.push_back("MOVE " + std::to_string(b.ID) + " " + std::to_string(q[b.ID].back()));
                    q[b.ID].pop_back();
                } else if (dists[b.Position][q[b.ID].back()] <= 50) {
                    output.push_back("UNPACK " + std::to_string(b.ID) + " " + std::to_string(q[b.ID].back()));
                    b.BridgeFrom = b.Position;
                    b.BridgeTo = q[b.ID].back();
                    connected[b.BridgeFrom][b.BridgeTo] = true;
                    connected[b.BridgeTo][b.BridgeFrom] = true;
                } else for (int j=i+1; j<N; j++) if (blk[j]==-1 && bridgemen[j].Position==q[b.ID].back() && b.Position==q[bridgemen[j].ID].back()) {
                    output.push_back("TEAMUNPACK " + to_string(b.ID) + ' ' + to_string(j) + " 50");
                    connected[b.Position][bridgemen[j].Position] = true;
                    connected[bridgemen[j].Position][b.Position] = true;
                    blk[i]=j;
                    blk[j]=b.ID;
                }
            } else if (b.BridgeFrom == -1) { // unpack
                std::vector<int> targets;
                for (int t = 0; t < N; ++t) {
                    if (t != b.Position && !connected[b.Position][t] && dists[b.Position][t] <= b.Bricks) {
                        targets.push_back(t);
                    }
                }
                if (!targets.empty()) {
                    int t = targets[Rand(targets.size())];
                    output.push_back("UNPACK " + std::to_string(b.ID) + " " + std::to_string(t));
                    b.BridgeFrom = b.Position;
                    b.BridgeTo = t;
                    connected[b.BridgeFrom][b.BridgeTo] = true;
                    connected[b.BridgeTo][b.BridgeFrom] = true;
                }
            } else if (b.BridgeFrom == b.Position) { // MOVE
                output.push_back("MOVE " + std::to_string(b.ID) + " " + std::to_string(b.BridgeTo));
            } else { // PACK
                output.push_back("PACK " + std::to_string(b.ID) + " " + std::to_string(b.BridgeFrom));
                connected[b.BridgeFrom][b.BridgeTo] = false;
                connected[b.BridgeTo][b.BridgeFrom] = false;
                b.BridgeFrom = -1;
                b.BridgeTo = -1;
            }
        }
        for (int i: unblk) blk[i]=-1;

        // SORT?
        for (size_t i = 0; i < output.size(); ++i) {
            std::cout << output[i];
            if (i < output.size() - 1) {
                std::cout << " | ";
            }
        }
        std::cout << std::endl;

        /*for (size_t i = 0; i < output.size(); ++i) {
            std::cerr << output[i];
            if (i < output.size() - 1) {
                std::cerr << " | ";
            }
        }
        std::cerr << std::endl;*/

    }

    return 0;
}