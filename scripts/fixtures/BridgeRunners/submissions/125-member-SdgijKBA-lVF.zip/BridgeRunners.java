import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

class BridgeRunnersV69 {

    private static int g_seed = 777778;

    private static int rand(int mod) {
        g_seed = (214013 * g_seed + 2531011);
        return ((g_seed >> 16) & 0x7FFF) % mod;
    }

    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        int N = Integer.parseInt(reader.readLine());
        int B = Integer.parseInt(reader.readLine());
        int O = Integer.parseInt(reader.readLine());

        Map<Integer,Set<Integer>> reachableFrom = new HashMap<>();

        int[][] dists = new int[N][N];
        boolean[][] connected = new boolean[N][N];
        for (int i = 0; i < N; i++) {
            reachableFrom.put(i,new HashSet<>());
            String[] line = reader.readLine().split(" ");
            for (int j = 0; j < N; j++) {
                dists[i][j] = Integer.parseInt(line[j]);
            }
        }

        for (int i = 0; i < N-1; i++) {
            for (int j = i+1; j < N; j++) {
                if (dists[i][j] <= 50) {
                    reachableFrom.get(i).add(j);
                    reachableFrom.get(j).add(i);
                }
            }
        }

        for (int i = 0; i < N; i++) {
            Deque<Integer> q = new ArrayDeque<>(reachableFrom.get(i));
            while (! q.isEmpty()) {
                int current = q.pollFirst();
                for (int j : reachableFrom.get(current)) {
                    if (!reachableFrom.get(i).contains(j)) {
                        q.add(j);
                        reachableFrom.get(i).add(j);
                    }
                }
            }

        }

        HashMap<Integer, Integer> commands = new HashMap<>();


        List<Bridgeman> bridgemen = IntStream.range(0, B)
                .mapToObj(Bridgeman::new)
                .collect(Collectors.toList());

        for (int turn = 1; turn <= 1000; turn++) {
            int elapsedTime = Integer.parseInt(reader.readLine());
            for (int i = 0; i < B; i++) {
                String[] line = reader.readLine().split(" ");
                bridgemen.get(i).position = Integer.parseInt(line[0]);
                bridgemen.get(i).bricks = Integer.parseInt(line[1]);
                bridgemen.get(i).target = Integer.parseInt(line[2]);
            }
            //List<Order> orders = new ArrayList<>();
            Order[] orders = new Order[O];
            HashMap<Integer,Integer> allFroms = new HashMap<>();
            for (int i = 0; i < O; i++) {
                String[] line = reader.readLine().split(" ");
                Order o = new Order(Integer.parseInt(line[0]), Integer.parseInt(line[1]));
                orders[i] = o;//.add(o);
                allFroms.put(o.from, o.to);
            }
            ArrayList<Integer> availableForBridges = new ArrayList<>();
            HashSet<Integer> shouldNotPlay = new HashSet<>();

            List<String> output = new ArrayList<>();

            int[] takenOrders = new int[O];
            Arrays.fill(takenOrders, -1);

            boolean[] haveNoTargetInitially = new boolean[B];

            for (int j = 0; j < B; j++) {
                if (shouldNotPlay.contains(j)) continue;
                Bridgeman b = bridgemen.get(j);
                //System.err.println("b.bricks : " + b.bricks);
                haveNoTargetInitially[j] = b.target == -1;

                if (b.bridgeFrom == -1) { // unpack
                    boolean hasNoTargetInitially = b.target == -1;
                    if (hasNoTargetInitially) {
                        int target = -1;//0;//b.target;
                        int bestScore = Integer.MAX_VALUE;

                        for (int i = 0; i < O; i++) {
                            if (reachableFrom.get(orders[i].from).contains(b.position) && reachableFrom.get(orders[i].from).contains(orders[i].to)) {

                                if (takenOrders[i] == -1 || dists[orders[i].from][b.position] < dists[orders[i].from][bridgemen.get(takenOrders[i]).position]) {
                                //if (!takenOrders[i] )
                                int score = dists[b.position][orders[i].from] + dists[orders[i].to][orders[i].from];

                                if (score < bestScore) {
                                    bestScore = score;
                                    target = i;//orders[i].from;//i
                                }
                            }
                            }
                        }

                        if (target == -1) {
                            for (int i = 0; i < O; i++) {
                                int score = dists[b.position][orders[i].from] + dists[orders[i].to][orders[i].from];

                                if (reachableFrom.get(orders[i].from).contains(b.position) && reachableFrom.get(orders[i].from).contains(orders[i].to) && score < bestScore) {
                                    bestScore = score;
                                    target = i;//orders[i].from;//i
                                }
                            }
                        }




                        if (target == -1) {


                            for (int i = 0; i < O; i++) {
                                if (reachableFrom.get(orders[i].from).contains(orders[i].to)) {

                                    if (takenOrders[i] == -1 || dists[orders[i].from][b.position] < dists[orders[i].from][bridgemen.get(takenOrders[i]).position]) {
                                        //if (!takenOrders[i] )
                                        int score = dists[b.position][orders[i].from] + dists[orders[i].to][orders[i].from];

                                        if (score < bestScore) {
                                            bestScore = score;
                                            target = i;//orders[i].from;//i
                                        }
                                    }
                                }
                            }


                        }

                        if (target == -1) {
                            for (int i = 0; i < O; i++) {
                                int score = dists[b.position][orders[i].from] + dists[orders[i].to][orders[i].from];

                                if (reachableFrom.get(orders[i].from).contains(orders[i].to) && score < bestScore) {
                                    bestScore = score;
                                    target = i;//orders[i].from;//i
                                }
                            }
                        }





                        if (target == -1) {


                            for (int i = 0; i < O; i++) {
                                if (reachableFrom.get(orders[i].from).contains(b.position)) {

                                    if (takenOrders[i] == -1 || dists[orders[i].from][b.position] < dists[orders[i].from][bridgemen.get(takenOrders[i]).position]) {
                                        //if (!takenOrders[i] )
                                        int score = dists[b.position][orders[i].from] + dists[orders[i].to][orders[i].from];

                                        if (score < bestScore) {
                                            bestScore = score;
                                            target = i;//orders[i].from;//i
                                        }
                                    }
                                }
                            }


                        }

                        if (target == -1) {
                            for (int i = 0; i < O; i++) {
                                int score = dists[b.position][orders[i].from] + dists[orders[i].to][orders[i].from];

                                if (reachableFrom.get(orders[i].from).contains(b.position) && score < bestScore) {
                                    bestScore = score;
                                    target = i;//orders[i].from;//i
                                }
                            }
                        }


                        if (target == -1) {
                            for (int i = 0; i < O; i++) {

                                    if (takenOrders[i] == -1 || dists[orders[i].from][b.position] < dists[orders[i].from][bridgemen.get(takenOrders[i]).position]) {
                                        //if (!takenOrders[i] )
                                        int score = dists[b.position][orders[i].from] + dists[orders[i].to][orders[i].from];

                                        if (score < bestScore) {
                                            bestScore = score;
                                            target = i;//orders[i].from;//i
                                        }
                                    }
                                }
                            }



                    if (target == -1) {
                        for (int i = 0; i < O; i++) {
                            int score = dists[b.position][orders[i].from] + dists[orders[i].to][orders[i].from];

                            if (score < bestScore) {
                                bestScore = score;
                                target = i;//orders[i].from;//i
                            }
                        }
                    }


                        if (takenOrders[target] == -1 || dists[orders[target].from][bridgemen.get(j).position] < dists[orders[target].from][bridgemen.get(takenOrders[target]).position])
                            takenOrders[target] = j;
                        b.target = orders[target].from;
                    }

                    int bestScore = Integer.MAX_VALUE;
                    int best = -1;

                    // maintenant que j'ai une cible, creer l'edge available qui m'en rapproche le plus
                    for (int t = 0 ; t < N ; t++) {
                            if (t != b.target && hasNoTargetInitially && allFroms.containsKey(t) && !reachableFrom.get(t).contains(allFroms.get(t))) {
                                continue;
                            }
                            if (t != b.position && !connected[b.position][t] && dists[b.position][t] <= b.bricks && dists[b.target][t] <= bestScore) {
                                bestScore = dists[b.target][t];
                                best = t;

                            }
                    }

                    if (best > -1) { //&& dists[b.position][best] <= b.bricks) {
                        output.add("UNPACK " + b.id + " " + best);
                        b.bridgeFrom = b.position;
                        b.bridgeTo = best;
                        connected[b.bridgeFrom][b.bridgeTo] = true;
                        connected[b.bridgeTo][b.bridgeFrom] = true;
                    } else {
                        availableForBridges.add(j);
                    }

                } else if (b.bridgeFrom == b.position) { // MOVE
                    output.add("MOVE " + b.id + " " + b.bridgeTo);
                } else if (!commands.containsKey(b.id)) { // PACK
                    output.add("PACK " + b.id + " " + b.bridgeFrom);
                    connected[b.bridgeFrom][b.bridgeTo] = false;
                    connected[b.bridgeTo][b.bridgeFrom] = false;
                    b.bridgeFrom = -1;
                    b.bridgeTo = -1;
                } else {
                    int b1id = commands.get(b.id);
                    Bridgeman b1 = bridgemen.get(b1id);
                    output.add("TEAMPACK " + b.id + " " + b1.id + " " + 50);
                    commands.remove(j);
                    commands.remove(b1id);
                    System.err.println("TEAMPACK " + b.id + " " + b1.id + " " + 50);
                    System.err.println("TEAMPACK " + j + " " + b1id);
                    System.err.flush();
                    shouldNotPlay.add(b1id);

                    connected[b1.bridgeFrom][b1.bridgeTo] = false;
                    connected[b1.bridgeTo][b1.bridgeFrom] = false;
                    connected[b.bridgeFrom][b.bridgeTo] = false;
                    connected[b.bridgeTo][b.bridgeFrom] = false;
                    b1.bridgeFrom = -1;
                    b.bridgeFrom = -1;
                    b.bridgeTo = -1;
                    b1.bridgeTo = -1;
                }
            }

            int L = availableForBridges.size();
            HashSet<Integer> used = new HashSet<>();

            if (L > 1) {
                // todo random shuffle availableForBridges histoire d'eviter de faire plusieurs pairings useless
                Collections.shuffle(availableForBridges);

                for (int j = 0; j < L-1; j++) {
                    if (!used.contains(j)) {
                        Bridgeman b = bridgemen.get(availableForBridges.get(j));
                        for (int j1 = j+1; j1 < L; j1++) {
                            if (!used.contains(j1)) {
                                Bridgeman b1 = bridgemen.get(availableForBridges.get(j1));
                                boolean cd = reachableFrom.get(b1.position).contains(b.target) || reachableFrom.get(b.position).contains(b1.target);
                                boolean cd1 = cd || b.target == b1.position || b1.target == b.position || (allFroms.containsKey(b.position) && haveNoTargetInitially[b1.id]) || (allFroms.containsKey(b1.position) && haveNoTargetInitially[b.id]);
                                if (cd1 && !connected[b1.position][b.position] && dists[b1.position][b.position] <= 100 && b.position != b1.position && !reachableFrom.get(b.position).contains(b1.position)) {
                                    output.add("TEAMUNPACK " + Math.min(b.id,b1.id) + " " + Math.max(b.id,b1.id) + " " + 50);
                                    System.err.println("TEAMUNPACK " + b.id + " " + b1.id + " " + 50);
                                    System.err.println("TEAMUNPACK " + j + " " + j1 + " " + 50);

                                    b.bridgeFrom = b.position;
                                    b.bridgeTo = b1.position;
                                    connected[b.bridgeFrom][b.bridgeTo] = true;
                                    connected[b.bridgeTo][b.bridgeFrom] = true;

                                    b1.bridgeFrom = b1.position;
                                    b1.bridgeTo = b.position;
                                    connected[b1.bridgeFrom][b1.bridgeTo] = true;
                                    connected[b1.bridgeTo][b1.bridgeFrom] = true;
                                    commands.put(b.id, b1.id);
                                    commands.put(b1.id, b.id);
                                    used.add(j);
                                    used.add(j1);
                                    break;

                                }

                            }
                        }
                    }
                }
            }


            System.err.println(String.join(" | ", output));
            System.out.println(String.join(" | ", output));
        }
    }


    static class Bridgeman {
        int id;
        int position;
        int target;
        int bricks = 50;

        int bridgeFrom = -1;
        int bridgeTo = -1;

        public Bridgeman(int id) {
            this.id = id;
        }
    }

    static class Order {
        int from;
        int to;

        public Order(int from, int to) {
            this.from = from;
            this.to = to;
        }
    }
}