#include <iostream>
#include <vector>
#include <string>
#include <sstream>
#include <numeric>
#include <algorithm>
using namespace std  ;
#include "hung.cpp"

int elapsedTime  ;
const int infinity = 1000000  ;

const int construct_bridge_to_nearest_order_start = 2  ;
const int cross_bridge_to_nearest_order_start     = 3 ;
const int gather_bridge_to_nearest_order_start    = 4 ;
const int construct_bridge_to_order_end  = 6 ;
const int cross_bridge_to_order_end      = 7 ;
const int gather_bridge_to_order_end     = 8 ;
// **************************************************************************
// **************************************************************************
class Man {
// **************************************************************************
public:
int id ;
int position ;
int order_end ;
int bridge_segments_carried ;
int bridge_from = -1 ;
int bridge_to = -1 ;
int long_bridge_other = -1 ;
bool long_bridge_crossed = false ;
int bridge_turn = -1 ;
int order = -1 ;
vector<int> plan ;
int total_bridge_segments ;
vector<int> goal ;

void set_goal ( int g )
{ if ( g < 0 )
   goal.resize ( 0 ) ;
 goal.resize ( 1 ) ;
 goal [0] = g ;
} ;
// **************************************************************************
} ; // end class Man
// **************************************************************************

class Order {
// **************************************************************************
public:
int from ;
int to ;
} ;
// **************************************************************************

static int g_seed = 777778 ;
// **************************************************************************
static int Rand ( int mod )
// **************************************************************************
{
 g_seed = (214013 * g_seed + 2531011) ;
 return ((g_seed >> 16) & 0x7FFF) % mod ;
} ;
// **************************************************************************

int N, B, Oh ;
Man                          men [ 20 ] ;
int                          count_cc = 0 ;
int                          cc [80] ;
std::vector<Order>           orders(Oh) ;
int                          dists[80][80] ;
int         overflow_buffer [1000000] ;
bool                         connected [80] [80] ;
vector<vector<vector<int>>>  hops ;
vector<vector<vector<int>>>  next_island ;
std::vector<std::string>     output ;
vector<string>               sorted_output ;
int turn ;

// **************************************************************************
int union_cc ( int i , int j )
// **************************************************************************
{
 int cn ;
 if ( i > j )
    swap ( i , j ) ;   // i <= j 
 cc[j] = cc[i] ;       // j -> not bigger
 cn = cc[j] ;
 if ( cc[i] != i )
    {
    cn = union_cc ( cc[i] , i ) ;
    i = cc[i] ;
    }
 cc [i] = cn ;
 return cn ;
}
// **************************************************************************
int find_cc ( int i )
// **************************************************************************
{
 int cn = cc[i] ;
 if ( cn != i )
    cn = find_cc ( cn ) ;
 cc[i] = cn ;
 return cn ;
} ;
// **************************************************************************
int calc_components ( ) // union find connected components algorithm
// **************************************************************************
{
 for ( int n = 0 ; n < N ; ++n )
    cc[n] = n ;

 for ( int i = 0 ; i < N ; ++i )
    for ( int j = 0 ; j < N ; ++j )
       if ( dists [i] [j] <= 50 )
	  union_cc ( find_cc(i) , j ) ;
 count_cc = 0 ;
 for ( int i = 0 ; i < N ; ++i )
    if ( find_cc (i) == i )
       ++count_cc ;
 return count_cc ;
}
// **************************************************************************
void cerr_NxN ( const vector<vector<int>> & hops , string title = ""  )
// **************************************************************************
{
 cerr << title << endl << "    " ;
 for ( int j = 0 ; j < N ; ++j )
    if ( j < 10 )
       cerr << j << "  " ;
    else
       cerr << j << " " ;
 cerr << endl ;
 for ( int i = 0 ; i < N ; ++i )
    {
    if ( i < 10 )
       cerr << i << " : " ;
    else
       cerr << i << ": " ;
    for ( int j = 0 ; j < N ; ++j )
       if ( hops [i][j] < infinity )
	  {
	  if ( hops [i] [j] < 10 )
	     cerr << hops [i] [j] << "  " ;
	  else
	     cerr << hops [i] [j] << " " ;
	  }
       else
	  cerr << ".  " ;
    cerr << endl ;
    }
 cerr << endl ;
} ;
// **************************************************************************
void calc_shortest_paths ( int length_limit , vector<vector<int>> & hops ,
			   vector<vector<int>> & next_island )
// **************************************************************************
{
//cerr << "calculating shortest paths " << endl << flush ;
 for ( int i = 0 ; i < N ; ++i )
    for ( int j = 0 ; j < N ; ++j )
       {
       hops [i][j] = infinity ;   // fill infinity
       }
 for ( int i = 0 ; i < N ; ++i )
    for ( int j = 0 ; j < N ; ++j )
       if ( dists [i] [j] > length_limit )
	  {
	  hops [i] [j] = infinity ;  // too far connection = infinity
	  }
       else if ( dists [i] [j] <= length_limit && dists [i] [j] <= 50 )
	  {
	  hops [i] [j] = 1 ;  // direct connection = 1
	  }
       else if ( dists [i] [j] <= 100 && dists [i][j] <= length_limit )
	  hops [i] [j] = 100 ;  // long connection = 100

 for ( int j = 0 ; j < N ; ++j )
    {
    hops [j][j] = 0 ;
    next_island [j][j] = j ;  // self connection = 0
    }

 for ( int k = 0 ; k < N ; ++k )
    for ( int i = 0 ; i < N ; ++i )    // Floyd-Warshall
       for ( int j = 0 ; j < N ; ++j )
      	  if ( hops [i][j] > hops[i][k] + hops [k][j] )
	     {
	     hops [i][j] = hops[i][k] + hops [j][k] ;
	     }

for ( int i = 0 ; i < N ; ++i )
   for ( int j = 0 ; j < N ; ++j )  // backtrack to find next island in shortest path
       {
       if ( hops [i][j] <= 1 || hops [i][j] == 100 )
	  next_island [i][j] = j ;
       else if ( hops [i][j] < infinity )
	  {
	  int best_next = -1 ;
	  int min_d = infinity ;
	  for ( int k = 0 ; k < N ; ++k )
	     {
	     if ( k != i && k != j && (hops [i][k] == 100 || hops [i][k] == 1 ) &&  hops [i][k] + hops [k][j] < min_d )
		{
		min_d = hops[i][k] + hops [k][j] ;
		best_next = k ;
		}
	     }
	  next_island [i][j] = best_next ;
	  }
       else
	  {
	  //cerr << i << " unreachable from " << j << endl ;
	  next_island [i][j] = -1 ;
	  }
       }
 
// cerr_NxN ( hops , "hops" ) ;
// cerr_NxN ( next_island , "next island" ) ;
} ;
// **************************************************************************
void send_move ( const vector<string> & move )
// **************************************************************************
{
 string line ;
 for ( int i = 0 ; i < sorted_output.size() ; ++i )
    {
    if ( sorted_output[i].size() > 3 )
       line += sorted_output[i] + " | " ;
    }

 if ( line.size() > 3 )
    line.resize ( line.size() - 3 ) ;
		  
 // std::cerr << "   turn " << turn << "    sending: " << turn << " " << line << std::endl ;
 std::cout << line << std::endl ;
} ;
// **************************************************************************
void init ( )
// **************************************************************************
{
 std::cin >> N >> B >> Oh ;

 orders.resize ( Oh ) ;
 for ( int i = 0 ; i < N ; ++i )
    {
    for ( int j = 0 ; j < N ; ++j )
       {
       connected [i] [j] = false ; // bridge built
       std::cin >> dists [i] [j] ;
       }
    }
 
 for (int i = 0 ; i < B ; ++i )
    {
    men[i].id = i ;
    men[i].plan.push_back ( construct_bridge_to_nearest_order_start ) ;
    men[i].total_bridge_segments = 50 ;
    }

 hops.resize(121) ;
 next_island.resize(121) ;
 for ( int n = 40 ; n < 120 ; ++n )
    {
    hops [n] . resize ( N ) ;
    next_island [n] . resize ( N ) ;
    for ( int i = 0 ; i < N ; ++i )
       {
       hops [n] [i].resize ( N ) ;
       next_island [n] [i].resize ( N ) ;
       }
    calc_shortest_paths ( n , hops[n] , next_island [n] ) ;
    }

 output.resize ( B ) ;
calc_components ( ) ;
// cerr << count_cc << " connected components in graph[50]" << endl ;
 turn = 1 ;
} ;
// **************************************************************************
void read_turn ( )
// **************************************************************************
{
 std::cin >> elapsedTime ;
 for (int i = 0 ; i < B ; ++i )
    {
    std::cin >> men[i].position
	     >> men[i].bridge_segments_carried
	     >> men[i].order_end ;
    }
 for (int i = 0 ; i < Oh ; ++i )
    {
    std::cin >> orders[i].from >> orders[i].to ;
    }
} ;
// **************************************************************************
void nearest_order ( Man & b , int & next_is , int & closest_start ,
		     int & closest_end , int & min_hops )
// **************************************************************************
{
//  if ( b.id == -1 )  cerr << "nearest order" << endl ;
 next_is = -1 ;
 closest_start = -1 ;
 closest_end = -1 ;
 min_hops = infinity ;
 int b_limit = b.total_bridge_segments ;
 for ( int t = 0 ; t < Oh ; ++t )
    {
    //    if ( b.id == -1 ) cerr << "t " << t << " from " << orders[t].from << " limit " << b_limit << endl ;
    int ot = orders [t].from ;
    int d = hops [b_limit] [b.position] [ot] ; // + hops [b_limit] [orders[t].from] [orders[t].to] ;
    if ( d < min_hops )
       {
       min_hops = d ;
       closest_start = ot ;
       closest_end   = orders[t].to ;
       next_is = next_island [b_limit] [b.position] [ot] ;
       }
    }
} ;
// **************************************************************************
void construct_long_bridge ( vector<string> & output , Man & b1 , Man & b2 )
// **************************************************************************
{
 if ( output[b1.id].size() == 0 && output[b2.id].size() == 0 )
    {
    //cerr << "construct long bridge " << b.position << " " + std::to_string(to) << endl ;
    output [b1.id] = ( "TEAMUNPACK " + std::to_string(b1.id) + " " + std::to_string(b2.id) + " 50" ) ;
    sorted_output.push_back ( output[b1.id] ) ;
    output [b2.id] = " " ;
    // cerr << output [b1.id] << endl ;
    
    b1.bridge_from = b1.position ;
    b1.bridge_to = b2.position ;
    b2.bridge_from = b2.position ;
    b2.bridge_to = b1.position ;
    b1.long_bridge_other = b2.id ;
    b2.long_bridge_other = b1.id ;
    b1.long_bridge_crossed = false ;
    b2.long_bridge_crossed = false ;
    b1.bridge_turn = turn ;
    b2.bridge_turn = turn ;
    
    connected [b1.position] [b2.position] = true ;
    connected [b2.position] [b1.position] = true ;
    }
} ;
// **************************************************************************
void gather_long_bridge ( vector<string> & output , Man & b1 , Man & b2 )
// **************************************************************************
{
 if ( output [b1.id].size() == 0 && output [b2.id].size() == 0 )
    {
    //cerr << "long bridge gather " << b.position << " " + std::to_string(to) << endl ;
    output[b1.id] = ( "TEAMPACK " + std::to_string(b1.id) + " " + std::to_string(b2.id) + " " +
		      to_string ( 50 - b1.bridge_segments_carried ) ) ;
    sorted_output.push_back ( output[b1.id] ) ;
    output [b2.id] = " " ;
    // cerr << output [b1.id] << endl ;

    b1.bridge_from = -1 ;
    b1.bridge_to = -1 ;
    b2.bridge_from = -1 ;
    b2.bridge_to = -1 ;
    b1.long_bridge_other = -1 ;
    b2.long_bridge_other = -1 ;
    b1.long_bridge_crossed = false ;
    b2.long_bridge_crossed = false ;
    
    connected [b1.position] [b2.position] = false ;
    connected [b2.position] [b1.position] = false ;
    }
} ;
// **************************************************************************
void construct ( vector<string> & output , Man & b , int to )
// **************************************************************************
{
 if ( output[b.id].size() == 0 && b.position != to )
    {
    // cerr << "construct " << b.position << " " + std::to_string(to) << endl ;
    output[b.id] = ( "UNPACK " + std::to_string(b.id) + " " + std::to_string(to) ) ;
    sorted_output.push_back ( output[b.id] ) ;
    b.bridge_from = b.position ;
    b.bridge_to = to ;
    connected [b.position] [to] = true ;
    connected [to] [b.position] = true ;

    b.bridge_segments_carried -= dists [b.position] [to] ;
    b.bridge_turn = turn ;
    }
} ;
// **************************************************************************
void move ( vector<string> & output , Man & b , int to )
// **************************************************************************
{
 if ( output[b.id].size() == 0 && b.position != to )
    {
    output[b.id] = ( "MOVE " + std::to_string(b.id) + " " + std::to_string(to) ) ;
    sorted_output.push_back ( output[b.id] ) ;
    }
} ;
// **************************************************************************
void gather ( vector<string> & output , Man & b )
// **************************************************************************
{
 if ( output[b.id].size() == 0 )
    {
    if ( b.bridge_to >= 0 && dists [ b.bridge_to ] [ b.bridge_from] > 50 )
       {
       cerr << "gather failed id  = " << b.id << " dist " << dists [ b.bridge_to ] [ b.bridge_from] << endl ;
       return ;
       }
    if ( b.bridge_from == b.position )
       {
       output[b.id] = ( "PACK " + std::to_string(b.id) + " " +
			std::to_string(b.bridge_to) ) ;
       sorted_output.push_back ( output[b.id] ) ;
       }
    else if ( b.bridge_to == b.position )
       {
       output[b.id] = ( "PACK " + std::to_string(b.id) + " " +
			std::to_string(b.bridge_from) ) ;
       sorted_output.push_back ( output[b.id] ) ;
       }
    else
       cerr << "invalid gather " << b.id << " from " << b.bridge_from << " to " << b.bridge_to
	    << " pos " << b.position << endl ;
    connected [b.bridge_to] [b.bridge_from] = false ;
    connected [b.bridge_from] [b.bridge_to] = false ;
    b.bridge_to = b.bridge_from = -1 ;
    }
} ;
// **************************************************************************
// int ** hung_cost ;
int * assignment ;
int * goals ;
int hung_size ;
// **************************************************************************
void alloc_hung_matrix ( )
// **************************************************************************
{
 hung_size = max ( B , Oh ) ;
 assignment = new int [hung_size] ;
 goals = new int [hung_size] ;
 hung_cost = hung_allocate2d ( hung_size , hung_size ) ;
} ;
// **************************************************************************
void assign ( )
// **************************************************************************
{
// cerr << "assignment matrix size " << hung_size << endl ;
//   for ( int w = 0 ; w < hung_size ; ++w )
//      {
//      for ( int j = 0 ; j < hung_size ; ++j )
// 	cerr << hung_cost [j][w] << " " ;
//      cerr << endl ;
//      }
 
  for ( int worker = 0 ; worker < hung_size ; ++worker )
    {
    // cerr << "W " << worker << " "  ;
    if ( worker >= B )                                 // dummy worker, all job costs = infinity
       {
       for ( int job = 0 ; job < hung_size ; ++job )
	  {
	  hung_cost [job] [worker] = infinity ;
	  // cerr << "infinity " ;
	  }
       }
    else                                                // real worker
       {
       if ( men[worker].order_end > -1 )          // worker preassigned to job cost = 0 
	  {
	  for ( int job = 0 ; job < hung_size ; ++job )  // all orders = infinity
	     hung_cost [job] [worker] = infinity ;
	  for ( int job = Oh ; job < hung_size ; ++job ) // all dummy jobs = 0   take any dummy job, preassignment filled in later
	     hung_cost [job] [worker] = 0 ;
	  // for ( int j = 0 ; j < hung_size ; ++j )
	  //    cerr << hung_cost [j][worker] << " " ;
	  }
       else                                             // real worker, no assignemnt
	  {
	  for ( int job = 0 ; job < hung_size ; ++job ) // no preassigned coal
	     hung_cost [job] [worker] = infinity ;      // dummy goals = infinity
	  for ( int job = 0 ; job < Oh ; ++job )        // available goals = actual cost
	     if ( hops [50] [men[worker].position] [orders[job].from] < 100 )
		  hung_cost [job] [worker] = hops [50] [men[worker].position] [orders[job].from] ;
	  // for ( int j = 0 ; j < hung_size ; ++j )
	  //    cerr << hung_cost [j][worker] << " " ;
	  }
       }
    // cerr << endl ;
    }

  // for ( int w = 0 ; w < hung_size ; ++w )
  //    {
  //    for ( int j = 0 ; j < hung_size ; ++j )
  // 	cerr << hung_cost [j][w] << " " ;
  //    cerr << endl ;
  //    }

  //*******************  
  int total_cost = hung ( hung_cost , hung_size , hung_size , assignment ) ;
  //*******************  

 //  cerr << endl ;
 // for ( int a = 0 ; a < hung_size ; ++a )
 //    cerr << assignment [a] << " " ;
 // cerr << endl ;

 for ( int worker = 0 ; worker < B ; ++worker )
    {
    if ( men [worker].order_end > -1 )
       men [worker] . set_goal ( men [worker] . order_end ) ;
    else if (assignment[worker] < Oh && assignment[worker] >= 0 ) 
       men [worker] . set_goal ( orders[assignment [worker]].from ) ;
    else
       men [worker] . set_goal ( -1 ) ;
    }

 //  cerr << "assignments " ;
 //  for ( int w = 0 ; w < B ; ++w )
 //    cerr << men [w].goal[0] << " " ;
 // cerr << endl ;
} ;
// **************************************************************************
// **************************************************************************
int man_at ( int n )
// **************************************************************************
{
 for ( int b = 0 ; b < B ; ++b )
    if ( men[b].position == n )
       return b ;
 return -1 ;
} ;
// **************************************************************************
int man_in_cc ( int comp , int desired_return_cc )
// **************************************************************************
{
 int other = -1 ;
 for ( int b = 0 ; b < B ; ++b )
    if ( cc [ men[b].position ] == comp )
       other = b ;
 for ( int b = 0 ; b < B ; ++b )
    if ( cc [ men[b].position ] == comp &&
	 men[b].goal.size() > 0 && cc [ men[b].goal[0] ] == desired_return_cc )
       other = b ;
 return other ;
} ;
// **************************************************************************
int long_bridge_assigned ( int island )
// **************************************************************************
{
 for ( int b = 0 ; b < B ; ++b )
    if ( cc[men[b].position] == cc [island] &&
	 men[b].goal.size() > 0 && men[b].goal[0] == island )
       return b ;
 return -1 ;
} ;
// **************************************************************************
void build_loose_long_bridges ( )
// **************************************************************************
{
 for ( int bi1 = 0 ; bi1 < B ; ++bi1 )  // try long bridges with different cc orders first
    {
    for ( int bi2 = 0 ; bi2 < B ; ++bi2 ) if ( bi1 != bi2 )
       {
       Man & b1 = men [bi1] ;
       Man & b2 = men [bi2] ;
       int p1 = b1.position ;
       int p2 = b2.position ;
       // if ( bi1 == 0 && bi2 == 14 )
       // 	  cerr << "connected [" << p1 << "] [" << p2 << "] = " << connected [p1][p2] << endl ;
       if ( ! connected [p1] [p2] )                   // not already connected
	  {
	  int d = dists [p1] [p2] ;
	  // if ( bi1 == 0 && bi2 == 14 )
	  //    cerr << "dist = " << dists[p1][p2] << endl ;
	  if ( d > 50 && d <= 100 )                    // long bridge distance
	     {
	     // if ( bi1 == 0 && bi2 == 14 )
	     // 	cerr << "carried " << b1.bridge_segments_carried << " "
	     // 	     << b2.bridge_segments_carried << endl ;
	     if ( b1.bridge_segments_carried == 50 &&  // full of segments
		  b2.bridge_segments_carried == 50 )
		{
		// if ( bi1 == 0 && bi2 == 14 )
		//    {
		//    cerr << "(end1 " << b1.order_end << " > 1 && cc["
		// 	<< p2 << "] = " << cc[p2] << " == cc[" << b1.order_end << "] = " << cc[b1.order_end] << " && ("
		// 	<< " end2 " << b2.order_end << " < 0 || cc["
		// 	<< p1 << "] = " << cc[p1] << " == cc[" << b2.order_end << "] = " << cc[b2.order_end] << ") ) || " << endl ;

		//    cerr << "(end2 " << b2.order_end << " > 1 && cc["
		// 	<< p1 << "] = " << cc[p1] << " == cc[" << b2.order_end << "] = " << cc[b2.order_end] << " && ("
		// 	<< " end1 " << b1.order_end << " < 0 || cc["
		// 	<< p2 << "] = " << cc[p2] << " == cc[" << b1.order_end << "] = " << cc[b1.order_end] << ") )" << endl ;
		//    }
		
		   // ( b2.order_end < 0 || cc[p1] == cc[b2.order_end] ) ) ||
		   //   ( b2.order_end > -1 && cc[p1] == cc[b2.order_end]  &&
		   //     ( b1.order_end < 0 || cc[p2] == cc[b1.order_end] ) ) )

		// if ( ( b1.order_end > -1 && cc[p2] == cc[b1.order_end] && cc[p1] != cc[p2] &&
		//        ( b2.order_end < 0 || cc[p2] != cc[b2.order_end] ) ) )
		if ( ( b1.order_end > -1 && cc[p1] != cc[p2] &&
		       ( b2.order_end < 0 || cc[p2] != cc[b2.order_end] ) ) )
		   {
		   // cerr << "building cross cc long bridge " << bi1 << " " << bi2 << endl ;
		   construct_long_bridge ( output , b1 , b2 ) ;
		   }
		}
	     }
	  }
       }
    }
 for ( int bi1 = 0 ; bi1 < B ; ++bi1 )   // all possible long bridges
    {
    for ( int bi2 = bi1+1 ; bi2 < B ; ++bi2 )
       {
       Man & b1 = men [bi1] ;
       Man & b2 = men [bi2] ;
       int p1 = b1.position ;
       int p2 = b2.position ;
       
       if ( cc[p1] != cc[p2] )
	  continue ;
       
       // if ( bi1 == 0 && bi2 == 14 )
       // 	  cerr << "connected [" << p1 << "] [" << p2 << "] = " << connected [p1][p2] << endl ;
       if ( ! connected [p1] [p2] )                   // not already connected
	  {
	  int d = dists [p1] [p2] ;
	  // if ( bi1 == 0 && bi2 == 14 )
	  //    cerr << "dist = " << dists[p1][p2] << endl ;
	  if ( d > 50 && d <= 100 )                    // long bridge distance
	     {
	     // if ( bi1 == 0 && bi2 == 14 )
	     // 	cerr << "carried " << b1.bridge_segments_carried << " "
	     // 	     << b2.bridge_segments_carried << endl ;
	     if ( b1.bridge_segments_carried == 50 &&  // full of segments
		  b2.bridge_segments_carried == 50 )
		{
		int goal1 = b1.goal[0] ;
		int gain1 = 0 ;
		int goal2 = b2.goal[0] ;
		int gain2 = 0 ;
		if ( goal1 > -1 )                 
		   {
		   gain1 = hops [100] [p1] [goal1] - hops [100] [p2] [goal1] ;
		   }
		if ( goal2 > -1 )
		   {
		   gain2 = hops [100] [p2] [goal2] - hops [100] [p1] [goal2] ;
		   }
		// if ( bi1 == 0 && bi2 == 14 )
		//    cerr << "gains " << gain1 << " " << gain2 << endl ;
		if ( gain1 + gain2 > 0 )     // is shorter than not building it
		   {
		   // cerr << "building inter cc long bridge" << endl ;
		   construct_long_bridge ( output , b1 , b2 ) ;
		   }
		}
	     }
	  }
       }
    }
} ;
// **************************************************************************
void build_long_bridges ( )
// **************************************************************************
{
 for ( int bi1 = 0 ; bi1 < B ; ++bi1 )  // try long bridges with different cc orders first
    {
    for ( int bi2 = bi1+1 ; bi2 < B ; ++bi2 )
       {
       Man & b1 = men [bi1] ;
       Man & b2 = men [bi2] ;
       int p1 = b1.position ;
       int p2 = b2.position ;
       // if ( bi1 == 0 && bi2 == 14 )
       // 	  cerr << "connected [" << p1 << "] [" << p2 << "] = " << connected [p1][p2] << endl ;
       if ( ! connected [p1] [p2] )                   // not already connected
	  {
	  int d = dists [p1] [p2] ;
	  // if ( bi1 == 0 && bi2 == 14 )
	  //    cerr << "dist = " << dists[p1][p2] << endl ;
	  if ( d > 50 && d <= 100 )                    // long bridge distance
	     {
	     // if ( bi1 == 0 && bi2 == 14 )
	     // 	cerr << "carried " << b1.bridge_segments_carried << " "
	     // 	     << b2.bridge_segments_carried << endl ;
	     if ( b1.bridge_segments_carried == 50 &&  // full of segments
		  b2.bridge_segments_carried == 50 )
		{
		// if ( bi1 == 0 && bi2 == 14 )
		//    {
		//    cerr << "(end1 " << b1.order_end << " > 1 && cc["
		// 	<< p2 << "] = " << cc[p2] << " == cc[" << b1.order_end << "] = " << cc[b1.order_end] << " && ("
		// 	<< " end2 " << b2.order_end << " < 0 || cc["
		// 	<< p1 << "] = " << cc[p1] << " == cc[" << b2.order_end << "] = " << cc[b2.order_end] << ") ) || " << endl ;

		//    cerr << "(end2 " << b2.order_end << " > 1 && cc["
		// 	<< p1 << "] = " << cc[p1] << " == cc[" << b2.order_end << "] = " << cc[b2.order_end] << " && ("
		// 	<< " end1 " << b1.order_end << " < 0 || cc["
		// 	<< p2 << "] = " << cc[p2] << " == cc[" << b1.order_end << "] = " << cc[b1.order_end] << ") )" << endl ;
		//    }
		
		   // ( b2.order_end < 0 || cc[p1] == cc[b2.order_end] ) ) ||
		   //   ( b2.order_end > -1 && cc[p1] == cc[b2.order_end]  &&
		   //     ( b1.order_end < 0 || cc[p2] == cc[b1.order_end] ) ) )
		if ( ( b1.order_end > -1 && cc[p2] == cc[b1.order_end] && cc[p1] != cc[p2] &&
		       ( b2.order_end < 0 || cc[p1] == cc[b2.order_end] ) ) ||
		     ( b2.order_end > -1 && cc[p1] == cc[b2.order_end] && cc[p1] != cc[p2] &&
		       ( b1.order_end < 0 || cc[p2] == cc[b1.order_end] ) ) )
		   {
		   // cerr << "building cross cc long bridge " << bi1 << " " << bi2 << endl ;
		   construct_long_bridge ( output , b1 , b2 ) ;
		   }
		}
	     }
	  }
       }
    }
 for ( int bi1 = 0 ; bi1 < B ; ++bi1 )   // all possible long bridges
    {
    for ( int bi2 = bi1+1 ; bi2 < B ; ++bi2 )
       {
       Man & b1 = men [bi1] ;
       Man & b2 = men [bi2] ;
       int p1 = b1.position ;
       int p2 = b2.position ;
       
       if ( cc[p1] != cc[p2] )
	  continue ;
       
       // if ( bi1 == 0 && bi2 == 14 )
       // 	  cerr << "connected [" << p1 << "] [" << p2 << "] = " << connected [p1][p2] << endl ;
       if ( ! connected [p1] [p2] )                   // not already connected
	  {
	  int d = dists [p1] [p2] ;
	  // if ( bi1 == 0 && bi2 == 14 )
	  //    cerr << "dist = " << dists[p1][p2] << endl ;
	  if ( d > 50 && d <= 100 )                    // long bridge distance
	     {
	     // if ( bi1 == 0 && bi2 == 14 )
	     // 	cerr << "carried " << b1.bridge_segments_carried << " "
	     // 	     << b2.bridge_segments_carried << endl ;
	     if ( b1.bridge_segments_carried == 50 &&  // full of segments
		  b2.bridge_segments_carried == 50 )
		{
		int goal1 = b1.goal[0] ;
		int gain1 = 0 ;
		int goal2 = b2.goal[0] ;
		int gain2 = 0 ;
		if ( goal1 > -1 )                 
		   {
		   gain1 = hops [100] [p1] [goal1] - hops [100] [p2] [goal1] ;
		   }
		if ( goal2 > -1 )
		   {
		   gain2 = hops [100] [p2] [goal2] - hops [100] [p1] [goal2] ;
		   }
		// if ( bi1 == 0 && bi2 == 14 )
		//    cerr << "gains " << gain1 << " " << gain2 << endl ;
		if ( gain1 + gain2 > 0 )     // is shorter than not building it
		   {
		   // cerr << "building inter cc long bridge" << endl ;
		   construct_long_bridge ( output , b1 , b2 ) ;
		   }
		}
	     }
	  }
       }
    }
} ;
// **************************************************************************
void cross_long_bridges ( )
// **************************************************************************
{
 for ( int bi1 = 0 ; bi1 < B ; ++bi1 )  // original builders cross
    {
    
    // if ( output[13] != "" )
    //    cerr << "            a output[13] =   " << output[13] << endl ;

    for ( int bi2 = bi1+1 ; bi2 < B ; ++bi2 )
       {
       // cerr << "trying " << bi1 << " " << bi2 << endl ;
       Man & b1 = men [bi1] ;
       Man & b2 = men [bi2] ;
       int p1 = b1.position ;
       int p2 = b2.position ;
       // if ( bi1 == 0 && bi2 == 14 )
       // 	  cerr << "connected [" << p1 << "] [" << p2 << "] = " << connected [p1][p2] << endl ;
       if ( connected [p1] [p2] )                   // already connected
	  {
	  int d = dists [p1] [p2] ;
	  // if ( bi1 == 0 && bi2 == 14 )
	  //    cerr << "dist = " << dists[p1][p2] << endl ;
	  if ( d > 50 && d <= 100 )                 // long bridge distance
	     {
	     // if ( bi1 == 0 && bi2 == 14 )
	     // 	cerr << men[b1.long_bridge_other].id << " == " << bi2 << " && "
	     // 	     << men[b2.long_bridge_other].id << " == " << bi1 << " && "
	     // 	     << "! " << b1.long_bridge_crossed << " && ! " << b2.long_bridge_crossed << " && "
	     // 	     << b1.bridge_turn << " < " << turn << " && " << b2.bridge_turn << " < " << turn << endl ;
	     if ( men[b1.long_bridge_other].id == bi2 &&
		  men[b2.long_bridge_other].id == bi1 &&
		  ! b1.long_bridge_crossed && ! b2.long_bridge_crossed &&
		  b1.bridge_turn < turn && b2.bridge_turn < turn )
		{
		move ( output , b1 , p2 ) ;
		move ( output , b2 , p1 ) ;
		// cerr << "long move " << bi1 << " " << bi2 << " " << output[bi1] << " " << output[bi2] << endl ;
		b1.long_bridge_crossed = true ;
		b2.long_bridge_crossed = true ;
		}
	     }
	  }
       }
    }
 // for ( int bi1 = 0 ; bi1 < B ; ++bi1 )  // cross random builders
 //    {
 //    // if ( output[13] != "" )
 //    //    cerr << "            b output[13] =   " << output[13] << endl ;
 //    // cerr << "trying " << bi1 << " " << endl ;
 //    Man & b1 = men [bi1] ;
 //    int p1 = b1.position ;
 //    // cerr << "position " << p1 << " carried " << b1.bridge_segments_carried << endl ;
 //    if ( b1.bridge_segments_carried == 50 && b1.bridge_turn < turn )
 //       {
 //       for ( int p2 = 0 ; p2 < N ; ++p2 )
 // 	  {
 // 	  if ( p1 != p2 )
 // 	     {
 // 	     // if ( p1 == 15)
 // 	     // 	cerr << "         ----   " << p1 << " " << p2 << " connected " << connected [p1] [p2] << endl ;
 // 	     if ( connected [p1] [p2] && b1.goal.size() > 0 && b1.goal[0] > -1 )
 // 		{
 // 		if ( hops [100] [p1] [b1.goal[0]] > hops [100] [p2] [b1.goal[0]] )
 // 		   {
 // 		   move ( output , b1 , p2 ) ;
 // 		   }
 // 		}
 // 	     }
 // 	  }
 //       }
 //    }
} ;
// **************************************************************************
void gather_long_bridges ( )
{
 for ( int bi1 = 0 ; bi1 < B ; ++bi1 )   // all possible long bridges
    {
    for ( int bi2 = bi1+1 ; bi2 < B ; ++bi2 )
       {
       Man & b1 = men [bi1] ;
       Man & b2 = men [bi2] ;
       int p1 = b1.position ;
       int p2 = b2.position ;
       if ( connected [p1] [p2] )                   // already connected
	  {
	  if ( b1.long_bridge_other == bi2 &&
	       b2.long_bridge_other == bi1 &&
	       b1.long_bridge_crossed &&
	       b2.long_bridge_crossed &&
	       ( b1.bridge_segments_carried + b2.bridge_segments_carried +
		 dists [p1] [p2] ) == 100 )
	     {
	     gather_long_bridge ( output , b1 , b2 ) ;
	     // cerr << "long gather " << b1.id << " " << b2.id << " " << output[bi1] << endl ;
	     }
	  }
       }
    }
} ;
// **************************************************************************
// **************************************************************************
int main()
// **************************************************************************
{
 int debug_id = 0 ;
 
 init ( ) ;
 alloc_hung_matrix ( ) ;
 for ( turn = 0 ; turn < 1000 ; turn++ )
    {
    //cerr << "                                                turn " << turn << endl ;
    read_turn ( ) ;
    assign() ;
    for ( int i = 0 ; i < B ; ++i )
       output[i] = "" ;
    sorted_output.resize(0) ;

    if ( count_cc > 1 )
       {
       build_long_bridges ( ) ;
       cross_long_bridges ( ) ;
       gather_long_bridges ( ) ;
       }
    
    if ( turn > 75 && turn < 65 )
       {
       cerr << connected [0] [10] << endl ;
       }






    for ( int bi = 0 ; bi < B ; ++bi ) // regular moves within one connected component
       {
       if ( output [bi] == "" )
	  {
	  //cerr << "construct " << bi << endl ;
	  Man & b = men[bi] ;
	  int pos = b.position ;
	  
	  int best_i = -1 ;
	  if ( b.bridge_segments_carried == 50 && b.goal.size() > 0 && b.goal[0] > -1 )
	     {
	     best_i = next_island [100][pos][b.goal[0]] ;
	     if ( best_i > -1 )
		{
		if ( dists [pos] [best_i] <= 50 )
		   {
		   if ( connected [pos] [best_i] )
		      move ( output , b , best_i ) ;
		   else
		      construct ( output , b , best_i ) ;
		   }
		}
	     }
	  }
       }


    for ( int bi = 0 ; bi < B ; ++bi ) // regular moves within one connected component
       {
       //cerr << "move " << bi << endl ;
       Man & b = men[bi] ;
       int pos = b.position ;
       if ( b.bridge_from == pos && connected [b.bridge_to] [b.bridge_from] )
	  move ( output , b , b.bridge_to ) ;
       }
    
	     
    for ( int bi = 0 ; bi < B ; ++bi ) // regular moves within one connected component
       {
       //cerr << "gather " << bi << endl ;
       Man & b = men[bi] ;
       int pos = b.position ;
       if ( b.bridge_to == pos && connected [b.bridge_to] [b.bridge_from] )
	  gather ( output , b ) ;
       }

    if ( sorted_output.size() == 0 )
       build_loose_long_bridges ( ) ;
    
    //    cerr << "next turn " << endl ;


       









    
    // for ( int bi = 0 ; bi < B ; ++bi ) // regular moves within one connected component
    //    if ( output [bi] == "" )
    //    {
       
    //    Man & b = men[bi] ;
    //    int b_limit = b.total_bridge_segments ;
    //    int best_i , best_to , best_from , best_d ;

    //    // if ( 0*bi == 0*debug_id )
    //    // 	  {
    //    // 	  cerr << "bridgeman " << b.id << " at " << b.position << " going to " ;
    //    // 	  for ( int g = 0 ; g < b.goal.size() ; ++g )
    //    // 	     cerr << b.goal[g] << " " ;
    //    // 	  cerr << "bridge " << b.bridge_from << " to " << b.bridge_to
    //    // 	       << " carrying " << b.bridge_segments_carried ;
    //    // 	  if ( b.goal.size() > 0 )
    //    // 	     cerr << " " << b.goal.size() << " ni " << next_island [50] [b.position] [b.goal[0]]
    //    // 		  << " dist " << dists [b.position] [b.goal[0]]
    //    // 		  << " hops " << hops [50] [b.position] [b.goal[0]] ;
	  
    //    // 	  cerr << endl ;
    //    // 	  }

    //    if ( b.goal.size() == 0 || output [bi] != "" || b.goal[0] == -1 )                                   // no assignment
    // 	  {
    // 	  continue ;
    // 	  }
    //    else                                                       // follow order
    // 	  {
    // 	  best_i = next_island [ 100 ] [b.position] [b.goal[0]] ;
    // 	  }

    //    if ( turn > 55 & turn <= 63 )
    //    	  cerr << bi << " best_i " << best_i << " b from " << b.bridge_from << " b to " << b.bridge_to << endl ;

    //    // if ( best_i > -1 && b.bridge_from > -1 )                     // have a bridge
    //    // 	  {
    //    // 	  if ( turn > 55 & turn < 63 )
    //    // 	     {
    //    // 	     cerr << "       id " << bi << " bridge at " << b.bridge_from << " to " << b.bridge_to << " goal " << best_i << endl ;
    //    // 	     cerr << "connected " << connected [b.position] [best_i] << endl ;
    //    // 	     }
	  
    //    // 	  if ( ( b.bridge_to != best_i && b.bridge_from != best_i ) ||
    //    // 	       ( b.position == best_i ) ) // gather it
    //    // 	     gather ( output , b ) ;
    //    // 	  else if ( b.position != best_i && connected [b.position] [best_i] )
    //    // 	     {
    //    // 	     //	     cerr << "move" << endl ;
    //    // 	     move ( output , b , best_i ) ;                       // cross it
    //    // 	     }
    //    // 	  continue ;
    //    // 	  }

    //    if ( b.position == b.bridge_to )
    // 	  gather ( output , b ) ;
       
    //    if ( best_i > -1 )                            // no bridge of our own
    // 	  {
    // 	  //	  cerr << "connected " <<  connected [b.position] [best_i] << endl ;
    // 	  // cerr << "        connected " << b.position << " to " << best_i << " = " << connected[b.position] [best_i] << endl ;
    // 	  // if ( connected [b.position] [best_i] )
    // 	  //    move ( output , b , best_i ) ;
    // 	  // else
    // 	  if ( b.bridge_segments_carried < 50 && b.position == b.bridge_from && connected [b.position] [b.bridge_to] )
    // 	     move ( output , b , b.bridge_to ) ;
    // 	  else
    // 	     if ( dists [b.position] [best_i] <= 50 && b.bridge_segments_carried == 50 )
    // 		construct ( output , b , best_i ) ;
    // 	  continue ;
    // 	  }

    //    continue ;                                                 // nowhere to go
       
    //    }
    
    // // for ( int i = 0 ; i < output.size() ; ++i )
    // //    cerr << output[i] << " " ;
    // // cerr << endl ;
    send_move ( output ) ;
    } 
 return 0 ;
} ;
