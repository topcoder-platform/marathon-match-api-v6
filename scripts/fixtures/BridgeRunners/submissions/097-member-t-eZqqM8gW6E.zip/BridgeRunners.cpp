#include <cmath>
#include <iostream>
#include <queue>
#include <string>
#include <unordered_set>
#include <vector>
#include <climits>
using namespace std;

struct BridgeMan {
  int island = -1;
  int carry = 50;
  int target = -1;
};

struct Order {
  int orig = -1, dest = -1;
};

enum class Act { MOVE, UNPACK, PACK, TEAMUNPACK, TEAMPACK, MSG };

struct Command {
  Act t;
  int a = -1, b = -1, c = -1;
  string s;
};

static string to_string(const Command& cmd) {
  switch (cmd.t) {
    case Act::MOVE:
      return "MOVE " + to_string(cmd.a) + " " + to_string(cmd.b);
    case Act::UNPACK:
      return "UNPACK " + to_string(cmd.a) + " " + to_string(cmd.b);
    case Act::PACK:
      return "PACK " + to_string(cmd.a) + " " + to_string(cmd.b);
    case Act::TEAMUNPACK:
      return "TEAMUNPACK " + to_string(cmd.a) + " " + to_string(cmd.b) + " " + to_string(cmd.c);
    case Act::TEAMPACK:
      return "TEAMPACK " + to_string(cmd.a) + " " + to_string(cmd.b) + " " + to_string(cmd.c);
    case Act::MSG:
      return "MSG " + cmd.s;
  }
  return "";
}

class Solver {
 public:
  Solver() {}

  void initial_input() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    cin >> N >> B >> O;
    dist_mat.assign(N, vector<int>(N));
    for (int i = 0; i < N; ++i) {
      for (int j = 0; j < N; ++j) {
        cin >> dist_mat[i][j];
      }
    }
    bridge_mans.assign(B, {});
    orders.assign(O, {});

    graph50_adj.assign(N, vector<int>());
    for (int i = 0; i < N; ++i) {
      for (int j = 0; j < N; ++j) {
        if (i == j) {
          continue;
        }
        if (dist_mat[i][j] <= 50) {
          graph50_adj[i].push_back(j);
        }
      }
    }

    graph50_mat.assign(N, vector<int>(N, 1 << 30));
    for (int i = 0; i < N; ++i) {
      queue<int> q;
      q.push(i);
      graph50_mat[i][i] = 0;
      while (!q.empty()) {
        int u = q.front();
        q.pop();
        for (int v : graph50_adj[u]) {
          if (graph50_mat[i][v] > graph50_mat[i][u] + 1) {
            graph50_mat[i][v] = graph50_mat[i][u] + 1;
            q.push(v);
          }
        }
      }
    }

    for (int i = 0; i < N; ++i) {
      for (int j = 0; j < N; ++j) {
        if (i == j) {
          continue;
        }
        if (dist_mat[i][j] > 50 && dist_mat[i][j] <= 100) {
          dist100_edges.push_back({i, j});
        }
      }
    }
  }

  void turn_input() {
    int elapsed_ms;
    cin >> elapsed_ms;
    for (int i = 0; i < B; ++i) {
      cin >> bridge_mans[i].island >> bridge_mans[i].carry >> bridge_mans[i].target;
    }
    for (int i = 0; i < O; ++i) {
      cin >> orders[i].orig >> orders[i].dest;
    }
  }

  enum class Step { Idle, WantMove, WantPack };

  std::unordered_set<uint64_t> bridges;  // 現在存在する橋（自分が発行したコマンドで更新）
  std::vector<Step> step;                // 各人の3手サイクル段階
  std::vector<int> plan_from, plan_to;   // WantMove 用に直前 UNPACK の u->v を保持
  std::vector<int> last_prev;            // WantPack 用：直前 MOVE の戻り先 u

  static inline uint64_t enc_edge(int u, int v) {
    if (u > v) std::swap(u, v);
    return (uint64_t)u << 32 | (uint32_t)v;
  }

  bool has_bridge(int u, int v) const { return bridges.count(enc_edge(u, v)) > 0; }

  // g50 上の s→t の「次の1手」を返す（到達不可なら -1）
  int next_hop_g50(int s, int t) const {
    if (s == t) return t;
    std::vector<int> par(N, -1);
    std::queue<int> q;
    q.push(s);
    par[s] = s;
    while (!q.empty()) {
      int u = q.front();
      q.pop();
      for (int v : graph50_adj[u])
        if (par[v] == -1) {
          par[v] = u;
          q.push(v);
          if (v == t) {
            // t まで到達したので最初の一歩を復元
            int x = t;
            while (par[x] != s) x = par[x];
            return x;
          }
        }
    }
    return -1;
  }


  bool pack_any_adjacent_id(int id, vector<Command>& out, vector<char>& used) {
    if (used[id]) return false;
    int u = bridge_mans[id].island;
    int have = bridge_mans[id].carry;  // ← 今ターン未行動なのでこれでOK
    for (int w = 0; w < N; ++w)
      if (w != u && has_bridge(u, w)) {
        int e = dist_mat[u][w];
        if (have + e <= 60) {  // ← 容量チェック
          used[id] = true;
          out.push_back(Command{Act::PACK, id, w, -1, {}});
          bridges.erase(enc_edge(u, w));
          return true;
        }
      }
    return false;
  }

  vector<Command> solve() {
    const int CARRY_CAP = 60;
    vector<int> carry_delta(B, 0);  // 今ターン内の増減: UNPACKで負、PACKで正

    vector<Command> next_commands;
    vector<char> used(B, false);

    // 初回だけステートを用意
    if ((int)step.size() != B) {
      step.assign(B, Step::Idle);
      plan_from.assign(B, -1);
      plan_to.assign(B, -1);
      last_prev.assign(B, -1);
      bridges.clear();  // 開始時は橋なし
    }

    auto add_MOVE = [&](int id, int v) -> bool {
      if (used[id]) return false;
      int u = bridge_mans[id].island;
      if (!has_bridge(u, v)) return false;
      used[id] = true;
      next_commands.push_back(Command{Act::MOVE, id, v, -1, {}});
      return true;
    };
    auto add_UNPACK = [&](int id, int v) -> bool {
      if (used[id]) return false;
      int u = bridge_mans[id].island;
      int e = dist_mat[u][v];
      int have = bridge_mans[id].carry + carry_delta[id];
      if (e <= 0 || e > have) return false;  // 今ターンの減少分も考慮
      used[id] = true;
      next_commands.push_back(Command{Act::UNPACK, id, v, -1, {}});
      bridges.insert(enc_edge(u, v));
      carry_delta[id] -= e;  // ← 減らす
      return true;
    };

    auto add_PACK = [&](int id, int v) -> bool {
      if (used[id]) return false;
      int u = bridge_mans[id].island;
      if (!has_bridge(u, v)) return false;
      int e = dist_mat[u][v];
      int have = bridge_mans[id].carry + carry_delta[id];
      if (have + e > CARRY_CAP) return false;  // ← 容量チェック
      used[id] = true;
      next_commands.push_back(Command{Act::PACK, id, v, -1, {}});
      bridges.erase(enc_edge(u, v));
      carry_delta[id] += e;  // ← 増やす
      return true;
    };

    auto bfs_from = [&](int s) {
      vector<int> d(N, -1);
      queue<int> q;
      q.push(s);
      d[s] = 0;
      while (!q.empty()) {
        int u = q.front();
        q.pop();
        for (int v : graph50_adj[u])
          if (d[v] == -1) {
            d[v] = d[u] + 1;
            q.push(v);
          }
      }
      return d;
    };

    for (int id = 0; id < B; ++id) {
      if (used[id]) continue;  // 念のため
      if (step[id] == Step::WantMove) {
        int u = bridge_mans[id].island;
        if (plan_from[id] == u && plan_to[id] != -1 && has_bridge(u, plan_to[id])) {
          if (add_MOVE(id, plan_to[id])) {
            last_prev[id] = plan_from[id];  // 次ターン PACK 用
            step[id] = Step::WantPack;
            continue;
          }
        }
        step[id] = Step::Idle;
      }
      if (used[id]) continue;
      if (step[id] == Step::WantPack) {
        int vnow = bridge_mans[id].island;
        if (last_prev[id] != -1 && has_bridge(vnow, last_prev[id])) {
          if (add_PACK(id, last_prev[id])) {
            step[id] = Step::Idle;
            continue;
          }
        }
        step[id] = Step::Idle;
      }
    }

    for (int id = 0; id < B; ++id) {
      if (used[id] || step[id] != Step::Idle) continue;

      int u = bridge_mans[id].island;

      int goal = -1;
      if (bridge_mans[id].target != -1) {
        goal = bridge_mans[id].target;
      } else {
        auto d_from_u = bfs_from(u);
        int best_idx = -1, best_cost = INT_MAX;
        for (int j = 0; j < O; ++j) {
          int orig = orders[j].orig, dest = orders[j].dest;
          if (orig < 0 || dest < 0) continue;
          if (d_from_u[orig] < 0) continue;  // 同成分でない
          auto d_from_orig = bfs_from(orig);
          if (d_from_orig[dest] < 0) continue;
          int cost = d_from_u[orig] + d_from_orig[dest];
          if (cost < best_cost) {
            best_cost = cost;
            best_idx = j;
          }
        }
        if (best_idx != -1) goal = orders[best_idx].orig;
      }

      if (goal == -1 || goal == u) continue;

      int v = next_hop_g50(u, goal);
      if (v == -1) continue;  // 到達不可

      int e = dist_mat[u][v];

      // 既存橋優先 → MOVE。無ければ ≤50 かつ燃料十分なら UNPACK
      if (has_bridge(u, v)) {
        if (add_MOVE(id, v)) {
          last_prev[id] = u;
          step[id] = Step::WantPack;  // 次ターン PACK
        }
      } else if (e <= 50 && bridge_mans[id].carry >= e) {
        if (add_UNPACK(id, v)) {
          plan_from[id] = u;
          plan_to[id] = v;
          step[id] = Step::WantMove;  // 次ターン MOVE
        }
      } else {
        pack_any_adjacent_id(id, next_commands, used);
      }
    }

    return next_commands;
  }

  static void turn_output(const vector<Command>& cmds) {
    if (cmds.empty()) {
      cout << '\n' << flush;
      return;
    }
    for (int i = 0; i < (int)cmds.size(); ++i) {
      if (i != 0) {
        cout << '|';
      }
      cout << to_string(cmds[i]);
    }
    cout << '\n' << flush;
  }

 private:
  int N = -1, B = -1, O = -1;
  vector<BridgeMan> bridge_mans;
  vector<Order> orders;
  vector<vector<int>> dist_mat;
  vector<vector<int>> graph50_adj;
  vector<vector<int>> graph50_mat;
  vector<pair<int, int>> dist100_edges;
};

int main() {
  Solver solver;
  solver.initial_input();
  for (int turn = 1; turn <= 1000; ++turn) {
    solver.turn_input();
    auto cmds = solver.solve();
    Solver::turn_output(cmds);
  }
  return 0;
}
