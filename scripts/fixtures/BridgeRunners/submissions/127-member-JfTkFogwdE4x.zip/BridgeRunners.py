g_seed = 777778
def Rand(mod):
    global g_seed
    g_seed = (214013 * g_seed + 2531011)
    return ((g_seed >> 16) & 0x7FFF) % mod

class Bridgeman:
    def __init__(self, id):
        self.ID = id
        self.Position = 0
        self.Target = 0
        self.Bricks = 0
        self.BridgeFrom = -1
        self.BridgeTo = -1

class Order:
    def __init__(self, from_node, to_node):
        self.From = from_node
        self.To = to_node

def main():
    N = int(input())
    B = int(input())
    O = int(input())

    dists = []
    for _ in range(N):
        dists.append(list(map(int, input().split())))

    connected = [[False for _ in range(N)] for _ in range(N)]

    bridgemen = [Bridgeman(i) for i in range(B)]

    for turn in range(1, 1001):
        elapsedTime = int(input())
        for i in range(B):
            line = list(map(int, input().split()))
            bridgemen[i].Position = line[0]
            bridgemen[i].Bricks = line[1]
            bridgemen[i].Target = line[2]

        orders = []
        for _ in range(O):
            line = list(map(int, input().split()))
            order = Order(line[0], line[1])
            orders.append(order)

        output = []
        for b in bridgemen:
            if b.BridgeFrom == -1: # unpack
                targets = [t for t in range(N) if t != b.Position and not connected[b.Position][t] and dists[b.Position][t] <= b.Bricks]
                if len(targets) > 0:
                    t = targets[Rand(len(targets))]
                    output.append(f"UNPACK {b.ID} {t}")
                    b.BridgeFrom = b.Position
                    b.BridgeTo = t
                    connected[b.BridgeFrom][b.BridgeTo] = True
                    connected[b.BridgeTo][b.BridgeFrom] = True
            elif b.BridgeFrom == b.Position: # MOVE
                output.append(f"MOVE {b.ID} {b.BridgeTo}")
            else: # PACK
                output.append(f"PACK {b.ID} {b.BridgeFrom}")
                connected[b.BridgeFrom][b.BridgeTo] = False
                connected[b.BridgeTo][b.BridgeFrom] = False
                b.BridgeFrom = -1
                b.BridgeTo = -1
        
        print(" | ".join(output))

if __name__ == "__main__":
    main()