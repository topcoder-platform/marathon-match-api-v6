#include <algorithm>
#include <iostream>
#include <limits>
#include <stdexcept>
#include <vector>
#include <chrono>
// #include <random>
#include <array>
#include <iomanip>
#include <cassert>

using namespace std;
using namespace chrono;

// #define DBG

#ifdef DBG
#define DEBUG(x) x
#else
#define DEBUG(x)
#endif

// if men leave their bridge behind, they will always get stuck at some point
// so bridges need ownership, at most two owners per bridge, with length owned
// new action can be for men to transfer bridge length, via (team)build and teamcollect
// men can lay bridge in multiple directions, but can not move away from bridge (partially) owned
//
// men with message can check minimum length needed to independently make path there
// if insufficient, need to find transfer
//
// all steps on path of man that has sufficient length can be considered 'to be build'
// others don't need to cover that bridge

// find for all carrying men the shortest route that fits with currently owned length
// if multiple found, take the route with least needed length
// remaining length becomes this man's slack
// these men can continue towards destination
//
// if carrying, but no route found, one or more steps must be beyond man's length
// find the route with minimum requirement
// if it is within max capacity, can try to find man to transfer his slack
// if cannot find, or beyond max capacity, can find other man taking same step in opposite direction, and align
//
// if not carrying message, and not busy with transferring, check distance to all orders fitting current length and divide up the orders
// 

constexpr int MAX_TURNS = 1000;
constexpr int MAX_ISLANDS = 80;
constexpr int MAX_MEN = 20;
constexpr int MAX_ORDERS = 10;
constexpr int MAX_CAPACITY = 60;
constexpr int MAX_BRIDGE_LENGTH = 2 * MAX_CAPACITY;
constexpr int IMPOSSIBLE_BRIDGE_LENGTH = 2 * MAX_BRIDGE_LENGTH;

#define BE(x) x.begin(), x.end()
#define FORI(v,b,e) for( int v = b; v < e; v++ )

// fast random

// uint32_t xorshift32_state = [](){ return random_device{}(); }();
uint32_t xorshift32_state = [](){ return 42424242; }();

uint32_t xorshift32()
{
    xorshift32_state ^= xorshift32_state << 13;
    xorshift32_state ^= xorshift32_state >> 17;
    xorshift32_state ^= xorshift32_state << 5;
    return xorshift32_state;
}

int get_random_int_between_0_and_n_exclusive( int n )
{
    return ( uint64_t( xorshift32() ) * uint64_t( n ) ) >> 32;
}

// time checking

struct EfficientTimeCheck
{
    constexpr static unsigned int INTERVAL = 15;

    const steady_clock::time_point limit;
    steady_clock::time_point last_now;
    unsigned int it = 0;

    EfficientTimeCheck( steady_clock::time_point _limit ) :
        limit( _limit ),
        last_now( steady_clock::now() )
    {}

    bool is_finished()
    {
        it++;
        if( ( it & INTERVAL ) == 0 )
        {
            last_now = steady_clock::now();
            return last_now > limit;
        }
        return false;
    }

    auto get_time_left() const
    {
        return limit - last_now;
    }
};

// stack vector

template< typename TYPE, size_t SIZE >
class StackVector
{
    array< TYPE, SIZE > data{};
    size_t sz = 0;

public:

    void set_from_vector( const vector<TYPE>& v )
    {
        sz = v.size();
        for( unsigned int i = 0; i < v.size(); i++ )
        {
            data[i] = v[i];
        } 
    }
    void clear() { sz = 0; }
    void push_back( TYPE&& v ) { data[sz++] = v; }
    void push_back( const TYPE& v ) { data[sz++] = v; }
    TYPE& operator[]( int idx ) { return data[idx]; }
    const TYPE& operator[]( int idx ) const { return data[idx]; }
    TYPE& back() { return data[sz-1]; }
    const TYPE& back() const { return data[sz-1]; }
    void pop_back() { sz--; }
    void resize( int s ) { sz = s; }
    int size() const { return sz; }
    bool empty() const { return sz == 0; }
    typename array< TYPE, SIZE >::iterator begin() { return data.begin(); }
    typename array< TYPE, SIZE >::const_iterator begin() const { return data.begin(); }
    typename array< TYPE, SIZE >::iterator end() { return data.begin()+sz; }
    typename array< TYPE, SIZE >::const_iterator end() const { return data.begin()+sz; }
    void erase( const typename array< TYPE, SIZE >::iterator& from, const typename array< TYPE, SIZE >::iterator& )
    {
        sz = distance( begin(), from );
    }
    bool operator==( const StackVector< TYPE, SIZE >& other )
    {
        if( sz != other.sz ) return false;
        for( unsigned int i = 0; i < sz; i++ ) if( data[i] != other.data[i] ) return false;
        return true;
    }
};

// MARK: state

struct Order
{
    int org;
    int dst;
};

struct Route
{
    int req;
    StackVector<int,MAX_ISLANDS> nodes;
};

enum class PlanType { WAIT, DONE, EN_ROUTE, FIND_TRANSFER_COOP, FIND_COOP, WAIT_FOR_BRIDGE, TRANSFER, RANDOM };

struct Plan
{
    PlanType type = PlanType::WAIT;
    Route route;
};

struct Man
{
    int island;
    int carried = 50;
    int owned = 50;
    Order message = { -1, -1 };
    Plan plan;
};

// moves are done in sequence:
// team builds
// builds
// moves
// collects
// team collects

enum class MoveType { WAIT, MULTIBUILD, BUILD, MOVE, COLLECT, MULTICOLLECT };

struct Move
{
    MoveType type;
    int to;
    int with;
    int ctx;
};

using Moves = vector<Move>;

struct DistIsl
{
    int dist;
    int island;
};

struct Owner
{
    int idx = -1;
    int length = 0;
};

struct Bridge
{
    array<Owner,2> owner{};
    // Owner owner{};
    bool is = false;
    bool planned = false;
};

class State
{
public:

    array< array< int, MAX_ISLANDS >, MAX_ISLANDS > distance{};
    array< array< Bridge, MAX_ISLANDS >, MAX_ISLANDS > bridges{};
    array< Man, MAX_MEN > men{};
    int turn;
    array< Order, MAX_ORDERS > orders{};
    int nr_islands;
    int nr_men;
    int nr_orders;
    int elapsed_time_ms;

    // MARK: input output

    void read_init_input()
    {
        cin >> nr_islands >> nr_men >> nr_orders;
        FORI( f, 0, nr_islands )
        {
            FORI( t, 0, nr_islands )
            {
                cin >> distance[f][t];
            }            
        }

        // FORI( f, 0, nr_islands )
        // {
        //     FORI( t, 0, nr_islands )
        //     {
        //         cerr << distance[f][t] << " ";
        //     }            
        //     cerr << endl;
        // }

        // find_cluster_bridges();

        // FORI( f, 0, nr_islands )
        // {
        //     FORI( t, 0, nr_islands )
        //     {
        //         cerr << distance[f][t] << " ";
        //     }            
        //     cerr << endl;
        // }
    }

    // the way picking up orders works:
    // - make all turn moves
    // - check if any men reached message destination -> deliver
    // - check if any men are on order origin islands -> pickup
    void read_turn_input( int _turn )
    {
        cin >> elapsed_time_ms;
        FORI( m, 0, nr_men )
        {
            int island, carried, dest;
            cin >> island >> carried >> dest;

            // verify that this matches expected state
            
            if( _turn > 0 )
                assert( island == men[m].island );
            else
                men[m].island = island;

            if( carried != men[m].carried )
            {
                DEBUG( cerr << m << " " << carried << " " << men[m].carried << endl; )
                throw runtime_error("Length mismatch");
            }
            if( men[m].message.dst != -1 && men[m].message.dst != dest )
            {
                DEBUG( cerr << m << " " << dest << " " << men[m].message.dst << endl; )
                throw runtime_error("Destination mismatch");
            }

            // note: if we just delivered in this turn, dst will have been set to -1 by apply_turn_moves
            if( men[m].message.dst == -1 && dest > -1 )
            {
                men[m].message.dst = dest;
                men[m].message.org = island;
            }
        }
        FORI( o, 0, nr_orders )
        {
            cin >> orders[o].org >> orders[o].dst;
        }
        turn = _turn;
    }

    // referee doesn't give bridge information
    void write_moves( const Moves& moves )
    {
        DEBUG( cerr << "Build:   "; )
        FORI( m, 0, nr_men )
        {
            // if( moves[m].type == MoveType::BUILD && is_valid_build( moves[m], m ) )
            if( moves[m].type == MoveType::BUILD )
            {
                cout << "UNPACK " << m << " " << moves[m].to << "|";
                DEBUG( cerr << m << " (" << men[m].island << "->" << moves[m].to << ")   "; )
                // perform_build( m, moves[m] );
            }
        }
        DEBUG( cerr << endl << "Team build:   "; )
        FORI( m, 0, nr_men )
        {
            // if( moves[m].type == MoveType::BUILD && is_valid_build( moves[m], m ) )
            if( moves[m].type == MoveType::MULTIBUILD )
            {
                cout << "TEAMUNPACK " << m << " " << moves[m].with << " " << moves[m].ctx << "|";
                DEBUG( cerr << m << "+" << moves[m].with << " (" << men[m].island << "->" << moves[m].to << ")   "; )
                // perform_build( m, moves[m] );
            }
        }
        DEBUG( cerr << endl << "Move:    "; )
        FORI( m, 0, nr_men )
        {
            // if( moves[m].type == MoveType::MOVE && is_valid_move( moves[m], m ) )
            if( moves[m].type == MoveType::MOVE )
            {
                cout << "MOVE " << m << " " << moves[m].to << "|";
                DEBUG( cerr << m << " (->" << moves[m].to << ")   "; )
                // perform_step( m, moves[m] );
            }
        }
        DEBUG( cerr << endl << "Collect: "; )
        FORI( m, 0, nr_men )
        {
            // if( moves[m].type == MoveType::COLLECT && is_valid_collect( moves[m], m ) )
            if( moves[m].type == MoveType::COLLECT )
            {
                cout << "PACK " << m << " " << moves[m].to << "|";
                DEBUG( cerr << m << " (" << men[m].island << "->" << moves[m].to << ")   "; )
                // perform_collect( m, moves[m] );
            }
        }
        DEBUG( cerr << endl << "Team collect:   "; )
        FORI( m, 0, nr_men )
        {
            // if( moves[m].type == MoveType::BUILD && is_valid_build( moves[m], m ) )
            if( moves[m].type == MoveType::MULTICOLLECT )
            {
                cout << "TEAMPACK " << m << " " << moves[m].with << " " << moves[m].ctx << "|";
                DEBUG( cerr << m << "+" << moves[m].with << " (" << men[m].island << "->" << moves[m].to << ")   "; )
                // perform_build( m, moves[m] );
            }
        }
        DEBUG( cerr << endl; )
        cout << "MSG done" << endl;
    }

    bool is_finished() const
    {
        return turn >= MAX_TURNS;
    }

    // MARK: preprocessing

    // identify clusters connected with gaps of at most 60
    // designate a single bridge between clusters (set all other distances to greater than max bridge)
    // this way coops can more easily find each other
    void find_cluster_bridges()
    {
        vector<int> cluster_idx( nr_islands, -1 );

        int nr = 0;
        FORI( i, 0, nr_islands )
        {
            if( cluster_idx[i] == -1 )
            {
                identify_cluster( i, cluster_idx, nr );
                nr++;
            }
        }

        vector<vector<int>> clusters( nr );
        FORI( c, 0, nr )
        {
            FORI( i, 0, nr_islands )
            {
                if( cluster_idx[i] == c )
                {
                    clusters[c].push_back(i);
                }
            }
            DEBUG( cerr << "Cluster " << c << ": ";
            for( int i : clusters[c] )
            {
                cerr << i << " ";
            }
            cerr << endl;
            )
        }

        FORI( c, 0, nr - 1 )
        {
            FORI( d, c+1, nr )
            {
                find_connector( clusters[c], clusters[d] );
            }
        }
    }

    void find_connector( const vector<int>& cc, const vector<int>& dd )
    {
        int smallest = numeric_limits<int>::max();
        int best_c = -1;
        int best_d = -1;
        FORI( ci, 0, cc.size() )
        {
            FORI( di, 0, dd.size() )
            {
                if( distance[ cc[ci] ][ dd[di] ] < smallest )
                {
                    smallest = distance[ cc[ci] ][ dd[di] ];
                    best_c = ci;
                    best_d = di;
                }
            }                        
        }

        if( smallest <= MAX_BRIDGE_LENGTH )
        {
            DEBUG( cerr << "Connector " << cc[best_c] << " - " << dd[best_d] << endl; )
            disable_all_connections_except( cc, dd, cc[best_c], dd[best_d] );
        }
        else
        {
            disable_all_connections( cc, dd );
        }
    }

    void disable_all_connections_except( const vector<int>& cc, const vector<int>& dd, int best_c, int best_d )
    {
        for( int c : cc )
        {
            for( int d : dd )
            {
                if( c != best_c || d != best_d )
                {
                    distance[c][d] = IMPOSSIBLE_BRIDGE_LENGTH;
                    distance[d][c] = IMPOSSIBLE_BRIDGE_LENGTH;
                }
            }
        }
    }

    void disable_all_connections( const vector<int>& cc, const vector<int>& dd )
    {
        for( int c : cc )
        {
            for( int d : dd )
            {
                distance[c][d] = IMPOSSIBLE_BRIDGE_LENGTH;
                distance[d][c] = IMPOSSIBLE_BRIDGE_LENGTH;
            }
        }
    }

    void identify_cluster( int isl, vector<int>& cluster_idx, int idx )
    {
        cluster_idx[isl] = idx;
        vector<int> frontier;
        frontier.reserve(nr_islands);
        frontier.push_back(isl);
        vector<int> next;
        next.reserve(nr_islands);

        while( !frontier.empty() )
        {
            next.clear();

            for( int f : frontier )
            {
                FORI( i, 0, nr_islands )
                {
                    // if( f != i && distance[f][i] <= MAX_CAPACITY && cluster_idx[i] == -1 )
                    if( f != i && distance[f][i] <= 50 && cluster_idx[i] == -1 )
                    {
                        cluster_idx[i] = idx;
                        next.push_back(i);
                    }
                }
            }

            swap( frontier, next );
        }
    }

    // MARK: sim

    void perform_builds( const Moves& moves )
    {
        FORI( m, 0, nr_men )
        {
            if( moves[m].type == MoveType::BUILD && is_valid_build( moves[m], m ) )
            {
                perform_build( m, moves[m] );
            }
        }
    }

    inline bool is_valid_build( const Move& mv, int man ) const
    {
        return !bridges[ men[man].island ][ mv.to ].is && distance[ men[man].island ][ mv.to ] <= men[man].carried;
    }

    void perform_build( int m, const Move& move )
    {
        bridges[ men[m].island ][ move.to ].is = true;
        bridges[ men[m].island ][ move.to ].owner[0].idx = m;
        bridges[ men[m].island ][ move.to ].owner[0].length = distance[ men[m].island ][ move.to ];
        bridges[ men[m].island ][ move.to ].owner[1] = { -1, 0 };

        bridges[ move.to ][ men[m].island ] = bridges[ men[m].island ][ move.to ];

        men[m].carried -= distance[ men[m].island ][ move.to ];
    }

    inline bool is_valid_team_build( const Move& mv1, const Move& mv2, int man1, int man2 ) const
    {
        return !bridges[ men[man1].island ][ mv1.to ].is && distance[ men[man1].island ][ mv1.to ] <= men[man1].carried + men[man2].carried;
    }

    void perform_team_build( int m, int n, const Move& mmove, const Move& nmove )
    {
        bridges[ men[m].island ][ mmove.to ].is = true;
        bridges[ men[m].island ][ mmove.to ].owner[0].idx = m;
        bridges[ men[m].island ][ mmove.to ].owner[0].length = mmove.ctx;
        bridges[ men[m].island ][ mmove.to ].owner[1].idx = n;
        bridges[ men[m].island ][ mmove.to ].owner[1].length = nmove.ctx;

        bridges[ mmove.to ][ men[m].island ] = bridges[ men[m].island ][ mmove.to ];

        men[m].carried -= mmove.ctx;
        men[n].carried -= nmove.ctx;
    }

    void perform_steps( const Moves& moves )
    {
        FORI( m, 0, nr_men )
        {
            if( moves[m].type == MoveType::MOVE && is_valid_move( moves[m], m ) )
            {
                perform_step( m, moves[m] );
            }
        }
    }

    inline bool is_valid_move( const Move& mv, int man ) const
    {
        return bridges[ men[man].island ][ mv.to ].is;
    }

    void perform_step( int m, const Move& move )
    {
        men[m].island = move.to;

        // check message delivery (pickup will be handled by read_turn_input)

        if( move.to == men[m].message.dst )
        {
            men[m].message = { -1, -1 };
        }
    }

    void perform_collects( const Moves& moves )
    {
        FORI( m, 0, nr_men )
        {
            if( moves[m].type == MoveType::COLLECT && is_valid_collect( moves[m], m ) )
            {
                perform_collect( m, moves[m] );
            }
        }
    }

    inline bool is_valid_collect( const Move& mv, int man ) const
    {
        return bridges[ men[man].island ][ mv.to ].is && distance[ men[man].island ][ mv.to ] + men[man].carried <= MAX_CAPACITY &&
               bridges[ men[man].island ][ mv.to ].owner[0].idx == man && bridges[ men[man].island ][ mv.to ].owner[1].idx == -1 ;
    }

    void perform_collect( int m, const Move& move )
    {
        bridges[ men[m].island ][ move.to ].is = false;
        bridges[ men[m].island ][ move.to ].owner[0] = { -1, 0 };

        bridges[ move.to ][ men[m].island ] = bridges[ men[m].island ][ move.to ];

        men[m].carried += distance[ men[m].island ][ move.to ];
    }

    inline bool is_valid_team_collect( const Move& mv1, const Move& mv2, int man1, int man2 ) const
    {
        return bridges[ men[man1].island ][ mv1.to ].is &&
               mv1.ctx + men[man1].carried <= MAX_CAPACITY && mv2.ctx + men[man2].carried <= MAX_CAPACITY &&
               men[man1].island == mv2.to && men[man2].island == mv1.to &&
               mv1.ctx + mv2.ctx == distance[ men[man1].island ][ mv1.to ] &&
               ( ( bridges[ men[man1].island ][ mv1.to ].owner[0].idx == man1 && bridges[ men[man1].island ][ mv1.to ].owner[1].idx == man2 ) ||
                 ( bridges[ men[man1].island ][ mv1.to ].owner[1].idx == man1 && bridges[ men[man1].island ][ mv1.to ].owner[0].idx == man2 ) );
    }

    void perform_team_collect( int m, int n, const Move& mmove, const Move& nmove )
    {
        int delta_owned_m = ( bridges[ men[m].island ][ mmove.to ].owner[0].idx == m ?
                                mmove.ctx - bridges[ men[m].island ][ mmove.to ].owner[0].length :
                                mmove.ctx - bridges[ men[m].island ][ mmove.to ].owner[1].length );
        men[m].owned += delta_owned_m;
        men[n].owned -= delta_owned_m;

        bridges[ men[m].island ][ mmove.to ].is = false;
        bridges[ men[m].island ][ mmove.to ].owner[0] = { -1, 0 };
        bridges[ men[m].island ][ mmove.to ].owner[1] = { -1, 0 };

        bridges[ mmove.to ][ men[m].island ] = bridges[ men[m].island ][ mmove.to ];

        men[m].carried += mmove.ctx;
        men[n].carried += nmove.ctx;
    }

    // MARK: find moves

    Moves find_best_moves()
    {
        if( turn == 0 )
        {
            return Moves( nr_men );
        }

        auto start = steady_clock::now();

        reset_plans_and_bridges();

        find_deliveries();
        find_pickups();
        mark_independent_routes_as_planned();
        find_cooperations_for_stuck_men();
        find_transfers_for_stuck_men();
        any_progress_for_remaining_stuck();
        // random_for_no_planners();

        auto moves = convert_plan_to_moves();

        cerr << duration_cast<microseconds>( steady_clock::now() - start ).count() << "us" << endl;

        return moves;
    }

    void reset_plans_and_bridges()
    {
        FORI( m, 0, nr_men )
        {
            men[m].plan = {};
        }

        FORI( i, 0, nr_islands )
        {
            FORI( j, 0, nr_islands )
            {
                bridges[i][j].planned = false;
            }            
        }
    }

    void mark_independent_routes_as_planned()
    {
        FORI( m, 0, nr_men )
        {
            if( men[m].plan.type == PlanType::EN_ROUTE )
            {
                FORI( r, 0, men[m].plan.route.nodes.size() - 1 )
                {
                    bridges[ men[m].plan.route.nodes[r] ][ men[m].plan.route.nodes[r+1] ].planned = true;
                    bridges[ men[m].plan.route.nodes[r+1] ][ men[m].plan.route.nodes[r] ].planned = true;
                }
            }
        }
    }

    // MARK: convert plans

    Moves convert_plan_to_moves()
    {
        Moves moves( nr_men );

        DEBUG( cerr << "* Leftovers:" << endl; )
        DEBUG( FORI( m, 0, nr_men )
        {
            if( men[m].plan.type == PlanType::WAIT || men[m].plan.type == PlanType::RANDOM )
            {
                cerr << "Man " << setw(2) << m << ": no plan" << endl;
            }
        } )

        DEBUG( cerr << "* Moves:" << endl; )
        convert_all_builds( moves );
        convert_all_team_builds( moves );
        convert_all_steps( moves );
        convert_all_collects( moves );
        convert_all_team_collects( moves );

        return moves;
    }

    // builds can happen if:
    // - on route, when there is no bridge, and we have enough to place it
    void convert_all_builds( Moves& moves )
    {
        FORI( m, 0, nr_men )
        {
            if( men[m].plan.type == PlanType::EN_ROUTE || ( men[m].plan.type == PlanType::TRANSFER && men[m].plan.route.nodes.size() > 2 ) )
            {
                if( men[m].plan.route.nodes.size() > 1 )
                {
                    int next_island = men[m].plan.route.nodes[1];

                    if( !bridges[ men[m].island ][ next_island ].is )
                    {
                        if( men[m].carried >= distance[ men[m].island ][ next_island ] )
                        {
                            moves[m].type = MoveType::BUILD;
                            moves[m].to = next_island;

                            if( !is_valid_build( moves[m], m ) )
                            {
                                cerr << "shit build" << endl;
                            }

                            perform_build( m, moves[m] );
                            men[m].plan.type = PlanType::DONE;
                        }
                    }
                }
            }
            else if( men[m].plan.type == PlanType::RANDOM && !anything_owned_besides( m, -1 ) )
            {
                // - build to random neighbor, if you own nothing AND (no other bridge OR 50% chance)

                bool any_bridge = false;
                vector<int> neighbors;
                FORI( i, 0, nr_islands )
                {
                    if( men[m].island != i )
                    {
                        if( bridges[ men[m].island ][i].is )
                        {
                            any_bridge = true;
                        }
                        else if( distance[ men[m].island ][i] <= men[m].carried )
                        {
                            neighbors.push_back(i);
                        }
                    }
                }

                if( ( !any_bridge || get_random_int_between_0_and_n_exclusive(100) < 25 ) && !neighbors.empty() )
                {
                    int nei = get_random_int_between_0_and_n_exclusive( neighbors.size() );

                    moves[m].type = MoveType::BUILD;
                    moves[m].to = neighbors[nei];

                    if( !is_valid_build( moves[m], m ) )
                    {
                        cerr << "shit build" << endl;
                    }

                    perform_build( m, moves[m] );
                    men[m].plan.type = PlanType::DONE;
                }                
            }
        }
    }

    // team builds happen if:
    // - when two men are waiting for bridge on either side of a gap,
    //   and their next step is that gap, and there is no bridge yet, and they can span it together
    //   also need to have cleaned up all other bridges first
    void convert_all_team_builds( Moves& moves )
    {
        FORI( m, 0, nr_men )
        {
            if( men[m].plan.type == PlanType::WAIT_FOR_BRIDGE )
            {
                if( men[m].plan.route.nodes.size() > 1 )
                {
                    int next_island = men[m].plan.route.nodes[1];

                    if( !bridges[ men[m].island ][ next_island ].is && !anything_owned_besides( m, next_island ) )
                    {
                        FORI( n, 0, nr_men )
                        {
                            if( m != n && men[n].plan.type == PlanType::WAIT_FOR_BRIDGE &&
                                men[n].plan.route.nodes.size() > 1 &&
                                men[n].plan.route.nodes[1] == men[m].island &&
                                next_island == men[n].island &&
                                men[m].carried + men[n].carried >= distance[ men[m].island ][ next_island ] &&
                                !anything_owned_besides( n, men[n].plan.route.nodes[1] ) )
                            {                              
                                int l1 = min( men[m].carried, distance[ men[m].island ][ next_island ] );
                                int l2 = distance[ men[m].island ][ next_island ] - l1;

                                moves[m].type = MoveType::MULTIBUILD;
                                moves[m].to = next_island;
                                moves[m].with = n;
                                moves[m].ctx = l1;

                                moves[n].type = MoveType::MULTIBUILD;
                                moves[n].to = men[m].island;
                                moves[n].with = m;
                                moves[n].ctx = l2;

                                if( !is_valid_team_build( moves[m], moves[n], m, n ) )
                                {
                                    cerr << "shit team build a" << endl;
                                }

                                perform_team_build( m, n, moves[m], moves[n] );
                                men[m].plan.type = PlanType::DONE;
                                men[n].plan.type = PlanType::DONE;

                                // set other player to wait, so the move isn't done twice
                                moves[n].type = MoveType::WAIT;

                                break;
                            }
                        }
                    }
                }
            }
            else if( men[m].plan.type == PlanType::TRANSFER && men[m].plan.route.nodes.size() == 2 && men[m].plan.route.req != -1 )
            {
                int next_island = men[m].plan.route.nodes[1];

                if( !bridges[ men[m].island ][ next_island ].is && !anything_owned_besides( m, next_island ) )
                {
                    FORI( n, 0, nr_men )
                    {
                        if( m != n && men[n].plan.type == PlanType::TRANSFER &&
                            men[n].plan.route.nodes.size() == 2 &&
                            men[n].plan.route.nodes[1] == men[m].island &&
                            next_island == men[n].island &&
                            men[m].carried + men[n].carried >= distance[ men[m].island ][ next_island ] &&
                            !anything_owned_besides( n, men[n].plan.route.nodes[1] ) )
                        {
                            // int needed = men[m].plan.route.req - men[m].owned;
                            int needed = MAX_CAPACITY - men[m].owned;

                            int l2 = min( distance[ men[m].island ][ next_island ], min( men[n].carried, max( needed, distance[ men[m].island ][ next_island ] - men[m].carried ) ) );
                            int l1 = distance[ men[m].island ][ next_island ] - l2;

                            moves[m].type = MoveType::MULTIBUILD;
                            moves[m].to = next_island;
                            moves[m].with = n;
                            moves[m].ctx = l1;

                            moves[n].type = MoveType::MULTIBUILD;
                            moves[n].to = men[m].island;
                            moves[n].with = m;
                            moves[n].ctx = l2;

                            if( !is_valid_team_build( moves[m], moves[n], m, n ) )
                            {
                                cerr << "shit team build b" << endl;
                            }

                            perform_team_build( m, n, moves[m], moves[n] );
                            men[m].plan.type = PlanType::DONE;
                            men[n].plan.type = PlanType::DONE;

                            // set other player to wait, so the move isn't done twice
                            moves[n].type = MoveType::WAIT;

                            break;
                        }
                    }
                }
            }
        }
    }

    bool anything_owned_besides( int m, int isl )
    {
        FORI( i, 0, nr_islands )
        {
            if( bridges[ men[m].island ][i].is && i != isl &&
                ( bridges[ men[m].island ][i].owner[0].idx == m || bridges[ men[m].island ][i].owner[1].idx == m ) )
            {
                return true;
            }
        }
        return false;
    }

    int bridge_coowned_with( int m, const Bridge& br )
    {
        if( br.owner[0].idx == m )
        {
            return br.owner[1].idx;
        }
        else if( br.owner[1].idx == m )
        {
            return br.owner[0].idx;
        }
        return -1;
    }

    // steps can happen if:
    // - on route, when there is a bridge, and no other owned bridge
    // - when waiting for bridge, and there is one, and no other owned bridge
    void convert_all_steps( Moves& moves )
    {
        FORI( m, 0, nr_men )
        {
            if( men[m].plan.type == PlanType::EN_ROUTE || men[m].plan.type == PlanType::WAIT_FOR_BRIDGE ||
                ( men[m].plan.type == PlanType::TRANSFER && men[m].plan.route.nodes.size() > 2 ) )
            {
                if( men[m].plan.route.nodes.size() > 1 )
                {
                    int next_island = men[m].plan.route.nodes[1];

                    if( bridges[ men[m].island ][ next_island ].is )
                    {
                        int coowner = bridge_coowned_with( m, bridges[ men[m].island ][ next_island ] );
                        if( coowner != -1 )
                        {
                            // can only cross together
                            if( ( men[coowner].plan.type == PlanType::WAIT || men[coowner].plan.type == PlanType::RANDOM ||
                                  ( men[coowner].plan.route.nodes.size() > 1 &&
                                    men[coowner].plan.route.nodes[1] == men[m].island ) ) &&
                                !anything_owned_besides( m, next_island ) && !anything_owned_besides( coowner, men[m].island ) )
                            {
                                moves[m].type = MoveType::MOVE;
                                moves[m].to = next_island;

                                moves[coowner].type = MoveType::MOVE;
                                moves[coowner].to = men[m].island;

                                perform_step( m, moves[m] );
                                men[m].plan.type = PlanType::DONE;

                                perform_step( coowner, moves[coowner] );
                                men[coowner].plan.type = PlanType::DONE;
                            }

                            continue;
                        }
                        
                        if( !anything_owned_besides( m, next_island ) )
                        {
                            moves[m].type = MoveType::MOVE;
                            moves[m].to = next_island;

                            if( !is_valid_move( moves[m], m ) )
                            {
                                cerr << "shit move" << endl;
                            }

                            perform_step( m, moves[m] );
                            men[m].plan.type = PlanType::DONE;
                        }
                    }
                }
            }
            else if( men[m].plan.type == PlanType::RANDOM )
            {
                // - build to random neighbor, if you own nothing AND (no other bridge OR 50% chance)
                // - step over random bridge, if we own nothing else AND 50% chance

                vector<int> neighbors;
                FORI( i, 0, nr_islands )
                {
                    if( men[m].island != i && bridges[ men[m].island ][i].is && !anything_owned_besides( m, i ) )
                    {
                        neighbors.push_back(i);
                    }
                }

                if( !neighbors.empty() && get_random_int_between_0_and_n_exclusive(100) < 25 )
                {
                    int nei = get_random_int_between_0_and_n_exclusive( neighbors.size() );

                    moves[m].type = MoveType::MOVE;
                    moves[m].to = neighbors[nei];

                    if( !is_valid_move( moves[m], m ) )
                    {
                        cerr << "shit move" << endl;
                    }

                    perform_step( m, moves[m] );
                    men[m].plan.type = PlanType::DONE;
                }                
            }
        }
    }

    // collect happen if:
    // - on route/waiting for bridge when there are other single-owned bridges that we don't need anymore
    void convert_all_collects( Moves& moves )
    {
        FORI( m, 0, nr_men )
        {
            if( men[m].plan.type == PlanType::EN_ROUTE || men[m].plan.type == PlanType::WAIT_FOR_BRIDGE || 
                men[m].plan.type == PlanType::TRANSFER )
            {
                if( men[m].plan.route.nodes.size() > 1 )
                {
                    int next_island = men[m].plan.route.nodes[1];

                    vector<int> owned;
                    FORI( i, 0, nr_islands )
                    {
                        if( bridges[ men[m].island ][i].is && i != next_island &&
                            bridges[ men[m].island ][i].owner[0].idx == m && bridges[ men[m].island ][i].owner[1].idx == -1 )
                        {
                            owned.push_back(i);
                        }
                    }

                    if( !owned.empty() )
                    {
                        moves[m].type = MoveType::COLLECT;
                        moves[m].to = owned.front();

                        if( !is_valid_collect( moves[m], m ) )
                        {
                            cerr << "shit collect" << endl;
                        }

                        perform_collect( m, moves[m] );
                        men[m].plan.type = PlanType::DONE;
                    }
                }
            }
            else if( men[m].plan.type == PlanType::RANDOM && anything_owned_besides( m, -1 ) )
            {
                // - build to random neighbor, if you own nothing AND (no other bridge OR 50% chance)
                // - step over random bridge, if we own nothing else AND 50% chance
                // - collect any bridge we own

                vector<int> neighbors;
                FORI( i, 0, nr_islands )
                {
                    if( men[m].island != i && bridges[ men[m].island ][i].is && bridges[ men[m].island ][i].owner[0].idx == m && bridges[ men[m].island ][i].owner[1].idx == -1 )
                    {
                        neighbors.push_back(i);
                    }
                }

                if( !neighbors.empty() )
                {
                    int nei = get_random_int_between_0_and_n_exclusive( neighbors.size() );

                    moves[m].type = MoveType::COLLECT;
                    moves[m].to = neighbors[nei];

                    if( !is_valid_collect( moves[m], m ) )
                    {
                        cerr << "shit collect" << endl;
                    }

                    perform_collect( m, moves[m] );
                    men[m].plan.type = PlanType::DONE;
                }                
            }
        }
    }

    // team collect happen if:
    // - on route/waiting for bridge when there are partial-owned bridges that we don't need anymore, with other co-owner on other side
    void convert_all_team_collects( Moves& moves )
    {
        FORI( m, 0, nr_men )
        {
            if( men[m].plan.type == PlanType::EN_ROUTE || men[m].plan.type == PlanType::WAIT_FOR_BRIDGE )
            {
                if( men[m].plan.route.nodes.size() > 1 )
                {
                    int next_island = men[m].plan.route.nodes[1];

                    vector<int> owned;
                    FORI( i, 0, nr_islands )
                    {
                        if( bridges[ men[m].island ][i].is && i != next_island &&
                            ( bridges[ men[m].island ][i].owner[0].idx == m || bridges[ men[m].island ][i].owner[1].idx == m ) &&
                            bridges[ men[m].island ][i].owner[1].idx != -1 )
                        {
                            owned.push_back(i);
                        }
                    }

                    for( int own : owned )
                    {
                        int other;
                        int my_len;
                        if( bridges[ men[m].island ][ own ].owner[0].idx == m )
                        {
                            other = bridges[ men[m].island ][ own ].owner[1].idx;
                            my_len = bridges[ men[m].island ][ own ].owner[0].length;
                        }
                        else
                        {
                            other = bridges[ men[m].island ][ own ].owner[0].idx;
                            my_len = bridges[ men[m].island ][ own ].owner[1].length;
                        }

                        if( men[other].island == own && men[other].plan.type != PlanType::DONE )
                        {
                            moves[m].type = MoveType::MULTICOLLECT;
                            moves[m].to = own;
                            moves[m].with = other;
                            moves[m].ctx = my_len;

                            moves[other].type = MoveType::MULTICOLLECT;
                            moves[other].to = men[m].island;
                            moves[other].with = m;
                            moves[other].ctx = distance[ men[m].island ][ own ] - my_len;

                            if( !is_valid_team_collect( moves[m], moves[other], m, other ) )
                            {
                                cerr << "shit team collect a" << endl;
                            }

                            perform_team_collect( m, other, moves[m], moves[other] );
                            men[m].plan.type = PlanType::DONE;
                            men[other].plan.type = PlanType::DONE;

                            // set other player to wait, so the move isn't done twice
                            moves[other].type = MoveType::WAIT;

                            break;
                        }
                    }
                }
            }
            else if( men[m].plan.type == PlanType::TRANSFER && men[m].plan.route.nodes.size() == 2 && men[m].plan.route.req != -1 )
            {
                int next_island = men[m].plan.route.nodes[1];

                if( bridges[ men[m].island ][next_island].is &&
                    ( bridges[ men[m].island ][next_island].owner[0].idx == m || bridges[ men[m].island ][next_island].owner[1].idx == m ) &&
                    bridges[ men[m].island ][next_island].owner[1].idx != -1 )
                {
                    int other;
                    if( bridges[ men[m].island ][ next_island ].owner[0].idx == m )
                    {
                        other = bridges[ men[m].island ][ next_island ].owner[1].idx;
                    }
                    else
                    {
                        other = bridges[ men[m].island ][ next_island ].owner[0].idx;
                    }

                    if( men[other].island == next_island && men[other].plan.type == PlanType::TRANSFER && men[other].plan.route.nodes.size() == 2 )
                    {
                        // int needed = men[m].plan.route.req - men[m].carried;
                        int needed = MAX_CAPACITY - men[m].carried;
                        int grab = min( needed, distance[ men[m].island ][ next_island ] );

                        moves[m].type = MoveType::MULTICOLLECT;
                        moves[m].to = next_island;
                        moves[m].with = other;
                        moves[m].ctx = grab;

                        moves[other].type = MoveType::MULTICOLLECT;
                        moves[other].to = men[m].island;
                        moves[other].with = m;
                        moves[other].ctx = distance[ men[m].island ][ next_island ] - grab;

                        if( !is_valid_team_collect( moves[m], moves[other], m, other ) )
                        {
                            cerr << "shit team collect b" << endl;
                        }

                        perform_team_collect( m, other, moves[m], moves[other] );
                        men[m].plan.type = PlanType::DONE;
                        men[other].plan.type = PlanType::DONE;

                        // set other player to wait, so the move isn't done twice
                        moves[other].type = MoveType::WAIT;

                        break;
                    }
                }
            }
        }
    }

    // MARK: make plan

    void find_deliveries()
    {
        DEBUG( cerr << "* Deliveries:" << endl; )
        FORI( m, 0, nr_men )
        {
            if( men[m].message.dst > -1 )
            {
                auto route = find_shortest_fitting_route( m, men[m].island, men[m].message.dst );
                if( !route.nodes.empty() )
                {
                    DEBUG( cerr << "Man " << setw(2) << m << ": route found, with length " << route.nodes.size() - 1 << " and slack " << men[m].owned - route.req << endl;
                    cerr << "        ";
                    for( int i : route.nodes ) cerr << i << " ";
                    cerr << endl; )
                    men[m].plan.type = PlanType::EN_ROUTE;
                    men[m].plan.route = route;
                }
                else
                {
                    auto route = find_route_with_min_requirement( m, men[m].island, men[m].message.dst );
                    if( !route.nodes.empty() )
                    {
                        if( route.req <= MAX_CAPACITY )
                        {
                            DEBUG( cerr << "Man " << setw(2) << m << ": route found, with length " << route.nodes.size() - 1
                                        << " but requires " << route.req << " while only having " << men[m].owned
                                        << ", so need transfer or cooperation" << endl;
                            cerr << "        ";
                            for( int i : route.nodes ) cerr << i << " ";
                            cerr << endl; )
                            men[m].plan.type = PlanType::FIND_TRANSFER_COOP;
                            men[m].plan.route = route;
                        }
                        else
                        {
                            DEBUG( cerr << "Man " << setw(2) << m << ": route found, with length " << route.nodes.size() - 1
                                        << " but requires " << route.req << " while only having " << men[m].owned
                                        << ", so needs cooperation" << endl;
                            cerr << "        ";
                            for( int i : route.nodes ) cerr << i << " ";
                            cerr << endl; )
                            if( men[m].owned == MAX_CAPACITY )
                            {
                                men[m].plan.type = PlanType::FIND_COOP;
                            }
                            else
                            {
                                men[m].plan.type = PlanType::FIND_TRANSFER_COOP;
                            }
                            men[m].plan.route = route;
                        }
                    }
                    else
                    {
                        DEBUG( cerr << "Man " << setw(2) << m << ": no route possible! (bug in generator?)" << endl; )
                        men[m].plan.type = PlanType::WAIT;
                    }
                }
            }
            else
            {
                // cerr << "Man " << m << ": skip" << endl;
            }
        }
    }

    void find_pickups()
    {
        DEBUG( cerr << "* Pickups:" << endl; )

        vector<vector<int>> man_order_dist( nr_men, vector<int>( nr_orders, numeric_limits<int>::max() ) );
        FORI( m, 0, nr_men )
        {
            if( men[m].message.dst == -1 )
            {
                man_order_dist[m] = find_fitting_distances_to_all_orders( m );
            }
        }

        while( assign_greedy( man_order_dist ) ) {}
    }

    bool assign_greedy( vector<vector<int>>& man_order_dist )
    {
        int closest = numeric_limits<int>::max();
        int man = -1;
        int order = -1;
        FORI( m, 0, nr_men )
        {
            FORI( o, 0, nr_orders )
            {
                if( man_order_dist[m][o] < closest )
                {
                    closest = man_order_dist[m][o];
                    man = m;
                    order = o;
                }
            }
        }

        if( man == -1 )
        {
            // DEBUG( cerr << "Remaining men unable to independently route to pickup" << endl; )
            return false;
        }

        FORI( m, 0, nr_men )
        {
            man_order_dist[m][ order ] = numeric_limits<int>::max();
        }
        FORI( o, 0, nr_orders )
        {
            man_order_dist[ man ][o] = numeric_limits<int>::max();
        }

        men[man].plan.type = PlanType::EN_ROUTE;
        men[man].plan.route = find_shortest_fitting_route( man, men[man].island, orders[order].org );

        DEBUG( cerr << "Man " << setw(2) << man << ": pickup found, with length " << men[man].plan.route.nodes.size() - 1 << " and slack " << men[man].owned - men[man].plan.route.req << endl;
        cerr << "        ";
        for( int i : men[man].plan.route.nodes ) cerr << i << " ";
        cerr << endl; )

        return true;
    }

    // check if any of the men that require cooperation are a match:
    // - using same bridge in opposite direction within their routes
    // - can both walk up to bridge independently
    // if found, can change plan to independent route to bridge side
    // if one already there, change plan to wait for bridge (so if someone else plunks it down, they can go across)
    void find_cooperations_for_stuck_men()
    {
        DEBUG( cerr << "* Coops:" << endl; )

        FORI( m, 0, nr_men )
        {
            if( men[m].plan.type == PlanType::FIND_TRANSFER_COOP || men[m].plan.type == PlanType::FIND_COOP )
            {
                bool planned = find_planned_bridge( m );
                if( !planned )
                {
                    FORI( n, 0, nr_men )
                    {
                        if( men[n].plan.type == PlanType::FIND_TRANSFER_COOP || men[n].plan.type == PlanType::FIND_COOP )
                        {
                            bool coop = find_coop_opportunity( m, n );
                            if( coop )
                            {
                                break;
                            }
                        }
                    }
                }
            }
        }
    }

    bool find_planned_bridge( int m )
    {
        FORI( mi, 0, men[m].plan.route.nodes.size() - 1 )
        {
            if( distance[ men[m].plan.route.nodes[mi] ][ men[m].plan.route.nodes[mi+1] ] > men[m].owned )
            {
                if( bridges[ men[m].plan.route.nodes[mi] ][ men[m].plan.route.nodes[mi+1] ].is ||
                    bridges[ men[m].plan.route.nodes[mi] ][ men[m].plan.route.nodes[mi+1] ].planned )
                {
                    DEBUG( cerr << "Man " << m << " can wait on planned bridge " << men[m].plan.route.nodes[mi] << " - " << men[m].plan.route.nodes[mi+1] << endl; )

                    if( mi == 0 )
                    {
                        men[m].plan.type = PlanType::WAIT_FOR_BRIDGE;
                    }
                    else
                    {
                        // men[m].plan.type = PlanType::EN_ROUTE;

                        auto mrt = find_shortest_fitting_route( m, men[m].island, men[m].plan.route.nodes[mi] );
                        if( !mrt.nodes.empty() )
                            men[m].plan.route = mrt;
                    }

                    return true;
                }
            } 
        }
        return false;
    }

    // return if found
    bool find_coop_opportunity( int m, int n )
    {
        FORI( mi, 0, men[m].plan.route.nodes.size() - 1 )
        {
            FORI( ni, 0, men[n].plan.route.nodes.size() - 1 )
            {
                if( distance[ men[m].plan.route.nodes[mi] ][ men[m].plan.route.nodes[mi+1] ] > men[m].owned && 
                    distance[ men[m].plan.route.nodes[mi] ][ men[m].plan.route.nodes[mi+1] ] > men[n].owned && 
                    men[m].plan.route.nodes[mi] == men[n].plan.route.nodes[ni+1] && men[m].plan.route.nodes[mi+1] == men[n].plan.route.nodes[ni] )
                {
                    auto mrt = find_shortest_fitting_route( m, men[m].island, men[m].plan.route.nodes[mi] );
                    auto nrt = find_shortest_fitting_route( n, men[n].island, men[n].plan.route.nodes[ni] );

                    if( !mrt.nodes.empty() && !nrt.nodes.empty() )
                    {
                        DEBUG( cerr << "Men " << m << " and " << n << " can cooperate on bridge " << men[m].plan.route.nodes[mi] << " - " << men[m].plan.route.nodes[mi+1] << endl; )
                        
                        bridges[ men[m].plan.route.nodes[mi] ][ men[m].plan.route.nodes[mi+1] ].planned = true;
                        bridges[ men[m].plan.route.nodes[mi+1] ][ men[m].plan.route.nodes[mi] ].planned = true;

                        if( mi == 0 )
                        {
                            men[m].plan.type = PlanType::WAIT_FOR_BRIDGE;
                        }
                        else
                        {
                            men[m].plan.type = PlanType::EN_ROUTE;
                            men[m].plan.route = mrt;
                        }

                        if( ni == 0 )
                        {
                            men[n].plan.type = PlanType::WAIT_FOR_BRIDGE;
                        }
                        else
                        {
                            men[n].plan.type = PlanType::EN_ROUTE;
                            men[n].plan.route = nrt;
                        }

                        return true;
                    }
                }
            }
        }
        return false;
    }

    void find_transfers_for_stuck_men()
    {
        DEBUG( cerr << "* Transfers:" << endl; )

        FORI( m, 0, nr_men )
        {
            if( men[m].plan.type == PlanType::FIND_TRANSFER_COOP )
            {
                bool found = find_direct_transfer( m );
                if( found ) break;

                found = find_sidestep_transfer( m );
                if( found ) break;

                found = find_travel_transfer( m );
                if( found ) break;
            }
        }
    }

    bool find_direct_transfer( int m )
    {
        FORI( n, 0, nr_men )
        {
            // TODO: consider more men
            if( m != n && men[n].plan.type == PlanType::WAIT )
            {
                if( men[m].island != men[n].island && distance[ men[m].island ][ men[n].island ] <= men[m].owned + men[n].owned )
                {
                    DEBUG( cerr << "Men " << m << " and " << n << " can transfer immediately on " << men[m].island << " - " << men[n].island << endl; )
                    
                    men[m].plan.type = PlanType::TRANSFER;
                    men[m].plan.route.nodes.clear();
                    men[m].plan.route.nodes.push_back( men[m].island );
                    men[m].plan.route.nodes.push_back( men[n].island );

                    men[n].plan.type = PlanType::TRANSFER;
                    men[n].plan.route.req = -1;
                    men[n].plan.route.nodes.clear();
                    men[n].plan.route.nodes.push_back( men[n].island );
                    men[n].plan.route.nodes.push_back( men[m].island );

                    return true;
                }
            }
        }
        return false;
    }

    bool find_sidestep_transfer( int m )
    {
        FORI( n, 0, nr_men )
        {
            // TODO: consider more men
            if( m != n && men[n].plan.type == PlanType::WAIT )
            {
                if( men[m].island == men[n].island )
                {
                    int step = -1;
                    FORI( i, 0, nr_islands )
                    {
                        if( distance[ men[n].island ][i] <= men[n].owned )
                        {
                            step = i;
                            break;
                        }
                    }

                    if( step != -1 )
                    {
                        DEBUG( cerr << "Men " << m << " and " << n << " can transfer after side-step on " << men[m].island << " - " << step << endl; )
                        
                        men[m].plan.type = PlanType::DONE;

                        men[n].plan.type = PlanType::TRANSFER;
                        men[n].plan.route.req = -1;
                        men[n].plan.route.nodes.clear();
                        men[n].plan.route.nodes.push_back( men[n].island );
                        men[n].plan.route.nodes.push_back( step );
                        men[n].plan.route.nodes.push_back( men[m].island );

                        return true;
                    }
                }
            }
        }
        return false;
    }

    bool find_travel_transfer( int m )
    {
        int shortest = numeric_limits<int>::max();
        int best_n = -1;
        FORI( n, 0, nr_men )
        {
            // TODO: consider more men
            if( m != n && men[n].plan.type == PlanType::WAIT )
            {
                auto rtn = find_shortest_fitting_route( n, men[n].island, men[m].island );
                if( !rtn.nodes.empty() && rtn.nodes.size() < shortest )
                {
                    shortest = rtn.nodes.size();
                    best_n = n;
                }
            }
        }

        if( best_n != -1 )
        {
            DEBUG( cerr << "Men " << m << " and " << best_n << " can transfer after travel on " << men[m].island << " - " << men[best_n].island << endl; )
            
            men[m].plan.type = PlanType::DONE;

            men[best_n].plan.type = PlanType::TRANSFER;
            men[best_n].plan.route = find_shortest_fitting_route( best_n, men[best_n].island, men[m].island );

            return true;
        }
        else
        {
            return false;
        }
    }

    void any_progress_for_remaining_stuck()
    {
        DEBUG( cerr << "* Fallbacks:" << endl; )

        FORI( m, 0, nr_men )
        {
            if( men[m].plan.type == PlanType::FIND_TRANSFER_COOP || men[m].plan.type == PlanType::FIND_COOP )
            {
                if( men[m].plan.route.nodes.size() > 1 )
                {
                    int next = men[m].plan.route.nodes[1];

                    if( distance[ men[m].island ][ next ] <= men[m].owned )
                    {
                        DEBUG( cerr << "Man " << m << ": can continue for now to " << next << endl; )

                        men[m].plan.type = PlanType::EN_ROUTE;
                    }
                }
            }
        }

        FORI( m, 0, nr_men )
        {
            if( men[m].plan.type == PlanType::FIND_TRANSFER_COOP || men[m].plan.type == PlanType::FIND_COOP )
            {
                find_direct_switch( m );
            }
        }

        FORI( m, 0, nr_men )
        {
            if( men[m].plan.type == PlanType::FIND_TRANSFER_COOP || men[m].plan.type == PlanType::FIND_COOP )
            {
                find_other_switch( m );
            }
        }

        FORI( m, 0, nr_men )
        {
            if( men[m].plan.type == PlanType::FIND_TRANSFER_COOP || men[m].plan.type == PlanType::FIND_COOP )
            {
                DEBUG( cerr << "Man " << m << ": cannot continue" << endl; )
                men[m].plan.type = PlanType::EN_ROUTE;
            }
        }
    }

    void find_other_switch( int m )
    {
        int closest = numeric_limits<int>::max();
        int best_n = -1;
        FORI( n, 0, nr_men )
        {
            if( men[n].plan.type == PlanType::WAIT )
            {
                auto route = find_shortest_fitting_route( n, men[n].island, men[m].plan.route.nodes[1] );
                if( !route.nodes.empty() && route.nodes.size() < closest )
                {
                    closest = route.nodes.size();
                    best_n = n;
                }
            }
        }

        if( best_n == -1 )
        {
            FORI( n, 0, nr_men )
            {
                if( men[n].plan.type == PlanType::FIND_TRANSFER_COOP || men[n].plan.type == PlanType::FIND_COOP )
                {
                    auto route = find_shortest_fitting_route( n, men[n].island, men[m].plan.route.nodes[1] );
                    if( !route.nodes.empty() && route.nodes.size() < 5 && route.nodes.size() < closest )
                    {
                        closest = route.nodes.size();
                        best_n = n;
                    }
                }
            }
        }

        if( best_n != -1 )
        {
            DEBUG( cerr << "Men " << m << " can switch after " << best_n << " approaches " << men[m].plan.route.nodes[1] << endl; )

            men[m].plan.type = PlanType::WAIT_FOR_BRIDGE;
            men[best_n].plan.type = PlanType::EN_ROUTE;
            men[best_n].plan.route = find_shortest_fitting_route( best_n, men[best_n].island, men[m].plan.route.nodes[1] );
        }
    }

    void find_direct_switch( int m )
    {
        FORI( n, 0, nr_men )
        {
            if( men[n].plan.type == PlanType::FIND_TRANSFER_COOP || men[n].plan.type == PlanType::FIND_COOP || men[n].plan.type == PlanType::WAIT )
            {
                // would a switch unstuck them?

                if( distance[ men[m].island ][ men[n].island ] <= men[m].owned + men[n].owned )
                {
                    auto rtm = find_shortest_fitting_route( m, men[n].island, men[m].message.dst );
                    auto rtmm = find_route_with_min_requirement( m, men[n].island, men[m].message.dst );
                    bool goodm = !rtm.nodes.empty() || ( !rtmm.nodes.empty() && rtmm.req < men[m].plan.route.req );

                    bool goodn;
                    if( men[n].plan.type == PlanType::WAIT )
                    {
                        goodn = false;
                    }
                    else
                    {
                        auto rtn = find_shortest_fitting_route( n, men[m].island, men[n].message.dst );
                        auto rtnm = find_route_with_min_requirement( n, men[m].island, men[n].message.dst );
                        goodn = !rtn.nodes.empty() || ( !rtnm.nodes.empty() && rtnm.req < men[n].plan.route.req );
                    }

                    if( goodm || goodn )
                    {
                        DEBUG( cerr << "Men " << m << " and " << n << " can switch directly on bridge " << men[m].island << " - " << men[n].island << endl; )

                        men[m].plan.type = PlanType::WAIT_FOR_BRIDGE;
                        men[m].plan.route.nodes.clear();
                        men[m].plan.route.nodes.push_back( men[m].island );
                        men[m].plan.route.nodes.push_back( men[n].island );

                        men[n].plan.type = PlanType::WAIT_FOR_BRIDGE;
                        men[n].plan.route.nodes.clear();
                        men[n].plan.route.nodes.push_back( men[n].island );
                        men[n].plan.route.nodes.push_back( men[m].island );

                        break;
                    }
                }
            }
        }
    }

    // random:
    // - build to random neighbor, if you own nothing AND (no other bridge OR 50% chance)
    // - step over random bridge, if we own nothing else AND 50% chance
    // - collect any bridge we own
    void random_for_no_planners()
    {
        FORI( m, 0, nr_men )
        {
            if( men[m].plan.type == PlanType::WAIT )
                men[m].plan.type = PlanType::RANDOM;
        }
    }

    // MARK: route finding

    struct ReqStep
    {
        int req;
        int steps;
    };

    Route find_shortest_fitting_route( int mi, int org, int tgt )
    {
        array<int,MAX_ISLANDS> req{};
        FORI( i, 0, nr_islands ) req[i] = 1000;
        req[ org ] = 0;

        vector<Route> final;
        final.reserve( 100 );

        vector<Route> routes;
        routes.reserve( 1000 );
        routes.push_back( {} );
        routes.back().req = 0;
        routes.back().nodes.push_back( org );

        vector<Route> next;
        next.reserve( 1000 );

        bool done = false;
        bool change = true;
        int it = 0;
        while( !done && change )
        {
            it++;
            change = false;
            next.clear();

            for( auto rt : routes )
            {
                if( rt.nodes.back() == tgt )
                {
                    final.push_back( rt );
                    done = true;
                }
                else
                {
                    FORI( i, 0, nr_islands )
                    {
                        if( i != rt.nodes.back() && distance[ rt.nodes.back() ][i] <= men[mi].owned )
                        {
                            int new_req = ( it == 1 && bridges[rt.nodes.back()][i].is ) ? 0 : max( rt.req, distance[ rt.nodes.back() ][i] );
                            if( new_req < req[i] )
                            {
                                req[i] = new_req;
                                next.push_back( rt );
                                next.back().nodes.push_back(i);
                                next.back().req = new_req;
                                change = true;
                            }
                        }
                    }
                }
            } 

            swap( routes, next );
        }

        if( final.empty() )
        {
            return {};
        }
        else
        {
            auto it = min_element( BE( final ), []( const auto& a, const auto& b ){ return a.req < b.req; } );
            return *it;
        }
    }

    vector<int> find_fitting_distances_to_all_orders( int m )
    {
        array<int,MAX_ISLANDS> dist{};
        fill_n( dist.begin(), nr_islands, numeric_limits<int>::max() );
        dist[ men[m].island ] = 0;

        vector<int> frontier;
        frontier.reserve( MAX_ISLANDS );
        frontier.push_back( men[m].island );

        vector<int> next;
        next.reserve( MAX_ISLANDS );

        while( !frontier.empty() )
        {
            next.clear();

            for( auto f : frontier )
            {
                FORI( i, 0, nr_islands )
                {
                    if( i != f && distance[f][i] <= men[m].owned && dist[f] + 1 < dist[i] )
                    {
                        dist[i] = dist[f] + 1;
                        next.push_back( i );
                    }
                }
            } 

            swap( frontier, next );
        }

        vector<int> order_dist( nr_orders );
        FORI( o, 0, nr_orders )
        {
            order_dist[o] = dist[ orders[o].org ];
        }
        return order_dist;
    }

    // find route with minimum maximum required length
    // only keep a route to a certain node, if it reached there with lower req or lower steps than other routes before
    Route find_route_with_min_requirement( int mi, int org, int tgt )
    {
        vector<ReqStep> islands( nr_islands, { numeric_limits<int>::max(), numeric_limits<int>::max() } );
        vector<Route> routes;

        routes.reserve( 1000 );
        routes.push_back( {} );
        routes.back().req = 0;
        routes.back().nodes.push_back( org );

        islands[ org ] = { 0, 0 };

        vector<Route> next;
        next.reserve( 1000 );

        bool change = true;
        while( change )
        {
            change = false;

            next.clear();

            for( auto rt : routes )
            {
                if( rt.nodes.back() == tgt )
                {
                    if( rt.req == islands[ tgt ].req )
                    {
                        next.push_back( rt );
                    }
                }
                else
                {
                    FORI( i, 0, nr_islands )
                    {
                        if( i != rt.nodes.back() && distance[ rt.nodes.back() ][i] <= MAX_BRIDGE_LENGTH )
                        {
                            int new_req = max( rt.req, distance[ rt.nodes.back() ][i] );
                            if( new_req < islands[i].req || rt.nodes.size() < islands[i].steps )
                            {
                                change = true;
                                islands[i].req = new_req;
                                islands[i].steps = rt.nodes.size();
                                next.push_back( rt );
                                next.back().nodes.push_back(i);
                                next.back().req = new_req;
                            }
                        }
                    }
                }
            } 

            swap( routes, next );
        }

        // DEBUG( cerr << m << " " << routes.size() << endl;
        // FORI( r, 0, routes.size() )
        // {
        //     cerr << routes[r].req << ": ";
        //     FORI( n, 0, routes[r].nodes.size() )
        //     {
        //         cerr << routes[r].nodes[n] << " ";
        //     }
        //     cerr << endl;
        // } )

        if( routes.empty() )
        {
            return {};
        }
        else
        {
            auto it = min_element( BE( routes ), []( const auto& a, const auto& b ){ return a.req < b.req; } );
            return *it;
        }
    }


};

int main()
{
    State state{};
    state.read_init_input();

    for( int t = 0; t < MAX_TURNS; t++ )
    {
        state.read_turn_input(t);

        if( state.elapsed_time_ms < 9800 )
        {
            auto moves = state.find_best_moves();
            state.write_moves( moves );
        }
        else
        {
            Moves moves( state.nr_men );
            state.write_moves( moves );
        }
    }

    return 0;
}