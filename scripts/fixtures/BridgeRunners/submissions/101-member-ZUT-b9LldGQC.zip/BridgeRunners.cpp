#include <cmath>
#include <iostream>
#include <queue>
#include <string>
#include <vector>
using namespace std;

struct BridgeMan {
  int island = -1;
  int carry = 50;
  int target = -1;
  int edge_u = -1, edge_v = -1;
  // for long bridge
  bool has_long_bridge = false;
  int partner_id = -1;
};

struct Order {
  int orig = -1, dest = -1;
};

enum class Act { MOVE, UNPACK, PACK, TEAMUNPACK, TEAMPACK, MSG };

struct Command {
  Act t;
  int a = -1, b = -1, c = -1;  // a: bridgemanID b: islandID c: unused (MOVE, UNPACK, PACK), a: bridgemanID1 b: bridgemanID2 c: length1 (TEAMUNPACK, TEAMPACK)
  string s;
};

static string to_string(const Command& cmd) {
  switch (cmd.t) {
    case Act::MOVE:
      return "MOVE " + to_string(cmd.a) + " " + to_string(cmd.b);
    case Act::UNPACK:
      return "UNPACK " + to_string(cmd.a) + " " + to_string(cmd.b);
    case Act::PACK:
      return "PACK " + to_string(cmd.a) + " " + to_string(cmd.b);
    case Act::TEAMUNPACK:
      return "TEAMUNPACK " + to_string(cmd.a) + " " + to_string(cmd.b) + " " + to_string(cmd.c);
    case Act::TEAMPACK:
      return "TEAMPACK " + to_string(cmd.a) + " " + to_string(cmd.b) + " " + to_string(cmd.c);
    case Act::MSG:
      return "MSG " + cmd.s;
  }
  return "";
}

class Solver {
 public:
  Solver() {}

  void initial_input() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    cin >> N >> B >> O;
    dist_mat.assign(N, vector<int>(N));
    for (int i = 0; i < N; ++i) {
      for (int j = 0; j < N; ++j) {
        cin >> dist_mat[i][j];
      }
    }
    bridge_mans.assign(B, {});
    orders.assign(O, {});

    graph50_adj.assign(N, vector<int>());
    for (int i = 0; i < N; ++i) {
      for (int j = 0; j < N; ++j) {
        if (i == j) {
          continue;
        }
        if (dist_mat[i][j] <= 50) {
          graph50_adj[i].push_back(j);
        }
      }
    }

    graph50_mat.assign(N, vector<int>(N, 1 << 28));
    for (int i = 0; i < N; ++i) {
      queue<int> q;
      q.push(i);
      graph50_mat[i][i] = 0;
      while (!q.empty()) {
        int u = q.front();
        q.pop();
        for (int v : graph50_adj[u]) {
          if (graph50_mat[i][v] > graph50_mat[i][u] + 1) {
            graph50_mat[i][v] = graph50_mat[i][u] + 1;
            q.push(v);
          }
        }
      }
    }

    vector<vector<pair<int, int>>> graph_hungarian_adj(N, vector<pair<int, int>>());
    for (int i = 0; i < N; ++i) {
      for (int j = 0; j < N; ++j) {
        if (i == j) {
          continue;
        }
        if (dist_mat[i][j] <= 50) {
          graph_hungarian_adj[i].push_back({1, j});
        } else if (dist_mat[i][j] <= 100) {
          graph_hungarian_adj[i].push_back({2, j});
        }
      }
    }
    graph_hungarian_mat.assign(N, vector<int>(N, 1 << 28));
    for (int i = 0; i < N; ++i) {
      priority_queue<pair<int, int>, vector<pair<int, int>>, greater<pair<int, int>>> pq;
      pq.push({0, i});
      graph_hungarian_mat[i][i] = 0;
      while (!pq.empty()) {
        auto [cost, u] = pq.top();
        pq.pop();
        if (graph_hungarian_mat[i][u] < cost) {
          continue;
        }
        for (auto [edge_cost, v] : graph_hungarian_adj[u]) {
          if (graph_hungarian_mat[i][v] > graph_hungarian_mat[i][u] + edge_cost) {
            graph_hungarian_mat[i][v] = graph_hungarian_mat[i][u] + edge_cost;
            pq.push({graph_hungarian_mat[i][v], v});
          }
        }
      }
    }


    for (int i = 0; i < N; ++i) {
      for (int j = 0; j < N; ++j) {
        if (i == j) {
          continue;
        }
        if (dist_mat[i][j] > 50 && dist_mat[i][j] <= 100) {
          dist100_edges.push_back({i, j});
        }
      }
    }

    bridge_available_mat.assign(N, vector<bool>(N, false));
  }

  void turn_input() {
    int elapsed_ms;
    cin >> elapsed_ms;
    for (int i = 0; i < B; ++i) {
      cin >> bridge_mans[i].island >> bridge_mans[i].carry >> bridge_mans[i].target;
    }
    for (int i = 0; i < O; ++i) {
      cin >> orders[i].orig >> orders[i].dest;
    }
  }

  vector<Command> solve() {
    vector<Command> commands;

    vector<int> order_assigned(O, false);

    // --- Hungarian-based assignment (orders -> idle bridgemen) ---
    const int INF = 1 << 28;
    const int WAIT_COST = 200;

    vector<int> bridge_man_targets(B, -1);

    vector<int> idle_ids;
    idle_ids.reserve(B);
    for (int i = 0; i < B; ++i) {
      if (bridge_mans[i].target != -1) {
        // 既にメッセージ所持中の人はそのまま配達先へ
        bridge_man_targets[i] = bridge_mans[i].target;  // dest へ
      } else if (bridge_mans[i].has_long_bridge) {
        // 長い橋にかかわっているひとも割当対象から外す
        continue;
      } else {
        idle_ids.push_back(i);  // 割当対象
      }
    }

    int R = (int)idle_ids.size();  // rows: idle men
    int K = O;                     // cols: orders（orig）
    int n = max(R, K);             // Hungarianは正方にする

    // コスト行列 A[n][n]：左上の R×K に実コスト、余りはダミー
    vector<vector<int>> A(n, vector<int>(n, 0));
    for (int ri = 0; ri < n; ++ri) {
      for (int cj = 0; cj < n; ++cj) {
        if (ri < R && cj < K) {
          int id = idle_ids[ri];
          int orig = orders[cj].orig;
          int dest = orders[cj].dest;
          if (orig < 0 || dest < 0) {
            A[ri][cj] = INF;
            continue;
          }
          int d1 = graph_hungarian_mat[bridge_mans[id].island][orig];
          int d2 = graph_hungarian_mat[orig][dest];
          A[ri][cj] = d1 + d2;  // 近さ: 現在地→orig + orig→dest
        } else if (ri < R && cj >= K) {
          // ダミー列：その人は今ターンは“何もしない/待機”
          A[ri][cj] = WAIT_COST;
        } else {
          // ダミー行：余った注文をダミーの人に割当（コスト0でOK）
          A[ri][cj] = 0;
        }
      }
    }

    // Hungarian（最小コスト割当） O(n^3)
    auto hungarian = [&](const vector<vector<int>>& a) {
      int n = (int)a.size();
      vector<int> u(n + 1), v(n + 1), p(n + 1), way(n + 1);
      for (int i = 1; i <= n; ++i) {
        p[0] = i;
        int j0 = 0;
        vector<int> minv(n + 1, INF);
        vector<char> used(n + 1, false);
        do {
          used[j0] = true;
          int i0 = p[j0], delta = INF, j1 = 0;
          for (int j = 1; j <= n; ++j)
            if (!used[j]) {
              int cur = a[i0 - 1][j - 1] - u[i0] - v[j];
              if (cur < minv[j]) {
                minv[j] = cur;
                way[j] = j0;
              }
              if (minv[j] < delta) {
                delta = minv[j];
                j1 = j;
              }
            }
          for (int j = 0; j <= n; ++j) {
            if (used[j]) {
              u[p[j]] += delta;
              v[j] -= delta;
            } else {
              minv[j] -= delta;
            }
          }
          j0 = j1;
        } while (p[j0] != 0);
        do {
          int j1 = way[j0];
          p[j0] = p[j1];
          j0 = j1;
        } while (j0);
      }
      vector<int> assign(n, -1);  // row i -> col assign[i]
      for (int j = 1; j <= n; ++j)
        if (p[j]) assign[p[j] - 1] = j - 1;
      return assign;
    };

    vector<int> assign = hungarian(A);

    // 割当結果を bridge_man_targets へ反映（ダミー列/INFは未割当）
    for (int ri = 0; ri < R; ++ri) {
      int cj = assign[ri];
      if (cj >= 0 && cj < K && A[ri][cj] < INF / 2) {
        int id = idle_ids[ri];
        bridge_man_targets[id] = orders[cj].orig;  // まずorigへ向かう
      }
    }

    // cerr allocation result
    for (int i = 0; i < B; ++i) {
      if (bridge_man_targets[i] != -1) {
        cerr << i << " -> " << bridge_man_targets[i] << endl;
      }
    }

    auto rulebase_one_step = [&](int bridge_man_id, int target) {
      // target は -1 ではないとする
      // bridge man と target(IslandId) は graph50 でつながっているものとする
      BridgeMan& bridge_man = bridge_mans[bridge_man_id];

      int current = bridge_man.island;
      int edge_u = bridge_man.edge_u;
      int edge_v = bridge_man.edge_v;
      int edge_next = (edge_u == current) ? edge_v : edge_u;
      if (edge_u != -1 && edge_v != -1) {
        // 橋が unpack されている状態
        if (graph50_mat[current][target] > graph50_mat[edge_next][target]) {
          // 橋が使えるなら、橋を渡る
          commands.push_back(Command{Act::MOVE, bridge_man_id, edge_next});
        } else {
          // 橋が使えないなら、橋を片付ける
          commands.push_back(Command{Act::PACK, bridge_man_id, edge_next});
          bridge_man.edge_u = -1;
          bridge_man.edge_v = -1;
          bridge_available_mat[edge_u][edge_v] = false;
          bridge_available_mat[edge_v][edge_u] = false;
        }
      } else {
        bool found_bridge = false;
        for (auto next_island_id : graph50_adj[current]) {
          if (graph50_mat[next_island_id][target] < graph50_mat[current][target] && bridge_available_mat[current][next_island_id]) {
            // 目的地に行くのに使える橋を探す
            commands.push_back(Command{Act::MOVE, bridge_man_id, next_island_id});
            found_bridge = true;
            break;
          }
        }
        if (!found_bridge) {
          // ないなら、自分で橋を用意する
          for (auto next_island_id : graph50_adj[current]) {
            if (graph50_mat[next_island_id][target] < graph50_mat[current][target] && !bridge_available_mat[current][next_island_id]) {
              commands.push_back(Command{Act::UNPACK, bridge_man_id, next_island_id});
              bridge_man.edge_u = current;
              bridge_man.edge_v = next_island_id;
              bridge_available_mat[current][next_island_id] = true;
              bridge_available_mat[next_island_id][current] = true;
              break;
            }
          }
        }
        // すでに目的についていて、橋もしまってある状態
      }
    };

    // --- 各人の行動決定 ---
    for (int bridge_man_id = 0; bridge_man_id < B; ++bridge_man_id) {
      if (bridge_man_targets[bridge_man_id] == -1) {
        continue;
      }
      if (bridge_mans[bridge_man_id].has_long_bridge) {
        // 長い橋にかかわっている人は割当対象から外す
        continue;
      }
      int target = bridge_man_targets[bridge_man_id];
      int current = bridge_mans[bridge_man_id].island;

      if (graph50_mat[current][target] >= (1 << 26)) {
        cerr << bridge_man_id << " no path to " << target << " from " << current << endl;
        // 50以内の道がないなら、何もしない
        continue;
      }

      rulebase_one_step(bridge_man_id, target);
    }

    cerr << " " << endl;
    cerr << " " << endl;
    cerr << "greedy is end: " << commands.size() << endl;
    for (auto cmd : commands) {
      cerr << to_string(cmd) << endl;
    }

    // 二人組の、長橋上での行動決定（それ以外は、移動行動）
    for (int bridge_id = 0; bridge_id < B; ++bridge_id) {
      if (!bridge_mans[bridge_id].has_long_bridge) {
        continue;
      }
      cerr << "bridge " << bridge_id << " has long bridge with " << bridge_mans[bridge_id].partner_id << endl;
      cerr << "u = " << bridge_mans[bridge_id].edge_u << ", v = " << bridge_mans[bridge_id].edge_v << endl;
      if (bridge_id > bridge_mans[bridge_id].partner_id) {
        // 重複があるので、片方だけ処理できればいい。
        continue;
      }
      // 以降は、bridge_id と partner_id の二人組の行動決定 move(swap) か teampack
      // if swap will work, swap, else teampack
      int partner_id = bridge_mans[bridge_id].partner_id;
      int now_my_dist = -1;
      if (bridge_mans[bridge_id].target == -1) {
        now_my_dist = 1 << 28;
      } else {
        now_my_dist = graph50_mat[bridge_mans[bridge_id].island][bridge_mans[bridge_id].target];
      }
      int now_partner_dist = -1;
      if (bridge_mans[partner_id].target == -1) {
        now_partner_dist = 1 << 28;
      } else {
        now_partner_dist = graph50_mat[bridge_mans[partner_id].island][bridge_mans[partner_id].target];
      }
      int swapped_my_dist = -1;
      if (bridge_mans[bridge_id].target == -1) {
        swapped_my_dist = 1 << 28;
      } else {
        swapped_my_dist = graph50_mat[bridge_mans[partner_id].island][bridge_mans[bridge_id].target];
      }
      int swapped_partner_dist = -1;
      if (bridge_mans[partner_id].target == -1) {
        swapped_partner_dist = 1 << 28;
      } else {
        swapped_partner_dist = graph50_mat[bridge_mans[bridge_id].island][bridge_mans[partner_id].target];
      }
      cerr << " now my dist = " << now_my_dist << ", partner dist = " << now_partner_dist << endl;
      if (now_my_dist + now_partner_dist > swapped_my_dist + swapped_partner_dist) {
        cerr << " swap " << bridge_id << " to " << bridge_mans[partner_id].island << ", " << partner_id << " to " << bridge_mans[bridge_id].island << endl;

        // swap is better
        commands.push_back(Command{Act::MOVE, bridge_id, bridge_mans[partner_id].island});
        commands.push_back(Command{Act::MOVE, partner_id, bridge_mans[bridge_id].island});
      } else {
        cerr << " teampack " << bridge_id << " and " << partner_id << endl;
        // teampack
        int u = bridge_mans[bridge_id].edge_u;
        int v = bridge_mans[bridge_id].edge_v;
        cerr << " packing long bridge " << u << " - " << v << endl;
        bridge_available_mat[u][v] = false;
        bridge_available_mat[v][u] = false;
        bridge_mans[bridge_id].has_long_bridge = false;
        cerr << " teampack " << bridge_id << " and " << partner_id << endl;
        bridge_mans[bridge_id].partner_id = -1;
        bridge_mans[bridge_id].edge_u = -1;
        bridge_mans[bridge_id].edge_v = -1;
        bridge_mans[partner_id].has_long_bridge = false;
        bridge_mans[partner_id].partner_id = -1;
        bridge_mans[partner_id].edge_u = -1;
        bridge_mans[partner_id].edge_v = -1;
        cerr << " u=" << u << ", v=" << v << endl;

        // carry が 両方とも 50 となるように pack する
        int my_carry = bridge_mans[bridge_id].carry;
        int length1 = 50 - my_carry;
        commands.push_back(Command{Act::TEAMPACK, bridge_id, partner_id, length1});
      }
    }
    cerr << " " << endl;
    cerr << "after first commands size=" << commands.size() << endl;
    for (auto cmd : commands) {
      cerr << to_string(cmd) << endl;
    }

    // 新しく二人組を作って長い橋を渡りたい人の行動決定
    vector<bool> acted(B, false);
    for (auto cmd : commands) {
      acted[cmd.a] = true;
      // TEAMUNPACK, TEAMPACK のときは b も acted にする
      if (cmd.t == Act::TEAMUNPACK || cmd.t == Act::TEAMPACK) {
        acted[cmd.b] = true;
      }
    }
    for (int free_i = 0; free_i < B; ++free_i) {
      if (acted[free_i]) {
        continue;
      }
      if (bridge_mans[free_i].target == -1) {
        continue;
      }
      // free_i -> (best_u - best_v) -> best_j
      // best_dist = max(dist[free_i][u], dist[v][best_j]) + min(dist[v][free_i target], dist[u][best_j target])
      int best_u = -1;
      int best_v = -1;
      int best_j = -1;
      int best_dist = 1 << 30;
      for (int free_j = 0; free_j < B; ++free_j) {
        if (acted[free_j]) {
          continue;
        }
        if (free_i == free_j) {
          continue;
        }
        // i, j ともに目的がないなら意味ないので continue
        if (bridge_mans[free_i].target == -1 && bridge_mans[free_j].target == -1) {
          continue;
        }
        // 両方とも暇な人同士で、長い橋をかけたい組みを探す
        // i <-> u <-> v <-> j で、最もいい u v を探す
        for (auto [u, v] : dist100_edges) {
          int d1 = graph50_mat[bridge_mans[free_i].island][u];
          int d2 = graph50_mat[bridge_mans[free_j].island][v];
          if (d1 >= (1 << 28) || d2 >= (1 << 28)) {
            continue;
          }
          int d3 = -1;
          if (bridge_mans[free_i].target == -1) {
            d3 = 1 << 28;
          } else {
            d3 = graph50_mat[v][bridge_mans[free_i].target];
          }
          int d4 = -1;
          if (bridge_mans[free_j].target == -1) {
            d4 = 1 << 28;
          } else {
            d4 = graph50_mat[v][bridge_mans[free_j].target];
          }
          if (d3 >= (1 << 28) && d4 >= (1 << 28)) {
            continue;
          }
          int dist = max(d1, d2) + min(d3, d4);
          if (dist < best_dist) {
            best_dist = dist;
            best_u = u;
            best_v = v;
            best_j = free_j;
          }
        }
      }
      cerr << "best for " << free_i << " is " << best_u << " - " << best_v << " with " << best_j << " dist=" << best_dist << endl;
      // free_i に対して良い j があれば採用だし、ないならないでいい。
      if (best_dist < (1 << 30) && best_u != -1 && best_v != -1 && best_j != -1) {
        // free_i == best_u && best_j == best_v なら、長い橋をかける。そうでなければ、free_i -> best_u, best_j -> best_v と動く
        if (bridge_mans[free_i].island == best_u && bridge_mans[best_j].island == best_v && bridge_mans[free_i].carry == 50 && bridge_mans[best_j].carry == 50) {
          // すでに橋があるなら swap move, 橋がないなら unpack
          if (!bridge_available_mat[best_u][best_v]) {
            // unpack
            bridge_mans[free_i].has_long_bridge = true;
            bridge_mans[free_i].partner_id = best_j;
            bridge_mans[free_i].edge_u = best_u;
            bridge_mans[free_i].edge_v = best_v;
            bridge_mans[best_j].has_long_bridge = true;
            bridge_mans[best_j].partner_id = free_i;
            bridge_mans[best_j].edge_u = best_u;
            bridge_mans[best_j].edge_v = best_v;
            bridge_available_mat[best_u][best_v] = true;
            bridge_available_mat[best_v][best_u] = true;
            commands.push_back(Command{Act::TEAMUNPACK, free_i, best_j, 50});
          } else {
            // swap move
            commands.push_back(Command{Act::MOVE, free_i, best_v});
            commands.push_back(Command{Act::MOVE, best_j, best_u});
          }
          acted[free_i] = true;
          acted[best_j] = true;
        } else {
          // move
          cerr << "move " << free_i << " to " << best_u << ", " << best_j << " to " << best_v << endl;
          rulebase_one_step(free_i, best_u);
          acted[free_i] = true;
          rulebase_one_step(best_j, best_v);
          acted[best_j] = true;
        }
      }
    }

    for (int free_i = 0; free_i < B; ++free_i) {
      if (acted[free_i]) {
        continue;
      }
      // free_i -> (best_u - best_v) -> best_j
      // best_dist = max(dist[free_i][u], dist[v][best_j]) + min(dist[v][free_i target], dist[u][best_j target])
      int best_u = -1;
      int best_v = -1;
      int best_j = -1;
      int best_dist = 1 << 30;
      for (int free_j = free_i + 1; free_j < B; ++free_j) {
        if (acted[free_j]) {
          continue;
        }
        if (free_i == free_j) {
          continue;
        }
        // i, j ともに目的がないなら意味ないので continue
        if (bridge_mans[free_i].target == -1 && bridge_mans[free_j].target == -1) {
          continue;
        }
        // 両方とも暇な人同士で、長い橋をかけたい組みを探す
        // i <-> u <-> v <-> j で、最もいい u v を探す
        for (auto [u, v] : dist100_edges) {
          int d1 = graph50_mat[bridge_mans[free_i].island][u];
          int d2 = graph50_mat[bridge_mans[free_j].island][v];
          if (d1 >= (1 << 28) || d2 >= (1 << 28)) {
            continue;
          }
          int d3 = -1;
          if (bridge_mans[free_i].target == -1) {
            d3 = 1 << 28;
          } else {
            d3 = graph50_mat[v][bridge_mans[free_i].target];
          }
          int d4 = -1;
          if (bridge_mans[free_j].target == -1) {
            d4 = 1 << 28;
          } else {
            d4 = graph50_mat[v][bridge_mans[free_j].target];
          }
          if (d3 >= (1 << 28) && d4 >= (1 << 28)) {
            continue;
          }
          int dist = max(d1, d2) + min(d3, d4);
          if (dist < best_dist) {
            best_dist = dist;
            best_u = u;
            best_v = v;
            best_j = free_j;
          }
        }
      }
      cerr << "best for " << free_i << " is " << best_u << " - " << best_v << " with " << best_j << " dist=" << best_dist << endl;
      // free_i に対して良い j があれば採用だし、ないならないでいい。
      if (best_dist < (1 << 30) && best_u != -1 && best_v != -1 && best_j != -1) {
        // free_i == best_u && best_j == best_v なら、長い橋をかける。そうでなければ、free_i -> best_u, best_j -> best_v と動く
        if (bridge_mans[free_i].island == best_u && bridge_mans[best_j].island == best_v && bridge_mans[free_i].carry == 50 && bridge_mans[best_j].carry == 50) {
          // すでに橋があるなら swap move, 橋がないなら unpack
          if (!bridge_available_mat[best_u][best_v]) {
            // unpack
            bridge_mans[free_i].has_long_bridge = true;
            bridge_mans[free_i].partner_id = best_j;
            bridge_mans[free_i].edge_u = best_u;
            bridge_mans[free_i].edge_v = best_v;
            bridge_mans[best_j].has_long_bridge = true;
            bridge_mans[best_j].partner_id = free_i;
            bridge_mans[best_j].edge_u = best_u;
            bridge_mans[best_j].edge_v = best_v;
            bridge_available_mat[best_u][best_v] = true;
            bridge_available_mat[best_v][best_u] = true;
            commands.push_back(Command{Act::TEAMUNPACK, free_i, best_j, 50});
          } else {
            // swap move
            commands.push_back(Command{Act::MOVE, free_i, best_v});
            commands.push_back(Command{Act::MOVE, best_j, best_u});
          }
          acted[free_i] = true;
          acted[best_j] = true;
        } else {
          // move
          cerr << "move " << free_i << " to " << best_u << ", " << best_j << " to " << best_v << endl;
          rulebase_one_step(free_i, best_u);
          acted[free_i] = true;
          rulebase_one_step(best_j, best_v);
          acted[best_j] = true;
        }
      }
    }

    cerr << "deadlock check" << endl;
    // deadlock してしまうことがあるので、graph50 内で動きたい人優先で動かす
    for (int bridge_man_id = 0; bridge_man_id < B; ++bridge_man_id) {
      if (acted[bridge_man_id]) {
        continue;
      }
      if (bridge_mans[bridge_man_id].target != -1) {
        continue;
      }
      int best_target = -1;
      int best_dist = 1 << 28;
      for (const Order& order : orders) {
        if (order.orig == -1) {
          continue;
        }
        if (graph50_mat[bridge_mans[bridge_man_id].island][order.orig] < best_dist) {
          best_dist = graph50_mat[bridge_mans[bridge_man_id].island][order.orig];
          best_target = order.orig;
        }
      }
      if (best_target != -1) {
        rulebase_one_step(bridge_man_id, best_target);
      }
    }
    cerr << "after second commands size=" << commands.size() << endl;
    return commands;
  }

  static void turn_output(const vector<Command>& cmds) {
    if (cmds.empty()) {
      cout << '\n' << flush;
      return;
    }
    for (int i = 0; i < (int)cmds.size(); ++i) {
      if (i != 0) {
        cout << '|';
      }
      cout << to_string(cmds[i]);
    }
    cout << '\n' << flush;
  }

 private:
  int N = -1, B = -1, O = -1;
  vector<BridgeMan> bridge_mans;
  vector<Order> orders;
  vector<vector<int>> dist_mat;
  vector<vector<int>> graph50_adj;
  vector<vector<int>> graph50_mat;
  vector<vector<int>> graph_hungarian_mat;
  vector<pair<int, int>> dist100_edges;
  vector<vector<bool>> bridge_available_mat;
};

int main() {
  Solver solver;
  solver.initial_input();
  for (int turn = 1; turn <= 1000; ++turn) {
    solver.turn_input();
    auto cmds = solver.solve();
    Solver::turn_output(cmds);
  }
  return 0;
}
