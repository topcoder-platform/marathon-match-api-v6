from collections import deque
import sys

g_seed = 777778
def Rand(mod):
    global g_seed
    g_seed = (214013 * g_seed + 2531011)
    return ((g_seed >> 16) & 0x7FFF) % mod

class PathFinder:
    def __init__(self, distances):
        assert distances, "Distances matrix cannot be empty"
        assert len(distances) > 0, "Must have at least one island"
        self.distances = distances
        self.n_islands = len(distances)

        # Validate distance matrix
        for i, row in enumerate(distances):
            assert len(row) == self.n_islands, f"Row {i} has wrong length: {len(row)} != {self.n_islands}"
            assert distances[i][i] == 0, f"Island {i} distance to itself must be 0, got {distances[i][i]}"

    def shortest_paths_with_constraint(self, source, max_edge_length):
        assert 0 <= source < self.n_islands, f"Source {source} out of range [0, {self.n_islands})"
        assert max_edge_length >= 0, f"Max edge length must be non-negative, got {max_edge_length}"

        # BFS with edge length constraint
        distances = [-1] * self.n_islands
        paths = [[] for _ in range(self.n_islands)]
        queue = deque([source])
        distances[source] = 0
        paths[source] = [source]

        while queue:
            current = queue.popleft()

            for next_node in range(self.n_islands):
                if (next_node != current and
                    distances[next_node] == -1 and
                    self.distances[current][next_node] <= max_edge_length):

                    distances[next_node] = distances[current] + 1
                    paths[next_node] = paths[current] + [next_node]
                    queue.append(next_node)

        # Return dict with reachable nodes only
        result = {}
        for node in range(self.n_islands):
            if distances[node] != -1:
                result[node] = (distances[node], paths[node])

        assert source in result, f"Source {source} should always be reachable"
        assert result[source][0] == 0, f"Source distance should be 0, got {result[source][0]}"

        return result

class MessageTracker:
    def __init__(self, n_islands):
        assert n_islands > 0, f"Number of islands must be positive, got {n_islands}"
        self.n_islands = n_islands
        self.waiting_messages = [0] * n_islands
        self.unassigned_messages = [0] * n_islands
        self.assigned_to = {}  # {node: [bridgeman_id, ...]} - list of bridgemen assigned to each node
        self.message_destinations = {}  # {origin_node: [dest1, dest2, ...]} - destinations of waiting messages

    def update_from_orders(self, orders):
        assert isinstance(orders, list), f"Orders must be a list, got {type(orders)}"

        # Reset counts and destinations
        old_waiting = self.waiting_messages[:]
        self.waiting_messages = [0] * self.n_islands
        self.message_destinations = {}

        # Count messages per origin node and track destinations
        for order in orders:
            assert len(order) == 2, f"Order must have 2 elements, got {len(order)}: {order}"
            origin, dest = order
            assert 0 <= origin < self.n_islands, f"Origin {origin} out of range [0, {self.n_islands})"
            assert 0 <= dest < self.n_islands, f"Dest {dest} out of range [0, {self.n_islands})"
            assert origin != dest, f"Origin and dest cannot be same: {origin}"

            self.waiting_messages[origin] += 1

            # Track destination for delivery feasibility checking
            if origin not in self.message_destinations:
                self.message_destinations[origin] = []
            self.message_destinations[origin].append(dest)

        # Update unassigned counts based on new waiting messages
        for node in range(self.n_islands):
            if node in self.assigned_to:
                # This node has assignments, so unassigned = max(0, waiting - num_assignments)
                num_assignments = len(self.assigned_to[node])
                self.unassigned_messages[node] = max(0, self.waiting_messages[node] - num_assignments)
            else:
                # No assignments, all waiting messages are unassigned
                self.unassigned_messages[node] = self.waiting_messages[node]

        # Sanity checks
        for node in range(self.n_islands):
            assert self.unassigned_messages[node] <= self.waiting_messages[node], \
                f"Node {node}: unassigned ({self.unassigned_messages[node]}) > waiting ({self.waiting_messages[node]})"
            assert self.unassigned_messages[node] >= 0, \
                f"Node {node}: unassigned messages cannot be negative: {self.unassigned_messages[node]}"

    def assign_message(self, node, bridgeman_id):
        assert 0 <= node < self.n_islands, f"Node {node} out of range [0, {self.n_islands})"
        assert bridgeman_id >= 0, f"Bridgeman ID must be non-negative, got {bridgeman_id}"
        assert self.unassigned_messages[node] > 0, \
            f"Cannot assign message at node {node}: no unassigned messages (unassigned={self.unassigned_messages[node]}, waiting={self.waiting_messages[node]})"

        # Check that this bridgeman isn't already assigned to this node
        if node in self.assigned_to:
            assert bridgeman_id not in self.assigned_to[node], \
                f"Bridgeman {bridgeman_id} already assigned to node {node}"
            self.assigned_to[node].append(bridgeman_id)
        else:
            self.assigned_to[node] = [bridgeman_id]

        self.unassigned_messages[node] -= 1

        assert self.unassigned_messages[node] >= 0, \
            f"Node {node}: unassigned messages went negative after assignment"

    def clear_assignment(self, bridgeman_id):
        assert bridgeman_id >= 0, f"Bridgeman ID must be non-negative, got {bridgeman_id}"

        # Find and remove assignment
        node_to_clear = None
        for node, assigned_list in self.assigned_to.items():
            if bridgeman_id in assigned_list:
                node_to_clear = node
                break

        if node_to_clear is not None:
            self.assigned_to[node_to_clear].remove(bridgeman_id)
            # If no more assignments for this node, remove the key
            if not self.assigned_to[node_to_clear]:
                del self.assigned_to[node_to_clear]
            # Don't increase unassigned count - message was picked up

    def get_nodes_with_unassigned_messages(self):
        return [node for node in range(self.n_islands) if self.unassigned_messages[node] > 0]

    def can_deliver_message_from_node(self, node, bridgeman_carry, path_finder):
        """Check if any message from this node can be delivered with given carry capacity."""
        assert 0 <= node < self.n_islands, f"Node {node} out of range [0, {self.n_islands})"
        assert bridgeman_carry >= 0, f"Carry capacity must be non-negative, got {bridgeman_carry}"

        if node not in self.message_destinations:
            return False  # No messages at this node

        # Check if any destination is reachable from the pickup node with given carry
        destinations = self.message_destinations[node]
        pickup_to_dest_paths = path_finder.shortest_paths_with_constraint(node, bridgeman_carry)

        for dest in destinations:
            if dest in pickup_to_dest_paths:
                return True  # At least one message can be delivered

        return False  # No messages can be delivered with current carry

class BridgeManager:
    def __init__(self, n_islands):
        assert n_islands > 0, f"Number of islands must be positive, got {n_islands}"
        self.n_islands = n_islands
        self.bridges = {}  # {(from, to): bridgeman_id}
        self.connected = [[False for _ in range(n_islands)] for _ in range(n_islands)]

        # Islands are connected to themselves
        for i in range(n_islands):
            self.connected[i][i] = True

    def has_bridge(self, from_node, to_node):
        assert 0 <= from_node < self.n_islands, f"From node {from_node} out of range"
        assert 0 <= to_node < self.n_islands, f"To node {to_node} out of range"

        return (from_node, to_node) in self.bridges or (to_node, from_node) in self.bridges

    def get_bridge_owner(self, from_node, to_node):
        assert 0 <= from_node < self.n_islands, f"From node {from_node} out of range"
        assert 0 <= to_node < self.n_islands, f"To node {to_node} out of range"

        if (from_node, to_node) in self.bridges:
            return self.bridges[(from_node, to_node)]
        elif (to_node, from_node) in self.bridges:
            return self.bridges[(to_node, from_node)]
        return None

    def add_bridge(self, from_node, to_node, bridgeman_id):
        assert 0 <= from_node < self.n_islands, f"From node {from_node} out of range"
        assert 0 <= to_node < self.n_islands, f"To node {to_node} out of range"
        assert from_node != to_node, f"Cannot build bridge from node to itself: {from_node}"
        assert bridgeman_id >= 0, f"Bridgeman ID must be non-negative, got {bridgeman_id}"
        assert not self.has_bridge(from_node, to_node), \
            f"Bridge already exists between {from_node} and {to_node}"

        self.bridges[(from_node, to_node)] = bridgeman_id
        self.connected[from_node][to_node] = True
        self.connected[to_node][from_node] = True

    def remove_bridge(self, from_node, to_node):
        assert 0 <= from_node < self.n_islands, f"From node {from_node} out of range"
        assert 0 <= to_node < self.n_islands, f"To node {to_node} out of range"
        assert self.has_bridge(from_node, to_node), \
            f"No bridge exists between {from_node} and {to_node}"

        # Remove in both directions
        if (from_node, to_node) in self.bridges:
            del self.bridges[(from_node, to_node)]
        if (to_node, from_node) in self.bridges:
            del self.bridges[(to_node, from_node)]

        self.connected[from_node][to_node] = False
        self.connected[to_node][from_node] = False

class EnhancedBridgeman:
    VALID_STATES = {"idle", "picking_up", "delivering"}

    def __init__(self, id):
        assert id >= 0, f"Bridgeman ID must be non-negative, got {id}"
        self.id = id
        self.position = 0
        self.carry = 0
        self.game_target = -1  # Target reported by game (-1 = no message)

        # Work state management
        self.work_state = "idle"
        self.assigned_pickup_node = -1

        # Path planning for multi-hop movement
        self.planned_path = []  # List of nodes to visit in order
        self.path_index = 0     # Current position in planned path

        # Bridge ownership (from BridgeRunners.py)
        self.bridge_from = -1
        self.bridge_to = -1

    def set_work_state(self, new_state):
        assert new_state in self.VALID_STATES, \
            f"Invalid work state: {new_state}. Must be one of {self.VALID_STATES}"
        old_state = self.work_state
        self.work_state = new_state

    def update_from_game(self, position, carry, game_target, n_islands):
        assert 0 <= position < n_islands, f"Position {position} out of range [0, {n_islands})"
        assert carry >= 0, f"Carry must be non-negative, got {carry}"
        assert game_target == -1 or 0 <= game_target < n_islands, \
            f"Game target {game_target} out of range (should be -1 or [0, {n_islands}))"

        self.position = position
        self.carry = carry
        self.game_target = game_target

    def has_bridge(self):
        return self.bridge_from != -1 and self.bridge_to != -1

    def has_planned_path(self):
        return len(self.planned_path) > 0 and self.path_index < len(self.planned_path)

    def get_next_node_in_path(self):
        assert self.has_planned_path(), f"Bridgeman {self.id} has no valid planned path"
        return self.planned_path[self.path_index]

    def advance_path(self):
        assert self.has_planned_path(), f"Bridgeman {self.id} has no valid planned path to advance"
        self.path_index += 1

    def clear_planned_path(self):
        self.planned_path = []
        self.path_index = 0

    def get_effective_carry_capacity(self, distances):
        """Get total carry capacity including bridge that can be packed."""
        assert distances, "Distances matrix required"
        effective_carry = self.carry

        if self.has_bridge():
            # Add bridge length to available capacity since we can pack it
            bridge_length = distances[self.bridge_from][self.bridge_to]
            assert bridge_length >= 0, f"Bridge length must be non-negative, got {bridge_length}"
            effective_carry += bridge_length

        assert effective_carry >= self.carry, \
            f"Effective carry {effective_carry} should be >= base carry {self.carry}"
        return effective_carry

    def validate_bridge_state(self, n_islands):
        if self.bridge_from != -1:
            assert self.bridge_to != -1, f"Bridgeman {self.id}: bridge_from set but bridge_to not set"
            assert 0 <= self.bridge_from < n_islands, \
                f"Bridgeman {self.id}: bridge_from {self.bridge_from} out of range"
            assert 0 <= self.bridge_to < n_islands, \
                f"Bridgeman {self.id}: bridge_to {self.bridge_to} out of range"
            assert self.bridge_from != self.bridge_to, \
                f"Bridgeman {self.id}: bridge_from and bridge_to cannot be same: {self.bridge_from}"
        else:
            assert self.bridge_to == -1, f"Bridgeman {self.id}: bridge_to set but bridge_from not set"

    def validate_path_state(self, n_islands):
        """Validate planned path state."""
        if self.planned_path:
            assert 0 <= self.path_index <= len(self.planned_path), \
                f"Bridgeman {self.id}: path_index {self.path_index} out of range [0, {len(self.planned_path)}]"

            # Validate all nodes in path
            for i, node in enumerate(self.planned_path):
                assert 0 <= node < n_islands, \
                    f"Bridgeman {self.id}: planned_path[{i}] = {node} out of range [0, {n_islands})"

            # If we have a valid path index, check connectivity
            if self.path_index < len(self.planned_path):
                current_pos = self.position
                next_node = self.planned_path[self.path_index]
                assert current_pos != next_node, \
                    f"Bridgeman {self.id}: next node {next_node} same as current position {current_pos}"
        else:
            assert self.path_index == 0, \
                f"Bridgeman {self.id}: empty planned_path but path_index = {self.path_index}"

class GameState:
    def __init__(self, n_islands, n_bridgemen, n_orders):
        assert n_islands > 0, f"Number of islands must be positive, got {n_islands}"
        assert n_bridgemen > 0, f"Number of bridgemen must be positive, got {n_bridgemen}"
        assert n_orders >= 0, f"Number of orders must be non-negative, got {n_orders}"

        self.n_islands = n_islands
        self.n_bridgemen = n_bridgemen
        self.n_orders = n_orders
        self.distances = []
        self.bridgemen = [EnhancedBridgeman(i) for i in range(n_bridgemen)]
        self.message_tracker = MessageTracker(n_islands)
        self.bridge_manager = BridgeManager(n_islands)
        self.path_finder = None  # Will be set after distances are loaded
        self.pack_queue = []  # List of (bridgeman_id, from_node, to_node) for deferred PACK actions

    def set_distances(self, distances):
        assert len(distances) == self.n_islands, \
            f"Distance matrix size {len(distances)} != n_islands {self.n_islands}"
        self.distances = distances
        self.path_finder = PathFinder(distances)

    def validate_state(self):
        assert self.path_finder is not None, "PathFinder not initialized - call set_distances first"

        # Validate all bridgemen
        for bridgeman in self.bridgemen:
            bridgeman.validate_bridge_state(self.n_islands)
            bridgeman.validate_path_state(self.n_islands)
            assert bridgeman.work_state in EnhancedBridgeman.VALID_STATES, \
                f"Bridgeman {bridgeman.id} has invalid work state: {bridgeman.work_state}"

        # Validate PACK queue
        for i, (bridgeman_id, from_node, to_node) in enumerate(self.pack_queue):
            assert 0 <= bridgeman_id < self.n_bridgemen, \
                f"PACK queue entry {i}: bridgeman_id {bridgeman_id} out of range [0, {self.n_bridgemen})"
            assert 0 <= from_node < self.n_islands, \
                f"PACK queue entry {i}: from_node {from_node} out of range [0, {self.n_islands})"
            assert 0 <= to_node < self.n_islands, \
                f"PACK queue entry {i}: to_node {to_node} out of range [0, {self.n_islands})"
            assert from_node != to_node, \
                f"PACK queue entry {i}: from_node and to_node cannot be same: {from_node}"

            # Verify bridgeman currently owns this bridge
            bridgeman = self.bridgemen[bridgeman_id]
            assert bridgeman.bridge_from == from_node and bridgeman.bridge_to == to_node, \
                f"PACK queue entry {i}: bridgeman {bridgeman_id} doesn't own bridge - " \
                f"queue: ({from_node}, {to_node}), bridgeman: ({bridgeman.bridge_from}, {bridgeman.bridge_to})"

        # Validate message assignments
        assigned_bridgemen = set()
        for node, bridgeman_list in self.message_tracker.assigned_to.items():
            for bridgeman_id in bridgeman_list:
                assert bridgeman_id not in assigned_bridgemen, \
                    f"Bridgeman {bridgeman_id} assigned to multiple nodes"
                assigned_bridgemen.add(bridgeman_id)

                # Check that assigned bridgeman is in picking_up state
                bridgeman = self.bridgemen[bridgeman_id]
                assert bridgeman.work_state == "picking_up", \
                    f"Bridgeman {bridgeman_id} assigned to node {node} but not in picking_up state: {bridgeman.work_state}"
                assert bridgeman.assigned_pickup_node == node, \
                    f"Bridgeman {bridgeman_id} assigned to node {node} but pickup_node is {bridgeman.assigned_pickup_node}"

def find_closest_unassigned_message(paths, message_tracker, bridgeman_carry, path_finder):
    """Find closest unassigned message that can be both picked up and delivered."""
    nodes_with_messages = message_tracker.get_nodes_with_unassigned_messages()
    if not nodes_with_messages:
        return -1

    closest_node = -1
    closest_distance = float('inf')

    for node in nodes_with_messages:
        if node in paths:  # Pickup reachable
            # Check if message can be delivered from pickup location
            if message_tracker.can_deliver_message_from_node(node, bridgeman_carry, path_finder):
                distance, path = paths[node]
                if distance < closest_distance:
                    closest_distance = distance
                    closest_node = node

    return closest_node

def process_idle_state(bridgeman, game_state):
    assert bridgeman.work_state == "idle", \
        f"process_idle_state called on bridgeman {bridgeman.id} in state {bridgeman.work_state}"

    # Compute shortest paths with effective carry constraint (including owned bridge)
    effective_carry = bridgeman.get_effective_carry_capacity(game_state.distances)
    paths = game_state.path_finder.shortest_paths_with_constraint(
        bridgeman.position, effective_carry)

    # Find closest node with unassigned message that can be delivered
    closest_node = find_closest_unassigned_message(
        paths, game_state.message_tracker, effective_carry, game_state.path_finder)

    if closest_node != -1:
        # Assign message and change state
        game_state.message_tracker.assign_message(closest_node, bridgeman.id)
        bridgeman.assigned_pickup_node = closest_node
        bridgeman.set_work_state("picking_up")

        # Immediately process picking up
        return process_picking_up_state(bridgeman, game_state)

    return None  # Stay idle

def process_picking_up_state(bridgeman, game_state):
    assert bridgeman.work_state == "picking_up", \
        f"process_picking_up_state called on bridgeman {bridgeman.id} in state {bridgeman.work_state}"
    assert bridgeman.assigned_pickup_node != -1, \
        f"Bridgeman {bridgeman.id} in picking_up state but no assigned pickup node"

    # Check if game reports delivery target
    if bridgeman.game_target != -1:
        # Message picked up, switch to delivering
        game_state.message_tracker.clear_assignment(bridgeman.id)
        bridgeman.assigned_pickup_node = -1
        bridgeman.set_work_state("delivering")
        return process_delivering_state(bridgeman, game_state)

    # Move toward pickup target
    return execute_planned_movement(bridgeman, bridgeman.assigned_pickup_node, game_state)

def process_delivering_state(bridgeman, game_state):
    assert bridgeman.work_state == "delivering", \
        f"process_delivering_state called on bridgeman {bridgeman.id} in state {bridgeman.work_state}"

    # Check if message delivered
    if bridgeman.game_target == -1:
        # Message delivered, return to idle
        bridgeman.set_work_state("idle")
        return process_idle_state(bridgeman, game_state)

    # Move toward delivery target
    return execute_planned_movement(bridgeman, bridgeman.game_target, game_state)

def plan_path_to_target(bridgeman, target_node, game_state):
    """Plan a path from bridgeman's current position to target node."""
    assert 0 <= target_node < game_state.n_islands, \
        f"Target node {target_node} out of range [0, {game_state.n_islands})"
    assert 0 <= bridgeman.position < game_state.n_islands, \
        f"Bridgeman {bridgeman.id} position {bridgeman.position} out of range"

    if bridgeman.position == target_node:
        bridgeman.clear_planned_path()
        return True  # Already at target

    # Use pathfinder to get shortest path with effective carry constraint (including owned bridge)
    effective_carry = bridgeman.get_effective_carry_capacity(game_state.distances)
    paths = game_state.path_finder.shortest_paths_with_constraint(
        bridgeman.position, effective_carry)

    if target_node not in paths:
        # No path exists with current carry capacity
        print(f"WARNING: No path from {bridgeman.position} to {target_node} with effective carry {effective_carry} (base: {bridgeman.carry})", file=sys.stderr)
        bridgeman.clear_planned_path()
        return False

    distance, path = paths[target_node]
    assert len(path) >= 2, f"Path should have at least 2 nodes, got {len(path)}: {path}"
    assert path[0] == bridgeman.position, f"Path should start at current position {bridgeman.position}, got {path[0]}"
    assert path[-1] == target_node, f"Path should end at target {target_node}, got {path[-1]}"

    # Store path (excluding current position since we're already there)
    bridgeman.planned_path = path[1:]  # Skip current position
    bridgeman.path_index = 0

    return True

def move_one_hop(bridgeman, next_node, game_state):
    """Execute a single hop movement to the next node."""
    assert 0 <= next_node < game_state.n_islands, \
        f"Next node {next_node} out of range [0, {game_state.n_islands})"
    assert 0 <= bridgeman.position < game_state.n_islands, \
        f"Bridgeman {bridgeman.id} position {bridgeman.position} out of range"
    assert next_node != bridgeman.position, \
        f"Next node {next_node} cannot be same as current position {bridgeman.position}"

    bridge_manager = game_state.bridge_manager

    # Check if we have a bridge toward next node
    if (bridgeman.bridge_from == bridgeman.position and
        bridgeman.bridge_to == next_node):
        return f"MOVE {bridgeman.id} {next_node}"

    # Check if we have a bridge elsewhere - queue it for packing (optimization: let others use it first)
    if bridgeman.has_bridge():
        assert bridgeman.bridge_from != -1 and bridgeman.bridge_to != -1, \
            f"Bridgeman {bridgeman.id} has_bridge() but bridge coordinates invalid"

        # Queue PACK action for end of turn instead of immediate execution
        game_state.pack_queue.append((bridgeman.id, bridgeman.bridge_from, bridgeman.bridge_to))

        # Note: Keep bridgeman state unchanged - bridge still exists until end of turn
        # Bridgeman is done for this turn - can't act while bridge is pending pack
        return None

    # Check if someone else has bridge to next node
    if bridge_manager.has_bridge(bridgeman.position, next_node):
        return f"MOVE {bridgeman.id} {next_node}"

    # Build new bridge to next node immediately
    edge_length = game_state.distances[bridgeman.position][next_node]
    effective_carry = bridgeman.get_effective_carry_capacity(game_state.distances)
    assert effective_carry == bridgeman.carry, "logic error: bridgeman should have no bridge when building new one"
    assert edge_length <= effective_carry, \
        f"Cannot build bridge from {bridgeman.position} to {next_node}: edge length {edge_length} > effective carry {effective_carry} (base: {bridgeman.carry})"

    # Execute UNPACK immediately so others can use the bridge this turn
    bridgeman.bridge_from = bridgeman.position
    bridgeman.bridge_to = next_node
    bridge_manager.add_bridge(bridgeman.position, next_node, bridgeman.id)
    return f"UNPACK {bridgeman.id} {next_node}"

def execute_planned_movement(bridgeman, target_node, game_state):
    """Execute planned movement toward target, planning path if needed."""
    assert 0 <= target_node < game_state.n_islands, \
        f"Target node {target_node} out of range [0, {game_state.n_islands})"

    if bridgeman.position == target_node:
        bridgeman.clear_planned_path()
        return None  # Already at target

    # Plan path if we don't have one or if we've completed the current path
    if not bridgeman.has_planned_path():
        if not plan_path_to_target(bridgeman, target_node, game_state):
            return None  # No path available

    # Get next node in path
    next_node = bridgeman.get_next_node_in_path()

    # Execute one hop toward next node
    action = move_one_hop(bridgeman, next_node, game_state)

    # Advance path only when bridgeman physically moves to next node
    if action and action.startswith(f"MOVE {bridgeman.id}"):
        bridgeman.advance_path()

    return action

def process_bridgeman(bridgeman, game_state):
    if bridgeman.work_state == "idle":
        return process_idle_state(bridgeman, game_state)
    elif bridgeman.work_state == "picking_up":
        return process_picking_up_state(bridgeman, game_state)
    elif bridgeman.work_state == "delivering":
        return process_delivering_state(bridgeman, game_state)
    else:
        assert False, f"Invalid bridgeman work state: {bridgeman.work_state}"

def main():
    try:
        N = int(input())
        B = int(input())
        O = int(input())

        # Read distances
        distances = []
        for _ in range(N):
            distances.append(list(map(int, input().split())))

        # Initialize game state
        game_state = GameState(N, B, O)
        game_state.set_distances(distances)

        for turn in range(1, 1001):
            elapsed_time = int(input())

            # Update bridgeman states from game
            for i in range(B):
                line = list(map(int, input().split()))
                assert len(line) == 3, f"Expected 3 values for bridgeman {i}, got {len(line)}: {line}"
                game_state.bridgemen[i].update_from_game(line[0], line[1], line[2], N)

            # Read orders and update message tracker
            orders = []
            for _ in range(O):
                line = list(map(int, input().split()))
                assert len(line) == 2, f"Expected 2 values for order, got {len(line)}: {line}"
                orders.append((line[0], line[1]))

            game_state.message_tracker.update_from_orders(orders)

            # Validate state before processing
            game_state.validate_state()

            # Process each bridgeman (collects immediate MOVE/UNPACK actions)
            immediate_actions = []
            for bridgeman in game_state.bridgemen:
                action = process_bridgeman(bridgeman, game_state)
                if action:
                    immediate_actions.append(action)

            # Process queued PACK actions (optimization: execute at end to let others use bridges first)
            pack_actions = []
            for bridgeman_id, from_node, to_node in game_state.pack_queue:
                bridgeman = game_state.bridgemen[bridgeman_id]

                # Determine correct PACK argument based on bridgeman's current position
                if bridgeman.position == from_node:
                    # Bridgeman is on the from_node, pack toward to_node
                    pack_target = to_node
                elif bridgeman.position == to_node:
                    # Bridgeman is on the to_node, pack toward from_node
                    pack_target = from_node
                else:
                    # Bridgeman moved away from bridge - this shouldn't happen but use from_node as default
                    pack_target = from_node
                    print(f"WARNING: Bridgeman {bridgeman_id} packing bridge ({from_node}, {to_node}) from position {bridgeman.position}", file=sys.stderr)

                pack_actions.append(f"PACK {bridgeman_id} {pack_target}")
                # Remove bridge from bridge manager
                game_state.bridge_manager.remove_bridge(from_node, to_node)
                # Update bridgeman state - bridge is now packed
                bridgeman.bridge_from = -1
                bridgeman.bridge_to = -1

            # Clear queue for next turn
            game_state.pack_queue.clear()

            # Combine and output all actions
            all_actions = immediate_actions + pack_actions
            print(" | ".join(all_actions) if all_actions else "")

    except Exception as e:
        print(f"ERROR: {e}", file=sys.stderr)
        raise

if __name__ == "__main__":
    main()
