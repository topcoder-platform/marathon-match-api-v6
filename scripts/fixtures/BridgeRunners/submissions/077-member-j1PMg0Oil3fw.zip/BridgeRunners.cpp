#pragma GCC optimize "-O3,omit-frame-pointer,inline,unroll-all-loops,fast-math"
#pragma GCC target "tune=native"

#include <algorithm>
#include <array>
#include <bitset>
#include <cassert>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits>
#include <list>
#include <map>
#include <memory>
#include <optional>
#include <queue>
#include <random>
#include <set>
#include <sstream>
#include <stack>
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <vector>

bool isTopCoder = true;

// -------------------------------------------------------------- #1 BOLIERPLATE ------------------------------
#define F0(i, n) for (int i = 0; i < n; i++)
#define FR(i, n) for (int i = n - 1; i >= 0; i--)
#define F1(i, n) for (int i = 1; i <= n; i++)
#define FI(i, j, n) for (int j = i + 1; j < n; j++)
#define CL(a, x) memset(x, a, sizeof(x));
#define SZ(x) ((int)x.size())
#define ASZ(x) sizeof(x);
const float pi = acos(-1.0);
const int inf = 1000000000;
const float MAXD = 100000000000.0;
typedef long long ll;
typedef unsigned long long ull;
const float EPS = 1e-9;

//@see https://stackoverflow.com/questions/33333363/built-in-mod-vs-custom-mod-function-improve-the-performance-of-modulus-op/33333636#33333636
inline size_t fast_mod(const size_t i, const size_t c) { return i >= c ? i % c : i; }

using namespace std;
string resDir = "/Users/erikkvanli/Downloads/tests/resDir";
string resFileName = "";

struct Stopwatch {
  float TIME_LIMIT;
  chrono::high_resolution_clock::time_point start_time;

  Stopwatch(const float TIME_LIMIT = 1) : TIME_LIMIT(TIME_LIMIT * 1000000LL), start_time(chrono::high_resolution_clock::now()) {}

  int64_t elapsed_nanoseconds() const { return chrono::duration_cast<chrono::nanoseconds>(chrono::high_resolution_clock::now() - start_time).count(); }

  int64_t elapsed_milliseconds() const { return chrono::duration_cast<chrono::milliseconds>(chrono::high_resolution_clock::now() - start_time).count(); }

  float elapsed_fraction() const { return static_cast<float>(elapsed_nanoseconds()) / TIME_LIMIT; }

  bool timeout() const { return elapsed_nanoseconds() >= TIME_LIMIT; }
};

struct XRand {
  u_int32_t val;

  XRand(const u_int32_t v = 643263) : val(v) {}

  u_int32_t xorshift32() {
    val ^= val << 13;
    val ^= val >> 17;
    val ^= val << 5;
    return val;
  }

  u_int64_t next(const int m) { // [0, m)
    return static_cast<u_int64_t>(xorshift32()) * m >> 32;
  }

  float nextfloat() { // [0, 1)
    return static_cast<float>(xorshift32()) / (static_cast<u_int64_t>(1) << 32);
  }
};
XRand rnd;

bool fileExists(const string &filename) {
  ifstream file(filename);
  return file.good();
}

ofstream file;

int sign(int val) {
  if (val == 0)
    return 0;
  if (val < 0)
    return -1;
  return 1;
}

string filename = "/Users/erikkvanli/Downloads/ac32/0000.txt";
bool isLocal = fileExists(filename);

// -------------------------------------------------------------- #1 VARIABLES ------------------------------
// unordered_set<uint64_t> seen;
// unordered_map<uint64_t, int> mapSeen;
int forcedSeed = 0, evals = 0;
string seed = "-1";

// -------------------------------------------------------------- #2 CONSTANTS ------------------------------
const int MaxN = 80, MaxNN = MaxN * MaxN, NOTARGET = -1337, MaxCapacity = 60;

// -------------------------------------------------------------- #3 SIM ------------------------------------

struct Order {
  int from, to;
  bool claimed;
};

struct FinalAction {
  int type = 0;
  int b1 = 0;
  int b2 = 0;
  int length = 0;
};

struct Bridgeman {
  int id;
  int pos;
  int target = NOTARGET;
  int bridge;
};

vector<float> trainedValues;
vector<vector<float>> tv;
int N, B, O;
bitset<MaxN> visited;
vector<vector<int>> randomOrders;

const int DijkstraSize = MaxN;
float dists[DijkstraSize][DijkstraSize];
int realDists[DijkstraSize][DijkstraSize];
bool connected[MaxN * MaxN]{false};
vector<int> neighbours[MaxN];
Bridgeman bridgemen[20];
Order orders[10];
int maxDepth = 3;

struct DijkstraQueue {
  int x;
  float dist;
};

void dijkstra(int startX) {
  vector<DijkstraQueue> queue = {{startX, 1}};
  int amount = 0, idx = startX;
  dists[idx][idx] = 0;
  while (queue.size() > 0) {
    vector<DijkstraQueue> next;
    F0 (i, queue.size()) {
      auto item = queue[i].x;
      F0 (neig, neighbours[item].size()) {
        int j = neighbours[item][neig];
        float depthAddon = 1;
        if (realDists[j][item] > 100)
          depthAddon = 30;
        else if (realDists[j][item] > 60)
          depthAddon = 10;
        else if (realDists[j][item] > 50)
          depthAddon = 1.2;

        float depth = queue[i].dist + depthAddon;
        int idx2 = j;
        if (dists[idx][idx2] <= depth)
          continue; // faster paths exist
        dists[idx][idx2] = depth;
        next.push_back({j, depth});
        amount++;
      }
    }
    queue = next;
  }
}

void initializeDistances() { // vector<vector<float>> &heatMap
  for (int i = 0; i < DijkstraSize; ++i) {
    for (int j = 0; j < DijkstraSize; ++j) {
      dists[i][j] = inf;
    }
  }

  for (int x = 0; x < DijkstraSize; x++) {
    dijkstra(x);
  }
}

// -------------------------------------------------------------- #4 STATE ------------------------------------

struct State {
  Bridgeman stateMen[20]{};
  Order stateOrders[10]{};
  bool stateConnected[MaxN * MaxN]{false};
  int delivered = 0;
  int depth = 0;
  int score = 0;
  bitset<20> usedMen;
  vector<FinalAction> actions;

  int getUnclaimedOrder(int from) {
    int target = rnd.next(O);
    if (rnd.nextfloat() < 0.95) { // Find closest
      int bestD = inf;
      F0 (i, O) {
        // if (rnd.nextfloat() < 0.1)
        //   continue;
        if (!stateOrders[i].claimed) {
          int d = dists[stateOrders[i].from][from];
          if (d < bestD) {
            bestD = d;
            target = stateOrders[i].from;
          }
        }
      }

      return target;
    }
    if (stateOrders[target].claimed) { // Random is bad - Find new
      if (rnd.nextfloat() < 0.5) {
        F0 (i, O) {
          if (!stateOrders[i].claimed)
            return i;
        }
      } else {
        for (int i = O - 1; i >= 0; i--) {
          if (!stateOrders[i].claimed)
            return i;
        }
      }
    }
    return target;
  }

  bool canDualBuildBridge(int &from, int &to, int &bridge, int &bridge2, int length) { return realDists[from][to] <= length + bridge2; }

  bool canDualPackBridge(int &from, int &to, int &bridge, int &bridge2, int length) { return bridge + length <= MaxCapacity && bridge2 + realDists[from][to] - length <= MaxCapacity; }

  bool canPotentialDualBuildBridge(int &from, int &to, int &bridge) { return !stateConnected[from + to * N] && realDists[from][to] <= bridge + 50 && realDists[from][to] > bridge; }

  bool canPotentialDualPackBridge(int &from, int &to, int &bridge) { return stateConnected[from + to * N] && realDists[from][to] + bridge <= MaxCapacity + 50 && realDists[from][to] + bridge > MaxCapacity; }

  bool canSoloBuildBridge(int &from, int &to, int &bridge) { return !stateConnected[from + to * N] && realDists[from][to] <= bridge; }

  bool canSoloPackBridge(int &from, int &to, int &bridge) { return stateConnected[from + to * N] && realDists[from][to] + bridge <= MaxCapacity; }

  void addDualBridge(int from, int to, int &bridge, int &bridge2, int length) {
    stateConnected[from + to * N] = true;
    stateConnected[to + from * N] = true;
    bridge -= length;
    bridge2 -= realDists[from][to] - length;
  }

  void removeDualBridge(int from, int to, int &bridge, int &bridge2, int length) {
    stateConnected[from + to * N] = false;
    stateConnected[to + from * N] = false;
    bridge += length;
    bridge2 += realDists[from][to] - length;
  }

  void addBridge(int from, int to, int &bridge) {
    stateConnected[from + to * N] = true;
    stateConnected[to + from * N] = true;
    bridge -= realDists[from][to];
  }

  void removeBridge(int from, int to, int &bridge) {
    stateConnected[from + to * N] = false;
    stateConnected[to + from * N] = false;
    bridge += realDists[from][to];
  }

  bool canMove(int from, int to) { return stateConnected[from + to * N]; }

  void reset() {
    F0 (i, O) {
      stateOrders[i].claimed = false;
      stateOrders[i].from = orders[i].from;
      stateOrders[i].to = orders[i].to;
    }
    actions.clear();
    depth = 0;
    score = 0;
    delivered = 0;
    F0 (i, N) {
      F0 (j, neighbours[i].size()) {
        stateConnected[i + neighbours[i][j] * N] = connected[i + neighbours[i][j] * N];
      }
    }
    F0 (i, B) {
      stateMen[i].id = bridgemen[i].id;
      stateMen[i].bridge = bridgemen[i].bridge;
      stateMen[i].pos = bridgemen[i].pos;
      stateMen[i].target = bridgemen[i].target;
    }
  }

  void afterTurn() {
    F0 (i, B) {
      if (stateMen[i].pos == stateMen[i].target) {
        ++delivered;
        score += 1; // (maxDepth * 2 - depth);
        stateMen[i].target = NOTARGET;
      }

      if (stateMen[i].target < 0) {
        F0 (j, O) {
          if (!stateOrders[j].claimed && stateOrders[j].from == stateMen[i].pos) {
            stateMen[i].target = stateOrders[j].to;
            stateOrders[j].claimed = true;
            break;
          }
        }
      }
    }
    ++depth;
  }

  float getScore() {
    float s = score * 1000;

    F0 (i, B) {
      if (stateMen[i].target >= 0) {
        s += 100 - dists[stateMen[i].target][stateMen[i].pos] * 5;
      }
    }

    F0 (i, B) {
      if (stateMen[i].target < 0) {
        s += (50 - dists[getUnclaimedOrder(stateMen[i].pos)][stateMen[i].pos]) / 2.0;
      }
    }

    F0 (i, B)
      s += stateMen[i].bridge / 5;

    // F0 (i, actions.size()) {
    //   // if (actions[i].type == 2)
    //   //   score += 1000000;
    //   // else
    //   // score += 5;
    // }

    return s;
  }

  void randomTurn(vector<int> &order) {
    // if (item.type == 0) {
    //     cout << "MOVE " << item.b1 << " " << item.b2;
    //   } else if (item.type == 1) {
    //     cout << "UNPACK " << item.b1 << " " << item.b2;
    //     connected[bridgemen[item.b1].pos + item.b2 * N] = true;
    //     connected[item.b2 + bridgemen[item.b1].pos * N] = true;
    //   } else if (item.type == 2) {
    //     cout << "PACK " << item.b1 << " " << item.b2;
    //     connected[bridgemen[item.b1].pos + item.b2 * N] = false;
    //     connected[item.b2 + bridgemen[item.b1].pos * N] = false;
    //   } else if (item.type == 3) {
    //     cout << "TEAMUNPACK " << item.b1 << " " << item.b2 << " " << item.length;
    //     connected[bridgemen[item.b1].pos + bridgemen[item.b2].pos * N] = true;
    //     connected[bridgemen[item.b2].pos + bridgemen[item.b1].pos * N] = true;
    //   } else if (item.type == 4) {
    //     cout << "TEAMPACK " << item.b1 << " " << item.b2 << " " << item.length;
    //     connected[bridgemen[item.b1].pos + bridgemen[item.b2].pos * N] = false;
    //     connected[bridgemen[item.b2].pos + bridgemen[item.b1].pos * N] = false;
    //   }
    usedMen.reset();
    F0 (idx, B) {
      int i = order[idx];
      if (usedMen.test(i))
        continue; // Prev moved
      usedMen.set(i);
      double proba = rnd.nextfloat();

      int from = stateMen[i].pos;
      int capacity = stateMen[i].bridge;
      // TODO: Build or move towards a goal if we have one
      if (proba < 0.3) { // MOVE
        int amount = 0;
        F0 (j, neighbours[from].size()) {
          if (canMove(from, neighbours[from][j])) {
            amount++;
          }
        }

        if (amount == 0)
          continue;
        amount = rnd.next(amount);
        F0 (j, neighbours[from].size()) {
          if (canMove(from, neighbours[from][j]) && amount-- <= 0) {
            if (depth == 0 && from != neighbours[from][j]) { // Same location move == WAIT
              actions.emplace_back(FinalAction({0, i, neighbours[from][j], 0}));
            }
            stateMen[i].pos = neighbours[from][j];
            break;
          }
        }
      } else if (proba < 0.4 && stateMen[i].bridge > 5) { // DOUBLE BUILD
        int amount = 0;
        F0 (j, neighbours[from].size()) {
          int targ = neighbours[from][j];
          if (!canPotentialDualBuildBridge(from, targ, capacity))
            continue;
          for (int i2 = i + 1; i2 < B; i2++) {
            int innerI = order[i2];
            if (stateMen[innerI].pos != targ || usedMen.test(innerI) || !canDualBuildBridge(from, targ, capacity, stateMen[innerI].bridge, capacity))
              continue;
            ++amount;
          }
        }
        if (amount == 0)
          continue;

        amount = rnd.next(amount);
        bool done = false;
        F0 (j, neighbours[from].size()) {
          int targ = neighbours[from][j];
          if (!canPotentialDualBuildBridge(from, targ, capacity))
            continue;
          for (int i2 = i + 1; i2 < B; i2++) {
            int innerI = order[i2];
            if (stateMen[innerI].pos != targ || usedMen.test(innerI) || !canDualBuildBridge(from, targ, capacity, stateMen[innerI].bridge, capacity))
              continue;
            if (amount-- <= 0) {
              usedMen.set(innerI);
              if (depth == 0) {
                actions.emplace_back(FinalAction({3, i, innerI, capacity}));
              }
              done = true;
              addDualBridge(from, targ, capacity, stateMen[innerI].bridge, capacity);
              break;
            }
          }
          if (done)
            break;
        }
      } else if (proba < 0.6) { // BUILD SOLO
        int amount = 0;
        F0 (j, neighbours[from].size()) {
          if (canSoloBuildBridge(from, neighbours[from][j], stateMen[i].bridge)) {
            amount++;
          }
        }
        if (amount == 0)
          continue;

        amount = rnd.next(amount);
        F0 (j, neighbours[from].size()) {
          if (canSoloBuildBridge(from, neighbours[from][j], stateMen[i].bridge) && amount-- <= 0) {
            if (depth == 0) {
              actions.emplace_back(FinalAction({1, i, neighbours[from][j], 0}));
            }
            addBridge(from, neighbours[from][j], stateMen[i].bridge);
            break;
          }
        }
      } else if (proba < 0.7 && stateMen[i].bridge < 50) { // DOUBLE PACK
        int amount = 0;
        int removableCapacity = 50 - capacity;
        F0 (j, neighbours[from].size()) {
          int targ = neighbours[from][j];
          if (!canPotentialDualPackBridge(from, targ, capacity))
            continue;
          for (int i2 = i + 1; i2 < B; i2++) {
            int innerI = order[i2];
            if (stateMen[innerI].pos != targ || usedMen.test(innerI) || !canDualPackBridge(from, targ, capacity, stateMen[innerI].bridge, removableCapacity))
              continue;
            ++amount;
          }
        }
        if (amount == 0)
          continue;

        amount = rnd.next(amount);
        bool done = false;
        F0 (j, neighbours[from].size()) {
          int targ = neighbours[from][j];
          if (!canPotentialDualPackBridge(from, targ, capacity))
            continue;
          for (int i2 = i + 1; i2 < B; i2++) {
            int innerI = order[i2];
            if (stateMen[innerI].pos != targ || usedMen.test(innerI) || !canDualPackBridge(from, targ, capacity, stateMen[innerI].bridge, removableCapacity))
              continue;
            if (amount-- <= 0) {
              usedMen.set(innerI);
              if (depth == 0) {
                actions.emplace_back(FinalAction({4, i, innerI, removableCapacity}));
              }
              done = true;
              removeDualBridge(from, targ, capacity, stateMen[innerI].bridge, removableCapacity);
              break;
            }
          }
          if (done)
            break;
        }
      } else { // PACK
        int amount = 0;
        // cerr << i << " cap: " << stateMen[i].bridge << endl;
        F0 (j, neighbours[from].size()) {
          // if (stateConnected[from + neighbours[from][j] * N] && depth == 0) {
          //   cerr << "Potential? " << from << " TO: " << neighbours[from][j] << " Bridge: " << bridgemen[i].bridge << " Inner : " << stateMen[i].bridge << " Dist: " << realDists[from][neighbours[from][j]] << endl;
          // }
          if (canSoloPackBridge(from, neighbours[from][j], stateMen[i].bridge)) {
            // if (depth == 0)
            //   cerr << "Possible: " << from << " TO: " << neighbours[from][j] << " Bridge: " << stateMen[i].bridge << endl;
            amount++;
          }
        }
        if (amount == 0)
          continue;
        // if (depth == 0)
        //   cerr << "DoRemove: " << amount << " Idx: " << i << endl;

        amount = rnd.next(amount);
        F0 (j, neighbours[from].size()) {
          if (canSoloPackBridge(from, neighbours[from][j], stateMen[i].bridge) && amount-- <= 0) {
            if (depth == 0) {
              actions.emplace_back(FinalAction({2, i, neighbours[from][j], 0}));

              // cerr << "trying to remove? " << actions[actions.size() - 1].type << endl;
            }
            removeBridge(from, neighbours[from][j], stateMen[i].bridge);
            break;
          }
        }
      }
    }

    afterTurn();
  }
};

// -------------------------------------------------------------- #5 MAIN --------------------------------

int main(int argc, char *argv[]) {
  tv = vector<vector<float>>{
      // TRAINBELOW
      {0.5, 0.5, 0.5},
  };
  trainedValues = tv[0];
  // READ

  std::cin >> N >> B >> O;
  random_device rd;
  mt19937 g(rd());
  F0 (i, 100) {
    vector<int> order;
    F0 (j, B) {
      order.emplace_back(j);
    }

    shuffle(order.begin(), order.end(), g);
    randomOrders.emplace_back(order);
  }

  F0 (i, N) {
    neighbours[i] = vector<int>();
  }
  for (int i = 0; i < N; ++i) {
    for (int j = 0; j < N; ++j) {
      std::cin >> realDists[i][j];
      if (realDists[i][j] <= 120 && i != j) {
        // cerr << "NEIG: " << i << " TO: " << j << " Dist: " << realDists[i][j] << endl;
        neighbours[i].emplace_back(j);
      }
    }
  }

  initializeDistances();
  State s;

  for (int turn = 1; turn <= 1000; turn++) {
    int elapsedTime;
    std::cin >> elapsedTime;

    for (int i = 0; i < B; ++i) {
      bridgemen[i].id = i;
      std::cin >> bridgemen[i].pos >> bridgemen[i].bridge >> bridgemen[i].target;
    }
    for (int i = 0; i < O; ++i) {
      std::cin >> orders[i].from >> orders[i].to;
    }
    // F0 (i, N) {
    //   F0 (j, neighbours[i].size()) {
    //     if (connected[neighbours[i][j] + i * N])
    //       cerr << "Connected on turn: " << turn << " : " << i << " TO " << neighbours[i][j] << endl;
    //   }
    // }
    std::vector<FinalAction> output;
    float bestScore = -1000000;
    Stopwatch sw((9750 - elapsedTime) / (1000 - turn + 1));
    maxDepth = max(3, min(5, (25 - B) / 2));
    F0 (times, 10000) {
      if ((times & 63) == 0 && sw.timeout())
        break;
      s.reset();
      F0 (i, maxDepth) {
        s.randomTurn(randomOrders[rnd.next(randomOrders.size())]);
      }
      float score = s.getScore();
      if (score > bestScore) {
        output = s.actions;
        bestScore = score;
      }
    }
    // cerr << "SW: " << sw.elapsed_milliseconds() << " Actual: " << elapsedTime << " BestScore: " << bestScore << endl;
    int idx = -1;
    for (auto item : output) {
      idx++;
      if (item.type == 0) {
        cout << "MOVE " << item.b1 << " " << item.b2;
      } else if (item.type == 1) {
        cout << "UNPACK " << item.b1 << " " << item.b2;
        connected[bridgemen[item.b1].pos + item.b2 * N] = true;
        connected[item.b2 + bridgemen[item.b1].pos * N] = true;
        // cerr << "Building? " << bridgemen[item.b1].pos << " " << item.b2 << endl;
      } else if (item.type == 2) {
        cout << "PACK " << item.b1 << " " << item.b2;
        connected[bridgemen[item.b1].pos + item.b2 * N] = false;
        connected[item.b2 + bridgemen[item.b1].pos * N] = false;
      } else if (item.type == 3) {
        cout << "TEAMUNPACK " << item.b1 << " " << item.b2 << " " << item.length;
        connected[bridgemen[item.b1].pos + bridgemen[item.b2].pos * N] = true;
        connected[bridgemen[item.b2].pos + bridgemen[item.b1].pos * N] = true;
      } else if (item.type == 4) {
        cout << "TEAMPACK " << item.b1 << " " << item.b2 << " " << item.length;
        connected[bridgemen[item.b1].pos + bridgemen[item.b2].pos * N] = false;
        connected[bridgemen[item.b2].pos + bridgemen[item.b1].pos * N] = false;
      }
      if (idx < output.size() - 1) {
        std::cout << " | ";
      }
    }
    std::cout << std::endl;
  }

  return 0;
}
