#include <bits/stdc++.h>
#include <iostream>
#include <queue>
#include <sstream>
#include <string>
#include <unordered_set>
#include <vector>



using namespace std;

// Bridgeman構造体
struct Bridgeman {
    int id;
    int island_id;
    int carry_length;   // 現在持っている橋の長さ
    int target_island;  // メッセージの配送先（-1の場合はメッセージなし）

    Bridgeman(int _id = 0, int _island = 0, int _carry = 50, int _target = -1)
        : id(_id), island_id(_island), carry_length(_carry), target_island(_target) {}
};

// Order構造体
struct Order {
    int origin_island;
    int dest_island;

    Order(int _origin = 0, int _dest = 0)
        : origin_island(_origin), dest_island(_dest) {}
};

// ゲーム状態を表す構造体
struct GameState {
    int N;     // 島の数
    int B;     // ブリッジマンの数
    int O;     // 同時に表示される注文の数
    int turn;  // 現在のターン数

    vector<vector<int>> distances;      // 島間の距離
    vector<Bridgeman> bridgemen;        // ブリッジマンの状態
    vector<Order> orders;               // 現在利用可能な注文
    vector<vector<bool>> bridgeActive;  // 現在存在する橋（ローカル管理）

    GameState() : N(0), B(0), O(0), turn(0) {}
};

// IO基盤クラス
class IOHandler {
   public:
    // 初期入力の読み込み
    static void readInitialInput(GameState& state) {
        cin >> state.N >> state.B >> state.O;

        // 距離行列の読み込み
        state.distances.resize(state.N, vector<int>(state.N));
        for (int i = 0; i < state.N; i++) {
            for (int j = 0; j < state.N; j++) {
                cin >> state.distances[i][j];
            }
        }

        // ブリッジマンの初期化
        state.bridgemen.resize(state.B);
        for (int i = 0; i < state.B; i++) {
            state.bridgemen[i] = Bridgeman(i, 0, 50, -1);
        }

        // 橋の状態の初期化（初期は無し）
        state.bridgeActive.assign(state.N, vector<bool>(state.N, 0));
    }

    // ターンごとの入力読み込み
    static void readTurnInput(GameState& state) {
        int elapsed_time;
        cin >> elapsed_time;

        // ブリッジマンの状態読み込み
        for (int i = 0; i < state.B; i++) {
            int island_id, carry_length, target_island;
            cin >> island_id >> carry_length >> target_island;
            state.bridgemen[i].island_id = island_id;
            state.bridgemen[i].carry_length = carry_length;
            state.bridgemen[i].target_island = target_island;
        }

        // 注文の読み込み
        state.orders.clear();
        for (int i = 0; i < state.O; i++) {
            int origin, dest;
            cin >> origin >> dest;
            state.orders.push_back(Order(origin, dest));
        }
    }

    // アクションの出力
    static void outputActions(const vector<string>& actions) {
        for (int i = 0; i < (int)actions.size(); i++) {
            if (i > 0) cout << "|";
            cout << actions[i];
        }
        cout << endl;
    }

    // デバッグメッセージの出力（未使用: MSGは1行に統合する）
    static void outputDebugMessage(const string& message) {
        cout << "MSG " << message << endl;
    }
};

// アクション生成用のヘルパー関数
class ActionBuilder {
   public:
    static string moveAction(int bridgeman_id, int island_id) {
        return "MOVE " + to_string(bridgeman_id) + " " + to_string(island_id);
    }

    static string unpackAction(int bridgeman_id, int island_id) {
        return "UNPACK " + to_string(bridgeman_id) + " " + to_string(island_id);
    }

    static string packAction(int bridgeman_id, int island_id) {
        return "PACK " + to_string(bridgeman_id) + " " + to_string(island_id);
    }

    static string teamUnpackAction(int bridgeman1_id, int bridgeman2_id, int length1) {
        return "TEAMUNPACK " + to_string(bridgeman1_id) + " " + to_string(bridgeman2_id) + " " + to_string(length1);
    }

    static string teamPackAction(int bridgeman1_id, int bridgeman2_id, int length1) {
        return "TEAMPACK " + to_string(bridgeman1_id) + " " + to_string(bridgeman2_id) + " " + to_string(length1);
    }
    static string msg(const string& s) {
        return string("MSG ") + s;
    }
};

//==================================================
// ソルバ本体
//==================================================
namespace {

const int INF = 1e9;

struct AgentPlan {
    enum Stage { Idle,
                 NeedUnpack,
                 NeedMove,
                 NeedPack } stage = Idle;
    int from = -1;
    int to = -1;

    bool hasAssignment = false;
    int assignOrigin = -1;
    int assignDest = -1;
};

struct SolverState {
    int N = 0, B = 0;
    vector<vector<bool>> bridgeActive;  // 実際に存在する橋（ローカル追跡）
    vector<vector<int>> bridgeOwner;    // 橋のオーナー（-1:無し、id:作成者）
    vector<vector<int>> within50;       // 各島から距離50以下で到達できる隣接島
    vector<AgentPlan> plans;            // 各エージェントのフェーズ管理

    unordered_set<long long> reservedUnpack;  // 無向辺キー
    unordered_set<long long> reservedPack;    // 無向辺キー
};

long long edgeKey(int a, int b) {
    if (a > b) swap(a, b);
    return (long long)a * 1000LL + (long long)b;  // N<=80, 1000で十分
}

struct PathResult {
    vector<int> path;  // src..dst の島列
    int cost = INF;
    bool ok = false;
};

// dijkstra: エッジコスト= 既存橋:1, 新規(≤50):3
PathResult shortestPathTurns(const GameState& state, const SolverState& ss, int src, int dst) {
    int n = state.N;
    vector<int> dist(n, INF), prev(n, -1);
    using P = pair<int, int>;
    priority_queue<P, vector<P>, greater<P>> pq;
    dist[src] = 0;
    pq.emplace(0, src);

    while (!pq.empty()) {
        auto top = pq.top();
        pq.pop();
        int d = top.first;
        int u = top.second;
        if (d != dist[u]) continue;
        if (u == dst) break;

        // 既存の橋経由
        for (int v = 0; v < n; v++) {
            if (!ss.bridgeActive[u][v]) continue;
            int nd = d + 1;  // MOVE 1ターン
            if (nd < dist[v]) {
                dist[v] = nd;
                prev[v] = u;
                pq.emplace(nd, v);
            }
        }
        // 未構築で距離≤50
        for (int v : ss.within50[u]) {
            if (ss.bridgeActive[u][v]) continue;  // 上で処理済
            int nd = d + 3;                       // UNPACK→MOVE→PACK の3ターン
            if (nd < dist[v]) {
                dist[v] = nd;
                prev[v] = u;
                pq.emplace(nd, v);
            }
        }
    }

    PathResult pr;
    if (dist[dst] >= INF) return pr;

    pr.cost = dist[dst];
    pr.ok = true;

    // 復元
    vector<int> rev;
    for (int v = dst; v != -1; v = prev[v]) rev.push_back(v);
    reverse(rev.begin(), rev.end());
    pr.path = move(rev);
    return pr;
}

// ハンガリー法（最小費用割当）
// 入力: cost 行列 (nAgents x nOrders) / 長方行列OK。INFは大きめ数。
// 戻り: agent i -> order idx (割り当て番号 or -1)
vector<int> hungarianMinAssign(const vector<vector<int>>& cost) {
    int n = (int)cost.size();
    int m = cost.empty() ? 0 : (int)cost[0].size();
    int N = max(n, m);
    const int BIG = 1e8;

    // 正方化
    vector<vector<int>> a(N, vector<int>(N, 0));
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < N; j++) {
            int c = 0;
            if (i < n && j < m)
                c = cost[i][j];
            else
                c = BIG;
            a[i][j] = c;
        }
    }

    // 1-indexed 実装
    vector<int> u(N + 1, 0), v(N + 1, 0), p(N + 1, 0), way(N + 1, 0);
    for (int i = 1; i <= N; i++) {
        p[0] = i;
        int j0 = 0;
        vector<int> minv(N + 1, BIG);
        vector<char> used(N + 1, false);
        do {
            used[j0] = true;
            int i0 = p[j0], delta = BIG, j1 = 0;
            for (int j = 1; j <= N; j++) {
                if (used[j]) continue;
                int cur = a[i0 - 1][j - 1] - u[i0] - v[j];
                if (cur < minv[j]) {
                    minv[j] = cur;
                    way[j] = j0;
                }
                if (minv[j] < delta) {
                    delta = minv[j];
                    j1 = j;
                }
            }
            for (int j = 0; j <= N; j++) {
                if (used[j]) {
                    u[p[j]] += delta;
                    v[j] -= delta;
                } else {
                    minv[j] -= delta;
                }
            }
            j0 = j1;
        } while (p[j0] != 0);
        do {
            int j1 = way[j0];
            p[j0] = p[j1];
            j0 = j1;
        } while (j0);
    }

    vector<int> ans(n, -1);
    for (int j = 1; j <= N; j++) {
        if (p[j] == 0) continue;
        int i = p[j] - 1;
        int jj = j - 1;
        if (i < n && jj < m) {
            if (a[i][jj] < BIG / 2) ans[i] = jj;
        }
    }
    return ans;
}

// 簡易メッセージ（最後のMSGのみ可視）
string buildTurnMsg(const GameState& state, const SolverState& ss) {
    ostringstream oss;
    oss << "T=" << state.turn << " ";
    int activeCnt = 0;
    for (int i = 0; i < ss.N; i++)
        for (int j = i + 1; j < ss.N; j++)
            if (ss.bridgeActive[i][j]) activeCnt++;
    oss << "bridges=" << activeCnt;
    return oss.str();
}

}  // namespace

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    GameState state;

    // 初期入力の読み込み
    IOHandler::readInitialInput(state);

    // ソルバ状態初期化
    SolverState ss;
    ss.N = state.N;
    ss.B = state.B;
    ss.bridgeActive.assign(state.N, vector<bool>(state.N, false));
    ss.bridgeOwner.assign(state.N, vector<int>(state.N, -1));
    ss.within50.assign(state.N, {});
    for (int i = 0; i < state.N; i++) {
        for (int j = 0; j < state.N; j++) {
            if (i == j) continue;
            if (state.distances[i][j] > 0 && state.distances[i][j] <= 50) {
                ss.within50[i].push_back(j);
            }
        }
    }
    ss.plans.assign(state.B, AgentPlan{});

    // 1000ターンのメインループ
    for (state.turn = 0; state.turn < 1000; state.turn++) {
        // ターンごとの入力読み込み
        IOHandler::readTurnInput(state);

        // 1. 予約リセット
        ss.reservedUnpack.clear();
        ss.reservedPack.clear();

        // 2. 割当（ハンガリー法）：対象は「ターゲット無し & Idle」のエージェント
        vector<int> freeAgents;
        for (int i = 0; i < state.B; i++) {
            auto& bm = state.bridgemen[i];
            auto& pl = ss.plans[i];
            if (bm.target_island == -1 && pl.stage == AgentPlan::Idle) {
                freeAgents.push_back(i);
            }
        }

        vector<vector<int>> cost;  // freeAgents x orders
        cost.assign(freeAgents.size(), vector<int>(state.orders.size(), INF));
        for (int ai = 0; ai < (int)freeAgents.size(); ai++) {
            int id = freeAgents[ai];
            int src = state.bridgemen[id].island_id;
            for (int oj = 0; oj < (int)state.orders.size(); oj++) {
                int o = state.orders[oj].origin_island;
                int d = state.orders[oj].dest_island;
                auto p1 = shortestPathTurns(state, ss, src, o);
                if (!p1.ok) continue;
                auto p2 = shortestPathTurns(state, ss, o, d);
                if (!p2.ok) continue;
                long long total = (long long)p1.cost + (long long)p2.cost;
                if (total >= INF) continue;
                cost[ai][oj] = (int)min<long long>(total, INF - 1);
            }
        }
        vector<int> assign;
        if (!freeAgents.empty() && !state.orders.empty()) {
            assign = hungarianMinAssign(cost);
        }

        // 割当結果を反映（Invalidは無視）
        for (int ai = 0; ai < (int)freeAgents.size(); ai++) {
            int ag = freeAgents[ai];
            auto& pl = ss.plans[ag];
            int oj = (assign.empty() ? -1 : assign[ai]);
            if (oj >= 0 && oj < (int)state.orders.size() && cost[ai][oj] < INF) {
                pl.hasAssignment = true;
                pl.assignOrigin = state.orders[oj].origin_island;
                pl.assignDest = state.orders[oj].dest_island;
            } else {
                if (!pl.hasAssignment) {
                    pl.hasAssignment = false;
                    pl.assignOrigin = -1;
                    pl.assignDest = -1;
                }
            }
        }

        // 3. アクション決定
        vector<string> actions;
        vector<char> agentUsed(state.B, false);

        auto canPackEdge = [&](int id, int from, int to, int atIsland) -> bool {
            if (from < 0 || to < 0) return false;
            if (!ss.bridgeActive[from][to]) return false;
            if (ss.bridgeOwner[from][to] != id) return false;         // 自分の橋のみ回収
            if (!(atIsland == from || atIsland == to)) return false;  // 端点に居ること
            long long k = edgeKey(from, to);
            if (ss.reservedPack.count(k)) return false;
            return true;
        };

        auto schedulePack = [&](int id, int from, int to, int atIsland) -> bool {
            if (!canPackEdge(id, from, to, atIsland)) return false;
            int other = (atIsland == from ? to : from);
            actions.push_back(ActionBuilder::packAction(id, other));
            ss.reservedPack.insert(edgeKey(from, to));
            // ローカル更新
            ss.bridgeActive[from][to] = ss.bridgeActive[to][from] = false;
            ss.bridgeOwner[from][to] = ss.bridgeOwner[to][from] = -1;
            agentUsed[id] = true;
            auto& pl = ss.plans[id];
            pl.stage = AgentPlan::Idle;
            pl.from = pl.to = -1;
            return true;
        };

        auto canMoveEdge = [&](int /*id*/, int from, int to, int atIsland) -> bool {
            if (atIsland != from) return false;
            if (!ss.bridgeActive[from][to]) return false;
            return true;
        };

        auto scheduleMove = [&](int id, int from, int to, int atIsland) -> bool {
            if (!canMoveEdge(id, from, to, atIsland)) return false;
            actions.push_back(ActionBuilder::moveAction(id, to));
            agentUsed[id] = true;
            auto& pl = ss.plans[id];
            pl.stage = AgentPlan::NeedPack;  // 次ターンで回収
            return true;
        };

        auto canUnpackEdge = [&](int id, int u, int v, int carry) -> bool {
            if (ss.bridgeActive[u][v]) return false;  // 既存
            int d = state.distances[u][v];
            if (d <= 0 || d > 50) return false;  // 50以内のみ
            if (carry < d) return false;         // 手持ち不足は不可
            long long k = edgeKey(u, v);
            if (ss.reservedUnpack.count(k)) return false;  // 同ターン重複防止
            return true;
        };

        auto scheduleUnpack = [&](int id, int u, int v) -> bool {
            if (!canUnpackEdge(id, u, v, state.bridgemen[id].carry_length)) return false;
            actions.push_back(ActionBuilder::unpackAction(id, v));
            ss.reservedUnpack.insert(edgeKey(u, v));
            // ローカルに橋生成＆オーナー付与
            ss.bridgeActive[u][v] = ss.bridgeActive[v][u] = true;
            ss.bridgeOwner[u][v] = ss.bridgeOwner[v][u] = id;
            agentUsed[id] = true;
            auto& pl = ss.plans[id];
            pl.stage = AgentPlan::NeedMove;
            pl.from = u;
            pl.to = v;
            return true;
        };

        // 3-1) 回収（NeedPack）を最優先
        for (int i = 0; i < state.B; i++) {
            if (agentUsed[i]) continue;
            auto& bm = state.bridgemen[i];
            auto& pl = ss.plans[i];
            if (pl.stage == AgentPlan::NeedPack) {
                schedulePack(i, pl.from, pl.to, bm.island_id);
            }
        }

        // 3-2) 移動（NeedMove）
        for (int i = 0; i < state.B; i++) {
            if (agentUsed[i]) continue;
            auto& bm = state.bridgemen[i];
            auto& pl = ss.plans[i];
            if (pl.stage == AgentPlan::NeedMove) {
                scheduleMove(i, pl.from, pl.to, bm.island_id);
            }
        }

        // 3-3) Idleの者に対して経路→UNPACKまたはMOVEを実行
        for (int i = 0; i < state.B; i++) {
            if (agentUsed[i]) continue;
            auto& bm = state.bridgemen[i];
            auto& pl = ss.plans[i];
            if (pl.stage != AgentPlan::Idle) continue;

            int goal = -1;
            if (bm.target_island != -1) {
                goal = bm.target_island;  // 既にメッセージ所持
            } else if (pl.hasAssignment) {
                goal = pl.assignOrigin;  // まずは受取元へ
            } else {
                continue;  // 待機
            }
            if (goal == -1 || goal == bm.island_id) continue;

            auto pr = shortestPathTurns(state, ss, bm.island_id, goal);
            if (!pr.ok || pr.path.size() < 2) {
                continue;  // 経路なし（TEAM拡張余地）
            }
            int u = pr.path[0];
            int v = pr.path[1];

            if (ss.bridgeActive[u][v]) {
                actions.push_back(ActionBuilder::moveAction(i, v));
                agentUsed[i] = true;
            } else {
                scheduleUnpack(i, u, v);
            }
        }

        // 4) 最後にMSGを追加
        actions.push_back(ActionBuilder::msg(buildTurnMsg(state, ss)));

        // 5) 出力
        IOHandler::outputActions(actions);
    }

    return 0;
}
