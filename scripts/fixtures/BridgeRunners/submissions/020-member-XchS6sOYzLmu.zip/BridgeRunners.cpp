// C++11
#include <bits/stdc++.h>
#include <sys/time.h>
#define GREEDY
#ifdef LOCAL
#include "../logger.hpp"
// #include "../TCClient.hpp"
#define LOG_TC(...) LOG_INFO(__VA_ARGS__);
void Initialize(int argc, char** argv);
#else
void Initialize(int argc, char** argv) {}
#define SHOW(...);
#define LOG_DEBUG(...);
#define LOG_INFO(...);
#define LOG_WARNING(...);
#define LOG_ERROR(...);
#define LOG_TC(...) {fprintf(stderr, __VA_ARGS__);fprintf(stderr, "\n"); }
#define PANIC(...);
#define ASSERT(...);
#endif

#ifdef USEPROFILER
#include "../Profiler.hpp"
#else
#define PROFILER_VAR(var, name);
#define PROFILER(name);
#endif

static inline double get_time() {
  timeval tv;
  gettimeofday(&tv, 0);
  return tv.tv_sec + tv.tv_usec * 1e-6;
}
double tlime;
// Need calibration
static inline double get_fast_time() {
  unsigned long long timelo, timehi;
  __asm__ volatile("rdtsc" : "=a"(timelo), "=d"(timehi));
  return ((timehi << 32) + timelo) * 3.5714286e-10;
}

const double END_TIME = 9.5;
double start_time = get_time();
double end_time = start_time + END_TIME;

struct rand_gen {
  static constexpr uint32_t kMax = 2147483647;
  static constexpr double kInvMax = 1.0 / (double)kMax;
  static constexpr __uint128_t kAdd = 0x60bee2bee120fc15ull;
  static constexpr __uint128_t kMul1 = 0xa3b195354a39b70dull;
  static constexpr __uint128_t kMul2 = 0x1b03738712fad5c9ull;
  uint64_t state = get_time() * 1000000 * 0 + 42;
  inline void seed(uint64_t seed) { state = seed; }
  inline uint32_t next_int() {
    state += kAdd; __uint128_t tmp = (__uint128_t)state * kMul1;
    uint64_t m1 = (tmp >> 64) ^ tmp; tmp = (__uint128_t)m1 * kMul2;
    uint64_t m2 = (tmp >> 64) ^ tmp; return (uint32_t)m2;
  }
  inline uint64_t next_int64() {
    state += kAdd; __uint128_t tmp = (__uint128_t)state * kMul1;
    uint64_t m1 = (tmp >> 64) ^ tmp; tmp = (__uint128_t)m1 * kMul2;
    uint64_t m2 = (tmp >> 64) ^ tmp;
    return m2;
  }
  inline uint32_t next_int(uint32_t max) { return next_int()%max; }
  inline uint32_t next_int(uint32_t min, uint32_t max) { return min + (next_int()%(max-min)); }
  inline double next_float() { return next_int(kMax) * kInvMax; }
} rng;

template<int Size>
class FastMap { public:
  FastMap() {size_ = 0; for (int i = 0; i < Size; i++) pos_[i] = -1; }
  void clear() { while (size_) { pos_[taken_[--size_]] = -1; }}
  inline void safeInsert(int v) { if (has(v)) return; insert(v);}
  inline void insert(int v) { taken_[pos_[v] = size_++] = v; }
  inline void push_back(int v) { taken_[pos_[v] = size_++] = v; }
  inline void pop_back() { pos_[taken_[--size_]] = -1; }
  inline int back() { return taken_[size_-1]; }
  inline void erase(int v) {
    const int p = pos_[v];
    const int last = taken_[--size_];
    pos_[last] = p;
    taken_[p] = last;
    pos_[v] = -1;
  }
  inline int operator[](int i) { return taken_[i]; }
  inline void safeErase(int v) { if (has(v)) erase(v); }
  inline bool has(int v) { return pos_[v] >= 0; }
  std::vector<int> toVector() {
    std::vector<int> ret;
    ret.insert(ret.begin(), begin(), end());
    return ret;
  }
  const std::vector<int>& toVector(std::vector<int>& ret) {
    ret.clear();
    ret.insert(ret.begin(), begin(), end());
    return ret;
  }
  inline int size() { return size_; }
  inline bool empty() { return size_ == 0; }
  inline int* begin() { return taken_.data(); }
  inline int* end() { return taken_.data() + size_; }

 private:
  std::array<int, Size> pos_;
  std::array<int, Size> taken_;
  int size_;
};

template <class T, int Size>
class Hungarian { public:
  T H[Size][Size] = {};
  int job[Size + 1] = {};
  T hungarian(int J, int W) {
    PROFILER("hungarian");

    std::fill(job, job + Size + 1, -1);
    T ys[J] = {};
    T yt[W + 1] = {};

    T answers = 0;
    const T inf = std::numeric_limits<T>::max();
    int Z[W+1]; int zz; Z[W] = W;
    for (zz = 0; zz < W; zz++) Z[zz] = zz;
    T min_to[W+1];
    int prv[W+1];
    for (int j_cur = 0; j_cur < J; ++j_cur) {
      zz = W;
      int w_cur = W;
      job[w_cur] = j_cur;
      std::fill(min_to, min_to + W + 1, inf);
      std::fill(prv, prv + W + 1, -1);
      while (job[w_cur] != -1) {
        const int j = job[w_cur];
        T delta = inf;
        int w_next;
        for (int ww = 0; ww < zz; ++ww) {
          int w = Z[ww];
          {
            const T b = H[j][w] - ys[j] - yt[w];
            if (b < min_to[w]) min_to[w] = b, prv[w] = w_cur;
          }
          if (min_to[w] < delta) { delta = min_to[w]; w_next = ww; }
        }
        for (int w = 0; w < zz; ++w)  min_to[Z[w]] -= delta;
        for (int w = zz; w <= W; ++w) ys[job[Z[w]]] += delta, yt[Z[w]] -= delta;
        w_cur = Z[w_next];
        std::swap(Z[w_next], Z[--zz]);
      }
      for (int w; w_cur != -1; w_cur = w) job[w_cur] = job[w = prv[w_cur]];
      answers = -yt[W];
    }
    return answers;
  }
};

const int MaxDistInit = 50;
const int MaxDist = 100;

struct Action {
  static constexpr int kUnpack = 0;
  static constexpr int kUnpack2 = 1;
  static constexpr int kMove = 2;
  static constexpr int kPack = 3;
  static constexpr int kPack2 = 4;
  static constexpr int kSkip = 16;
  int type;
  int id;
  int dest;
  int id2 = 0;
  int amount = 0;
  void print() {
    if (type == kUnpack) printf("UNPACK %d %d | ", id, dest);
    if (type == kUnpack2) printf("TEAMUNPACK %d %d %d | ", id, id2, amount);
    if (type == kMove) printf("MOVE %d %d | ", id, dest);
    if (type == kPack) printf("PACK %d %d | ", id, dest);
    if (type == kPack2) printf("TEAMPACK %d %d %d | ", id, id2, amount);
  }
};

class Bridgeman {
 public:
  int ID;
  int Position;
  int Target;
  int Bricks;
  int BridgeFrom = -1;
  int BridgeTo = -1;
  std::vector<Action> actions;
  int epos;
  int target;
};
Bridgeman bridgemen[32];

class Order {
 public:
  int From;
  int To;
};
Order orders[32];

int N, B, O, C;
int Dist[80][80];
int connected[2048][80][80];
int connectedId[2048][80][80];
int turn;

int Comp[80];
int CompSize[80];
bool ValidComp[80];
bool Valid[80];

std::vector<int> EdgesSolo[80];
std::vector<int> EdgesDuo[80];

std::vector<std::pair<int, int>> Jumps[20][20];
std::vector<std::pair<int, int>> SameJumps[20];

void ComputeComps() {
  for (int i = 0; i < N; i++) {
    for (int k = 0; k < N; k++) {
      if (i == k || Dist[i][k] > MaxDist) continue;
      if (Dist[i][k] > MaxDistInit) {
        EdgesDuo[i].push_back(k);
      } else {
        EdgesSolo[i].push_back(k);
      }
    }
  }
  auto dfs = [&](auto dfs, int s, int i) {
    if (Comp[s] != 0) return;
    Comp[s] = i;
    CompSize[i]++;
    for (int k : EdgesSolo[s]) {
      dfs(dfs, k, i);
    }
  };
  C = 0;
  for (int i = 0; i < N; i++) {
    if (Comp[i] == 0) dfs(dfs, i, ++C);
  }
  for (int b = 0; b < B; b++) ValidComp[Comp[bridgemen[b].Position]] = true;
  int rem = 0;
  for (int i = 0; i < N; i++) {
    if (ValidComp[Comp[i]]) {
      Valid[i] = true;
    } else {
      rem++;
    }
  }
  double avg_dist = 0.0;
  for (int i = 0; i < N; i++) {
    for (int k = 0; k < N; k++) {
      if (Dist[i][k] <= MaxDist && Dist[i][k] > MaxDistInit) Jumps[Comp[i]][Comp[k]].push_back({i, k});
      if (Dist[i][k] <= MaxDistInit) SameJumps[Comp[k]].push_back({i, k});
    }
  }
  LOG_INFO("Num component: %d, invalid %d", C, rem);
  LOG_INFO("METADATA_START:{\"N\": %d, \"B\": %d, \"O\": %d, \"C\": %d, \"R\": %d}:METADATA_END", N, B, O, C, rem);
}


int DistSolo[80][80];
int FromSolo[80][80];
void BFSSolo() {
  for (int start = 0; start < N; start++) {
    for (int i = 0; i < N; i++) DistSolo[start][i] = 1000000;
    for (int i = 0; i < N; i++) FromSolo[start][i] = -1;
    std::vector<int> ll[2];
    ll[0].push_back(start);
    DistSolo[start][start] = 0;
    FromSolo[start][start] = -1;
    for (int d = 0; !ll[d%2].empty(); d++) {
      for (int n : ll[d%2]) {
        for (int e : EdgesSolo[n]) {
          if (DistSolo[start][e] <= d+1) continue;
          DistSolo[start][e] = d+1;
          FromSolo[start][e] = n;
          ll[(d+1)%2].push_back(e);
        }
      }
      ll[d%2].clear();
    }
  }
}
int DistDuo[80][80];
int FromDuo[80][80];
void BFSDuo() {
  const int Cost = B > 2 * C ? 4 : 8;
  // const int Cost = N / B;
  for (int start = 0; start < N; start++) {
    for (int i = 0; i < N; i++) DistDuo[start][i] = 1000000;
    for (int i = 0; i < N; i++) FromDuo[start][i] = -1;
    std::vector<int> ll[128];
    ll[0].push_back(start);
    DistDuo[start][start] = 0;
    FromDuo[start][start] = -1;
    for (int d = 0; d < 100; d++) {
      for (int n : ll[d]) {
        for (int e : EdgesSolo[n]) {
          if (DistDuo[start][e] <= d+1) continue;
          DistDuo[start][e] = d+1;
          FromDuo[start][e] = n;
          ll[d+1].push_back(e);
        }
        for (int e : EdgesDuo[n]) {
          if (DistDuo[start][e] <= d+Cost) continue;
          DistDuo[start][e] = d+Cost;
          FromDuo[start][e] = n;
          ll[d+Cost].push_back(e);
        }
      }
    }
  }
  double avg_dist = 0.0;
  for (int start = 0; start < N; start++)
    for (int end = 0; end < N; end++)
      avg_dist += DistDuo[start][end];
  avg_dist /= (N * N - N);
  LOG_INFO("Distance: %lf, Score: %lf", avg_dist, 1000.0 * B / (3.5 * avg_dist));
}

void Connect(int a, int b, int turn, int t, int id) {
  connected[t][a][b] = turn;
  connected[t+1][a][b] = turn;
  connected[t+2][a][b] = turn;
  connected[t][b][a] = turn;
  connected[t+1][b][a] = turn;
  connected[t+2][b][a] = turn;

  connectedId[t][a][b] = id;
  connectedId[t+1][a][b] = id;
  connectedId[t+2][a][b] = id;
  connectedId[t][b][a] = id;
  connectedId[t+1][b][a] = id;
  connectedId[t+2][b][a] = id;
}

int AllDist[80][80];
double ExpectedScore(std::vector<std::pair<int, int>> edges, int K) {
  const int Cost = B > 2 * C ? 4 : 8;
  for (int a = 0; a < N; a++) {
    for (int b = 0; b < N; b++) {
      if (Dist[a][b] <= MaxDistInit) AllDist[a][b] = 3;
      else if (Dist[a][b] <= MaxDist) AllDist[a][b] = 3 * Cost;
      else AllDist[a][b] = 100000;
    }
    AllDist[a][a] = 0;
  }
  for (auto e : edges) {
    AllDist[e.first][e.second] /= 3;
    AllDist[e.second][e.first] /= 3;
  }
  for (int c = 0; c < N; c++) {
    for (int b = 0; b < N; b++) {
      for (int a = 0; a < N; a++) {
        AllDist[a][b] = std::min(AllDist[a][b], AllDist[a][c] + AllDist[c][b]);
      }
    }
  }
  int ret = 0;
  for (int a = 0; a < N; a++) {
    for (int b = 0; b < N; b++) {
      ret += AllDist[a][b];
    }
  }
  return 1000.0 * K * (N * N - N) / (ret * 1.2);
}

int visited[1024][128];
std::pair<int, int> from[1024][128];
int vv;
std::vector<Action> BFS(int start, int to, int time, int id, bool clear = true) {
  vv++;
  std::vector<Action> ret;
  std::vector<int> ll[600];
  ll[0].push_back(start);
  for (int d = 0; d < 512 && d + time; d++) {
    for (int n : ll[d]) {
      if (n == to) {
        while (d > 0) {
          // if (clear)
          ret.clear();
          if (from[d][n].first == d - 1) {
            ret.push_back({Action::kMove, id, n});
            n = from[d][n].second;
            d--;
          } else if (Dist[n][from[d][n].second] <= MaxDistInit) {
            ret.push_back({Action::kPack, id, from[d][n].second});
            ret.push_back({Action::kMove, id, n});
            ret.push_back({Action::kUnpack, id, n});
            Connect(n, from[d][n].second, turn, time + d - 3, id);
            n = from[d][n].second;
            d -= 3;
          } else {
            n = from[d][n].second;
            d -= 64;
          }
        }
        return ret;
      }
      for (int e : EdgesSolo[n]) {
        if (connected[time+d][n][e] >= turn) {
          if (visited[d+1][e] != vv) {
            visited[d+1][e] = vv;
            from[d+1][e] = {d, n};
            ll[d+1].push_back(e);
          }
        } else {
          if (connected[time+d+1][n][e] >= turn) continue;
          if (connected[time+d+2][n][e] >= turn) continue;
          if (visited[d+3][e] != vv) {
            visited[d+3][e] = vv;
            from[d+3][e] = {d, n};
            ll[d+3].push_back(e);
          }
        }
      }
      if (clear) {
        for (int e : EdgesDuo[n]) {
          if (connected[time+d][n][e] >= turn) {
            if (visited[d+1][e] != vv) {
              visited[d+1][e] = vv;
              from[d+1][e] = {d, n};
              ll[d+1].push_back(e);
            }
          } else {
            if (visited[d+64][e] != vv) {
              visited[d+64][e] = vv;
              from[d+64][e] = {d, n};
              ll[d+64].push_back(e);
            }
          }
        }
        if (visited[d+1][n] != vv) {
          visited[d+1][n] = vv;
          from[d+1][n] = {d, n};
          ll[d+1].push_back(n);
        }
      }
    }
    ll[d%2].clear();
  }
  return ret;
}

std::vector<Action> actions;
bool used[1024];
void ParseTurn() {
  int elapsedTime;
  std::cin >> elapsedTime;
  for (int i = 0; i < B; ++i) {
    std::cin >> bridgemen[i].Position >> bridgemen[i].Bricks >> bridgemen[i].target;
    bridgemen[i].Target = bridgemen[i].target;
  }
  for (int i = 0; i < O; ++i) {
    std::cin >> orders[i].From >> orders[i].To;
  }
  actions.clear();
  for (int b = 0; b < B; b++) used[b] = false;
}

void Swap(int i1, int i2) {
  int s1 = bridgemen[i1].Position;
  int s2 = bridgemen[i2].Position;
  if (connected[turn][s1][s2] >= turn) {
    bridgemen[i1].actions.push_back({Action::kMove, bridgemen[i1].ID, s2});
    bridgemen[i2].actions.push_back({Action::kMove, bridgemen[i2].ID, s1});
    used[i1] = true;
    used[i2] = true;
    return;
  }
  used[i1] = true;
  used[i2] = true;
  bridgemen[i1].actions.push_back({Action::kPack2, bridgemen[i1].ID, 0, bridgemen[i2].ID, MaxDistInit});
  bridgemen[i2].actions.push_back({Action::kSkip, bridgemen[i2].ID, 0});
  bridgemen[i1].actions.push_back({Action::kMove, bridgemen[i1].ID, s2});
  bridgemen[i2].actions.push_back({Action::kMove, bridgemen[i2].ID, s1});
  bridgemen[i1].actions.push_back({Action::kUnpack2, bridgemen[i1].ID, 0, bridgemen[i2].ID, MaxDistInit});
  bridgemen[i2].actions.push_back({Action::kSkip, bridgemen[i2].ID, 0});
  Connect(s1, s2, turn + 2, turn, i1);
}

Hungarian<double, 32> hung;
void AssignTargets() {
  int size = std::max(B, O);
  for (int b = 0; b < size; b++) {
    for  (int o = 0; o < size; o++) {
      if (b >= B || o >= O) hung.H[o][b] = 1000000;
      else if (bridgemen[b].target >= 0) hung.H[o][b] = 1000000;
      else {
        hung.H[o][b] = std::sqrt(DistDuo[bridgemen[b].epos][orders[o].From] + bridgemen[b].actions.size());
      }
    }
  }
  hung.hungarian(size, size);
  for (int b = 0; b < B; b++) {
    if (bridgemen[b].target >= 0) continue;
    if (hung.job[b] >= O) continue;
    // LOG_INFO("%d - Assign %d to %d (%d)", turn, b, orders[hung.job[b]].From, DistDuo[bridgemen[b].epos][orders[hung.job[b]].From] + bridgemen[b].actions.size());
    bridgemen[b].Target = orders[hung.job[b]].From;
  }
}

struct Beam {
  int parent;
  int score;
  int used;
};
Beam beams[1000000];

struct CompareInt {
    bool operator()(int a, int b) {
        return beams[a].score > beams[b].score;
    }
};

void SolveKC() {
  AssignTargets();
  // Find shortcut
  struct Act {
    int score;
    int type;
    int i1, i2, i3;
    int m1, m2;
    int t = 0;
    bool rep1 = true;
    bool rep2 = true;
  };
  std::vector<Act> swaps;
  for (int i1 = 0; i1 < B; i1++) {
    for (int i2 = i1 + 1; i2 < B; i2++) {
      if (bridgemen[i1].target < 0 && bridgemen[i2].target < 0) continue;
      int s1 = bridgemen[i1].epos;
      int s2 = bridgemen[i2].epos;
      int t1 = bridgemen[i1].Target;
      int t2 = bridgemen[i2].Target;
      int cd = 0;
      if (t1 >= 0) cd += 3 * DistDuo[s1][t1] + bridgemen[i1].actions.size();
      if (t2 >= 0) cd += 3 * DistDuo[s2][t2] + bridgemen[i2].actions.size();
      int ccomp = 0;
      if (t1 >= 0) ccomp += Comp[s1] == Comp[t1];
      if (t2 >= 0) ccomp += Comp[s2] == Comp[t2];

      cd -= ccomp * 16;

      int bdiff = 100000;
      Act bact;
      for (auto& j : Jumps[Comp[s1]][Comp[s2]]) {
        int nd = 0;
        int m1 = 3 * DistSolo[s1][j.first] + bridgemen[i1].actions.size();
        int m2 = 3 * DistSolo[s2][j.second] + bridgemen[i2].actions.size();
        int add = 3;
        int m = std::max(m1, m2);
        if (connected[turn + m][j.first][j.second] >= turn) {
          add = 1;
        }
        int e1 = 3 * DistDuo[j.second][t1] + add;
        int e2 = 3 * DistDuo[j.first][t2] + add;
        if (t1 >= 0) nd += m + e1;
        if (t2 >= 0) nd += m + e2;
        int ncomp = 0;
        if (t1 >= 0) ncomp += Comp[j.second] == Comp[t1];
        if (t2 >= 0) ncomp += Comp[j.first] == Comp[t2];
        nd -= ncomp * 16;
        if (nd < cd) {
          int t = m;
          if (nd - cd < bdiff || (nd - cd == bdiff && bact.t > m)) {
            bdiff = nd - cd;
            bact = {nd - cd, 0, i1, i2, -1, j.first, j.second, m};
          }
        }
      }
      if (Comp[s1] == Comp[s2]) {
        for (auto& j : SameJumps[Comp[s2]]) {
          if (t1 >= 0 && DistSolo[s1][j.first] + DistSolo[j.second][t1] + 1 > DistSolo[s1][t1]) continue;
          if (t2 >= 0 && DistSolo[s2][j.second] + DistSolo[j.first][t2] + 1 > DistSolo[s2][t2]) continue;
          int m1 = 3 * DistSolo[s1][j.first] + bridgemen[i1].actions.size();
          int m2 = 3 * DistSolo[s2][j.second] + bridgemen[i2].actions.size();
          if (std::abs(m1 - m2) < 3) {
            if (-2 < bdiff || (-2 == bdiff && bact.t > std::min(m1, m2))) {
              bdiff = -2;
              bact = {-2, 1, i1, i2, -1, j.first, j.second, std::min(m1, m2)};
            }
          } else if (std::abs(m1 - m2) == 3) {
            // if (-1 < bdiff || (-1 == bdiff && bact.t > std::min(m1, m2))) {
            //   bdiff = -1;
            //   bact = {-1, 2, i1, i2, -1, j.first, j.second, std::min(m1, m2)};
            // }
          }
        }
        for (auto& j : SameJumps[Comp[s2]]) {
          if (t1 >= 0 && DistSolo[s1][j.first] + DistSolo[j.second][t1] + 1 > DistSolo[s1][t1]) continue;
          if (t2 >= 0 && DistSolo[s2][j.first] + DistSolo[j.second][t2] + 1 > DistSolo[s2][t2]) continue;
          int m1 = 3 * DistSolo[s1][j.first] + bridgemen[i1].actions.size();
          int m2 = 3 * DistSolo[s2][j.first] + bridgemen[i2].actions.size();
          if (std::abs(m1 - m2) < 3) {
            if (-2 < bdiff || (-2 == bdiff && bact.t > std::min(m1, m2))) {
              bdiff = -2;
              bact = {-2, 3, i1, i2, -1, j.first, j.second, std::min(m1, m2)};
            }
          } else if (std::abs(m1 - m2) == 3) {
            // if (-1 < bdiff || (-1 == bdiff && bact.t > std::min(m1, m2))) {
            //   bdiff = -1;
            //   bact = {-1, 4, i1, i2, -1, j.first, j.second, std::min(m1, m2)};
            // }
          }
        }
      }
      if (bdiff < 100000) {
        swaps.push_back(bact);
      }
    }
  }
  if (C > 1) {
    for (int i1 = 0; i1 < B; i1++) {
      int s1 = bridgemen[i1].epos;
      int t1 = bridgemen[i1].Target;
      for (int i2 = 0; i2 < B; i2++) {
        int s2 = bridgemen[i2].epos;
        int t2 = bridgemen[i2].Target;
        if (Comp[s1] != Comp[s2] || i1 == i2) continue;
        for (int i3 = 0; i3 < B; i3++) {
          int s3 = bridgemen[i3].epos;
          int t3 = bridgemen[i3].Target;
          if (Comp[s3] == Comp[s1]) continue;

          int cd = 0;
          if (t1 >= 0) cd += 3 * DistDuo[s1][t1] + bridgemen[i1].actions.size();
          if (t2 >= 0) cd += 3 * DistDuo[s2][t2] + bridgemen[i2].actions.size();
          if (t3 >= 0) cd += 3 * DistDuo[s3][t3] + bridgemen[i3].actions.size();
          int ccomp = 0;
          if (t1 >= 0) ccomp += Comp[s1] == Comp[t1];
          if (t2 >= 0) ccomp += Comp[s2] == Comp[t2];
          if (t3 >= 0) ccomp += Comp[s3] == Comp[t3];
          cd -= ccomp * 16;

          int bdiff = 100000;
          Act bact;

          for (auto& j : Jumps[Comp[s1]][Comp[s3]]) {
            int nd = 0;
            int m1 = 3 * DistSolo[s1][j.first] + bridgemen[i1].actions.size();
            int m2 = 3 * DistSolo[s2][j.first] + bridgemen[i2].actions.size();
            int m3 = 3 * DistSolo[s3][j.second] + bridgemen[i3].actions.size();
            int open = std::max(m1, m3);
            int cross = std::max(open, m2);
            int close = std::max(cross, open+1);

            int e1 = 3 * DistDuo[j.first][t1];
            int e2 = 3 * DistDuo[j.second][t2];
            int e3 = 3 * DistDuo[j.second][t3];
            if (t1 >= 0) nd += close + 1 + e1;
            if (t2 >= 0) nd += cross + 1 + e2;
            if (t3 >= 0) nd += close + 1 + e3;
            int ncomp = 0;
            if (t1 >= 0) ncomp += Comp[j.first] == Comp[t1];
            if (t2 >= 0) ncomp += Comp[j.second] == Comp[t2];
            if (t3 >= 0) ncomp += Comp[j.second] == Comp[t3];
            nd -= ncomp * 16;
            if (nd < cd) {
              if (nd - cd < bdiff || (nd - cd == bdiff && bact.t > cross)) {
                bdiff = nd - cd;
                bact = {nd - cd, 5, i1, i2, i3, j.first, j.second, cross};
              }
            }
          }
        }
      }
    }
  }

  std::sort(swaps.begin(), swaps.end(), [&](const auto& a, const auto& b){
    if (a.score != b.score) return a.score < b.score;
    if (a.type != b.type) return a.type < b.type;
    if (a.i1 != b.i1) return a.i1 < b.i1;
    if (a.i2 != b.i2) return a.i2 < b.i2;
    if (a.m1 != b.m1) return a.m1 < b.m1;
    if (a.m2 != b.m2) return a.m2 < b.m2;
    return DistDuo[bridgemen[a.i1].epos][a.m1] < DistDuo[bridgemen[b.i1].epos][b.m1];
  });

  int bid = 0;
  std::priority_queue<int, std::vector<int>, CompareInt> qq[swaps.size() + 1];
  qq[0].push(bid++);
  double etime = get_time() + 0.005;
  while (get_time() < etime && bid < 900000) {
    int sid = bid;
    for (int i = 0; i < swaps.size(); i++) {
      if (qq[i].empty()) continue;
      int id = qq[i].top();
      qq[i].pop();
      auto& b = beams[id];
      auto& s = swaps[i];
      beams[bid].score = b.score;
      beams[bid].used = b.used;
      beams[bid].parent = id;
      qq[i+1].push(bid++);
      if (b.used & (1<<s.i1)) continue;
      if (b.used & (1<<s.i2)) continue;
      if ((s.type == 5) && (b.used & (1<<s.i3))) continue;
      beams[bid].score = b.score + s.score;
      beams[bid].parent = id;
      beams[bid].used = b.used | (1<<s.i1) | (1<<s.i2);
      if (s.type == 5) beams[bid].used |= 1<<s.i3;
      qq[i+1].push(bid++);
    }
    if (sid == bid) {
      // LOG_INFO("Early stop: %d", bid);
      break;
    }
  }
  int acc = 0;
  int cid = qq[swaps.size()].top();
  std::vector<int> id_list;
  for (int i = swaps.size()-1; i >= 0; i--) {
    int used = beams[cid].used;
    cid = beams[cid].parent;
    if (beams[cid].used != used) id_list.push_back(i);
  }

  std::reverse(id_list.begin(), id_list.end());
  // for (auto s : swaps) {
  for (int cid : id_list) {
    auto&s  = swaps[cid];
    int i1 = s.i1;
    int i2 = s.i2;
    if (used[i1] || used[i2]) continue;
    int m1 = s.m1;
    int m2 = s.m2;
    // LOG_INFO("Use %d & %d at %d %d = %d", i1, i2, m1, m2, s.first);
    if (s.type == 0) {
      acc += s.score;
      if (bridgemen[i1].Position == m1 && bridgemen[i2].Position == m2 &&
          bridgemen[i1].actions.empty() && bridgemen[i2].actions.empty()) {
        Swap(i1, i2);
      } else {
        if (s.rep1) bridgemen[i1].Target = m1;
        if (s.rep2) bridgemen[i2].Target = m2;
        used[i1] = true;
        used[i2] = true;
      }
    } else if (s.type <= 2) {
      acc += s.score;
      used[i1] = true;
      used[i2] = true;
      if (bridgemen[i1].Position == m1 && bridgemen[i1].actions.empty()) {
        if (connected[turn][m1][m2] >= turn) continue;
        Connect(m1, m2, turn+2, turn, i1);
        bridgemen[i1].actions.push_back({Action::kPack, i1, m1});
        if (s.type == 2) {
          bridgemen[i1].actions.push_back({Action::kSkip, i1, m2});
          connected[turn+3][m1][m2] = turn+3;
          connected[turn+3][m2][m1] = turn+3;
          connectedId[turn+3][m1][m2] = i1;
          connectedId[turn+3][m2][m1] = i1;
        }
        bridgemen[i1].actions.push_back({Action::kMove, i1, m2});
        bridgemen[i1].actions.push_back({Action::kUnpack, i1, m2});
        // LOG_INFO("%d - Unpack from: %d to %d", turn, i1, m2);
      } else if (bridgemen[i2].Position == m2 && bridgemen[i2].actions.empty()) {
        if (connected[turn][m1][m2] >= turn) continue;
        Connect(m1, m2, turn+2, turn, i2);
        bridgemen[i2].actions.push_back({Action::kPack, i2, m2});
        if (s.type == 2) {
          bridgemen[i2].actions.push_back({Action::kSkip, i2, m1});
          connected[turn+3][m1][m2] = turn+3;
          connected[turn+3][m2][m1] = turn+3;
          connectedId[turn+3][m1][m2] = i2;
          connectedId[turn+3][m2][m1] = i2;
        }
        bridgemen[i2].actions.push_back({Action::kMove, i2, m1});
        bridgemen[i2].actions.push_back({Action::kUnpack, i2, m1});
        // LOG_INFO("%d - Unpack from: %d to %d", turn, i2, m1);
      } else {
        bridgemen[i1].Target = m1;
        bridgemen[i2].Target = m2;
      }
    } else if (s.type <= 4) {
      acc += s.score;
      used[i1] = true;
      used[i2] = true;
      if (bridgemen[i1].Position == m1 && bridgemen[i1].actions.empty()) {
        if (connected[turn][m1][m2] >= turn) continue;
        Connect(m1, m2, turn+2, turn, i1);
        bridgemen[i1].actions.push_back({Action::kPack, i1, m1});
        if (s.type == 4) {
          bridgemen[i1].actions.push_back({Action::kSkip, i1, m2});
          connected[turn+3][m1][m2] = turn+3;
          connected[turn+3][m2][m1] = turn+3;
          connectedId[turn+3][m1][m2] = i1;
          connectedId[turn+3][m2][m1] = i1;
        }
        bridgemen[i1].actions.push_back({Action::kMove, i1, m2});
        bridgemen[i1].actions.push_back({Action::kUnpack, i1, m2});
      } else if (bridgemen[i2].Position == m1 && bridgemen[i2].actions.empty()) {
        if (connected[turn][m1][m2] >= turn) continue;
        Connect(m1, m2, turn+2, turn, i2);
        bridgemen[i2].actions.push_back({Action::kPack, i2, m1});
        if (s.type == 4) {
          bridgemen[i2].actions.push_back({Action::kSkip, i2, m2});
          connected[turn+3][m1][m2] = turn+3;
          connected[turn+3][m2][m1] = turn+3;
          connectedId[turn+3][m1][m2] = i2;
          connectedId[turn+3][m2][m1] = i2;
        }
        bridgemen[i2].actions.push_back({Action::kMove, i2, m2});
        bridgemen[i2].actions.push_back({Action::kUnpack, i2, m2});
      } else {
        bridgemen[i1].Target = m1;
        bridgemen[i2].Target = m1;
      }
    } else {
      int i3 = s.i3;
      if (used[i3]) continue;
      acc += s.score;
      // LOG_INFO("Help %d with %d %d", i2, i1, i3);
      if (bridgemen[i1].Position == m1 &&  bridgemen[i2].Position == m1 && bridgemen[i3].Position == m2 &&
          bridgemen[i1].actions.empty() && bridgemen[i2].actions.empty() && bridgemen[i3].actions.empty()) {
        if (connected[turn][m1][m2] < turn) {
          bridgemen[i1].actions.push_back({Action::kPack2, i1, 0, i3, 50});
          bridgemen[i1].actions.push_back({Action::kUnpack2, i1, 0, i3, 50});
          bridgemen[i3].actions.push_back({Action::kSkip, i3, 0, i2, 50});
          bridgemen[i3].actions.push_back({Action::kSkip, i3, 0, i2, 50});
          connected[turn][m1][m2] = turn + 1;
          connected[turn+1][m1][m2] = turn + 1;
          connected[turn][m2][m1] = turn + 1;
          connected[turn+1][m2][m1] = turn + 1;

          connectedId[turn][m1][m2] = i1;
          connectedId[turn+1][m1][m2] = i1;
          connectedId[turn][m2][m1] = i1;
          connectedId[turn+1][m2][m1] = i1;
          used[i1] = true;
          used[i3] = true;
        }
        bridgemen[i2].actions.push_back({Action::kMove, i2, m2});
        used[i2] = true;
      } else {
        bridgemen[i1].Target = m1;
        bridgemen[i2].Target = m1;
        bridgemen[i3].Target = m2;
        used[i1] = true;
        used[i2] = true;
        used[i3] = true;
      }
    }
  }

  // LOG_INFO("%d vs %d (%d)", beams[qq[swaps.size()].top()].score, acc, bid);

  // Move the solo
  for (int ib = 0; ib < B; ib++) {
    auto&  b = bridgemen[ib];
    if (b.Target >= 0) {
      auto moves = BFS(b.epos, b.Target, turn + b.actions.size(), b.ID);
      if (b.actions.empty()) b.actions = moves;
      else if (moves.size()) {
        if (b.actions.size() == 1 && b.actions.back().type == Action::kPack &&
            moves.back().type == Action::kUnpack && b.actions.back().dest == moves.back().dest) {
          connected[turn+1][b.actions.back().dest][b.Position] = turn + 1;
          connected[turn+1][b.Position][b.actions.back().dest] = turn + 1;
          connectedId[turn+1][b.actions.back().dest][b.Position] = b.ID;
          connectedId[turn+1][b.Position][b.actions.back().dest] = b.ID;
          b.actions = moves;
          b.actions.pop_back();
        }
      }
    }
  }

  // Apply move
  for (int ib = 0; ib < B; ib++) {
    auto&  b = bridgemen[ib];
    if (b.actions.size() > 0) {
      actions.push_back(b.actions.back());
      b.actions.pop_back();
    }
  }
}

void Rebalancing() {
  if (C == 1) return;
  Hungarian<float, 20> hh;
  std::vector<std::pair<int, int>> comp;
  for (int c = 1; c <= C; c++) {
    LOG_INFO("Comp %d -> %d", c, CompSize[c]);
    comp.push_back({CompSize[c], c});
  }
  std::sort(comp.begin(), comp.end());
  std::vector<int> alloc;
  int sum = 0;
  for (auto& c : comp) {
    sum += c.first;
    do {
      alloc.push_back(c.second);
    } while (sum * B > alloc.size() * N);
  }
  ASSERT(alloc.size() == B, "%d vs %d", alloc.size(), B);
  ASSERT(alloc.size() == B, "%d vs %d", alloc.size(), B);
  int dd[B][C + 1];
  int fdd[B][C + 1];
  for (int b = 0; b < B; b++) {
    for (int c = 1; c <= C; c++) {
      dd[b][c] = 1000000;
    }
    for (int n = 0; n < N; n++) {
      if (dd[b][Comp[n]] > DistDuo[bridgemen[b].Position][n]) {
        dd[b][Comp[n]] = DistDuo[bridgemen[b].Position][n];
        fdd[b][Comp[n]] = n;
      }
    }
  }
  for (int b = 0; b < B; b++) {
    for (int a = 0; a < B; a++) {
      hh.H[a][b] = dd[b][alloc[a]];
    }
  }
  int cost = hh.hungarian(B, B);
  LOG_INFO("Cost: %d", cost);
  for (int b = 0; b < B; b++) {
    if (fdd[b][alloc[hh.job[b]]] != bridgemen[b].Position) {
      LOG_INFO("Move: %d -> %d", b, fdd[b][alloc[hh.job[b]]]);
    }
  }
}

int main() {
  std::cin >> N >> B >> O;

  for (int i = 0; i < N; ++i) {
    for (int j = 0; j < N; ++j) {
      std::cin >> Dist[i][j];
      // fprintf(stderr, "%d ", Dist[i][j]);
    }
    // fprintf(stderr, "\n");
  }

  for (int i = 0; i < B; ++i) {
    bridgemen[i].ID = i;
  }

  for (turn = 1; turn <= 1000; turn++) {
    ParseTurn();
    if (turn == 1) {
      ComputeComps();
      BFSSolo();
      BFSDuo();
      LOG_INFO("Expected: %lf", ExpectedScore({}, B));
      // Rebalancing();
    }

    // Finf expected position
    for (int ib = 0; ib < B; ib++) {
      auto&  b = bridgemen[ib];
      b.epos = b.Position;
      for (auto& a : b.actions) {
        if (a.type == Action::kMove) {
          b.epos = a.dest;
          break;
        }
      }
    }

    // if (C == 1) Solve1C(); else
    SolveKC();

    std::sort(actions.begin(), actions.end(), [](const auto& a, const auto& b) {
      if (a.type != b.type) return a.type < b.type;
      if (a.id != b.id) return a.id < b.id;
      return a.dest < b.dest;
    });

    std::vector<bool> skip(B, false);
    for (auto& a : actions) {
      if (a.type == Action::kPack && bridgemen[a.id].actions.empty()) {
        if (connected[turn+1][bridgemen[a.id].Position][a.dest] == turn && !skip[connectedId[turn+1][bridgemen[a.id].Position][a.dest]]) {
          // LOG_INFO("KEEP: %d %d", bridgemen[a.id].Position, a.dest);
          bridgemen[a.id].actions.push_back(a);
          connected[turn+1][bridgemen[a.id].Position][a.dest] = turn + 1;
          connected[turn+1][a.dest][bridgemen[a.id].Position] = turn + 1;
          connectedId[turn+1][bridgemen[a.id].Position][a.dest] = a.id;
          connectedId[turn+1][a.dest][bridgemen[a.id].Position] = a.id;
          skip[a.id] = true;
          continue;
        }
      }
      if (a.type == Action::kUnpack) {
        Connect(a.dest, bridgemen[a.id].Position, turn + 2, turn, a.id);
      }
      if (a.type == Action::kUnpack2) {
        // Connect(bridgemen[a.id2].Position, bridgemen[a.id].Position, turn + 2, turn);
      }
      a.print();
    }
    printf("MSG All good!\n");
    // fprintf(stderr, "MSG All good!\n");
  }

  return 0;
}

// For each component assign a builder whose priority is to create pathway?
// Rebalancing on components
// SA to assign static edges (FAILED)
// Open highway between components?
// Works as a duo
// Use hungarian assignment (DONE)