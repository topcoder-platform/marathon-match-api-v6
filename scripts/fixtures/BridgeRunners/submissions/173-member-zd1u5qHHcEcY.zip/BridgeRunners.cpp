// START FILE shared/Pragmas.h
#ifndef DONT_PRAGMAS
#pragma GCC optimize("Ofast,inline,unroll-loops,tracer")
#pragma GCC target("tune=native")
#endif
#pragma GCC target("avx2,fma,bmi,bmi2,popcnt,lzcnt")
// END FILE shared/Pragmas.h

// START FILE shared/Macros.h
#ifndef DEBUG
#define INLINE __attribute__((always_inline)) inline
#else
#define INLINE inline
#endif
// END FILE shared/Macros.h

// START FILE shared/Types.h
#include <cstdint>
#include <ostream>

typedef uint64_t u64;
typedef uint32_t u32;
typedef uint16_t u16;
typedef uint8_t u8;

typedef int64_t i64;
typedef int32_t i32;
typedef int16_t i16;
typedef int8_t i8;

typedef double f64;
typedef float f32;

template<typename T>
struct Point {
    T x, y;

    Point() = default;

    constexpr Point(const T& x, const T& y): x(x), y(y) {
    }


    template<typename U>
    friend std::ostream& operator<<(std::ostream& os, const Point<U>& point);

    constexpr Point operator-(const Point& other) const {
        return Point(x - other.x, y - other.y);
    }

    constexpr Point operator+(const Point& other) const {
        return Point(x + other.x, y + other.y);
    }

    constexpr Point operator*(const T& scale) const {
        return Point(x * scale, y * scale);
    }

    constexpr Point operator/(const T& scale) const {
        return Point(x / scale, y / scale);
    }

    constexpr bool operator==(const Point& other) const {
        return x == other.x && y == other.y;
    }

    constexpr bool operator!=(const Point& other) const {
        return x != other.x || y != other.y;
    }
};

template<typename T>
std::ostream& operator<<(std::ostream& os, const Point<T>& point) {
    os << '(' << point.x << ", " << point.y << ')';
    return os;
}
// END FILE shared/Types.h

// START FILE Config.h
#include <algorithm>
#include <iostream>
#include <string>
#include <sstream>


using namespace std;

#define CONFIG_PARAMETERS \
    PARAM(float, em_score, 3400.0, 3445.4636560100002, 3600.0) \
    PARAM(float, em_bigbridge, 7.6, 8.348514754348344, 9.4) \
    PARAM(float, em_path, 2.3, 2.3017301118646567, 3.3) \
    PARAM(float, em_buildable, 3.2, 4.049438383200796, 4.4) \
    PARAM(float, em_built, 0.8, 0.8170496089929042, 1.8) \
    PARAM(float, em_carry, 0.9, 1.304799082603016, 1.4) \
    PARAM(float, e_pickup, 900.0, 968.3752277668659, 1250.0) \
    PARAM(float, e_deliver, 900.0, 923.5373272056039, 1100.0) \
    PARAM(float, ip_gt50mst, 2.2, 2.5733514812507017, 2.8) \
    PARAM(float, ip_gt50, 10.0, 14.894553242860614, 18.0) \
    PARAM(float, rm_overtake, 0.2, 0.4012657350786424, 1.0) \
    PARAM(float, rm_pickup, 0.25, 0.58526938296739, 2.0) \
    PARAM(float, hm_pickup, 7.0, 9.05393744737413, 12.5) \
    PARAM(float, hp_toolong, 70, 87.58296608957596, 140) \
    PARAM(i64, step, 1, 1, 1) \
    PARAM(float, global_beam_keep_a, -6.0, -2.4235150388046156, -2.0) \
    PARAM(float, global_beam_keep_b, 200, 360.33913633103225, 450) \
    PARAM(i64, respect_o, 100, 155, 1600) \
    PARAM(i64, i_help, 0, 1, 1) \
    PARAM(i64, b_exchange, 0, 1, 1) \

#define PARAM(type, name, minVal, defaultValue, maxVal) \
    inline static type name;

class Config {
public:
    CONFIG_PARAMETERS

private:
    INLINE static float read_float(const string& name, const float defaultValue) {
        const char* envVar = getenv(name.c_str());
        if (envVar == nullptr) return defaultValue;
        return atof(envVar);
    }

    INLINE static i64 read_i64(const string& name, const i64 defaultValue) {
        const char* envVar = getenv(name.c_str());
        if (envVar == nullptr) return defaultValue;
        return atoll(envVar);
    }

public:
#undef PARAM
#define PARAM(type, name, minVal, defaultValue, maxVal) \
    name = read_##type(#name, defaultValue);

    INLINE static bool isTruthy(const char* envVar) {
        if (envVar == nullptr) {
            return false;
        }
        string value(envVar);
        transform(value.begin(), value.end(), value.begin(),
            [](const unsigned char c) { return tolower(c); });
        return value == "t" || value == "true" || value == "on" || value == "1";
    }

    INLINE static void init() {
        CONFIG_PARAMETERS
        if (isTruthy(getenv("SHOW_PARAMS"))) {
            cout << toJSON() << endl;
            exit(0);
        }
    }

#undef PARAM
#define PARAM(type, name, minVal, defaultValue, maxVal) \
    if (isFirstParam) { isFirstParam = false; } else { ss << ","; } \
    ss << "{"; \
    ss << "\"name\": \"" << #name << "\","; \
    ss << "\"type\": \"" << #type << "\","; \
    ss << "\"value\": " << name << ","; \
    ss << "\"defaultValue\": " << to_string(defaultValue) << ","; \
    ss << "\"min\": " << to_string(minVal) << ","; \
    ss << "\"max\": " << to_string(maxVal); \
    ss << "}";

    INLINE static string toJSON() {
        stringstream ss;
        ss << "[";
        bool isFirstParam = true;
        CONFIG_PARAMETERS
        ss << "]";
        return ss.str();
    }
};

#undef PARAM
#undef CONFIG_PARAMETERS
// END FILE Config.h

// START FILE shared/Time.h
extern "C" {
extern int gettimeofday(timeval*, void*);
}

inline u64 getTime() {
    timeval t;
    gettimeofday(&t, nullptr);
    return t.tv_sec * 1000000UL + t.tv_usec;
}

struct StopWatch {
    inline static u64 lastMeasurement = 0;

    static void init() {
#ifdef MEASURE_TIME
        lastMeasurement = getTime();
#endif
    }

    static u64 measure() {
#ifdef MEASURE_TIME
        const u64 now = getTime();
        const u64 interval = now - lastMeasurement;
        lastMeasurement = now;
        return interval;
#else
        return 0;
#endif
    }
};
// END FILE shared/Time.h

// START FILE Constants.h
using namespace std;

constexpr u64 MAX_TURN = 1000;

constexpr u64 MAX_N = 80;
constexpr u64 MAX_B = 20;
constexpr u64 MAX_O = 10;

constexpr u64 MAX_CARRY = 60;

constexpr u8 NO_MSG = 80;
static_assert(NO_MSG >= MAX_N);
// END FILE Constants.h

// START FILE shared/Vector.h
#include <initializer_list>
#include <random>
#include <stdexcept>
#include <iostream>

template<typename T, size_t N>
class Vector {
    size_t _size;
    T      _data[N];

public:
    Vector() : _size(0) {
    }

    Vector(std::initializer_list<T> list) : _size(0) {
#if DEBUG
        if (list.size() > N) throw std::runtime_error("initializer list too big");
#endif
        for (const T& value : list) {
            push_back(value);
        }
    }

    void push_back(const T& value) {
#if DEBUG
        if (full()) throw std::runtime_error("Vector is full");
#endif
        _data[_size++] = value;
    }

    void pop_back() {
#if DEBUG
        if (empty()) throw std::runtime_error("Vector is empty");
#endif
        --_size;
    }

    T popBackAndGet() {
#if DEBUG
        if (empty()) throw std::runtime_error("Vector is empty");
#endif
        return _data[--_size];
    }

    void removeAndReplaceWithLast(const size_t index) {
#if DEBUG
        if (index < 0 || size() <= index) throw std::runtime_error("index is outside range");
#endif
        _data[index] = back();
        pop_back();
    }

    T& front() {
#if DEBUG
        if (empty()) throw std::runtime_error("Vector is empty");
#endif
        return _data[0];
    }

    const T& front() const {
#if DEBUG
        if (empty()) throw std::runtime_error("Vector is empty");
#endif
        return _data[0];
    }

    T& back() {
#if DEBUG
        if (empty()) throw std::runtime_error("Vector is empty");
#endif
        return _data[_size - 1];
    }

    const T& back() const {
#if DEBUG
        if (empty()) throw std::runtime_error("Vector is empty");
#endif
        return _data[_size - 1];
    }

    T& operator[](const size_t index) {
#if DEBUG
        if (index < 0 || size() <= index) throw std::runtime_error("index is outside range");
#endif
        return _data[index];
    }

    const T& operator[](const size_t index) const {
#if DEBUG
        if (index < 0 || size() <= index) throw std::runtime_error("index is outside range");
#endif
        return _data[index];
    }

    [[nodiscard]] size_t size() const {
        return _size;
    }

    template<typename S>
    void setSize(const S size) {
#if DEBUG
        if (size < 0 || static_cast<S>(N) < size) throw std::runtime_error("size is outside range");
#endif
        _size = size;
    }

    void clear() {
        setSize(0);
    }

    [[nodiscard]] size_t capacity() const {
        return N;
    }

    [[nodiscard]] bool empty() const {
        return _size == 0;
    }

    [[nodiscard]] bool full() const {
        return _size == capacity();
    }

    const T& random(std::mt19937& rnd) const {
#if DEBUG
        if (empty()) throw std::runtime_error("Vector is empty");
#endif
        const size_t index = rnd() % size();
        return _data[index];
    }

    friend std::ostream& operator<<(std::ostream& out, const Vector& vector) {
        out << "[ ";
        for (auto v : vector) {
            out << v << " ";
        }
        out << ']';
        return out;
    }

    T* begin() {
        return _data;
    }

    T* end() {
        return _data + _size;
    }

    const T* begin() const {
        return _data;
    }

    const T* end() const {
        return _data + _size;
    }
};
// END FILE shared/Vector.h

// START FILE game/GameState.h
#include <array>
#include <queue>
#include <bitset>
#include <cassert>
#include <debug/unordered_set>


using namespace std;

struct Action {
    enum Type: u8 {
        END_MOVE   = 0b0000'0000,
        MOVE       = 0b0010'0000,
        UNPACK     = 0b0100'0000,
        PACK       = 0b0110'0000,
        TEAM_UNPAC = 0b1000'0000,
        TEAM_PACK  = 0b1010'0000,
        TRANSFER   = 0b1100'0000,
        MASK       = 0b1110'0000,
    };

    u8 val1;
    u8 val2;
    u8 val3;

    Action() = default;

    Action(const u8 val1, const u8 val2, const u8 val3)
        : val1(val1), val2(val2), val3(val3) {
    }

    static Action move(const u8 manId, const u8 islandId) {
        return Action(manId | MOVE, islandId, 0);
    }

    static Action unpack(const u8 manId, const u8 islandId) {
        return Action(manId | UNPACK, islandId, 0);
    }

    static Action pack(const u8 manId, const u8 islandId) {
        return Action(manId | PACK, islandId, 0);
    }

    static Action teamUnPack(const u8 manId1, const u8 manId2, const u8 length) {
        return Action(manId1 | TEAM_UNPAC, manId2, length);
    }

    static Action teamPack(const u8 manId1, const u8 manId2, const u8 length) {
        return Action(manId1 | TEAM_PACK, manId2, length);
    }

    static Action transfer(const u8 manId1, const u8 manId2, const u8 length) {
        return Action(manId1 | TRANSFER, manId2, length);
    }

    static Action EndMove() {
        return Action(END_MOVE, 0, 0);
    }

    INLINE u8 type() const {
        return val1 & MASK;
    }

    INLINE u8 manId() const {
        return val1 & ~MASK;
    }

    bool isTransferMove() const {
        return type() == TRANSFER;
    }

    bool isEndMove() const {
        return val1 == 0;
    }

    friend ostream& operator<<(ostream& out, const Action& action) {
        const u8 type = action.type();
        const u64 manId = action.manId();
        const u64 v2 = action.val2;
        const u64 v3 = action.val3;
        if (type == MOVE) out << "MOVE " << manId << ' ' << v2;
        if (type == UNPACK) out << "UNPACK " << manId << ' ' << v2;
        if (type == PACK) out << "PACK " << manId << ' ' << v2;
        if (type == TEAM_UNPAC) out << "TEAMUNPACK " << manId << ' ' << (v2 & 127) << ' ' << v3;
        if (type == TEAM_PACK) out << "TEAMPACK " << manId << ' ' << v2 << ' ' << v3;
        if (type == END_MOVE) out << "MSG .\n";
        else out << " | ";
        return out;
    }
};


struct Move {
    Vector<Action, MAX_B + 1> actions;
};

struct Edge {
    u8 target;
    u8 tIndex;
    u16 dist;
};

class GameState {
public:
    typedef float EvalType;
    typedef u32 MoveIdType;


    inline static i64 N, B, O;

    inline static array<Vector<Edge, 8>, MAX_N> edges;
    inline static array<array<u16, MAX_N>, MAX_N> trueEdge;
    inline static array<array<u16, MAX_N>, MAX_N> allDists;
    inline static array<array<u16, MAX_N>, MAX_N> maxEdgeOnPath;
#if DEBUG
    inline static array<Point<u16>, MAX_N> islandPos;
#endif

    inline static array<array<u32, MAX_N>, MAX_B> zobPos;
    inline static array<array<u32, MAX_CARRY + 1>, MAX_B> zobCarry;
    inline static array<array<u32, 256>, MAX_B> zobTarget;
    inline static array<array<u32, MAX_N>, MAX_N> zobBridge;
    inline static array<u32, MAX_B> zobAlreadyMoved;
    inline static u32 zobAllAlreadyMoved = 0;
    inline static array<u32, 256> zobScore;
    inline static array<pair<u8, u8>, MAX_O> orders;
    inline static array<u8, MAX_B> firstPickup;
    inline static array<u8, MAX_N> connectedComponent;
    inline static array<u8, MAX_N> connectedComponentSize;
    inline static bool respect_o = true;
    inline static u8 exchangeLimit = 60;

    MoveIdType moveId;

    struct BigBridge {
        u8 from, to, carry;

        BigBridge() {
            from = NO_MSG;
            to = NO_MSG;
            carry = 0;
        }

        BigBridge(const u8 from, const u8 to, const u8 carry)
            : from(from),
              to(to),
              carry(carry) {
        }
    };

    array<u8, MAX_B> pos;
    array<u8, MAX_B> carry;
    array<u8, MAX_B> carryAndBridges;
    array<u8, MAX_B> targets;
    array<u8, MAX_N> bridges;
    array<u8, MAX_B> maskBridges;
    array<u8, MAX_B> maskInvBridges;
    array<BigBridge, MAX_B> bigBridges;
    u16 inactiveOrders = 0;

    u32 alreadyMoved = 0;
    u32 futureMoved = 0;
    u16 score = 0;
    u32 hash = 0;
    u8 turn = 0;


public:
    INLINE static void initializeZobristHashes() {
        mt19937 rng(1);
        for (auto& arr : zobPos) initalizeZobristArray(arr, rng);
        for (auto& arr : zobCarry) initalizeZobristArray(arr, rng);
        for (auto& arr : zobTarget) initalizeZobristArray(arr, rng);
        initalizeZobristArray(zobAlreadyMoved, rng);
        initalizeZobristArray(zobScore, rng);

        for (u64 i = 0; i < MAX_N; ++i) {
            for (u64 j = i; j < MAX_N; ++j) {
                zobBridge[i][j] = zobBridge[j][i] = rng();
            }
        }
    }

    INLINE static void initializeDists(const u16 maxOneLength = 50, u16 maxTeamLength = 100, Vector<pair<u8, u8>, MAX_N> sg = {},
                                       u64 mstMaxLength = 3000) {
        unordered_set<u16> sgs;
        for (auto [v,w] : sg) {
            sgs.insert((static_cast<u16>(v) << 8) + static_cast<u16>(w));
            sgs.insert((static_cast<u16>(w) << 8) + static_cast<u16>(v));
        }
        for (u64 i = 0; i < N; ++i) {
            for (u64 j = 0; j < N; ++j) {
                allDists[i][j] = UINT16_MAX;
            }
            priority_queue<pair<float, u8>, vector<pair<float, u8>>, greater<>> Q;
            Q.push({0, i});
            allDists[i][i] = 0;
            while (!Q.empty()) {
                const auto [d, v] = Q.top();
                Q.pop();
                for (u64 e = 0; e < edges[v].size(); ++e) {
                    u64 w = edges[v][e].target;
                    float nDist = edges[v][e].dist;
                    if (nDist > maxTeamLength) continue;
                    if (nDist > maxOneLength) {
                        if (nDist <= mstMaxLength) {
                            nDist *= Config::ip_gt50mst;
                        } else {
                            nDist *= Config::ip_gt50;
                        }
                    }

                    nDist += d;
                    if (allDists[i][w] > nDist) {
                        allDists[i][w] = nDist;
                        Q.push({nDist, w});
                    }
                }
            }
        }

        for (u64 i = 0; i < N; ++i) {
            for (u64 j = 0; j < N; ++j) {
                maxEdgeOnPath[i][j] = UINT16_MAX;
            }
            priority_queue<pair<u16, u8>, vector<pair<u16, u8>>, greater<>> Q;
            Q.push({0, i});
            maxEdgeOnPath[i][i] = 0;
            while (!Q.empty()) {
                const auto [d, v] = Q.top();
                Q.pop();
                for (u64 e = 0; e < edges[v].size(); ++e) {
                    u64 w = edges[v][e].target;
                    float nDist = max(d, edges[v][e].dist);
                    if (maxEdgeOnPath[i][w] > nDist) {
                        maxEdgeOnPath[i][w] = nDist;
                        Q.push({nDist, w});
                    }
                }
            }
        }
    }

private:
    template<u64 ZobristArraySize>
    INLINE static void initalizeZobristArray(array<u32, ZobristArraySize>& arr, mt19937& rng) {
        for (auto& value : arr) {
            value = rng();
        }
    }

public:
    INLINE void changePos(const u32 b, const u64 v, const u64 w) {
        alreadyMoved |= (1U << b);
        hash ^= zobPos[b][v];
        pos[b] = w;
        hash ^= zobPos[b][w];
#if DEBUG
        if (respect_o) {
            assert(__builtin_popcount(maskBridges[b]) == __builtin_popcount(maskInvBridges[b]));
        }
#endif
        swap(maskBridges[b], maskInvBridges[b]);
        swap(bigBridges[b].from, bigBridges[b].to);
    }

    INLINE Action startTransferAction(const Action& action) {
        const u64 b = action.manId();
        const u64 b2 = action.val2;
        const u64 v = pos[b];
        const u64 w = pos[b2];
        const u64 bWants = action.val3;

        alreadyMoved |= (1U << b) | (1U << b2);
        for (u64 e = 0; e < edges[v].size(); ++e) {
            const u64 target = edges[v][e].target;
            if (w == target) {
                const auto wIndex = edges[v][e].tIndex;
                const auto vwDist = edges[v][e].dist;
                const u64 vwBridgeMask = 1UL << e;
                const u64 wvBridgeMask = 1UL << wIndex;
                futureMoved |= (1U << b) | (1U << b2);
                if (bridges[v] & vwBridgeMask) {
                    const u64 bChange = min<u64>(vwDist, 60 - carry[b]);
                    const u64 b2Change = vwDist - bChange;
                    carryAndBridges[b] += bChange;
                    carryAndBridges[b2] += b2Change;
                    doTeamPack(b, b2, v, w, vwBridgeMask, wvBridgeMask, bChange, b2Change, true);
                    return Action::teamPack(b, b2, bChange);
                } else {
                    const u64 b2Change = min<u64>(vwDist, carry[b2]);
                    const u64 bChange = vwDist - b2Change;
                    carryAndBridges[b] -= bChange;
                    carryAndBridges[b2] -= b2Change;
                    doTeamUnpack(b, b2, v, w, vwBridgeMask, wvBridgeMask, bChange, b2Change, true);

                    return Action::teamUnPack(b, b2, bChange);
                }
            }
        }
        throw runtime_error("not implemented");
    }

    INLINE Action endTransferAction(const Action& action) {
        const u64 b = action.manId();
        const u64 b2 = action.val2;
        const u64 v = pos[b];
        const u64 w = pos[b2];
        const u64 bWants = action.val3;

        for (u64 e = 0; e < edges[v].size(); ++e) {
            const u64 target = edges[v][e].target;
            if (w == target) {
                const auto wIndex = edges[v][e].tIndex;
                const auto vwDist = edges[v][e].dist;
                const u64 vwBridgeMask = 1UL << e;
                const u64 wvBridgeMask = 1UL << wIndex;
                if (bridges[v] & vwBridgeMask) {
                    const u64 bChange = bWants - carry[b];
                    const u64 b2Change = vwDist - bChange;
                    carryAndBridges[b] += bChange;
                    carryAndBridges[b2] += b2Change;
                    doTeamPack(b, b2, v, w, vwBridgeMask, wvBridgeMask, bChange, b2Change, true);
                    return Action::teamPack(b, b2, bChange);
                } else {
                    const u64 bChange = carry[b] - bWants;
                    const u64 b2Change = vwDist - bChange;
                    carryAndBridges[b] -= bChange;
                    carryAndBridges[b2] -= b2Change;
                    doTeamUnpack(b, b2, v, w, vwBridgeMask, wvBridgeMask, bChange, b2Change, true);
                    return Action::teamUnPack(b, b2, bChange);
                }
            }
        }
        throw runtime_error("not implemented");
    }

    INLINE void lightApplyAction(const Action& action) {
        const u8 type = action.val1 & Action::MASK;
        const u64 manId = action.manId();
        const u64 v = pos[manId];
        const u64 v2 = action.val2;
        const u64 v3 = action.val3;

        if (type == Action::MOVE) {
            changePos(manId, v, v2);
            return;
        }
        if (type == Action::UNPACK) {
            const u64 target = v2;
            for (u64 e = 0; e < edges[v].size(); ++e) {
                const u64 w = edges[v][e].target;
                if (w == target) {
                    const auto wIndex = edges[v][e].tIndex;
                    const auto vwDist = edges[v][e].dist;
                    const u64 vwBridgeMask = 1UL << e;
                    const u64 wvBridgeMask = 1UL << wIndex;
                    doUnpack(manId, v, w, vwBridgeMask, wvBridgeMask, vwDist);
                    return;
                }
            }
        }
        if (type == Action::PACK) {
            const u64 target = v2;
            for (u64 e = 0; e < edges[v].size(); ++e) {
                const u64 w = edges[v][e].target;
                if (w == v2) {
                    const auto wIndex = edges[v][e].tIndex;
                    const auto vwDist = edges[v][e].dist;
                    const u64 vwBridgeMask = 1UL << e;
                    const u64 wvBridgeMask = 1UL << wIndex;
                    doPack(manId, v, w, vwBridgeMask, wvBridgeMask, vwDist);
                    return;
                }
            }
        }
        if (type == Action::TEAM_UNPAC) {
            const u64 target = pos[v2 & 127];
            for (u64 e = 0; e < edges[v].size(); ++e) {
                const u64 w = edges[v][e].target;
                const u64 vwDist = edges[v][e].dist;
                if (w == target) {
                    const auto wIndex = edges[v][e].tIndex;
                    const auto vwDist = edges[v][e].dist;
                    const u64 vwBridgeMask = 1UL << e;
                    const u64 wvBridgeMask = 1UL << wIndex;
                    doTeamUnpack(manId, v2 & 127, v, w, vwBridgeMask, wvBridgeMask, v3, vwDist - v3);
                    if ((v2 & 128) != 0) {
                        bigBridges[manId] = BigBridge();
                        bigBridges[v2 & 127] = BigBridge();
                        carryAndBridges[manId] += vwDist - v3;
                        carryAndBridges[v2 & 127] -= vwDist - v3;
                        abandonBridge(v2 & 127, wvBridgeMask, vwBridgeMask);
                    }
                    return;
                }
            }
        }
        if (type == Action::TEAM_PACK) {
            const u64 target = pos[v2];
            for (u64 e = 0; e < edges[v].size(); ++e) {
                const u64 w = edges[v][e].target;
                if (w == target) {
                    const auto wIndex = edges[v][e].tIndex;
                    const auto vwDist = edges[v][e].dist;
                    const u64 vwBridgeMask = 1UL << e;
                    const u64 wvBridgeMask = 1UL << wIndex;
                    doTeamPack(manId, v2, v, w, vwBridgeMask, wvBridgeMask, v3, vwDist - v3);
                    return;
                }
            }
        }
        if (type == Action::END_MOVE) {
        }
    }

    INLINE void controlBridge(const u64 b, const u64 vBridgeMask, const u64 wBridgeMask) {
        if (respect_o) {
            maskBridges[b] |= vBridgeMask;
            maskInvBridges[b] ^= wBridgeMask;
        }
    }

    INLINE void abandonBridge(const u64 b, const u64 vBridgeMask, const u64 wBridgeMask) {
        if (respect_o) {
            maskBridges[b] &= ~vBridgeMask;
            maskInvBridges[b] ^= wBridgeMask;
        }
    }

    INLINE void addBridge(const u64 v, const u64 w, const u64 vBridgeMask, const u64 wBridgeMask) {
        bridges[v] |= vBridgeMask;
        bridges[w] |= wBridgeMask;
        hash ^= zobBridge[v][w];
    }


    INLINE void removeBridge(const u64 v, const u64 w, const u64 vBridgeMask, const u64 wBridgeMask) {
        bridges[v] &= ~vBridgeMask;
        bridges[w] &= ~wBridgeMask;
        hash ^= zobBridge[v][w];
    }

    INLINE void changeCarry(const u64 b, const i8 dValue) {
        hash ^= zobCarry[b][carry[b]];
        carry[b] += dValue;
        hash ^= zobCarry[b][carry[b]];
    }

    INLINE void setAlreadyMoved(const u32 b) {
        alreadyMoved |= 1 << b;
    }

    INLINE void setFutureMoved(const u32 b) {
        futureMoved |= 1 << b;
    }

    INLINE void changeTarget(const u64 b, u8 target) {
        hash ^= zobTarget[b][targets[b]];
        targets[b] = target;
        hash ^= zobTarget[b][targets[b]];
    }

    INLINE void handleOrdersFor(const u32 b) {
        const u64 fo = firstPickup[b];
        if (targets[b] >= 128 && inactiveOrders & (1 << fo) && orders[fo].first == (targets[b] & 127)) {
            changeTarget(b, NO_MSG);
            return;
        }
        if (targets[b] != NO_MSG) {
            if ((targets[b] & 127) == pos[b]) {
                hash ^= zobScore[score % zobScore.size()];
                score += 8 - turn;
                hash ^= zobScore[score % zobScore.size()];
                if (fo == NO_MSG) {
                    changeTarget(b, NO_MSG);
                } else {
                    changeTarget(b, orders[fo].second);
                    inactiveOrders |= (1 << fo);
                }
            }
            return;
        }
        for (u64 o = 0; o < O; ++o) {
            if (inactiveOrders & (1 << o)) continue;
            if (pos[b] == orders[o].first) {
                changeTarget(b, orders[o].second);
                inactiveOrders |= (1 << o);
                return;
            }
        }
    }

    INLINE void doTransfer(const u64 b, const u64 b2, const u64 bCorrection) {
        alreadyMoved |= (1U << b) | (1U << b2);
        futureMoved |= (1U << b) | (1U << b2);
        carryAndBridges[b] += bCorrection;
        carryAndBridges[b2] -= bCorrection;
        changeCarry(b, bCorrection);
        changeCarry(b2, -bCorrection);
    }

    INLINE void doPack(const u64 b, const u64 v, const u64 w, const u64 vwBridgeMask, const u64 wvBridgeMask, const u8 vwDist) {
        removeBridge(v, w, vwBridgeMask, wvBridgeMask);
        abandonBridge(b, vwBridgeMask, wvBridgeMask);
        changeCarry(b, vwDist);
    }

    INLINE void doTeamPack(const u64 b, const u64 b2, const u64 v, const u64 w, const u64 vwBridgeMask, const u64 wvBridgeMask,
                           const u8 bChange, const u8 b2Change, const bool noPermaBridges = false) {
        removeBridge(v, w, vwBridgeMask, wvBridgeMask);
        if (true || noPermaBridges) {
            abandonBridge(b, vwBridgeMask, wvBridgeMask);
            abandonBridge(b2, wvBridgeMask, vwBridgeMask);
        }
        bigBridges[b] = BigBridge();
        bigBridges[b2] = BigBridge();
        changeCarry(b, bChange);
        changeCarry(b2, b2Change);
    }

    INLINE void doUnpack(const u64 b, const u64 v, const u64 w, const u64 vwBridgeMask, const u64 wvBridgeMask, const u8 vwDist) {
        addBridge(v, w, vwBridgeMask, wvBridgeMask);
        if (true) {
            controlBridge(b, vwBridgeMask, wvBridgeMask);
        } else {
            carryAndBridges[b] -= vwDist;
        }
        changeCarry(b, -vwDist);
    }

    INLINE void doTeamUnpack(const u64 b, const u64 b2, const u64 v, const u64 w, const u64 vwBridgeMask, const u64 wvBridgeMask,
                             const u8 bChange, const u8 b2Change, const bool noPermaBridges = false) {
        addBridge(v, w, vwBridgeMask, wvBridgeMask);
        const auto storedChange = b < b2 ? bChange : b2Change;
        if (true || noPermaBridges) {
            controlBridge(b, vwBridgeMask, wvBridgeMask);
            controlBridge(b2, wvBridgeMask, vwBridgeMask);
            bigBridges[b] = BigBridge(v, w, storedChange);
            bigBridges[b2] = BigBridge(w, v, storedChange);
        } else {
            carryAndBridges[b] -= bChange;
            carryAndBridges[b2] -= b2Change;
        }
        changeCarry(b, -bChange);
        changeCarry(b2, -b2Change);
    }

    INLINE void finalize() {
        alreadyMoved = futureMoved;
        ++turn;
        futureMoved = 0;
    }

    INLINE u32 calcHash() const {
        u32 h = 0;
        for (u64 b = 0; b < B; ++b) {

            const u64 v = pos[b];
            h ^= zobPos[b][v];
            h ^= zobCarry[b][carry[b]];
            h ^= zobTarget[b][targets[b]];

#ifdef DEBUG
            assert(bridges[v] != 0 || (carry[b] == carryAndBridges[b]));
            assert(carryAndBridges[b] <= 60);
            assert(carry[b] <= 60);
#endif
        }

        for (u64 v = 0; v < MAX_N; ++v) {
            for (u64 e = 0; e < edges[v].size(); ++e) {
                const u64 target = edges[v][e].target;
                const u64 tIndex = edges[v][e].tIndex;
                const u8 dist = edges[v][e].dist;
                if (target < v) continue;
                if ((bridges[v] & (1UL << e)) == 0) continue;
                h ^= zobBridge[v][target];
            }
        }

        h ^= zobScore[score % zobScore.size()];
        return h;
    }


    [[nodiscard]] EvalType calcEval() const {
        EvalType eval = score * Config::em_score;
        u32 carrySum = 0;
        array<float, MAX_O> orderDist;
        fill(orderDist.begin(), orderDist.end(), 4096);

        for (u64 b = 0; b < B; ++b) {
            const u64 v = pos[b];
            carrySum += carry[b];


            float targetDist;
            if (targets[b] != NO_MSG) {
                targetDist = Config::em_path * allDists[v][targets[b] & 127];
            }

            for (u64 e = 0; e < edges[v].size(); ++e) {
                const u64 w = edges[v][e].target;
                const u16 dist = edges[v][e].dist;
                float mult = Config::em_built;
                if ((bridges[v] & (1UL << e)) == 0) {
                    if (dist <= carry[b]) {
                        mult = Config::em_buildable;
                    } else {
                        continue;
                    }
                }
                if (bigBridges[b].from == v) {
                    mult = Config::em_bigbridge;
                }
                if (targets[b] != NO_MSG) {
                    targetDist = min(targetDist, mult * dist + Config::em_path * allDists[w][targets[b] & 127]);
                }
            }
            if (targets[b] != NO_MSG) {
                eval += (targets[b] < 128 ? Config::e_deliver : Config::e_pickup) - targetDist;
            }
        }
        eval += Config::em_carry * static_cast<float>(carrySum);
        return eval;
    }
};
// END FILE game/GameState.h

// START FILE agent/Agent.h
#include <cstdint>
#include <memory>




class Reader;
using namespace std;

class Agent {
    inline static u64 timeLeftCheckCounter = 0;

public:
    inline static bool _timeout = false;
    inline static uint64_t startTime = 0;
    inline static uint64_t maxRoundTime = 46000;
    inline static i32 turn = 0;

    array<u64, 8> turnEndTimes;
    u64 skip = 0;

    GameState gameState{};


    Reader& reader;
    ostream& output;
    ostream& error;

    Agent(Reader& reader, ostream& output, ostream& error) : reader(reader), output(output), error(error) {
    }


    static bool hasTimeLeft() {
#if DEBUG
        return true;
#else
        if (_timeout) return false;
        if (startTime + maxRoundTime < getTime()) {
            _timeout = true;
            return false;
        }
        return true;
#endif

    }

    void readInitialInput();
    void readTurnInput();
    void calculateOutput();
};
// END FILE agent/Agent.h

// START FILE shared/Bag.h
#include <limits>


template<typename T, size_t Size, typename IdType>
class Bag {
    static_assert(Size > 0 && Size - 1 <= std::numeric_limits<IdType>::max());
    T data[Size];
public: 
    Vector<IdType, Size> ids;

public:
    constexpr Bag() {
        for (IdType id = 0; ; ++id) {
            ids.push_back(id);
            if (id == Size - 1) break;
        }
    }

    constexpr T& operator[](const size_t id) {
#if DEBUG
        if (Size <= id) throw std::runtime_error("id is outside range");
#endif
        return data[id];
    }

    constexpr const T& operator[](const size_t id) const {
#if DEBUG
        if (Size <= id) throw std::runtime_error("id is outside range");
#endif
        return data[id];
    }

    constexpr T& addGetRef(const T& value) {
        IdType id = ids.pop_back();
        data[id] = value;
        return data[id];
    }

    constexpr IdType addGetId(const T& value) {
        IdType id = ids.popBackAndGet();
        data[id] = value;
        return id;
    }

    constexpr pair<IdType, T&> addGetIdAndRef(const T& value) {
        IdType id = ids.popBackAndGet();
        data[id] = value;
        return {id, data[id]};
    }

    void remove(const size_t id) {
        ids.push_back(id);
    }
};
// END FILE shared/Bag.h

// START FILE shared/Beam2.h
template<typename T, size_t Size>
class Beam2 {
    Vector<T, Size> beams[2];
    size_t currentBeamIndex = 0, nextBeamIndex = 1;

public:
    constexpr Vector<T, Size>& current() {
        return beams[currentBeamIndex];
    }

    constexpr Vector<T, Size>& current() const {
        return beams[currentBeamIndex];
    }

    constexpr Vector<T, Size>& next() {
        return beams[nextBeamIndex];
    }

    constexpr Vector<T, Size>& next() const {
        return beams[nextBeamIndex];
    }

    void swap() {
        currentBeamIndex = 1 - currentBeamIndex;
        nextBeamIndex = 1 - nextBeamIndex;
    }
};
// END FILE shared/Beam2.h

// START FILE shared/MoveTree.h
#include <cassert>

using namespace std;

template<typename T, size_t Capacity, typename IdType, typename ChildrenCounterType>
class MoveTree {
    struct Node {
        T value;
        IdType parentId;
        ChildrenCounterType children;
    };

    static_assert(Capacity > 0 && Capacity - 1 <= std::numeric_limits<IdType>::max());
    Node data[Capacity];
    Vector<IdType, Capacity> ids;

public:
    MoveTree() {
        data[0].children = 3;
        for (IdType id = Capacity - 1; id > 0; --id) {
            ids.push_back(id);
        }
    }

    [[nodiscard]] size_t size() const {
        return Capacity - ids.size();
    }

    T move(const IdType id) const {
        return data[id].value;
    }

    IdType parentId(const IdType id) const {
        return data[id].parentId;
    }

    IdType addAndFreeParent(const T value, const IdType parentId) {
        IdType id = add(value, parentId);
        free(parentId);
        return id;
    }

    IdType add(const T value, const IdType parentId) {
        const IdType id = ids.popBackAndGet();
        data[id] = Node{value, parentId, 1};
        ++data[parentId].children;
        return id;
    }

    void free(const IdType id) {
        // assert(data[id].children > 0);
        --data[id].children;

        IdType idIt = id;
        while (data[idIt].children == 0) {
            ids.push_back(idIt);


            idIt = data[idIt].parentId;
            // assert(data[idIt].children > 0);
            --data[idIt].children;
        }
    }

    void add1(const IdType id) {
        // assert(data[id].children > 0);
        ++data[id].children;
    }
};
// END FILE shared/MoveTree.h

// START FILE game/BeamSearch.h
#include <algorithm>
#include <unordered_set>



typedef u16 IdType;

struct BeamElement {
    IdType gameStateId;
    GameState::EvalType eval;

    bool operator>(const BeamElement& other) const {
        return eval > other.eval;
    }
};

class BeamSearch {
    inline static Bag<GameState, 65536, IdType> gameStates;
    inline static Beam2<BeamElement, 65536> beams;
    inline static Vector<BeamElement, 65536> globalBeam;
    inline static array<Move, 2048> startingMoves;

    inline static MoveTree<Action, 1 << 23, GameState::MoveIdType, u8> movesTree;

    unordered_set<u32> cache;

public:
    inline static u64 DEPTH = 4;
    inline static u64 BEAM_KEEP = 32;
    inline static u64 GLOBAL_BEAM_KEEP = 128;

    explicit BeamSearch(const GameState& gameState) {
        GLOBAL_BEAM_KEEP = Config::global_beam_keep_b + Config::global_beam_keep_a * GameState::B;
        while (!globalBeam.empty()) {
            movesTree.free(gameStates[globalBeam.back().gameStateId].moveId);
            gameStates.remove(globalBeam.back().gameStateId);
            globalBeam.pop_back();
        }
        cache.clear();
        movesTree.add1(0);
        const IdType gameStateId = gameStates.addGetId(gameState);
        beams.current().push_back({gameStateId, -1e9});
    }

    static u64 reconstructMoves(ostream& output, ostream& error, GameState& gameState, u32 moveId) {
        vector<Action> actions;
        while (moveId != 0) {
            Action action = movesTree.move(moveId);
            actions.push_back(action);
            moveId = movesTree.parentId(moveId);
        }
        std::reverse(actions.begin(), actions.end());

        vector<Move> moves = {{}};
        Move nextMove;
        Move transferActions;
        unordered_set<u32> used;
        i32 movesLeft = Config::step;
        for (const auto& action : actions) {
            if (action.isTransferMove()) {
                transferActions.actions.push_back(action);
            } else if (action.isEndMove()) {
#if DEBUG
                gameState.calcHash();
#endif
                GameState gameStateCopy = gameState;
                for (const auto& transferAction : transferActions.actions) {
                    const Action startTransferAction = gameState.startTransferAction(transferAction);
                    output << startTransferAction;
                    error << startTransferAction;
                    moves.back().actions.push_back(startTransferAction);
                }

                gameState.lightApplyAction(action);
                gameState.finalize();
                output << action;
                error << action;

                for (const auto& transferAction : transferActions.actions) {
                    const Action endTransferAction = gameState.endTransferAction(transferAction);
                    output << endTransferAction;
                    error << endTransferAction;
                    moves.back().actions.push_back(endTransferAction);
                }
                transferActions = {};
                gameState.bridges = gameStateCopy.bridges;
                gameState.maskBridges = gameStateCopy.maskBridges;
                gameState.maskInvBridges = gameStateCopy.maskInvBridges;
                gameState.bigBridges = gameStateCopy.bigBridges;

                moves.back().actions.push_back(action);
                --movesLeft;
#if DEBUG
                gameState.calcHash();
#endif
                for (const auto& nextAction : nextMove.actions) {
                    gameState.lightApplyAction(nextAction);
                    output << nextAction;
                    error << nextAction;
                }
                if (movesLeft == 0) break;
                moves.push_back(nextMove);
                nextMove = {};
                used.clear();
            } else {
                if (used.insert(action.manId()).second) {
                    moves.back().actions.push_back(action);
                    gameState.lightApplyAction(action);
                    output << action;
                    error << action;

                    if (action.type() == Action::TEAM_PACK || action.type() == Action::TEAM_UNPAC) {
                        used.insert(action.val2 & 127);
                    }
                } else {
                    nextMove.actions.push_back(action);
                }
            }
        }
        if (moves.empty()) moves.push_back(Move{{Action::EndMove()}});
        const u64 size = moves.size();
        return size;
    }

    inline static u64 depth = 0;

    GameState::MoveIdType start() {
        copyCurrentToGlobalBeam();
        for (u64 d = 0; d < DEPTH; ++d) {
            depth = d;
            for (u64 b = 0; b < GameState::B; ++b) {
                doOneIteration(b == GameState::B - 1);
                if (beams.next().empty()) {
                    break;
                }
                beams.swap();
                copyCurrentToGlobalBeam();
                beams.next().clear();
                const u64 sizesSum = globalBeam.size() + gameStates.ids.size();
                // assert(sizesSum == 65536);
            }
            beams.current().clear();
            transferGlobalToCurrentBeam();
        }
        beams.current().clear();
        sort(globalBeam.begin(), globalBeam.end(), greater<>());
        const auto bestBe = globalBeam.front();
        return gameStates[bestBe.gameStateId].moveId;
    }


    INLINE bool conditionalInsert(const GameState& parentGameState, GameState& nextGameState, const IdType nextGameStateId,
                                  const Action& action, const GameState::EvalType prvEval) {
#if DEBUG
        assert(nextGameState.hash == nextGameState.calcHash());
#endif
        const auto hash = nextGameState.calcHash();
        if (!cache.insert(hash).second) {
            gameStates.remove(nextGameStateId);
            return false;
        }
        const GameState::EvalType eval = nextGameState.calcEval();
        beams.next().push_back(BeamElement{nextGameStateId, eval});
        nextGameState.moveId = movesTree.add(action, nextGameState.moveId);
        return true;
    }

    inline static array<Vector<u8, 4>, MAX_N> posRev;

    void doOneIteration(const bool finalize) {
        while (beams.current().size() > BEAM_KEEP) {
            movesTree.free(gameStates[beams.current().back().gameStateId].moveId);
            gameStates.remove(beams.current().back().gameStateId);
            beams.current().pop_back();
        }
        for (const auto& be : beams.current()) {
            const GameState& gameState = gameStates[be.gameStateId];
            for (u32 b = 0; b < GameState::B; ++b) {
                if (!posRev[gameState.pos[b]].full()) posRev[gameState.pos[b]].push_back(b);
            }

            for (u32 b = 0; b < GameState::B; ++b) {
                const u32 nextAlreadyMoved = gameState.alreadyMoved | (1U << b);
                if (gameState.alreadyMoved == nextAlreadyMoved) continue;
                const u64 v = gameState.pos[b];


                const i32 controlledBigBridges = gameState.bigBridges[b].from != NO_MSG ? 1 : 0;
                const i32 controlledBridges = GameState::respect_o ? __builtin_popcount(gameState.maskBridges[b]) : controlledBigBridges;
                for (u64 e = 0; e < GameState::edges[v].size(); ++e) {
                    const u64 w = GameState::edges[v][e].target;
                    const u64 wIndex = GameState::edges[v][e].tIndex;
                    const u8 vwDist = GameState::edges[v][e].dist;
                    const u64 vwBridgeMask = 1UL << e;
                    const u64 wvBridgeMask = 1UL << wIndex;



                    if (gameState.bridges[v] & vwBridgeMask) {
                        if ((controlledBridges == 0 || (controlledBridges == 1 && (gameState.maskBridges[b] & vwBridgeMask))) ||
                            (!GameState::respect_o && controlledBigBridges == 0)) {
                            if (gameState.bigBridges[b].from == NO_MSG) {
                                const auto [nextGameStateId, nextGameState] = gameStates.addGetIdAndRef(gameState);
                                nextGameState.alreadyMoved = nextAlreadyMoved;
                                nextGameState.changePos(b, v, w);
                                nextGameState.handleOrdersFor(b);
                                conditionalInsert(gameState, nextGameState, nextGameStateId, Action::move(b, w), be.eval);
                            }
                            if (!posRev[w].empty()) { 
                                i64 bestAtW = -1;
                                for (const auto b2 : posRev[w]) {
                                    if (nextAlreadyMoved & (1U << b2)) continue;
                                    if ((gameState.maskBridges[b2] & ~wvBridgeMask) != 0 && GameState::respect_o) {
                                        continue;
                                    }
                                    if (gameState.bigBridges[b].from == NO_MSG) {
                                        if (gameState.bigBridges[b2].from == NO_MSG) {
                                            bestAtW = b2;
                                        }
                                    } else if (gameState.bigBridges[b2].from == w && gameState.bigBridges[b2].to == v) {
                                        bestAtW = b2;
                                        break;
                                    }
                                }
                                if (bestAtW != -1) {
                                    const auto [nextGameStateId, nextGameState] = gameStates.addGetIdAndRef(gameState);

                                    nextGameState.alreadyMoved = nextAlreadyMoved | (1U << bestAtW);
                                    nextGameState.changePos(b, v, w);
                                    nextGameState.changePos(bestAtW, w, v);
                                    nextGameState.handleOrdersFor(b);
                                    nextGameState.handleOrdersFor(bestAtW);
                                    nextGameState.moveId = movesTree.add(Action::move(b, w), nextGameState.moveId);
                                    const auto tmpMoveId = nextGameState.moveId;
                                    conditionalInsert(gameState, nextGameState, nextGameStateId, Action::move(bestAtW, v), be.eval);
                                    movesTree.free(tmpMoveId);
                                }
                            }
                        }
                        if ((gameState.maskBridges[b] & vwBridgeMask) || (!GameState::respect_o && (gameState.bridges[v] & vwBridgeMask))) {
                            if (vwDist + gameState.carry[b] <= 60 && gameState.bigBridges[b].to != w) {
                                const auto [nextGameStateId, nextGameState] = gameStates.addGetIdAndRef(gameState);
                                nextGameState.alreadyMoved = nextAlreadyMoved;
                                nextGameState.doPack(b, v, w, vwBridgeMask, wvBridgeMask, vwDist);
                                conditionalInsert(gameState, nextGameState, nextGameStateId, Action::pack(b, w), be.eval);
                            } else if (gameState.bigBridges[b].to == w) {
                                i64 bestAtW = -1;
                                for (auto b2 : posRev[w]) {
                                    if ((nextAlreadyMoved & (1U << b2)) != 0) continue;
                                    if (gameState.bigBridges[b2].to == v && gameState.bigBridges[b2].from == w) {
                                        bestAtW = b2;
                                        break;
                                    }
                                }
                                if (bestAtW != -1) {
                                    const auto [nextGameStateId, nextGameState] = gameStates.addGetIdAndRef(gameState);
                                    nextGameState.alreadyMoved = nextAlreadyMoved | (1U << bestAtW);
                                    const auto storedChange = gameState.bigBridges[b].carry;
                                    const auto bChange = b < bestAtW ? storedChange : vwDist - storedChange;
                                    nextGameState.doTeamPack(b, bestAtW, v, w, vwBridgeMask, wvBridgeMask, bChange, vwDist - bChange);
                                    conditionalInsert(gameState, nextGameState, nextGameStateId,
                                        Action::teamPack(b, bestAtW, bChange), be.eval);
                                }
                            }
                        }
                    } else {
                        if (gameState.carry[b] >= vwDist) {
                            const auto [nextGameStateId, nextGameState] = gameStates.addGetIdAndRef(gameState);
                            nextGameState.alreadyMoved = nextAlreadyMoved;
                            nextGameState.doUnpack(b, v, w, vwBridgeMask, wvBridgeMask, vwDist);
                            bool inserted = conditionalInsert(gameState, nextGameState, nextGameStateId, Action::unpack(b, w), be.eval);
                            if (controlledBridges == 0 && nextGameState.bigBridges[b].from == NO_MSG) {
                                const auto [futureGameStateId, futureGameState] = gameStates.addGetIdAndRef(nextGameState);
                                futureGameState.setFutureMoved(b);
                                futureGameState.changePos(b, v, w);
                                futureGameState.handleOrdersFor(b);
                                if (inserted) {
                                    conditionalInsert(nextGameState, futureGameState, futureGameStateId, Action::move(b, w), be.eval);
                                } else {
                                    auto mt1 = nextGameState.moveId = movesTree.add(Action::unpack(b, w), nextGameState.moveId);
                                    conditionalInsert(gameState, futureGameState, futureGameStateId, Action::move(b, w), be.eval);
                                    movesTree.free(mt1);
                                }
                            }
                        } else if (gameState.carry[b] > 0 && gameState.bigBridges[b].from == NO_MSG && controlledBridges == 0) {
                            i64 bestAtW = -1;
                            i32 bestAtWScore = 0;
                            i64 bestAtWSingle = -1;
                            i32 bestAtWScoreSingle = 0;
                            const i32 bGain = gameState.targets[b] != NO_MSG
                                                  ? GameState::allDists[v][gameState.targets[b] & 127]
                                                  - GameState::allDists[w][gameState.targets[b] & 127]
                                                  : 0;
                            for (const auto b2 : posRev[w]) {
                                if ((nextAlreadyMoved & (1U << b2)) != 0) continue;
                                if (gameState.carry[b] + gameState.carry[b2] < vwDist) continue;
                                if (gameState.bigBridges[b2].from != NO_MSG) continue;
                                if (__builtin_popcount(gameState.maskBridges[b2]) != 0 && GameState::respect_o) continue;
                                const i32 b2Gain = gameState.targets[b2] != NO_MSG
                                                       ? GameState::allDists[w][gameState.targets[b2] & 127]
                                                       - GameState::allDists[v][gameState.targets[b2] & 127]
                                                       : 0;
                                const i32 score = bGain + b2Gain;
                                if (score >= bestAtWScore) {
                                    bestAtW = b2;
                                    bestAtWScore = score;
                                }
                                const i32 scoreSingle = bGain;
                                if (scoreSingle >= bestAtWScoreSingle) {
                                    bestAtWSingle = b2;
                                    bestAtWScoreSingle = scoreSingle;
                                }
                            }
                            const bool doDouble = bestAtW != -1;
                            const bool doSingle = bestAtWSingle != -1 && vwDist <= 60 && GameState::connectedComponentSize[v] <= 3;
                            if (doDouble) {
                                const auto [nextGameStateId, nextGameState] = gameStates.addGetIdAndRef(gameState);
                                nextGameState.alreadyMoved = nextAlreadyMoved | (1U << bestAtW);
                                auto bChange = gameState.carry[b];
                                nextGameState.doTeamUnpack(b, bestAtW, v, w, vwBridgeMask, wvBridgeMask, bChange, vwDist - bChange);
                                {
                                    const auto [futureGameStateId, futureState] = gameStates.addGetIdAndRef(nextGameState);
                                    futureState.setFutureMoved(b);
                                    futureState.setFutureMoved(bestAtW);
                                    futureState.changePos(b, v, w);
                                    futureState.changePos(bestAtW, w, v);
                                    futureState.handleOrdersFor(b);
                                    futureState.handleOrdersFor(bestAtW);

                                    auto mt1 = futureState.moveId = movesTree.add(
                                        Action::teamUnPack(b, bestAtW, bChange), futureState.moveId);
                                    auto mt2 = futureState.moveId = movesTree.add(
                                        Action::move(b, w), futureState.moveId);
                                    conditionalInsert(gameState, futureState, futureGameStateId,
                                        Action::move(bestAtW, v), be.eval);
                                    movesTree.free(mt1);
                                    movesTree.free(mt2);
                                }
                                gameStates.remove(nextGameStateId);
                            }
                            auto bChange = gameState.carry[b];
                            if (doSingle && Config::b_exchange &&
                                gameState.carryAndBridges[b] + vwDist - bChange <= GameState::exchangeLimit) {
                                const auto [nextGameStateId, nextGameState] = gameStates.addGetIdAndRef(gameState);
                                nextGameState.alreadyMoved = nextAlreadyMoved | (1U << bestAtWSingle);
                                nextGameState.doTeamUnpack(b, bestAtWSingle, v, w, vwBridgeMask, wvBridgeMask, bChange, vwDist - bChange);

                                const auto [futureGameStateId, futureState] = gameStates.addGetIdAndRef(nextGameState);
                                futureState.bigBridges[b] = GameState::BigBridge();
                                futureState.bigBridges[bestAtWSingle] = GameState::BigBridge();
                                futureState.abandonBridge(bestAtWSingle, wvBridgeMask, vwBridgeMask);
                                futureState.carryAndBridges[b] += vwDist - bChange;
                                futureState.carryAndBridges[bestAtWSingle] -= vwDist - bChange;
                                futureState.setFutureMoved(b);
                                futureState.changePos(b, v, w);
                                futureState.handleOrdersFor(b);

                                auto mt1 = futureState.moveId = movesTree.add(
                                    Action::teamUnPack(b, 128 | bestAtWSingle, bChange), futureState.moveId);
                                conditionalInsert(gameState, futureState, futureGameStateId,
                                    Action::move(b, w), be.eval);
                                movesTree.free(mt1);
                                gameStates.remove(nextGameStateId);
                            }
                        }
                    }
                }
            }

            for (u32 b = 0; b < GameState::B; ++b) {
                posRev[gameState.pos[b]].clear();
            }
        }
        sort(beams.next().begin(), beams.next().end(), greater<>());
    }

    template
    <
        typename T>
    static void cutBeam(T& beam, u64 keepN) {
        if (beam.size() > keepN) {
            std::nth_element(beam.begin(), beam.begin() + keepN, beam.end(), greater<BeamElement>());
            while (beam.size() > keepN) {
                movesTree.free(gameStates[beam.back().gameStateId].moveId);
                gameStates.remove(beam.popBackAndGet().gameStateId);
            }
        }
    }

    INLINE void copyCurrentToGlobalBeam() {
        const u64 globalSize = min(GLOBAL_BEAM_KEEP, beams.current().size());
        for (u64 i = 0; i < globalSize; ++i) {
            globalBeam.push_back(beams.current()[i]);
        }
        while (beams.current().size() > globalSize) {
            movesTree.free(gameStates[beams.current().back().gameStateId].moveId);
            gameStates.remove(beams.current().back().gameStateId);
            beams.current().pop_back();
        }
        if (beams.current().size() > BEAM_KEEP) {
            beams.current().setSize(BEAM_KEEP);
        }
    }


    INLINE void transferGlobalToCurrentBeam() {
        const u64 size = min(GLOBAL_BEAM_KEEP, globalBeam.size());
        std::sort(globalBeam.begin(), globalBeam.end(), greater<>());
        cutBeam(globalBeam, size);


        for (u64 i = 0; i < size; ++i) {
            beams.current().push_back(globalBeam[i]);
            GameState& gameState = gameStates[globalBeam[i].gameStateId];
            gameState.finalize();


            const auto prvMoveId = gameState.moveId;
            gameState.moveId = movesTree.add(Action::EndMove(), gameState.moveId);
            movesTree.free(prvMoveId);
        }

        if (beams.current().size() > BEAM_KEEP) {
            beams.current().setSize(BEAM_KEEP);
        }
    }
};
// END FILE game/BeamSearch.h

// START FILE game/TreePlaner.h
#include <array>
#include <queue>


using namespace std;


struct TEdge {
    u8 v, w;
    u16 length;

    TEdge() = default;

    TEdge(const u8 v, const u8 w, const u16 length) : v(v), w(w), length(length) {
    }

    bool operator<(const TEdge& other) const {
        return length < other.length;
    }
};

class TreePlaner {
    inline static array<i32, MAX_N> parent, rank, maxEdge;

    static void make_set(const i32 v) {
        parent[v] = v;
        rank[v] = 0;
    }

    static i32 find_set(const i32 v) {
        if (v == parent[v])
            return v;
        return parent[v] = find_set(parent[v]);
    }

    static i32 union_sets(i32 a, i32 b) {
        a = find_set(a);
        b = find_set(b);
        if (a != b) {
            if (rank[a] < rank[b])
                swap(a, b);
            parent[b] = a;
            maxEdge[a] = max(maxEdge[a], maxEdge[b]);
            if (rank[a] == rank[b])
                rank[a]++;
        }
        return a;
    }

public:

    static void plan(Vector<TEdge, MAX_N * MAX_N> edges) {
        Vector<TEdge, MAX_N> spanningGraph;
        array<i32, MAX_N> matPerMan;
        array<i32, MAX_N> matLeft;
        array<i32, MAX_N> matForExtra;

        for (i32 i = 0; i < MAX_N; i++) make_set(i);

        for (const TEdge& edge : edges) {
            if (find_set(edge.v) != find_set(edge.w)) {
                spanningGraph.push_back(edge);
                union_sets(edge.v, edge.w);
            }
        }
        i32 mstSum = 0;
        for (i64 i = spanningGraph.size() - 1; true; --i) {
            matLeft[i + 1] = GameState::B * 50 - mstSum;
            matPerMan[i + 1] = matLeft[i + 1] / GameState::B;
            matForExtra[i + 1] = matLeft[i + 1];
            if (i < 0) break;

            matForExtra[i + 1] -= spanningGraph[i].length * GameState::B;
            mstSum += spanningGraph[i].length;
        }


        Vector<pair<u8, u8>, MAX_N> sg;
        for (int j = 0; j < spanningGraph.size(); ++j) {
            sg.push_back({spanningGraph[j].w, spanningGraph[j].v});
        }
        GameState::initializeDists(50, 100, sg, spanningGraph.back().length);


        for (i32 i = 0; i < MAX_N; i++) make_set(i);
        for (i32 i = 0; i < spanningGraph.size(); i++) {
            if (spanningGraph[i].length > 50) {
                break;
            }
            const auto [v,w,length] = spanningGraph[i];
            const auto st = union_sets(v, w);
            maxEdge[st] = max<i32>(maxEdge[st], length);
        }

        vector<i32> ccs[MAX_N];
        for (i32 i = 0; i < GameState::N; i++) {
            ccs[find_set(i)].push_back(i);
            GameState::connectedComponent[i] = find_set(i);
        }
        u32 ccsCount = 0;
        for (i32 i = 0; i < GameState::N; i++) {
            if (ccs[i].empty()) continue;
            ++ccsCount;
            for (const i32 v : ccs[i]) {
                GameState::connectedComponentSize[i] = ccs[i].size();
                cerr << v << ' ';
            }
            cerr << '\n';
        }
        if (ccsCount == 1) Config::b_exchange = 0;
        GameState::exchangeLimit = min<u8>(spanningGraph.back().length, 60);
        if (GameState::exchangeLimit <= 50) Config::b_exchange = 0;

        for (i64 i = 0; i < spanningGraph.size(); ++i) {
        }
    }
};
// END FILE game/TreePlaner.h

// START FILE io/Reader.h
#include <iostream>


using namespace std;

constexpr bool printOutInput = false;

class Reader {
public:
    virtual ~Reader() = default;
    virtual char readChar() =0;
    virtual string readString() = 0;
    virtual i64 readI64() = 0;
    virtual double readDouble() = 0;
};

/** Reads stdin with getchar_unlocked() which is not thread safe*/
class SingleThreadReader final : public Reader {
public:
    char readChar() override {
        char res;
        while (true) {
            res = getchar_unlocked();
            if (isspace(res)) break;
        }
        if (printOutInput) cerr << res << " ";
        return res;
    }

    string readString() override {
        string s;
        while (true) {
            const char c = getchar_unlocked();
            if (isspace(c)) break;
            s.push_back(c);
        }
        if (printOutInput) cerr << s << " ";
        return s;
    }

    i64 readI64() override {
        i64 num = 0;
        char ch = getchar_unlocked();
        while (true) {
            if (ch == '-') break;
            if ('0' <= ch && ch <= '9') break;
            ch = getchar_unlocked();
        }
        if (ch == '-') {
            while (true) {
                ch = getchar_unlocked();
                if (ch < '0' || '9' < ch) break;
                num = num * 10 - (ch - '0');
            }
        } else {
            num = ch - '0';
            while (true) {
                ch = getchar_unlocked();
                if (ch < '0' || '9' < ch) break;
                num = num * 10 + (ch - '0');
            }
        }
        if (printOutInput) cerr << num << " ";
        return num;
    }


    double readDouble() override {
        string s;
        while (true) {
            const char c = getchar_unlocked();
            if (isspace(c)) break;
            s.push_back(c);
        }
        double num = std::stod(s);
        if (printOutInput) cerr << num << " ";
        return num;
    }
};
// END FILE io/Reader.h

// START FILE agent/AgentInput.h
#include <cassert>
#include <iomanip>



template<typename T, T INF>
vector<i64> hungarian(const u64 n, const u64 m, vector<vector<T>> A) {
    vector<T> u(n + 1), v(m + 1);
    vector<i64> p(m + 1), way(m + 1);
    for (i64 i = 1; i <= n; ++i) {
        p[0] = i;
        i64 j0 = 0;
        vector<T> minv(m + 1, INF);
        vector used(m + 1, false);
        do {
            used[j0] = true;
            i64 i0 = p[j0], j1;
            T delta = INF;
            for (i64 j = 1; j <= m; ++j)
                if (!used[j]) {
                    const T cur = A[i0][j] - u[i0] - v[j];
                    if (cur < minv[j])
                        minv[j] = cur, way[j] = j0;
                    if (minv[j] < delta)
                        delta = minv[j], j1 = j;
                }
            for (i64 j = 0; j <= m; ++j)
                if (used[j])
                    u[p[j]] += delta, v[j] -= delta;
                else
                    minv[j] -= delta;
            j0 = j1;
        } while (p[j0] != 0);
        do {
            const u64 j1 = way[j0];
            p[j0] = p[j1];
            j0 = j1;
        } while (j0);
    }
    vector<i64> ans(n + 1);
    for (i64 j = 1; j <= m; ++j)
        ans[p[j]] = j;
    return ans;
}

INLINE void Agent::readInitialInput() {
    GameState::initializeZobristHashes();
    GameState::N = reader.readI64();
    startTime = getTime();
    GameState::B = reader.readI64();
    GameState::O = reader.readI64();

    Vector<TEdge, MAX_N * MAX_N> allEdges;
    for (u64 i = 0; i < GameState::N; ++i) {
#if DEBUG
        if (GameState::O >= 128) {
            GameState::islandPos[i].x = reader.readI64();
            GameState::islandPos[i].y = reader.readI64();
        }
#endif
        for (u64 j = 0; j < GameState::N; ++j) {
            GameState::trueEdge[i][j] = reader.readI64();
            if (i < j && GameState::trueEdge[i][j] <= 100) {
                allEdges.push_back(TEdge(i, j, GameState::trueEdge[i][j]));
            }
        }
    }
    sort(allEdges.begin(), allEdges.end());
    for (auto [v,w,length] : allEdges) {
        if (GameState::edges[v].full()) continue;
        if (GameState::edges[w].full()) continue;
        if (GameState::trueEdge[v][w] > 50) {
            bool found = false;
            for (u64 u = 0; u < GameState::N; ++u) {
                if (GameState::trueEdge[v][u] <= 50 && GameState::trueEdge[u][w] <= 50) {
                    found = true;
                    break;
                }
            }
            if (found) {
                continue;
            }
        }
        const u16 dist = GameState::trueEdge[v][w];
        const u8 vIndex = GameState::edges[v].size();
        const u8 wIndex = GameState::edges[w].size();
        GameState::edges[v].push_back({w, wIndex, dist});
        GameState::edges[w].push_back({v, vIndex, dist});
    }
    for (u64 i = 0; i < GameState::N; ++i) {
        // assert(!GameState::edges[i].empty());
    }

#if DEBUG
    if (GameState::O >= 128) {
        GameState::O -= 128;
    }
#endif
    for (u64 b = 0; b < GameState::B; ++b) {
        gameState.carryAndBridges[b] = 50;
    }

    if (GameState::B <= 6) BeamSearch::DEPTH = 6, BeamSearch::BEAM_KEEP = 128;
    else if (GameState::B <= 10) BeamSearch::DEPTH = 5, BeamSearch::BEAM_KEEP = 64;
    else if (GameState::B <= 14) BeamSearch::DEPTH = 4, BeamSearch::BEAM_KEEP = 48;
    else if (GameState::B <= 17) BeamSearch::DEPTH = 3, BeamSearch::BEAM_KEEP = 36;
    else BeamSearch::DEPTH = 3, BeamSearch::BEAM_KEEP = 20;

    TreePlaner::plan(allEdges);
    if (GameState::N * GameState::B >= Config::respect_o && false) GameState::respect_o = false;
}

INLINE void Agent::readTurnInput() {
    gameState.turn = 0;
    u64 time = reader.readI64() * 1000;
#ifndef DEBUG
    if (turn >= 9) {
        u64 avgTurnTime = (time - turnEndTimes[turn & 7]) / 8;
        turnEndTimes[turn & 7] = time;
        u64 expectedEndTime = time + (MAX_TURN - turn + 1) * avgTurnTime;
        error << "Turn " << turn << "\n";
        error << "Time " << time / 1000 << "\n";
        error << "Avg turn time " << avgTurnTime / 1000 << "\n";
        error << "Expected end time " << expectedEndTime / 1000 << "\n";
        if (expectedEndTime > 9'800'000) {
            if (BeamSearch::BEAM_KEEP >= 4) {
                BeamSearch::BEAM_KEEP -= 1;
                error << "BEAM_KEEP" << BeamSearch::BEAM_KEEP << "\n";
            }
            if (BeamSearch::BEAM_KEEP <= 20 && BeamSearch::DEPTH >= 4) {
                --BeamSearch::DEPTH;
            }
        } else if (expectedEndTime < 9'500'000 && turn % 8 == 0) {
            if (BeamSearch::BEAM_KEEP + 2 <= BeamSearch::GLOBAL_BEAM_KEEP) {
                BeamSearch::BEAM_KEEP += 1;
                error << "BEAM_KEEP" << BeamSearch::BEAM_KEEP << "\n";
            }
        }
    }
#endif

    for (u64 b = 0; b < GameState::B; ++b) {
        if (turn == 1) {
            gameState.pos[b] = reader.readI64();
            gameState.carry[b] = reader.readI64();
        } else {
            reader.readI64();
            reader.readI64();
        }
        const i64 target = reader.readI64();
        gameState.targets[b] = target != -1 ? target : NO_MSG;
        GameState::firstPickup[b] = NO_MSG;
    }

    gameState.inactiveOrders = 0;
    for (u64 o = 0; o < GameState::O; ++o) {
        GameState::orders[o].first = reader.readI64();
        GameState::orders[o].second = reader.readI64();
    }

    gameState.hash = gameState.calcHash();
    if (turn == 1) {
        for (u64 b = 0; b < GameState::B; ++b) {
            gameState.handleOrdersFor(b);
        }
    }

    Vector<u8, MAX_B> freeAgents;
    for (u64 b = 0; b < GameState::B; ++b) {
        if (gameState.targets[b] == NO_MSG) {
            freeAgents.push_back(b);
        }
    }

    vector<vector<i32>> a;
    const u64 m = max<u64>(freeAgents.size(), GameState::O);
    constexpr u16 INF = 1 << 14;
    a.emplace_back(m + 1, INF);
    a[0][0] = 0;
    for (u64 o = 0; o < GameState::O; ++o) {
        vector<i32> row;
        row.push_back(INF);
        for (u64 i = 0; i < freeAgents.size(); ++i) {
            const u64 v = gameState.pos[freeAgents[i]];
            const float pickupLength = GameState::allDists[GameState::orders[o].first][v];
            const float deliveryLength = GameState::allDists[GameState::orders[o].first][GameState::orders[o].second];
            const u16 maxE = max(GameState::maxEdgeOnPath[GameState::orders[o].first][v],
                GameState::maxEdgeOnPath[GameState::orders[o].first][GameState::orders[o].second]);
            const float mep = maxE <= gameState.carryAndBridges[freeAgents[i]] ? 0 : Config::hp_toolong;
            if (gameState.inactiveOrders & (1 << o)) {
                row.push_back(INF);
            } else {
                row.push_back(Config::hm_pickup * pickupLength + deliveryLength + mep);
            }
        }
        while (row.size() <= m) {
            row.push_back(INF);
        }
        a.push_back(row);
    }

    const auto matching = hungarian<i32, INF + 1>(GameState::O, m, a);
    array<bool, MAX_O> selectedOrders{};
    array<bool, MAX_B> bOverloaded{};
    for (i64 o = 0; o < GameState::O; ++o) {
        if (gameState.inactiveOrders & (1 << o)) {
            selectedOrders[o] = true;
            continue;
        }
        const i64 bIndex = matching[o + 1] - 1;
        if (bIndex < 0 || freeAgents.size() <= bIndex) continue;
        const u64 b = freeAgents[bIndex];
        gameState.changeTarget(b, 128 + GameState::orders[o].first);
        GameState::firstPickup[b] = o;
        selectedOrders[o] = true;
    }
    for (int i = 0; i < 3; ++i) {
        for (u64 b = 0; b < GameState::B; ++b) {
            if (bOverloaded[b]) continue;
            const u64 o = GameState::firstPickup[b];
            float dist;
            u64 lastPos;
            if (o == NO_MSG && gameState.targets[b] != NO_MSG) {
                lastPos = gameState.targets[b];
                dist = GameState::allDists[gameState.pos[b]][lastPos];
            } else if (o != NO_MSG) {
                const u64 from = GameState::orders[o].first;
                const u64 to = GameState::orders[o].second;
                lastPos = to;
                dist = GameState::allDists[gameState.pos[b]][from] + GameState::allDists[from][to];
            } else {
                continue;
            }

            for (u64 b2 = 0; b2 < GameState::B; ++b2) {
                if (b == b2) continue;
                const u64 o2 = GameState::firstPickup[b2];
                if (o2 == NO_MSG) continue;
                const u64 from2 = GameState::orders[o2].first;
                const float dist2 = GameState::allDists[gameState.pos[b2]][from2];
                if (dist + GameState::allDists[lastPos][from2] <= dist2 * Config::rm_overtake) {
                    gameState.changeTarget(b2, NO_MSG);
                    GameState::firstPickup[b2] = NO_MSG;
                    i64 bestO = -1;
                    float bestOScore = INF;
                    for (i64 o3 = 0; o3 < GameState::O; ++o3) {
                        if (selectedOrders[o3]) continue;
                        const float pickupLength = GameState::allDists[GameState::orders[o3].first][gameState.pos[b2]];
                        const float deliveryLength = GameState::allDists[GameState::orders[o3].first][GameState::orders[o3].second];
                        const float score = Config::rm_pickup * pickupLength + deliveryLength;
                        if (score < bestOScore) {
                            bestOScore = score;
                            bestO = o3;
                        }
                    }
                    if (bestO != -1) {
                        gameState.changeTarget(b2, 128 + GameState::orders[bestO].first);
                        GameState::firstPickup[b2] = bestO;
                        selectedOrders[bestO] = true;
                    }
                    bOverloaded[b] = true;
                    break;
                }
            }
        }
    }

    u64 mostPowerful = 0;
    for (u64 b = 1; b < GameState::B; ++b) {
        if (gameState.carryAndBridges[mostPowerful] < gameState.carryAndBridges[b]) {
            mostPowerful = b;
        }
    }
    if (gameState.targets[mostPowerful] != NO_MSG && Config::i_help) {
        const u64 target = gameState.targets[mostPowerful] & 127;
        const u64 v = gameState.pos[mostPowerful];
        if (GameState::maxEdgeOnPath[target][v] > gameState.carryAndBridges[mostPowerful]) {
            i64 closest = -1;
            i64 closestDist = 100000;
            for (u64 e = 0; e < GameState::edges[v].size(); ++e) {
                const u64 w = GameState::edges[v][e].target;
                if (GameState::connectedComponent[w] == GameState::connectedComponent[v]) continue;
                if (GameState::allDists[target][w] < GameState::allDists[target][v]) {
                    for (u64 b = 0; b < GameState::B; ++b) {
                        if (b == mostPowerful) continue;
                        if (GameState::connectedComponent[gameState.pos[b]] == GameState::connectedComponent[w]) {
                            const i64 dist = GameState::allDists[v][gameState.pos[b]];
                            if (dist < closestDist) {
                                closestDist = dist;
                                closest = b;
                            }
                        }
                    }
                }
            }
            if (closest != -1) {
                cerr << "tt" << closest << "tte" << v << endl;
                gameState.changeTarget(closest, 128 + v);
                GameState::firstPickup[closest] = NO_MSG;
            }
        }
    }

}
// END FILE agent/AgentInput.h

// START FILE agent/AgentOutput.h
INLINE void Agent::calculateOutput() {
    error << turn << " " << skip << endl;
    if (turn <= skip) return;
    BeamSearch beamSearch(gameState);
    const auto moveIdType = beamSearch.start();
    const u64 toSkip = beamSearch.reconstructMoves(output, error, gameState, moveIdType);
    skip += toSkip;
}
// END FILE agent/AgentOutput.h

// START FILE agent/Agent.cpp

// END FILE agent/Agent.cpp

// START FILE BridgeRunnersSubmit.cpp
#include <iostream>



using namespace std;

int main() {
    SingleThreadReader reader;
    Agent agent(reader, cout, cerr);

    Config::init();

    agent.readInitialInput();
    while (Agent::turn < MAX_TURN) {
        ++Agent::turn;
        Agent::_timeout = false;
        agent.readTurnInput();
        agent.calculateOutput();
        cout.flush();
        cerr.flush();
    }
}
// END FILE BridgeRunnersSubmit.cpp

