/*

how to utilize idle ones?


10530, 10635, 10665 still stuck

stuck = no target!
till swap

when is it worth to give up single position or even 2?
-when distance <= 60: move and rebalance
-avoid that group (can be problematic)
-when target is in 50-60: wait for mate bridge and cut, then come back and rebalance

assumption: do not keep bridges, universal 50

*/

#include <iostream>
#include <vector>
#include <string>
#include <sstream>
#include <numeric>
#include <algorithm>
#include <deque>
#include <thread>

using namespace std;

class Bridgeman {
public:
    int ID;
    int Position;
    int Target;
    int Bricks;
    int Move;
    int BridgeFrom = -1;
    int BridgeTo = -1;
    bool Used;
    int TeamWith = -1;
    bool TeamPrimary = false;
    int OriTarget;
    int NextMove = -1;
    int AvoidTeam = -1;
    int NewPosition = -1;
    bool Served = false;
    int FinalTarget;
    int HalfOther = -1;
    bool FakeTarget = false;
};

class Order {
public:
    int From;
    int To;
};

static int g_seed = 777778;
static int Rand(int mod) {
    g_seed = (214013 * g_seed + 2531011);
    return ((g_seed >> 16) & 0x7FFF) % mod;
}

static const int MAXN = 80;
static const int MAXB = 20;
static const int MAXG = 20;
static const int MAXO = 10;

int N, B, O;

int group = 1;
int groupdist = 50;
int elapsedTime;
int score;
int turn;
bool stuck = false;
double avgmul = 2.5;

int groups[MAXN];
Order orders[MAXO];
vector<int> members[MAXG];
int groupdists[MAXG][MAXG];
int dists[MAXN][MAXN];
bool connected[MAXN][MAXN];

int connectedcnt[MAXN][MAXN];

Bridgeman bridgemen[MAXB];
Bridgeman savebridgemen[12][MAXB];

bool calcgroup(int i)
{
    if (groups[i] > 0)
        return false;
    groups[i] = group;
    members[group].push_back(i);
    cerr << i << ' ';
    for (int j = 0; j < N; ++j) {
        if (i != j && dists[i][j] <= groupdist)
            calcgroup(j);
    }
    return true;
}

void calcgroup()
{
    cerr << "groupdist " << groupdist << endl;
    cerr << 1 << ':';
    for (int i = 0; i < N; ++i) {
        if (calcgroup(i)) {
            ++group;
            cerr << endl;
            cerr << group << ':';
        }
    }
    cerr << endl;
}


void calcgroups()
{
    while (1) {
        calcgroup();
        if (group >= 3 + 1)
            return;
        group = 1;
        for (int g = 0; g < group; ++g)
            members[g].clear();
        for (int i = 0; i < N; ++i)
            groups[i] = 0;
        groupdist -= 5;
    }
}

int onespec;
int bestonenode = -1;
int bestbone;
int bestbforone;
int bestbridgepos;
int onespecphase = -1;

void calcgroupdists()
{
    for (int g1 = 1; g1 < group; ++g1) {
        for (int g2 = g1 + 1; g2 < group; ++g2) {
            int mn = 999;
            for (auto i1 : members[g1]) {
                for (auto i2 : members[g2]) {
                    int d = dists[i1][i2];
                    if (d < mn)
                        mn = d;
                }
            }
            groupdists[g1][g2] = mn;
            groupdists[g2][g1] = mn;
            cerr << 'G' << g1 << ' ' << 'G' << g2 << ' ' << 'D' << mn << endl;
        }
    }
}

int bfsdists[MAXN][MAXN];
int prevs[MAXN][MAXN];

void calcbfsdist(int i)
{
    for (int j = 0; j < N; ++j) {
        bfsdists[i][j] = 99;
        prevs[j][i] = -1;
    }
    bfsdists[i][i] = 0;
    deque<pair<int, int>> q;
    q.push_back(make_pair(i, 0));
    while (!q.empty()) {
        auto p = q.front();
        q.pop_front();
        int d = p.second + 1;
        int dg = d + 5;
        for (int j = 0; j < N; ++j) {
            if (dists[p.first][j] <= 50 && bfsdists[i][j] >= d) {
                if (bfsdists[i][j] > d || dists[0][prevs[j][i]] > dists[0][p.first])
                    prevs[j][i] = p.first;
                if (bfsdists[i][j] > d) {
                    bfsdists[i][j] = d;
                    q.push_back(make_pair(j, d));
                }
                //                cerr << i << ' ' << j << " D" << d << ' ' << p.first << endl;
            }
            if (dists[p.first][j] <= 100 && groups[p.first] != groups[j] && bfsdists[i][j] >= dg) {
                if (i == 10 && j == 20)
                    int alma = 0;
                if (bfsdists[i][j] > dg || dists[j][prevs[j][i]] > dists[j][p.first])
                    prevs[j][i] = p.first;
                if (bfsdists[i][j] > dg) {
                    bfsdists[i][j] = dg;
                    q.push_back(make_pair(j, dg));
                }
                //                cerr << i << ' ' << j << " D" << dg << ' ' << p.first << endl;
            }
        }
    }
}

void calcbfsdists()
{
    cerr << "bfs" << endl;
    for (int i = 0; i < N; ++i)
        calcbfsdist(i);
}

double getdistadjust(int i, int target)
{
    double d = 0;
    auto& b = bridgemen[i];
    int start = b.Position;
    int next = prevs[target][start];
    int other = b.BridgeFrom == start ? b.BridgeTo : b.BridgeTo == start ? b.BridgeFrom : -1;
    if (connected[start][next]) {
        --d;
        if (other == -1)
            --d;
    }
    else if (other != -1) {
        if (bfsdists[start][target] <= bfsdists[other][target])
            ++d;
        else
            --d;
    }
    return d;
}

void assigntargets()
{
    cerr << "assign" << endl;

    if (stuck) {
        cerr << "stuck" << endl;
        for (int i = 0; i < B; ++i) {
            auto& b = bridgemen[i];
            int mn = 999;
            int bestj;
            for (int j = 0; j < B; ++j) {
                auto& b2 = bridgemen[j];
                if (groups[b.Position] != groups[b2.Position]) { // && members[groups[b.Position]].size() > 2 && members[groups[b2.Position]].size() > 2) {
                    int d = dists[b.Position][b2.Position];
                    if (d < mn) {
                        mn = d;
                        bestj = j;
                    }
                }
            }
            if (mn < 999) {
                b.Target = bridgemen[bestj].Position;
                cerr << 'B' << i << ' ' << 'B' << bestj << ' ' << b.Target << endl;
            }
        }
        return;
    }


    bool assigned[MAXO];
    double minreach[MAXO];
    for (int i = 0; i < O; ++i) {
        assigned[i] = orders[i].To == bestonenode;
        minreach[i] = 99;
    }

    for (int o = 0; o < O; ++o) {

        bool dup = false;
        for (int o2 = 0; o2 < O; ++o2) {
            if (orders[o].From == orders[o2].From) {
                dup = true;
                break;
            }
        }

        if (!dup) {
            for (int i = 0; i < B; ++i) {
                auto& b = bridgemen[i];
                if (b.OriTarget != -1 && groups[b.Position] == groups[b.Target] && b.OriTarget == orders[o].From) {
                    double d = avgmul * bfsdists[b.Position][b.OriTarget] - 1;
                    d += getdistadjust(i, b.OriTarget);


                    if (d < minreach[o])
                        minreach[o] = d;
                }
            }
        }
    }

    while (1) {
        double mn = 99;
        int besti;
        int besto;
        for (int i = 0; i < N; ++i) {
            int start = bridgemen[i].Position;
            if (bridgemen[i].Target == -1) {
                for (int o = 0; o < O; ++o) {

                    if (turn == 835 && i == 17)
                        int alma = 0;

                    if (assigned[o])
                        continue;

                    int g = groups[orders[o].From];

                    double d = avgmul * bfsdists[start][orders[o].From];
                    if (turn > 990)
                        d += avgmul * bfsdists[orders[o].From][orders[o].To];
                    d += getdistadjust(i, orders[o].From);

                    if (d < mn && d < minreach[o]) {

                        mn = d;
                        besti = i;
                        besto = o;
                    }
                }
            }
        }
        if (mn == 99)
            break;
        bridgemen[besti].Target = bridgemen[besti].Position == orders[besto].From ? orders[besto].To : orders[besto].From;
        bridgemen[besti].FinalTarget = orders[besto].To;
        assigned[besto] = true;
        cerr << 'B' << besti << ' ' << bridgemen[besti].Position << ' ' << orders[besto].From << ' ' << orders[besto].To << " D" << mn << endl;
    }

    if (group == 2) {
        for (int i = 0; i < B; ++i) {
            if (bridgemen[i].Target == -1) {
                cerr << "without target " << i << endl;
                if (bridgemen[i].Position != 0) {
                    bridgemen[i].Target = 0;
                    bridgemen[i].FakeTarget = true;
                }
            }
        }
    }
}

vector<string> output;
vector<string> saveoutput[12];

void teamunpack(int i, int j, int len = 50)
{
    auto& b = bridgemen[i];
    auto& b2 = bridgemen[j];
    output.push_back("TEAMUNPACK " + to_string(b.ID) + " " + to_string(b2.ID) + " " + to_string(len));
    b.BridgeFrom = b.Position;
    b.BridgeTo = b2.Position;
    connected[b.BridgeFrom][b.BridgeTo] = true;
    connected[b.BridgeTo][b.BridgeFrom] = true;

    ++connectedcnt[b.BridgeFrom][b.BridgeTo];
    ++connectedcnt[b.BridgeTo][b.BridgeFrom];

    b.Used = true;
    b2.Used = true;
    b2.BridgeFrom = b2.Position;
    b2.BridgeTo = b.Position;
    b.TeamWith = j;
    b2.TeamWith = i;
    b.TeamPrimary = true;
    stuck = false;
}

void calcteamunpackopt(int min)
{
    while (1) {
        double mx = min;
        int besti;
        int bestj;
        for (int i = 0; i < B; ++i) {
            auto& b = bridgemen[i];
            if (b.Used || b.NextMove != -1 || b.BridgeFrom != -1 || b.Target == -1)
                continue;
            for (int j = 0; j < B; ++j) {
                auto& b2 = bridgemen[j];
                if (b2.Used || b2.NextMove != -1 || b2.BridgeFrom != -1 || b2.Target == -1)
                    continue;
                if (dists[b.Position][b2.Position] > 50 && dists[b.Position][b2.Position] <= 100 && groups[b.Position] == groups[b2.Position] && !connected[b.Position][b2.Position]) {
                    double orid = (b.FakeTarget ? 0 : avgmul * bfsdists[b.Position][b.Target]) + (b2.FakeTarget ? 0 : avgmul * bfsdists[b2.Position][b2.Target]);
                    double nd = (b2.FakeTarget ? 0 : 3 + avgmul * bfsdists[b.Position][b2.Target]) + (b.FakeTarget ? 0 : 3 + avgmul * bfsdists[b2.Position][b.Target]);
                    double diff = orid - nd;
                    if (diff > mx) {
                        mx = diff;
                        besti = i;
                        bestj = j;
                    }
                }
            }
        }
        if (mx == min)
            break;
        teamunpack(besti, bestj);
    }
}

void pack(int i, int t)
{
    auto& b = bridgemen[i];
    output.push_back("PACK " + to_string(b.ID) + " " + to_string(t));

    connected[b.Position][t] = false;
    connected[t][b.Position] = false;

    b.BridgeFrom = -1;
    b.BridgeTo = -1;
    b.Used = true;
    b.TeamPrimary = false;
}

void calcteamunpackoptb(int min)
{
    while (1) {
        double mx = min;
        int besti;
        int bestj;
        for (int i = 0; i < B; ++i) {
            auto& b = bridgemen[i];
            if (b.Used || b.NextMove != -1 || b.BridgeFrom != -1 || b.Target == -1)
                continue;
            for (int j = 0; j < B; ++j) {
                auto& b2 = bridgemen[j];
                if (b2.Used || b2.NextMove != -1 || b2.BridgeFrom == -1 || b2.TeamWith != -1 || b2.Target == -1)
                    continue;
                if (dists[b.Position][b2.Position] > 50 && dists[b.Position][b2.Position] <= 100 && groups[b.Position] == groups[b2.Position] && !connected[b.Position][b2.Position]) {
                    double orid = (b.FakeTarget ? 0 : avgmul * bfsdists[b.Position][b.Target]) + (b2.FakeTarget ? 0 : avgmul * bfsdists[b2.Position][b2.Target]);
                    double nd = (b2.FakeTarget ? 0 : 3 + avgmul * bfsdists[b.Position][b2.Target] + 1) + (b.FakeTarget ? 0 : 3 + avgmul * bfsdists[b2.Position][b.Target] + 1);
                    double diff = orid - nd;
                    if (diff > mx) {
                        mx = diff;
                        besti = i;
                        bestj = j;
                    }
                }
            }
        }
        if (mx == min)
            break;
        auto& b2 = bridgemen[bestj];
        pack(bestj, b2.Position == b2.BridgeFrom ? b2.BridgeTo : b2.BridgeFrom);
        bridgemen[besti].Used = true;
    }
}


void calchalfteamunpackopt(int min = 0)
{
    while (1) {
        double mx = min;
        int besti;
        int bestj;
        int bestother;
        for (int i = 0; i < B; ++i) {
            auto& b = bridgemen[i];
            if (b.Used || b.NextMove != -1 || b.BridgeFrom == -1 || b.TeamWith != -1 || b.Target == -1)
                continue;
            for (int j = 0; j < B; ++j) {
                auto& b2 = bridgemen[j];
                if (b2.Used || b2.NextMove != -1 || b2.BridgeFrom != -1 || b2.Target == -1)
                    continue;
                if (dists[b.Position][b2.Position] > 50 && dists[b.Position][b2.Position] <= b.Bricks + b2.Bricks && groups[b.Position] == groups[b2.Position] && !connected[b.Position][b2.Position]) {
                    int other = b.BridgeFrom == b.Position ? b.BridgeTo : b.BridgeFrom;
                    double orid = (b.FakeTarget ? 0 : 1 + avgmul * bfsdists[b.Position][b.Target]) + (b2.FakeTarget ? 0 : avgmul * bfsdists[b2.Position][b2.Target]);
                    double nd = (b2.FakeTarget ? 0 : 4 + avgmul * bfsdists[other][b2.Target]) + (b.FakeTarget ? 0 : 3 + avgmul * bfsdists[b2.Position][b.Target]);
                    int next2 = prevs[b.Position][b2.Target];
                    if (turn == 758)
                        int alma = 0;
                    if (bfsdists[next2][b2.Target] == bfsdists[other][b2.Target])
                        --nd;
                    double diff = orid - nd;
                    if (diff > mx) {
                        mx = diff;
                        besti = i;
                        bestj = j;
                        bestother = other;
                    }
                }
            }
        }
        if (mx == min)
            break;

        cerr << "half " << besti << ' ' << bestj << ' ' << bestother << endl;
        teamunpack(besti, bestj, bridgemen[besti].Bricks);
        bridgemen[bestj].HalfOther = bestother;
    }
}

// other variations
//  --- short
//  --- long ---



void move(int i, int t)
{
    if (turn >= 119 && i == 4)
        int alma = 0;
    auto& b = bridgemen[i];
    output.push_back("MOVE " + to_string(b.ID) + " " + to_string(t));
    b.Used = true;
    b.NewPosition = t;
    if (t == b.Target && b.OriTarget == b.Target)
        ++score;
}

void unpack(int i, int t)
{
    auto& b = bridgemen[i];
    output.push_back("UNPACK " + to_string(b.ID) + " " + to_string(t));
    b.BridgeFrom = b.Position;
    b.BridgeTo = t;
    connected[b.BridgeFrom][b.BridgeTo] = true;
    connected[b.BridgeTo][b.BridgeFrom] = true;
    ++connectedcnt[b.BridgeFrom][b.BridgeTo];
    ++connectedcnt[b.BridgeTo][b.BridgeFrom];

    b.Used = true;
}

void teampack(int i, int j, int len = 50)
{
    auto& b = bridgemen[i];
    auto& b2 = bridgemen[j];
    output.push_back("TEAMPACK " + to_string(b.ID) + " " + to_string(b2.ID) + " " + to_string(len));

    connected[b.Position][b2.Position] = false;
    connected[b2.Position][b.Position] = false;

    b2.Used = true;
    b2.BridgeFrom = -1;
    b2.BridgeTo = -1;
    b.AvoidTeam = b.TeamWith;
    b2.AvoidTeam = b2.TeamWith;

    b.TeamWith = -1;
    b2.TeamWith = -1;
    b2.TeamPrimary = false;

    b.BridgeFrom = -1;
    b.BridgeTo = -1;
    b.Used = true;
    b.TeamPrimary = false;

    if (b2.HalfOther != -1) {
        b2.BridgeFrom = b2.Position;
        b2.BridgeTo = b2.HalfOther;
        b2.HalfOther = -1;
    }
}


void calcearlymove()
{
    for (int i = 0; i < B; ++i) {
        auto& b = bridgemen[i];

        if (b.Used || b.NextMove != -1 || b.Target == -1 || b.TeamWith != -1)
            continue;

        double orid = avgmul * bfsdists[b.Position][b.Target];
        double mn = orid;
        int t;
        for (int n = 0; n < N; ++n) {
            if (connected[b.Position][n] && groups[n] == groups[b.Position] && (b.Bricks == 50 || b.Position == b.BridgeFrom && b.BridgeTo == n || b.Position == b.BridgeTo && b.BridgeFrom == n)) {

                /*
                                int next = prevs[n][b.Target];
                if (groups[n] != groups[next])
                    continue; */

                double d = avgmul * bfsdists[n][b.Target] + 1;
                if (d < mn) {
                    if (turn == 119)
                        int alma = 0;
                    mn = d;
                    t = n;
                }
            }
        }
        if (mn < orid) {
            cerr << "early " << i << ' ' << t << endl;
            move(i, t);
        }
    }
}

void calcclosemovefor(int min = 0)
{
    while (1) {
        double mx = min;
        int besti;
        int besttarget;
        int bestj;
        for (int i = 0; i < B; ++i) {
            auto& b = bridgemen[i];
            if (b.Used || b.NextMove != -1 || b.BridgeFrom != -1 || b.Target == -1 || b.Served)
                continue;
            for (int j = 0; j < B; ++j) {
                auto& b2 = bridgemen[j];
                if (b2.Used || b2.NextMove != -1 || i == j || b2.Target == -1 || b2.Served || b2.FakeTarget)
                    continue;
                if (dists[b.Position][b2.Position] <= 50 && groups[b.Position] == groups[b2.Position] && !connected[b.Position][b2.Position]) {
                    double orid = (b.FakeTarget ? 0 : avgmul * bfsdists[b.Position][b.Target]) + avgmul * bfsdists[b2.Position][b2.Target];
                    double nd = 1 + avgmul * bfsdists[b.Position][b2.Target] + (b.FakeTarget ? 0 : 3 + avgmul * bfsdists[b2.Position][b.Target]);
                    double diff = orid - nd;
                    if (diff > mx) {
                        mx = diff;
                        besti = i;
                        besttarget = b2.Position;
                        bestj = j;
                    }
                }
                int t2 = prevs[b2.Target][b2.Position];
                if (b.Position == b2.Position && dists[b.Position][t2] <= 50 && groups[b.Position] == groups[t2] && !connected[b.Position][t2]) {
                    double orid = (b.FakeTarget ? 0 : avgmul * bfsdists[b.Position][b.Target]) + avgmul * bfsdists[b2.Position][b2.Target];
                    double nd = 1 + avgmul * bfsdists[t2][b2.Target] + (b.FakeTarget ? 0 : 3 + avgmul * bfsdists[t2][b.Target]);
                    double diff = orid - nd;
                    if (diff > mx) {
                        mx = diff;
                        besti = i;
                        besttarget = t2;
                        bestj = j;
                    }
                }
            }
        }
        if (mx == min)
            break;
        cerr << "closefor " << besti << ' ' << bestj << ' ' << besttarget << endl;
        unpack(besti, besttarget);
        bridgemen[bestj].Served = true;
    }
}

void calcbeforepick()
{
    for (int i = 0; i < B; ++i) {
        auto& b = bridgemen[i];

        if (b.Used || b.Bricks < 50 || b.NextMove != -1 || b.OriTarget != -1 || bfsdists[b.Position][b.Target] != 2 || b.Target == b.FinalTarget)
            continue;

        int next = prevs[b.Position][b.Target];
        if (connected[b.Position][next] || prevs[b.Target][b.FinalTarget] == next)
            continue;

        double orid = avgmul * bfsdists[b.Target][b.FinalTarget] + 1;
        double mn = orid;
        int t;
        for (int n = 0; n < N; ++n) {
            if (n != next && n != b.Position && dists[n][b.Position] <= 50 && dists[n][b.Target] <= 50 && !connected[n][b.Position]) {
                double d = avgmul * bfsdists[n][b.FinalTarget] + 2;
                if (d < mn) {
                    mn = d;
                    t = n;
                }
            }
        }
        if (mn < orid) {
            cerr << "beforepick " << i << ' ' << t << endl;
            unpack(i, t);
        }
    }
}

void calcunpack()
{
    calcteamunpackopt(3);
    calchalfteamunpackopt(3);
    calcteamunpackoptb(3);
    calcearlymove();

    calcteamunpackopt(1);
    calcteamunpackoptb(1);
    calchalfteamunpackopt(1);
    calcclosemovefor();
    calcbeforepick();

    for (int i = 0; i < B; ++i) {
        auto& b = bridgemen[i];
        if (b.Used || b.Target == -1 || b.NextMove != -1)
            continue;

        double orid = avgmul * bfsdists[b.Position][b.Target];
        double mn = orid;
        {
            int t;
            for (int n = 0; n < N; ++n) {
                if (connected[b.Position][n] && groups[n] == groups[b.Position] && (b.Bricks == 50 || b.BridgeTo == n)) {
/*
                    int next = prevs[n][b.Target];
                    if (groups[n] != groups[next])
                        continue; */

                    double d = avgmul * bfsdists[n][b.Target] + 1;
                    if (d < mn) {
                        mn = d;
                        t = n;
                    }
                }
            }
            if (mn < orid) {
                cerr << "semiearly " << i << ' ' << t << endl;
                move(i, t);
                continue;
            }
        }

        int t = prevs[b.Position][b.Target];

        if (b.BridgeFrom == -1 && !connected[b.Position][t]) {
            if (dists[b.Position][t] <= 50)
                unpack(i, t);
            else if (dists[b.Position][t] <= 100) {
                bool ok = false;

                for (int allowany = 0; allowany < 2; ++allowany) {

                    for (int j = 0; j < B; ++j) {
                        auto& b2 = bridgemen[j];
                        if (t == 13 && b.Position == 23 && b2.Position == 26)
                            int alma = 0;

                        if (b2.Used || b2.NextMove != -1 || b2.ID == b.ID || dists[b.Position][b2.Position] > 100 || groups[t] != groups[b2.Position] ||
                            b2.OriTarget != -1 && groups[b2.Target] == groups[b2.Position] || b2.BridgeFrom != -1 || b.AvoidTeam == j)
                            continue;

                        if (!allowany && b2.Position != t)
                            continue;

                        if (b.OriTarget == -1 && b2.OriTarget == -1)
                            continue;

                        if (onespecphase != -1 && j == bestbforone)
                            continue;

                        int t2 = b2.OriTarget == -1 || groups[b2.Target] != groups[b2.Position] ? b.Position : prevs[b2.Position][b2.Target];

                        if (!allowany) {
                            if (groups[t2] != groups[b.Position] || groups[t] != groups[b2.Position])
                                continue;
                        }

                        if (dists[b2.Position][b.Position] > 50 && !connected[b.Position][b2.Position]) {
                            if (turn == 38)
                                int alma = 0;

                            teamunpack(i, j);
                            ok = true;
                            break;
                        }
                    }
                    if (ok)
                        break;
                }
                if (!ok) {
                    if (turn == 700)
                        int alma = 0;
                    int mn = 199;
                    int bestj;
                    int bestn;
                    bool alreadyconnected = false;
                    for (int j = 0; j < B; ++j) {
                        auto& b2 = bridgemen[j];
                        if (b2.ID == b.ID || groups[b.Position] == groups[b2.Position])
                            continue;
                        if (connected[b.Position][b2.Position] && dists[b.Position][b2.Position] > 50) {
                            alreadyconnected = true;
                            break;
                        }
                        int t2 = b2.OriTarget == -1 || groups[b2.Target] != groups[b2.Position] ? b.Position : prevs[b2.Position][b2.Target];
                        if (groups[t2] == groups[b.Position] || groups[t] == groups[b2.Position]) {
                            for (int n = 0; n < N; ++n) {
                                if (dists[n][b.Position] <= 50 && !connected[n][b.Position]) {
                                    int d = dists[n][b2.Position];
                                    if (d < mn) {
                                        mn = d;
                                        bestn = n;
                                        bestj = j;
                                    }
                                }
                            }
                        }
                    }
                    if (!alreadyconnected && mn < 199) {
                        if (bestn != b.Position) {
                            b.Target = bestn;
                            output.push_back("UNPACK " + to_string(b.ID) + " " + to_string(bestn));
                            b.BridgeFrom = b.Position;
                            b.BridgeTo = bestn;
                            connected[b.BridgeFrom][b.BridgeTo] = true;
                            connected[b.BridgeTo][b.BridgeFrom] = true;
                            b.NextMove = bestn;
                        }
                        b.Used = true;
                    }
                }
            }
        }
        b.AvoidTeam = -1;
    }
}

void calcmove()
{
    for (int i = 0; i < B; ++i) {
        auto& b = bridgemen[i];

        if (turn == 16 && i == 7)
            int alma = 0;

        if (b.Used || b.TeamWith != -1 && b.Position != b.BridgeFrom)
            continue;

        int t;
        if (b.NextMove != -1) {
            t = b.NextMove;
            b.NextMove = -1;
        }
        else if (b.BridgeFrom != -1 && b.TeamWith != -1)
            t = bridgemen[b.TeamWith].Position;
        else if (b.Target == -1)
            continue;
        else {
            t = prevs[b.Position][b.Target];
            if (members[groups[b.Position]].size() <= 3 && groups[b.Position] != groups[b.Target]) {
                for (int j = 0; j < N; ++j) {
                    if (connected[b.Position][j] && dists[b.Position][j] > 50 && members[groups[t]].size() > 3) {
                        t = j;
                        break;
                    }
                }
            }
            //                if (groups[b.Position] != groups[t] && members[groups[t]].size() <= 3 && members[groups[b.Position]].size() >= 10 && groups[t] != groups[b.Target])
            //                    continue;
        }

        if ((b.BridgeFrom == -1 || t == b.BridgeFrom || t == b.BridgeTo) && connected[b.Position][t]) { // MOVE
            move(i, t);
        }
    }
}

bool stillneeded(int i, int j)
{
    for (int bi = 0; bi < B; ++bi) {
        auto& b = bridgemen[bi];
        if (b.OriTarget != -1 && b.NewPosition != b.Target && b.BridgeFrom == -1 &&
            (b.NewPosition == i && prevs[b.NewPosition][b.Target] == j || b.NewPosition == j && prevs[b.NewPosition][b.Target] == i)) {

            if (onespecphase > 6 && bi == bestbone)
                continue;

            cerr << "stillneeded " << i << ' ' << j << " for " << bi << endl;
            return true;
        }
    }
    return false;
}

void calcpack()
{
    for (int i = 0; i < B; ++i) {
        auto& b = bridgemen[i];
        if (b.Used || b.Target == -1)
            continue;
        int t = prevs[b.Position][b.Target];
        if (b.BridgeFrom != -1 && t != b.BridgeTo && t != b.BridgeFrom && (b.Position == b.BridgeFrom || b.Position == b.BridgeTo) && !stillneeded(b.BridgeFrom, b.BridgeTo)) { // PACK

            if (b.TeamWith == -1) {
                pack(i, b.Position == b.BridgeFrom ? b.BridgeTo : b.BridgeFrom);
            }
            else {
                teampack(b.TeamPrimary ? i : b.TeamWith, b.TeamPrimary ? b.TeamWith : i);
            }
        }
    }
}

void calcone()
{
    return;

    int mn = 999;
    for (int g1 = group - 1; g1 >= 0; --g1) {
        for (int g2 = g1 - 1; g2 >= 0; --g2) {
            if (members[g1].size() == 1 && groupdists[g1][g2] <= 60 && members[g2].size() > 10) {
                ++onespec;

                int bone;
                for (int i = 0; i < B; ++i) {
                    if (groups[bridgemen[i].Position] == g1) {
                        bone = i;
                        break;
                    }
                }

                bestbridgepos = -1;
                for (int i = 0; i < N; ++i) {
                    if (groups[i] == g2 && dists[i][members[g1][0]] <= 60) {
                        bestbridgepos = i;
                        break;
                    }
                }
                if (bestbridgepos == -1)
                    continue;

                for (int i = 0; i < B; ++i) {
                    if (groups[bridgemen[i].Position] != g2)
                        continue;
                    int d = bfsdists[bridgemen[i].Position][bestbridgepos];
                    if (d < mn) {
                        mn = d;
                        bestonenode = members[g1][0];
                        bestbone = bone;
                        bestbforone = i;
                        onespecphase = 1;
                    }
                }

                if (onespecphase == 1) {
                    cerr << "bestonenode " << bestonenode << endl;
                    cerr << "bestbone " << bestbone << endl;
                    cerr << "bestbforone " << bestbforone << endl;
                    cerr << "bestbridgepos " << bestbridgepos << endl;

                    /*                   for (int i = 0; i < N; ++i) {
                                           if (i != bestbridgepos)
                                               prevs[i][bestonenode] = bestbridgepos;
                                       } */
                    return;
                }
            }
        }
    }
}

void handleonespec()
{
    auto& b1 = bridgemen[bestbone];
    auto& b2 = bridgemen[bestbforone];
    cerr << "spec " << onespecphase << endl;
    if (onespecphase == 1) {
        if (b2.Position == bestbridgepos && b2.Bricks == 50)
            onespecphase = 2;
        else {
            b1.Target = -1;
            b2.Target = bestbridgepos;
            return;
        }
    }
    if (onespecphase == 2) {
        teamunpack(bestbforone, bestbone);
        onespecphase = 3;
        return;
    }
    if (onespecphase == 3) {
        move(bestbone, b2.Position);
        pack(bestbforone, b1.Position);
        onespecphase = 4;
        return;
    }
    if (onespecphase == 4) {
        for (int i = 0; i < N; ++i) {
            if (dists[i][b1.Position] <= 50 && i != b1.Position && !connected[i][b1.Position]) {
                unpack(bestbforone, i);
                move(bestbone, i);
                onespecphase = 5;
                return;
            }
        }
        b1.Used = true;
        b2.Used = true;
        return;
    }
    if (onespecphase == 5) {
        teampack(bestbforone, bestbone, 50 - b2.Bricks);
        onespecphase = 6;
        return;
    }
    if (onespecphase == 6) {
        for (int i = 0; i < B; ++i) {
            if (bridgemen[i].Position == bestbridgepos && bridgemen[i].OriTarget == bestonenode && bridgemen[i].Bricks == 50) {
                for (int n = 0; n < N; ++n) {
                    if (connected[bridgemen[i].Position][n]) {
                        for (int j = 0; j < N; ++j) {
                            if (bridgemen[j].Position == n && bridgemen[j].BridgeFrom == bridgemen[j].Position && bridgemen[j].BridgeTo == bestbridgepos) {
                                teampack(i, j, 10);
                                bestbone = i;
                                bestbforone = j;
                                onespecphase = 7;
                                return;
                            }
                        }
                    }
                }
            }
        }
        return;
    }
    if (onespecphase == 7) {
        unpack(bestbone, bestonenode);
        b2.Used = true;
        onespecphase = 8;
        return;
    }
    if (onespecphase == 8) {
        move(bestbone, bestonenode);
        b2.Used = true;
        onespecphase = 9;
        return;
    }
    if (onespecphase == 9) {
        move(bestbone, bestbridgepos);
        b2.Used = true;
        onespecphase = 10;
        return;
    }
    if (onespecphase == 10) {
        pack(bestbone, bestonenode);
        b2.Used = true;
        onespecphase = 11;
        return;
    }
    if (onespecphase == 11) {
        if (connected[b1.Position][b2.Position]) {
            b1.Used = true;
            b2.Used = true;
        }
        else {
            teamunpack(bestbone, bestbforone, 10);
            onespecphase = 12;
        }
        return;
    }
    if (onespecphase == 12) {
        pack(bestbforone, bestbridgepos);
        b2.TeamWith = -1;
        b1.TeamWith = -1;
        b1.BridgeFrom = -1;
        b1.BridgeTo = -1;
        onespecphase = 6;
        return;
    }
}

int main() {
    cin >> N >> B >> O;

    for (int i = 0; i < N; ++i) {
        for (int j = 0; j < N; ++j) {
            connected[i][j] = false;
            cin >> dists[i][j];
        }
    }

    calcgroup();
    calcgroupdists();

    calcbfsdists();

    for (int i = 0; i < B; ++i)
        bridgemen[i].ID = i;

    for (turn = 1; turn <= 1000; turn++) {
        cin >> elapsedTime;
        for (int i = 0; i < B; ++i) {
            cin >> bridgemen[i].Position >> bridgemen[i].Bricks >> bridgemen[i].Target;
            bridgemen[i].Used = false;
            bridgemen[i].Served = false;
            bridgemen[i].OriTarget = bridgemen[i].Target;
            bridgemen[i].FakeTarget = false;
        }
        for (int i = 0; i < O; ++i)
            cin >> orders[i].From >> orders[i].To;

        if (turn == 1)
            calcone();

        output.clear();

        assigntargets();

        if (onespecphase > 0)
            handleonespec();

        calcunpack();
        calcmove();
        calcpack();

        if (turn == 1000) {
            cerr << "Result," << N << ',' << B << ',' << O << ',' << group - 1 << ',' << score << ',' << onespec << ',' << elapsedTime << endl;

            for (int i = 0; i < N; ++i)
                for (int j = i + 1; j < N; ++j)
                    if (connectedcnt[i][j] > 100)
                        cerr << "cc " << i << ' ' << j << ' ' << connectedcnt[i][j] << endl;
            cerr.flush();

#ifdef LOCAL
            this_thread::sleep_for(chrono::milliseconds(100));
#endif

        }

        bool checkstuck = false;
        for (int i = 0; i < B; ++i) {
            auto& b = bridgemen[i];
            if (b.OriTarget != -1) {
                int next = prevs[b.Position][b.Target];
                if (groups[next] != groups[b.Position]) {
                    checkstuck = true;
                    break;
                }
            }
        }

        if (checkstuck && turn > 12) {
            for (int d = 0; d <= 2; ++d) {
                int dv = d * 4;
                if (!stuck) {
                    if (output.size() == 0)
                        stuck = true;
                    else if (output.size() == saveoutput[turn % 12 + dv].size()) {
                        stuck = true;
                        for (int i = 0; i < output.size(); ++i) {
                            if (output[i] != saveoutput[turn % 12 + dv][i]) {
                                stuck = false;
                                break;
                            }
                        }
                        if (stuck && output.size() <= 2) {
                            for (int i = 0; i < N; ++i) {
                                if (bridgemen[i].Position != savebridgemen[turn % 12 + dv][i].Position) {
                                    stuck = false;
                                    break;
                                }
                            }
                        }
                    }
                }
            }
        }

        saveoutput[turn % 12] = output;
        for (int i = 0; i < B; ++i)
            savebridgemen[turn % 12][i].Position = bridgemen[i].Position;

        for (size_t i = 0; i < output.size(); ++i) {
            cout << output[i];
            if (i < output.size() - 1) {
                cout << " | ";
            }
        }
        cout << endl;
    }

    return 0;
}