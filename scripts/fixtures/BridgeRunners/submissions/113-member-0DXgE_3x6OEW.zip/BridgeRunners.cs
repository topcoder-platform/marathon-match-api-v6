﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;

class Bridgeman
{
    public int ID;
    public int Position;
    public int Target;
    public int Bricks;

    public int BridgeFrom = -1;
    public int BridgeTo = -1;
}

class Order
{
    public int From;
    public int To;
}

class Elem
{
    public int action;
    public int BridgemanID;
    public int BridgemanID2;
    public int length;
    public int islandID;
    static int g_seed = 777778;
    static int Rand(int mod)
    {
        g_seed = (214013 * g_seed + 2531011);
        return ((g_seed >> 16) & 0x7FFF) % mod;
    }
    
    public Elem() { }
    public Elem(int a, int bid, int bid2, int l, int isl)
    {
        action = a;
        BridgemanID = bid;
        BridgemanID2 = bid2;
        length = l;
        islandID = isl;
    }

    public static Elem GenerateAction(List<Bridgeman> bridgemen, int N, int B)
    {
        int action=-1;
        int BridgemanID;
        int BridgemanID2=-1;
        int length=0;
        int islandID=-1;



        action = Rand(5);
        BridgemanID = bridgemen[Rand(B)].ID;
        if (action < 3)
        {
            islandID = Rand(N);
        }
        else if (action >= 3)
        {
            islandID = Rand(N);
            Bridgeman other = bridgemen
            .Where(b => b.ID != BridgemanID)
            .OrderBy(_ => Guid.NewGuid()) // mélange aléatoire
            .FirstOrDefault();
            BridgemanID2 = other.ID;
            int lb = bridgemen.Where(b => b.ID == BridgemanID).First().Bricks;
            length = Rand(lb)+1;

        }

        Elem el = new Elem(action, BridgemanID, BridgemanID2, length, islandID);

        return el;
    

    }

    public static Elem GenerateActionFB1(int bid, List<Bridgeman> bridgemen, int N, int B)
    {
        int action = -1;
        int BridgemanID;
        int BridgemanID2 = 1000000;
        int length = 0;
        int islandID = 1000000;



        action = Rand(5);
        BridgemanID = bid;
        if (action < 3)
        {
            islandID = Rand(N);
        }
        else if (action >= 3)
        {
            islandID = Rand(N);
            Bridgeman other = bridgemen
            .Where(b => b.ID != BridgemanID)
            .OrderBy(_ => Guid.NewGuid()) // mélange aléatoire
            .FirstOrDefault();
            BridgemanID2 = other.ID;
            int lb = bridgemen.Where(b => b.ID == BridgemanID).First().Bricks;
            if(lb > 0)length = Rand(lb);
            if (length == 0) length = 1;

        }

        Elem el = new Elem(action, BridgemanID, BridgemanID2, length, islandID);

        return el;


    }

    public static Elem GenerateActionFB(int bid, List<Bridgeman> bridgemen, int N, int B, int[,] dists)
    {
        int action = Rand(5);
        int BridgemanID = bid;
        int BridgemanID2 = 1000000;
        int length = 0;
        int islandID = 1000000;

        if (action < 3)
        {
            islandID = Rand(N);
        }
        else
        {
            // pick partner
            var others = bridgemen.Where(b => b.ID != BridgemanID).ToList();
            if (others.Count == 0) { action = Rand(3); islandID = Rand(N); return new Elem(action, BridgemanID, 1000000, 0, islandID); }
            Bridgeman b1 = bridgemen.First(b => b.ID == BridgemanID);
            Bridgeman b2 = others[Rand(others.Count)];

            BridgemanID2 = b2.ID;
            int dist = dists[b1.Position, b2.Position];

            // valid dist?
            if (dist <= 1)
            {
                // impossible de faire team action quand dist <= 1
                action = Rand(3);
                islandID = Rand(N);
                return new Elem(action, BridgemanID, 1000000, 0, islandID);
            }

            int maxPrimary = Math.Min(b1.Bricks, dist - 1);                // primary ne doit pas couvrir tout seul
            int minPrimary = Math.Max(1, dist - b2.Bricks);                 // helper doit pouvoir couvrir le reste

            if (maxPrimary < minPrimary)
            {
                // aucune longueur possible -> downgrade (pas de team action réaliste)
                action = Rand(3);
                islandID = Rand(N);
                return new Elem(action, BridgemanID, 1000000, 0, islandID);
            }

            // choisir len entre minPrimary et maxPrimary
            int range = maxPrimary - minPrimary + 1;
            length = minPrimary + Rand(range); // minPrimary..maxPrimary
            islandID = Rand(N);
        }

        return new Elem(action, BridgemanID, BridgemanID2, length, islandID);
    }


}

class Player
{
    int N;
    int O;
    int B;
    int[,] dists;
    public int elapsedTime = 0;
  
    public Player() { }

    public Player(int N, int O, int B, int[,] dists)
    {
        this.N = N;
        this.O = O;
        this.B = B;
        this.dists = dists;
    }

    public List<string> Simulation(bool[,] connected, List<Bridgeman> bridgemen, List<Order> orders)
    {
        int timeLimit = 5;
        int maxt = 0;
        Stopwatch stopwatch = Stopwatch.StartNew();

        List<Elem> best_action = new List<Elem>();
        int best_score = -100000000;
        while (stopwatch.ElapsedMilliseconds < timeLimit)
        {
            List<Elem> lelem = new List<Elem>();
            HashSet<int> usedThisTurn = new HashSet<int>();
            HashSet<Tuple<int,int>> unpack_hash = new HashSet<Tuple<int, int>>();
            HashSet<Tuple<int, int>> pack_hash = new HashSet<Tuple<int, int>>();
            int score = 0;
            for (int i = 0; i < B; ++i)
            {
                if (usedThisTurn.Contains(bridgemen[i].ID)) continue;
                Elem action_elem = Elem.GenerateActionFB(bridgemen[i].ID, bridgemen, N, B, dists);

                if (action_elem.action == 0)
                {
                    Bridgeman b1 = bridgemen.Where(b => b.ID == bridgemen[i].ID).First();
                    if (connected[action_elem.islandID, b1.Position] && b1.Position != action_elem.islandID &&
                       !pack_hash.Contains(Tuple.Create(action_elem.islandID, b1.Position)))
                    {
                        lelem.Add(action_elem);
                      
                        if (b1.Target != -1)
                        {
                            score += 500 - dists[action_elem.islandID, b1.Target];

                        }
                        else
                        {
                            int mini = 1000000;
                            for(int o = 0;o < O; ++o)
                            {
                                int d = dists[b1.Position, orders[o].From];
                                if(d < mini)
                                {
                                    mini = d;
                                }
                            }
                            score += 100 - mini;
                        }
                        if (b1.Target == action_elem.islandID ) score += 10000;
                    }
                    else continue;
                }
                else if (action_elem.action == 1)
                {
                    Bridgeman b1 = bridgemen.Where(b => b.ID == bridgemen[i].ID).First();
                    if (!connected[action_elem.islandID, b1.Position] && b1.Bricks >= dists[b1.Position, action_elem.islandID] &&
                        b1.Position != action_elem.islandID && !unpack_hash.Contains(Tuple.Create(action_elem.islandID, b1.Position)))
                    {
                        unpack_hash.Add(Tuple.Create(action_elem.islandID, b1.Position));
                        unpack_hash.Add(Tuple.Create(b1.Position, action_elem.islandID));
                        lelem.Add(action_elem);
                        score += 22;
                    }
                    else continue;
                }
                else if (action_elem.action == 2)
                {
                    Bridgeman b1 = bridgemen.Where(b => b.ID == bridgemen[i].ID).First();
                    if (connected[action_elem.islandID, b1.Position] && b1.Position != action_elem.islandID &&
                        !pack_hash.Contains(Tuple.Create(action_elem.islandID, b1.Position)))
                    {
                        if (b1.Bricks + dists[action_elem.islandID, b1.Position] > 60) continue;
                        lelem.Add(action_elem);
                        pack_hash.Add(Tuple.Create(action_elem.islandID, b1.Position));
                        pack_hash.Add(Tuple.Create(b1.Position, action_elem.islandID));
                        score += dists[action_elem.islandID, b1.Position] / 2;
                    }
                    else continue;
                }
                else if (action_elem.action == 3)
                {
                    if (usedThisTurn.Contains(action_elem.BridgemanID2)) continue;
                    Bridgeman b1 = bridgemen.Where(b => b.ID == bridgemen[i].ID).First();
                    Bridgeman b2 = bridgemen.Where(b => b.ID == action_elem.BridgemanID2).First();
                    int lb1 = b1.Bricks;
                    int lb2 = b2.Bricks;

                    if ((lb1 >0) && (lb2 > 0) && (lb1 >= action_elem.length) && (lb2 >= (dists[b1.Position, b2.Position]- action_elem.length)) && ((action_elem.length+lb2)>= dists[b1.Position, b2.Position])
                        && b1.Position != b2.Position && !connected[b1.Position, b2.Position] && !unpack_hash.Contains(Tuple.Create(b1.Position, b2.Position)))
                    {
                        if (action_elem.length >= dists[b1.Position, b2.Position]) continue;
                        unpack_hash.Add(Tuple.Create(b1.Position, b2.Position));
                        unpack_hash.Add(Tuple.Create(b2.Position, b1.Position));
                        usedThisTurn.Add(action_elem.BridgemanID2);
                        lelem.Add(action_elem);
                        score += 20;
                    }
                    else continue;

                }
                else if (action_elem.action == 4)
                {
                    if (usedThisTurn.Contains(action_elem.BridgemanID2)) continue;
                    Bridgeman b1 = bridgemen.Where(b => b.ID == bridgemen[i].ID).First();
                    Bridgeman b2 = bridgemen.Where(b => b.ID == action_elem.BridgemanID2).First();
                    int lb1 = b1.Bricks;
                    int lb2 = b2.Bricks;

                    if (connected[b1.Position, b2.Position] && b1.Position != b2.Position && !pack_hash.Contains(Tuple.Create(b1.Position, b2.Position)))
                    {
                        if (action_elem.length >= dists[b1.Position, b2.Position]) continue;
                        if ((60 - lb1) < action_elem.length) continue;
                        if ((60 - lb2) < (dists[b1.Position, b2.Position] - action_elem.length)) continue;
                        pack_hash.Add(Tuple.Create(b1.Position, b2.Position));
                        pack_hash.Add(Tuple.Create(b2.Position, b1.Position));
                        usedThisTurn.Add(action_elem.BridgemanID2);
                        lelem.Add(action_elem);
                        score += 30;
                    }
                    else continue;

                }

                usedThisTurn.Add(bridgemen[i].ID);


            }

            if (score > best_score)
            {
                best_score = score;
                best_action = lelem;
            }

        }

        List<string> output = new List<string>();
        for (int i = 0; i < best_action.Count; ++i)
        {
            Elem action_elem = best_action[i];
            if (action_elem.action == 0)
            {
                output.Add("MOVE " + action_elem.BridgemanID + " " + action_elem.islandID);
                Bridgeman b1 = bridgemen.Where(b => b.ID == action_elem.BridgemanID).First();
             
            }
            else if (action_elem.action == 1)
            {
                output.Add("UNPACK " + action_elem.BridgemanID + " " + action_elem.islandID);
                Bridgeman b1 = bridgemen.Where(b => b.ID == action_elem.BridgemanID).First();
                b1.Bricks = Math.Max(0, b1.Bricks - action_elem.length);
                connected[b1.Position, action_elem.islandID] = true;
                connected[action_elem.islandID, b1.Position] = true;
            }
            else if (action_elem.action == 2)
            {
                output.Add("PACK " + action_elem.BridgemanID + " " + action_elem.islandID);
                Bridgeman b1 = bridgemen.Where(b => b.ID == action_elem.BridgemanID).First();
                b1.Bricks += action_elem.length;
                connected[b1.Position, action_elem.islandID] = false;
                connected[action_elem.islandID, b1.Position] = false;
            }
            else if (action_elem.action == 3)
            {
                output.Add("TEAMUNPACK " + action_elem.BridgemanID + " " + action_elem.BridgemanID2 + " " + action_elem.length);
                Bridgeman b1 = bridgemen.Where(b => b.ID == action_elem.BridgemanID).First();
                Bridgeman b2 = bridgemen.Where(b => b.ID == action_elem.BridgemanID2).First();
                
                /*int dist = dists[b1.Position, b2.Position];
                int len = action_elem.length;
                int lb1 = b1.Bricks;
                int lb2 = b2.Bricks;
                int neededFromB2 = dist - len;
                int total = lb1 + lb2;

                int id1 = action_elem.BridgemanID;
                int id2 = action_elem.BridgemanID2;

                // DEBUG log clair
                Console.Error.WriteLine($"TEAMUNPACK {id1} {id2} len={len} dist={dist} lb1={lb1} lb2={lb2} needB2={neededFromB2} total={total}");

                // validations détaillées
                if (len <= 0) { Console.Error.WriteLine("Invalid TEAMUNPACK: length <= 0"); continue; }
                if (b1.Position == b2.Position) { Console.Error.WriteLine("Invalid TEAMUNPACK: same position"); continue; }
                if (dist <= 0) { Console.Error.WriteLine("Invalid TEAMUNPACK: invalid distance"); continue; }
                if (len >= dist) { Console.Error.WriteLine("Invalid TEAMUNPACK: primary length >= distance (should be <)"); continue; }
                if (lb1 < len) { Console.Error.WriteLine($"Invalid TEAMUNPACK: primary ({id1}) lacks bricks ({lb1} < {len})"); continue; }
                if (lb2 < neededFromB2) { Console.Error.WriteLine($"Invalid TEAMUNPACK: partner ({id2}) lacks bricks ({lb2} < {neededFromB2})"); continue; }
                if (total < dist) { Console.Error.WriteLine($"Invalid TEAMUNPACK: not enough total ({total} < {dist})"); continue; }
                */

                b1.Bricks = Math.Max(0, b1.Bricks - action_elem.length);
                b2.Bricks = Math.Max(0, b2.Bricks - (dists[b1.Position, b2.Position] - action_elem.length));
                //Console.Error.WriteLine("--TEAMUNPACK " + action_elem.BridgemanID + " " + action_elem.BridgemanID2 + " " + action_elem.length + " " + b1.Bricks + "/" + b2.Bricks+"="+ dists[b1.Position, b2.Position]);
                connected[b1.Position, b2.Position] = true;
                connected[b2.Position, b1.Position] = true;
            }
            else if (action_elem.action == 4)
            {
                output.Add("TEAMPACK " + action_elem.BridgemanID + " " + action_elem.BridgemanID2 + " " + action_elem.length);
                Bridgeman b1 = bridgemen.Where(b => b.ID == action_elem.BridgemanID).First();
                Bridgeman b2 = bridgemen.Where(b => b.ID == action_elem.BridgemanID2).First();
                //Console.Error.WriteLine("--TEAMPACK " + action_elem.BridgemanID + " " + action_elem.BridgemanID2 + " " + action_elem.length + " " + b1.Bricks + "/" + b2.Bricks + "=" + dists[b1.Position, b2.Position] + ", " + action_elem.length + " + " + (dists[b1.Position, b2.Position] - action_elem.length));

                b1.Bricks += action_elem.length;
                b2.Bricks += dists[b1.Position, b2.Position] - action_elem.length;

                connected[b1.Position, b2.Position] = false;
                connected[b2.Position, b1.Position] = false;
            }


        }

        return output;

    }
        



}

class BridgeRunners
{
    static int g_seed = 777778;
    static int Rand(int mod)
    {
        g_seed = (214013 * g_seed + 2531011);
        return ((g_seed >> 16) & 0x7FFF) % mod;
    }

    static void Main(string[] args)
    {
        int N = int.Parse(Console.ReadLine());
        int B = int.Parse(Console.ReadLine());
        int O = int.Parse(Console.ReadLine());

        int[,] dists = new int[N, N];
        bool[,] connected = new bool[N, N];
        for (int i = 0; i < N; i++)
        {
            int[] line = Console.ReadLine().Split().Select(int.Parse).ToArray();
            for (int j = 0; j < N; j++)
            {
                dists[i, j] = line[j];
                connected[i, j] = false;
            }
        }

        Player player = new Player(N, O, B, dists);

        List<Bridgeman> bridgemen = Enumerable.Range(0, B).Select(i => new Bridgeman { ID = i }).ToList();
        for (int turn = 1; turn <= 1000; turn++)
        {
            int elapsedTime = int.Parse(Console.ReadLine());
            for (int i = 0; i < B; i++)
            {
                int[] line = Console.ReadLine().Split().Select(int.Parse).ToArray();
                bridgemen[i].Position = line[0];
                bridgemen[i].Bricks = line[1];
                bridgemen[i].Target = line[2];
            }
            List<Order> orders = new List<Order>();
            for (int i = 0; i < O; i++)
            {
                int[] line = Console.ReadLine().Split().Select(int.Parse).ToArray();
                Order o = new Order { From = line[0], To = line[1] };
                orders.Add(o);
            }

            List<string> output = player.Simulation(connected, bridgemen, orders);
            /*for (int i = 0;i < output.Count; ++i)
            {
                Console.Error.WriteLine(output[i]);
            }*/

            Console.WriteLine(string.Join(" | ", output));
        }
    }
}

