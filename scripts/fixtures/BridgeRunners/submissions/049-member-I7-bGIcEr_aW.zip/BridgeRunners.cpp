#include <bits/stdc++.h>


using namespace std;


struct Bridgeman {
    int id, pos, target, bricks;
    vector <int> path;
};

struct Order {
    int source, target;
};


int nIslands, nBridgemen, nOrders, elapsedTime;

vector <vector<int>> dist, connected;
vector <Bridgeman> bridgemen;
vector <Order> orders;


vector <int> bfs(int source, int target, int maxLen) {
    vector <int> from(nIslands, -1);
    from[source] = -2;

    queue <int> q;
    q.push(source);

    while (!q.empty()) {
        int v = q.front();
        q.pop();

        for (int u = 0; u < nIslands; u++) if (from[u] == -1 && dist[v][u] <= maxLen) {
            from[u] = v;
            q.push(u);

            if (u == target) {
                vector <int> path = {u};

                while (u != source) {
                    u = from[u];
                    path.push_back(u);
                }

                return path;
            }
        }
    }

    return {};
}

vector <string> makeTurn() {
    vector <string> output;

    for (auto &b : bridgemen) if (b.path.empty()) {
        int target = b.target;
        if (target == -1) {
            for (int i = 0; i < nOrders; i++) {
                int u = orders[i].source;
                if (target == -1 || dist[b.pos][u] < dist[b.pos][target]) {
                    target = u;
                }
            }
        }

        b.path = bfs(b.pos, target, b.bricks);
    }

    for (auto &b : bridgemen) if (!b.path.empty()) {
        assert(b.path.size() >= 2);

        if (b.path.back() != b.pos) { // PACK
            assert(b.pos == b.path[(int) b.path.size() - 2]);

            if (b.bricks != 50) {
                int u = b.path.back(), v = b.pos;
                assert(connected[u][v]);

                output.push_back("PACK " + to_string(b.id) + " " + to_string(u));
                connected[u][v] = connected[v][u] = 0;
            }

            if (b.path.size() > 2) {
                b.path.pop_back();
            } else {
                b.path.clear();
            }
        } else {
            int u = b.path[(int) b.path.size() - 2], v = b.pos;
            if (connected[u][v]) { // MOVE
                output.push_back("MOVE " + to_string(b.id) + " " + to_string(u));
            } else { // UNPACK
                output.push_back("UNPACK " + to_string(b.id) + " " + to_string(u));
                connected[u][v] = connected[v][u] = 1;
            }
        }
    }

    return output;
}

int main() {
    cin >> nIslands >> nBridgemen >> nOrders;

    dist = connected = vector <vector<int>> (nIslands, vector <int> (nIslands, 0));
    for (int i = 0; i < nIslands; i++) for (int j = 0; j < nIslands; j++) {
        cin >> dist[i][j];
        connected[i][j] = 0;
    }

    bridgemen.resize(nBridgemen);
    for (int i = 0; i < nBridgemen; i++) {
        bridgemen[i].id = i;
    }

    orders.resize(nOrders);
    for (int turn = 1; turn <= 1000; turn++) {
        cin >> elapsedTime;

        for (int i = 0; i < nBridgemen; i++) {
            cin >> bridgemen[i].pos >> bridgemen[i].bricks >> bridgemen[i].target;
        }

        for (int i = 0; i < nOrders; i++) {
            cin >> orders[i].source >> orders[i].target;
        }

        auto output = makeTurn();
        for (int i = 0; i < (int) output.size(); i++) {
            cout << output[i];
            if (i < output.size() - 1) {
                cout << " | ";
            }
        }
        cout << endl;
    }

    return 0;
}