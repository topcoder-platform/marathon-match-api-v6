import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

class BridgeRunners {

    private static int g_seed = 777778;

    private static int rand(int mod) {
        g_seed = (214013 * g_seed + 2531011);
        return ((g_seed >> 16) & 0x7FFF) % mod;
    }

    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        int N = Integer.parseInt(reader.readLine());
        int B = Integer.parseInt(reader.readLine());
        int O = Integer.parseInt(reader.readLine());

        int[][] dists = new int[N][N];
        boolean[][] connected = new boolean[N][N];
        for (int i = 0; i < N; i++) {
            String[] line = reader.readLine().split(" ");
            for (int j = 0; j < N; j++) {
                dists[i][j] = Integer.parseInt(line[j]);
            }
        }

        List<Bridgeman> bridgemen = IntStream.range(0, B)
                .mapToObj(Bridgeman::new)
                .collect(Collectors.toList());

        for (int turn = 1; turn <= 1000; turn++) {
            int elapsedTime = Integer.parseInt(reader.readLine());
            for (int i = 0; i < B; i++) {
                String[] line = reader.readLine().split(" ");
                bridgemen.get(i).position = Integer.parseInt(line[0]);
                bridgemen.get(i).bricks = Integer.parseInt(line[1]);
                bridgemen.get(i).target = Integer.parseInt(line[2]);
            }
            //List<Order> orders = new ArrayList<>();
            Order[] orders = new Order[O];
            for (int i = 0; i < O; i++) {
                String[] line = reader.readLine().split(" ");
                Order o = new Order(Integer.parseInt(line[0]), Integer.parseInt(line[1]));
                orders[i] = o;//.add(o);
            }

            List<String> output = new ArrayList<>();

            int[] takenOrders = new int[O];
            Arrays.fill(takenOrders, -1);

            for (int j = 0; j < B; j++) {
                Bridgeman b = bridgemen.get(j);
                System.err.println("b.bricks : " + b.bricks);

                if (b.bridgeFrom == -1) { // unpack

                    if (b.target == -1) {
                        int target = 0;//b.target;
                        int bestScore = Integer.MAX_VALUE;

                        for (int i = 0; i < O; i++) {
                            if (takenOrders[i] == -1 || dists[orders[i].from][b.position] < dists[orders[i].from][bridgemen.get(takenOrders[i]).position]) {
                                //if (!takenOrders[i] )
                                int score = dists[b.position][orders[i].from] + dists[orders[i].to][orders[i].from];

                                if (score < bestScore) {
                                    bestScore = score;
                                    target = i;//orders[i].from;//i
                                }
                            }
                        }
                        takenOrders[target] = j;
                        b.target = orders[target].from;
                    }

                    int bestScore = Integer.MAX_VALUE;
                    int best = -1;

                    // maintenant que j'ai une cible, creer l'edge available qui m'en rapproche le plus
                    for (int t = 0 ; t < N ; t++) {
                            if (t != b.position && !connected[b.position][t] && dists[b.position][t] <= b.bricks && dists[b.target][t] <= bestScore) {
                                bestScore = dists[b.target][t];
                                best = t;

                            }
                    }

                    if (best > -1) {

                        int t = best;//targets.get(rand(targets.size()));
                        System.err.println("distance : " + dists[b.position][t]);

                        output.add("UNPACK " + b.id + " " + t);
                        b.bridgeFrom = b.position;
                        b.bridgeTo = t;
                        connected[b.bridgeFrom][b.bridgeTo] = true;
                        connected[b.bridgeTo][b.bridgeFrom] = true;
                    }

                } else if (b.bridgeFrom == b.position) { // MOVE
                    output.add("MOVE " + b.id + " " + b.bridgeTo);
                } else { // PACK
                    output.add("PACK " + b.id + " " + b.bridgeFrom);
                    connected[b.bridgeFrom][b.bridgeTo] = false;
                    connected[b.bridgeTo][b.bridgeFrom] = false;
                    b.bridgeFrom = -1;
                    b.bridgeTo = -1;
                }
            }

            System.out.println(String.join(" | ", output));
        }
    }


    static class Bridgeman {
        int id;
        int position;
        int target;
        int bricks = 50;

        int bridgeFrom = -1;
        int bridgeTo = -1;

        public Bridgeman(int id) {
            this.id = id;
        }
    }

    static class Order {
        int from;
        int to;

        public Order(int from, int to) {
            this.from = from;
            this.to = to;
        }
    }
}