'''
java -jar tester.jar -exec "python BridgeRunners.py" -showOrders -delay 1 -seed 1

T = ターン数1000
N = 島の数 (25〜80)
B = bridgemen の数 (4〜20)
O = 同時に見える注文(order)の数 (4〜10)
D = 各島の距離行列

初期状態
    各bridgemanは橋材を50持っており、最大60まで持てる
    どの島にいるかはランダムだが、必ず移動できることは保証される

各ターンの入力
    B 行：各bridgemanの状態
        islandID:   現在地
        carry:      持っている橋材の長さ
        target:     配達先のメッセージがある場合はその島ID、なければ -1

    O 行：現在受注可能な注文
        orig:   メッセージを受け取るべき島
        dest:   配達先

各ターンの出力
    1行 "|" 区切りで出力
    命令フォーマット：
        "MOVE bridgemanID islandID":    既存の橋を渡って移動
        "UNPACK bridgemanID islandID":  現在地から islandID へ新しい橋を建設
        "PACK bridgemanID islandID":    現在地から islandID への橋を撤去
        "TEAMUNPACK bridgemanID1 bridgemanID2 length1": 
            2人のいる島間に橋を建設。1人目が length1 を、2人目が残りを担当
        "TEAMPACK bridgemanID1 bridgemanID2 length1":   
            2人のいる島間の橋を撤去。1人目が length1 を、2人目が残りを担当
        "MSG any":  |は含められない。最後のMSGだけが可視化される

補足:
    同一島から複数注文が出る場合は順番が固定
    ある島のbridgemanがメッセージを受け取った瞬間、新しい注文が即座に出現する場合がある
    同一島に複数のbridgemanがいて即時取得可能な場合はIDが最小のbridgemanが優先

'''

import sys
from random import random, seed, randrange, choice, sample
from collections import deque, defaultdict, Counter
from heapq import heapify, heappush, heappop

N = int(input())    # 島の数
M = int(input())    # エージェント数
K = int(input())    # 表示オーダー数

# 距離行列
D = [[int(i) for i in input().split()] for _ in range(N)]
LIMIT = 60

class DSU:
    def __init__(self, n):
        self._n = n
        self.parent_or_size = [-1] * n

    def merge(self, a, b):
        # assert 0 <= a < self._n
        # assert 0 <= b < self._n
        x, y = self.leader(a), self.leader(b)
        if x == y:
            return x
        if -self.parent_or_size[x] < -self.parent_or_size[y]:
            x, y = y, x
        self.parent_or_size[x] += self.parent_or_size[y]
        self.parent_or_size[y] = x
        return x

    def same(self, a, b):
        # assert 0 <= a < self._n
        # assert 0 <= b < self._n
        return self.leader(a) == self.leader(b)

    def leader(self, a):
        # assert 0 <= a < self._n
        stack = []
        while self.parent_or_size[a] >= 0:
            stack.append(a)
            a = self.parent_or_size[a]
        for i in stack:
            self.parent_or_size[i] = a
        return a

    def size(self, a):
        # assert 0 <= a < self._n
        return -self.parent_or_size[self.leader(a)]

    def groups(self):
        leader_buf = [self.leader(i) for i in range(self._n)]
        group_size = [0] * self._n
        for i in leader_buf:
            group_size[i] += 1
        result = [[] for _ in range(self._n)]
        for i in range(self._n):
            result[leader_buf[i]].append(i)
        result = [i for i in result if i]
        return result

class Agent:
    def __init__(self, id):
        self.id = id
        self.pos = 0
        self.target = -1
        self.bricks = 50
        self.bricksAll = 50
        self.nxt = -1
        self.prv = -1
        self.pair = 0
        self.task = 0
        self.used = [0]*M

    def __repr__(self):
        return f"Agent(id: {self.id}, pos: {self.pos}, target: {self.target}, bricks: {self.bricks})"

class Order:
    def __init__(self, frm, to):
        self.frm = frm
        self.to = to

    def __repr__(self):
        return f"Order(frm: {self.frm}, to: {self.to})"

class Solver:
    def __init__(self):
        self.elapsedTime = 0
        self.make_graph()
        self.make_group()
        self.make_costs()
        self.agents = [Agent(i) for i in range(M)]
        self.cnt = []
        self.orders = [Order(0, 0) for _ in range(K)]
        self.bridges = [[0]*N for _ in range(N)]        # 0:なし, 1:あり, 2:使用される
        self.pair = [[i] for i in range(M)]
        self.cancel_pair = []

    def make_graph(self):   # 距離100以内のグラフ作成
        edges = []
        self.graph = [[] for _ in range(N)]
        for i in range(N):
            for j in range(N):
                if i==j: continue
                if D[i][j]>100: continue
                self.graph[i].append((j, D[i][j]))
                edges.append((D[i][j], i, j))

        uf = DSU(N)
        total = 0
        for d, i, j in edges:
            if uf.same(i, j): continue
            uf.merge(i, j)
            total += d
        print(f"mst: {total}", file=sys.stderr)
        print(f"less: {total - 50*M}", file=sys.stderr)

    def make_group(self):   # 連結成分グループ分け構築
        self.uf = DSU(N)
        for i in range(N-1):
            for j in range(i+1, N):
                if D[i][j]>50: continue
                if self.uf.same(i, j): continue
                self.uf.merge(i, j)
                
        groups = self.uf.groups()
        leaders = [self.uf.leader(g[0]) for g in groups]

        self.group_pair = dict()    # 連結成分を渡れる島の組み合わせ
        for i in range(len(leaders)-1):
            a = leaders[i]
            for j in range(i+1, len(leaders)):
                b = leaders[j]
                self.group_pair[(a, b)] = []
                self.group_pair[(b, a)] = []
                for u in groups[i]:
                    for v, w in self.graph[u]:
                        if self.uf.leader(v)!=b: continue
                        self.group_pair[(a, b)].append((u, v))
                        self.group_pair[(b, a)].append((v, u))
        cnt = [set() for _ in range(N)]
        for key in self.group_pair:
            for u, v in self.group_pair[key]:
                cnt[u].add(key[0])
                cnt[u].add(key[1])
                cnt[v].add(key[0])
                cnt[v].add(key[1])

        # 多くの連結成分へ行ける組み合わせを代表点にする
        for key in self.group_pair:
            # self.group_pair[key].sort(reverse=True,
            #     key=lambda x: (len(cnt[x[0]])+1)*(len(cnt[x[1]])+1))
            self.group_pair[key].sort(reverse=True,
                key=lambda x: (len(cnt[x[0]])+1)+(len(cnt[x[1]])+1)*1000 - D[x[0]][x[1]])
        # print(self.group_pair, file=sys.stderr)
        
        # 連結成分のグラフと距離
        self.group_graph = [[] for _ in range(N)]
        self.group_dist = [[100]*N for _ in range(N)]
        for a in leaders:
            for b in leaders:
                if a==b: continue
                if len(self.group_pair[(a, b)])==0: continue
                self.group_graph[a].append(b)

        self.under = [50]*N

        uf = DSU(N)
        for s in leaders:
            # 連結成分間距離
            self.group_dist[s][s] = 0
            q = deque()
            q.append(s)
            while q:
                u = q.popleft()
                for v in self.group_graph[u]:
                    if self.group_dist[s][v]<100: continue
                    self.group_dist[s][v] = self.group_dist[s][u]+1
                    q.append(v)

            edges = []
            for u in range(N-1):
                if self.uf.same(u, s)==False: continue
                for v in range(u+1, N):
                    if self.uf.same(v, s)==False: continue
                    edges.append((D[u][v], u, v))
            edges.sort()
            ma = 0
            for d, u, v in edges:
                if uf.size(s)==self.uf.size(s): break
                ma = max(ma, d)
                if uf.same(u, v): continue
                uf.merge(u, v)
            self.under[s] = max(40, min(50, ma+10))
            print("min", s, self.under[s], file=sys.stderr)

        # 連結成分内下限
        limit = 40
        if self.uf.size(s)==1: limit = 40
        if self.uf.size(s)==2: limit = 45
        if self.uf.size(s)==3: limit = 47

        # 下限
        leaders.sort(key=lambda x: self.uf.size(x))
        for u in leaders:
            if self.uf.size(u)>=2: 
                self.under[u] = 50
                continue
            ma = 0
            for key in self.group_pair:
                if len(self.group_pair[key])==0: continue
                if u!=key[0]: continue
                x, y = self.group_pair[key][0]
                ma = max(ma, D[x][y]-max(
                        self.under[self.uf.leader(y)], self.under[self.uf.leader(x)]))
            # self.under[u] = min(50, max(40, self.under[u], ma))
            self.under[u] = min(50, max(limit, self.under[u], ma))
        for i in range(N):
            self.under[i] = self.under[self.uf.leader(i)]
        
        print(leaders, file=sys.stderr)
        print([self.under[u] for u in leaders], file=sys.stderr)

    def make_costs(self):   # 最短経路計算用
        self.costs = []
        for bricks in range(61):
            self.costs.append([[10000 for _ in range(N)] for _ in range(N)])
            if bricks<40: 
                self.costs[-1] = []
                continue

            for s in range(N):
                self.costs[bricks][s][s] = 0
                hq = []
                heappush(hq, (0, s))
                while hq:
                    d, u = heappop(hq)
                    if self.costs[bricks][s][u]<d: continue
                    for v, w in self.graph[u]:
                        if w>bricks+LIMIT: continue
                        if w>100: continue
                        if self.uf.same(u, v)==False:   # 連結成分が別
                            a = self.uf.leader(u)
                            b = self.uf.leader(v)
                            # print((a, b), (u, v), self.group_pair[(a, b)], file=sys.stderr)
                            # if self.group_pair[(a, b)][0] != (u, v):  continue
                        add = 3 if w<=bricks else 303
                        if self.uf.same(u, v)==False: add = 303
                        if self.costs[bricks][s][v] > d+add:
                            self.costs[bricks][s][v] = d+add
                            heappush(hq, (self.costs[bricks][s][v], v))

    def input_process(self):    # 入力処理
        self.elapsedTime = int(input())
        for a in self.agents:
            a.pos, a.bricks, a.target = [int(i) for i in input().split()]
            a.task = int(a.target>=0)
            if a.bricks>a.bricksAll:
                print(a.pos, a.id, a.bricks, a.bricksAll, file=sys.stderr)

        if len(self.cnt)==0:
            self.cnt = [0]*N
            for agent in self.agents:
                self.cnt[self.uf.leader(agent.pos)] += 1

        for order in self.orders:
            order.frm, order.to = list(map(int, input().split()))

    def matching_order(self):   # オーダー起点とエージェントのマッチング
        free = [a for a in self.agents if a.target<0]
        rate = 300   # 連結成分を跨ぐ重さ

        edges = []  # エージェントとオーダー開始位置, 最悪でも200組
        # print([a.id for a in self.agents if a.target<0], file=sys.stderr)
        for i in range(len(free)):
            pos = free[i].pos
            for j in range(len(self.orders)):
                frm = self.orders[j].frm
                to = self.orders[j].to
                bricks = max(self.under[frm], self.under[to], self.under[pos], free[i].bricksAll)
                # if self.uf.same(frm, pos):
                #     bricks = max(bricks, free[i].bricksAll)
                if free[i].nxt>=0:
                    # 今架けている橋も加味して判断
                    # edges.append((min(self.costs[free[i].bricksAll][frm][pos]+self.group_dist[frm][to]*rate,
                    #     self.costs[free[i].bricksAll][frm][free[i].nxt]+2+self.group_dist[frm][to]*rate,
                    #     self.costs[free[i].bricksAll][frm][free[i].prv]+2+self.group_dist[frm][to]*rate), i, j))
                    edges.append((min(
                        self.costs[bricks][frm][pos]+1+self.group_dist[frm][to]*rate,
                        self.costs[bricks][frm][free[i].nxt]+2+self.group_dist[frm][to]*rate,
                        self.costs[bricks][frm][free[i].prv]+2+self.group_dist[frm][to]*rate), i, j))
                else:
                    # 周りに架かっている橋も加味
                    # score = self.costs[free[i].bricksAll][frm][pos]+self.group_dist[frm][to]*rate
                    # for v, w in self.graph[pos]:
                    #     if self.bridges[pos][v]==0: continue
                    #     score = min(score, self.costs[free[i].bricksAll][frm][v]+1+
                    #                 self.group_dist[frm][to]*rate)
                    score = self.costs[bricks][frm][pos]+self.group_dist[frm][to]*rate
                    for v, w in self.graph[pos]:
                        if self.bridges[pos][v]==0: continue
                        score = min(score, self.costs[bricks][frm][v]+1+self.group_dist[frm][to]*rate)
                    edges.append((score, i, j))
                
        edges.sort()
        used = set()
        for c, i, j in edges:
            if free[i].target>=0: continue
            if j in used: continue
            free[i].target = self.orders[j].frm
            used.add(j)

        for agent in self.agents:
            a = self.uf.leader(agent.pos)
            if agent.target<0:
                best = self.uf.size(a)
                for v in self.group_graph[a]:
                    score = self.uf.size(v)
                    if best<score:
                        best = score
                        agent.target = v
            else:
                b = self.uf.leader(agent.target)
                if a==b: continue
                if self.group_dist[a][b]>1:     # 直接行き来出来ない場合
                    best = 10000
                    for v in self.group_graph[a]:
                        score = self.group_dist[v][b]*1000 - self.uf.size(v)
                        # score = self.group_dist[v][b]*1000
                        if best>score:
                            best = score
                            agent.target = v
        
        # print(self.agents, file=sys.stderr)

    def matching_agent(self):   # エージェント同士のマッチング

        for i in range(len(self.pair))[::-1]:   # 既存のペア解消判定
            if len(self.pair[i])==1: continue
            if self.pair[i][0] not in self.cancel_pair and self.pair[i][1] not in self.cancel_pair: continue
            # if self.pair[i][0] not in self.cancel_pair or self.pair[i][1] not in self.cancel_pair: continue
            self.agents[self.pair[i][0]].pair = 0
            self.agents[self.pair[i][1]].pair = 0
            self.pair.append([self.pair[i].pop()])

        for i in range(len(self.pair))[::-1]:   # 既存のペア解消判定
            if len(self.pair[i])==1: continue
            agent1 = self.agents[self.pair[i][0]]
            agent2 = self.agents[self.pair[i][1]]
            # if (self.uf.same(agent1.pos, agent2.pos)==False or 
            # 一つ離れ or 橋がある
            if (self.group_dist[self.uf.leader(agent1.pos)][self.uf.leader(agent2.pos)]==1 or 
                self.bridges[agent1.pos][agent2.pos]): continue
            # 連結成分内で橋がある
            if (self.group_dist[self.uf.leader(agent1.pos)][self.uf.leader(agent2.pos)]==0 and
                self.bridges[agent1.pos][agent2.pos]): continue
            self.agents[self.pair[i][0]].pair = 0
            self.agents[self.pair[i][1]].pair = 0
            self.pair.append([self.pair[i].pop()])
        self.cancel_pair = []
                    
        for _ in range(M):  # 連結成分を移動したいエージェント同士のマッチング
            best = 100000
            bi, bj = -1, -1
            for i in range(len(self.pair)-1, 0, -1):
                # print(self.agents[self.pair[i][0]].id, self.pair[i], self.agents[self.pair[i][0]].target, file=sys.stderr)
                if len(self.pair[i])>=2: continue
                if self.agents[self.pair[i][0]].target<0: continue
                agent1 = self.agents[self.pair[i][0]]
                frm1 = self.uf.leader(agent1.pos)
                to1 = self.uf.leader(agent1.target)
                if agent1.bricksAll<self.under[frm1]: continue
                # print(agent1.id, frm1, to1, file=sys.stderr)
                if frm1==to1: continue
                for j in range(i-1, -1, -1):
                    if len(self.pair[j])>=2: continue
                    if self.agents[self.pair[j][0]].target<0: continue
                    agent2 = self.agents[self.pair[j][0]]
                    frm2 = self.uf.leader(agent2.pos)
                    to2 = self.uf.leader(agent2.target)
                    if agent2.bricksAll<self.under[frm2]: continue
                    if frm2==frm1: continue
                    if frm1!=to2 or frm2!=to1: continue 
                    cap = agent1.bricksAll+agent2.bricksAll
                    if self.group_dist[frm1][frm2]>1: continue
                    
                    bst = 100000
                    cap = agent1.bricksAll + agent2.bricksAll
                    for t1, t2 in self.group_pair[(self.uf.leader(agent1.pos), self.uf.leader(agent2.pos))]:
                        if D[t1][t2]>cap: continue
                        s1 = self.costs[agent1.bricksAll][agent1.pos][t1]
                        if agent1.nxt==agent1.pos:
                            s1 = min(s1+1, self.costs[agent1.bricksAll][agent1.prv][t1]+2)
                        if agent1.prv==agent1.pos:
                            s1 = min(s1+1, self.costs[agent1.bricksAll][agent1.nxt][t1]+2)
                        s2 = self.costs[agent2.bricksAll][agent2.pos][t2]
                        if agent2.nxt==agent2.pos:
                            s2 = min(s2+1, self.costs[agent2.bricksAll][agent2.prv][t2]+2)
                        if agent2.prv==agent2.pos:
                            s2 = min(s2+1, self.costs[agent2.bricksAll][agent2.nxt][t2]+2)
                        # score = max(s1, s2)
                        score = s1+s2
                        if bst>score:
                            bst = score
                            target1, target2 = t1, t2
                    if bst == 100000: continue
                    score = bst

                    # score = max(self.costs[agent1.pos][target1], self.costs[agent2.pos][target2])
                    # score = self.costs[50][agent1.pos][agent2.pos]
                    if best>score:
                        best = score
                        bi, bj = i, j
            if bi>=0:
                if bj > bi:
                    bi, bj = bj, bi
                self.pair[bj].append(self.pair[bi][0])
                self.pair[bi] = self.pair[-1]
                self.pair.pop()
                self.agents[self.pair[bj][0]].pair = 1
                self.agents[self.pair[bj][1]].pair = 1
            else: break

        for _ in range(M):  # 連結成分を移動したいエージェント優先
            best = 100000
            bi, bj = -1, -1
            for i in range(len(self.pair)):
                if len(self.pair[i])>=2: continue
                agent1 = self.agents[self.pair[i][0]]
                frm1 = self.uf.leader(agent1.pos)
                to1 = self.uf.leader(agent1.target)
                if agent1.bricksAll<self.under[frm1]: continue
                if frm1==to1: continue
                if agent1.task==0: continue
                for j in range(len(self.pair)):
                    if i==j: continue
                    if len(self.pair[j])>=2: continue
                    agent2 = self.agents[self.pair[j][0]]
                    frm2 = self.uf.leader(agent2.pos)
                    to2 = self.uf.leader(agent2.target) if agent2.target>=0 else -1
                    if agent2.bricksAll<self.under[frm2]: continue
                    if frm2==to2 and agent2.task==1: continue
                    # if frm2==to2: continue
                    if to1!=frm2: continue      # 行きたい連結成分にいるか

                    bst = 100000
                    cap = agent1.bricksAll + agent2.bricksAll
                    for t1, t2 in self.group_pair[(self.uf.leader(agent1.pos), self.uf.leader(agent2.pos))]:
                        if D[t1][t2]>cap: continue
                        s1 = self.costs[agent1.bricksAll][agent1.pos][t1]
                        if agent1.nxt==agent1.pos:
                            s1 = min(s1+1, self.costs[agent1.bricksAll][agent1.prv][t1]+2)
                        if agent1.prv==agent1.pos:
                            s1 = min(s1+1, self.costs[agent1.bricksAll][agent1.nxt][t1]+2)
                        s2 = self.costs[agent2.bricksAll][agent2.pos][t2]
                        if agent2.nxt==agent2.pos:
                            s2 = min(s2+1, self.costs[agent2.bricksAll][agent2.prv][t2]+2)
                        if agent2.prv==agent2.pos:
                            s2 = min(s2+1, self.costs[agent2.bricksAll][agent2.nxt][t2]+2)
                        # score = max(s1, s2)
                        score = s1+s2
                        if bst>score:
                            bst = score
                            target1, target2 = t1, t2
                    if bst == 100000: continue
                    score = bst
                    # if (agent2.target>=0):
                    #     score += self.costs[agent2.bricksAll][target2][agent2.target]+3
                    # score += self.costs[agent2.bricksAll][target1][agent1.target]+3
                    # if agent2.task==1:
                    #     if (self.costs[agent2.bricksAll][agent1.target][target2]+
                    #         self.costs[agent2.bricksAll][agent2.target][target2]+
                    #         score>
                    #         self.costs[agent2.bricksAll][agent2.pos][agent2.target]): continue
                    # score = bst

                    # score = self.costs[50][agent1.pos][agent2.pos]

                    if best>score:
                        best = score
                        bi, bj = i, j
            if bi>=0:
                if bj > bi:
                    bi, bj = bj, bi
                self.pair[bj].append(self.pair[bi][0])
                self.pair[bi] = self.pair[-1]
                self.pair.pop()
                self.agents[self.pair[bj][0]].pair = 1
                self.agents[self.pair[bj][1]].pair = 1
            else: break

        for _ in range(M):  # 連結成分内で即時2人橋でswap
            best = 0
            bi, bj = -1, -1
            for i in range(len(self.pair)):
                if len(self.pair[i])>=2: continue
                agent1 = self.agents[self.pair[i][0]]
                if agent1.target<0: continue
                if agent1.prv>=0: continue
                frm1 = self.uf.leader(agent1.pos)
                to1 = self.uf.leader(agent1.target)
                for j in range(len(self.pair)):
                    if i==j: continue
                    if len(self.pair[j])>=2: continue
                    agent2 = self.agents[self.pair[j][0]]
                    if agent2.target<0: continue
                    if agent2.prv>=0: continue
                    # if agent1.prv>=0 and agent2.prv<0: continue
                    # if agent1.prv<0 and agent2.prv>=0: continue
                    if D[agent1.pos][agent2.pos]<=50: continue
                    cap = agent1.bricksAll+agent2.bricksAll
                    if cap<D[agent1.pos][agent2.pos]: continue
                    frm2 = self.uf.leader(agent2.pos)
                    to2 = self.uf.leader(agent2.target) if agent2.target>=0 else frm2
                    if frm1!=frm2: continue
                    if self.group_dist[frm1][frm2]>1: continue
                    # お互い距離が縮む時のみ連結成分内swap
                    if (self.costs[agent1.bricksAll][agent1.target][agent2.pos]+3>=
                        self.costs[agent1.bricksAll][agent1.target][agent1.pos]): continue
                    if (self.costs[agent2.bricksAll][agent2.target][agent1.pos]+3>=
                        self.costs[agent2.bricksAll][agent2.target][agent2.pos]): continue
                    score = 0
                    score += self.costs[agent1.bricksAll][agent1.target][agent2.pos]-self.costs[agent1.bricksAll][agent1.target][agent1.pos]+3
                    score += self.costs[agent2.bricksAll][agent2.target][agent1.pos]-self.costs[agent2.bricksAll][agent2.target][agent2.pos]+3
                    if best>score:
                        best = score
                        bi, bj = i, j
            if bi>=0:
                if bj > bi:
                    bi, bj = bj, bi
                self.pair[bj].append(self.pair[bi][0])
                self.pair[bi] = self.pair[-1]
                self.pair.pop()
                self.agents[self.pair[bj][0]].pair = 1
                self.agents[self.pair[bj][1]].pair = 1
            else: break

        # (橋の数, タスク有無)でソート
        self.pair.sort(key=lambda x: 
            sum(int(self.agents[i].prv>=0)*10 + int(self.agents[i].target>=0) for i in x))

        # print(self.pair, file=sys.stderr)

    def solo_action(self, x, tar=-1):
        # print("solo_action", x, file=sys.stderr)
        agent = self.agents[x]
        frm = self.uf.leader(agent.pos)
        to = self.uf.leader(agent.target)
        
        bv = -1     # 次移動したい島
        if agent.target>=0:     # 目的地が無い場合処理しない
            # print(frm, to, self.group_dist[frm][to], file=sys.stderr)
            if frm!=to:     # 隣接へ行くために近づいておく
                target1, target2 = self.group_pair[(frm, to)][0]
                if agent.pos==target1:
                    agent.target = target2
                else:
                    agent.target = target1
            best = self.costs[agent.bricksAll][agent.target][agent.pos]
            if agent.prv>=0: best += 1
            for v, w in self.graph[agent.pos]:
                if (w > agent.bricksAll and self.bridges[agent.pos][v]==0): continue
                if (w > agent.bricksAll and agent.prv>=0): continue
                if (self.costs[agent.bricksAll][agent.target][v]>=
                    self.costs[agent.bricksAll][agent.target][agent.pos]): continue
                # 連結成分最後の１つ
                if (self.uf.same(agent.pos, v)==False and 
                    self.cnt[self.uf.leader(agent.pos)]<1): continue

                add = 0 if self.bridges[agent.pos][v]>=1 else 2
                if best > self.costs[agent.bricksAll][agent.target][v]+add:
                    best = self.costs[agent.bricksAll][agent.target][v]+add
                    bv = v
                    
        # 自分が作った橋をそのまま帰れば良いパターン
        if agent.prv>=0 and agent.prv==bv:
            agent.prv, agent.nxt = agent.nxt, agent.prv
        # 橋の所有権を人と入れ替える
        if bv>=0 and agent.nxt!=bv and agent.nxt==agent.pos and agent.pair==0:
            for a in self.agents:
                if a.id==x: continue
                if a.pos!=agent.pos: continue   # 現在位置
                if a.pos!=a.nxt: continue       # 移動後でない
                if a.pair==1: continue          # ペアでの橋
                if agent.bricks+D[a.prv][a.nxt]>LIMIT: continue
                if agent.bricks+D[a.prv][a.nxt]<self.under[agent.pos]: continue
                if a.bricks+D[agent.prv][agent.nxt]>LIMIT: continue
                if a.bricks+D[agent.prv][agent.nxt]<self.under[a.pos]: continue
                agent.bricksAll += D[a.prv][a.nxt]-D[agent.prv][agent.nxt]
                a.bricksAll -= D[a.prv][a.nxt]-D[agent.prv][agent.nxt]
                # print(agent.bricksAll, a.bricksAll, file=sys.stderr)

                agent.nxt = a.prv
                a.nxt = agent.prv
                agent.prv = agent.pos
                a.prv = a.pos
                break

        # 自分の橋が経路でない時は回収する
        if agent.nxt>=0 and agent.nxt!=bv: bv = -1
        if bv<0: 
            if agent.prv<0 and agent.nxt<0: return
            if agent.prv==agent.pos:    # 橋を架けていて渡る前
                if self.bridges[agent.pos][agent.nxt]>=2: return
                self.output.append(f"PACK {agent.id} {agent.nxt}")
                self.used[x] = 1
                self.bridges[agent.pos][agent.nxt] = 0
                self.bridges[agent.nxt][agent.pos] = 0
                agent.bricks += D[agent.prv][agent.nxt]
                # self.cancel_pair.append(x)
                agent.nxt = -1
                agent.prv = -1
                return
            if agent.nxt==agent.pos:               # 橋を架けていて渡った後
                if self.bridges[agent.pos][agent.prv]>=2: return
                self.output.append(f"PACK {agent.id} {agent.prv}")
                self.used[x] = 1
                self.bridges[agent.pos][agent.prv] = 0
                self.bridges[agent.prv][agent.pos] = 0
                agent.bricks += D[agent.prv][agent.nxt]
                # self.cancel_pair.append(x)
                agent.nxt = -1
                agent.prv = -1
                return

        # 仕事をしていないエージェントに自分へ向けて橋を架けさせる
        if self.bridges[agent.pos][bv]==0 and agent.nxt<0:
            for pair in self.pair:
                if x in pair: break
                if len(pair)>=2: continue
                for y in pair:
                    if self.used[y]: continue
                    if self.agents[y].pos!=bv: continue
                    if self.agents[y].prv>=0: continue
                    if D[agent.pos][bv]>self.agents[y].bricksAll: continue
                    self.agents[y].prv = self.agents[y].pos
                    self.agents[y].nxt = agent.pos
                    self.output.append(f"UNPACK {self.agents[y].id} {self.agents[y].nxt}")
                    self.used[y] = 1
                    self.bridges[self.agents[y].pos][self.agents[y].nxt] = 1
                    self.bridges[self.agents[y].nxt][self.agents[y].pos] = 1
                    self.agents[y].bricks -= D[self.agents[y].prv][self.agents[y].nxt]
                    break
                else: continue
                break
        
        # 橋を利用
        if self.bridges[agent.pos][bv]>=1 and (agent.nxt<0 or agent.nxt==bv):
            self.cnt[self.uf.leader(agent.pos)] -= 1
            self.cnt[self.uf.leader(bv)] += 1
            self.output.append(f"MOVE {agent.id} {bv}")
            self.used[x] = 1
            self.cancel_pair.append(x)
            agent.pos = bv
            return

        # 橋を架ける
        agent.prv = agent.pos
        agent.nxt = bv
        self.output.append(f"UNPACK {agent.id} {agent.nxt}")
        self.used[x] = 1
        self.bridges[agent.pos][agent.nxt] = 1
        self.bridges[agent.nxt][agent.pos] = 1
        agent.bricks -= D[agent.prv][agent.nxt]

    def pair_action(self, x, y):
        # print("pair_action", x, y, file=sys.stderr)
        agent1 = self.agents[x]
        agent2 = self.agents[y]

        # 二人で架けた橋の撤去
        # print(D[0][19], file=sys.stderr)
        if (self.bridges[agent1.pos][agent2.pos]==1 and 
                agent1.prv==agent2.pos and agent2.prv==agent1.pos):
            self.used[x] = 1
            self.used[y] = 1
            self.bridges[agent1.pos][agent2.pos] = 0
            self.bridges[agent2.pos][agent1.pos] = 0
            total = agent1.bricksAll+agent2.bricksAll
            ave = total//2
            
            # 連結成分内
            if self.uf.same(agent1.pos, agent2.pos):
            # if False:
                bricks = agent1.bricksAll - agent1.bricks
                self.output.append(f"TEAMPACK {agent1.id} {agent2.id} {bricks}")
                agent2.bricks = agent2.bricksAll
                agent1.bricks = agent1.bricksAll

            # 同じsize
            # elif self.uf.size(agent1.pos)==self.uf.size(agent2.pos):
            elif False:
                if agent1.bricks <= agent2.bricks:
                    # bricks1 = max(self.under[agent1.pos], agent1.bricks)
                    bricks1 = max(self.under[agent1.pos], min(agent1.bricks, ave))
                    bricks2 = max(self.under[agent2.pos], agent2.bricks)
                    harf = (total-bricks1-bricks2)//2
                    bricks = (bricks1+harf)-agent1.bricks
                    
                    self.output.append(f"TEAMPACK {agent1.id} {agent2.id} {bricks}")
                    agent2.bricks += D[agent1.pos][agent2.pos]-bricks
                    agent1.bricks += bricks
                else:
                    # bricks1 = max(self.under[agent1.pos], agent1.bricks)
                    bricks1 = max(self.under[agent1.pos], min(agent1.bricks, ave))
                    bricks2 = max(self.under[agent2.pos], agent2.bricks)
                    harf = (total-bricks1-bricks2)//2
                    bricks = (bricks2+harf)-agent2.bricks
                    
                    self.output.append(f"TEAMPACK {agent2.id} {agent1.id} {bricks}")
                    agent1.bricks += D[agent1.pos][agent2.pos]-bricks
                    agent2.bricks += bricks
            elif self.uf.size(agent1.pos)>=self.uf.size(agent2.pos):
                # bricks2 = max(self.under[agent2.pos], agent2.bricks)
                bricks2 = max(self.under[agent2.pos], min(agent1.bricks, min(agent1.bricksAll, agent2.bricksAll)-5))
                bricks1 = min(LIMIT, total - bricks2)
                
                bricks = max(0, bricks1 - agent1.bricks)
                self.output.append(f"TEAMPACK {agent1.id} {agent2.id} {bricks}")
                agent2.bricks += D[agent1.pos][agent2.pos]-bricks
                agent1.bricks += bricks
                
            else:
                # bricks1 = max(self.under[agent1.pos], agent1.bricks)
                bricks1 = max(self.under[agent1.pos], min(agent1.bricks, min(agent1.bricksAll, agent2.bricksAll)-5))
                bricks2 = min(LIMIT, total - bricks1)
                
                bricks = max(0, bricks2 - agent2.bricks)
                self.output.append(f"TEAMPACK {agent2.id} {agent1.id} {bricks}")
                agent1.bricks += D[agent1.pos][agent2.pos]-bricks
                agent2.bricks += bricks
                # print(total, agent1.bricks, agent2.bricks, file=sys.stderr)
            agent1.bricksAll = agent1.bricks
            agent2.bricksAll = agent2.bricks
            agent1.prv = -1
            agent2.prv = -1
            agent1.nxt = -1
            agent2.nxt = -1
            agent1.pair = 0
            agent2.pair = 0
            self.cancel_pair.append(x)
            self.cancel_pair.append(y)
            return

        # 連結成分を渡るための良い感じの場所を見つける
        target1, target2 = agent1.pos, agent2.pos
        if self.uf.same(agent1.pos, agent2.pos)==False:
            bst = 100000
            cap = agent1.bricksAll + agent2.bricksAll
            for t1, t2 in self.group_pair[(self.uf.leader(agent1.pos), self.uf.leader(agent2.pos))]:
                if D[t1][t2]>cap: continue
                s1 = self.costs[agent1.bricksAll][agent1.pos][t1]
                if agent1.nxt==agent1.pos:
                    s1 = min(s1+1, self.costs[agent1.bricksAll][agent1.prv][t1]+2)
                if agent1.prv==agent1.pos:
                    s1 = min(s1+1, self.costs[agent1.bricksAll][agent1.nxt][t1]+2)
                s2 = self.costs[agent2.bricksAll][agent2.pos][t2]
                if agent2.nxt==agent2.pos:
                    s2 = min(s2+1, self.costs[agent2.bricksAll][agent2.prv][t2]+2)
                if agent2.prv==agent2.pos:
                    s2 = min(s2+1, self.costs[agent2.bricksAll][agent2.nxt][t2]+2)
                # if agent1.target>=0:
                #     s2 += self.costs[agent2.bricksAll][t2][agent1.target]
                # if agent2.target>=0:
                #     s1 += self.costs[agent1.bricksAll][t1][agent2.target]
                # score = max(s1, s2)
                score = s1+s2
                if bst>score:
                    bst = score
                    target1, target2 = t1, t2
            # target1, target2 = self.group_pair[(self.uf.leader(agent1.pos), self.uf.leader(agent2.pos))][0]
        # if {x, y} == {1, 3}:
        #     print(x, y, target1, target2, file=sys.stderr)
        if agent1.pos!=target1 or agent2.pos!=target2:  # 連結成分を渡るための場所へ各自移動
            if agent1.pos!=target1 or agent1.nxt>=0:
                agent1.target = target1
            if agent2.pos!=target2 or agent2.nxt>=0:
                agent2.target = target2
            # agent1.target = target1
            # agent2.target = target2
            self.solo_action(x, target2)
            self.solo_action(y, target1)
            return
            
        # swap地点で最後の橋撤去処理
        if (agent1.nxt>=0 and agent1.nxt!=agent2.pos) or (agent2.nxt>=0 and agent2.nxt!=agent1.pos):
            # if agent1.pos!=target1 or agent1.nxt>=0:
            #     agent1.target = target1
            # if agent2.pos!=target2 or agent2.nxt>=0:
            #     agent2.target = target2
            agent1.target = target1
            agent2.target = target2
            self.solo_action(x, target2)
            self.solo_action(y, target1)
            return
        
        # 橋がある
        if self.bridges[agent1.pos][agent2.pos]>=1:
            self.output.append(f"MOVE {agent1.id} {agent2.pos}")
            self.output.append(f"MOVE {agent2.id} {agent1.pos}")
            self.used[x] = 1
            self.used[y] = 1
            agent1.pos, agent2.pos = agent2.pos, agent1.pos
            if agent1.prv<0:
                self.cancel_pair.append(x)
                self.cancel_pair.append(y)
            return

        # 二人で橋を作る
        agent1.prv = agent1.pos
        agent1.nxt = agent2.pos
        agent2.prv = agent2.pos
        agent2.nxt = agent1.pos
        total = agent1.bricks+agent2.bricks
        bricks = min(D[agent1.pos][agent2.pos], 
            min(agent1.bricks, D[agent1.pos][agent2.pos]*agent1.bricks//total+1))
        self.output.append(f"TEAMUNPACK {agent1.id} {agent2.id} {bricks}")
        self.used[x] = 1
        self.used[y] = 1
        self.bridges[agent1.pos][agent2.pos] = 1
        self.bridges[agent2.pos][agent1.pos] = 1
        agent2.bricks -= D[agent1.pos][agent2.pos]-bricks
        agent1.bricks -= bricks
        agent1.pair = 1
        agent2.pair = 1

    def action(self):
        self.used = [0]*M
        self.output = []
        for pair in self.pair:
            if len(pair)>=2:   # 連結成分を跨ぐペア
                self.pair_action(pair[0], pair[1])
            else:
                self.solo_action(pair[0])

    def post_processing(self):
        for i in range(N):
            for j in range(N):
                if self.bridges[i][j]>=2:
                    self.bridges[i][j] = 1

def main():
    solver = Solver()

    for turn in range(1000):
        # print([a.bricks for a in solver.agents], file=sys.stderr)
        # print([a for a in solver.agents], file=sys.stderr)
        solver.input_process()
        solver.matching_order()
        solver.matching_agent()
        solver.action()
        # solver.post_processing()
        
        # solver.output.append(f"MSG {','.join(map(str, solver.pair))}")
        print(" | ".join(solver.output))
        # print(" | ".join(solver.output), file=sys.stderr)

if __name__ == "__main__":
    main()