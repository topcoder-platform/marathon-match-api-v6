import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

class BridgeRunners {
    private static int g_seed = 777778;
    private static final int INF = 100000000;

    public static int[] hungarian(int[][] cost) {
        int n = cost.length;       // lignes (sources)
        int m = cost[0].length;    // colonnes (cibles, avec padding)
        int[] u = new int[n + 1];
        int[] v = new int[m + 1];
        int[] p = new int[m + 1];
        int[] way = new int[m + 1];

        for (int i = 1; i <= n; i++) {
            p[0] = i;
            int j0 = 0;
            int[] minv = new int[m + 1];
            boolean[] used = new boolean[m + 1];
            Arrays.fill(minv, INF);
            Arrays.fill(used, false);

            do {
                used[j0] = true;
                int i0 = p[j0], delta = INF, j1 = 0;
                for (int j = 1; j <= m; j++) {
                    if (!used[j]) {
                        int cur = cost[i0 - 1][j - 1] - u[i0] - v[j];
                        if (cur < minv[j]) {
                            minv[j] = cur;
                            way[j] = j0;
                        }
                        if (minv[j] < delta) {
                            delta = minv[j];
                            j1 = j;
                        }
                    }
                }
                for (int j = 0; j <= m; j++) {
                    if (used[j]) {
                        u[p[j]] += delta;
                        v[j] -= delta;
                    } else {
                        minv[j] -= delta;
                    }
                }
                j0 = j1;
            } while (p[j0] != 0);

            do {
                int j1 = way[j0];
                p[j0] = p[j1];
                j0 = j1;
            } while (j0 != 0);
        }

        int[] assignment = new int[n]; // -1 si pas assigned
        Arrays.fill(assignment, -1);

        for (int j = 1; j <= m; j++) {
            if (p[j] != 0 && p[j] - 1 < n && j - 1 < m) {
                assignment[p[j] - 1] = (j - 1);
            }
        }
        return assignment;
    }

    private static int rand(int mod) {
        g_seed = (214013 * g_seed + 2531011);
        return ((g_seed >> 16) & 0x7FFF) % mod;
    }

    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        int N = Integer.parseInt(reader.readLine());
        int B = Integer.parseInt(reader.readLine());
        int O = Integer.parseInt(reader.readLine());

        int[][] dists = new int[N][N];
        boolean[][] connected = new boolean[N][N];
        for (int i = 0; i < N; i++) {
            String[] line = reader.readLine().split(" ");
            for (int j = 0; j < N; j++) {
                dists[i][j] = Integer.parseInt(line[j]);
            }
        }

        List<Bridgeman> bridgemen = IntStream.range(0, B)
                .mapToObj(Bridgeman::new)
                .collect(Collectors.toList());

        for (int turn = 1; turn <= 1000; turn++) {
            int elapsedTime = Integer.parseInt(reader.readLine());
            for (int i = 0; i < B; i++) {
                String[] line = reader.readLine().split(" ");
                bridgemen.get(i).position = Integer.parseInt(line[0]);
                bridgemen.get(i).bricks = Integer.parseInt(line[1]);
                bridgemen.get(i).target = Integer.parseInt(line[2]);
            }
            //List<Order> orders = new ArrayList<>();
            Order[] orders = new Order[O];
            for (int i = 0; i < O; i++) {
                String[] line = reader.readLine().split(" ");
                Order o = new Order(Integer.parseInt(line[0]), Integer.parseInt(line[1]));
                orders[i] = o;//.add(o);
            }

            List<String> output = new ArrayList<>();

            //int[] takenOrders = new int[O];
            //Arrays.fill(takenOrders, -1);
            if (turn < 6) {
            int[][] padded;
            if (B >= O) {
                // on pad avec colonnes fictives
                padded = new int[B][B];
                for (int i = 0; i < B; i++) {
                    Arrays.fill(padded[i], INF);
                    for (int j = 0; j < O; j++) {
                        padded[i][j] = dists[bridgemen.get(i).position][orders[j].from] + dists[orders[j].to][orders[j].from];
                    }
                }
            } else {
                padded = new int[O][O];
                for (int i = 0; i < O; i++) {
                    Arrays.fill(padded[i], INF);
                    for (int j = 0; j < B; j++) {
                        padded[i][j] = dists[bridgemen.get(j).position][orders[i].from] + dists[orders[i].to][orders[i].from];
                    }
                }
            }

            int[] res = hungarian(padded);
            /*for (int j = 0; j < res.length; j++)
                System.err.print(res[j]+" ");
            System.err.println(" ");*/
            //System.exit(0);


            for (int j = 0; j < B; j++) {
                Bridgeman b = bridgemen.get(j);
                //System.err.println("b.bricks : " + b.bricks);

                if (b.bridgeFrom == -1) { // unpack
                    if (b.target == -1) {
                        int target = res[j];

                        //if (target == -1) {
                        if (target >= O) {// == INF) {
                            b.target = 0; //ile du milieu pour mieux rebondir
                            /*for (int i = 0; i < O; i++) {
                                int score = dists[b.position][orders[i].from] + dists[orders[i].to][orders[i].from];

                                if (score < bestScore) {
                                    bestScore = score;
                                    target = i;//orders[i].from;//i
                                }
                            }*/
                        } else {
                            b.target = orders[target].from;
                        }
                    }

                    int bestScore = Integer.MAX_VALUE;
                    int best = -1;

                    // maintenant que j'ai une cible, creer l'edge available qui m'en rapproche le plus
                    for (int t = 0; t < N; t++) {
                        if (t != b.position && !connected[b.position][t] && dists[b.position][t] <= b.bricks && dists[b.target][t] <= bestScore) {
                            bestScore = dists[b.target][t];
                            best = t;

                        }
                    }

                    if (best > -1) {

                        int t = best;//targets.get(rand(targets.size()));
                        //System.err.println("distance : " + dists[b.position][t]);

                        output.add("UNPACK " + b.id + " " + t);
                        b.bridgeFrom = b.position;
                        b.bridgeTo = t;
                        connected[b.bridgeFrom][b.bridgeTo] = true;
                        connected[b.bridgeTo][b.bridgeFrom] = true;
                    }

                } else if (b.bridgeFrom == b.position) { // MOVE
                    output.add("MOVE " + b.id + " " + b.bridgeTo);
                } else { // PACK
                    output.add("PACK " + b.id + " " + b.bridgeFrom);
                    connected[b.bridgeFrom][b.bridgeTo] = false;
                    connected[b.bridgeTo][b.bridgeFrom] = false;
                    b.bridgeFrom = -1;
                    b.bridgeTo = -1;
                }
            }
        } else {

                int[] takenOrders = new int[O];
                Arrays.fill(takenOrders, -1);

                for (int j = 0; j < B; j++) {
                    Bridgeman b = bridgemen.get(j);
                    System.err.println("b.bricks : " + b.bricks);

                    if (b.bridgeFrom == -1) { // unpack
                        if (b.target == -1) {
                            int target = -1;//0;//b.target;
                            int bestScore = Integer.MAX_VALUE;

                            for (int i = 0; i < O; i++) {
                                if (takenOrders[i] == -1 || dists[orders[i].from][b.position] < dists[orders[i].from][bridgemen.get(takenOrders[i]).position]) {
                                    //if (!takenOrders[i] )
                                    int score = dists[b.position][orders[i].from] + dists[orders[i].to][orders[i].from];

                                    if (score < bestScore) {
                                        bestScore = score;
                                        target = i;//orders[i].from;//i
                                    }
                                }
                            }

                            if (target == -1) {
                                b.target = 0; //ile du milieu pour mieux rebondir
                            /*for (int i = 0; i < O; i++) {
                                int score = dists[b.position][orders[i].from] + dists[orders[i].to][orders[i].from];

                                if (score < bestScore) {
                                    bestScore = score;
                                    target = i;//orders[i].from;//i
                                }
                            }*/
                            } else {

                                if (takenOrders[target] == -1 || dists[orders[target].from][bridgemen.get(j).position] < dists[orders[target].from][bridgemen.get(takenOrders[target]).position])
                                    takenOrders[target] = j;
                                b.target = orders[target].from;
                            }
                        }

                        int bestScore = Integer.MAX_VALUE;
                        int best = -1;

                        // maintenant que j'ai une cible, creer l'edge available qui m'en rapproche le plus
                        for (int t = 0 ; t < N ; t++) {
                            if (t != b.position && !connected[b.position][t] && dists[b.position][t] <= b.bricks && dists[b.target][t] <= bestScore) {
                                bestScore = dists[b.target][t];
                                best = t;

                            }
                        }

                        if (best > -1) {

                            int t = best;//targets.get(rand(targets.size()));
                            System.err.println("distance : " + dists[b.position][t]);

                            output.add("UNPACK " + b.id + " " + t);
                            b.bridgeFrom = b.position;
                            b.bridgeTo = t;
                            connected[b.bridgeFrom][b.bridgeTo] = true;
                            connected[b.bridgeTo][b.bridgeFrom] = true;
                        }

                    } else if (b.bridgeFrom == b.position) { // MOVE
                        output.add("MOVE " + b.id + " " + b.bridgeTo);
                    } else { // PACK
                        output.add("PACK " + b.id + " " + b.bridgeFrom);
                        connected[b.bridgeFrom][b.bridgeTo] = false;
                        connected[b.bridgeTo][b.bridgeFrom] = false;
                        b.bridgeFrom = -1;
                        b.bridgeTo = -1;
                    }
                }



            }

            System.out.println(String.join(" | ", output));
        }
    }


    static class Bridgeman {
        int id;
        int position;
        int target;
        int bricks = 50;

        int bridgeFrom = -1;
        int bridgeTo = -1;

        public Bridgeman(int id) {
            this.id = id;
        }
    }

    static class Order {
        int from;
        int to;

        public Order(int from, int to) {
            this.from = from;
            this.to = to;
        }
    }
}