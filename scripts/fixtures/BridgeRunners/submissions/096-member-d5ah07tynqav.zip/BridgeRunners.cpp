#include <bits/stdc++.h>
using namespace std;

struct Bridgeman {
    int ID=-1, Position=-1, Bricks=0;
    int TargetInInput=-1;   // -1: no cargo, >=0 delivering to dest
    int BridgeFrom=-1, BridgeTo=-1; // crossing state; -1 when idle
    int AssignedOrder=-1;   // index into visible orders (FETCH); reset every turn
};

struct Order { int From=-1, To=-1; bool claimed=false; };

static const int INF = 1e9;
static const int MAX_CARRY = 50;
static int TURN = 0;

/*** 実効グラフ: 既存橋は無制限、未架橋は w<=cap なら使用可 ***/
int next_hop_effective(int N, int s, int t, int cap,
                       const vector<vector<int>>& w,
                       const vector<vector<bool>>& connected) {
    if (s == t) return s;
    vector<int> d(N, INF), par(N, -1);
    d[s] = 0;
    using P = pair<int,int>;
    priority_queue<P, vector<P>, greater<P>> pq;
    pq.emplace(0, s);
    while (!pq.empty()) {
        auto [cd, u] = pq.top(); pq.pop();
        if (cd != d[u]) continue;
        for (int v = 0; v < N; ++v) {
            if (u == v) continue;
            bool ok = connected[u][v] || (w[u][v] <= cap);
            if (!ok) continue;
            int nd = cd + w[u][v];
            if (nd < d[v]) { d[v] = nd; par[v] = u; pq.emplace(nd, v); }
        }
    }
    if (d[t] == INF) return -1;
    int cur = t, prev = par[cur];
    if (prev == -1) return -1;
    while (prev != -1 && prev != s) { cur = prev; prev = par[cur]; }
    return (prev == s ? cur : -1);
}

int shortest_dist_effective(int N, int s, int t, int cap,
                            const vector<vector<int>>& w,
                            const vector<vector<bool>>& connected) {
    if (s == t) return 0;
    vector<int> d(N, INF);
    d[s] = 0;
    using P = pair<int,int>;
    priority_queue<P, vector<P>, greater<P>> pq;
    pq.emplace(0, s);
    while (!pq.empty()) {
        auto [cd, u] = pq.top(); pq.pop();
        if (cd != d[u]) continue;
        for (int v = 0; v < N; ++v) {
            if (u == v) continue;
            bool ok = connected[u][v] || (w[u][v] <= cap);
            if (!ok) continue;
            int nd = cd + w[u][v];
            if (nd < d[v]) { d[v] = nd; pq.emplace(nd, v); }
        }
    }
    return d[t];
}

vector<int> reconstruct_path_effective(int N, int s, int t, int cap,
                                       const vector<vector<int>>& w,
                                       const vector<vector<bool>>& connected) {
    if (s < 0 || t < 0) return {};
    if (s == t) return {s};
    vector<int> d(N, INF), par(N, -1);
    d[s] = 0;
    using P = pair<int,int>;
    priority_queue<P, vector<P>, greater<P>> pq;
    pq.emplace(0, s);
    while (!pq.empty()) {
        auto [cd, u] = pq.top(); pq.pop();
        if (cd != d[u]) continue;
        for (int v = 0; v < N; ++v) {
            if (u == v) continue;
            bool ok = connected[u][v] || (w[u][v] <= cap);
            if (!ok) continue;
            int nd = cd + w[u][v];
            if (nd < d[v]) { d[v] = nd; par[v] = u; pq.emplace(nd, v); }
        }
    }
    if (d[t] == INF) return {};
    vector<int> path; path.push_back(s);
    int cur = t, prev = par[cur];
    while (prev != -1) { path.push_back(cur); cur = prev; prev = par[cur]; }
    reverse(path.begin(), path.end());
    return path;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int N,B,O;
    if (!(cin >> N >> B >> O)) return 0;

    vector<vector<int>> w(N, vector<int>(N));
    for (int i=0;i<N;++i) for (int j=0;j<N;++j) cin >> w[i][j];

    // 既存橋（我々の操作で張ったもの）
    vector<vector<bool>> connected(N, vector<bool>(N, false));

    vector<Bridgeman> bm(B);
    for (int i=0;i<B;++i) bm[i].ID = i;

    vector<Order> orders(O);

    auto reset_order_claims = [&](vector<Order>& os){
        for (auto &od: os) od.claimed = false;
    };

    auto log_orders = [&](const vector<Order>& os){
        cerr << "[T" << TURN << "] ORDERS(" << os.size() << "):";
        for (size_t i=0;i<os.size();++i) {
            cerr << " (" << os[i].From << "->" << os[i].To << (os[i].claimed? ",claimed":"") << ")";
        }
        cerr << "\n";
    };

    auto log_route_plan = [&](int i, int start, int goal, const string& phase){
        int cap = bm[i].Bricks; // 新設の上限（既存橋は無制限利用）
        auto path = reconstruct_path_effective(N, start, goal, cap, w, connected);
        if (path.empty()) {
            cerr << "[T" << TURN << "] BM#" << i << " " << phase
                 << " route start=" << start << " goal=" << goal
                 << " : UNREACHABLE (cap=" << cap << ", uses connected=yes)\n";
        } else {
            cerr << "[T" << TURN << "] BM#" << i << " " << phase
                 << " route " << start << " -> ";
            for (size_t k=1;k<path.size();++k) {
                cerr << path[k] << (k+1<path.size()? " -> " : "");
            }
            cerr << "  (edges=" << (int)path.size()-1 << ", cap=" << cap << ")\n";
        }
    };

    auto try_assign_fetch = [&](int i, vector<Order>& os){
        if (bm[i].TargetInInput != -1) return; // delivering
        if (bm[i].AssignedOrder != -1) return;
        int pos = bm[i].Position;
        int cap = bm[i].Bricks;
        int best = -1, bestDist = INF;
        for (int k=0;k<(int)os.size();++k) {
            if (os[k].claimed) continue;
            int d = shortest_dist_effective(N, pos, os[k].From, cap, w, connected);
            if (d < bestDist) { bestDist = d; best = k; }
        }
        if (best != -1 && bestDist < INF) {
            os[best].claimed = true;
            bm[i].AssignedOrder = best;
            cerr << "[T" << TURN << "] BM#" << i << " ASSIGN FETCH order("
                 << os[best].From << "->" << os[best].To << "), dist=" << bestDist
                 << " (cap="<<cap<<", connected usable)\n";
            log_route_plan(i, pos, os[best].From, "FETCH");
        } else {
            cerr << "[T" << TURN << "] BM#" << i << " FETCH unreachable now (cap="<<cap<<", even with connected)\n";
        }
    };

    auto detect_deliver_start = [&](int i){
        if (bm[i].TargetInInput != -1) {
            int pos = bm[i].Position, goal = bm[i].TargetInInput;
            cerr << "[T" << TURN << "] BM#" << i << " DELIVER target=" << goal << "\n";
            log_route_plan(i, pos, goal, "DELIVER");
        }
    };

    // 他BMが使いそうな辺（UNPACK/MOVE予定）を予約しておく
    auto build_reserved = [&](vector<vector<bool>>& reserved){
        reserved.assign(N, vector<bool>(N, false));
        for (int i=0;i<B;++i){
            int a=bm[i].BridgeFrom, b=bm[i].BridgeTo;
            if (a!=-1 && b!=-1){
                reserved[a][b]=reserved[b][a]=true;
            }
        }
    };

    auto try_scavenge_pack = [&](int i, vector<string>& cmds,
                                 vector<vector<bool>>& reserved)->bool{
        int cur = bm[i].Position;
        int free_cap = MAX_CARRY - bm[i].Bricks;
        if (free_cap <= 0) return false;
        int bestV = -1, bestLen = -1;
        for (int v=0; v<N; ++v) {
            if (v==cur) continue;
            if (!connected[cur][v]) continue;
            if (reserved[cur][v]) continue; // 他BMの予定辺は壊さない
            int need = w[cur][v];
            if (need <= free_cap) {
                if (need > bestLen) { bestLen = need; bestV = v; }
            }
        }
        if (bestV != -1) {
            cmds.push_back("PACK " + to_string(bm[i].ID) + " " + to_string(bestV));
            connected[cur][bestV] = connected[bestV][cur] = false;
            cerr << "[T" << TURN << "] BM#" << i << " SCAVENGE PACK "
                 << cur << "<-" << bestV << " need=" << bestLen
                 << " free=" << free_cap << " carry=" << bm[i].Bricks << "\n";
            return true;
        }
        return false;
    };

    for (TURN=1; TURN<=1000; ++TURN) {
        int elapsed;
        if (!(cin >> elapsed)) break;

        for (int i=0;i<B;++i) {
            cin >> bm[i].Position >> bm[i].Bricks >> bm[i].TargetInInput;
        }
        orders.assign(O, {});
        for (int i=0;i<O;++i) cin >> orders[i].From >> orders[i].To;

        // ---- DEBUG: input snapshot ----
        cerr << "================ TURN " << TURN << " ================\n";
        cerr << "[T" << TURN << "] elapsed=" << elapsed << " ms\n";
        for (int i=0;i<B;++i) {
            cerr << "[T" << TURN << "] BM#" << i
                 << " pos=" << bm[i].Position
                 << " bricks=" << bm[i].Bricks
                 << " testerTarget=" << bm[i].TargetInInput
                 << " state(" << bm[i].BridgeFrom << "->" << bm[i].BridgeTo << ")"
                 << " assignedOrder=" << bm[i].AssignedOrder
                 << "\n";
        }

        reset_order_claims(orders);
        log_orders(orders);

        // AssignedOrder はこのターン限定
        for (int i=0;i<B;++i) bm[i].AssignedOrder = -1;

        // 空手のBMにFETCH割当（実効グラフで評価）
        for (int i=0;i<B;++i) try_assign_fetch(i, orders);

        // 配達モードのルート表示
        for (int i=0;i<B;++i) detect_deliver_start(i);

        // 予約辺（他BMのBridgeFrom/To）を記録
        vector<vector<bool>> reserved;
        build_reserved(reserved);

        vector<string> cmds; cmds.reserve(B);

        for (int i=0;i<B;++i) {
            int id = bm[i].ID;
            int cur = bm[i].Position;

            // stale self-loop state cleanup
            if (bm[i].BridgeFrom == cur && bm[i].BridgeTo == cur) {
                bm[i].BridgeFrom = bm[i].BridgeTo = -1;
            }

            // 目標決定
            int goal = -1;
            string phase = "-";
            if (bm[i].TargetInInput != -1) {
                goal = bm[i].TargetInInput; phase = "DELIVER";
            } else if (bm[i].AssignedOrder != -1) {
                goal = orders[bm[i].AssignedOrder].From; phase = "FETCH";
            } else {
                // 仕事が無い → ブリック回収を試みる
                if (!try_scavenge_pack(i, cmds, reserved)) {
                    cerr << "[T" << TURN << "] BM#" << i << " IDLE (no job)\n";
                }
                continue;
            }

            if (cur == goal) {
                cerr << "[T" << TURN << "] BM#" << i << " at goal=" << goal
                     << " (" << phase << ") waiting server-side change.\n";
                continue;
            }

            // 3-step per edge: UNPACK -> MOVE -> PACK
            if (bm[i].BridgeFrom == -1) {
                int cap = bm[i].Bricks;
                int nh = next_hop_effective(N, cur, goal, cap, w, connected);
                if (nh == -1) {
                    if (!try_scavenge_pack(i, cmds, reserved)) {
                        cerr << "[T" << TURN << "] BM#" << i << " " << phase
                             << " unreachable even with connected+cap; wait\n";
                    }
                    continue;
                }
                if (nh == cur) { // 念のため自己ループ回避
                    cerr << "[T" << TURN << "] BM#" << i << " skip self-hop\n";
                    continue;
                }
                if (!connected[cur][nh]) {
                    int need = w[cur][nh];
                    if (need <= bm[i].Bricks) {
                        cmds.push_back("UNPACK " + to_string(id) + " " + to_string(nh));
                        bm[i].BridgeFrom = cur; bm[i].BridgeTo = nh;
                        connected[cur][nh] = connected[nh][cur] = true;
                        reserved[cur][nh] = reserved[nh][cur] = true; // 以後壊さない
                        cerr << "[T" << TURN << "] BM#" << i << " UNPACK "
                             << cur << "->" << nh << " need=" << need
                             << " bricks=" << bm[i].Bricks << "\n";
                    } else {
                        cerr << "[T" << TURN << "] BM#" << i << " CANNOT UNPACK (need="
                             << need << ", bricks=" << bm[i].Bricks << ")\n";
                    }
                } else {
                    bm[i].BridgeFrom = cur; bm[i].BridgeTo = nh;
                    reserved[cur][nh] = reserved[nh][cur] = true;
                    cerr << "[T" << TURN << "] BM#" << i << " READY TO MOVE existing "
                         << cur << "->" << nh << "\n";
                }
            }
            else if (bm[i].BridgeFrom == bm[i].Position) {
                // ★ MOVE前に橋の存在を再検証。無ければUNPACKに切替。
                int from = bm[i].BridgeFrom, to = bm[i].BridgeTo;
                if (from == to) { bm[i].BridgeFrom = bm[i].BridgeTo = -1; continue; }
                if (connected[from][to]) {
                    cmds.push_back("MOVE " + to_string(id) + " " + to_string(to));
                    cerr << "[T" << TURN << "] BM#" << i << " MOVE " << from << "->" << to << "\n";
                } else {
                    int need = w[from][to];
                    if (need <= bm[i].Bricks) {
                        cmds.push_back("UNPACK " + to_string(id) + " " + to_string(to));
                        connected[from][to] = connected[to][from] = true;
                        reserved[from][to] = reserved[to][from] = true;
                        cerr << "[T" << TURN << "] BM#" << i << " RE-UNPACK "
                             << from << "->" << to << " need=" << need
                             << " bricks=" << bm[i].Bricks << " (bridge missing before MOVE)\n";
                        // 次ターンにMOVEされる
                    } else {
                        // 足りないなら回収試行→失敗なら状態クリアして次の経路を引き直し
                        cerr << "[T" << TURN << "] BM#" << i
                             << " cannot RE-UNPACK (need="<<need<<", bricks="<<bm[i].Bricks<<")\n";
                        if (!try_scavenge_pack(i, cmds, reserved)) {
                            bm[i].BridgeFrom = bm[i].BridgeTo = -1;
                            cerr << "[T" << TURN << "] BM#" << i << " reset state; will replan next turn\n";
                        }
                    }
                }
            }
            else {
                // PACK（回収できるときだけ）。無理なら橋は残して状態クリア
                int from = bm[i].BridgeFrom, to = bm[i].BridgeTo;
                int need = w[from][to];
                int free_cap = MAX_CARRY - bm[i].Bricks;
                if (need <= free_cap) {
                    if (connected[from][to]) {
                        cmds.push_back("PACK " + to_string(id) + " " + to_string(from));
                        connected[from][to] = connected[to][from] = false;
                        cerr << "[T" << TURN << "] BM#" << i << " PACK "
                             << from << "<-" << to << " need=" << need
                             << " carry=" << bm[i].Bricks << " free=" << free_cap << "\n";
                    } else {
                        cerr << "[T" << TURN << "] BM#" << i << " WARN missing bridge "
                             << from << "<->" << to << "\n";
                    }
                } else {
                    cerr << "[T" << TURN << "] BM#" << i << " SKIP PACK (need="
                         << need << ">free=" << free_cap << ") keep bridge\n";
                }
                bm[i].BridgeFrom = bm[i].BridgeTo = -1;
            }
        }

        // === グローバル詰み検知：このターンに1つもアクションが出せない場合 → 全員の内部目的地をクリア ===
        if (cmds.empty()) {
            for (int i=0;i<B;++i) {
                bm[i].AssignedOrder = -1;
                bm[i].BridgeFrom = bm[i].BridgeTo = -1;
            }
            cout << "MSG reset\n";
            cerr << "[T" << TURN << "] OUT: MSG reset (clear all internal goals; reassign next turn)\n";
            continue; // 次ターンで再割当
        }

        // 出力
        for (size_t i=0;i<cmds.size();++i) {
            if (i) cout << " | ";
            cout << cmds[i];
        }
        cout << "\n";
        cerr << "[T" << TURN << "] OUT: ";
        for (size_t i=0;i<cmds.size();++i) {
            if (i) cerr << " | ";
            cerr << cmds[i];
        }
        cerr << "\n";
    }
    return 0;
}
