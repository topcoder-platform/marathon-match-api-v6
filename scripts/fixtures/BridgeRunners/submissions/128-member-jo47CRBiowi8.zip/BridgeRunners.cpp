#include <iostream>
#include <vector>
#include <string>
#include <sstream>
#include <numeric>
#include <algorithm>
#include <utility>



class Bridgeman {
public:
    int ID;
    int Position;
    int Target;
    int Bricks;
    int BridgeFrom = -1;
    int BridgeTo = -1;
};

class Order {
public:
    int From;
    int To;
};

static int g_seed = 777778;
static int Rand(int mod) {
    g_seed = (214013 * g_seed + 2531011);
    return ((g_seed >> 16) & 0x7FFF) % mod;
}



int main() {
    int N, B, O;
    std::cin >> N >> B >> O;

    int dists[N][N];
    bool connected[N][N];

    for (int i = 0; i < N; ++i) {
        for (int j = 0; j < N; ++j) {
            connected[i][j]=false;
            std::cin >> dists[i][j];

        }
    }


    Bridgeman bridgemen[B];
    for (int i = 0; i < B; ++i) {
        bridgemen[i].ID = i;
    }

    for (int turn = 1; turn <= 1000; turn++) {
        int elapsedTime;
        std::cin >> elapsedTime;
        for (int i = 0; i < B; ++i) {
            std::cin >> bridgemen[i].Position >> bridgemen[i].Bricks >> bridgemen[i].Target;
        }
        std::vector<Order> orders(O);
        for (int i = 0; i < O; ++i) {
            std::cin >> orders[i].From >> orders[i].To;
        }

        std::vector<std::string> output;
        for (auto& b : bridgemen) {
            if (b.BridgeFrom == -1) { // unpack
                std::vector<int> targets;
                for (int t = 0; t < N; ++t) {
                    bool found = 0;

                    if (t != b.Position && !connected[b.Position][t] && dists[b.Position][t] <= b.Bricks ) {

                            targets.push_back(t);
                    }

                }
                if (!targets.empty()) {
                    bool found = 0;
                    int t =-1;
                    std::vector<std::pair<int,int>> evals;
                    
                    for (auto tar:targets){
                        for (auto& o: orders){
                            if (b.Position == o.From && tar==o.To){
                                t = tar;
                                found=1;
                                evals.push_back({o.To,0});
                            }
                            
                            else if (tar == o.From) {
                                int distObj = dists[o.From][b.Position];
                                 evals.push_back({o.From,distObj*2});
                                 found=1;
                            }
                        }
                        if (b.Target !=-1){
                            int distObj = dists[tar][b.Target];
                            evals.push_back({tar,distObj});
                            found=1;
                        }
                         
                    }
                    sort(evals.begin(),evals.end(),[](auto& a , auto& b){return a.second < b.second;});

                    if (found){
                        t = evals[0].first;
                    }
                    else {
                        t = targets[Rand(targets.size())];
                    }

                    output.push_back("UNPACK " + std::to_string(b.ID) + " " + std::to_string(t));
                    b.BridgeFrom = b.Position;
                    b.BridgeTo = t;
                    connected[b.BridgeFrom][b.BridgeTo] = true;
                    connected[b.BridgeTo][b.BridgeFrom] = true;
                }
            } else if (b.BridgeFrom == b.Position) { // MOVE
                output.push_back("MOVE " + std::to_string(b.ID) + " " + std::to_string(b.BridgeTo));
            } else { // PACK
                output.push_back("PACK " + std::to_string(b.ID) + " " + std::to_string(b.BridgeFrom));
                connected[b.BridgeFrom][b.BridgeTo] = false;
                connected[b.BridgeTo][b.BridgeFrom] = false;
                b.BridgeFrom = -1;
                b.BridgeTo = -1;
            }
        }

        for (size_t i = 0; i < output.size(); ++i) {
            std::cout << output[i];
            if (i < output.size() - 1) {
                std::cout << " | ";
            }
        }
        std::cout << std::endl;
    }

    return 0;
}