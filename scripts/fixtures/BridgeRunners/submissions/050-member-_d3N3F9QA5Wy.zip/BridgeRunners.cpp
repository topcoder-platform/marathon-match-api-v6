#include <bits/stdc++.h>


using namespace std;


const int N_TURNS = 1000;
const int BRICKS_ONE = 50;
const int BRICKS_TWO = 100;
const int INF = 1 << 30;


struct Bridgeman {
    int id, pos, target, bricks, waiting = 0;
    vector <tuple<int,int,int,bool>> path;
};

struct Order {
    int source, target;
};


int nIslands, nBridgemen, nOrders, nComps, elapsedTime;

vector <vector<int>> dist, connected[N_TURNS];
vector <Bridgeman> bridgemen;
vector <Order> orders;

vector <int> comp;
vector <vector<int>> compDist;

vector <pair<int,int>> plansTeamUnpack[N_TURNS], plansCompMove[N_TURNS], plansTeamPack[N_TURNS];
vector <int> plansStopWaiting[N_TURNS];
set <pair<int,int>> futureCompBridges;


vector <tuple<int,int,int,bool>> bfs(int source, int tStart, int target, int maxLen) {
    assert(tStart < N_TURNS);

    vector <int> from(nIslands, -1), minTime(nIslands, N_TURNS);
    minTime[source] = tStart;

    set <pair<int,int>> q;
    q.insert({tStart, source});

    while (!q.empty()) {
        auto [t, v] = *q.begin();
        q.erase(q.begin());

        assert(t < N_TURNS);

        if (t > minTime[v]) {
            continue;
        }

        if (v == target) {
            vector <tuple<int,int,int,bool>> path;

            while (v != source) {
                bool build = !connected[minTime[v] - 1][from[v]][v];
                path.push_back({from[v], v, minTime[v] - build - 1, build});
                v = from[v];
            }

            return path;
        }

        for (int u = 0; u < nIslands; u++) if (dist[v][u] <= maxLen) {
            int d;
            if (connected[t][v][u]) {
                d = 1;
            } else if (t < N_TURNS - 1 && connected[t + 1][v][u]) {
                d = 2;
            } else {
                d = 3;
            }

            int tNew = t + d;
            if (tNew < minTime[u]) {
                from[u] = v;
                minTime[u] = tNew;

                q.insert({tNew, u});
            }
        }
    }

    return {};
}

void dfsComp(int v, int c) {
    comp[v] = c;

    for (int u = 0; u < nIslands; u++) if (comp[u] == -1 && dist[u][v] <= BRICKS_ONE) {
        dfsComp(u, c);
    }
}

void updateConnected(vector <tuple<int,int,int,bool>> &path) {
    for (auto [u, v, tMove, build] : path) {
        if (build) {
            for (int t = tMove - 1; t <= min(tMove + 1, N_TURNS - 1); t++) {
                connected[t][u][v] = connected[t][v][u] = 1;
            }
        } else {
            assert(connected[tMove][u][v]);
        }
    }
}

void planCompExchange(int t, int uLongBest, int vLongBest, int gainLongBest, const vector <int> &bridgemenStuck) {
    int iLong = -1, jLong = -1;
    for (int i = 0; i < nIslands; i++) if (comp[i] == uLongBest) {
        for (int j = 0; j < nIslands; j++) if (comp[j] == vLongBest && dist[i][j] <= BRICKS_TWO) {
            iLong = i, jLong = j;
        }
    }

    assert(iLong != -1);

    vector <int> uStuck, vStuck;
    for (int id : bridgemenStuck) {
        int cSource = comp[bridgemen[id].pos], cTarget = comp[bridgemen[id].target];
        assert(cSource != cTarget);

        if (cSource == uLongBest && compDist[vLongBest][cTarget] < compDist[uLongBest][cTarget]) {
            uStuck.push_back(id);
        } else if (cSource == vLongBest && compDist[uLongBest][cTarget] < compDist[vLongBest][cTarget]) {
            vStuck.push_back(id);
        }
    }

    assert(uStuck.size() + vStuck.size() == gainLongBest);

    auto ensureNonEmpty = [&](int c, vector <int> &stuck) {
        if (stuck.empty()) {
            for (auto &b : bridgemen) if (comp[b.pos] == c && b.path.empty() && !b.waiting) {
                stuck.push_back(b.id);
                break;
            }
        }
    };

    ensureNonEmpty(uLongBest, uStuck);
    ensureNonEmpty(vLongBest, vStuck);

    if (!uStuck.empty() && !vStuck.empty()) {
        auto processStuck = [&](int target, vector <int> &stuck) -> tuple <int,int,int> {
            int idFirst = -1, tFirst = INF, tLast = t;
            for (int i = 0; i < (int) stuck.size(); i++) {
                int id = stuck[i];

                assert(comp[bridgemen[id].pos] == comp[target]);
                assert(!bridgemen[id].waiting);

                bridgemen[id].waiting = 1;

                int tHere = t;
                if (bridgemen[id].pos != target) {
                    bridgemen[id].path = bfs(bridgemen[id].pos, t, target, bridgemen[id].bricks);
                    if (bridgemen[id].path.empty()) {
                        swap(stuck[i--], stuck.back());
                        stuck.pop_back();

                        continue;
                    }

                    auto [u, v, tMove, build] = bridgemen[id].path[0];
                    tHere = tMove + 1 + build;

                    updateConnected(bridgemen[id].path);
                }

                if (tHere < tFirst) {
                    idFirst = id, tFirst = tHere;
                }

                tLast = max(tLast, tHere);
            }

            return {idFirst, tFirst, tLast};
        };

        auto [iId, iFirst, iLast] = processStuck(iLong, uStuck);
        auto [jId, jFirst, jLast] = processStuck(jLong, vStuck);

        int tUnpack = max(iFirst, jFirst);
        int tMove = max({iLast, jLast, tUnpack + 1});
        int tPack = tMove + 1;

        if (tPack < N_TURNS) {
            futureCompBridges.insert(minmax(uLongBest, vLongBest));
            plansTeamUnpack[tUnpack].push_back({iId, jId});

            for (int id : uStuck) {
                plansCompMove[tMove].push_back({id, jLong});
                plansStopWaiting[tPack].push_back(id);
            }

            for (int id : vStuck) {
                plansCompMove[tMove].push_back({id, iLong});
                plansStopWaiting[tPack].push_back(id);
            }

            plansTeamPack[tPack].push_back({iId, jId});
        }
    }
}

vector <string> makeTurn(int t) {
    vector <string> output;

    vector <int> bridgemenStuck;
    for (auto &b : bridgemen) if (b.path.empty() && b.target != -1 && !b.waiting) {
        if (comp[b.pos] != comp[b.target]) {
            bridgemenStuck.push_back(b.id);
            continue;
        }

        b.path = bfs(b.pos, t, b.target, b.bricks);
        if (!b.path.empty()) {
            updateConnected(b.path);
        }
    }

    int uLongBest = -1, vLongBest = -1, gainLongBest = 0;
    for (int u = 0; u < nComps; u++) for (int v = u + 1; v < nComps; v++) {
        if (compDist[u][v] == 1 && !futureCompBridges.count(minmax(u, v))) {
            int gain = 0;
            for (int id : bridgemenStuck) {
                int cSource = comp[bridgemen[id].pos], cTarget = comp[bridgemen[id].target];
                assert(cSource != cTarget);

                gain += (
                    (cSource == u && compDist[v][cTarget] < compDist[u][cTarget]) ||
                    (cSource == v && compDist[u][cTarget] < compDist[v][cTarget])
                );
            }

            if (gain > gainLongBest) {
                uLongBest = u, vLongBest = v, gainLongBest = gain;
            }
        }
    }

    if (gainLongBest >= 1) {
        planCompExchange(t, uLongBest, vLongBest, gainLongBest, bridgemenStuck);
    }

    vector <int> bridgemenLeft;
    for (auto &b : bridgemen) if (b.path.empty() && b.target == -1 && !b.waiting) {
        bridgemenLeft.push_back(b.id);
    }

    vector <int> orderTaken(nOrders, 0);
    while (true) {
        int idBest = -1, orderBest = -1, costBest = INF;
        for (int id : bridgemenLeft) {
            for (int i = 0; i < nOrders; i++) if (!orderTaken[i]) {
                auto pathSource = bfs(bridgemen[id].pos, t, orders[i].source, bridgemen[id].bricks);
                if (pathSource.empty()) {
                    continue;
                }

                auto [uLast, vLast, tMoveLast, buildLast] = pathSource[0];
                int tNext = tMoveLast + 1 + buildLast;

                auto pathTarget = bfs(orders[i].source, tNext, orders[i].target, bridgemen[id].bricks);
                if (pathTarget.empty()) {
                    continue;
                }

                int cost = tNext;
                if (cost < costBest) {
                    idBest = id, orderBest = i, costBest = cost;
                }
            }
        }

        if (idBest == -1) {
            break;
        }

        auto path = bfs(
            bridgemen[idBest].pos, t, orders[orderBest].source, bridgemen[idBest].bricks
        );
        assert(!path.empty());

        path.erase(path.begin(), path.end() - 1);
        updateConnected(path);

        bridgemen[idBest].path = path;
        bridgemenLeft.erase(find(bridgemenLeft.begin(), bridgemenLeft.end(), idBest));

        orderTaken[orderBest] = 1;
    }

    auto addMoves = [&](const string &type, vector <pair<int,int>> &plans) {
        for (auto [i, v] : plans) {
            output.push_back(type + " " + to_string(i) + " " + to_string(v));
        }
    };

    auto addTeamMoves = [&](const string &type, vector <pair<int,int>> &plans) {
        for (auto [i, j] : plans) {
            output.push_back("TEAM" + type + " " + to_string(i) + " " + to_string(j) + " " + to_string(BRICKS_ONE));
        }
    };

    vector <pair<int,int>> plansUnpack, plansMove, plansPack;
    for (auto &b : bridgemen) if (!b.path.empty()) {
        auto [u, v, tMove, build] = b.path.back();
        if (t == tMove) {
            plansMove.push_back({b.id, v});
        } else if (build && b.pos == u) {
            plansUnpack.push_back({b.id, v});
        } else if (build && b.pos == v) {
            plansPack.push_back({b.id, u});
        }

        if (t == tMove + build) {
            b.path.pop_back();
        }
    }

    addMoves("UNPACK", plansUnpack);
    addTeamMoves("UNPACK", plansTeamUnpack[t]);

    addMoves("MOVE", plansMove);
    addMoves("MOVE", plansCompMove[t]);

    addMoves("PACK", plansPack);
    addTeamMoves("PACK", plansTeamPack[t]);

    for (auto [i, j] : plansTeamPack[t]) {
        auto p = minmax(comp[bridgemen[i].pos], comp[bridgemen[j].pos]);
        assert(futureCompBridges.count(p));

        futureCompBridges.erase(p);
    }

    for (int i : plansStopWaiting[t]) {
        assert(bridgemen[i].waiting);
        bridgemen[i].waiting = 0;
    }

    return output;
}

int main() {
    cin >> nIslands >> nBridgemen >> nOrders;

    dist.resize(nIslands, vector <int> (nIslands, 0));
    for (int i = 0; i < nIslands; i++) for (int j = 0; j < nIslands; j++) {
        cin >> dist[i][j];
    }

    comp.resize(nIslands, -1);

    nComps = 0;
    for (int i = 0; i < nIslands; i++) if (comp[i] == -1) {
        dfsComp(i, nComps++);
    }

    compDist.resize(nComps, vector <int> (nComps, INF));
    for (int i = 0; i < nComps; i++) {
        compDist[i][i] = 0;
    }

    for (int i = 0; i < nIslands; i++) for (int j = i + 1; j < nIslands; j++) {
        if (comp[i] != comp[j] && dist[i][j] <= BRICKS_TWO) {
            compDist[comp[i]][comp[j]] = compDist[comp[j]][comp[i]] = 1;
        }
    }

    for (int k = 0; k < nComps; k++) for (int i = 0; i < nComps; i++) for (int j = 0; j < nComps; j++) {
        compDist[i][j] = min(compDist[i][j], compDist[i][k] + compDist[k][j]);
    }

    for (int t = 0; t < N_TURNS; t++) {
        connected[t] = vector <vector<int>> (nIslands, vector <int> (nIslands, 0));
    }

    bridgemen.resize(nBridgemen);
    for (int i = 0; i < nBridgemen; i++) {
        bridgemen[i].id = i;
    }

    orders.resize(nOrders);
    for (int turn = 0; turn < N_TURNS; turn++) {
        cin >> elapsedTime;

        for (int i = 0; i < nBridgemen; i++) {
            cin >> bridgemen[i].pos >> bridgemen[i].bricks >> bridgemen[i].target;
        }

        for (int i = 0; i < nOrders; i++) {
            cin >> orders[i].source >> orders[i].target;
        }

        auto output = makeTurn(turn);
        for (int i = 0; i < (int) output.size(); i++) {
            cout << output[i];
            if (i < output.size() - 1) {
                cout << " | ";
            }
        }
        cout << endl;
    }

    return 0;
}