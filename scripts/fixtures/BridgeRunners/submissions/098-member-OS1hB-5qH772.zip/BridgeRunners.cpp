#include <cmath>
#include <iostream>
#include <queue>
#include <string>
#include <vector>
using namespace std;

struct BridgeMan {
  int island = -1;
  int carry = 50;
  int target = -1;
  int edge_u = -1, edge_v = -1;
  bool is_long_bridge = false;
};

struct Order {
  int orig = -1, dest = -1;
};

enum class Act { MOVE, UNPACK, PACK, TEAMUNPACK, TEAMPACK, MSG };

struct Command {
  Act t;
  int a = -1, b = -1, c = -1;
  string s;
};

static string to_string(const Command& cmd) {
  switch (cmd.t) {
    case Act::MOVE:
      return "MOVE " + to_string(cmd.a) + " " + to_string(cmd.b);
    case Act::UNPACK:
      return "UNPACK " + to_string(cmd.a) + " " + to_string(cmd.b);
    case Act::PACK:
      return "PACK " + to_string(cmd.a) + " " + to_string(cmd.b);
    case Act::TEAMUNPACK:
      return "TEAMUNPACK " + to_string(cmd.a) + " " + to_string(cmd.b) + " " + to_string(cmd.c);
    case Act::TEAMPACK:
      return "TEAMPACK " + to_string(cmd.a) + " " + to_string(cmd.b) + " " + to_string(cmd.c);
    case Act::MSG:
      return "MSG " + cmd.s;
  }
  return "";
}

class Solver {
 public:
  Solver() {}

  void initial_input() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    cin >> N >> B >> O;
    dist_mat.assign(N, vector<int>(N));
    for (int i = 0; i < N; ++i) {
      for (int j = 0; j < N; ++j) {
        cin >> dist_mat[i][j];
      }
    }
    bridge_mans.assign(B, {});
    orders.assign(O, {});

    graph50_adj.assign(N, vector<int>());
    for (int i = 0; i < N; ++i) {
      for (int j = 0; j < N; ++j) {
        if (i == j) {
          continue;
        }
        if (dist_mat[i][j] <= 50) {
          graph50_adj[i].push_back(j);
        }
      }
    }

    graph50_mat.assign(N, vector<int>(N, 1 << 30));
    for (int i = 0; i < N; ++i) {
      queue<int> q;
      q.push(i);
      graph50_mat[i][i] = 0;
      while (!q.empty()) {
        int u = q.front();
        q.pop();
        for (int v : graph50_adj[u]) {
          if (graph50_mat[i][v] > graph50_mat[i][u] + 1) {
            graph50_mat[i][v] = graph50_mat[i][u] + 1;
            q.push(v);
          }
        }
      }
    }

    for (int i = 0; i < N; ++i) {
      for (int j = 0; j < N; ++j) {
        if (i == j) {
          continue;
        }
        if (dist_mat[i][j] > 50 && dist_mat[i][j] <= 100) {
          dist100_edges.push_back({i, j});
        }
      }
    }

    bridge_available_mat.assign(N, vector<bool>(N, false));
  }

  void turn_input() {
    int elapsed_ms;
    cin >> elapsed_ms;
    for (int i = 0; i < B; ++i) {
      cin >> bridge_mans[i].island >> bridge_mans[i].carry >> bridge_mans[i].target;
    }
    for (int i = 0; i < O; ++i) {
      cin >> orders[i].orig >> orders[i].dest;
    }
  }

  vector<Command> solve() {
    vector<Command> commands;

    vector<int> order_assigned(O, false);

    // --- Hungarian-based assignment (orders -> idle bridgemen) ---
    const int INF = 1'000'000'000;
    const int WAIT_COST = 120;

    vector<int> bridge_man_targets(B, -1);

    // 既にメッセージ所持中の人はそのまま配達先へ
    vector<int> idle_ids;
    idle_ids.reserve(B);
    for (int i = 0; i < B; ++i) {
      if (bridge_mans[i].target != -1) {
        bridge_man_targets[i] = bridge_mans[i].target;  // dest へ
      } else {
        idle_ids.push_back(i);  // 割当対象
      }
    }

    int R = (int)idle_ids.size();  // rows: idle men
    int K = O;                     // cols: orders（orig）
    int n = max(R, K);             // Hungarianは正方にする

    // コスト行列 A[n][n]：左上の R×K に実コスト、余りはダミー
    vector<vector<int>> A(n, vector<int>(n, 0));
    for (int ri = 0; ri < n; ++ri) {
      for (int cj = 0; cj < n; ++cj) {
        if (ri < R && cj < K) {
          int id = idle_ids[ri];
          int orig = orders[cj].orig;
          int dest = orders[cj].dest;
          if (orig < 0 || dest < 0) {
            A[ri][cj] = INF;
            continue;
          }
          int d1 = dist_mat[bridge_mans[id].island][orig];
          int d2 = dist_mat[orig][dest];
          A[ri][cj] = d1 + d2;  // 近さ: 現在地→orig + orig→dest
        } else if (ri < R && cj >= K) {
          // ダミー列：その人は今ターンは“何もしない/待機”
          A[ri][cj] = WAIT_COST;
        } else {
          // ダミー行：余った注文をダミーの人に割当（コスト0でOK）
          A[ri][cj] = 0;
        }
      }
    }

    // Hungarian（最小コスト割当） O(n^3)
    auto hungarian = [&](const vector<vector<int>>& a) {
      int n = (int)a.size();
      vector<int> u(n + 1), v(n + 1), p(n + 1), way(n + 1);
      for (int i = 1; i <= n; ++i) {
        p[0] = i;
        int j0 = 0;
        vector<int> minv(n + 1, INF);
        vector<char> used(n + 1, false);
        do {
          used[j0] = true;
          int i0 = p[j0], delta = INF, j1 = 0;
          for (int j = 1; j <= n; ++j)
            if (!used[j]) {
              int cur = a[i0 - 1][j - 1] - u[i0] - v[j];
              if (cur < minv[j]) {
                minv[j] = cur;
                way[j] = j0;
              }
              if (minv[j] < delta) {
                delta = minv[j];
                j1 = j;
              }
            }
          for (int j = 0; j <= n; ++j) {
            if (used[j]) {
              u[p[j]] += delta;
              v[j] -= delta;
            } else {
              minv[j] -= delta;
            }
          }
          j0 = j1;
        } while (p[j0] != 0);
        do {
          int j1 = way[j0];
          p[j0] = p[j1];
          j0 = j1;
        } while (j0);
      }
      vector<int> assign(n, -1);  // row i -> col assign[i]
      for (int j = 1; j <= n; ++j)
        if (p[j]) assign[p[j] - 1] = j - 1;
      return assign;
    };

    vector<int> assign = hungarian(A);

    // 割当結果を bridge_man_targets へ反映（ダミー列/INFは未割当）
    for (int ri = 0; ri < R; ++ri) {
      int cj = assign[ri];
      if (cj >= 0 && cj < K && A[ri][cj] < INF / 2) {
        int id = idle_ids[ri];
        bridge_man_targets[id] = orders[cj].orig;  // まずorigへ向かう
      }
    }

    for (int bridge_man_id = 0; bridge_man_id < B; ++bridge_man_id) {
      if (bridge_man_targets[bridge_man_id] == -1) {
        continue;
      }
      int target = bridge_man_targets[bridge_man_id];
      int current = bridge_mans[bridge_man_id].island;

      int edge_u = bridge_mans[bridge_man_id].edge_u;
      int edge_v = bridge_mans[bridge_man_id].edge_v;
      int edge_next = (edge_u == current) ? edge_v : edge_u;
      if (edge_u != -1 && edge_v != -1) {
        // 橋が使えるなら、橋を渡る
        if (graph50_mat[current][target] > graph50_mat[edge_next][target]) {
          commands.push_back(Command{Act::MOVE, bridge_man_id, edge_next});
        } else {
          // 橋が使えないなら、橋を片付ける
          bridge_mans[bridge_man_id].edge_u = -1;
          bridge_mans[bridge_man_id].edge_v = -1;
          bridge_available_mat[edge_u][edge_v] = false;
          bridge_available_mat[edge_v][edge_u] = false;
          commands.push_back(Command{Act::PACK, bridge_man_id, edge_next});
        }
        continue;
      }

      // 橋を張ってないなら、目的地に行くのに使える橋を探す
      bool found_bridge = false;
      for (auto next_island_id : graph50_adj[current]) {
        if (graph50_mat[next_island_id][target] < graph50_mat[current][target] && bridge_available_mat[current][next_island_id]) {
          commands.push_back(Command{Act::MOVE, bridge_man_id, next_island_id});
          found_bridge = true;
          break;
        }
      }
      if (found_bridge) {
        continue;
      }
      // ないなら、自分で橋を用意する
      for (auto next_island_id : graph50_adj[current]) {
        if (graph50_mat[next_island_id][target] < graph50_mat[current][target] && !bridge_available_mat[current][next_island_id]) {
          bridge_mans[bridge_man_id].edge_u = current;
          bridge_mans[bridge_man_id].edge_v = next_island_id;
          bridge_available_mat[current][next_island_id] = true;
          bridge_available_mat[next_island_id][current] = true;
          commands.push_back(Command{Act::UNPACK, bridge_man_id, next_island_id});
          break;
        }
      }
    }
    return commands;
  }

  static void turn_output(const vector<Command>& cmds) {
    if (cmds.empty()) {
      cout << '\n' << flush;
      return;
    }
    for (int i = 0; i < (int)cmds.size(); ++i) {
      if (i != 0) {
        cout << '|';
      }
      cout << to_string(cmds[i]);
    }
    cout << '\n' << flush;
  }

 private:
  int N = -1, B = -1, O = -1;
  vector<BridgeMan> bridge_mans;
  vector<Order> orders;
  vector<vector<int>> dist_mat;
  vector<vector<int>> graph50_adj;
  vector<vector<int>> graph50_mat;
  vector<pair<int, int>> dist100_edges;
  vector<vector<bool>> bridge_available_mat;
};

int main() {
  Solver solver;
  solver.initial_input();
  for (int turn = 1; turn <= 1000; ++turn) {
    solver.turn_input();
    auto cmds = solver.solve();
    Solver::turn_output(cmds);
  }
  return 0;
}
