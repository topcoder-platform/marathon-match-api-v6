#define SUBMISSION

#ifdef SUBMISSION
#define CHECKER_TEST
#endif
#define CHECKER_TEST
// #define RUN_ITER
#ifdef RUN_ITER
#define LOCAL_TEST
#endif

#include <stdarg.h>

#include <algorithm>
#include <array>
#include <bitset>
#include <chrono>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <iostream>
#include <list>
#include <map>
#include <memory>
#include <numeric>
#include <optional>
#include <queue>
#include <random>
#include <set>
#include <sstream>
#include <stack>
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <vector>
#ifdef WIN32
#include "windows.h"
#endif

using namespace std;

void dbg(const char* fmt, ...) {
#ifndef SUBMISSION
  va_list args;
  va_start(args, fmt);
  vfprintf(stderr, fmt, args);
  va_end(args);
  fflush(stderr);
#endif
}

#ifdef max
#undef max
#endif

#ifdef min
#undef min
#endif

#define mp make_pair
#define sqr(a) ((a) * (a))

#define x first
#define y second

#define BIT(n, k) (((n) >> (k)) & 1)

#ifdef LOCAL_TEST
#define ASSERT(cond)              \
  if (!(cond)) {                  \
    dbg("assert %d\n", __LINE__); \
    throw 1;                      \
  }
#else
#define ASSERT(cond)
#endif

typedef pair<int, int> pi;
typedef pair<double, double> pd;
typedef unsigned long long ull;
typedef vector<int> vi;
typedef vector<vi> vvi;
typedef vector<string> vs;
typedef vector<char> vc;
typedef vector<vc> vvc;
typedef vector<double> vd;
typedef vector<vd> vvd;

using i8 = int8_t;
using i16 = int16_t;
using i32 = int32_t;
using i64 = int64_t;
using u8 = uint8_t;
using u16 = uint16_t;
using u32 = uint32_t;
using u64 = uint64_t;

double GetTickCountMy() {
  auto now = chrono::system_clock::now();
  auto epoch = now.time_since_epoch();
  auto epoch_micros = chrono::duration_cast<chrono::microseconds>(epoch);
  return 1e-6 * epoch_micros.count();
}

double rnd() { return (double)rand() / RAND_MAX; }

#ifndef LOCAL_TEST
const double TimeLimit = 9.8;
#else
#ifndef RUN_ITER
const double TimeLimit = 9.8;
#else
const double TimeLimit = 12.8;
#endif
#endif

const int TurnCount = 1000;
const int MaxCapacity = 60;
const int InitCapacity = 50;
const int InfinityDist = 1'000'000;

template <size_t WordCnt>
class Bitset {
 public:
  inline bool operator[](u64 i) const {
    return (data_[i >> 6] >> (i & 63)) & 1;
  }

  void set_to_end(u64 from) {
    u64 word = from >> 6;
    u64 shift = from & 63;

    if (shift != 0) {
      data_[word] |= (~0ULL << shift);
      ++word;
    }
    for (; word < WordCnt; ++word) {
      data_[word] = ~0ULL;
    }
  }

  void set_range(u64 from, u64 to) {
    set_to_end(from);
    clear_to_end(to + 1);
  }

  void clear_to_end(u64 from) {
    u64 word = from >> 6;
    u64 shift = from & 63;

    if (shift != 0) {
      data_[word] &= ((1ULL << shift) - 1ULL);
      ++word;
    }
    for (; word < WordCnt; ++word) {
      data_[word] = 0ULL;
    }
  }

  inline void set1(u64 i) { data_[i >> 6] |= (1ULL << (i & 63)); }

  inline void clear1(u64 i) { data_[i >> 6] &= ~(1ULL << (i & 63)); }

 private:
  u64 data_[WordCnt] = {};
};

enum class MoveType {
  Build = 0,
  TeamBuild = 1,
  Move = 2,
  Destroy = 3,
  TeamDestroy = 4,
  Idle = 5,
};

struct Move {
  MoveType type;
  i8 b_id = -1;
  i8 target = -1;
  int len = 0;

  void print() const {
    switch (type) {
      case MoveType::Move:
        printf("MOVE %d %d", b_id, target);
        break;
      case MoveType::Build:
        printf("UNPACK %d %d", b_id, target);
        break;
      case MoveType::Destroy:
        printf("PACK %d %d", b_id, target);
        break;
      case MoveType::TeamBuild:
        printf("TEAMUNPACK %d %d %d", b_id, target, len);
        break;
      case MoveType::TeamDestroy:
        printf("TEAMPACK %d %d %d", b_id, target, len);
        break;
    }
  }

  Move() = default;
  Move(MoveType type, i8 b_id, i8 target, int len = 0)
      : type(type), b_id(b_id), target(target), len(len) {}
};

struct Order {
  i8 from = -1;
  i8 to = -1;

  Order() = default;
  Order(i8 from, i8 to) : from(from), to(to) {}

  bool operator==(const Order& other) const {
    return from == other.from && to == other.to;
  }
};

struct Builder {
  i8 v = -1;
  i8 carry = 0;
  i8 target = -1;
};

struct ComponentMove {
  MoveType type;
  i8 from = -1;
  i8 to = -1;

  ComponentMove() = default;
  explicit ComponentMove(MoveType type) : type(type) {}
  ComponentMove(MoveType type, i8 from, i8 to)
      : type(type), from(from), to(to) {}
};

enum class SwapState {
  Init,
  BuildDone,
  MoveDone,
  DestroyDone,
};

struct Swap {
  SwapState state = SwapState::Init;
  i8 b1 = -1;
  i8 b2 = -1;
  i8 v1 = -1;
  i8 v2 = -1;
  // i8 b1_len = 0;

  Swap() = default;
  Swap(i8 b1, i8 b2, i8 v1, i8 v2) : b1(b1), b2(b2), v1(v1), v2(v2) {}
};

const int MaxLookahead = 80;

inline u32 encodeState(u32 v, bool has_prev, bool has_next,
                       bool fixed_next = false) {
  return ((u32)v << 3) | ((u32)fixed_next << 2) | ((u32)has_next << 1) |
         ((u32)has_prev);
}

struct BuilderState {
  i8 v = -1;
  // i8 carry = 0;
  i8 order_target = -1;

  i8 prev_bridge = -1;
  i8 next_bridge = -1;

  BuilderState() = default;

  inline u32 encode() const {
    return encodeState(v, prev_bridge != -1, next_bridge != -1,
                       next_bridge != -1);
  }

  explicit BuilderState(const Builder& builder)
      : v(builder.v),
        order_target(builder.target)
  //,carry(builder.carry)
  {}

  void update(const Builder& builder, const vvi& g_dist) {
    ASSERT(v == builder.v);
    int bridges = 0;
    if (prev_bridge != -1) {
      bridges += g_dist[v][prev_bridge];
    }
    if (next_bridge != -1) {
      bridges += g_dist[v][next_bridge];
    }
    if (bridges <= InitCapacity) {
      ASSERT(builder.carry == InitCapacity - bridges);
    } else {
      // team
      ASSERT(builder.carry < InitCapacity);
    }
    order_target = builder.target;
  }
};

class Solver {
 public:
  void init(const vvi& g) {
    g_dist_ = g;
    n_ = g_dist_.size();
    state_cnt_ = n_ * 8;
    rnd_.seed(123);

    used_.resize(state_cnt_);
    dist_.resize(state_cnt_);
    prev_.resize(state_cnt_);

    // v_orders_.resize(n_);

    buildGraph();
    computeComponents();

    bridges_.resize(n_, vector<Bitset<4>>(n_));
    init_bridges_.resize(n_, vector<Bitset<4>>(n_));
  }

  vector<Move> makeMove(const vector<Builder>& builders,
                        const vector<Order>& orders, double time_elapsed) {
    turn_start_time_ = GetTickCountMy();
    time_left_ = TimeLimit - time_elapsed;
    ++turn_;
    int turns_left = TurnCount - turn_ + 1;
    turn_time_limit_ = time_left_ / turns_left;
    orders_ = orders;
    res_moves_.clear();

    if (turn_ == 1) {
      builder_cnt_ = builders.size();
      for (const auto& b : builders) {
        builders_.emplace_back(b);
      }
      swap_processed_.resize(builder_cnt_);
      joined_paths_.resize(builder_cnt_);

      move_targets_.resize(builder_cnt_);
      curr_component_.resize(builder_cnt_);

      builder_path_len_comp_.resize(builder_cnt_);

      best_order_.resize(builder_cnt_);
      std::iota(best_order_.begin(), best_order_.end(), 0);
      std::shuffle(best_order_.begin(), best_order_.end(), rnd_);

      handleOrders();

      dbg("components: %d, builders %d, orders %d\n", comp_cnt_,
          builders_.size(), orders_.size());
      for (int i = 0; i < comp_cnt_; ++i) {
        int builders_per_comp = 0;
        for (const auto& b : builders) {
          if (v_component_[b.v] == i) {
            ++builders_per_comp;
          }
        }
        dbg("component %d: %d/%d\n", i, builders_per_comp,
            components_[i].size());
      }
    } else {
      for (int i = 0; i < builder_cnt_; ++i) {
        builders_[i].update(builders[i], g_dist_);
      }
    }

    makeMoves();
    applyMoves();

    if (turn_ == TurnCount) {
      dbg("total iter %d, updates %d\n", search_iter_, updates_);
    }
    if (res_moves_.empty()) {
      // int t = 0;
      // TODO debug this
      dbg("no moves %d\n", turn_);
    }
    // ASSERT(!res_moves_.empty());
    return res_moves_;
  }

 private:
  u32 componentBfs(const BuilderState& builder, bool fast_stop,
                   const vc& is_target, int offset, bool need_cleanup) {
    used_.assign(state_cnt_, false);

    u32 init_state = builder.encode();
    queue<u32> q;
    q.push(init_state);
    used_[init_state] = true;
    dist_[init_state] = 0;
    prev_[init_state] = -1;

    while (!q.empty()) {
      u32 curr = q.front();
      q.pop();
      int v = curr >> 3;
      bool has_prev = curr & 1;
      bool has_next = (curr & 0b10) != 0;

      if (fast_stop && is_target[v] &&
          (!need_cleanup || (!has_prev && !has_next))) {
        return curr;
      }
      bool fixed_next = (curr & 0b100) != 0;

      int curr_dist = dist_[curr];

      int nxt = -1;
      if (has_prev) {
        nxt = encodeState(v, false, has_next);
      } else if (!has_next) {
        nxt = encodeState(v, false, true);
      }

      if (nxt != -1 && !used_[nxt]) {
        used_[nxt] = true;
        dist_[nxt] = curr_dist + 1;
        prev_[nxt] = curr;
        q.push(nxt);
      }

      if (!has_prev) {
        for (int u : g_[v]) {
          bool has_edge = bridges_[v][u][curr_dist + offset];
          if (!has_next && !has_edge) {
            continue;
          }
          if (g_dist_[v][u] > InitCapacity && !has_edge) {
            continue;
          }
          if (fixed_next && builder.next_bridge != u) {
            ASSERT(has_next);
            continue;
          }
          u32 nxt = encodeState(u, has_next, false);
          if (!used_[nxt]) {
            used_[nxt] = true;
            dist_[nxt] = curr_dist + 1;
            prev_[nxt] = curr;
            q.push(nxt);
          }
        }
      }
      if (fixed_next && has_next && !has_prev) {
        int nxt = encodeState(v, false, false);
        if (!used_[nxt]) {
          used_[nxt] = true;
          dist_[nxt] = curr_dist + 1;
          prev_[nxt] = curr;
          q.push(nxt);
        }
      }
      if (has_prev && !has_next && curr_dist == 0) {
        int nxt = encodeState(builder.prev_bridge, true, false);
        if (!used_[nxt]) {
          used_[nxt] = true;
          dist_[nxt] = curr_dist + 1;
          prev_[nxt] = curr;
          q.push(nxt);
        }
      }
    }

    if (fast_stop) {
      ASSERT(false);
    }
  }

  vector<ComponentMove> bfsPath(int offset, const BuilderState& builder,
                                u32 dest) {
    int curr = dest;
    vector<u32> state_path;
    while (curr != -1) {
      state_path.push_back(curr);
      curr = prev_[curr];
    }
    reverse(state_path.begin(), state_path.end());
    int prev_v = builder.prev_bridge;

    vector<ComponentMove> res;
    res.reserve(state_path.size() - 1);
    for (int i = 0; i < state_path.size() - 1; ++i) {
      u32 from_state = state_path[i];
      int from_v = from_state >> 3;
      bool from_prev_bridge = from_state & 1;
      bool from_nxt_bridge = (from_state & 0b10) != 0;

      u32 to_state = state_path[i + 1];
      int to_v = to_state >> 3;
      bool to_nxt_bridge = (to_state & 0b10) != 0;
      bool to_prev_bridge = to_state & 1;

      if (from_v == to_v) {
        if (from_prev_bridge && !to_prev_bridge) {
          ASSERT(from_nxt_bridge == to_nxt_bridge);
          ASSERT(prev_v != -1);
          res.emplace_back(MoveType::Destroy, from_v, prev_v);
          prev_v = -1;
        } else if (!from_nxt_bridge && to_nxt_bridge) {
          ASSERT(i + 2 < state_path.size());
          int nxt_v = state_path[i + 2] >> 3;
          ASSERT(nxt_v != from_v);
          res.emplace_back(MoveType::Build, from_v, nxt_v);
        } else {
          ASSERT(from_nxt_bridge && !to_nxt_bridge);
          ASSERT(from_v == builder.v);
          ASSERT(builder.next_bridge != -1);
          res.emplace_back(MoveType::Destroy, from_v, builder.next_bridge);
        }
      } else {
        res.emplace_back(MoveType::Move, from_v, to_v);
        prev_v = from_v;
      }
    }

    for (int i = 0; i < (int)res.size() - 1; ++i) {
      bool is_destroy_build = res[i].type == MoveType::Destroy &&
                              res[i + 1].type == MoveType::Build;
      if (!is_destroy_build) {
        continue;
      }
      if (g_dist_[res[i].from][res[i].to] +
                  g_dist_[res[i + 1].from][res[i + 1].to] <=
              InitCapacity &&
          !bridges_[res[i + 1].from][res[i + 1].to][i + offset]) {
        swap(res[i], res[i + 1]);
        ++i;
      }
    }
    return res;
  }

  void buildGraph() {
    g_.resize(n_);
    for (int i = 0; i < n_; ++i) {
      vector<pi> v;
      for (int j = 0; j < n_; ++j) {
        if (i == j) {
          continue;
        }
        if (g_dist_[i][j] <= InitCapacity * 2) {
          v.emplace_back(g_dist_[i][j], j);
        }
      }
      sort(v.begin(), v.end());
      for (const auto& [_, v_id] : v) {
        g_[i].push_back(v_id);
      }
    }
  }

  void computeComponents() {
    vc used(n_);
    v_component_.resize(n_);
    for (int from = 0; from < n_; ++from) {
      if (used[from]) {
        continue;
      }
      components_.emplace_back();
      auto& comp = components_.back();

      queue<int> q;
      q.push(from);
      used[from] = true;

      while (!q.empty()) {
        int v = q.front();
        comp.push_back(v);
        v_component_[v] = components_.size() - 1;

        q.pop();
        for (int u = 0; u < n_; ++u) {
          if (v != u && g_dist_[v][u] <= InitCapacity && !used[u]) {
            used[u] = true;
            q.push(u);
          }
        }
      }
    }

    comp_cnt_ = components_.size();
    comp_g_from_.resize(comp_cnt_, vvi(comp_cnt_));
    comp_g_to_.resize(comp_cnt_, vvi(comp_cnt_));

    for (int i = 0; i < comp_cnt_; ++i) {
      for (int j = 0; j < comp_cnt_; ++j) {
        if (i == j) {
          continue;
        }

        for (int v : components_[i]) {
          for (int u : components_[j]) {
            if (g_dist_[v][u] <= 2 * InitCapacity) {
              comp_g_from_[i][j].push_back(v);
              comp_g_to_[i][j].push_back(u);
            }
          }
        }
      }
    }

    comp_dist_.resize(comp_cnt_, vi(comp_cnt_, InfinityDist));
    for (int from = 0; from < comp_cnt_; ++from) {
      vc used(comp_cnt_);
      auto& dist = comp_dist_[from];
      dist[from] = 0;
      used[from] = true;
      queue<int> q;
      q.push(from);
      while (!q.empty()) {
        int v = q.front();
        q.pop();
        for (int u = 0; u < comp_cnt_; ++u) {
          if (used[u] || comp_g_from_[v][u].empty()) {
            continue;
          }
          q.push(u);
          used[u] = true;
          dist[u] = dist[v] + 1;
        }
      }
    }

    // comp_path_.resize(comp_cnt_, vi(comp_cnt_, -1));

    // for (int from_c = 0; from_c < comp_cnt_; ++from_c) {
    //   for (int to_c = 0; to_c < comp_cnt_; ++to_c) {
    //     if (from_c == to_c) {
    //       continue;
    //     }
    //     vc used(comp_cnt_);
    //     vi prev(comp_cnt_, -1);
    //     used[from_c] = true;
    //     queue<int> q;
    //     q.push(from_c);
    //     while (!q.empty()) {
    //       int v = q.front();
    //       q.pop();
    //       for (int u = 0; u < comp_cnt_; ++u) {
    //         if (used[u] || comp_g_from_[v][u].empty()) {
    //           continue;
    //         }
    //         q.push(u);
    //         used[u] = true;
    //         prev[u] = v;
    //       }
    //     }
    //     ASSERT(prev[to_c] != -1);
    //     int last = to_c;
    //     while (prev[last] != from_c) {
    //       last = prev[last];
    //     }
    //     comp_path_[from_c][to_c] = last;
    //   }
    // }

    dist_in_comp_.resize(n_, vi(n_, InfinityDist));

    for (int from = 0; from < n_; ++from) {
      auto& dist = dist_in_comp_[from];
      queue<int> q;
      q.push(from);
      vc used(n_);
      used[from] = true;
      dist[from] = 0;

      while (!q.empty()) {
        int v = q.front();
        q.pop();
        for (int u = 0; u < n_; ++u) {
          if (g_dist_[v][u] <= InitCapacity && !used[u]) {
            used[u] = true;
            q.push(u);
            dist[u] = dist[v] + 1;
          }
        }
      }
    }

    cross_comp_next_v_.resize(n_, vi(n_, -1));

    for (const auto& comp : components_) {
      for (int v : comp) {
        for (int u : comp) {
          cross_comp_next_v_[v][u] = u;
        }
      }
    }

    for (int from = 0; from < n_; ++from) {
      // if (from == 21) {
      //   int t = 0;
      // }
      vi dist(n_, InfinityDist);
      dist[from] = 0;
      vc used(n_);
      vi prev(n_);
      prev[from] = -1;
      used[from] = true;
      set<pi> pq;
      pq.emplace(0, from);
      while (!pq.empty()) {
        auto [curr_dist, v] = *pq.begin();
        pq.erase(pq.begin());
        used[v] = true;
        int comp_id = v_component_[v];
        for (int u : components_[comp_id]) {
          int next_dist = curr_dist + dist_in_comp_[v][u];
          if (!used[u] && next_dist < dist[u]) {
            pq.erase(mp(dist[u], u));
            dist[u] = next_dist;
            prev[u] = v;
            pq.insert(mp(dist[u], u));
          }
        }
        for (int u = 0; u < n_; ++u) {
          if (used_[u] || v_component_[u] == comp_id ||
              g_dist_[v][u] > 2 * InitCapacity) {
            continue;
          }
          int next_dist = curr_dist + 1000;
          if (!used[u] && next_dist < dist[u]) {
            pq.erase(mp(dist[u], u));
            dist[u] = next_dist;
            prev[u] = v;
            pq.insert(mp(dist[u], u));
          }
        }
      }

      for (int u = 0; u < n_; ++u) {
        int u_comp = v_component_[u];
        ASSERT(used[u]);
        if (u_comp == v_component_[from]) {
          continue;
        }
        int curr = u;
        while (prev[curr] != from) {
          curr = prev[curr];
        }
        if (v_component_[curr] != v_component_[from]) {
          cross_comp_next_v_[from][u] = from;
        } else {
          cross_comp_next_v_[from][u] = curr;
        }
      }
    }

    long_edges_in_comp_.resize(n_);

    for (int v = 0; v < n_; ++v) {
      vector<pi> edges;
      for (int u = 0; u < n_; ++u) {
        if (v == u || v_component_[v] != v_component_[u]) {
          continue;
        }
        if (g_dist_[v][u] > InitCapacity && g_dist_[v][u] <= 2 * InitCapacity) {
          edges.emplace_back(-g_dist_[v][u], u);
        }
      }
      sort(edges.begin(), edges.end());
      for (const auto& [_, u] : edges) {
        long_edges_in_comp_[v].push_back(u);
      }
    }
  }

  // void populateVOrders() {
  //   for (auto& o : v_orders_) {
  //     o.clear();
  //   }
  //   for (const auto& order : orders_) {
  //     v_orders_[order.from].push_back(order.to);
  //   }
  // }

  void handleOrders() {
    for (auto& builder : builders_) {
      if (builder.order_target == builder.v) {
        builder.order_target = -1;
      }
    }
    for (auto& builder : builders_) {
      if (builder.order_target == -1) {
        for (const auto& [o_from, o_to] : orders_) {
          if (o_from == builder.v) {
            builder.order_target = o_to;
            orders_.erase(std::find(orders_.begin(), orders_.end(),
                                    Order(builder.v, builder.order_target)));
            break;
          }
        }
      }
    }
  }

  void addCompPathBridges(BuilderState& builder, int offset,
                          const vector<ComponentMove>& moves) {
    // ComponentMove last_build;
    // bool was_move = false;
    // if (moves.empty()) {
    //  return;
    //}
    if (offset == 0) {
      if (builder.prev_bridge != -1) {
        bridges_[builder.v][builder.prev_bridge].set_to_end(0);
        bridges_[builder.prev_bridge][builder.v].set_to_end(0);
      }
      if (builder.next_bridge != -1) {
        bridges_[builder.v][builder.next_bridge].set_to_end(0);
        bridges_[builder.next_bridge][builder.v].set_to_end(0);
      }
    }
    for (int i = 0; i < moves.size(); ++i) {
      int turn = i + offset;
      const auto& move = moves[i];
      if (move.type == MoveType::Build) {
        bridges_[move.from][move.to].set_to_end(turn);
        bridges_[move.to][move.from].set_to_end(turn);
        // last_build = move;
        if (builder.next_bridge == -1) {
          builder.next_bridge = move.to;
        } else {
          ASSERT(builder.prev_bridge == -1);
          builder.prev_bridge = builder.next_bridge;
          builder.next_bridge = move.to;
        }
      }
      if (move.type == MoveType::Destroy) {
        bridges_[move.from][move.to].clear_to_end(turn + 1);
        bridges_[move.to][move.from].clear_to_end(turn + 1);
        if (move.to == builder.prev_bridge) {
          builder.prev_bridge = -1;
        } else {
          ASSERT(move.to == builder.next_bridge);
          builder.next_bridge = -1;
        }
      }
      if (move.type == MoveType::Move) {
        // was_move = true;
        ASSERT(builder.prev_bridge == -1 ||
               (builder.prev_bridge == move.to && builder.next_bridge == -1));
        if (builder.next_bridge != -1 || builder.prev_bridge == move.to) {
          builder.prev_bridge = builder.v;
        }
        builder.next_bridge = -1;
        builder.v = move.to;
      }
    }

    // int last_turn = moves.size() - 1 + offset;
    // if (last_build.from != -1) {
    //   bridges_[last_build.from][last_build.to].clear_to_end(last_turn + 1);
    //   bridges_[last_build.to][last_build.from].clear_to_end(last_turn + 1);
    //   builder.prev_bridge = -1;
    // }
    // if (!was_move) {
    //   if (builder.prev_bridge != -1) {
    //     bridges_[builder.v][builder.prev_bridge].clear_to_end(last_turn + 1);
    //     bridges_[builder.prev_bridge][builder.v].clear_to_end(last_turn + 1);
    //   }
    //   if (builder.next_bridge != -1) {
    //     bridges_[builder.v][builder.next_bridge].clear_to_end(last_turn + 1);
    //     bridges_[builder.next_bridge][builder.v].clear_to_end(last_turn + 1);
    //   }
    // }
  }

  void addMoveBridges() {
    for (const auto& move : res_moves_) {
      if (move.type == MoveType::Move) {
        continue;
      }
      bool build =
          move.type == MoveType::Build || move.type == MoveType::TeamBuild;
      int from = builders_[move.b_id].v;
      int to = -1;
      if (move.type == MoveType::Build || move.type == MoveType::Destroy) {
        to = move.target;
      } else {
        to = builders_[move.target].v;
      }
      if (build) {
        ASSERT(!init_bridges_[from][to][0]);
        ASSERT(!init_bridges_[to][from][0]);
        init_bridges_[from][to].set1(0);
        init_bridges_[to][from].set1(0);
      } else {
        ASSERT(init_bridges_[from][to][0]);
        ASSERT(init_bridges_[to][from][0]);
        init_bridges_[from][to].clear1(0);
        init_bridges_[to][from].clear1(0);
      }
    }
    bridges_ = init_bridges_;
  }

  void applyMoves() {
    sort(res_moves_.begin(), res_moves_.end(),
         [](const auto& m1, const auto& m2) {
           return (int)m1.type < (int)m2.type;
         });

    addMoveBridges();
    for (const auto& move : res_moves_) {
      auto& builder = builders_[move.b_id];
      if (move.type == MoveType::Move) {
        if (builder.next_bridge != -1) {
          ASSERT(builder.prev_bridge == -1);
          builder.prev_bridge = builder.v;
          builder.next_bridge = -1;
        } else if (builder.prev_bridge == move.target) {
          builder.prev_bridge = builder.v;
        }
        builder.v = move.target;
      } else if (move.type == MoveType::Build ||
                 move.type == MoveType::TeamBuild) {
        int next_bridge = move.type == MoveType::Build
                              ? move.target
                              : builders_[move.target].v;
        if (builder.next_bridge == -1) {
          builder.next_bridge = next_bridge;
        } else {
          ASSERT(builder.prev_bridge == -1);
          ASSERT(move.type != MoveType::TeamBuild);
          builder.prev_bridge = builder.next_bridge;
          builder.next_bridge = next_bridge;
        }
        if (move.type == MoveType::TeamBuild) {
          builders_[move.target].next_bridge = builder.v;
        }
      } else {
        if (builder.prev_bridge != -1) {
          builder.prev_bridge = -1;
          if (move.type == MoveType::TeamDestroy) {
            builders_[move.target].prev_bridge = -1;
          }
        } else {
          ASSERT(builder.next_bridge != -1);
          builder.next_bridge = -1;
          if (move.type == MoveType::TeamDestroy) {
            builders_[move.target].next_bridge = -1;
          }
        }
      }
    }
    handleOrders();
  }

  // vvc targets;
  // vc curr_component;

  void assignWithinCompDelivery() {
    for (int i = 0; i < builder_cnt_; ++i) {
      const auto& builder = builders_[i];
      if (builder.order_target != -1) {
        if (curr_component_[i] == v_component_[builder.order_target]) {
          move_targets_[i].push_back(builder.order_target);
          builder_path_len_comp_[i].x += builderDistInComp(
              builder, builder.order_target, firstBuilderId(i));
        }
      }
    }
  }

  int builderDistInComp(int v, int prev_bridge, int next_bridge, int to,
                        int first_builder_id = -1) {
    int base_dist = (int)(prev_bridge != -1) + (int)(next_bridge != -1);
    int move_dist = dist_in_comp_[v][to];
    bool updated = false;

    if (first_builder_id != -1 && prev_bridge == -1 && next_bridge == -1) {
      if (builder_dist_in_comp_cache_[first_builder_id][to] == -1) {
        int best_dist = 3 * move_dist;
        for (int u : g_[v]) {
          if (bridges_[v][u][0]) {
            if (dist_in_comp_[u][to] == InfinityDist) {
              continue;
            }
            int new_dist = 1 + 3 * dist_in_comp_[u][to];
            if (new_dist < best_dist) {
              best_dist = new_dist;
            }
          }
        }
        builder_dist_in_comp_cache_[first_builder_id][to] = best_dist;
      }
      if (builder_dist_in_comp_cache_[first_builder_id][to] < 3 * move_dist) {
        return builder_dist_in_comp_cache_[first_builder_id][to];
      }
    }

    if (!updated && next_bridge != -1) {
      if (dist_in_comp_[next_bridge][to] < move_dist) {
        base_dist += 1;
        move_dist = dist_in_comp_[next_bridge][to];
        updated = true;
      }
    }
    if (!updated && prev_bridge != -1) {
      if (dist_in_comp_[prev_bridge][to] < move_dist) {
        base_dist += 1;
        move_dist = dist_in_comp_[prev_bridge][to];
      }
    }

    return base_dist + move_dist * 3;
  }

  int builderDistInComp(const BuilderState& builder, int to,
                        int first_builder_id) {
    return builderDistInComp(builder.v, builder.prev_bridge,
                             builder.next_bridge, to, first_builder_id);
  }

  inline int firstBuilderId(int b_id) {
    if (swap_processed_[b_id].x != -1) {
      return -1;
    }
    return b_id;
  }

  void assignOutsideCompDelivery() {
    for (int builder_it = 0; builder_it < builder_cnt_; ++builder_it) {
      const auto& builder = builders_[builder_it];
      if (!(builder.order_target != -1 && move_targets_[builder_it].empty())) {
        continue;
      }
      if (swap_processed_[builder_it].x != -1) {
        continue;
      }

      int best_helper = -1;
      int best_b_swap_v = -1;
      int best_b_next_target = -1;
      int best_h_swap_v = -1;
      int best_h_next_target = -1;
      int best_dist = InfinityDist;
      bool best_has_order = false;

      int curr_comp = v_component_[builder.v];

      int target_comp = v_component_[builder.order_target];
      int curr_comp_dist = comp_dist_[curr_component_[builder_it]][target_comp];
      for (int helper_it = 0; helper_it < builder_cnt_; ++helper_it) {
        if (helper_it == builder_it || !move_targets_[helper_it].empty()) {
          continue;
        }
        if (swap_processed_[helper_it].x != -1) {
          continue;
        }

        int other_comp = curr_component_[helper_it];
        if (comp_dist_[other_comp][target_comp] >= curr_comp_dist) {
          continue;
        }
        const auto& helper = builders_[helper_it];
        // if (helper.next_bridge != -1) {
        //   continue;
        // }
        bool curr_has_order =
            helper.order_target != -1 &&
            comp_dist_[v_component_[helper.order_target]][curr_comp] <
                comp_dist_[v_component_[helper.order_target]]
                          [v_component_[helper.v]];
        if (!curr_has_order && best_has_order) {
          continue;
        }
        for (int edge_it = 0;
             edge_it < comp_g_from_[curr_comp][other_comp].size(); ++edge_it) {
          int edge_from = comp_g_from_[curr_comp][other_comp][edge_it];
          int edge_to = comp_g_to_[curr_comp][other_comp][edge_it];
          int b_swap_v = edge_from;
          int b_next_target = cross_comp_next_v_[edge_to][builder.order_target];
          int h_swap_v = edge_to;
          int h_next_target =
              curr_has_order
                  ? cross_comp_next_v_[edge_from][helper.order_target]
                  : b_swap_v;
          // if (b_swap_v == builder.v && builder.next_bridge != -1) {
          //   continue;
          // }
          // if (h_swap_v == helper.v && helper.next_bridge != -1) {
          //   continue;
          // }
          int time_to_swap = max(
              builderDistInComp(builder, edge_from, firstBuilderId(builder_it)),
              builderDistInComp(helper, edge_to, firstBuilderId(helper_it)));
          int curr_dist = time_to_swap * 2 +
                          builderDistInComp(edge_to, -1, -1, b_next_target) +
                          builderDistInComp(edge_from, -1, -1, h_next_target) +
                          3;
          bool better =
              (curr_has_order && !best_has_order) ||
              (curr_has_order == best_has_order && curr_dist < best_dist);
          if (better) {
            best_helper = helper_it;
            best_b_swap_v = b_swap_v;
            best_b_next_target = b_next_target;
            best_h_swap_v = h_swap_v;
            best_h_next_target = h_next_target;
            best_dist = curr_dist;
            best_has_order = curr_has_order;
          }
        }
      }
      if (best_helper == -1) {
        move_targets_[builder_it].push_back(
            cross_comp_next_v_[builder.v][builder.order_target]);
        builder_path_len_comp_[builder_it].x = InfinityDist;
      } else {
        swaps_.emplace_back(builder_it, best_helper, best_b_swap_v,
                            best_h_swap_v);
        int swap_id = swaps_.size() - 1;
        if (!processSwap(swap_id, false)) {
          move_targets_[builder_it].push_back(best_b_swap_v);
          move_targets_[builder_it].push_back(best_b_next_target);

          move_targets_[best_helper].push_back(best_h_swap_v);
          move_targets_[best_helper].push_back(best_h_next_target);

          joined_paths_[builder_it] = best_helper;
          joined_paths_[best_helper] = builder_it;
        } else {
          move_targets_[builder_it].push_back(best_b_next_target);
          move_targets_[best_helper].push_back(best_h_next_target);
          // -build/destroy
          best_dist -= 2;
        }

        if (best_b_next_target == builder.order_target) {
          builder_path_len_comp_[builder_it].x = best_dist;
          builder_path_len_comp_[builder_it].y =
              v_component_[builder.order_target];
        } else {
          builder_path_len_comp_[builder_it].x = InfinityDist;
        }
        if (best_h_next_target == builders_[best_helper].order_target) {
          builder_path_len_comp_[best_helper].x = best_dist;
          builder_path_len_comp_[best_helper].y =
              v_component_[builders_[best_helper].order_target];
        } else {
          builder_path_len_comp_[best_helper].x = InfinityDist;
        }
      }
    }
  }

  void assignPickup(const vi& order) {
    const int HasTargetPenalty = 3;
    vc used(builder_cnt_);
    while (true) {
      int best_builder = -1;
      int best_dist = InfinityDist;
      int best_order = -1;
      int best_order_target = -1;
      bool best_within_comp = false;
      for (int b_id : order) {
        if (used[b_id]) {
          continue;
        }
        bool has_targets = !move_targets_[b_id].empty();

        if (has_targets && builder_path_len_comp_[b_id].x == InfinityDist) {
          continue;
        }

        if (has_targets) {
          continue;
        }

        // TODO: remove?
        if (swap_processed_[b_id].x != -1) {
          continue;
        }
        int v = builders_[b_id].v;
        int comp_id = builder_path_len_comp_[b_id].y;
        int base_dist = builder_path_len_comp_[b_id].x;
        if (has_targets) {
          base_dist += HasTargetPenalty;
        }
        vc was_order(n_);
        for (const auto& [u, target] : orders_) {
          if (was_order[u] || v_component_[u] != comp_id) {
            continue;
          }
          was_order[u] = true;
          bool curr_within_comp = v_component_[target] == comp_id;

          int curr_dist = base_dist;
          if (!has_targets) {
            curr_dist +=
                builderDistInComp(builders_[b_id], u, firstBuilderId(b_id));
          } else {
            curr_dist +=
                builderDistInComp(move_targets_[b_id].back(), -1, -1, u);
          }

          if (curr_dist < best_dist) {
            best_dist = curr_dist;
            best_builder = b_id;
            best_order = u;
            best_order_target = target;
            best_within_comp = curr_within_comp;
          }
        }
      }

      if (best_builder == -1) {
        break;
      }
      used[best_builder] = true;
      if (move_targets_[best_builder].empty()) {
        move_targets_[best_builder].push_back(best_order);
        int target_v = best_order_target;
        if (best_within_comp) {
          move_targets_[best_builder].push_back(target_v);
          builder_path_len_comp_[best_builder].x += best_dist;
          builder_path_len_comp_[best_builder].x +=
              builderDistInComp(best_order, -1, -1, target_v);
        } else {
          move_targets_[best_builder].push_back(
              cross_comp_next_v_[best_order][target_v]);
          builder_path_len_comp_[best_builder].x = InfinityDist;
        }
      }
      orders_.erase(std::find(orders_.begin(), orders_.end(),
                              Order(best_order, best_order_target)));
    }
  }

  void assignIdle() {
    for (int builder_it = 0; builder_it < builder_cnt_; ++builder_it) {
      const auto& builder = builders_[builder_it];
      if (!move_targets_[builder_it].empty() ||
          swap_processed_[builder_it].x != -1) {
        continue;
      }
      int max_dist = 0;
      int max_u = -1;
      for (int u : g_[builder.v]) {
        // if (g_dist_[builder.v][u] > InitCapacity ||
        // bridges_[builder.v][u][0]) {
        if (g_dist_[builder.v][u] > InitCapacity) {
          continue;
        }
        if (g_dist_[builder.v][u] > max_dist) {
          max_dist = g_dist_[builder.v][u];
          max_u = u;
        }
      }
      if (max_u != -1) {
        move_targets_[builder_it].push_back(max_u);
      }
    }
  }

  void joinInComponent(const vi& builder_order) {
    for (int b_id : builder_order) {
      // if (move_targets_[b_id].size() != 1 || swap_processed_[b_id].x != -1) {
      if (move_targets_[b_id].empty() || swap_processed_[b_id].x != -1 ||
          joined_paths_[b_id] != -1) {
        continue;
      }
      const auto& builder = builders_[b_id];
      int builder_target = move_targets_[b_id][0];

      int best_helper = -1;
      int best_b_swap_v = -1;
      int best_h_swap_v = -1;
      int best_dist_diff = 2;
      int best_builder_len_diff = 0;
      int best_helper_len_diff = 0;

      int curr_comp = v_component_[builder.v];

      for (int helper_it = 0; helper_it < builder_cnt_; ++helper_it) {
        // if (helper_it == b_id || move_targets_[helper_it].size() > 1) {
        if (helper_it == b_id || joined_paths_[helper_it] != -1 ||
            v_component_[builder.v] != v_component_[builders_[helper_it].v]) {
          continue;
        }
        if (move_targets_[helper_it].empty()) {
          continue;
        }
        if (swap_processed_[helper_it].x != -1) {
          continue;
        }
        int other_comp = curr_component_[helper_it];
        if (other_comp != curr_comp) {
          continue;
        }

        const auto& helper = builders_[helper_it];

        int base_dist_builder =
            builderDistInComp(builder, builder_target, firstBuilderId(b_id));
        int helper_target =
            move_targets_[helper_it].empty() ? -1 : move_targets_[helper_it][0];
        int base_dist_helper = 0;
        int base_dist = base_dist_builder;
        if (helper_target != -1) {
          ASSERT(v_component_[helper.v] == v_component_[helper_target]);

          base_dist_helper = builderDistInComp(helper, helper_target,
                                               firstBuilderId(helper_it));
          base_dist += base_dist_helper;
        }

        // for (const auto& [edge_from, edge_to] :
        //      long_edges_in_comp_[curr_comp]) {
        for (int edge_from : components_[curr_comp]) {
          if (long_edges_in_comp_[edge_from].empty()) {
            continue;
          }
          int p1 = builderDistInComp(builder, edge_from, firstBuilderId(b_id));
          int n2 = helper_target == -1
                       ? 0
                       : builderDistInComp(edge_from, -1, -1, helper_target);
          if (p1 * 2 + n2 + 6 >= base_dist - best_dist_diff) {
            continue;
          }

          for (int edge_to : long_edges_in_comp_[edge_from]) {
            int p2 =
                builderDistInComp(helper, edge_to, firstBuilderId(helper_it));

            int n1 = builderDistInComp(edge_to, -1, -1, builder_target);

            int builder_len = max(p1, p2) + 3 + n1;
            int helper_len = max(p1, p2) + 3 + n2;
            int new_dist = builder_len + helper_len;

            int curr_dist_diff = base_dist - new_dist;
            // if (helper_target == -1) {
            //   curr_dist_diff -= helper_len;
            // }
            if (curr_dist_diff < 0) {
              continue;
            }

            bool better = (curr_dist_diff > best_dist_diff);
            if (better) {
              best_helper = helper_it;
              best_b_swap_v = edge_from;
              best_h_swap_v = edge_to;
              best_dist_diff = curr_dist_diff;
              best_builder_len_diff = builder_len - base_dist_builder;
              best_helper_len_diff = helper_len - base_dist_helper;
            }
          }
        }
      }
      if (best_helper == -1) {
        continue;
      } else {
        swaps_.emplace_back(b_id, best_helper, best_b_swap_v, best_h_swap_v);
        int swap_id = swaps_.size() - 1;
        if (!processSwap(swap_id, false)) {
          if (builder_path_len_comp_[b_id].x != InfinityDist) {
            builder_path_len_comp_[b_id].y += best_builder_len_diff;
          }
          if (builder_path_len_comp_[best_helper].x != InfinityDist) {
            builder_path_len_comp_[best_helper].y += best_helper_len_diff;
          }

          move_targets_[b_id].insert(move_targets_[b_id].begin(),
                                     best_b_swap_v);
          move_targets_[best_helper].insert(move_targets_[best_helper].begin(),
                                            best_h_swap_v);
          if (move_targets_[best_helper].size() == 1) {
            move_targets_[best_helper].push_back(best_b_swap_v);
          }
          joined_paths_[b_id] = best_helper;
          joined_paths_[best_helper] = b_id;
        }
      }
    }
  }

  void assignMoveTargets() {
    for (int i = 0; i < builder_cnt_; ++i) {
      const auto& builder = builders_[i];
      curr_component_[i] = v_component_[builder.v];
      if (swap_processed_[i].x != -1) {
        curr_component_[i] = v_component_[swap_processed_[i].x];
        builder_path_len_comp_[i] =
            mp(swap_processed_[i].y, curr_component_[i]);
      }
      move_targets_[i].clear();
    }

    assignWithinCompDelivery();
    assignOutsideCompDelivery();
  }

  int movesForOrder(const vi& order) {
    assignPickup(order);
    // assignPickup(false, order);
    joinInComponent(order);

    assignIdle();

    vc is_target(n_);
    vc builder_used(n_);

    int score = 0;
    for (int init_b_id : order) {
      if (builder_used[init_b_id]) {
        continue;
      }
      // if (turn_ == 69 && b_id == 2) {
      //   int t = 0;
      // }
      builder_used[init_b_id] = true;
      vector<BuilderState> builders;
      vi b_ids;
      b_ids.push_back(init_b_id);
      builders.push_back(builders_[init_b_id]);
      vi offsets;
      offsets.push_back(0);

      if (joined_paths_[init_b_id] != -1) {
        b_ids.push_back(joined_paths_[init_b_id]);
        builders.push_back(builders_[b_ids.back()]);
        offsets.push_back(0);
        ASSERT(!builder_used[b_ids.back()]);
        builder_used[b_ids.back()] = true;
      }

      for (int i = 0; i < b_ids.size(); ++i) {
        auto& builder = builders[i];
        int b_id = b_ids[i];
        if (swap_processed_[b_id].x != -1) {
          builder.v = swap_processed_[b_id].x;
          builder.prev_bridge = -1;
          builder.next_bridge = -1;
          offsets[i] = swap_processed_[b_id].y;
        }
      }
      int target_cnt = move_targets_[b_ids[0]].size();
      if (builders.size() == 2) {
        ASSERT(target_cnt >= 2);
        ASSERT(move_targets_[b_ids[1]].size() >= 2);
        target_cnt = max(target_cnt, (int)move_targets_[b_ids[1]].size());
      }
      vector<ComponentMove> first_path;
      for (int target_id = 0; target_id < target_cnt; ++target_id) {
        for (int builder_it = 0; builder_it < b_ids.size(); ++builder_it) {
          int b_id = b_ids[builder_it];
          const auto& targets = move_targets_[b_id];
          if (targets.size() <= target_id) {
            continue;
          }
          auto& builder = builders[builder_it];
          auto& offset = offsets[builder_it];
          int target = targets[target_id];

          is_target[target] = true;
          bool need_cleanup = true;
          if (target_id < targets.size() - 1 &&
              v_component_[targets[target_id]] ==
                  v_component_[targets[target_id + 1]] &&
              b_ids.size() == 1) {
            need_cleanup = false;
          }
          auto dest =
              componentBfs(builder, true, is_target, offset, need_cleanup);
          is_target[target] = false;
          auto path = bfsPath(offset, builder, dest);

          if (b_ids.size() == 1 || target_id > 0) {
            if (!path.empty() && target_id == 0 && offset == 0) {
              res_moves_.emplace_back(path[0].type, b_id, path[0].to);
            }
            addCompPathBridges(builder, offset, path);
            offset += path.size();
          } else {
            if (builder_it == 0) {
              first_path = path;
              continue;
            }
            int path_len = max(path.size(), first_path.size());
            ASSERT(path_len > 0);
            auto pad_path = [](auto& path, int target_len) {
              if (path.size() == target_len) {
                return;
              }
              if (!path.empty() && path.back().type == MoveType::Destroy) {
                auto bak = path.back();
                path.pop_back();
                while (path.size() < target_len - 1) {
                  path.emplace_back(MoveType::Idle);
                }
                path.push_back(bak);
              } else {
                while (path.size() < target_len) {
                  path.emplace_back(MoveType::Idle);
                }
              }
            };
            pad_path(path, path_len);
            pad_path(first_path, path_len);
            for (int i = 0; i < 2; ++i) {
              const auto& p = i == 0 ? first_path : path;
              if (offsets[i] == 0 && p[0].type != MoveType::Idle) {
                res_moves_.emplace_back(p[0].type, b_ids[i], p[0].to);
              }
              addCompPathBridges(builders[i], offsets[i], p);

              offsets[i] += 3 + path_len;
              ASSERT(builders[i].prev_bridge == -1);
              ASSERT(builders[i].next_bridge == -1);
            }
            swap(builders[0].v, builders[1].v);
          }
        }
      }
      for (int o : offsets) {
        score += o;
      }
    }
    return score;
  }

  int updates_ = 0;
  int search_iter_ = 0;

  void makeMoves() {
    const int OrderSwaps = 3;

    if (turn_ == 162) {
      int t = 0;
    }
    joined_paths_.assign(builder_cnt_, -1);

    for (int i = 0; i < builder_cnt_; ++i) {
      builder_path_len_comp_[i].x = 0;
      builder_path_len_comp_[i].y = v_component_[builders_[i].v];
    }

    builder_dist_in_comp_cache_ = vvi(builder_cnt_, vi(n_, -1));
    processSwaps();
    assignMoveTargets();

    auto res_moves_bak = res_moves_;
    auto swap_processed_bak = swap_processed_;
    auto bridges_bak = bridges_;
    auto move_targets_bak = move_targets_;
    auto curr_comp_bak = curr_component_;
    auto joined_paths_bak = joined_paths_;
    auto swaps_bak = swaps_;
    auto builders_bak = builders_;
    auto curr_component_bak = curr_component_;
    auto orders_bak = orders_;
    auto builder_path_len_bak = builder_path_len_comp_;

    int best_score = movesForOrder(best_order_);
    auto best_res = res_moves_;
    auto best_swaps = swaps_;

    uniform_int_distribution<> order_distr(0, best_order_.size() - 1);
    while (GetTickCountMy() - turn_start_time_ < turn_time_limit_) {
      res_moves_ = res_moves_bak;
      swap_processed_ = swap_processed_bak;
      bridges_ = bridges_bak;
      move_targets_ = move_targets_bak;
      curr_component_ = curr_comp_bak;
      joined_paths_ = joined_paths_bak;
      swaps_ = swaps_bak;
      builders_ = builders_bak;
      curr_component_ = curr_component_bak;
      orders_ = orders_bak;
      builder_path_len_comp_ = builder_path_len_bak;
      ++search_iter_;

      vi curr_order = best_order_;
      for (int i = 0; i < OrderSwaps; ++i) {
        int id1 = order_distr(rnd_);
        int id2 = order_distr(rnd_);
        while (id1 == id2) {
          id2 = order_distr(rnd_);
        }
        swap(curr_order[id1], curr_order[id2]);
      }
      int curr_score = movesForOrder(curr_order);
      if (curr_score < best_score) {
        ++updates_;
        best_res = res_moves_;
        best_swaps = swaps_;
        best_order_ = curr_order;
        best_score = curr_score;
      }
    }
    res_moves_ = best_res;
    swaps_ = best_swaps;
  }

  bool processSwap(int& swap_id, bool remove_init) {
    auto& swap = swaps_[swap_id];
    bool in_swap = swap.state != SwapState::Init;
    in_swap |=
        builders_[swap.b1].v == swap.v1 && builders_[swap.b2].v == swap.v2;
    if (swap.state == SwapState::Init && in_swap) {
      if (builders_[swap.b1].prev_bridge != -1 ||
          builders_[swap.b2].prev_bridge != -1 ||
          builders_[swap.b1].next_bridge != -1 ||
          builders_[swap.b2].next_bridge != -1) {
        in_swap = false;
      }
    }
    if (!in_swap) {
      // TODO: revisit persisting init swaps
      if (remove_init) {
        swaps_.erase(swaps_.begin() + swap_id);
        --swap_id;
      }
      return false;
    }
    int offset = -1;

    if (swap.state == SwapState::Init) {
      if (!bridges_[swap.v1][swap.v2][0]) {
        ASSERT(g_dist_[swap.v1][swap.v2] > InitCapacity);
        res_moves_.emplace_back(MoveType::TeamBuild, swap.b1, swap.b2,
                                InitCapacity);
        swap.state = SwapState::BuildDone;
        bridges_[swap.v1][swap.v2].set_range(0, 2);
        bridges_[swap.v2][swap.v1].set_range(0, 2);
        offset = 3;
      } else {
        res_moves_.emplace_back(MoveType::Move, swap.b1, swap.v2);
        res_moves_.emplace_back(MoveType::Move, swap.b2, swap.v1);
        swap.state = SwapState::DestroyDone;
        offset = 1;
      }
    } else if (swap.state == SwapState::BuildDone) {
      res_moves_.emplace_back(MoveType::Move, swap.b1, swap.v2);
      res_moves_.emplace_back(MoveType::Move, swap.b2, swap.v1);
      bridges_[swap.v1][swap.v2].set_range(0, 1);
      bridges_[swap.v2][swap.v1].set_range(0, 1);
      swap.state = SwapState::MoveDone;
      offset = 2;
    } else {
      ASSERT(swap.state == SwapState::MoveDone);
      res_moves_.emplace_back(MoveType::TeamDestroy, swap.b1, swap.b2,
                              InitCapacity);
      swap.state = SwapState::DestroyDone;
      offset = 1;
    }
    swap_processed_[swap.b1] = mp(swap.v2, offset);
    swap_processed_[swap.b2] = mp(swap.v1, offset);

    if (swap.state == SwapState::DestroyDone) {
      swaps_.erase(swaps_.begin() + swap_id);
      --swap_id;
    }
    return true;
  }

  void processSwaps() {
    swap_processed_.assign(builder_cnt_, mp(-1, -1));

    for (int i = 0; i < swaps_.size(); ++i) {
      processSwap(i, true);
    }
  }

  minstd_rand rnd_;

  double time_left_;
  double turn_start_time_;
  double turn_time_limit_;

  vc used_;
  vi dist_;
  vi prev_;

  int n_;
  int state_cnt_;
  vvi g_dist_;
  vvi g_;

  vi v_component_;
  int comp_cnt_ = 0;
  int builder_cnt_ = 0;

  vvi components_;
  vvi dist_in_comp_;
  vector<vvi> comp_g_from_;
  vector<vvi> comp_g_to_;
  vvi comp_dist_;
  vvi cross_comp_next_v_;
  vvi long_edges_in_comp_;

  // turn state
  vector<vector<Bitset<4>>> init_bridges_;
  vvi builder_dist_in_comp_cache_;

  int turn_ = 0;

  // search state
  vi best_order_;
  vector<vector<Bitset<4>>> bridges_;
  vector<Move> res_moves_;
  vector<pair<i8, i8>> swap_processed_;
  vc joined_paths_;
  vector<Swap> swaps_;
  vector<BuilderState> builders_;
  vvc move_targets_;
  vc curr_component_;
  vector<pi> builder_path_len_comp_;
  vector<Order> orders_;
  // vector<deque<int>> v_orders_;
};

void readTurn(vector<Builder>& builders, vector<Order>& orders,
              double& time_elapsed) {
  int elapsed_ms;
  scanf("%d", &elapsed_ms);
  time_elapsed = elapsed_ms / 1000.;

  for (auto& builder : builders) {
    int v, c, t;
    scanf("%d %d %d", &v, &c, &t);
    builder.v = v;
    builder.carry = c;
    builder.target = t;
  }
  for (auto& order : orders) {
    int f, t;
    scanf("%d %d", &f, &t);
    order.from = f;
    order.to = t;
  }
}

void initSetup(vvi& g, vector<Builder>& builders, vector<Order>& orders,
               double& elapsed, int seed = -1) {
  if (seed != -1) {
    char buf[100] = {0};
    sprintf(buf, "seeds/%d.in", seed);
    freopen(buf, "r", stdin);
  }

  int n, b, o;
  scanf("%d%d%d", &n, &b, &o);
  g.resize(n, vi(n));
  for (int i = 0; i < n; ++i) {
    for (int j = 0; j < n; ++j) {
      int d;
      scanf("%d", &d);
      g[i][j] = d;
    }
  }

  builders.resize(b);
  orders.resize(o);

  readTurn(builders, orders, elapsed);
}

void checkerTest() {
  vvi g;
  vector<Builder> builders;
  vector<Order> orders;
  double elapsed;
  initSetup(g, builders, orders, elapsed);
  Solver solver;
  solver.init(g);

  for (int turn = 1; turn <= TurnCount; ++turn) {
    auto moves = solver.makeMove(builders, orders, elapsed);
    for (int i = 0; i < moves.size(); ++i) {
      moves[i].print();
      if (i != moves.size() - 1) {
        printf("|");
      }
    }
    printf("\n");
    fflush(stdout);
    readTurn(builders, orders, elapsed);
  }
}

#ifdef LOCAL_TEST
enum class BridgeStatus {
  BUILT,
  NONE,
};

class Checker {
 public:
  int run(int seed) {
    vvi g;
    vector<Builder> builders;
    vector<Order> orders;
    double elapsed;
    initSetup(g, builders, orders, elapsed, seed);
    generateOrders(g.size(), seed);
    double start_time = GetTickCountMy();
    Solver solver;
    solver.init(g);
    elapsed = GetTickCountMy() - start_time;
    vector<vector<BridgeStatus>> bridges(
        g.size(), vector<BridgeStatus>(g.size(), BridgeStatus::NONE));

    for (int turn = 1; turn <= TurnCount; turn++) {
      start_time = GetTickCountMy();
      auto moves = solver.makeMove(builders, orders, elapsed);
      elapsed += GetTickCountMy() - start_time;

      handleOrders(builders, orders);
      vc used(builders.size());

      for (const auto& m : moves) {
        ASSERT(m.type != MoveType::Idle);
        auto& builder = builders[m.b_id];
        ASSERT(!used[m.b_id]);
        used[m.b_id] = true;
        int g_from = builder.v;
        int g_to =
            (m.type == MoveType::TeamBuild || m.type == MoveType::TeamDestroy)
                ? builders[m.target].v
                : m.target;
        if (m.type == MoveType::TeamBuild || m.type == MoveType::TeamDestroy) {
          ASSERT(!used[m.target]);
          used[m.target] = true;
        }
        int dist = g[g_from][g_to];
        if (m.type == MoveType::Build) {
          ASSERT(builder.carry >= dist);
          builder.carry -= dist;
        } else if (m.type == MoveType::Destroy) {
          ASSERT(builder.carry + dist <= MaxCapacity);
          builder.carry += dist;
        } else if (m.type == MoveType::Move) {
          ASSERT(m.target >= 0 && m.target < g.size());
          ASSERT(bridges[g_from][g_to] != BridgeStatus::NONE);
          ASSERT(builder.v != m.target);
          builder.v = m.target;
        } else if (m.type == MoveType::TeamBuild) {
          ASSERT(m.len > 0 && m.len < dist);
          ASSERT(m.len <= builder.carry);

          auto& other = builders[m.target];
          ASSERT(m.len + other.carry >= dist);

          builder.carry -= m.len;
          other.carry -= dist - m.len;
        } else if (m.type == MoveType::TeamDestroy) {
          ASSERT(m.len > 0 && m.len < g[g_from][g_to]);
          ASSERT(m.len + builder.carry <= MaxCapacity);

          auto& other = builders[m.target];
          int other_add = dist - m.len;
          ASSERT(other_add + builder.carry <= MaxCapacity);

          builder.carry += m.len;
          other.carry += dist - m.len;
        } else {
          ASSERT(false);
        }
        if (m.type == MoveType::Build || m.type == MoveType::TeamBuild) {
          ASSERT(bridges[g_from][g_to] == BridgeStatus::NONE);
          bridges[g_from][g_to] = bridges[g_to][g_from] = BridgeStatus::BUILT;
        }
        if (m.type == MoveType::Destroy || m.type == MoveType::TeamDestroy) {
          ASSERT(bridges[g_from][g_to] == BridgeStatus::BUILT);
          bridges[g_from][g_to] = bridges[g_to][g_from] = BridgeStatus::NONE;
        }

        handleOrders(builders, orders);
      }
    }
    if (elapsed > TimeLimit + 0.2) {
      dbg("TLE %d: %lf\n", seed, elapsed);
    }
    return score_;
  }

 private:
  int score_ = 0;
  queue<Order> order_q_;

  void generateOrders(int n, int seed) {
    minstd_rand rng(seed);
    uniform_int_distribution<> distr(0, n - 1);
    for (int i = 0; i < 20000; ++i) {
      int from = distr(rng);
      int to = distr(rng);
      while (from == to) {
        to = distr(rng);
      }
      order_q_.emplace(from, to);
    }
  }

  void handleOrders(vector<Builder>& builders, vector<Order>& orders) {
    for (auto& builder : builders) {
      if (builder.target != builder.v) {
        continue;
      }
      builder.target = -1;
      ++score_;
    }
    while (handleTakingOrders(builders, orders));
  }

  bool handleTakingOrders(vector<Builder>& builders, vector<Order>& orders) {
    for (auto& order : orders) {
      for (auto& builder : builders) {
        if (builder.target != -1 || builder.v != order.from) {
          continue;
        }
        builder.target = order.to;
        order = order_q_.front();
        order_q_.pop();
        return true;
      }
    }
    return false;
  }
};

int myTest(int seed) {
  Checker checker;
  int res = checker.run(seed);
  dbg("Seed %d score: %d\n", seed, res);
  return res;
}
#endif

int main(int argc, char* argv[]) {
  // freopen("log", "w", stderr);

#ifdef CHECKER_TEST
  checkerTest();
#else
#ifndef RUN_ITER
  int seed = 5;
  myTest(seed);
#else
  int seed;
  sscanf(argv[1], "%d", &seed);
  auto score = myTest(seed);
  printf("%d\n", score);
  fflush(stdout);
#endif
#endif
  return 0;
}