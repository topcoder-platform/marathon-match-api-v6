#define _CRT_SECURE_NO_WARNINGS

#pragma comment(linker, "/STACK:500000000")
#include <cstdio>
#include <cstdarg>
#include <cstring>
#include <cmath>
#include <ctime>
#include <vector>
#include <string>
#include <set>
#include <map>
#include <queue>
#include <algorithm>
#include <fstream>
#include <iostream>
#include <thread>
#include <random>
#include <unordered_map>
#include <unordered_set>
using namespace std;
typedef unsigned short ushort;
typedef unsigned int uint;
typedef unsigned long long ull;

#ifndef LOCAL
#define __forceinline __attribute__((always_inline)) inline
#endif


#pragma region Timer

const double TL=9.5;

const double CPU=2.8E9;
const double CPUCOEF=1/CPU;
#ifndef LOCAL
uint64_t rdtsc()
{
	unsigned int lo, hi;
	__asm__ __volatile__ ("rdtsc" : "=a" (lo), "=d" (hi));
	return ((uint64_t)hi<<32)|lo;
}
#else
#include <intrin.h>
uint64_t rdtsc()
{
	return __rdtsc();
}
#endif
uint64_t stt=rdtsc();
void RestartTimer() { stt=rdtsc(); }
__forceinline double Time() { return (rdtsc()-stt)*CPUCOEF; }
#pragma endregion


#pragma region Logging
string ToString(char x) { return string()+x; }
string ToString(const char* x) { return string(x); }
string ToString(const string& s) { return s; }
template <class T>
string ToString(const T& x) { return to_string(x); }
template <class T, class... Types>
string ToString(const T& t, const Types&... args) { return ToString(t)+" "+ToString(args...); }
void Log(const string& s) { fprintf(stderr, "%s\n", s.substr(0, 1000).c_str()); }
template <class T, class... Types>
void Log(const T& t, const Types&... args) { Log(ToString(t, args...)); }
void Logf(const char* format, ...) { va_list args; va_start(args, format); vfprintf(stderr, format, args); fprintf(stderr, "\n"); va_end(args); }
#pragma endregion


#pragma region Rand
class Rand
{
	static unsigned int xs[1<<16], ys[1<<16];
	static bool initialized;
	unsigned int x;
public:
	Rand() : x(0) {}
	Rand(int seed) : x(seed) {}
	__forceinline unsigned int next() { return xs[x&65535]^ys[++x>>16]; }
	__forceinline bool b() { return next()&1; }
	__forceinline int i() { return next()>>1; }
	__forceinline int i(int n) { return next()%n; }
	__forceinline int i(int l, int r) { return next()%(r-l+1)+l; }
	__forceinline double d() { return next()*2.3283064370807973754314699618685e-10; }
	template<class T>
	void Shuffle(T* a, int n)
	{
		for (; n--; swap(a[n], a[i(n+1)]));
	}
	static bool Initialize()
	{
		unsigned int x=123456789, y=362436, z=521288629, c=7654321;
		unsigned long long t, a=698769069LL;
		unsigned int *m=xs;
		for(int i=0; i<2; m=ys, i++)
			for(int j=0; j<(1<<16); ++j)
			{
				x=69069*x+12345;
				y^=y<<13; y^=y>>17; y^=y<<5;
				t=a*z+c; c=t>>32;
				m[j]=x+y+(z=t);
			}
		return 1;
	}
};
unsigned int Rand::xs[1<<16], Rand::ys[1<<16];
bool Rand::initialized=Rand::Initialize();
Rand rnd;
#pragma endregion


template<class T>
void Append(vector<T>& u, const vector<T>& v)
{
	u.insert(u.end(), v.begin(), v.end());
}
template<class T>
void Remove(vector<T>& u, const T& v)
{
	u.erase(find(u.begin(), u.end(), v));
}

struct Config
{
	int i0, i1, inferredLimit;
	double d0, d1;

#define nameof(a) #a
	FILE* configFile;
	map<string, int*> intProperties=
	{ 
		{nameof(i0), &i0},
		{nameof(i1), &i1},
	};
	map<string, double*> doubleProperties=
	{
		{nameof(d0), &d0},
		{nameof(d1), &d1},
	};
	int ReadInt()
	{
		int x=0; fscanf(configFile, "%d", &x); return x;
	}
	double ReadDouble()
	{
		double x=0; fscanf(configFile, "%lf", &x); return x;
	}
	string ReadString()
	{
		char x[100]=""; fscanf(configFile, "%s", x); return x;
	}
	void Read(string file)
	{
		configFile=fopen(file.c_str(), "r");
		for(; ; )
		{
			string propertyName=ReadString();
			if(propertyName.empty()) break;
			ReadString();
			if(intProperties.count(propertyName)) *intProperties[propertyName]=ReadInt();
			else if(doubleProperties.count(propertyName)) *doubleProperties[propertyName]=ReadDouble();
		}
		fclose(configFile);
	}
	void Read()
	{
		Read("config.txt");
	}
	void Print()
	{
		for(auto& p : intProperties) Logf("%s=%d;", p.first.c_str(), *p.second);
		for(auto& p : doubleProperties) Logf("%s=%lf;", p.first.c_str(), *p.second);
	}
	void Default()
	{
		i0=394;
		i1=426;
		d0=165;
		d1=434;
	}
}config;

const double Pi=acos(-1.0);
const int N=500;
const int C=100;

struct P
{
	int x, y;
	P(int x, int y): x(x), y(y) {}
	P() : x(0), y(0) {}
};
P invalid(C+1, C+1);
P operator +(const P& a, const P& b) { return P(a.x+b.x, a.y+b.y); }
P operator -(const P& a, const P& b) { return P(a.x-b.x, a.y-b.y); }
P operator *(const P& a, int b) { return P(a.x*b, a.y*b); }
P operator /(const P& a, int b) { return P(a.x/b, a.y/b); }
void operator +=(P& a, const P& b) { a.x+=b.x; a.y+=b.y; }
void operator -=(P& a, const P& b) { a.x-=b.x; a.y-=b.y; }
void operator *=(P& a, int b) { a.x*=b; a.y*=b; }
long long operator &(const P& a, const P& b) { return (long long)a.x*b.x+(long long)a.y*b.y; }
long long operator *(const P& a, const P& b) { return (long long)a.x*b.y-(long long)a.y*b.x; }
double operator !(const P& a) { return a&a; }
P operator -(const P& a) { return P(-a.x, -a.y); }
bool operator <(const P& a, const P& b) { return a.x<b.x || (a.x==b.x && a.y<b.y); }
bool operator ==(const P& a, const P& b) { return a.x==b.x && a.y==b.y; }
bool operator !=(const P& a, const P& b) { return a.x!=b.x || a.y!=b.y; }

int nr, nc, n;
P dm[2*N];
double sq[2*N];
double X;

namespace Relationships
{
	const int CMIN=5, CMAX=15, RMIN=5, RMAX=25, CT=CMAX-CMIN+1, RT=RMAX/2-RMIN/2+1;
	int cc[2*CT][2*CMAX+1][2*CMAX+1];
	int rc[RT][RT][CT][RMAX/2+CMAX+1][RMAX/2+CMAX+1];
	int cb[CT][C+1][C+1];
	int rb[RT+1][RT+1][C+1][C+1];
	int CircleCircle(const P& a, int ar, const P& b, int br)
	{
		int x=abs(b.x-a.x), y=abs(b.y-a.y);
		int r=ar+br;
		if(x>=2*CMAX || y>=2*CMAX) return 0;
		return cc[r-2*CMIN][x][y];
	}
	int RectCircle(const P& a, const P& d, const P& b, int br)
	{
		int x, y;
		if(2*b.x<2*a.x+d.x) x=a.x-b.x;
		else x=b.x-a.x-d.x;
		if(2*b.y<2*a.y+d.y) y=a.y-b.y;
		else y=b.y-a.y-d.y;
		if(x>=br || y>=br) return 0;
		return rc[d.x/2-RMIN/2][d.y/2-RMIN/2][br-CMIN][x+d.x/2][y+d.y/2];
	}
	int SegmentSegment(int a, int b, int c, int d)
	{
		return max(min(b-c, d-a), 0);
	}
	int RectRect(const P& a, const P&ad, const P& b, const P& bd)
	{
		return min(SegmentSegment(a.x, a.x+ad.x, b.x, b.x+bd.x), SegmentSegment(a.y, a.y+ad.y, b.y, b.y+bd.y));
	}
	int CircleBorder(const P& a, int r)
	{
		if(a.x*a.x+a.y*a.y<=(C-r)*(C-r)) return 0;
		return cb[r-CMIN][abs(a.x)][abs(a.y)];
	}
	int RectBorder(const P& a, const P& d)
	{
		int x, y;
		if(-a.x>a.x+d.x) x=-a.x;
		else x=a.x+d.x;
		if(-a.y>a.y+d.y) y=-a.y;
		else y=a.y+d.y;
		if(x*x+y*y<=C*C) return 0;
		return rb[(d.x+1)/2-(RMIN+1)/2][(d.y+1)/2-(RMIN+1)/2][x][y];
	}
	bool Intersect(int r, int x, int y)
	{
		if(x<=0 && y<=0) return 1;
		if(x<=0) return y<r;
		if(y<=0) return x<r;
		return x*x+y*y<r*r;
	}
	void Initialize()
	{
		for(int c=2*CMIN; c<=2*CMAX; c++)
			for(int x=c; x>=0; x--)
				for(int y=c; y>=0; y--)
					if(x*x+y*y>=c*c) cc[c-2*CMIN][x][y]=0;
					else cc[c-2*CMIN][x][y]=1+min(cc[c-2*CMIN][x+1][y], cc[c-2*CMIN][x][y+1]);
		for(int w=RMIN/2; w<=RMAX/2; w++)
			for(int h=RMIN/2; h<=RMAX/2; h++)
				for(int c=CMIN; c<=CMAX; c++)
					for(int x=w+c; x>=0; x--)
						for(int y=h+c; y>=0; y--)
							if(!Intersect(c, x-w, y-h)) rc[w-RMIN/2][h-RMIN/2][c-CMIN][x][y]=0;
							else rc[w-RMIN/2][h-RMIN/2][c-CMIN][x][y]=1+min(rc[w-RMIN/2][h-RMIN/2][c-CMIN][x+1][y], rc[w-RMIN/2][h-RMIN/2][c-CMIN][x][y+1]);
		for(int c=CMIN; c<=CMAX; c++)
			for(int x=0; x<=C; x++)
				for(int y=0; y<=C; y++)
					if(x*x+y*y<=(C-c)*(C-c)) cb[c-CMIN][x][y]=0;
					else 
					{
						cb[c-CMIN][x][y]=C;
						if(x>0) cb[c-CMIN][x][y]=min(cb[c-CMIN][x][y], cb[c-CMIN][x-1][y]+1);
						if(y>0) cb[c-CMIN][x][y]=min(cb[c-CMIN][x][y], cb[c-CMIN][x][y-1]+1);
					}
		int d0=(RMIN+1)/2;
		for(int w=(RMIN+1)/2; w<=(RMAX+1)/2; w++)
			for(int h=(RMIN+1)/2; h<=(RMAX+1)/2; h++)
				for(int x=0; x<=C; x++)
					for(int y=0; y<=C; y++)
						if(x*x+y*y<=C*C) rb[w-d0][h-d0][x][y]=0;
						else
						{
							rb[w-d0][h-d0][x][y]=C;
							if(x>w) rb[w-d0][h-d0][x][y]=min(rb[w-d0][h-d0][x][y], rb[w-d0][h-d0][x-1][y]+1);
							if(y>h) rb[w-d0][h-d0][x][y]=min(rb[w-d0][h-d0][x][y], rb[w-d0][h-d0][x][y-1]+1);
						}
	}
}

struct State
{
	vector<P> p;
	double sc, sr, score, sascore, cost, costCoef, divCoef, division;
	int collisions, y0;
	State() : p(n, invalid), sc(0), sr(0), sascore(0), score(0), cost(0), costCoef(0), division(0), collisions(0), divCoef(0) {}
	void IntersectCost(int x, int k)
	{
		if(x==0) return;
		cost+=k*((x>0)+x)*costCoef;
		collisions+=k;
	}
	void DivisionCost(int x, int k)
	{
		division+=k*x*divCoef;
	}
	void UpdateCircleCost(int i, int k)
	{
		sc+=k*sq[i];
		DivisionCost(C-p[i].y+dm[i].x, k);
		IntersectCost(Relationships::CircleBorder(p[i], dm[i].x), k);
		//IntersectCost(max(y0-p[i].y+dm[i].x, 0), k);
		for(int j=0; j<nc; j++)
			if(j!=i && p[j].x!=invalid.x) IntersectCost(Relationships::CircleCircle(p[i], dm[i].x, p[j], dm[j].x), k);
		for(int j=nc; j<n; j++)
			if(p[j].x!=invalid.x) IntersectCost(Relationships::RectCircle(p[j], dm[j], p[i], dm[i].x), k);
	}
	void UpdateRectCost(int i, int k)
	{
		sr+=k*sq[i];
		IntersectCost(Relationships::RectBorder(p[i], dm[i]), k);
		DivisionCost(p[i].y+dm[i].y+C, k);
		for(int j=0; j<nc; j++)
			if(p[j].x!=invalid.x)
				IntersectCost(Relationships::RectCircle(p[i], dm[i], p[j], dm[j].x), k);
		for(int j=nc; j<n; j++)
			if(j!=i && p[j].x!=invalid.x) IntersectCost(Relationships::RectRect(p[j], dm[j], p[i], dm[i]), k);
	}
	void UpdateScore()
	{
		double x=-(sc+sr-abs(X*sc-(1-X)*sr));
		score=-x+collisions*1E6;
		sascore=x+cost+division;
	}
	void Remove(int i)
	{
		if(p[i].x==invalid.x) return;
		if(dm[i].y==0) UpdateCircleCost(i, -1);
		else UpdateRectCost(i, -1);
		p[i]=invalid;
		UpdateScore();
	}
	void Place(int i, P t)
	{
		if(p[i].x!=invalid.x) return;
		p[i]=t;
		if(dm[i].y==0) UpdateCircleCost(i, 1);
		else UpdateRectCost(i, 1);
		UpdateScore();
	}
};

namespace SA
{
	double temp;
	bool Check(double de, double t)
	{
		//return de<=0 || de*de*rnd.d()<t;
		return de<=0;
	}
	P GetRandomLocation(const P& f)
	{
		if(f.y==0) return P(rnd.i(-C+f.x, C-f.x), rnd.i(-C+f.x, C-f.x));
		else return P(rnd.i(-C, C-f.x), rnd.i(-C, C-f.y));
	}
	void TryRemove(State& a, int i)
	{
		if(a.p[i].x==invalid.x) return;
		P t=a.p[i];
		double bs=a.sascore;
		a.Remove(i);
		if(Check(a.sascore-bs, temp));
		else a.Place(i, t);
	}
	void TryPlace(State& a, int i, int n)
	{
		if(a.p[i].x!=invalid.x) return;
		double bs=a.sascore;
		P bp=a.p[i];
		for(; n--; )
		{
			P t=GetRandomLocation(dm[i]);
			a.Place(i, t);
			if(Check(a.sascore-bs, temp)) { bs=a.sascore; bp=t; }
			a.Remove(i);
		}
		if(bp!=a.p[i]) a.Place(i, bp);
	}
	void TryShift(State& a, int i, int h)
	{
		if(a.p[i].x==invalid.x) return;
		double bs=a.sascore;
		P bp=a.p[i];
		P p=a.p[i];
		P t;
		a.Remove(i);
		int x0=p.x-h, x1=p.x+h, y0=p.y-h, y1=p.y+h;
		if(dm[i].y==0) { x0=max(x0, -C+dm[i].x); x1=min(x1, C-dm[i].x); y0=max(y0, -C+dm[i].x); y1=min(y1, C-dm[i].x); }
		else { x0=max(x0, -C); x1=min(x1, C-dm[i].x); y0=max(y0, -C); y1=min(y1, C-dm[i].y); }
		for(t.x=x0; t.x<=x1; t.x++)
			for(t.y=y0; t.y<=y1; t.y++)
			{
				a.Place(i, t);
				if(Check(a.sascore-bs, temp)) { bs=a.sascore; bp=t; }
				a.Remove(i);
			}
		a.Place(i, bp);
	}
	void TryRelocate(State& a, int i, int n)
	{
		if(a.p[i].x==invalid.x) return;
		double bs=a.sascore;
		P bp=a.p[i];
		a.Remove(i);
		for(; n--; )
		{
			P t=GetRandomLocation(dm[i]);
			a.Place(i, t);
			if(Check(a.sascore-bs, temp)) { bs=a.sascore; bp=t; }
			a.Remove(i);
		}
		a.Place(i, bp);
	}
	State Run(State a, double duration, double startTemp)
	{
		double timeLimit=min(Time()+duration, TL);
		State r=a, c=a;
		vector<int> ci(nc);
		for(int i=0; i<nc; ci[i]=i, i++);
		sort(ci.begin(), ci.end(), [](int i, int j) { return dm[i].x<dm[j].x; });
		double x=0;
		for(int i=0; i<nc; x+=sq[ci[i]], i++)
			if(x>C*C*Pi*1.3) { ci.resize(i); break; }
		vector<int> ri(nr);
		for(int i=0; i<nr; ri[i]=nc+i, i++);
		sort(ri.begin(), ri.end(), [](int i, int j) { return dm[i].x*dm[i].y<dm[j].x*dm[j].y; });
		x=0;
		for(int i=0; i<nr; x+=sq[ri[i]], i++)
			if(x>C*C*Pi*1.3) { ri.resize(i); break; }
		Append(ci, ri);
		int it=0;
		//int itlimit=1000;
		for(; ; it++)
		//for(; it<itlimit; it++)
		{
			//temp=(double)(itlimit-it)/itlimit;
			temp=(timeLimit-Time())/duration;
			if(temp<0) break;
			a.costCoef=pow(1-temp, 0.3/(0.1+min(X, 1-X)))*500;
			a.divCoef=temp*temp*5;
			temp=temp*temp*startTemp;
			int i=rnd.i(n);
			TryRemove(a, i);
			TryPlace(a, i, 10);
			TryRelocate(a, i, 10);
			TryShift(a, i, 3);
			if(a.score>r.score) r=a;
		}
		Log("Iter:", it);
		return r;
	}
}

namespace SARect
{
	const int MINH=5, MAXH=25;
	double temp;
	int ln[C+1];
	vector<P> rs;
	vector<vector<P>> res;
	struct S
	{
		vector<int> h;
		int sh;
		int score;
		int y0;
		S() : score(0), sh(0) {}
		void Evaluate(bool full=0)
		{
			static int a[N], u[N], d[2*C+1], z[2*C+1];
			int hs=h.size();
			int y=y0;
			for(int i=hs-1; i>=0; i--)
			{
				int yy=y-h[i];
				int l=ln[max(abs(y), abs(yy))];
				a[i]=(l*(MAXH+1)+h[i])*N+i;
				y-=h[i];
			}
			sort(a, a+hs);
			fill(u, u+rs.size(), 0);
			score=0;
			if(full) 
			{
				res.resize(hs);
				for(auto& r : res) r.clear();
			}
			for(int i=0; i<hs; i++)
			{
				int j=a[i]%N;
				int l=a[i]/N/(MAXH+1);
				fill(d, d+l+1, -1);
				fill(z, z+l+1, 0);
				d[0]=0;
				for(int k=(int)rs.size()-1; k>=0; k--)
				{
					if(!u[k] && rs[k].y<=h[j])
						for(int x=l; x>=rs[k].x; x--)
							if(d[x-rs[k].x]!=-1)
							{
								int nz=z[x-rs[k].x]+rs[k].x*rs[k].y;
								if(d[x]==-1 && nz>z[x]) { d[x]=k; z[x]=nz; }
							}
					if(d[l]!=-1) break;
				}
				int x=-1;
				for(y=l; y>0; y--)
					if(d[y]!=-1)
						if(x==-1 || z[y]>z[x]) x=y;
				if(x==-1) continue;
				for(; x>0; )
				{
					int k=d[x];
					u[k]=1;
					score+=rs[k].x*rs[k].y;
					if(full) res[j].push_back(rs[k]);
					x-=rs[k].x;
				}
			}
		}
	};
	bool Check(double de, double t)
	{
		return de<=0 || de*de*rnd.d()<t;
		//return de<=0;
	}
	void TryRemove(S& a)
	{
		if(a.h.size()<=1) return;
		int i=rnd.i(a.h.size());
		int h=a.h[i];
		a.h.erase(a.h.begin()+i);
		a.sh-=h;
		int bs=a.score;
		a.Evaluate();
		if(!Check(bs-a.score, temp)) { a.score=bs; a.h.insert(a.h.begin()+i, h); a.sh+=h; }
	}
	void TryInsert(S& a, int h)
	{
		if(a.sh+h>a.y0+C) return;
		int i=rnd.i(a.h.size());
		a.h.insert(a.h.begin()+i, h);
		a.sh+=h;
		int bs=a.score;
		a.Evaluate();
		if(!Check(bs-a.score, temp)) { a.score=bs; a.h.erase(a.h.begin()+i); a.sh-=h; }
	}
	void TryChange(S& a, int k)
	{
		int i=rnd.i(a.h.size());
		if(a.h[i]+k<MINH || a.h[i]+k>MAXH || a.sh+k>a.y0+C) return;
		a.h[i]+=k;
		a.sh+=k;
		int bs=a.score;
		a.Evaluate();
		if(!Check(bs-a.score, temp)) { a.score=bs; a.h[i]-=k; a.sh-=k; }
	}
	void TrySwap(S& a)
	{
		int i=rnd.i(a.h.size());
		int j=rnd.i(a.h.size());
		if(i==j) return;
		swap(a.h[i], a.h[j]);
		int bs=a.score;
		a.Evaluate();
		if(!Check(bs-a.score, temp)) { a.score=bs; swap(a.h[i], a.h[j]); }
	}
	State Run(int y0, double duration)
	{
		double timeLimit=min(Time()+duration, TL);
		S a;
		a.y0=y0;
		rs=vector<P>(nr);
		for(int i=0; i<nr; rs[i]=dm[nc+i], i++);
		sort(rs.begin(), rs.end(), [](const P& a, const P& b) { return a.y<b.y || (a.y==b.y && a.x<b.x); });
		for(int i=0; i<=C; ln[i]=2*(int)sqrt(C*C-i*i), i++);
		int i=0;
		for(int y=-C; i<nr; )
		{
			int yy=y+rs[i].y;
			if(yy>y0) break;
			int l=ln[max(abs(y), abs(yy))];
			if(l<5) { y++; continue; }
			a.h.push_back(rs[i].y);
			a.sh+=rs[i].y;
			y+=rs[i].y;
			int s=0;
			for(; s<l && i<nr; s+=rs[i].x, i++);
		}
		a.Evaluate();
		S r=a;
		int it=0;
		int itlimit=1000;
		for(; ; it++)
		//for(; it<itlimit; it++)
		{
			//temp=(double)(itlimit-it)/itlimit;
			temp=(timeLimit-Time())/duration;
			if(temp<0) break;
			temp=temp*temp;
			TryRemove(a);
			TryInsert(a, rnd.i(MINH, MAXH));
			TryChange(a, 1);
			TryChange(a, -1);
			TrySwap(a);
			if(a.score>r.score) r=a;
		}
		Log("Iter:", it);
		map<int, vector<int>> m;
		for(int i=0; i<nr; m[dm[i+nc].x*C+dm[i+nc].y].push_back(i+nc), i++);
		State s;
		r.Evaluate(1);
		int y=y0;
		for(int i=(int)r.h.size()-1; i>=0; i--)
		{
			int yy=y-r.h[i];
			int l=ln[max(abs(y), abs(yy))];
			int x=-l/2;
			for(int j=0; j<res[i].size(); j++)
			{
				int z=res[i][j].x*C+res[i][j].y;
				int k=m[z].back();
				m[z].pop_back();
				s.p[k]=P(x, yy);
				x+=res[i][j].x;
			}
			y-=r.h[i];
		}
		s.sr=r.score;
		s.UpdateScore();
		return s;
	}
}

namespace SACircle
{
	const int MAXC=15;
	const int MINC=5;
	double temp;
	bool Check(double de, double t)
	{
		return de<=0 || de*de*rnd.d()<t;
		//return de<=0;
	}
	struct S
	{
		vector<P> p;
		vector<int> r;
		int c[MAXC+1];
		double sc, score, sascore, cost, costCoef;
		int collisions, y0;
		S() : score(0), sascore(0), sc(0), cost(0), costCoef(0), collisions(0) { fill(c, c+MAXC, 0); for(int i=0; i<nc; c[dm[i].x]++, i++); }
		void IntersectCost(int x, int k)
		{
			if(x==0) return;
			cost+=k*((x>0)+x)*costCoef;
			cost+=k*((x>0)+x)*10000;
			collisions+=k;
		}
		void UpdateCircleCost(int i, int k)
		{
			sc+=k*r[i]*r[i]*Pi;
			IntersectCost(Relationships::CircleBorder(p[i], r[i]), k);
			IntersectCost(max(y0-p[i].y+r[i], 0), k);
			for(int j=0; j<p.size(); j++)
				if(j!=i) IntersectCost(Relationships::CircleCircle(p[i], r[i], p[j], r[j]), k);
			UpdateScore();
		}
		void UpdateScore()
		{
			score=sc-collisions*1E6;
			sascore=-sc+cost;
		}
		void Remove(int i)
		{
			UpdateCircleCost(i, -1);
			c[r[i]]++;
			p.erase(p.begin()+i);
			r.erase(r.begin()+i);
		}
		void Place(P t, int tr)
		{
			c[tr]--;
			p.push_back(t);
			r.push_back(tr);
			UpdateCircleCost(p.size()-1, 1);
		}
	};
	P GetRandomLocation(int r, int y0)
	{
		return P(rnd.i(-C+r, C-r), rnd.i(y0+r, C-r));
	}
	void TryRemove(S& a)
	{
		if(a.r.size()==0) return;
		int i=rnd.i(a.r.size());
		P t=a.p[i];
		int tr=a.r[i];
		double bs=a.sascore;
		a.Remove(i);
		if(Check(a.sascore-bs, temp));
		else a.Place(t, tr);
	}
	void TryPlace(S& a, int n)
	{
		double bs=a.sascore;
		for(; n--; )
		{
			int r=rnd.i(MINC, MAXC);
			if(a.c[r]==0 || C-a.y0<2*r) continue;
			P t=GetRandomLocation(r, a.y0);
			a.Place(t, r);
			if(Check(a.sascore-bs, temp));
			else a.Remove(a.r.size()-1);
		}
	}
	void TryShift(S& a, int h)
	{
		if(a.r.size()==0) return;
		int i=rnd.i(a.r.size());
		double bs=a.sascore;
		P p=a.p[i];
		P t;
		int tr=a.r[i];
		int x0=max(p.x-h, -C+tr), x1=min(p.x+h, C-tr), y0=max(p.y-h, a.y0+tr), y1=min(p.y+h, C-tr);
		if(x0>x1 || y0>y1) return;
		a.Remove(i);
		t=P(rnd.i(x0, x1), rnd.i(y0, y1));
		a.Place(t, tr);
		if(Check(a.sascore-bs, temp));
		else
		{
			a.Remove(a.r.size()-1);
			a.Place(p, tr);
		}
	}
	void TryChange(S& a, int k)
	{
		if(a.r.size()==0) return;
		int i=rnd.i(a.r.size());
		if(a.r[i]+k<MINC || a.r[i]+k>MAXC || a.c[a.r[i]+k]==0) return;
		P t=a.p[i];
		int tr=a.r[i];
		double bs=a.sascore;
		a.Remove(i);
		a.Place(t, tr+k);
		if(Check(a.sascore-bs, temp));
		else
		{
			a.Remove(a.r.size()-1);
			a.Place(t, tr);
		}
	}
	State Run(State s, int y0, double duration)
	{
		double timeLimit=min(Time()+duration, TL);
		S a;
		a.y0=y0;
		for(int i=0; i<nc; i++)
			if(s.p[i].x!=invalid.x) a.Place(s.p[i], dm[i].x);
		S r=a;
		int it=0;
		int itlimit=1000;
		for(; ; it++)
		//for(; it<itlimit; it++)
		{
			//temp=(double)(itlimit-it)/itlimit;
			temp=(timeLimit-Time())/duration;
			if(temp<0) break;
			a.costCoef=pow(1-temp, 0.2/(0.1+min(X, 1-X)))*500;
			temp=temp*temp;
			TryRemove(a);
			TryPlace(a, 10);
			TryShift(a, 4);
			TryChange(a, 1);
			if(a.score>r.score) r=a;
		}
		map<int, vector<int>> m;
		for(int i=0; i<nc; m[dm[i].x].push_back(i), i++);
		for(int i=0; i<nc; s.Remove(i), i++);
		for(int i=0; i<r.p.size(); i++)
		{
			int j=m[r.r[i]].back();
			m[r.r[i]].pop_back();
			s.Place(j, r.p[i]);
		}
		s.UpdateScore();
		Log("Iter:", it);
		return s;
	}
}

namespace GreedyCircle
{
	const int MINC=5, MAXC=15;
	State Run(State a, int y0)
	{
		vector<int> b(nc);
		for(int i=0; i<nc; b[i]=i, a.Remove(i), i++);
		sort(b.begin(), b.end(), [](int i, int j) { return dm[i].x<dm[j].x; });
		int f=12;
		int dy;
		for(dy=0; dy*dy<3*f*f; dy++);
		int i=nc-1;
		for(; i>=0 && dm[b[i]].x>f; i--);
		int l;
		for(int y=y0+f, row=0; y<C && i>=0; y+=dy, row++)
		{
			if(row==0)
			{
				for(l=C; l>=0 && l*l+y*y>(C-f)*(C-f); l--);
				if(l<0) break;
				int cnt=l/f+1;
				if(cnt%2) l=2*f*(cnt/2);
				else l=f+2*f*(cnt/2-1);
			}
			else
				for(l+=f; l>=0 && l*l+y*y>(C-f)*(C-f); l-=2*f);
			for(int x=-l; x<=l && i>=0; x+=2*f)
				if(x*x+y*y<=(C-dm[b[i]].x)*(C-dm[b[i]].x)) { a.Place(b[i], P(x, y)); i--; }
		}
		a.UpdateScore();
		return a;
	}
}

namespace Solve
{
	vector<P> Run(double x, vector<int> cs, vector<P> rs)
	{
		nc=cs.size();
		nr=rs.size();
		n=nc+nr;
		X=x;
		for(int i=0; i<nc; dm[i]=P(cs[i], 0), sq[i]=cs[i]*cs[i]*Pi, i++);
		for(int i=0; i<nr; dm[i+nc]=rs[i], sq[i+nc]=rs[i].x*rs[i].y, i++);
		Relationships::Initialize();
		State a, r;
		int y0=0;
		double bs=0;
		double s0=0, s1=0;
		for(int i=0; i<nc; s0+=sq[i], i++);
		for(int i=0; i<nr; s1+=sq[i+nc], i++);
		for(int y=-C+10; y<=C-10; y++)
		{
			double x0, x1;
			if(y>0) { x0=C*C*acos((double)y/C)-y*sqrt(C*C-y*y); x1=C*C*Pi-x0; }
			else { x1=C*C*acos((double)-y/C)+y*sqrt(C*C-y*y); x0=C*C*Pi-x1; }
			x0*=0.80;
			x1*=0.95;
			x0=min(x0, s0*1.3);
			x1=min(x1, s1*1.3);
			double s=x0+x1-abs(X*x0-(1-X)*x1);
			if(s>bs) { bs=s; y0=y; }
		}
		int yy=y0;
		bs=0;
		for(int y=yy-5; y<=yy+5; y++)
			if(y>=-C+10 && y<=C-10)
			{
				a=SARect::Run(y, 0.1);
				a=GreedyCircle::Run(a, y);
				a=SACircle::Run(a, y, 0.2);
				if(a.score>bs) { bs=a.score; y0=y; }
				if(a.score>r.score) r=a;
			}
		a=SARect::Run(y0, 1.0);
		a=GreedyCircle::Run(a, y0);
		a=SACircle::Run(a, y0, 5.0);
		if(a.score>r.score) r=a;
		Log("score:", r.score);
		Log("time:", Time());
		return r.p;
	}
}

class TastyPizza
{
public:
	double x;
	vector<int> cs;
	vector<P> rs;
	vector<P> res;
	vector<P> findSolution(double x, vector<int> cs, vector<P> rs)
	{
		RestartTimer();
		config.Default();
		return Solve::Run(x, cs, rs);
	}
	void Run()
	{
		res=findSolution(x, cs, rs);
	}
	void Read(FILE* f)
	{
		int c, r;
		fscanf(f, "%d%d%lf", &c, &r, &x);
		cs.resize(c);
		for(auto& t : cs) fscanf(f, "%d", &t);
		rs.resize(r);
		for(auto& t : rs) fscanf(f, "%d%d", &t.x, &t.y);
	}
	void Write(FILE* f)
	{
		fprintf(f, "%d\n", res.size());
		for(auto& t : res) 
			if(t==invalid) fprintf(f, "NA\n");
			else fprintf(f, "%d %d\n", t.x, t.y);
		fflush(f);
	}
	void Save(FILE* f)
	{
		fprintf(f, "%d %d %.13lf\n", cs.size(), rs.size(), x);
		for(auto& t : cs) fprintf(f, "%d\n", t);
		for(auto& t : rs) fprintf(f, "%d %d\n", t.x, t.y);
	}
	void TestGen(Rand& rnd)
	{
	}
	void TestGen()
	{
		static Rand rnd;
		TestGen(rnd);
	}
	double Score()
	{
		return 0;
	}
};

namespace Runner
{
	TastyPizza a;
	void Run()
	{
		a.Read(stdin);
		a.Run();
		a.Write(stdout);
	}
	void SaveTest()
	{
		a.Read(stdin);
		FILE* f=fopen("test.txt", "w");
		a.Save(f);
		fclose(f);
		a.Run();
		a.Write(stdout);
	}
	void Sleep(int ms)
	{
		for(int t=clock(); clock()-t<ms; );
	}
	void SaveAllTests(int t)
	{
		for(int i=1; i<=t; i++)
		{
			string com="java -jar tester.jar -exec SaveTest.exe -novis -seed "+to_string(i);
			system(com.c_str());
			Sleep(300);
			com="copy test.txt Tests\\"+to_string(i)+".txt";
			system(com.c_str());
		}
	}
	void Debug(int seed)
	{
		//Log(seed);
		string test="Release/Tests/"+to_string(seed)+".txt";
		FILE* f=fopen(test.c_str(), "r");
		a.Read(f);
		fclose(f);
		a.Run();
	}
	void RandTest(int n)
	{
		a.TestGen();
		a.Run();
	}
	void RandTests(int t)
	{
		double aver=0;
		for(int i=0; i<t; i++)
		{
			a.TestGen();
			a.Run();
			double score=a.Score();
			aver+=score;
		}
		aver/=t;
		Log(aver);
		Log(Time());
	}
};
int main(int narg, char *args[])
{
	//unner::SaveTest();
	//Runner::SaveAllTests(atoi(args[1]));
#if _DEBUG
	Runner::Debug(7);
#else
	//Runner::Debug(1);
	Runner::Run();
#endif
	//Runner::DebugFull(1);
	//for(int seed; ; scanf("%d", &seed), Runner::Debug(seed));
	//for(int i=1; i<=1000; Runner::Debug(i), i++);
	//Runner::RandTests(100, 55, -1, 0);
	//Runner::LearnConfig();
	return 0;
}
