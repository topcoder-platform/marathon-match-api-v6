import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.SplittableRandom;

public class TastyPizza {
    private int c, r;
    private double xcr;
    private int[] cr, rw, rh;
    private double[] ac, ar;
    private static final int unused = -1000;
    private Solution best;
    private SplittableRandom rnd = new SplittableRandom(9);

    public String findSolution(int c, int r, double xcr, int[] cr, int[] rw, int[] rh) {
        init(c, r, xcr, cr, rw, rh);
        place();
        return best.toString();
    }

    private void place() {
        Solution sol = new Solution();
        int fail = 0;
        NEXT: while (++fail < 1000) {
            if (c < 0 && xcr * sol.csum > (1 - xcr) * sol.rsum) {
                //TODO
                int i = rnd.nextInt(r);
                if (sol.rx[i] != unused) continue;
            } else {
                int i = rnd.nextInt(c);
                if (sol.cx[i] != unused) continue;
                int ri = cr[i];
                OUT: for (int x = -100 + ri; x <= 100 - ri; x++) {
                    for (int y = 0; y <= 100 - ri; y++) {
                        if (!isCircleInPizza(x, y, ri)) continue OUT;
                        for (int j = y == 0 ? 1 : 0; j <= 1; j++) {
                            int yy = j == 0 ? y : -y;
                            if (sol.canPlaceCircle(i, x, yy)) {
                                sol.placeCircle(i, x, yy);
                                fail = 0;
                                continue NEXT;
                            }
                        }
                    }
                }
            }
        }
        System.err.println(sol.score());
        if (best == null || sol.score() > best.score()) best = sol;
    }

    private boolean isCircleInPizza(int x, int y, int ri) {
        int dr = 100 - ri;
        return x * x + y * y <= dr * dr;
    }

    private void init(int c, int r, double xcr, int[] cr, int[] rw, int[] rh) {
        this.c = c;
        this.r = r;
        this.xcr = xcr;
        this.cr = cr;
        this.rw = rw;
        this.rh = rh;
        ac = new double[c];
        for (int i = 0; i < c; i++) {
            ac[i] = Math.PI * cr[i] * cr[i];
        }
        ar = new double[r];
        for (int i = 0; i < r; i++) {
            ar[i] = rw[i] * rh[i];
        }
    }

    class Solution {
        int[] cx, cy, rx, ry;
        double csum, rsum;
        List<Integer> cPlaced = new ArrayList<Integer>();
        List<Integer> rPlaced = new ArrayList<Integer>();

        void placeCircle(int idx, int x, int y) {
            cx[idx] = x;
            cy[idx] = y;
            csum += ac[idx];
            cPlaced.add(idx);
        }

        boolean circleInter(int x0, int y0, int r0, int x1, int y1, int r1) {
            int dx = x0 - x1;
            int dy = y0 - y1;
            int dr = r0 + r1;
            return dx * dx + dy * dy < dr * dr;
        }

        boolean canPlaceCircle(int idx, int x, int y) {
            int ridx = cr[idx];
            for (int i : cPlaced) {
                if (circleInter(x, y, ridx, cx[i], cy[i], cr[i])) return false;
            }
            return true;
        }

        void placeRect(int idx, int x, int y) {
            rx[idx] = x;
            ry[idx] = y;
            rsum += ar[idx];
            rPlaced.add(idx);
        }

        double score() {
            return csum + rsum - Math.abs(xcr * csum - (1 - xcr) * rsum);
        }

        public Solution() {
            cx = new int[c];
            cy = new int[c];
            rx = new int[r];
            ry = new int[r];
            Arrays.fill(cx, unused);
            Arrays.fill(rx, unused);
        }

        public String toString() {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < c; i++) {
                int x = cx[i];
                if (x == unused) sb.append("NA");
                else sb.append(x).append(' ').append(cy[i]);
                sb.append('\n');
            }
            for (int i = 0; i < r; i++) {
                int x = rx[i];
                if (x == unused) sb.append("NA");
                else sb.append(x).append(' ').append(ry[i]);
                sb.append('\n');
            }
            return sb.toString();
        }
    }

    public static void main(String[] args) {
        TastyPizza sol = new TastyPizza();
        try {
            BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
            int c = Integer.parseInt(br.readLine());
            int r = Integer.parseInt(br.readLine());
            double x = Double.parseDouble(br.readLine());
            int[] cr = new int[c];
            for (int i = 0; i < c; i++) {
                cr[i] = Integer.parseInt(br.readLine());
            }
            int[] rw = new int[r];
            int[] rh = new int[r];
            for (int i = 0; i < r; i++) {
                String[] s = br.readLine().split(" ");
                rw[i] = Integer.parseInt(s[0]);
                rh[i] = Integer.parseInt(s[1]);
            }
            String ret = sol.findSolution(c, r, x, cr, rw, rh);
            System.out.println(c + r);
            System.out.print(ret);
            System.out.flush();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}