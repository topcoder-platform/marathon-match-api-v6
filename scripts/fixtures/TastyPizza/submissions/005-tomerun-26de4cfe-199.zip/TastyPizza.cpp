#include <algorithm>
#include <utility>
#include <vector>
#include <iostream>
#include <array>
#include <numeric>
#include <memory>
#include <cstring>
#include <cstdlib>
#include <cstdio>
#include <cmath>
#include <sys/time.h>

#ifdef LOCAL
// #define MEASURE_TIME
#ifndef NDEBUG
#define DEBUG
#endif
#else
#define NDEBUG
// #define DEBUG
#endif
#include <cassert>

using namespace std;
using u8=uint8_t;
using u16=uint16_t;
using u32=uint32_t;
using u64=uint64_t;
using i64=int64_t;
using ll=int64_t;
using ull=uint64_t;
using vi=vector<int>;
using vvi=vector<vi>;

namespace {

#ifdef LOCAL
constexpr double CLOCK_PER_SEC = 2.2e9;
constexpr ll TL = 1000;
#else
constexpr double CLOCK_PER_SEC = 2.5e9;
constexpr ll TL = 9500;
#endif

ll start_time; // msec

inline ll get_time() {
  struct timeval tv;
  gettimeofday(&tv, NULL);
  ll result =  tv.tv_sec * 1000LL + tv.tv_usec / 1000LL;
  return result;
}

inline ll get_elapsed_msec() {
  return get_time() - start_time;
}

inline bool reach_time_limit() {
  return get_elapsed_msec() >= TL;
}

inline ull get_tsc() {
#ifdef __i386
  ull ret;
  __asm__ volatile ("rdtsc" : "=A" (ret));
  return ret;
#else
  ull high,low;
  __asm__ volatile ("rdtsc" : "=a" (low), "=d" (high));
  return (high << 32) | low;
#endif
}

struct XorShift {
  uint32_t x,y,z,w;
  static const double TO_DOUBLE;

  XorShift() {
    x = 123456789;
    y = 362436069;
    z = 521288629;
    w = 88675123;
  }

  uint32_t nextUInt(uint32_t n) {
    uint32_t t = x ^ (x << 11);
    x = y;
    y = z;
    z = w;
    w = (w ^ (w >> 19)) ^ (t ^ (t >> 8));
    return w % n;
  }

  uint32_t nextUInt() {
    uint32_t t = x ^ (x << 11);
    x = y;
    y = z;
    z = w;
    return w = (w ^ (w >> 19)) ^ (t ^ (t >> 8));
  }

  double nextDouble() {
    return nextUInt() * TO_DOUBLE;
  }
};
const double XorShift::TO_DOUBLE = 1.0 / (1LL << 32);

struct Counter {
  vector<ull> cnt;

  void add(int i) {
    if (i >= cnt.size()) {
      cnt.resize(i+1);
    }
    ++cnt[i];
  }

  void print() {
    cerr << "counter:[";
    for (int i = 0; i < cnt.size(); ++i) {
      cerr << cnt[i] << ", ";
      if (i % 10 == 9) cerr << endl;
    }
    cerr << "]" << endl;
  }
};

struct Timer {
  vector<ull> at;
  vector<ull> sum;

  void start(int i) {
    if (i >= at.size()) {
      at.resize(i+1);
      sum.resize(i+1);
    }
    at[i] = get_tsc();
  }

  void stop(int i) {
    sum[i] += (get_tsc() - at[i]);
  }

  void print() {
    cerr << "timer:[";
    for (int i = 0; i < at.size(); ++i) {
      cerr << (int)(sum[i] / CLOCK_PER_SEC * 1000) << ", ";
      if (i % 10 == 9) cerr << endl;
    }
    cerr << "]" << endl;
  }
};

}

#ifdef MEASURE_TIME
#define START_TIMER(i) (timer.start(i))
#define STOP_TIMER(i) (timer.stop(i))
#define PRINT_TIMER() (timer.print())
#define ADD_COUNTER(i) (counter.add(i))
#define PRINT_COUNTER() (counter.print())
#else
#define START_TIMER(i)
#define STOP_TIMER(i)
#define PRINT_TIMER()
#define ADD_COUNTER(i)
#define PRINT_COUNTER()
#endif

#ifdef DEBUG
#define debug(format, ...) fprintf(stderr, format, __VA_ARGS__)
#define debugStr(str) fprintf(stderr, str)
#define debugln() fprintf(stderr, "\n")
#else
#define debug(format, ...)
#define debugStr(str)
#define debugln()
#endif

template<class T>
constexpr inline T sq(T v) { return v * v; }

void debug_vec(const vi& vec) {
  for (int i = 0; i < vec.size(); ++i) {
    debug("%d ", vec[i]);
  }
  debugln();
}

XorShift rnd;
Timer timer;
Counter counter;

constexpr double PI = 3.141592653589793238;

//////// end of template ////////

struct Pos {
  int x, y;
};

bool operator==(const Pos& p1, const Pos& p2) {
  return p1.x == p2.x && p1.y == p2.y;
}

struct Size {
  int w, h;
};

struct Result {
  vector<Pos> pos_c, pos_r;
  double score;
};

constexpr int BR = 100;
constexpr int INVALID_COORD = 255;
const Pos INVALID_POS = {INVALID_COORD, INVALID_COORD};
int C, R;
double X;
array<int, 500> CS;
array<Size, 500> RS;

int rnd_int(int min, int max) {
  return (int)rnd.nextUInt(max - min + 1) + min;
}

bool inside_c(const Pos& p, int r) {
  return sq(p.x) + sq(p.y) <= sq(BR - r);
}

bool inside_r(const Pos& p, const Size& s) {
  if (sq(p.x) + sq(p.y) > sq(BR)) return false;
  if (sq(p.x + s.w) + sq(p.y) > sq(BR)) return false;
  if (sq(p.x) + sq(p.y + s.h) > sq(BR)) return false;
  if (sq(p.x + s.w) + sq(p.y + s.h) > sq(BR)) return false;
  return true;
}

bool overlap_cc(const Pos& p1, int r1, const Pos& p2, int r2) {
  return sq(p1.x - p2.x) + sq(p1.y - p2.y) < sq(r1 + r2);
}

bool overlap_rr(const Pos& p1, const Size& s1, const Pos& p2, const Size&  s2) {
  if (p1.x + s1.w <= p2.x) return false;
  if (p1.x >= p2.x + s2.w) return false;
  if (p1.y + s1.h <= p2.y) return false;
  if (p1.y >= p2.y + s2.h) return false;
  return true;
}

bool overlap_cr(const Pos& p1, int r1, const Pos& p2, const Size&  s2) {
  int x = p1.x * 2 - (p2.x * 2 + s2.w);
  int y = p1.y * 2 - (p2.y * 2 + s2.h);
  if (x >= s2.w + r1 * 2) return false;
  if (y >= s2.h + r1 * 2) return false;
  if (x < s2.w) return true;
  if (y < s2.h) return true;
  return sq(x - s2.w) + sq(y - s2.h) < sq(r1 * 2);
}

// inline bool accept(int diff) {
//   if (diff <= 0) return true;
//   double v = diff * sa_cooler;
//   if (v > 7) return false;
//   return rnd.nextDouble() < exp(-v);
// }

Result solve_one() {
  Result res;
  double area_c = 0.0;
  double area_r = 0.0;
  const int SHIFT = 1024;
  const int TRY = 100;
  vi cands;
  for (int i = 0; i < C; ++i) {
    cands.push_back(i);
  }
  for (int i = 0; i < R; ++i) {
    cands.push_back(SHIFT + i);
  }
  vector<Pos> cand_pos(C + R, INVALID_POS);
  for (int i = 0; i < C + R; ++i) {
    int swp = rnd.nextUInt(C + R - i) + i;
    swap(cands[i], cands[swp]);
    if (cands[i] < SHIFT) {
      int rad = CS[cands[i]];
      int min_coord = -BR + rad;
      int max_coord = BR - rad;
      for (int j = 0; j < TRY; ++j) {
        int cx = rnd_int(min_coord, max_coord);
        int cy = rnd_int(min_coord, max_coord);
        if (!inside_c({cx, cy}, rad)) continue;
        bool ok = true;
        for (int k = 0; k < i; ++k) {
          if (cand_pos[k].x == INVALID_COORD) continue;
          if (cands[k] < SHIFT) {
            if (overlap_cc({cx, cy}, rad, cand_pos[k], CS[cands[k]])) {
              ok = false;
              break;
            }
          } else {
            if (overlap_cr({cx, cy}, rad, cand_pos[k], RS[cands[k] - SHIFT])) {
              ok = false;
              break;
            }
          }
        }
        if (ok) {
          cand_pos[i] = {cx, cy};
          area_c += rad * rad * PI;
          break;
        }
      }
    } else {
      const Size& sz = RS[cands[i] - SHIFT];
      int min_coord = -BR;
      int max_x = BR - sz.w;
      int max_y = BR - sz.h;
      for (int j = 0; j < TRY; ++j) {
        int cx = rnd_int(min_coord, max_x);
        int cy = rnd_int(min_coord, max_y);
        if (!inside_r({cx, cy}, sz)) continue;
        bool ok = true;
        for (int k = 0; k < i; ++k) {
          if (cand_pos[k].x == INVALID_COORD) continue;
          if (cands[k] < SHIFT) {
            if (overlap_cr(cand_pos[k], CS[cands[k]], {cx, cy}, sz)) {
              ok = false;
              break;
            }
          } else {
            if (overlap_rr(cand_pos[k], RS[cands[k] - SHIFT], {cx, cy}, sz)) {
              ok = false;
              break;
            }
          }
        }
        if (ok) {
          cand_pos[i] = {cx, cy};
          area_r += sz.w * sz.h;
          break;
        }
      }
    }
    // debug("%d %d %d\n", cand_pos[i].x, cand_pos[i].y, cands[i]);
  }
  res.pos_c.resize(C);
  res.pos_r.resize(R);
  for (int i = 0; i < R + C; ++i) {
    if (cands[i] < SHIFT) {
      res.pos_c[cands[i]] = cand_pos[i];
    } else {
      res.pos_r[cands[i] - SHIFT] = cand_pos[i];
    }
  }
  res.score = area_c + area_r - abs(area_c * X - area_r * (1 - X));
  return res;
}

class TastyPizza {
public:
  Result findSolution() {
    Result best_res;
    best_res.score = 0.0;
    for (int turn = 0; ; ++turn) {
      if (get_elapsed_msec() > TL) {
        debug("total_turn:%d\n", turn);
        break;
      }
      Result res = solve_one();
      if (res.score > best_res.score) {
        debug("turn:%d score:%f\n", turn, res.score);
        best_res = res;
      }
    }
    return best_res;
  }
};

int main() {
  scanf("%d %d %lf", &C, &R, &X);
  start_time = get_time();
  debug("C:%d R:%d X:%f\n", C, R, X);
  for (int i = 0; i < C; ++i) {
    scanf("%d", &CS[i]);
  }
  for (int i = 0; i < R; ++i) {
    scanf("%d %d", &RS[i].w, &RS[i].h);
  }
  TastyPizza prog;
  const Result res = prog.findSolution();
  printf("%d\n", C + R);
  for (const auto& p : res.pos_c) {
    if (p.x == INVALID_COORD) {
      printf("NA\n");
    } else {
      printf("%d %d\n", p.x, p.y);
    }
  }
  for (const auto& p : res.pos_r) {
    if (p.x == INVALID_COORD) {
      printf("NA\n");
    } else {
      printf("%d %d\n", p.x, p.y);
    }
  }
  fflush(stdout);
  // debug("elapsed:%lld\n", get_elapsed_msec());
  PRINT_TIMER();
  PRINT_COUNTER();
}