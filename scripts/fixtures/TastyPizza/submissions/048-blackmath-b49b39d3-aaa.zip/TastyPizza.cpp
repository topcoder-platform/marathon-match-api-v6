//g++ --std=c++0x -W -Wall -Wno-sign-compare -O2 -pipe -mmmx -msse -msse2 -msse3 -DLOCAL % -o %:r
#include <algorithm>
#include <cassert>
#include <climits>
#include <complex>
#include <cstdlib>
#include <deque>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <map>
#include <queue>
#include <set>
#include <stack>
#include <sstream>
#include <sys/time.h>
#include <unordered_map>
#include <unordered_set>
#include <vector>
#include <unistd.h>
#include <emmintrin.h>
using namespace std;
// }}}
#ifdef LOCAL
  #define FACTOR (1.0)
#else
  #define FACTOR (1.0)
#endif
#define PROFILING 
//#define STOPWATCH
// {{{
#define NOOP() ((void) 0)
#define INLINE inline __attribute__ ((always_inline))
#define NOINLINE __attribute__ ((noinline))
#define LIKELY(x) __builtin_expect(!!(x), 1)
#define UNLIKELY(x) __builtin_expect(!!(x), 0)
#define ALIGNED __attribute__ ((aligned(16)))
// }}}
// {{{ output operators
template<class T1, class T2> ostream& operator<<(ostream &, const pair<T1, T2> &);
template<class T> ostream& operator<<(ostream&, const vector<T> &);
template<class T> ostream& operator<<(ostream&, const set<T> &);
template<class V, class K> ostream& operator<<(ostream &, const map<V, K> &);
template<class... Args> ostream &operator<<(ostream &, const tuple<Args...> &);
template<class T> void dumpContainer(const T &c, ostream &out) { for (auto it = c.begin(); it != c.end(); ++it) { if (it != c.begin()) { out << ", "; } out << *it; } }
template<class T1, class T2> ostream& operator<<(ostream &out, const pair<T1, T2> &p) { out << "(" << p.first << ", " << p.second << ")"; return out; }
template<class T> ostream& operator<<(ostream &out, const vector<T> &v) { out << "["; dumpContainer(v, out); out << "]"; return out; }
template<class T> ostream& operator<<(ostream &out, const set<T> &s) { out << "{"; dumpContainer(s, out); out << "}"; return out; }
template<class K, class V> ostream& operator<<(ostream &out, const map<K, V> &m) { out << "{"; dumpContainer(m, out); out << "}"; return out; }
template<size_t> struct sizeT {}; 
template<class T> void dumpTuple(const T &, sizeT<0>, ostream &) {} 
template<class T> void dumpTuple(const T &t, sizeT<1>, ostream &out) { out << get<tuple_size<T>::value - 1>(t); }
template<class T, size_t numRemaining> void dumpTuple(const T &t, sizeT<numRemaining>, ostream &out) { out << get<tuple_size<T>::value - numRemaining>(t) << ", "; dumpTuple(t, sizeT<numRemaining - 1>(), out); }
template<class... Args> ostream &operator<<(ostream &out, const tuple<Args...> &t) { out << "("; dumpTuple(t, sizeT<sizeof...(Args)>(), out); out << ")"; return out; }
// }}}
// {{{ debug
#define COMPOSE_MACRO(_1, _2, _3, _4, _5, _6, _7, _8, MACRO_NAME, ...) MACRO_NAME
#define STREAM1(x, ...) #x << " = " << (x)
#define STREAM2(x, ...) STREAM1(x) << ", " << STREAM1(__VA_ARGS__)
#define STREAM3(x, ...) STREAM1(x) << ", " << STREAM2(__VA_ARGS__)
#define STREAM4(x, ...) STREAM1(x) << ", " << STREAM3(__VA_ARGS__)
#define STREAM5(x, ...) STREAM1(x) << ", " << STREAM4(__VA_ARGS__)
#define STREAM6(x, ...) STREAM1(x) << ", " << STREAM5(__VA_ARGS__)
#define STREAM7(x, ...) STREAM1(x) << ", " << STREAM6(__VA_ARGS__)
#define STREAM8(x, ...) STREAM1(x) << ", " << STREAM7(__VA_ARGS__)
#define STREAM_VARARGS(...) COMPOSE_MACRO(__VA_ARGS__, STREAM8, STREAM7, STREAM6, STREAM5, STREAM4, STREAM3, STREAM2, STREAM1)(__VA_ARGS__)
#ifdef NODBG 
ofstream devNull("/dev/null");
#define DBG_DEST devNull
#else
#define DBG_DEST cerr
#endif
#define DBG(...) DBG_DEST << STREAM_VARARGS(__VA_ARGS__) << endl
#define DBG_WITH_LINE(...) DBG_DEST << "line " << __LINE__ << ": " << STREAM_VARARGS(__VA_ARGS__) << endl
#define DBG_NZ(x) if (x) { DBG(x); }
#define WARNING DBG_DEST << "WARNING "
// }}}
// {{{ assert
struct Equals { template<class T1, class T2> bool operator()(const T1 &lhs, const T2 &rhs) const { return lhs == rhs; } };
template<class T1, class T2, class OP> void verboseAssert(const T1 &lhs, const T2 &rhs, const OP &op, const char *lhsExp, const char *rhsExp, const char *opStr, const char *file, const char *function, int line) { if (!op(lhs, rhs)) { cerr << "Assertion failed: not true that " << lhsExp << " " << opStr << " " << rhsExp << ", function " << function << ", file " << file << ", line " << line << "." << endl; cerr << "    " << lhsExp << " = " << lhs << endl; cerr << "    " << rhsExp << " = " << rhs << endl; abort(); } }
#ifdef NDEBUG
#define assertEquals(x, y) NOOP();
#else
#define assertEquals(x, y) verboseAssert(x, y, Equals(), #x, #y, "equals", __FUNCTION__, __FILE__, __LINE__);
#endif
// }}}
// {{{ timing / profiling
#ifdef PROFILING
  long long numMeasureTime = 0;
  #define INC(x) ++x
  #define DBG_PROFILING() DBG(numMeasureTime);
#else
  #define INC(x) NOOP()
  #define DBG_PROFILING() NOOP()
#endif
INLINE static double measureTime() {
  INC(numMeasureTime);
  timeval t; 
  gettimeofday(&t, 0); 
  return (t.tv_sec * 1000000LL + t.tv_usec) * 1e-6 * FACTOR;
}
struct StopWatch {
#ifdef STOPWATCH
  string name;
  double lastTic;
  double totalElapsed;
  int numTics;
  bool isRunning;
  StopWatch(const string &name) : name(name), totalElapsed(0.0), numTics(0), isRunning(false){}
  INLINE void tic() {
    assert(!isRunning);
    isRunning = true;
    numTics++;
    lastTic = measureTime();
  }
  INLINE double toc() {
    assert(isRunning);
    isRunning = false;
    double delta = measureTime() - lastTic;
    totalElapsed += delta;
    return delta;
  }
  INLINE double getTotalElapsed() {
    return totalElapsed + (isRunning ? measureTime() - lastTic : 0.0);
  }
  void print() {
    double t = getTotalElapsed();
    DBG_DEST << name << ": total=" << t << "s, count=" << numTics;
    if (numTics) {
      DBG_DEST << " avg=" << t / numTics << "s";
    }
    if (isRunning) {
      DBG_DEST << " [isRunning=true]";
    }
    DBG_DEST << endl;
  }
#else
  StopWatch(string) {}
  void tic() {}
  double toc() { return 0.0; }
  double getTotalElapsed() { return 0.0; }
  void print() {}
#endif
#define SW(x) StopWatch stopWatch##x(#x); stopWatch##x.tic();
#define SW_END(x) stopWatch##x.toc(); stopWatch##x.print();
};
// }}}
// {{{ PRNG 
class MersenneTwister {
 public:
  MersenneTwister() { init(); }
  MersenneTwister(unsigned seed) { init(seed); }
  void init(unsigned seed=0) {
    ix = 0;
    MT[0] = seed;
    for (unsigned i = 1; i < 624; i++) {
      MT[i] = 1812433253u * (MT[i-1] ^ (MT[i-1] >> 30)) + i;
    }
  }
  INLINE unsigned next() {
    if (ix == 0) {
      generate();
    }
    unsigned y = MT[ix];
    y ^= y >> 11;
    y ^= (y << 7) & 2636928640u;
    y ^= (y << 15) & 4022730752u;
    y ^= y >> 18;
    if (++ix >= 624) {
      ix = 0;
    }
    return y;
  }
  INLINE int next(int m) { return next() % m; }
  INLINE int next(int a, int b) { return a + next() % (b - a); }
  INLINE double nextDouble() { return next() * .00000000023283064365; }
  INLINE float nextFloat() { return next() * .00000000023283064365f; }
  template<class T> void randomShuffle(T begin, T end) {
    for (int i = 1, n = end - begin; i < n; i++) {
      swap(begin[i], begin[next() % (i + 1)]);
    }
  }
  template<class T> void randomShuffle(T &v) {
    randomShuffle(v.begin(), v.end());
  }
 private:
  unsigned MT[624];
  int ix;
  double v;
  bool precalc = false;
  INLINE void generate() {
    for (int i = 0; i < 624; i++) {
      unsigned y = (MT[i] & (1u << 31)) + (MT[i == 623 ? 0 : i + 1] & ((1u << 31) - 1));
      MT[i] = MT[i + 397 >= 624 ? i + 397 - 624 : i + 397] ^ (y >> 1);
      if (y & 1) {
        MT[i] ^= 2567483615u;
      }
    }
  }
 public:
  double gaussian() {
    if (precalc) {
      precalc = false;
      return v;
    }
    double x, y, r2;
    do {
      x = 2 * nextDouble() - 1.0;
      y = 2 * nextDouble() - 1.0;
      r2 = x*x + y*y;
    } while (r2 > 1 || r2 == 0);
    double s = sqrt(-2.0 * log(r2) / r2);
    double u = s * x;
    v = s * y;
    precalc = true;
    return u;
  }
} mt;
// mt(time(0));
// }}}
// {{{
typedef vector<int> VI;
typedef vector<VI> VVI;
typedef vector<string> VS;
typedef pair<int, int> PII;
typedef long long LL;
// }}}

const double PI = 2.0 * acos(0.0);
const double EPS = 1e-9;
const int baseRadius = 100;
double startTime;

int numCircle;
int numRectangle;
double X;
VI radius;
VI xs;
VI ys;

VI circleBoundaryMin;
VI circleBoundaryMax;

int sq(int x) {
  return x * x;
}

double sq(double x) {
  return x * x;
}

int distance2(int x0, int y0, int x1, int y1) {
  return sq(x1 - x0) + sq(y1 - y0);
}

bool circleCircleOverlap(int k0, int x0, int y0, int k1, int x1, int y1) {
  int r0 = radius[k0];
  int r1 = radius[k1];

  return distance2(x0, y0, x1, y1) < sq(r0 + r1);
}

bool rectangleRectangleOverlap(int k0, int x0, int y0, int k1, int x1, int y1) {
  return x0 < x1 + xs[k1]
  && x0 + xs[k0] > x1
  && y0 < y1 + ys[k1]
  && y0 + ys[k0] > y1;
}

bool circleRectangleOverlap(int k0, int x0, int y0, int k1, int x1, int y1) {
  double x = abs(x0 - (x1 + xs[k1] * 0.5));
  double y = abs(y0 - (y1 + ys[k1] * 0.5));

  if (x + EPS > xs[k1] * 0.5 + radius[k0]) {
    return false;
  }
  if (y + EPS > ys[k1] * 0.5 + radius[k0]) {
    return false;
  }
  if (x + EPS < xs[k1] * 0.5) {
    return true;
  }
  if (y + EPS < ys[k1] * 0.5) {
    return true;
  }
  double cornerDist = sq(x - xs[k1] * 0.5) + sq(y - ys[k1] * 0.5);
  return cornerDist + EPS < sq(radius[k0]);
}

bool circleInside(int k, int x, int y) {
  int r = radius[k];
  return sq(x) + sq(y) <= sq(baseRadius - r);
}

bool rectangleInside(int k, int x, int y) {
  return distance2(x, y, 0, 0) <= sq(baseRadius)
      && distance2(x, y + ys[k], 0, 0) <= sq(baseRadius)
      && distance2(x + xs[k], y, 0, 0) <= sq(baseRadius)
      && distance2(x + xs[k], y + ys[k], 0, 0) <= sq(baseRadius);
}

int rectangleArea(int k) {
  return xs[k] * ys[k];
}

double circleArea(int k) {
  return PI * sq(radius[k]);
}

bool isRectangleValid(int k, int x, int y, const VI &circleUsed, const VI &circleX, const VI &circleY, const VI &rectangleUsed, const VI &rectangleX, const VI &rectangleY) {
  if (!rectangleInside(k, x, y)) {
    return false;
  }

  for (int i = 0; i < numRectangle; i++) {
    if (rectangleUsed[i] && rectangleRectangleOverlap(k, x, y, i, rectangleX[i], rectangleY[i])) {
      return false;
    }
  }

  for (int i = 0; i < numCircle; i++) {
    if (circleUsed[i] && circleRectangleOverlap(i, circleX[i], circleY[i], k, x, y)) {
      return false;
    }
  }

  return true;
}

bool isCircleValid(int k, int x, int y, const VI &circleUsed, const VI &circleX, const VI &circleY, const VI &rectangleUsed, const VI &rectangleX, const VI &rectangleY) {
  if (!circleInside(k, x, y)) {
    return false;
  }

  for (int i = 0; i < numRectangle; i++) {
    if (rectangleUsed[i] && circleRectangleOverlap(k, x, y, i, rectangleX[i], rectangleY[i])) {
      return false;
    }
  }

  for (int i = 0; i < numCircle; i++) {
    if (circleUsed[i] && circleCircleOverlap(i, circleX[i], circleY[i], k, x, y)) {
      return false;
    }
  }

  return true;
}

struct Position {
  bool isRectangle;
  int index;
  int x;
  int y;
  double area;
};

void calculateCircleBoundaries() {
  for (int x = -100; x <= 100; x++) {
    int y0 = 0;
    while (distance2(x, y0 - 1, 0, 0) <= sq(baseRadius)) {
      y0--;
    }
    circleBoundaryMin.push_back(y0);

    int y1 = 0;
    while (distance2(x, y1 + 1, 0, 0) <= sq(baseRadius)) {
      y1++;
    }
    circleBoundaryMax.push_back(y1);
  }
}

struct Stripe {
  int index;
  int length;
};

void coverWindow(int x0, int x1, int y0, int y1, VI &rectangleUsed, VI &rectangleX, VI &rectangleY, int targetArea) {
  vector<vector<Stripe>> rectangleByXs(26);

  for (int i = 0; i < numRectangle; i++) {
    if (!rectangleUsed[i]) {
      rectangleByXs[xs[i]].push_back(Stripe{i, ys[i]});
    }
  }
  int totalArea = 0;
  int x = x0;
  while (x + 5 <= x1) {
    double bestRatio = 0.0;
    int bestDx = -1;
    int bestMinY = 0;
    VI bestIndexes;
    for (int dx = 5; x + dx <= x1 && dx <= 25; dx++) {
      DBG(x, dx);
      // x, x + 1, ..., x + dx

      int minY = y0; 
      int maxY = y1;
      for (int x2 = x; x2 <= x + dx; x2++) {
        minY = max(minY, circleBoundaryMin[x2 + 100]);
        maxY = min(maxY, circleBoundaryMax[x2 + 100]);
      }

      int area = 0;
      for (int x2 = x; x2 <= x + dx; x2++) {
        minY = max(minY, circleBoundaryMin[x2 + 100]);
        area += min(circleBoundaryMax[x2 + 100], circleBoundaryMax[x2 + 100 + 1]) - max(circleBoundaryMin[x2 + 100], circleBoundaryMin[x2 + 100 + 1]);
      }

      if (area <= 0) {
        continue;
      }

      int dy = maxY - minY;
      if (dy < 5) {
        continue;
      }

      VI dp(dy + 1, -1);
      VI dpIndex(dy + 1, -1);
      dp[0] = 0;

      for (int i = 0; i < (int) rectangleByXs[dx].size(); i++) {
        if (rectangleUsed[rectangleByXs[dx][i].index]) {
          continue;
        }
        int length = rectangleByXs[dx][i].length;
        for (int j = dy; j >= length; j--) {
          if (dp[j] == -1 && dp[j - length] >= 0) {
            dp[j] = length;
            dpIndex[j] = i;
          }
        }
      }

      int maxTotalLength = dy;
      while (dp[maxTotalLength] == -1) {
        maxTotalLength--;
        assert(maxTotalLength >= 0);
      }

      VI indexes;
      for (int l = maxTotalLength; l > 0; l -= dp[l]) {
        indexes.push_back(dpIndex[l]);
      }

      // indexes covers maxTotalLength * dx out of area
      DBG(area, maxTotalLength * dx);

      double ratio = (double) maxTotalLength * dx / area;
      if (ratio > bestRatio) {
        bestRatio = ratio;
        bestDx = dx;
        bestIndexes = indexes;
        bestMinY = minY;
      }
    }

    if (bestDx == -1) {
      x++;
    } else {
      DBG(bestRatio);
      int y = bestMinY;
      int totalLength = 0;
      for (int i : bestIndexes) {
        int length = rectangleByXs[bestDx][i].length;
        int index = rectangleByXs[bestDx][i].index;
        rectangleUsed[index] = 1;
        rectangleX[index] = x;
        rectangleY[index] = y;

        y += length;
        totalLength += length;
      }
      x += bestDx;
      totalArea += bestDx * totalLength;
      if (totalArea > targetArea) {
        return;
      }
    }
  }
}
 
bool isCircleValid(int k, int x, int y, const VVI &circleByX, const VI &circleX, const VI &circleY, const VVI &rectangleByX, const VI &rectangleX, const VI &rectangleY) {
  if (!circleInside(k, x, y)) {
    return false;
  }

  int r = radius[k];

  int minX = max(x - r - 25, -100);
  int maxX = min(x + r + 25, 100);

  for (int x0 = minX; x0 <= maxX; x0++) {
    for (int i : rectangleByX[x0 + 100]) {
      if (circleRectangleOverlap(k, x, y, i, rectangleX[i], rectangleY[i])) {
        return false;
      }
    }
  }

  minX = max(x - r - 15, -100);
  maxX = min(x + r + 15, 100);
  for (int x0 = minX; x0 <= maxX; x0++) {
    for (int i : circleByX[x0 + 100]) {
      if (circleCircleOverlap(i, circleX[i], circleY[i], k, x, y)) {
        return false;
      }
    }
  }

  return true;
}

bool isRectangleValid(int k, int x, int y, const VVI &circleByX, const VI &circleX, const VI &circleY, const VVI &rectangleByX, const VI &rectangleX, const VI &rectangleY) {
  if (!rectangleInside(k, x, y)) {
    return false;
  }
  int minX = max(x - xs[k] - 25, -100);
  int maxX = min(x + xs[k] + 25, 100);

  for (int x0 = minX; x0 <= maxX; x0++) {
    for (int i : rectangleByX[x0 + 100]) {
      if (rectangleRectangleOverlap(k, x, y, i, rectangleX[i], rectangleY[i])) {
        return false;
      }
    }
  }

  minX = max(x - xs[k] - 15, -100);
  maxX = min(x + xs[k] + 15, 100);
  for (int x0 = minX; x0 <= maxX; x0++) {
    for (int i : circleByX[x0 + 100]) {
      if (circleRectangleOverlap(i, circleX[i], circleY[i], k, x, y)) {
        return false;
      }
    }
  }

  return true;
}


void solve() {
  calculateCircleBoundaries();

//void coverWindow(int x0, int x1, int y0, int y1, VI &rectangleUsed, VI &rectangleX, VI &rectangleY) {

  VI rectangleX(numRectangle);
  VI rectangleY(numRectangle);

  VI circleX(numCircle);
  VI circleY(numCircle);

  VI circleUsed(numCircle, 0);
  VI rectangleUsed(numRectangle, 0);

  int targetArea = (int) (100 * 100 * PI * X * 0.95);
  coverWindow(-100, 100, -100, 100, rectangleUsed, rectangleX, rectangleY, targetArea);

  VVI rectangleByX(201);
  VVI circleByX(201);

  for (int i = 0; i < numRectangle; i++) {
    if (rectangleUsed[i]) {
      rectangleByX[rectangleX[i] + 100].push_back(i);
    }
  }

  VVI circleByRadius(16);
  for (int i = 0; i < numCircle; i++) {
    circleByRadius[radius[i]].push_back(i);
  }

  for (int r = 15; r >= 5; r--) {
    DBG(r, circleByRadius[r].size());
    for (int k : circleByRadius[r]) {
      int x0 = 1000;
      int y0 = 1000;
      for (int t = 0; t < 3000; t++) {
        int x = mt.next(200) - 100;
        int y = mt.next(200) - 100;
        //if ((x < x0 || (x == x0 && y < y0)) && isCircleValid(k, x, y, circleByX, circleX, circleY, rectangleByX, rectangleX, rectangleY)) {
        if ((x < x0 || (x == x0 && y < y0)) && isCircleValid(k, x, y, circleByX, circleX, circleY, rectangleByX, rectangleX, rectangleY)) {
          x0 = x;
          y0 = y;
        }
      }

     
      if (x0 < 1000) { 
        while (isCircleValid(k, x0, y0 - 1, circleByX, circleX, circleY, rectangleByX, rectangleX, rectangleY)) {
          y0--;
        }
        while (isCircleValid(k, x0 - 1, y0, circleByX, circleX, circleY, rectangleByX, rectangleX, rectangleY)) {
          x0--;
        }
      }

      if (x0 < 1000) {
        circleUsed[k] = 1;
        circleX[k] = x0;
        circleY[k] = y0;
        DBG(r, x0, y0);

        circleByX[x0 + 100].push_back(k);
      } else {
        break;
      }
    }
  }

  vector<PII> rectanglesByArea;
  for (int i = 0; i < numRectangle; i++) {
    if (!rectangleUsed[i]) {
      rectanglesByArea.push_back(PII(xs[i] * ys[i], i));
    }
  }

  sort(rectanglesByArea.rbegin(), rectanglesByArea.rend());

  for (PII p : rectanglesByArea) {
    int k = p.second;
    int x0 = 1000;
    int y0 = 1000;
    for (int t = 0; t < 3000; t++) {
      int x = mt.next(200) - 100;
      int y = mt.next(200) - 100;
      //if ((x < x0 || (x == x0 && y < y0)) && isCircleValid(k, x, y, circleByX, circleX, circleY, rectangleByX, rectangleX, rectangleY)) {
      if ((x < x0 || (x == x0 && y < y0)) && isRectangleValid(k, x, y, circleByX, circleX, circleY, rectangleByX, rectangleX, rectangleY)) {
        x0 = x;
        y0 = y;
      }
    }


    if (x0 < 1000) { 
      while (isRectangleValid(k, x0, y0 - 1, circleByX, circleX, circleY, rectangleByX, rectangleX, rectangleY)) {
        y0--;
      }
      while (isRectangleValid(k, x0 - 1, y0, circleByX, circleX, circleY, rectangleByX, rectangleX, rectangleY)) {
        x0--;
      }
    }

    if (x0 < 1000) {
      rectangleUsed[k] = 1;
      rectangleX[k] = x0;
      rectangleY[k] = y0;

      rectangleByX[x0 + 100].push_back(k);
    } else {
    }
  }

  cout << (numCircle + numRectangle) << endl;
  for (int i = 0; i < numCircle; i++) {
    if (circleUsed[i]) {
      cout << circleX[i] << " " << circleY[i] << endl;
    } else {
      cout << "NA" << endl;
    }
  }

  for (int i = 0; i < numRectangle; i++) {
    if (rectangleUsed[i]) {
      cout << rectangleX[i] << " " << rectangleY[i] << endl;
    } else {
      cout << "NA" << endl;
    }
  }
}

VI readVector(istream &in, int n) {
  VI v;
  for (int i = 0; i < n; i++) {
    int k;
    in >> k;
    v.push_back(k);
  }
  return v;
}

VI readVector(istream &in) {
  VI v;
  int n;
  in >> n;
  return readVector(in, n);
}

template<class T>
void readVector(istream &in, T &v) {
  int n;
  in >> n;
  v.resize(n);
  for (int i = 0; i < n; i++) {
    in >> v[i];
  }
}

template<class T>
void writeVector(const T &v, ostream &out) {
  out << v.size() << endl;
  for (const auto &x : v) {
    out << x << endl;
  }
}

void run(int seed, istream &in) {
  assert(seed >= -1);

  startTime = measureTime();

  int numCircle;
  int numRectangle;
  double X;
  
  in >> numCircle >> numRectangle >> X;
  
  vector<int> radius;
  
  for (int i = 0; i < numCircle; i++) {
    int r;
    in >> r;
    radius.push_back(r);
  }

  vector<int> xs;
  vector<int> ys;
  for (int i = 0; i < numRectangle; i++) {
    int x;
    int y;
    in >> x >> y;

    xs.push_back(x);
    ys.push_back(y);
  }

  ::X = X;
  ::numCircle = numCircle;
  ::numRectangle = numRectangle;
  ::xs = xs;
  ::ys = ys;
  ::radius = radius;

  solve();
}

int main(int argc, char **argv) {
  int seed = -1;
  run(seed, cin);
//#ifdef LOCAL
//  if (argc >= 2) {
//    seed = atoi(argv[1]);
//    cerr << "processing seed " << seed << endl;
//  }
//#endif
//#if EC2
//  DBG(argc);
//  if (argc >= 2) {
//    seed = atoi(argv[1]);
//  }
//  assert(seed != -1);
//  char filename[64];
//  //sprintf(filename, "input/%d.in", seed);
//  sprintf(filename, "/home/ubuntu/input-tco2020-mm116/%d.in", seed);
//  DBG(filename);
//  ifstream in(filename);
//  run(seed, in);
//#else
//  run(seed, cin);
//#endif
  return 0;
}

//static_assert(__LINE__ <= 3000, "More than 3000 lines - consider coming up with a shorter solution!");

