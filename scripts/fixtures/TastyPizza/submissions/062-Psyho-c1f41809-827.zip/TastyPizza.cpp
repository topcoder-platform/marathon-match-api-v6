// Author: Psyho
// Twitter: https://twitter.com/fakepsyho
// Site: http://psyho.gg/

const double TIME_LIMIT = 9.0;
	
 
#include <bits/stdc++.h>
#include <sys/time.h>
 
using namespace std;
 
#define INLINE   inline __attribute__ ((always_inline))
#define NOINLINE __attribute__ ((noinline))

#define byte        unsigned char
#define FOR(i,a,b)  for(int i=(a);i<(b);++i)
#define REP(i,a)    FOR(i,0,a)
#define ZERO(m)     memset(m,0,sizeof(m))
#define MINUS(m)    memset(m,-1,sizeof(m))
#define ALL(x)      x.begin(),x.end()
#define PB          push_back
#define S           size()
#define LL          long long
#define ULL         unsigned long long
#define LD          long double
#define MP          make_pair
#define X           first
#define Y           second
#define VC          vector
#define PII         pair<int, int>
#define PDD         pair<double, double>
#define PIII        pair<PII, int>
#define VB          VC<byte>
#define VVB         VC<VB>
#define VI          VC<int>
#define VVI         VC<VI>
#define VVVI        VC<VVI>
#define VPII        VC<PII>
#define VVPII       VC<VPII>
#define VD          VC<double>
#define VVD         VC<VD>
#define VVVD        VC<VVD>
#define VVVVD       VC<VVVD>
#define VF          VC<float>
#define VVF         VC<VF>
#define VVVF        VC<VVF>
#define VS          VC<string>
#define VVS         VC<VS>
 
template<typename A, typename B> ostream& operator<<(ostream &os, pair<A,B> p) {os << "(" << p.X << "," << p.Y << ")"; return os;}
template<typename A, typename B, typename C> ostream& operator<<(ostream &os, tuple<A,B,C> p) {os << "(" << get<0>(p) << "," << get<1>(p) << "," << get<2>(p) << ")"; return os;}
template<typename T> ostream& operator<<(ostream &os, VC<T> v) {os << "{"; REP(i, v.S) {if (i) os << ", "; os << v[i];} os << "}"; return os;}
template<typename T> ostream& operator<<(ostream &os, set<T> s) {VS vs(ALL(s)); return os << vs;}
template<typename T> string i2s(T x) {ostringstream o; o << x; return o.str();}
VS splt(string s, char c = ' ') {VS all; int p = 0, np; while (np = s.find(c, p), np >= 0) {if (np != p) all.PB(s.substr(p, np - p)); p = np + 1;} if (p < s.S) all.PB(s.substr(p)); return all;}

#define ARGS_SIZE_(a1,a2,a3,a4,a5,a6,a7,a8,a9,size,...) size
#define ARGS_SIZE(...) ARGS_SIZE_(__VA_ARGS__,9,8,7,6,5,4,3,2,1)

#define DB_1(x) #x << "=" << (x) <<
#define DB_2(x, ...) #x << "=" << (x) << ", " << DB_1(__VA_ARGS__)
#define DB_3(x, ...) #x << "=" << (x) << ", " << DB_2(__VA_ARGS__)
#define DB_4(x, ...) #x << "=" << (x) << ", " << DB_3(__VA_ARGS__)
#define DB_5(x, ...) #x << "=" << (x) << ", " << DB_4(__VA_ARGS__)
#define DB_6(x, ...) #x << "=" << (x) << ", " << DB_5(__VA_ARGS__)
#define DB_7(x, ...) #x << "=" << (x) << ", " << DB_6(__VA_ARGS__)
#define DB_8(x, ...) #x << "=" << (x) << ", " << DB_7(__VA_ARGS__)
#define DB_9(x, ...) #x << "=" << (x) << ", " << DB_8(__VA_ARGS__)
#define DB__(size, ...) DB_##size(__VA_ARGS__)
#define DB_(size, ...) DB__(size, __VA_ARGS__)
#define DB(...) do {cerr << DB_(ARGS_SIZE(__VA_ARGS__), __VA_ARGS__) endl;} while (0)
 
double get_time() {timeval tv; gettimeofday(&tv, NULL); return tv.tv_sec + tv.tv_usec * 1e-6;}
 
double PI = 2*acos(0);

struct RNG {
    unsigned int MT[624];
    int index;
    RNG(int seed = 1) {init(seed);}
    void init(int seed = 1) {MT[0] = seed; FOR(i, 1, 624) MT[i] = (1812433253UL * (MT[i-1] ^ (MT[i-1] >> 30)) + i); index = 0; }
    void generate() {
        const unsigned int MULT[] = {0, 2567483615UL};
        REP(i, 227) {unsigned int y = (MT[i] & 0x8000000UL) + (MT[i+1] & 0x7FFFFFFFUL); MT[i] = MT[i+397] ^ (y >> 1); MT[i] ^= MULT[y&1]; }
        FOR(i, 227, 623) {unsigned int y = (MT[i] & 0x8000000UL) + (MT[i+1] & 0x7FFFFFFFUL); MT[i] = MT[i-227] ^ (y >> 1); MT[i] ^= MULT[y&1]; }
        unsigned int y = (MT[623] & 0x8000000UL) + (MT[0] & 0x7FFFFFFFUL); MT[623] = MT[623-227] ^ (y >> 1); MT[623] ^= MULT[y&1];
    }
    unsigned int rand() { if (index == 0) generate(); unsigned int y = MT[index]; y ^= y >> 11; y ^= y << 7  & 2636928640UL; y ^= y << 15 & 4022730752UL; y ^= y >> 18; index = index == 623 ? 0 : index + 1; return y;}
    INLINE int next() {return rand(); }
    INLINE int next(int x) {return rand() % x; }
    INLINE int next(int a, int b) {return a + (rand() % (b - a)); }
    INLINE double next_double() {return (rand() + 0.5) * (1.0 / 4294967296.0); }
    INLINE double next_double(double a, double b) {return a + next_double() * (b - a); }
};
 
static RNG rng;

double start_time = get_time();

#define SQR(a) ((a)*(a))


double max_c = 0;
double max_r = 0;


INLINE bool circ_col(int r1, int x1, int y1, int r2, int x2, int y2) {
	return SQR(x2-x1)+SQR(y2-y1) < SQR(r1+r2);
}

INLINE bool rect_col(int w1, int h1, int x1, int y1, int w2, int h2, int x2, int y2) {
	return x1 < x2+w2 && x1+w1 > x2 &&
	       y1 < y2+h2 && y1+h1 > y2;
}

const double EPS=1e-6;
INLINE bool mix_col(int r1, int x1, int y1, int w2, int h2, int x2, int y2) {
	double x = abs(x1 - (x2+w2/2.0));
	double y = abs(y1 - (y2+h2/2.0));
	if (x+EPS > w2/2.0 + r1) return false;
	if (y+EPS > h2/2.0 + r1) return false;
	if (x+EPS < w2/2.0) return true;
	if (y+EPS < h2/2.0) return true;
	double corner_dist = SQR(x - w2/2.0) + SQR(y - h2/2.0);
	return corner_dist+EPS < SQR(r1);
}

bool circ_ins(int r, int x, int y) {
	return SQR(x) + SQR(y) < SQR(100-r)-EPS;
}

bool rect_ins(int w, int h, int x, int y) {
	return SQR(x)+SQR(y) < 100*100-EPS &&
	       SQR(x)+SQR(y+h) < 100*100-EPS &&
	       SQR(x+w)+SQR(y) < 100*100-EPS &&
	       SQR(x+w)+SQR(y+h) < 100*100-EPS;
}

const double INF=1000;


double xtime;

int C,R,N;
double X;

VI   fc;
VPII fr;

double score(int c, int r) {
	return r + c - abs(X*c - (1-X)*r);
}

PDD get_area(VPII &s) {
	double c = 0;
	double r = 0;
	REP(i,C) if (s[i].X < INF) c += fc[i]*fc[i]*PI;
	REP(i,R) if (s[i+C].X < INF) r += fr[i].X*fr[i].Y;
	return MP(c,r);
}

double score(VPII &s) {
	PII p = get_area(s);
	return score(p.X,p.Y);
}

INLINE bool circ_ok(VPII &s, int id, int x, int y) {
	if (!circ_ins(fc[id],x,y)) return false;
	REP(i,C) if (i!=id && s[i].X < INF && circ_col(fc[id],x,y,fc[i],s[i].X,s[i].Y)) return false;
	REP(i,R) if (s[i+C].X < INF && mix_col(fc[id],x,y,fr[i].X,fr[i].Y,s[i+C].X,s[i+C].Y)) return false;
	return true;
}

INLINE bool rect_ok(VPII &s, int id, int x, int y) {
	if (!rect_ins(fr[id].X,fr[id].Y,x,y)) return false;
	REP(i,C) if (s[i].X < INF && mix_col(fc[i],s[i].X,s[i].Y,fr[id].X,fr[id].Y,x,y)) return false;
	REP(i,R) if (i!=id && s[i+C].X < INF && rect_col(fr[id].X,fr[id].Y,x,y,fr[i].X,fr[i].Y,s[i+C].X,s[i+C].Y)) return false;
	return true;
}

const int BLOCK=10;
const int MAX_FIGS=10;
struct State {
	int gno[200/BLOCK+1][200/BLOCK+1];
	int gid[200/BLOCK+1][200/BLOCK+1][MAX_FIGS];
	
	int check[1000];
	int checkid = 0;
	
	void clear() {
		ZERO(gno);
		ZERO(gid);
		ZERO(check);
	}
	
	State() {
		clear();
	}
	
	INLINE void add_fig(int id, int bx, int by) {
		gid[bx][by][gno[bx][by]++] = id;
		assert(gno[bx][by]<=10);
	}
	
	INLINE void add_circ(int id, int x, int y) {
		FOR(bx,(100+x-fc[id])/BLOCK,(100+x+fc[id])/BLOCK+1)
			FOR(by,(100+y-fc[id])/BLOCK,(100+y+fc[id])/BLOCK+1) {
				this->add_fig(id, bx, by);
			}
	}
	
	INLINE void add_rect(int id, int x, int y) {
		FOR(bx,(100+x)/BLOCK,(100+x+fr[id].X)/BLOCK+1)
			FOR(by,(100+y)/BLOCK,(100+y+fr[id].Y)/BLOCK+1) {
				this->add_fig(id+C, bx, by);
			}
	}
	
	INLINE void rem_circ(int id, int x, int y) {
		//TODO: add
	}
	
	INLINE void rem_rect(int id, int x, int y) {
		//TODO: add
	}
	
	INLINE bool check_circ(VPII &s, int id, int x, int y) {
		checkid++;
		if (!circ_ins(fc[id],x,y)) return false;
		assert(100+x-fc[id]>=0);
		assert(100+x-fc[id]<=200);
		FOR(bx,(100+x-fc[id])/BLOCK,(100+x+fc[id])/BLOCK+1)
			FOR(by,(100+y-fc[id])/BLOCK,(100+y+fc[id])/BLOCK+1) 
				REP(i, gno[bx][by]) {
					int p = gid[bx][by][i];
					if (check[p] != checkid) {
						if (p<C) {
							if (circ_col(fc[id],x,y,fc[p],s[p].X,s[p].Y)) return false;
						} else {
							if (mix_col(fc[id],x,y,fr[p-C].X,fr[p-C].Y,s[p].X,s[p].Y)) return false;
						}
						check[p] = checkid;
					}
				}
		return true;
	}
	
	INLINE bool check_rect(VPII &s, int id, int x, int y) {
		checkid++;
		if (!rect_ins(fr[id].X,fr[id].Y,x,y)) return false;
		FOR(bx,(100+x)/BLOCK,(100+x+fr[id].X)/BLOCK+1)
			FOR(by,(100+y)/BLOCK,(100+y+fr[id].Y)/BLOCK+1)
				REP(i, gno[bx][by]) {
					int p = gid[bx][by][i];
					if (check[p] != checkid) {
						if (p<C) {
							if (mix_col(fc[p],s[p].X,s[p].Y,fr[id].X,fr[id].Y,x,y)) return false;
						} else {
							if (rect_col(fr[id].X,fr[id].Y,x,y,fr[p-C].X,fr[p-C].Y,s[p].X,s[p].Y)) return false;
						}
						check[p] = checkid;
					}
				}
		return true;
	}
};

State state;
VPII gen_greedy(int t=0, int offx=0, int offy=0) {
	VPII s(N, MP(INF,INF));
	int usedr = 0;
	int usedc = 0;
	
	VI orderc; REP(i,C) orderc.PB(i);
	sort(ALL(orderc), [&](int a, int b) -> bool {return fc[a]>fc[b];});
	VI orderr; REP(i,R) orderr.PB(i);
	// sort(ALL(orderr), [&](int a, int b) -> bool {return fr[a].X*fr[a].Y>fr[b].X*fr[b].Y;});
	if (t == 0) {
		sort(ALL(orderr), [&](int a, int b) -> bool {return fr[a].X*100+fr[a].Y>fr[b].X*100+fr[b].Y;});
	} else if (t == 1) {
		sort(ALL(orderr), [&](int a, int b) -> bool {return fr[a].Y*100+fr[a].X>fr[b].Y*100+fr[b].X;});
	} else if (t == 2) {
		sort(ALL(orderr), [&](int a, int b) -> bool {return fr[a].X*fr[a].Y>fr[b].X*fr[b].Y;});
	}
	
	double max_total_area = 30000;
	
	double max_circ_area = max_total_area * (1 - X);
	double max_rect_area = max_total_area * X;
	
	VPII vpos; FOR(x,-100,100) FOR(y,-100,100) vpos.PB(MP(x,y));
	sort(ALL(vpos), [](PII &a, PII &b) -> bool {return SQR(a.X)+SQR(a.Y)<SQR(b.X)+SQR(b.Y);});
	
	VPII xpos; FOR(x,-100,100) FOR(y,-100,100) xpos.PB(MP(x,y));
	sort(ALL(xpos), [&](PII &a, PII &b) -> bool {return SQR(a.X+offx)+SQR(a.Y+offy)<SQR(b.X+offx)+SQR(b.Y+offy);});
	
	state.clear();
	
	while (true) {
		if (usedr == R && usedc == C || get_time() - xtime > TIME_LIMIT) break;
		
		PDD p = get_area(s);
		double c = p.X; 
		double r = p.Y;
		if (X*c < (1-X)*r && usedc < C || usedr == R && usedc < C) {
			// greedy circle
			while (c + fc[orderc[usedc]]*fc[orderc[usedc]]*PI >= max_circ_area && usedc+1 < C && usedr < R && c + fc[orderc[usedc+1]]*fc[orderc[usedc+1]]*PI >= max_circ_area && max_r > max_total_area )
				usedc++;
			
			for (PII &p : vpos) {
				if (state.check_circ(s, orderc[usedc], p.X, p.Y)) {
					s[orderc[usedc]] = p;
					state.add_circ(orderc[usedc],p.X,p.Y);
					goto donec;
				}
			}
			
			while (usedc+1 < C && fc[orderc[usedc]] == fc[orderc[usedc+1]]) usedc++;
			
			donec: ;
			usedc++;
		} else {
			// greedy rect
			while (r + fr[orderr[usedr]].X*fr[orderr[usedr]].Y >= max_rect_area && usedr+1 < R && usedc < C && r + fr[orderr[usedr+1]].X*fr[orderr[usedr+1]].Y >= max_rect_area && max_c > max_total_area)
				usedr++;
			
			for (PII &p : xpos) {
				if (state.check_rect(s, orderr[usedr], p.X, p.Y)) {
					s[C+orderr[usedr]] = p;
					state.add_rect(orderr[usedr], p.X, p.Y);
					goto doner;
				}
			}
			// for (int x = 100; x >= -100; x--) FOR(y, -100, +100) {
				// if (rect_ok(s, orderr[usedr], x, y)) {
					// s[C+orderr[usedr]] = MP(x, y);
					// goto doner;
				// }
			// }
			
			doner: ;
			usedr++;
		}
	}
	return s;
	
}

class TastyPizza {public: VS findSolution(int C, int R, double X, VI &circles, VPII &rects) { 
	xtime = get_time();
	
	DB(R,C,X);
	
	::X = X;
	::R = R;
	::C = C;
	N = R+C;
	fc = circles;
	fr = rects;
	
	REP(i, C) max_c += fc[i]*fc[i]*PI;
	REP(i, R) max_r += fr[i].X*fr[i].Y;
	DB(max_c, max_r);
	
	double bv = 0;
	
	int run = 0;
	
	VPII bsol;
	while (get_time() - xtime < TIME_LIMIT) {
		VPII sol = gen_greedy(run%3,run<3?0:rng.next(-5,5),run<3?0:rng.next(-5,5));
		double av = score(sol);
		if (av > bv) {
			bv = av;
			bsol = sol;
		}
		DB(run, av);
		run++;
	}
	
	PDD p = get_area(bsol);
	DB(p.X,p.Y,abs(X*p.X-(1-X)*p.Y));
	
	DB(get_time() - xtime);
	
	VS rv;
	REP(i, N) rv.PB(bsol[i].X >= INF ? "NA" : i2s(bsol[i].X)+" "+i2s(bsol[i].Y));
	return rv; 
}};

int main() {
  TastyPizza prog;
  int R, C;
  double X;
  cin >> C >> R >> X;
  VPII aRect(R);
  VI aCircles(C);
  REP(i, C) cin >> aCircles[i];
  REP(i, R) cin >> aRect[i].first >> aRect[i].second;
  VS ret = prog.findSolution(C, R, X, aCircles, aRect);
  cout << ret.S << endl;
  REP(i, ret.S) cout << ret[i] << endl;
  cout.flush();
}