const double TL2 = 3.33;
const double TL1 = 2*TL2/3.0;
#include <bits/stdc++.h>
using namespace std;
#define F0(i,n) for (int i=0; i<n; i++)
#define FR(i,n) for (int i=n-1; i>=0; i--)
#define F1(i,n) for (int i=1; i<=n; i++)
#define CL(a,x) memset(x, a, sizeof(x));
#define SZ(x) ((int)x.size())
const int inf = 1000009;
const double pi = acos(-1.0);
typedef pair<int, int> pii;
typedef long long ll;
const double EPS = 1e-9;
#define PR(x) cerr << #x << "=" << x << endl

inline ll GetTSC() {
    ll lo, hi;
    asm volatile ("rdtsc": "=a"(lo), "=d"(hi));
    return lo + (hi << 32);
}
inline double GetSeconds() {
    return GetTSC() / 2.79e9;
}

const int MAX_RAND = 1 << 30;
struct Rand {
    ll x, y, z, w, o;
    Rand(ll seed) { reseed(seed); o = 0; }
    inline void reseed(ll seed) { x = 0x498b3bc5 ^ seed; y = 0; z = 0; w = 0;  F0(i, 10) mix(); }
    inline void mix() { ll t = x ^ (x << 11); x = y; y = z; z = w; w = w ^ (w >> 19) ^ t ^ (t >> 8); }
    inline ll rand() { mix(); return x & (MAX_RAND - 1); }
    inline int nextInt(int n) { return rand() % n; }
    inline int nextInt(int L, int R) { return rand()%(R - L + 1) + L; }
    inline int nextBool() { if (o < 4) o = rand(); o >>= 2; return o & 1; }
    double nextDouble() { return rand() * 1.0 / MAX_RAND; }
};
Rand my(2021);
double saveTime;
double t_o[20];
ll c_o[20];
void Init() {
    saveTime = GetSeconds();
    F0(i, 20) t_o[i] = 0.0;
    F0(i, 20) c_o[i] = 0;
}
double Elapsed() { return GetSeconds() - saveTime; }
void Report() {
    cerr << "-------------------------------------" << endl;
    cerr << "Elapsed time: " << Elapsed() << " sec" << endl;
    double total = 0.0; F0(i, 20) { if (t_o[i] > 0) cerr << "t_o[" << i << "] = " << t_o[i] << endl; total += t_o[i]; } cerr << endl; //if (total > 0) cerr << "Total spent: " << total << endl;
    F0(i, 20) if (c_o[i] > 0) cerr << "c_o[" << i << "] = " << c_o[i] << endl;
    cerr << "-------------------------------------" << endl;
}
struct AutoTimer {
    int x;
    double t;
    AutoTimer(int x) : x(x) {
        t = Elapsed();
    }
    ~AutoTimer() {
        t_o[x] += Elapsed() - t;
    }
};
#define AT(i) AutoTimer a##i(i)
//#define AT(i)

// CONSTANTS
const int N = 1024;
const int CR = 100;
const int MAXPOS = (2*CR+1) * (2*CR+1);
const int B = 24;
const int MINR = 5;
const int MAXR = 15;
const int MINW = 5;
const int MAXW = 25;
const int MAXG = 2*CR/B+10;
const int DX[]={-1,0,1,0};
const int DY[]={0,1,0,-1};
double coeff;
int n, C, R;
double X;
set<int> rpool[64];
double bestScore, score, cscore, rscore;
vector<pii> bestSol, sol;
int r[N], w[N], h[N], ax[N], ay[N];
int cZ, checkz[N];
int tn[MAXG][MAXG], t[MAXG][MAXG][128];
int threatn, threat[N];
double losec[N], loser[N], areaof[64];
pii gvalues[64], sgvalus[64];
int gn, sgn;
int curr_rem[N], curr_remn;
pii c_pos[MAXR + 1][MAXPOS], c_touch_pos[MAXR + 1][MAXPOS];
int c_posn[MAXR+1], c_touch_posn[MAXR+1];
pii r_pos[MAXW+1][MAXW+1][MAXPOS], r_touch_pos[MAXW+1][MAXW+1][MAXPOS];
int r_posn[MAXW+1][MAXW+1], r_touch_posn[MAXW+1][MAXW+1];

double area[N];
const int LOGN = 1 << 16;
double logs[LOGN];

void UpdateBest() {
    if (score > bestScore) {
        bestScore = score;
        F0(i, n) bestSol[i] = pii(ax[i], ay[i]);
    }
}

double FV(double c, double r) {
    return c + r - abs(X*c - (1-X)*r) * coeff;
}

double F(double c, double r) {
    return c + r - abs(X*c - (1-X)*r);
}

inline int sq(int x) { return x * x; }

/*
void PrepG(int x, int y, int r) {
    int X1 = x - r;
    int Y1 = y - r;
    int X2 = x + r;
    int Y2 = y + r;
    X1 += CR;
    Y1 += CR;
    X2 += CR;
    Y2 += CR;
    X1 /= B;
    Y1 /= B;
    X2 /= B;
    Y2 /= B;
    gn = 0;
    for (int X = X1; X <= X2; X++) for (int Y = Y1; Y <= Y2; Y++) gvalues[gn++] = {X, Y};
}

void PrepG(int x, int y, int w, int h) {
    int X1 = x;
    int Y1 = y;
    int X2 = x + w;
    int Y2 = y + h;
    X1 += CR;
    Y1 += CR;
    X2 += CR;
    Y2 += CR;
    X1 /= B;
    Y1 /= B;
    X2 /= B;
    Y2 /= B;
    gn = 1;
    gvalues[0] = pii(X1, Y1);
    if (X1 != X2) {
        gvalues[gn++] = pii(X2, Y1);
        if (Y1 != Y2) gvalues[gn++] = pii(X2, Y2);
    }
    if (Y1 != Y2) gvalues[gn++] = pii(X1, Y2);
}*/

void PrepG(int i) {
    int X1 = 0, Y1 = 0, X2 = 0, Y2 = 0;
    if (i < C) {
        X1 = (ax[i] - r[i] + CR) / B;
        Y1 = (ay[i] - r[i] + CR) / B;
        X2 = (ax[i] + r[i] + CR) / B;
        Y2 = (ay[i] + r[i] + CR) / B;
    } else {
        X1 = (ax[i] + CR) / B;
        Y1 = (ay[i] + CR) / B;
        X2 = (ax[i] + w[i] + CR) / B;
        Y2 = (ay[i] + h[i] + CR) / B;
    }
    gn = 0;
    for (int X = X1; X <= X2; X++) for (int Y = Y1; Y <= Y2; Y++) gvalues[gn++] = {X, Y};
}

void AddTValue(int x, int y, int i) {
    //if (x < 0 || y < 0 || x >= MAXG || y >= MAXG) throw;
    t[x][y][tn[x][y]++] = i;
}

void RemTValue(int x, int y, int i) {
    F0(k, tn[x][y]) if (t[x][y][k] == i) {
        for (int l = k; l + 1 < tn[x][y]; l++) t[x][y][l] = t[x][y][l + 1];
        tn[x][y]--;
        return;
    }
    throw;
}

void AddT(int i) {
    //if (i < C) rpool[r[i]].erase(i);
    PrepG(i);
    F0(g, gn) AddTValue(gvalues[g].first, gvalues[g].second, i);
}

void RemT(int i) {
    //if (i < C) rpool[r[i]].insert(i);
    PrepG(i);
    F0(g, gn) RemTValue(gvalues[g].first, gvalues[g].second, i);
    ax[i] = inf;
}

bool int_circle_circle(int i, int j) {
    return sq(ax[i] - ax[j]) + sq(ay[i] - ay[j]) < sq(r[i] + r[j]);
}

bool int_rect_rect(int i, int j) {
    return ax[i] < ax[j] + w[j] && ax[i] + w[i] > ax[j] &&
            ay[i] < ay[j] + h[j] && ay[i] + h[i] > ay[j];
}

bool int_circle_rect(int i, int j) {
    int dx = abs(2*ax[i] - 2*ax[j] - w[j]);
    int dy = abs(2*ay[i] - 2*ay[j] - h[j]);
    if (dx >= w[j] + 2*r[i] || dy >= h[j] + 2*r[i]) return false;
    if (dx < w[j] || dy < h[j]) return true;
    return sq(dx-w[j]) + sq(dy-h[j]) < sq(2*r[i]);
}

bool int_circle_any(int i, int j) {
    if (j < C) return int_circle_circle(i, j);
    return int_circle_rect(i, j);
}

bool int_rect_any(int i, int j) {
    if (j < C) return int_circle_rect(j, i);
    return int_rect_rect(i, j);
}

bool inside(int x, int y) { return sq(x) + sq(y) <= sq(CR); }
bool inside(int x, int y, int r) { return sq(x) + sq(y) <= sq(CR - r); }
bool inside(int x1, int y1, int x2, int y2) {
    return inside(x1, y1) && inside(x1, y2) && inside(x2, y1) && inside(x2, y2);
}

bool IsSafe(int i) {
    if (i < C) {
        if (!inside(ax[i], ay[i], r[i])) return false;
        cZ++;
        checkz[i] = cZ;
        PrepG(i);
        F0(g, gn) {
            int x = gvalues[g].first, y = gvalues[g].second;
            F0(k, tn[x][y]) {
                int j = t[x][y][k];
                if (checkz[j] == cZ) continue;
                checkz[j] = cZ;
                if (int_circle_any(i, j)) {
                    return false;
                }
            }
        }
    } else {
        if (!inside(ax[i], ay[i], ax[i]+w[i], ay[i]+h[i])) return false;
        cZ++;
        checkz[i] = cZ;
        PrepG(i);
        F0(g, gn) {
            int x = gvalues[g].first, y = gvalues[g].second;
            F0(k, tn[x][y]) {
                int j = t[x][y][k];
                if (checkz[j] == cZ) continue;
                checkz[j] = cZ;
                if (int_rect_any(i, j)) {
                    return false;
                }
            }
        }
    }
    return true;
}

void Improve(double endTime) {
    int numStages = 20;
    int itc = 2000000000;
    //itc = 100000;
    double T1 = 0.0, T2 = 20.0 + 10*X, T = 0.0;
    int tot = 1, acc = 0, lastStage = -1;
    double startTime = Elapsed();
    int gl = 0;
    F0(iter, itc) {
        if ((iter & 255) == 0) {
            //double r = 1.0 * (itc - iter) / itc;
            double r = (endTime - Elapsed()) / (endTime - startTime);
            coeff = 0.0+1.0*(1-r);
            if (1) {
                int newStage = (1 - r) * numStages;
                if (newStage != lastStage) {
                    lastStage = newStage;
                    cerr << "St: " << newStage << " " << 100.0*acc/tot << " " << bestScore << " " << score << endl;
                }
            }
            if (r <= 0) {
                PR(iter);
                break;
            }
            T = T1 + (T2 - T1) * r;
        }
        // TODO: bigger ones more likely
        int i = gl;
        if (++gl == n) gl = 0;

        /*
        if (my.nextDouble() <= 0.5) {
            i = my.nextInt(C);
        } else {
            i = my.nextInt(R) + C;
        }*/
        //if (ax[i] == inf) i = my.nextInt(n);
        int u = my.rand();
        if (ax[i] != inf) {
            AT(1);
            int k = u & 3;
            int sx = ax[i], sy = ay[i];
            while (1) {
                ax[i] += DX[k];
                ay[i] += DY[k];
                bool still_in = false;
                if (i < C) {
                    if (inside(ax[i], ay[i], r[i])) {
                        still_in = true;
                        cZ++;
                        checkz[i] = cZ;
                        PrepG(i);
                        F0(g, gn) if (still_in) {
                            int x = gvalues[g].first, y = gvalues[g].second;
                            F0(k, tn[x][y]) {
                                int j = t[x][y][k];
                                if (checkz[j] == cZ) continue;
                                checkz[j] = cZ;
                                if (int_circle_any(i, j)) {
                                    still_in = false;
                                    break;
                                }
                            }
                        }
                    }
                } else {
                    if (inside(ax[i], ay[i], ax[i]+w[i], ay[i]+h[i])) {
                        still_in = true;
                        cZ++;
                        checkz[i] = cZ;
                        PrepG(i);
                        F0(g, gn) if (still_in) {
                            int x = gvalues[g].first, y = gvalues[g].second;
                            F0(k, tn[x][y]) {
                                int j = t[x][y][k];
                                if (checkz[j] == cZ) continue;
                                checkz[j] = cZ;
                                if (int_rect_any(i, j)) {
                                    still_in = false;
                                    break;
                                }
                            }
                        }
                    }
                }
                if (!still_in) {
                    ax[i] -= DX[k];
                    ay[i] -= DY[k];
                    break;
                }
            }

            if (sx != ax[i] || sy != ay[i]) {
                int ex = ax[i], ey = ay[i];
                ax[i] = sx; ay[i] = sy; RemT(i);
                ax[i] = ex; ay[i] = ey; AddT(i);
            } /*else if (my.nextInt(4)) {
                int k2 = (k+2*my.nextInt(2)+5)%4;

                while (IsSafe(i)) {
                    ax[i] += DX[k2];
                    ay[i] += DY[k2];
                }
                ax[i] -= DX[k2];
                ay[i] -= DY[k2];
                int delta = abs(ax[i]-sx) + abs(ay[i]-sy);
                if (delta >= 8) {
                    int times = my.nextInt(delta - 1) + 1;
                    ax[i] = sx + DX[k2] * times;
                    ay[i] = sy + DY[k2] * times;
                    //cerr << times << "/" << delta << endl;
                    while (1) {
                        ax[i] += DX[k];
                        ay[i] += DY[k];
                        if (!IsSafe(i)) {
                            ax[i] -= DX[k];
                            ay[i] -= DY[k];
                            break;
                        }
                    }
                    if (sx != ax[i] && sy != ay[i]) {
                        int ex = ax[i], ey = ay[i];
                        ax[i] = sx; ay[i] = sy; RemT(i);
                        ax[i] = ex; ay[i] = ey; AddT(i);
                    } else {
                        ax[i] = sx;
                        ay[i] = sy;
                    }
                } else {
                    ax[i] = sx;
                    ay[i] = sy;
                }
            }*/
            continue;
        }
        int mode = u & 15;
        u >>= 4;
        /*
        if (i < C) {
            if (mode >= 15) {
                AT(5);
                threatn = 0;
                int k = my.nextInt(c_posn[MINR]);
                ax[n] = c_pos[MINR][k].first;
                ay[n] = c_pos[MINR][k].second;
                int rmax = 5;
                while (rmax + 1 <= MAXR && inside(ax[n], ay[n], rmax + 1)) rmax++;
                r[n] = rmax;
                for (int k = MINR; k <= rmax; k++) losec[k] = loser[k] = 0.0;
                PrepG(ax[n], ay[n], rmax);
                cZ++;
                F0(g, gn) {
                    int x = gvalues[g].first, y = gvalues[g].second;
                    F0(k, tn[x][y]) {
                        int j = t[x][y][k];
                        if (checkz[j] == cZ) continue;
                        checkz[j] = cZ;
                        if (int_circle_any(n, j)) {
                            threat[threatn++] = j;
                        }
                    }
                }
                F0(i, threatn) {
                    int P = MINR, Q = rmax;
                    while (P < Q) {
                        r[n] = (P + Q) / 2;
                        if (int_circle_any(n, threat[i])) {
                            Q = r[n];
                        } else P = r[n] + 1;
                    }
                    if (threat[i] < C) losec[P] += area[threat[i]]; else loser[P] += area[threat[i]];
                }
                double maxscore = score - T * logs[my.nextInt(LOGN)] - EPS;
                double nc = cscore;
                double nr = rscore;
                int winr = -1;
                for (int k = MINR; k <= rmax; k++) {
                    nc -= losec[k];
                    nr -= loser[k];
                    double v = F(nc + areaof[k], nr);
                    // TODO: better pool
                    if (v > maxscore && !rpool[k].empty()) {
                        maxscore = v;
                        winr = k;
                    }
                }
                if (winr != -1) {
                    int i = *rpool[winr].begin();
                    ax[i] = ax[n];
                    ay[i] = ay[n];
                    F0(j, threatn) {
                        if (int_circle_any(i, threat[j])) {
                            if (threat[j] < C) cscore -= area[threat[j]]; else rscore -= area[threat[j]];
                            RemT(threat[j]);
                        }
                    }
                    cscore += area[i];
                    score = F(cscore, rscore);
                    AddT(i);
                    UpdateBest();
                }
                continue;
            }
        }*/

        //AT(2)
        if (i < C) {
            if (mode >= 12) {
                int k = u % c_posn[r[i]];
                ax[i] = c_pos[r[i]][k].first;
                ay[i] = c_pos[r[i]][k].second;
            } else {
                int k = u % c_touch_posn[r[i]];
                ax[i] = c_touch_pos[r[i]][k].first;
                ay[i] = c_touch_pos[r[i]][k].second;
            }
        } else {
            if (mode >= 4) {
                int k = u % r_posn[w[i]][h[i]];
                ax[i] = r_pos[w[i]][h[i]][k].first;
                ay[i] = r_pos[w[i]][h[i]][k].second;
            } else {
                int k = u % r_touch_posn[w[i]][h[i]];
                ax[i] = r_touch_pos[w[i]][h[i]][k].first;
                ay[i] = r_touch_pos[w[i]][h[i]][k].second;
            }
        }
        double nc = cscore, nr = rscore;
        curr_remn = 0;
        cZ++;
        PrepG(i);
        if (i < C) {
            //AT(3);
            nc += area[i];
            F0(g, gn) {
                int x = gvalues[g].first, y = gvalues[g].second;
                F0(k, tn[x][y]) {
                    int j = t[x][y][k];
                    if (checkz[j] == cZ) continue;
                    checkz[j] = cZ;
                    if (int_circle_any(i, j)) {
                        curr_rem[curr_remn++] = j;
                        if (j < C) nc -= area[j]; else nr -= area[j];
                    }
                }
            }
        } else {
            //AT(4);
            nr += area[i];
            F0(g, gn) {
                int x = gvalues[g].first, y = gvalues[g].second;
                F0(k, tn[x][y]) {
                    int j = t[x][y][k];
                    if (checkz[j] == cZ) continue;
                    checkz[j] = cZ;
                    if (int_rect_any(i, j)) {
                        curr_rem[curr_remn++] = j;
                        if (j < C) nc -= area[j]; else nr -= area[j];
                    }
                }
            }
        }
        double nscore = F(nc, nr);

        double v1 = FV(cscore, rscore);
        double v2 = FV(nc, nr);
        double delta = v2 - v1;

        tot++;
        if (delta >= 0 || delta >= -T * logs[my.nextInt(LOGN)]) {
            acc++;
            score = nscore;
            cscore = nc;
            rscore = nr;

            F0(k, curr_remn) RemT(curr_rem[k]);
            AddT(i);
            //if (lastStage >= 17)
            UpdateBest();
        } else {
            ax[i] = inf;
        }
    }
    UpdateBest();
}

void Prep() {
    F0(i, LOGN) logs[i] = -log((i+0.5)/LOGN);
    //F0(i, C) rpool[r[i]].insert(i);
    for (int r = MINR; r <= MAXR; r++) areaof[r] = pi * r * r;
    for (int x = -CR; x <= CR; x++) {
        for (int y = -CR; y <= CR; y++) if (inside(x, y)) {
            for (int r = 1; r <= MAXR; r++) if (inside(x, y, r)) {
                c_pos[r][c_posn[r]++] = pii(x, y);
                F0(k, 4) {
                    int x2 = x+DX[k], y2 = y+DY[k];
                    if (!inside(x2, y2) || !inside(x2, y2, r)) {
                        c_touch_pos[r][c_touch_posn[r]++] = pii(x, y);
                        break;
                    }
                }
            }
            for (int w = MINW; w <= MAXW; w++) if (inside(x + w, y)) {
                int h = MINW;
                if (!inside(x, y + h) || !inside(x + w, y + h)) continue;
                while (inside(x, y + h) && inside(x + w, y + h) && h <= MAXW) {
                    r_pos[w][h][r_posn[w][h]++] = pii(x, y);
                    F0(k, 4) if (!inside(x + DX[k], y + DY[k], x + DX[k] + w, y + DY[k] + h)) {
                        r_touch_pos[w][h][r_touch_posn[w][h]++] = pii(x, y);
                        break;
                    }
                    h++;
                }
            }
        }
    }
    PR(Elapsed());
}

int candx[N*N], candy[N*N], candn, cand_index[N], indn;
const int MAXI = 1<<14;
pii history[1<<20];
int h_index[1<<20], hn;


void MicroSA(double TL2) {
    while (Elapsed() < TL2) {
        double T1 = 0.0, T2 = 32.0, T = 0.0;
        int itc = MAXI;
        int SIDE = 24;
        int sx = my.nextInt(2*CR-SIDE)-CR;
        int sy = my.nextInt(2*CR-SIDE)-CR;

        candn = 0;
        F0(dx, SIDE) F0(dy, SIDE) if (inside(sx + dx, sy + dy)) {
            candx[candn] = sx + dx;
            candy[candn++] = sy + dy;
        }
        int sd = SIDE;
        while (candn < SIDE * SIDE && (sx + sd <= CR || sy + sd <= CR)) {
            F0(dx, SIDE) if (inside(sx + dx, sy + sd)) {
                candx[candn] = sx + dx;
                candy[candn++] = sy + sd;
            }
            F0(dy, SIDE-1) if (inside(sx + sd, sy + dy)) {
                candx[candn] = sx + sd;
                candy[candn++] = sy + dy;
            }
            sd++;
        }
        //cerr << candn << " " << SIDE*SIDE << " " << sx << " " << sy << " " << indn << endl;
        if (candn < SIDE * SIDE / 2) continue;
        indn = 0;
        F0(i, n) if (ax[i] == inf || (ax[i] >= sx && ay[i] >= sy && ax[i] < sx+sd && ay[i] < sy+sd)) cand_index[indn++] = i;
        if (indn == 0) continue;

        hn = 0;
        double current_bscore = score;
        double local_bscore = score;
        int local_bh = 0;

        int tot = 1, acc = 0;
        int gl = my.nextInt(indn);
        F0(iter, itc) {
            if ((iter & 63) == 0) {
                double r = 1.0 * (itc - iter) / itc;
                coeff = 1;
                if (r <= 0) {
                    break;
                }
                T = T1 + (T2 - T1) * r;
            }
            int i = cand_index[gl];
            if (++gl == indn) gl = 0;

            int u = my.rand();
            if (ax[i] != inf) {
                int k = u & 3;
                int sx = ax[i], sy = ay[i];
                while (1) {
                    ax[i] += DX[k];
                    ay[i] += DY[k];
                    bool still_in = false;
                    if (i < C) {
                        if (inside(ax[i], ay[i], r[i])) {
                            still_in = true;
                            cZ++;
                            checkz[i] = cZ;
                            PrepG(i);
                            F0(g, gn) if (still_in) {
                                int x = gvalues[g].first, y = gvalues[g].second;
                                F0(k, tn[x][y]) {
                                    int j = t[x][y][k];
                                    if (checkz[j] == cZ) continue;
                                    checkz[j] = cZ;
                                    if (int_circle_any(i, j)) {
                                        still_in = false;
                                        break;
                                    }
                                }
                            }
                        }
                    } else {
                        if (inside(ax[i], ay[i], ax[i]+w[i], ay[i]+h[i])) {
                            still_in = true;
                            cZ++;
                            checkz[i] = cZ;
                            PrepG(i);
                            F0(g, gn) if (still_in) {
                                int x = gvalues[g].first, y = gvalues[g].second;
                                F0(k, tn[x][y]) {
                                    int j = t[x][y][k];
                                    if (checkz[j] == cZ) continue;
                                    checkz[j] = cZ;
                                    if (int_rect_any(i, j)) {
                                        still_in = false;
                                        break;
                                    }
                                }
                            }
                        }
                    }
                    if (!still_in) {
                        ax[i] -= DX[k];
                        ay[i] -= DY[k];
                        break;
                    }
                }

                if (sx != ax[i] || sy != ay[i]) {
                    int ex = ax[i], ey = ay[i];
                    ax[i] = sx; ay[i] = sy; RemT(i); h_index[hn] = i; history[hn++] = pii(sx, sy);
                    ax[i] = ex; ay[i] = ey; AddT(i); h_index[hn] = i; history[hn++] = pii(inf, inf);
                }
                continue;
            }
            int k = u % candn;
            ax[i] = candx[k];
            ay[i] = candy[k];
            if (i < C && !inside(ax[i], ay[i], r[i])) {
                ax[i] = inf;
                continue;
            }
            if (i >= C && !inside(ax[i], ay[i], ax[i] + w[i], ay[i] + h[i])) {
                ax[i] = inf;
                continue;
            }
            double nc = cscore, nr = rscore;
            curr_remn = 0;
            cZ++;
            PrepG(i);
            if (i < C) {
                //AT(3);
                nc += area[i];
                F0(g, gn) {
                    int x = gvalues[g].first, y = gvalues[g].second;
                    F0(k, tn[x][y]) {
                        int j = t[x][y][k];
                        if (checkz[j] == cZ) continue;
                        checkz[j] = cZ;
                        if (int_circle_any(i, j)) {
                            curr_rem[curr_remn++] = j;
                            if (j < C) nc -= area[j]; else nr -= area[j];
                        }
                    }
                }
            } else {
                //AT(4);
                nr += area[i];
                F0(g, gn) {
                    int x = gvalues[g].first, y = gvalues[g].second;
                    F0(k, tn[x][y]) {
                        int j = t[x][y][k];
                        if (checkz[j] == cZ) continue;
                        checkz[j] = cZ;
                        if (int_rect_any(i, j)) {
                            curr_rem[curr_remn++] = j;
                            if (j < C) nc -= area[j]; else nr -= area[j];
                        }
                    }
                }
            }
            double nscore = F(nc, nr);

            double v1 = FV(cscore, rscore);
            double v2 = FV(nc, nr);
            double delta = v2 - v1;

            tot++;
            if (delta >= 0 || delta >= -T * logs[my.nextInt(LOGN)]) {
                acc++;
                score = nscore;
                cscore = nc;
                rscore = nr;

                F0(k, curr_remn) {
                    h_index[hn] = curr_rem[k]; history[hn++] = pii(ax[curr_rem[k]], ay[curr_rem[k]]);
                    if (ax[curr_rem[k]] == inf) throw;
                    RemT(curr_rem[k]);
                }
                AddT(i);
                h_index[hn] = i; history[hn++] = pii(inf, inf);
                if (score >= local_bscore) {
                    local_bscore = score;
                    local_bh = hn;
                }
            } else {
                ax[i] = inf;
            }
        }
        for (int k = hn - 1; k >= local_bh; k--) {
            int i = h_index[k];
            pii p = history[k];
            if (p.first == inf) {
                if (i < C) cscore -= area[i]; else rscore -= area[i];
                RemT(i);
            } else {
                if (i < C) cscore += area[i]; else rscore += area[i];
                ax[i] = p.first;
                ay[i] = p.second;
                AddT(i);
            }
        }
        score = F(cscore, rscore);
        if (score > bestScore) {
            //cerr << bestScore << " " << current_bscore << " " << local_bscore << " " << local_bh << "/" << hn << endl;
            UpdateBest();
        }
    }
}

struct TastyPizza {
vector<string> findSolution(int _C, int _R, double _X, vector<int> &aCircles, vector<pair<int, int> > &aRect) {
    Init();

    C = _C; R = _R; X = _X; n = C + R;

    PR(C); PR(R); PR(X);
    F0(i, C) {
        r[i] = aCircles[i];
        area[i] = pi * r[i] * r[i];
    }
    F0(i, R) {
        w[i + C] = aRect[i].first;
        h[i + C] = aRect[i].second;
        area[i + C] = w[i + C] * h[i + C];
    }
    bestSol.assign(C+R, pii(inf, inf));
    bestScore = 0.0;
    Prep();

    cscore = 0.0;
    rscore = 0.0;
    score = F(cscore, rscore);
    F0(i, n) ax[i] = ay[i] = inf;

    Improve(TL2);

    //Improve(TL1);
    //MicroSA(TL2);

    /*
    cscore = 0.0;
    rscore = 0.0;
    score = F(cscore, rscore);
    F0(i, n) if (ax[i] != inf) RemT(i);
    Improve(2*TL);
    */

    F0(i, 0) {
        cscore = 0.0;
        rscore = 0.0;
        score = F(cscore, rscore);
        F0(i, n) if (ax[i] != inf) RemT(i);
        Improve(TL1*(i+2));
    }

    PR(bestScore);
    vector<string> ret;
    F0(i, C+R) if (bestSol[i].first != inf) {
        ret.push_back(to_string(bestSol[i].first) + " " + to_string(bestSol[i].second));
    } else {
        ret.push_back("NA");
    }
    Report();
    return ret;
}};














void RunVis() {
    TastyPizza prog;
    int R, C;
    double X;
    cin >> C >> R >> X;
    vector< pair<int, int> > aRect(R);
    vector<int> aCircles(C);
    for (int i=0;i<C;i++)
    {
      cin >> aCircles[i];
    }
    for (int i=0;i<R;i++)
    {
      cin >> aRect[i].first >> aRect[i].second;
    }
    vector<string> ret = prog.findSolution(C, R, X, aCircles, aRect);
    cout << ret.size() << endl;
    for (int i = 0; i < (int)ret.size(); ++i)
        cout << ret[i] << endl;
    cout.flush();
}

void RunFromSave() {
    ignore = freopen("2.txt", "r", stdin);
    RunVis();
}

void RunVisSave() {
    ignore = freopen("2.txt", "w", stdout);
    int R, C;
    double X;
    cin >> C >> R >> X;
    cout << C << " " << R << " " << X << endl;
    vector< pair<int, int> > aRect(R);
    vector<int> aCircles(C);
    for (int i=0;i<C;i++)
    {
      cin >> aCircles[i];
      cout << aCircles[i] << endl;
    }
    for (int i=0;i<R;i++)
    {
      cin >> aRect[i].first >> aRect[i].second;
      cout << aRect[i].first << " " << aRect[i].second << endl;
    }
}

int main(int argc, char* argv[]) {
#ifdef RED
    auto x = freopen("log.txt", "w", stderr); (void)x;
#endif
    (void)argv; if (argc > 1) {
        RunFromSave(); exit(0);
    }
    //RunVisSave(); exit(0);
    RunVis();

    return 0;
}
