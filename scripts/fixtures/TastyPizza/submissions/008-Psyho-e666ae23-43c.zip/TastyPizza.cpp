// Author: Psyho
// Twitter: https://twitter.com/fakepsyho
// Site: http://psyho.gg/
 
#include <bits/stdc++.h>
#include <sys/time.h>
 
using namespace std;
 
#define INLINE   inline __attribute__ ((always_inline))
#define NOINLINE __attribute__ ((noinline))

#define byte        unsigned char
#define FOR(i,a,b)  for(int i=(a);i<(b);++i)
#define REP(i,a)    FOR(i,0,a)
#define ZERO(m)     memset(m,0,sizeof(m))
#define MINUS(m)    memset(m,-1,sizeof(m))
#define ALL(x)      x.begin(),x.end()
#define PB          push_back
#define S           size()
#define LL          long long
#define ULL         unsigned long long
#define LD          long double
#define MP          make_pair
#define X           first
#define Y           second
#define VC          vector
#define PII         pair<int, int>
#define PDD         pair<double, double>
#define PIII        pair<PII, int>
#define VB          VC<byte>
#define VVB         VC<VB>
#define VI          VC<int>
#define VVI         VC<VI>
#define VVVI        VC<VVI>
#define VPII        VC<PII>
#define VVPII       VC<VPII>
#define VD          VC<double>
#define VVD         VC<VD>
#define VVVD        VC<VVD>
#define VVVVD       VC<VVVD>
#define VF          VC<float>
#define VVF         VC<VF>
#define VVVF        VC<VVF>
#define VS          VC<string>
#define VVS         VC<VS>
 
template<typename A, typename B> ostream& operator<<(ostream &os, pair<A,B> p) {os << "(" << p.X << "," << p.Y << ")"; return os;}
template<typename A, typename B, typename C> ostream& operator<<(ostream &os, tuple<A,B,C> p) {os << "(" << get<0>(p) << "," << get<1>(p) << "," << get<2>(p) << ")"; return os;}
template<typename T> ostream& operator<<(ostream &os, VC<T> v) {os << "{"; REP(i, v.S) {if (i) os << ", "; os << v[i];} os << "}"; return os;}
template<typename T> ostream& operator<<(ostream &os, set<T> s) {VS vs(ALL(s)); return os << vs;}
template<typename T> string i2s(T x) {ostringstream o; o << x; return o.str();}
VS splt(string s, char c = ' ') {VS all; int p = 0, np; while (np = s.find(c, p), np >= 0) {if (np != p) all.PB(s.substr(p, np - p)); p = np + 1;} if (p < s.S) all.PB(s.substr(p)); return all;}

#define ARGS_SIZE_(a1,a2,a3,a4,a5,a6,a7,a8,a9,size,...) size
#define ARGS_SIZE(...) ARGS_SIZE_(__VA_ARGS__,9,8,7,6,5,4,3,2,1)

#define DB_1(x) #x << "=" << (x) <<
#define DB_2(x, ...) #x << "=" << (x) << ", " << DB_1(__VA_ARGS__)
#define DB_3(x, ...) #x << "=" << (x) << ", " << DB_2(__VA_ARGS__)
#define DB_4(x, ...) #x << "=" << (x) << ", " << DB_3(__VA_ARGS__)
#define DB_5(x, ...) #x << "=" << (x) << ", " << DB_4(__VA_ARGS__)
#define DB_6(x, ...) #x << "=" << (x) << ", " << DB_5(__VA_ARGS__)
#define DB_7(x, ...) #x << "=" << (x) << ", " << DB_6(__VA_ARGS__)
#define DB_8(x, ...) #x << "=" << (x) << ", " << DB_7(__VA_ARGS__)
#define DB_9(x, ...) #x << "=" << (x) << ", " << DB_8(__VA_ARGS__)
#define DB__(size, ...) DB_##size(__VA_ARGS__)
#define DB_(size, ...) DB__(size, __VA_ARGS__)
#define DB(...) do {cerr << DB_(ARGS_SIZE(__VA_ARGS__), __VA_ARGS__) endl;} while (0)
 
double get_time() {timeval tv; gettimeofday(&tv, NULL); return tv.tv_sec + tv.tv_usec * 1e-6;}
 
struct RNG {
    unsigned int MT[624];
    int index;
    RNG(int seed = 1) {init(seed);}
    void init(int seed = 1) {MT[0] = seed; FOR(i, 1, 624) MT[i] = (1812433253UL * (MT[i-1] ^ (MT[i-1] >> 30)) + i); index = 0; }
    void generate() {
        const unsigned int MULT[] = {0, 2567483615UL};
        REP(i, 227) {unsigned int y = (MT[i] & 0x8000000UL) + (MT[i+1] & 0x7FFFFFFFUL); MT[i] = MT[i+397] ^ (y >> 1); MT[i] ^= MULT[y&1]; }
        FOR(i, 227, 623) {unsigned int y = (MT[i] & 0x8000000UL) + (MT[i+1] & 0x7FFFFFFFUL); MT[i] = MT[i-227] ^ (y >> 1); MT[i] ^= MULT[y&1]; }
        unsigned int y = (MT[623] & 0x8000000UL) + (MT[0] & 0x7FFFFFFFUL); MT[623] = MT[623-227] ^ (y >> 1); MT[623] ^= MULT[y&1];
    }
    unsigned int rand() { if (index == 0) generate(); unsigned int y = MT[index]; y ^= y >> 11; y ^= y << 7  & 2636928640UL; y ^= y << 15 & 4022730752UL; y ^= y >> 18; index = index == 623 ? 0 : index + 1; return y;}
    INLINE int next() {return rand(); }
    INLINE int next(int x) {return rand() % x; }
    INLINE int next(int a, int b) {return a + (rand() % (b - a)); }
    INLINE double next_double() {return (rand() + 0.5) * (1.0 / 4294967296.0); }
    INLINE double next_double(double a, double b) {return a + next_double() * (b - a); }
};
 
static RNG rng;

double start_time = get_time();

#define SQR(a) ((a)*(a))

bool circ_col(int r1, int x1, int y1, int r2, int x2, int y2) {
	return SQR(x2-x1)+SQR(y2-y1) < SQR(r1+r2);
}


      // return A.x < B.x+B.width  && A.x+A.width > B.x &&
             // A.y < B.y+B.height && A.y+A.height > B.y;

bool rect_col(int w1, int h1, int x1, int y1, int w2, int h2, int x2, int y2) {
	return x1 < x2+w2 && x1+w1 > x2 &&
	       y1 < y2+h2 && y1+h1 > y2;
}

const double EPS=1e-6;
bool mix_col(int r1, int x1, int y1, int w2, int h2, int x2, int y2) {
	double x = abs(x1 - (x2+w2/2.0));
	double y = abs(y1 - (y2+h2/2.0));
	if (x+EPS > w2/2.0 + r1) return false;
	if (y+EPS > h2/2.0 + r1) return false;
	if (x+EPS < w2/2.0) return true;
	if (y+EPS < h2/2.0) return true;
	double corner_dist = SQR(x - w2/2.0) + SQR(y - h2/2.0);
	return corner_dist+EPS < SQR(r1);
}

bool circ_ins(int r, int x, int y) {
	return SQR(x) + SQR(y) < SQR(100-r)-EPS;
}

bool rect_ins(int w, int h, int x, int y) {
	return SQR(x)+SQR(y) < 100*100-EPS &&
	       SQR(x)+SQR(y+h) < 100*100-EPS &&
	       SQR(x+w)+SQR(y) < 100*100-EPS &&
	       SQR(x+w)+SQR(y+h) < 100*100-EPS;
}

const double INF=1000;


double xtime;

int C,R,N;
double X;

VI   fc;
VPII fr;


double score(int r, int c) {
	return r + c - abs(X*c - (1-X)*r);
}

VPII gen_random() {
	double TIME_LIMIT = 1.0;
	
	int tc=0,tr=0;
	VPII s(N); REP(i,N) s[i].X = INF, s[i].Y = INF;

	int step = 0;
	while (true) {
		step++;
		if ((step & 1023) == 1023 && get_time() - xtime > TIME_LIMIT) break;
		
		int p = rng.next(N);
		int x = rng.next(-100, 100);
		int y = rng.next(-100, 100);
		
		if (p < C) {
			if (!circ_ins(fc[p],x,y)) goto bad;
			REP(i,C) if (i!=p && s[i].X < INF && circ_col(fc[p],x,y,fc[i],s[i].X,s[i].Y)) goto bad;
			REP(i,R) if (s[i+C].X < INF && mix_col(fc[p],x,y,fr[i].X,fr[i].Y,s[i+C].X,s[i+C].Y)) goto bad;
			tc++;
		} else {
			if (!rect_ins(fr[p-C].X,fr[p-C].Y,x,y)) goto bad;
			REP(i,C) if (s[i].X < INF && mix_col(fc[i],s[i].X,s[i].Y,fr[p-C].X,fr[p-C].Y,x,y)) goto bad;
			REP(i,R) if (i+C!=p && s[i+C].X < INF && rect_col(fr[p-C].X,fr[p-C].Y,x,y,fr[i].X,fr[i].Y,s[i+C].X,s[i+C].Y)) goto bad;
			tr++;
		}
		s[p] = MP(x,y);
		bad: ;
	}
	DB(score(tr,tc));
	// REP(i,R) REP(j,i) if (s[i+C].X < INF && s[j+C].X < INF && rect_col(fr[i].X,fr[i].Y,s[i+C].X,s[i+C].Y,fr[j].X,fr[j].Y,s[j+C].X,s[j+C].Y)) DB(i,j);
	
	return s;
}


class TastyPizza {public: VS findSolution(int C, int R, double X, VI &circles, VPII &rects) { 
	xtime = get_time();
	
	::X = X;
	::R = R;
	::C = C;
	N = R+C;
	fc = circles;
	fr = rects;
	
	VPII sol = gen_random();
	
	VS rv;
	REP(i, N) rv.PB(sol[i].X >= INF ? "NA" : i2s(sol[i].X)+" "+i2s(sol[i].Y));
	return rv; 
}};

int main() {
  TastyPizza prog;
  int R, C;
  double X;
  cin >> C >> R >> X;
  VPII aRect(R);
  VI aCircles(C);
  REP(i, C) cin >> aCircles[i];
  REP(i, R) cin >> aRect[i].first >> aRect[i].second;
  VS ret = prog.findSolution(C, R, X, aCircles, aRect);
  cout << ret.S << endl;
  REP(i, ret.S) cout << ret[i] << endl;
  cout.flush();
}