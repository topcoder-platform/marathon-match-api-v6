//#define NDEBUG

#pragma GCC target "avx"

#include <algorithm>
#include <bitset>
#include <cassert>
#include <cctype>
#include <climits>
#include <cmath>
#include <complex>
//#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <limits>
#include <list>
#include <map>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <string>
#include <utility>
#include <vector>
#include <array>

#include <sys/time.h>
#include <random>
#include <chrono>
#include <unordered_map>
#include <unordered_set>

#include <x86intrin.h>
#include <emmintrin.h>

using namespace std;
//#define DEBUG              // general information//

template<class T, class V> std::ostream&  operator <<(std::ostream& stream, const pair<T,V> & p) {
  stream << p.first << "," << p.second << " ";
  return stream;
}

template<class T> std::ostream&  operator <<(std::ostream& stream, const vector<T> & v) {
  for (auto el : v)
    stream << el << " ";
  return stream;
}

template<class T> std::ostream&  operator << (std::ostream& stream, const vector< vector<T> > & v) {
  for (auto line : v) {
    for (auto el : line)
      stream << el << " ";
    stream << "\n";
  }
  return stream;
}

class debugger {
public:
  template<class T> void output (const T& v) {
    cerr << v << " ";
  }
  
  template<class T> debugger& operator , (const T& v) {
    output(v);
    return *this;
  }
} dbg;

// Adapted from http://codeforces.com/blog/entry/15643
vector<string> debug_split(const string& s, char c) {
    vector<string> v; stringstream ss(s); string x;
    while (getline(ss, x, c)) v.emplace_back(x); return move(v);}

//void debug_err(vector<string>::iterator it) {cerr << "\n";}
template<typename T, typename... Args>
void debug_err(vector<string>::iterator it, T a, Args... args) {
    cerr << it -> substr((*it)[0] == ' ', it -> length()) << " = " << a << " | ";
    debug_err(++it, args...);
}

// End debug

////////////////
// templates  //
////////////////

// general
//template size
template<typename T> int size(const T& c) { return int(c.size()); }
//template abs
template<typename T> T abs(T x) { return x < 0 ? -x : x; }
//template sqr
template<typename T> T sqr(T x) { return x*x; }
//template remin
template<typename T> bool remin(T& x, T y) { if (x <= y) return false; x = y; return true; }
//template remax
template<typename T> bool remax(T& x, T y) { if (x >= y) return false; x = y; return true; }
//template toStr
template<typename T> string toStr(T x) { stringstream ss; ss << x; return ss.str(); }
//helper len
inline int len(const string & x){ return x.length(); }
//helper print_mask
inline void print_mask(int mask, int n){for (int i = 0; i < n; ++i) cerr << (char)('0' + (mask >> i & 1));}
//helper stoi
//int stoi(const string & s){stringstream ss(s); int res; ss >> res; return res;}
//helper itos
string itos(const int & x){stringstream ss; ss << x; return ss.str();}

// types
//template int64
typedef long long            int64 ;
//template uint64
typedef unsigned long long   uint64 ;
typedef unsigned char uchar;
typedef unsigned short ushort;
typedef int64 hash_type;

// shortcuts
#define all(_xx)             _xx.begin(), _xx.end()

#define pb                   push_back
#define vl                   vector<long long>
#define vs                   vector<string>
#define vvs                  vector<vector<string>>
#define vvi                  vector<vector<int>>
#define vvl                  vector<vector<long long>>
#define vd                   vector<double>
#define vvd                  vector<vector<double>>
#define vc                   vector<char>
#define vvc                  vector<vector<char>>
#define vpdd                 vector<pair<double,double> >

#define vi                   vector<int>
#define vpii                 vector<pair<int,int>> 
//#define vpii                 vector<pair<short,short> >


#define pii                  pair<int, int>
#define pcc                  pair<char, char>
#define pucc                 pair<uchar, uchar>
#define pll                  pair<long long, long long>
#define pdd                  pair<double, double>
#define mp(XX, YY)           make_pair(XX, YY)
#define fi                   first
#define se                   second

#define ll                   long long
#define ull                  unsigned long long
#define SS                   stringstream

#define ptype unsigned short

// for loops
#define re(II, NN)           for (int II(0), _NN(NN); (II) < (_NN); ++(II))
#define fod(II, XX, YY)      for (int II(XX), _YY(YY); (II) >= (_YY); --(II))
#define fo(II, XX, YY)       for (int II(XX), _YY(YY); (II) <= (_YY); ++(II))
#define foreach(it,c) for(__typeof((c).begin()) it=(c).begin();it!=(c).end();++it)

// Useful hardware instructions
#define bitcount             __builtin_popcount
#define gcd                  __gcd

// Useful all around
#define checkbit(n,b)        ((n >> (b)) & 1)
#define pt2(b)               (1LL<<(b))
#define DREP(a)              sort(a.begin(), a.end());a.erase(unique(a.begin(), a.end()),a.end())
#define INDEX(arr,ind)       (lower_bound(arr.begin(), arr.end(),ind)-arr.begin())
#define PAUSE cerr << "Press any key to continue ..."; char xxxx; scanf("%c", &xxxx);

#define v_fill(xx,val) fill(all(xx), val)
#define m_fill(xx,val) memset(xx, val, sizeof(xx))

#define SUM(vv) accumulate(vv.begin(), vv.end(), 0)
#define oo (10001)

#define ALWAYS_INLINE inline __attribute__((always_inline))
#define ALIGNED __attribute__ ((aligned(16)))

#define likely(x)  __builtin_expect(!!(x),1)
#define unlikely(x) __builtin_expect(!!(x),0)

#define SSE_LOAD(a)    _mm_load_si128((const __m128i*)&a)
#define SSE_STORE(a, b) _mm_store_si128((__m128i*)&a, b)


ull getTicks() {
#ifdef __i386
    ull time;
    __asm__ volatile ("rdtsc" : "=A" (time));
    return time;
#else
    ull timelo, timehi;
    __asm__ volatile ("rdtsc" : "=a" (timelo), "=d" (timehi));
    return (timehi << 32) + timelo;
#endif
}

#define SUBMIT

// changed NON SUBMIT from 3.6e9 * 1.32

const double inv_frequency = 1.0 / 2.8e9;

double convertTicks(ull time) {
#ifndef SUBMIT  
    return time / 3.3e9 * 1.23;
#else
    return time * inv_frequency;
    //return time / 3.6e9 * 1.46;
#endif
}

double getTime() {
  return convertTicks(getTicks()) * 1.0;
}

struct Timer {
  ull ticks;
  const string name;
  bool running;
  int count;
  
  Timer() {;}

  Timer(string _name) : name(_name) {
    ticks = 0;
    count = 0;
    running = false;
  }

  void reset() {
    ticks = 0;
    count = 0;
    running = false; 
  }

  double elapsed() {
    return convertTicks(running ? getTicks() - ticks : ticks);
  }

  void start() {
    if (running) return;
    ticks = getTicks() - ticks;
    running = true;
  }
  
  void stop() {
    if (!running) return;
    ticks = getTicks() - ticks;
    running = false;
    count++;
  }
  
  void check() {
    double delta = elapsed();
    cerr << name << ": " << delta << " count: " << count;
    if (count) cerr << " mean per sec: " << (1 / delta) * count;
    cerr << endl;
  }

//  double elapsed() {;}
//  void startTimer() {;}
//  void stopTimer() {;}
//  void checkTimer() {;}

};

// class ChronoTimer {
// public:
//   double start, end, total;
  
//   double getTime()
//   { 
//     timeval tv;
//     gettimeofday(&tv, 0);
//     return (tv.tv_sec + tv.tv_usec * 0.000001);
//   }

//   void startTimer() {
//     start = getTime();
//   }
  
//   double stopTimer() {
//     double elapsed_seconds = checkTimer();
//     // total += elapsed_seconds;
//     // cerr << "ChronoTimer: " << elapsed_seconds << "\n";
//     return elapsed_seconds;
//   }
  
//   double checkTimer() {
//     timeval tv;
//     gettimeofday(&tv, 0);
//     return tv.tv_sec + tv.tv_usec * 0.000001 - start;
//   }
  
//   ChronoTimer() {total = 0.0; startTimer();}
// };

namespace Color {
  enum Code {
    FG_RED      = 31,
    FG_GREEN    = 32,
    FG_YELLOW   = 33,
    FG_BLUE     = 34,
    FG_DEFAULT  = 39,
    BG_RED      = 41,
    BG_GREEN    = 42,
    BG_BLUE     = 44,
    BG_DEFAULT  = 49
  };
  
  class Modifier {
    Code code;
  public:
    Modifier(Code pCode) : code(pCode) {}
    friend std::ostream&
    operator<<(std::ostream& os, const Modifier& mod) {
      return os << "\033[" << mod.code << "m";
    }
  };
}

const uchar
v_white[3]  = { 255, 255, 255 }, v_black[3] = { 0, 0, 0 },     v_red[3] = { 120, 50, 80 },
v_yellow[3] = { 200, 155, 0 },   v_green[3] = { 30, 200, 70 }, v_purple[3] = { 175, 32, 186 },
v_blue[3]   = { 55, 140, 185 },  v_grey[3] = { 127, 127, 127 };

Color::Modifier green(Color::FG_GREEN);
Color::Modifier red(Color::FG_RED);
Color::Modifier yellow(Color::FG_YELLOW);
Color::Modifier blue(Color::FG_BLUE);
Color::Modifier def(Color::FG_DEFAULT);

///////////////////////////////////////////////////////////

template <class T>
pair<T, T> operator - (const pair<T, T> & a, const pair<T, T> & b) {
    return mp(a.fi - b.fi, a.se - b.se);
}

template <class T>
pair<T, T> operator + (const pair<T, T> & a, const pair<T, T> & b) {
    return mp(a.fi + b.fi, a.se + b.se);
}

template <class T, class U>
pair<T, T> operator / (const pair<T, T> & a, const U d) {
    return mp(a.fi / d, a.se / d);
}

template <class T, class U>
pair<T, T> operator * (const U d, const pair<T, T> & a) {
    return mp(a.fi * d, a.se * d);
}

///////////////////////////////////////////////////////////

// void SSE_CLEAR(const char * v, int size) {
//     auto zero = _mm_set1_epi8 (0);
//     for (int k = 0; k < size; k += 16) {
//         SSE_STORE(v[k], zero);
//     }
// }

// void SSE_CLEAR(const short * v, int size) {
//     auto zero = _mm_set1_epi16 (0);
//     for (int k = 0; k < size; k += 8) {
//         SSE_STORE(v[k], zero);
//     }
// }

// void SSE_CLEAR(const int * v, int size) {
//     auto zero = _mm_set1_epi32 (0);
//     for (int k = 0; k < size; k += 4) {
//         SSE_STORE(v[k], zero);
//     }
// }

// void SSE_COPY(const char * v, const char * to, int size) {
//     for (int i = 0; i < size; i += 16) {
//       __m128i m = SSE_LOAD(v[i]);
//       SSE_STORE(to[i], m);
//     }
// }

// void SSE_COPY(const short * v, const short * to, int size) {
//     for (int i = 0; i < size; i += 8) {
//       __m128i m = SSE_LOAD(v[i]);
//       SSE_STORE(to[i], m);
//     }
// }
////////////////////////////////////////////////////////////

template <typename T>
vector<T> join_vector(const vector<T> & left, const vector<T> & right) {
    if (!size(right)) return left;
    auto res = vector<T>(left);
    res.insert(res.end(), all(right));
    return res;
}

template <typename T>
void concat_vector(vector<T> & left, const vector<T> & right) {
  if (!size(right)) return;
    left.insert(left.end(), all(right));
}

template <typename T>
T sum_vector(vector<T> & v) {
    return accumulate(all(v), 0);
}

template <typename T>
T mean_vector(vector<T> & v) {
    return sum_vector(v) / size(v);
}

vi string_to_vector(const string & s) {
  vi res; for (auto c : s) res.pb(c); return res;
}

template <typename T>
vector<T> operator + (const vector<T>& left, const vector<T>& right) {
  return join_vector(left, right);
}

/////////////////////////////////////////////////////////////

mt19937 random_engine;

double nextDouble() {return 1.0 * (random_engine() % (1<<30) + 1) / ((1<<30)-1);}
int nextInt() {return random_engine();}
int nextInt(int range) {return random_engine() % range;}
int nextInt(int first, int last) {return random_engine() % (last - first + 1) + first;}

/////////////////////////////////////////////////////////////

struct RNG {
  unsigned int x = 123456789;
  unsigned int y = 362436069;
  unsigned int z = 521288629;
  
  unsigned int rand() {
    x ^= x << 16;
    x ^= x >> 5;
    x ^= x << 1;

    unsigned int t = x;
    x = y;
    y = z;
    z = t ^ x ^ y;

    return z;   
  }
    
  inline int nextInt(int x) {
    return rand() % x;
  }
    
  inline int nextInt(int a, int b) {
    return a + (rand() % (b - a + 1));
  }
    
  inline double nextDouble() {
    return (rand() + 0.5) * (1.0 / 4294967296.0);
  }

  void seed(int val) {
    random_engine.seed(val);
    x = nextInt((1<<30));
    y = nextInt((1<<30));
    z = nextInt((1<<30));
  }
};

static RNG rng;

template<typename T>
T ChooseRandom (const vector<T>& vec) {
  assert (size(vec));
  return vec[rng.nextInt(size(vec))];
}

template<typename T>
void FastShuffle(vector<T>& vec) {
    fod (i, size(vec) - 1, 0) {
        swap(vec[i], vec[rng.nextInt(0, i)]);
    }
}
////////////////////////////////////////////////////////////
double dist_l2 (const pii& A, const pii& B) {
  return hypot (1.0*A.fi - B.fi, 1.0 * A.se - B.se);
}

template<typename T>
pair<double, double> computeMeanVariance (const vector<T>& v) {
  pair<double, double> result;
  for (const auto& x : v) {
    result.fi += x;
  } 
  result.fi /= size(v);
  for (const auto& x : v) {
    result.se += sqr(x - result.fi);
  }
  result.se = sqrt(result.se / size(v));
  return result;
}

template<typename T>
double computePercentage (vector<T>& v, int index) {
  return 1.0 * v[index] / sum_vector(v);
}

template<typename T>
vector<double> computeAllPercentages (vector<T>& v) {
  vd result (size(v));
  auto S = sum_vector(v);
  re (i, size(v))
    result[i] = 1.0 * v[i] / S;
  return result;
}

///////////////////////////////////////////////////////////

#ifdef __APPLE__
#define HOME_COMPUTER
#define LOCAL
#endif

//#define LOCAL

#ifdef LOCAL
#define WARN
#define HIGHLIGHT
#define DEBUG
#define INFO
#endif

#ifdef DEBUG
#define debug(args...)            {dbg,args; cerr<<"\n"; cerr.flush();}
#define trace(args...) { vector<string> _v = debug_split(#args, ','); debug_err(_v.begin(), args); }
#define echo(arg) {cerr << #arg << ": "; dbg,arg; cerr << "\n"; cerr.flush();}
#else
#define debug(args...) {}
#define echo(arg) {}
#define trace(args...) {} 
#endif

#ifdef WARN
#define warn(args...)             {dbg,args; cerr<<"\n"; cerr.flush();}
#else
#define warn(args...)
#endif

#ifdef INFO
#define info(args...)             {cerr << blue; dbg,args; cerr<<def<<"\n"; cerr.flush();}  
#else
#define info(args...)
#endif

#ifdef HIGHLIGHT
#define highlight(args...)        {cerr << red; dbg,args; cerr<<def<<"\n"; cerr.flush();}
#else
#define highlight(args...)
#endif

#ifdef LOCAL
#define MAX_TIME 9.6
#define TIME_BUFFER 0.5
#else
// DON'T CHANGE
#define MAX_TIME 9.6
#define TIME_BUFFER 0.5
#endif

#define MAX_SAFE_TIME 4.0
#define EPS 1e-9

#define delta_type double
#define double_type double

//////////////////////////////////////////////
const int INF = (1<<30);

const int MAX_N = 50;
//////////////////////////////////////////////
//////////////////////////////////////////////
Timer solution_timer("solution");
//////////////////////////////////////////////
unordered_map<string, int64> Counter;
//////////////////////////////////////////////
const int RAD = 100;
const int RAD2 = 10000;
const int CIRCLE = 0;
const int RECT = 1;
const double AREA = 100 * 100 * M_PI;

int N, C, R;
double X;
double P;

double SUM;

vi aCircles;
vpii aRects;


struct Pos {
    int y;
    int x;
    bool OK() {return sqr(y) + sqr(x) <= RAD2;}
    Pos() {;}
    Pos(int _y, int _x) {y = _y, x = _x;}
};

struct Shape {
    int id;
    int type;
    int r;
    int h;
    int w;
    int y;
    int x;

    void Place(Pos p) {
        y = p.y, x = p.x;
    }

    bool OK() {
        if (circle()) {
            return sqr(RAD - r) >= sqr(y) + sqr(x);
        } else {
            vector<Pos> corners = {Pos{y, x}, Pos{y + h, x}, Pos{y, x + w}, Pos{y + h, x + w}};
            for (auto p : corners) {
                if (!p.OK())
                    return false;
            }
            return true;
        }
    }

    double Area() const {
        if (circle()) {
            return sqr(r) * M_PI;  
        } else {
            return h * w;
        }
        return 0;
    }

    double Util() const {
        return Area();
    }

    bool circle() const {return type == CIRCLE;}
    bool rect() const {return type == RECT;}

    bool operator < (const Shape& other) const {
        return Util() < other.Util();
    }

    string Serialize() {
        SS ss;
        if (circle()) {
            ss << x << " " << y;
        } else {
            ss << x << " " << y;
        }
        return ss.str();
    }
};

bool IntersectCC(const Shape& s1, const Shape& s2) {
    assert(s1.circle());
    assert(s2.circle());

    return sqr(s1.r + s2.r) > sqr(s1.y-s2.y) + sqr(s1.x-s2.x);
}

bool IntersectRR(const Shape& A, const Shape& B) {
    return A.x < B.x+B.w  && A.x+A.w > B.x &&
             A.y < B.y+B.h && A.y+A.h > B.y;
}

bool IntersectCR(const Shape& A, const Shape& B) {
    double x = abs(A.x - (B.x+B.w/2.0));
    double y = abs(A.y - (B.y+B.h/2.0));
    if (x+EPS > B.w/2.0 + A.r) return false;
    if (y+EPS > B.h/2.0 + A.r) return false;
    if (x+EPS < B.w/2.0) return true;
    if (y+EPS < B.h/2.0) return true;
    double cornerDist = sqr(x - B.w/2.0) + sqr(y - B.h/2.0);
    return (cornerDist+EPS < sqr(A.r));
}

bool Overlap(const Shape& s1, const Shape& s2) {
    if (s1.circle() && s2.circle()) {
        return IntersectCC(s1, s2);
    } else if (s1.rect() && s2.rect()) {
        return IntersectRR(s1, s2);
    } else {
        if (s1.circle()) {
            return IntersectCR(s1, s2);
        } else {
            return IntersectCR(s2, s1);
        }
    }
}

vector<Pos> pos;
vector<Shape> shapes;

// TODO: What to keep in state?

struct State {
    int tot_area;
    double balance;
    double score;

    vector<Shape> S;

    State() {
        tot_area = 0;
        balance = 0;
        score = 0;
        S.clear();
    }

    void Add(int id, Pos p) {
        auto s = shapes[id];
        s.Place(p);
        S.pb(s);
    }

    vs Serialize() {
        vs ret(N, "NA");
        for (auto s : S) {
            //warn("?", s.id, s.y, s.x);
            ret[s.id] = s.Serialize();
        }
        return ret;
    }
};
namespace Solver {
    void Init() {
        pos.clear();
        fo (y, -100, 100) {
            fo (x, -100, 100) {
                if (sqr(y) + sqr(x) <= RAD2) {
                    pos.emplace_back(y, x);
                }
            }
        }
    }

    State Sample() {
        State state;
        state.Add(0, Pos{0, 0});
        return state;
    }

    State Greedy() {
        auto S = shapes;
        sort(all(S));
        reverse(all(S));

        State state;
        for (auto s : S) {
            for (auto p : pos) {
                auto ns = s;
                ns.Place(p);

                if (!ns.OK())
                    continue;

                bool ok = true;

                for (auto ss: state.S) {
                    if (Overlap(ns, ss)) {
                        ok = false;
                        break;
                    }
                }

                if (ok) {
                    state.Add(ns.id, p);

                    goto END_SEARCH;
                }
            }
            END_SEARCH:;
        }
        return state;
    }
}
//////////////////////////////////////////////
class TastyPizza {
public:
    void Log() {
        ofstream fout("logXXX.aux", ofstream::out | ofstream::app);
        fout << N << " " << C << " " << R << " " << X << "\n";
        fout.close();
        exit(0);
    }

    void Info() {
        highlight("N:", N, "C:", C, "R:", R, "X:", X);
    }

    vector<string> findSolution(int _C, int _R, double _X, vector<int> &_aCircles, vector<pair<int, int> > &_aRects) {
        solution_timer.start();
        random_engine.seed(0);
        rng.seed(0);           

        

        C = _C;
        R = _R;
        N = C + R;

        SUM = 0;

        aCircles = _aCircles;
        aRects = _aRects;

        shapes.clear();
        re (i, C) {
            shapes.push_back(Shape{i, CIRCLE, aCircles[i], 0, 0});
        }

        re (i, R) {
            shapes.push_back(Shape{i + C, RECT, 0, aRects[i].se, aRects[i].fi});
        }

        Info();
        Solver::Init();

        warn("Init done!");

        State bst_state;
        vs final_ret;

        //bst_state = Solver::Greedy();
        //final_ret = bst_state.Serialize();

        bst_state = Solver::Greedy();
        final_ret = bst_state.Serialize();
        solution_timer.stop();
        return final_ret;
    } 
};

////////////////////////
#define PERSONAL

template<class T> void getVector(vector<T>& v) {
    for (int i = 0; i < v.size(); ++i)
        cin >> v[i];
}

void RunTester() {
    std::ios::sync_with_stdio(false);
    cin.tie(0);
    
    TastyPizza prog;
    int R, C;
    double X;
    cin >> C >> R >> X;
    vector< pair<int, int> > aRect(R);
    vector<int> aCircles(C);
    for (int i=0;i<C;i++)
    {
    cin >> aCircles[i];
    }
    for (int i=0;i<R;i++)
    {
    cin >> aRect[i].first >> aRect[i].second;
    }
    vector<string> ret = prog.findSolution(C, R, X, aCircles, aRect);
    cout << ret.size() << endl;
    for (int i = 0; i < (int)ret.size(); ++i)
      cout << ret[i] << endl;
    cout.flush();
}

int main(int argc, char ** argv) {
    if (argc == 1) {
        RunTester();
    } else {
        assert(false);
    }
    return 0;
}