const double TL2 = 9.7;
const double TL1 = 4*TL2/6.0;
#include <bits/stdc++.h>
using namespace std;
#define F0(i,n) for (int i=0; i<n; i++)
#define FR(i,n) for (int i=n-1; i>=0; i--)
#define F1(i,n) for (int i=1; i<=n; i++)
#define CL(a,x) memset(x, a, sizeof(x));
#define SZ(x) ((int)x.size())
const int inf = 1000009;
const double pi = acos(-1.0);
typedef pair<int, int> pii;
typedef long long ll;
const double EPS = 1e-9;
#define PR(x) cerr << #x << "=" << x << endl

inline ll GetTSC() {
    ll lo, hi;
    asm volatile ("rdtsc": "=a"(lo), "=d"(hi));
    return lo + (hi << 32);
}
inline double GetSeconds() {
    return GetTSC() / 2.79e9;
}

const int MAX_RAND = 1 << 30;
struct Rand {
    ll x, y, z, w, o;
    Rand(ll seed) { reseed(seed); o = 0; }
    inline void reseed(ll seed) { x = 0x498b3bc5 ^ seed; y = 0; z = 0; w = 0;  F0(i, 10) mix(); }
    inline void mix() { ll t = x ^ (x << 11); x = y; y = z; z = w; w = w ^ (w >> 19) ^ t ^ (t >> 8); }
    inline ll rand() { mix(); return x & (MAX_RAND - 1); }
    inline int nextInt(int n) { return rand() % n; }
    inline int nextInt(int L, int R) { return rand()%(R - L + 1) + L; }
    inline int nextBool() { if (o < 4) o = rand(); o >>= 2; return o & 1; }
    double nextDouble() { return rand() * 1.0 / MAX_RAND; }
};
Rand my(2021);
double saveTime;
double t_o[20];
ll c_o[20];
void Init() {
    saveTime = GetSeconds();
    F0(i, 20) t_o[i] = 0.0;
    F0(i, 20) c_o[i] = 0;
}
double Elapsed() { return GetSeconds() - saveTime; }
void Report() {
    cerr << "-------------------------------------" << endl;
    cerr << "Elapsed time: " << Elapsed() << " sec" << endl;
    double total = 0.0; F0(i, 20) { if (t_o[i] > 0) cerr << "t_o[" << i << "] = " << t_o[i] << endl; total += t_o[i]; } cerr << endl; //if (total > 0) cerr << "Total spent: " << total << endl;
    F0(i, 20) if (c_o[i] > 0) cerr << "c_o[" << i << "] = " << c_o[i] << endl;
    cerr << "-------------------------------------" << endl;
}
struct AutoTimer {
    int x;
    double t;
    AutoTimer(int x) : x(x) {
        t = Elapsed();
    }
    ~AutoTimer() {
        t_o[x] += Elapsed() - t;
    }
};
#define AT(i) AutoTimer a##i(i)
//#define AT(i)

// CONSTANTS
const int N = 1024;
const int CR = 100;
const int MAXPOS = (2*CR+1) * (2*CR+1);
const int B = 22;
const int MINR = 5;
const int MAXR = 15;
const int MINW = 5;
const int MAXW = 25;
const int MAXG = 2*CR/B+10;
const int DX[]={-1,0,1,0};
const int DY[]={0,1,0,-1};
map<int, vector<pii>> pre;
double coeff;
int n, C, R;
double X;
set<int> rpool[64];
double bestScore, score, cscore, rscore;
vector<pii> bestSol, sol;
int r[N], w[N], h[N], ax[N], ay[N];
int cZ, checkz[N];
int tn[MAXG][MAXG], t[MAXG][MAXG][128];
int threatn, threat[N];
double losec[N], loser[N], areaof[64];
pii gvalues[64];
int curr_rem[N], curr_remn;
pii c_pos[MAXR + 1][MAXPOS], c_touch_pos[MAXR + 1][MAXPOS];
int c_posn[MAXR+1], c_touch_posn[MAXR+1];
pii r_pos[MAXW+1][MAXW+1][MAXPOS], r_touch_pos[MAXW+1][MAXW+1][MAXPOS];
int r_posn[MAXW+1][MAXW+1], r_touch_posn[MAXW+1][MAXW+1];
int circle_dx[16][16][4096];
int circle_dy[16][16][4096];
int circle_dn[16][16];
bool dprr[26][26][128];
bool dp[16][26][26][128][128];
#define int_rect_rect(i, j) (dprr[w[i]][w[j]][ax[i]-ax[j]+64] && dprr[h[i]][h[j]][ay[i]-ay[j]+64])
#define int_circle_rect(i, j) (dp[r[i]][w[j]][h[j]][ax[i]-ax[j]+64][ay[i]-ay[j]+64])
int wh[N], rnd_array[N], rnd_size;
int wh_c[N], rnd_array_c[N], rnd_size_c;

double area[N];
const int LOGN = 1 << 16;
double logs[LOGN];

void UpdateBest() {
    if (score > bestScore) {
        bestScore = score;
        F0(i, n) bestSol[i] = pii(ax[i], ay[i]);
    }
}

double FV(double c, double r) {
    return c + r - abs(X*c - (1-X)*r) * coeff;
}

double F(double c, double r) {
    return c + r - abs(X*c - (1-X)*r);
}

inline int sq(int x) { return x * x; }
int X1, Y1, X2, Y2;

void PrepG(int x, int y, int r) {
    X1 = (x - r + CR) / B;
    Y1 = (y - r + CR) / B;
    X2 = (x + r + CR) / B;
    Y2 = (y + r + CR) / B;
}

void PrepG(int i) {
    if (i < C) {
        X1 = (ax[i] - r[i] + CR) / B;
        Y1 = (ay[i] - r[i] + CR) / B;
        X2 = (ax[i] + r[i] + CR) / B;
        Y2 = (ay[i] + r[i] + CR) / B;
    } else {
        X1 = (ax[i] + CR) / B;
        Y1 = (ay[i] + CR) / B;
        X2 = (ax[i] + w[i] + CR) / B;
        Y2 = (ay[i] + h[i] + CR) / B;
    }
}

void AddTValue(int x, int y, int i) {
    t[x][y][tn[x][y]++] = i;
}

void RemTValue(int x, int y, int i) {
    F0(k, tn[x][y]) if (t[x][y][k] == i) {
        for (int l = k; l + 1 < tn[x][y]; l++) t[x][y][l] = t[x][y][l + 1];
        tn[x][y]--;
        return;
    }
}

void AddT(int i) {
    if (i < C) {
        rpool[r[i]].erase(i);
        wh_c[i] = rnd_size_c;
        rnd_array_c[rnd_size_c++] = i;
    }
    else {
        wh[i] = rnd_size;
        rnd_array[rnd_size++] = i;
    }
    PrepG(i);
    for (int X = X1; X <= X2; X++) for (int Y = Y1; Y <= Y2; Y++) AddTValue(X, Y, i);
}

void RemT(int i) {
    if (i < C) {
        rpool[r[i]].insert(i);
        rnd_array_c[wh_c[i]] = rnd_array_c[rnd_size_c-1];
        wh_c[rnd_array_c[wh_c[i]]] = wh_c[i];
        rnd_size_c--;
    }
    else {
        rnd_array[wh[i]] = rnd_array[rnd_size-1];
        wh[rnd_array[wh[i]]] = wh[i];
        rnd_size--;
    }

    PrepG(i);
    for (int X = X1; X <= X2; X++) for (int Y = Y1; Y <= Y2; Y++) RemTValue(X, Y, i);
    ax[i] = inf;
}

inline bool int_circle_circle(int i, int j) {
    return sq(ax[i] - ax[j]) + sq(ay[i] - ay[j]) < sq(r[i] + r[j]);
}

inline bool int_circle_any(int i, int j) {
    return (j < C) ? int_circle_circle(i, j) : int_circle_rect(i, j);
}

inline bool int_rect_any(int i, int j) {
    return (j < C) ? int_circle_rect(j, i) : int_rect_rect(i, j);
}

bool inside(int x, int y) { return sq(x) + sq(y) <= sq(CR); }
bool inside(int x, int y, int r) { return sq(x) + sq(y) <= sq(CR - r); }
bool inside(int x1, int y1, int x2, int y2) {
    return inside(x1, y1) && inside(x1, y2) && inside(x2, y1) && inside(x2, y2);
}

void Improve(double endTime) {
    int numStages = 20;
    int itc = 2000000000;
    //itc = 100000;
    double T1 = 0.0, T2 = 20.0 + 10*X, T = 0.0;
    int tot = 1, acc = 0, lastStage = -1;
    double startTime = Elapsed();
    int gl = 0, gl2 = 0;
    int M1 = 10, M2 = 3;
    if (X < 0.2) M2 = 3;
    else if (X < 0.8) M2 = 2;
    else M2 = 1;
    F0(iter, itc) {
        if ((iter & 255) == 0) {
            //double r = 1.0 * (itc - iter) / itc;
            double r = (endTime - Elapsed()) / (endTime - startTime);
            coeff = 0.0+1.0*(1-r);
            if (0) {
                int newStage = (1 - r) * numStages;
                if (newStage != lastStage) {
                    lastStage = newStage;
                    cerr << "St: " << newStage << " " << 100.0*acc/tot << " " << bestScore << " " << score << endl;
                }
            }
            if (r <= 0) {
                PR(iter);
                break;
            }
            T = T1 + (T2 - T1) * (1 - sqrt(1-r));
        }
        int i = 0;
        if (iter%M1<M2) {
            i = gl;
            if (++gl == C) gl = 0;
        } else {
            i = gl2+C;
            if (++gl2 == R) gl2 = 0;
        }

        int u = my.rand();
        if (ax[i] != inf) {
            if (i < C && r[i] < MAXR && !rpool[r[i] + 1].empty() && inside(ax[i], ay[i], r[i]+1)) {
                cZ++;
                checkz[i] = cZ;
                r[i]++;
                PrepG(ax[i], ay[i], r[i]);
                bool can = true;
                for (int X = X1; X <= X2; X++) for (int Y = Y1; Y <= Y2; Y++) {
                    F0(k, tn[X][Y]) {
                        int j = t[X][Y][k];
                        if (checkz[j] == cZ) continue;
                        checkz[j] = cZ;
                        if (int_circle_any(i, j)) {
                            can = false;
                            break;
                        }
                    }
                }
                r[i]--;
                if (can) {
                    cscore += areaof[r[i]+1] - areaof[r[i]];
                    score = F(cscore, rscore);
                    int j = *rpool[r[i]+1].begin();
                    ax[j] = ax[i];
                    ay[j] = ay[i];
                    RemT(i);
                    AddT(j);
                    continue;
                }
            }
            int k = u & 3;
            int sx = ax[i], sy = ay[i];
            while (1) {
                ax[i] += DX[k];
                ay[i] += DY[k];
                bool still_in = false;
                if (i < C) {
                    if (inside(ax[i], ay[i], r[i])) {
                        still_in = true;
                        cZ++;
                        checkz[i] = cZ;
                        PrepG(i);
                        for (int X = X1; X <= X2; X++) for (int Y = Y1; Y <= Y2; Y++) if (still_in) {
                            F0(k, tn[X][Y]) {
                                int j = t[X][Y][k];
                                if (checkz[j] == cZ) continue;
                                checkz[j] = cZ;
                                if (int_circle_any(i, j)) {
                                    still_in = false;
                                    break;
                                }
                            }
                        }
                    }
                } else {
                    if (inside(ax[i], ay[i], ax[i]+w[i], ay[i]+h[i])) {
                        still_in = true;
                        cZ++;
                        checkz[i] = cZ;
                        PrepG(i);
                        for (int X = X1; X <= X2; X++) for (int Y = Y1; Y <= Y2; Y++) if (still_in) {
                            F0(k, tn[X][Y]) {
                                int j = t[X][Y][k];
                                if (checkz[j] == cZ) continue;
                                checkz[j] = cZ;
                                if (int_rect_any(i, j)) {
                                    still_in = false;
                                    break;
                                }
                            }
                        }
                    }
                }
                if (!still_in) {
                    ax[i] -= DX[k];
                    ay[i] -= DY[k];
                    break;
                }
            }

            if (sx != ax[i] || sy != ay[i]) {
                int ex = ax[i], ey = ay[i];
                ax[i] = sx; ay[i] = sy; RemT(i);
                ax[i] = ex; ay[i] = ey; AddT(i);
            }
            continue;
        }
        int mode = u & 15;
        u >>= 4;

        if (i < C) {
            if (mode >= 15) {
                threatn = 0;
                int k = my.nextInt(c_posn[MINR]);
                ax[n] = c_pos[MINR][k].first;
                ay[n] = c_pos[MINR][k].second;
                int rmax = 5;
                while (rmax + 1 <= MAXR && inside(ax[n], ay[n], rmax + 1)) rmax++;
                r[n] = rmax;
                for (int k = MINR; k <= rmax; k++) losec[k] = loser[k] = 0.0;
                PrepG(ax[n], ay[n], rmax);
                cZ++;
                for (int X = X1; X <= X2; X++) for (int Y = Y1; Y <= Y2; Y++) {
                    F0(k, tn[X][Y]) {
                        int j = t[X][Y][k];
                        if (checkz[j] == cZ) continue;
                        checkz[j] = cZ;
                        if (int_circle_any(n, j)) {
                            threat[threatn++] = j;
                        }
                    }
                }
                F0(i, threatn) {
                    int P = MINR, Q = rmax;
                    while (P < Q) {
                        r[n] = (P + Q) / 2;
                        if (int_circle_any(n, threat[i])) {
                            Q = r[n];
                        } else P = r[n] + 1;
                    }
                    if (threat[i] < C) losec[P] += area[threat[i]]; else loser[P] += area[threat[i]];
                }
                double maxscore = score - T * logs[my.nextInt(LOGN)] - EPS;
                double nc = cscore;
                double nr = rscore;
                int winr = -1;
                for (int k = MINR; k <= rmax; k++) {
                    nc -= losec[k];
                    nr -= loser[k];
                    double v = F(nc + areaof[k], nr);
                    if (v > maxscore && !rpool[k].empty()) {
                        maxscore = v;
                        winr = k;
                    }
                }
                if (winr != -1) {
                    int i = *rpool[winr].begin();
                    ax[i] = ax[n];
                    ay[i] = ay[n];
                    F0(j, threatn) {
                        if (int_circle_any(i, threat[j])) {
                            if (threat[j] < C) cscore -= area[threat[j]]; else rscore -= area[threat[j]];
                            RemT(threat[j]);
                        }
                    }
                    cscore += area[i];
                    score = F(cscore, rscore);
                    AddT(i);
                    UpdateBest();
                }
                continue;
            }
        }

        if (i < C) {
            if ((mode&1) && rnd_size_c) {
                int j = rnd_array_c[u % rnd_size_c];
                int k = my.nextInt(circle_dn[r[i]][r[j]]);
                ax[i] = ax[j] + circle_dx[r[i]][r[j]][k];
                ay[i] = ay[j] + circle_dy[r[i]][r[j]][k];
                if (!inside(ax[i], ay[i], r[i])) ax[i] = inf;
            }
            if (ax[i] == inf) {
                if (mode >= 12) {
                    int k = u % c_posn[r[i]];
                    ax[i] = c_pos[r[i]][k].first;
                    ay[i] = c_pos[r[i]][k].second;
                } else {
                    int k = u % c_touch_posn[r[i]];
                    ax[i] = c_touch_pos[r[i]][k].first;
                    ay[i] = c_touch_pos[r[i]][k].second;
                }
            }
        } else {
            if (mode>=8 && rnd_size) {
                int j = (u&4) ? rnd_array[rnd_size-1] : rnd_array[u % rnd_size];
                if (u&1) ax[i] = ax[j] - w[i]; else ax[i] = ax[j] + w[j];
                if (u&2) ay[i] = ay[j] - h[i]; else ay[i] = ay[j] + h[j];
                if (!inside(ax[i], ay[i], ax[i] + w[i], ay[i] + h[i])) ax[i] = inf;
            }
            if (ax[i] == inf) {
                if (mode >= 4) {
                    int k = u % r_posn[w[i]][h[i]];
                    ax[i] = r_pos[w[i]][h[i]][k].first;
                    ay[i] = r_pos[w[i]][h[i]][k].second;
                } else {
                    int k = u % r_touch_posn[w[i]][h[i]];
                    ax[i] = r_touch_pos[w[i]][h[i]][k].first;
                    ay[i] = r_touch_pos[w[i]][h[i]][k].second;
                }
            }
        }
        double nc = cscore, nr = rscore;
        curr_remn = 0;
        cZ++;
        PrepG(i);
        if (i < C) {
            nc += area[i];
            for (int X = X1; X <= X2; X++) for (int Y = Y1; Y <= Y2; Y++) {
                F0(k, tn[X][Y]) {
                    int j = t[X][Y][k];
                    if (checkz[j] == cZ) continue;
                    checkz[j] = cZ;
                    if (int_circle_any(i, j)) {
                        curr_rem[curr_remn++] = j;
                        if (j < C) nc -= area[j]; else nr -= area[j];
                    }
                }
            }
        } else {
            nr += area[i];
            for (int X = X1; X <= X2; X++) for (int Y = Y1; Y <= Y2; Y++) {
                F0(k, tn[X][Y]) {
                    int j = t[X][Y][k];
                    if (checkz[j] == cZ) continue;
                    checkz[j] = cZ;
                    if (int_rect_any(i, j)) {
                        curr_rem[curr_remn++] = j;
                        if (j < C) nc -= area[j]; else nr -= area[j];
                    }
                }
            }
        }
        double nscore = F(nc, nr);

        double v1 = FV(cscore, rscore);
        double v2 = FV(nc, nr);
        double delta = v2 - v1;

        tot++;
        if (delta >= 0 || delta >= -T * logs[my.nextInt(LOGN)]) {
            acc++;
            score = nscore;
            cscore = nc;
            rscore = nr;

            F0(k, curr_remn) RemT(curr_rem[k]);
            AddT(i);
            UpdateBest();
        } else {
            ax[i] = inf;
        }
    }
    UpdateBest();
}

void Prep() {
    F0(i, LOGN) logs[i] = -log((i+0.5)/LOGN);
    F0(i, C) rpool[r[i]].insert(i);
    for (int r = MINR; r <= MAXR; r++) areaof[r] = pi * r * r;
    for (int x = -CR; x <= CR; x++) {
        for (int y = -CR; y <= CR; y++) if (inside(x, y)) {
            for (int r = MINR; r <= MAXR; r++) if (inside(x, y, r)) {
                c_pos[r][c_posn[r]++] = pii(x, y);
                F0(k, 4) {
                    int x2 = x+DX[k], y2 = y+DY[k];
                    if (!inside(x2, y2) || !inside(x2, y2, r)) {
                        c_touch_pos[r][c_touch_posn[r]++] = pii(x, y);
                        break;
                    }
                }
            }
            for (int w = MINW; w <= MAXW; w++) if (inside(x + w, y)) {
                int h = MINW;
                if (!inside(x, y + h) || !inside(x + w, y + h)) continue;
                while (inside(x, y + h) && inside(x + w, y + h) && h <= MAXW) {
                    r_pos[w][h][r_posn[w][h]++] = pii(x, y);
                    F0(k, 4) if (!inside(x + DX[k], y + DY[k], x + DX[k] + w, y + DY[k] + h)) {
                        r_touch_pos[w][h][r_touch_posn[w][h]++] = pii(x, y);
                        break;
                    }
                    h++;
                }
            }
        }
    }
    for (int r1 = MINR; r1 <= MAXR; r1++) for (int r2 = MINR; r2 <= MAXR; r2++) {
        for (int dx = -(r1+r2); dx <= (r1+r2); dx++) for (int dy = -(r1+r2); dy <=(r1+r2); dy++) {
            int dist = sq(dx)+sq(dy);
            if (dist <sq(r1+r2)) continue;
            bool good = 1;
            F0(k, 4) {
                int ndx = dx+DX[k];
                int ndy = dy+DY[k];
                if (sq(ndx)+sq(ndy) >= dist) continue;
                if (sq(ndx)+sq(ndy) >= sq(r1+r2)) good = 0;
            }
            if (good) {
                circle_dx[r1][r2][circle_dn[r1][r2]] = dx;
                circle_dy[r1][r2][circle_dn[r1][r2]] = dy;
                circle_dn[r1][r2]++;
            }
        }
    }
    F0(w1, 26) F0(w2, 26) F0(x, 128) dprr[w1][w2][x] = (x-64<w2) && (x-64>-w1);
    for (int r = MINR; r <= MAXR; r++) for (int w = MINW; w <= MAXW; w++) for (int h = MINW; h <= MAXW; h++) F0(x, 128) F0(y, 128) {
        int dx = abs(2*(x-64) - w);
        int dy = abs(2*(y-64) - h);
        if (dx >= w + 2*r || dy >= h + 2*r);
        else if (dx < w || dy < h) dp[r][w][h][x][y] = true;
        else dp[r][w][h][x][y] = sq(dx-w) + sq(dy-h) < sq(2*r);
    }
    if (C > 300) {
        pre[10].push_back({76,48});
        pre[15].push_back({82,-1});
        pre[6].push_back({87,35});
        pre[8].push_back({-91,8});
        pre[14].push_back({-69,51});
        pre[12].push_back({9,75});
        pre[6].push_back({8,93});
        pre[6].push_back({86,-37});
        pre[15].push_back({6,-28});
        pre[7].push_back({-10,72});
        pre[15].push_back({-24,24});
        pre[13].push_back({-82,27});
        pre[15].push_back({-69,-2});
        pre[15].push_back({36,-28});
        pre[15].push_back({6,-80});
        pre[7].push_back({58,72});
        pre[8].push_back({89,-23});
        pre[15].push_back({-54,24});
        pre[15].push_back({-39,-2});
        pre[15].push_back({36,24});
        pre[15].push_back({51,-2});
        pre[15].push_back({51,-54});
        pre[15].push_back({21,50});
        pre[15].push_back({36,77});
        pre[15].push_back({-24,-80});
        pre[13].push_back({35,-79});
        pre[9].push_back({76,-50});
        pre[10].push_back({-55,71});
        pre[15].push_back({21,-54});
        pre[8].push_back({-91,-9});
        pre[15].push_back({-9,-2});
        pre[15].push_back({-39,-54});
        pre[6].push_back({20,91});
        pre[10].push_back({-8,89});
        pre[6].push_back({69,63});
        pre[13].push_back({-67,-55});
        pre[15].push_back({-9,-54});
        pre[8].push_back({89,21});
        pre[15].push_back({-39,50});
        pre[15].push_back({6,24});
        pre[15].push_back({66,25});
        pre[9].push_back({-54,-73});
        pre[15].push_back({-9,50});
        pre[15].push_back({66,-28});
        pre[15].push_back({-24,-28});
        pre[15].push_back({51,51});
        pre[15].push_back({-31,79});
        pre[13].push_back({-82,-28});
        pre[15].push_back({21,-2});
        pre[15].push_back({-54,-28});
    } else if (C > 200) {
        pre[12].push_back({-84,-25});
        pre[10].push_back({73,0});
        pre[6].push_back({-12,-93});
        pre[15].push_back({3,78});
        pre[10].push_back({74,50});
        pre[12].push_back({-74,-47});
        pre[14].push_back({-41,52});
        pre[6].push_back({93,0});
        pre[14].push_back({-56,26});
        pre[15].push_back({3,-26});
        pre[15].push_back({-27,-78});
        pre[15].push_back({48,0});
        pre[6].push_back({-93,3});
        pre[6].push_back({-93,-9});
        pre[8].push_back({-65,-65});
        pre[9].push_back({-56,70});
        pre[15].push_back({18,-52});
        pre[7].push_back({55,74});
        pre[15].push_back({-27,78});
        pre[15].push_back({-12,-52});
        pre[15].push_back({-72,0});
        pre[14].push_back({-69,51});
        pre[15].push_back({18,52});
        pre[15].push_back({18,0});
        pre[15].push_back({-42,0});
        pre[15].push_back({-27,-26});
        pre[15].push_back({-42,-52});
        pre[9].push_back({-51,-75});
        pre[15].push_back({-27,26});
        pre[15].push_back({63,26});
        pre[13].push_back({-83,26});
        pre[15].push_back({48,52});
        pre[15].push_back({63,-26});
        pre[15].push_back({-57,-26});
        pre[11].push_back({87,-16});
        pre[15].push_back({-12,0});
        pre[8].push_back({85,35});
        pre[8].push_back({85,-35});
        pre[15].push_back({33,26});
        pre[10].push_back({74,-50});
        pre[15].push_back({33,78});
        pre[7].push_back({66,65});
        pre[11].push_back({87,16});
        pre[6].push_back({-12,93});
        pre[15].push_back({-12,52});
        pre[7].push_back({66,-65});
        pre[15].push_back({3,26});
        pre[15].push_back({48,-52});
        pre[15].push_back({33,-78});
        pre[7].push_back({55,-74});
        pre[15].push_back({33,-26});
        pre[15].push_back({3,-78});
    } else {
        pre[10].push_back({-56,-70});
        pre[9].push_back({84,33});
        pre[15].push_back({0,79});
        pre[9].push_back({84,-33});
        pre[15].push_back({68,-51});
        pre[15].push_back({19,1});
        pre[15].push_back({30,79});
        pre[9].push_back({-8,-75});
        pre[14].push_back({-55,25});
        pre[15].push_back({-44,52});
        pre[15].push_back({34,27});
        pre[15].push_back({-14,52});
        pre[14].push_back({-41,-50});
        pre[15].push_back({38,-55});
        pre[13].push_back({-73,46});
        pre[12].push_back({87,-12});
        pre[14].push_back({63,-22});
        pre[14].push_back({-27,26});
        pre[14].push_back({-55,-23});
        pre[7].push_back({-52,77});
        pre[12].push_back({87,12});
        pre[8].push_back({-64,65});
        pre[14].push_back({15,54});
        pre[13].push_back({47,0});
        pre[11].push_back({36,-81});
        pre[9].push_back({2,-90});
        pre[14].push_back({-83,-22});
        pre[15].push_back({-32,-78});
        pre[15].push_back({34,-25});
        pre[10].push_back({54,72});
        pre[9].push_back({-90,0});
        pre[15].push_back({-30,79});
        pre[12].push_back({41,54});
        pre[14].push_back({-40,1});
        pre[15].push_back({-26,-25});
        pre[8].push_back({70,-1});
        pre[12].push_back({15,-70});
        pre[13].push_back({-84,22});
        pre[15].push_back({-11,-51});
        pre[15].push_back({4,27});
        pre[15].push_back({-11,1});
        pre[9].push_back({55,-72});
        pre[8].push_back({19,-90});
        pre[15].push_back({4,-25});
        pre[15].push_back({68,51});
        pre[15].push_back({-70,-48});
        pre[7].push_back({-14,-91});
        pre[13].push_back({-68,1});
        pre[14].push_back({63,22});
        pre[10].push_back({14,-48});

    }

    for (int r = MINR; r <= MAXR; r++) {
        vector<pair<int, pii>> v;
        for (pii p : pre[r]) {
            v.push_back(make_pair(-sq(p.first)-sq(p.second), p));
            sort(v.begin(), v.end());
            pre[r].clear();
            for (auto q : v) pre[r].push_back(q.second);
        }
        //sort(pre[r].begin(), pre[r].end());
    }

}

int candx[N*N], candy[N*N], candn, cand_index[N], indn;
const int MAXI = 1<<14;
pii history[1<<20];
int h_index[1<<20], hn;


void MicroSA(double TL2) {
    while (Elapsed() < TL2) {
        double T1 = 0.0, T2 = 25+X*10, T = 0.0;
        int itc = MAXI;
        int SIDE = 22;
        int sx = my.nextInt(2*CR-SIDE)-CR;
        int sy = my.nextInt(2*CR-SIDE)-CR;

        candn = 0;
        F0(dx, SIDE) F0(dy, SIDE) if (inside(sx + dx, sy + dy)) {
            candx[candn] = sx + dx;
            candy[candn++] = sy + dy;
        }
        int sd = SIDE;
        while (candn < SIDE * SIDE && (sx + sd <= CR || sy + sd <= CR)) {
            F0(dx, SIDE) if (inside(sx + dx, sy + sd)) {
                candx[candn] = sx + dx;
                candy[candn++] = sy + sd;
            }
            F0(dy, SIDE-1) if (inside(sx + sd, sy + dy)) {
                candx[candn] = sx + sd;
                candy[candn++] = sy + dy;
            }
            sd++;
        }
        //cerr << candn << " " << SIDE*SIDE << " " << sx << " " << sy << " " << indn << endl;
        if (candn < SIDE * SIDE / 2) continue;
        indn = 0;
        F0(i, n) if (ax[i] == inf) {
            if (i < C && my.nextInt(16) == 0) cand_index[indn++] = i;
            if (i >= C && my.nextInt(4) == 0) cand_index[indn++] = i;
        } else if (ax[i] >= sx && ay[i] >= sy && ax[i] < sx+sd && ay[i] < sy+sd) cand_index[indn++] = i;
        if (indn == 0) continue;

        hn = 0;
        double current_bscore = score;
        double local_bscore = score;
        int local_bh = 0;

        int tot = 1, acc = 0;
        int gl = my.nextInt(indn);
        F0(iter, itc) {
            if ((iter & 63) == 0) {
                double r = 1.0 * (itc - iter) / itc;
                coeff = 0.0+1.0*(1-r);
                if (r <= 0) {
                    break;
                }
                T = T1 + (T2 - T1) * r;
            }
            int i = cand_index[gl];
            if (++gl == indn) gl = 0;

            int u = my.rand();
            if (ax[i] != inf) {
                int k = u & 3;
                int sx = ax[i], sy = ay[i];
                while (1) {
                    ax[i] += DX[k];
                    ay[i] += DY[k];
                    bool still_in = false;
                    if (i < C) {
                        if (inside(ax[i], ay[i], r[i])) {
                            still_in = true;
                            cZ++;
                            checkz[i] = cZ;
                            PrepG(i);
                            for (int X = X1; X <= X2; X++) for (int Y = Y1; Y <= Y2; Y++) if (still_in) {
                                F0(k, tn[X][Y]) {
                                    int j = t[X][Y][k];
                                    if (checkz[j] == cZ) continue;
                                    checkz[j] = cZ;
                                    if (int_circle_any(i, j)) {
                                        still_in = false;
                                        break;
                                    }
                                }
                            }
                        }
                    } else {
                        if (inside(ax[i], ay[i], ax[i]+w[i], ay[i]+h[i])) {
                            still_in = true;
                            cZ++;
                            checkz[i] = cZ;
                            PrepG(i);
                            for (int X = X1; X <= X2; X++) for (int Y = Y1; Y <= Y2; Y++) if (still_in) {
                                F0(k, tn[X][Y]) {
                                    int j = t[X][Y][k];
                                    if (checkz[j] == cZ) continue;
                                    checkz[j] = cZ;
                                    if (int_rect_any(i, j)) {
                                        still_in = false;
                                        break;
                                    }
                                }
                            }
                        }
                    }
                    if (!still_in) {
                        ax[i] -= DX[k];
                        ay[i] -= DY[k];
                        break;
                    }
                }

                if (sx != ax[i] || sy != ay[i]) {
                    int ex = ax[i], ey = ay[i];
                    ax[i] = sx; ay[i] = sy; RemT(i); h_index[hn] = i; history[hn++] = pii(sx, sy);
                    ax[i] = ex; ay[i] = ey; AddT(i); h_index[hn] = i; history[hn++] = pii(inf, inf);
                }
                continue;
            }
            int k = u % candn;
            ax[i] = candx[k];
            ay[i] = candy[k];
            if (i < C && !inside(ax[i], ay[i], r[i])) {
                ax[i] = inf;
                continue;
            }
            if (i >= C && !inside(ax[i], ay[i], ax[i] + w[i], ay[i] + h[i])) {
                ax[i] = inf;
                continue;
            }
            double nc = cscore, nr = rscore;
            curr_remn = 0;
            cZ++;
            PrepG(i);
            if (i < C) {
                //AT(3);
                nc += area[i];
                for (int X = X1; X <= X2; X++) for (int Y = Y1; Y <= Y2; Y++) {
                    F0(k, tn[X][Y]) {
                        int j = t[X][Y][k];
                        if (checkz[j] == cZ) continue;
                        checkz[j] = cZ;
                        if (int_circle_any(i, j)) {
                            curr_rem[curr_remn++] = j;
                            if (j < C) nc -= area[j]; else nr -= area[j];
                        }
                    }
                }
            } else {
                //AT(4);
                nr += area[i];
                for (int X = X1; X <= X2; X++) for (int Y = Y1; Y <= Y2; Y++) {
                    F0(k, tn[X][Y]) {
                        int j = t[X][Y][k];
                        if (checkz[j] == cZ) continue;
                        checkz[j] = cZ;
                        if (int_rect_any(i, j)) {
                            curr_rem[curr_remn++] = j;
                            if (j < C) nc -= area[j]; else nr -= area[j];
                        }
                    }
                }
            }
            double nscore = F(nc, nr);

            double v1 = FV(cscore, rscore);
            double v2 = FV(nc, nr);
            double delta = v2 - v1;

            tot++;
            if (delta >= 0 || delta >= -T * logs[my.nextInt(LOGN)]) {
                acc++;
                score = nscore;
                cscore = nc;
                rscore = nr;

                F0(k, curr_remn) {
                    h_index[hn] = curr_rem[k]; history[hn++] = pii(ax[curr_rem[k]], ay[curr_rem[k]]);
                    RemT(curr_rem[k]);
                }
                AddT(i);
                h_index[hn] = i; history[hn++] = pii(inf, inf);
                if (score >= local_bscore) {
                    local_bscore = score;
                    local_bh = hn;
                }
            } else {
                ax[i] = inf;
            }
        }
        for (int k = hn - 1; k >= local_bh; k--) {
            int i = h_index[k];
            pii p = history[k];
            if (p.first == inf) {
                if (i < C) cscore -= area[i]; else rscore -= area[i];
                RemT(i);
            } else {
                if (i < C) cscore += area[i]; else rscore += area[i];
                ax[i] = p.first;
                ay[i] = p.second;
                AddT(i);
            }
        }
        score = F(cscore, rscore);
        if (score > bestScore) {
            //cerr << bestScore << " " << current_bscore << " " << local_bscore << " " << local_bh << "/" << hn << endl;
            UpdateBest();
        }
    }
}

struct TastyPizza {
vector<string> findSolution(int _C, int _R, double _X, vector<int> &aCircles, vector<pair<int, int> > &aRect) {
    Init();

    C = _C; R = _R; X = _X; n = C + R;
    PR(C); PR(R); PR(X);
    F0(i, C) {
        r[i] = aCircles[i];
        area[i] = pi * r[i] * r[i];
    }

    F0(i, R) {
        w[i + C] = aRect[i].first;
        h[i + C] = aRect[i].second;
        area[i + C] = w[i + C] * h[i + C];
    }

    bestSol.assign(C+R, pii(inf, inf));
    bestScore = 0.0;
    Prep();

    cscore = 0.0;
    rscore = 0.0;
    score = F(cscore, rscore);
    F0(i, n) ax[i] = ay[i] = inf;

    if (X<0.4)
    for (int r = MINR; r <= MAXR; r++) {
        for (pii p : pre[r]) {
            if (!rpool[r].empty()) {
                int i = *rpool[r].begin();
                ax[i] = p.first;
                ay[i] = p.second;
                AddT(i);
                cscore += area[i];
            } else break;
        }
    }
    score = F(cscore, rscore);
    UpdateBest();


    Improve(TL1);
    MicroSA(TL2);

    /*
    vector<int> f(32, 0), g(32, 0);
    F0(i, C) {
        f[r[i]]++;
        if (bestSol[i].first != inf) {
            g[r[i]]++;
            if (r[i] >= 6) cerr << "pre[" << r[i] << "].push_back({" << bestSol[i].first << "," << bestSol[i].second << "});" << endl;
        }
    }

    F0(i, 32) if (f[i]) cerr << i << "  " << g[i] << "/" << f[i] << endl;

    cerr << endl;
    map<pii, int> U;
    map<pii, int> V;
    F0(i, R) {
        U[pii(w[i+C], h[i+C])]++;
        if (bestSol[i+C].first != inf) V[pii(w[i+C], h[i+C])]++;
    }
    for (auto x : U) cerr << x.first.first << "," << x.first.second << "  " << V[x.first] << "/" << x.second << endl;
    */

    PR(bestScore);

    vector<string> ret;
    F0(i, C+R) if (bestSol[i].first != inf) {
        ret.push_back(to_string(bestSol[i].first) + " " + to_string(bestSol[i].second));
    } else {
        ret.push_back("NA");
    }
    Report();
    //if (Elapsed() > 9.8) throw;
    return ret;
}};














void RunVis() {
    TastyPizza prog;
    int R, C;
    double X;
    cin >> C >> R >> X;
    vector< pair<int, int> > aRect(R);
    vector<int> aCircles(C);
    for (int i=0;i<C;i++)
    {
      cin >> aCircles[i];
    }
    for (int i=0;i<R;i++)
    {
      cin >> aRect[i].first >> aRect[i].second;
    }
    vector<string> ret = prog.findSolution(C, R, X, aCircles, aRect);
    cout << ret.size() << endl;
    for (int i = 0; i < (int)ret.size(); ++i)
        cout << ret[i] << endl;
    cout.flush();
}

void RunFromSave() {
    ignore = freopen("2.txt", "r", stdin);
    RunVis();
}

void RunVisSave() {
    ignore = freopen("2.txt", "w", stdout);
    int R, C;
    double X;
    cin >> C >> R >> X;
    cout << C << " " << R << " " << X << endl;
    vector< pair<int, int> > aRect(R);
    vector<int> aCircles(C);
    for (int i=0;i<C;i++)
    {
      cin >> aCircles[i];
      cout << aCircles[i] << endl;
    }
    for (int i=0;i<R;i++)
    {
      cin >> aRect[i].first >> aRect[i].second;
      cout << aRect[i].first << " " << aRect[i].second << endl;
    }
}

int main(int argc, char* argv[]) {
#ifdef RED
    auto x = freopen("log.txt", "w", stderr); (void)x;
#endif
    (void)argv; if (argc > 1) {
        RunFromSave(); exit(0);
    }
    //RunVisSave(); exit(0);
    RunVis();

    return 0;
}
