import java.awt.geom.Ellipse2D;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.SplittableRandom;

public class TastyPizza {
    private int c, r;
    private double xcr, mbest;
    private int[] cr, rw, rh;
    private double[] ac, ar;
    private static final int unused = -1000;
    private Solution best;
    private SplittableRandom rnd = new SplittableRandom(9);
    private long timeout = System.currentTimeMillis() + 9000;
//long K1,K2;
    public String findSolution(int c, int r, double xcr, int[] cr, int[] rw, int[] rh) {
        init(c, r, xcr, cr, rw, rh);
        int cycles = 0;
        while (System.currentTimeMillis() < timeout) {
            place();
            cycles++;
        }
        improveRect(best);
        System.err.println(cycles);
//        System.err.println("K1="+(K1/1e6));
        //System.err.println("K2="+(K2/1e6));
        return best.toString();
    }

    private void improveRect(Solution sol) {
        OUT: for (int k = 0; k < sol.rPlaced.size(); k++) {
            int idx = sol.rPlaced.get(k);
            int x0 = sol.rx[idx];
            int y0 = sol.ry[idx];
            int w0 = rw[idx];
            int h0 = rh[idx];
            double ar0 = ar[idx];
            sol.rx[idx] = unused;
            for (int i = 0; i < r; i++) {
                if (i == idx || sol.rx[i] != unused) continue;
                if (ar[i] <= ar0) continue;
                int w1 = rw[i];
                int h1 = rh[i];
                for (int j = 0; j < 4; j++) {
                    int x1 = (j & 1) == 0 ? x0 : x0 + w0 - w1;
                    int y1 = (j & 2) == 0 ? y0 : y0 + h0 - h1;
                    if (isRectInPizza(x1, y1, w1, h1)) {
                        if (sol.canPlaceRectFull(i, x1, y1)) {
                            sol.rPlaced.set(k, i);
                            sol.placeRect(i, x1, y1);
                            sol.rsum += ar[i] - ar[idx];
                            k--;
                            continue OUT;
                        }
                    }
                }
            }
            sol.rx[idx] = x0;
        }
    }

    private void place() {
        Solution sol = new Solution();
        int[] copt = new int[c];
        int cc = c;
        int[] ropt = new int[r];
        int rr = r;
        for (int i = 0; i < c; i++) {
            copt[i] = i;
        }
        for (int i = 0; i < r; i++) {
            ropt[i] = i;
        }
        double m = mbest + rnd.nextDouble(-0.05, 0.05);//1.25 - xcr * rnd.nextDouble(0.1, 0.3); //TODO
        NEXT: while ((rr > 0 || cc > 0) && System.currentTimeMillis() < timeout) {
            if (rr > 0 && (xcr * sol.csum > (1 - xcr) * sol.rsum * m || cc == 0)) {
                int i = ropt[rnd.nextInt(rr)];
                for (int j = 0; j < 20; j++) {
                    int k = ropt[rnd.nextInt(rr)];
                    if (ar[i] < ar[k]) i = k;
                }
                int wi = rw[i];
                int hi = rh[i];
                OUT: for (int x = 100 - wi - 1; x > -100; x--) {
                    for (int y = 0; y < 100; y++) {
                        boolean up = true;
                        boolean down = true;
                        if (up) {
                            if (isRectInPizza(x, y, wi, hi)) {
                                //long t = System.nanoTime();
                                if (sol.canPlaceRect(i, x, y)) {
                                    sol.placeRect(i, x, y);
                                    for (int j = 0; j < rr; j++) {
                                        if (ropt[j] == i) {
                                            ropt[j] = ropt[--rr];
                                            break;
                                        }
                                    }
                                    //K1 += System.nanoTime()-t;
                                    continue NEXT;
                                }
                                //K1 += System.nanoTime()-t;
                            } else {
                                if (!down) continue OUT;
                                up = false;
                            }
                        }
                        if (down && y > 0) {
                            if (isRectInPizza(x, -y, wi, hi)) {
                                //long t = System.nanoTime();
                                if (sol.canPlaceRect(i, x, -y)) {
                                    sol.placeRect(i, x, -y);
                                    for (int j = 0; j < rr; j++) {
                                        if (ropt[j] == i) {
                                            ropt[j] = ropt[--rr];
                                            break;
                                        }
                                    }
                                    //K1 += System.nanoTime()-t;
                                    continue NEXT;
                                }
                                    //K1 += System.nanoTime()-t;
                            } else {
                                if (!up) continue OUT;
                                down = false;
                            }
                        }
                    }
                }
                for (int j = 0; j < rr; j++) {
                    if (ropt[j] == i) {
                        ropt[j--] = ropt[--rr];
                    } else {
                        int k = ropt[j];
                        if (rw[k] >= wi && rh[k] >= hi) {
                            ropt[j--] = ropt[--rr];
                        }
                    }
                }
            } else if (cc > 0) {
                int i = copt[rnd.nextInt(cc)];
                for (int j = 0; j < 20; j++) {
                    int k = copt[rnd.nextInt(cc)];
                    if (ac[i] < ac[k]) i = k;
                }
                int ri = cr[i];
                for (int x = -100 + ri; x <= 100 - ri; x++) {
                    for (int y = 100 - ri; y >= 0; y--) {
                        if (!isCircleInPizza(x, y, ri)) continue;
                        for (int j = y == 0 ? 1 : 0; j <= 1; j++) {
                            int yy = j == 0 ? y : -y;
                            //long t = System.nanoTime();
                            if (sol.canPlaceCircle(i, x, yy)) {
                                sol.placeCircle(i, x, yy);
                                for (int k = 0; k < cc; k++) {
                                    if (copt[k] == i) {
                                        copt[k] = copt[--cc];
                                        break;
                                    }
                                }
                                //K2 += System.nanoTime()-t;
                                continue NEXT;
                            }
                            //K2 += System.nanoTime()-t;
                        }
                    }
                }
                for (int j = 0; j < cc; j++) {
                    if (copt[j] == i) {
                        copt[j--] = copt[--cc];
                    } else {
                        int k = copt[j];
                        if (cr[k] >= ri) {
                            copt[j--] = copt[--cc];
                        }
                    }
                }
            }
        }
        if (best == null || sol.score() > best.score()) {
            System.err.println(sol.score());
            best = sol;
            mbest = m;
        }
    }

    private boolean isCircleInPizza(int x, int y, int ri) {
        int dr = 100 - ri;
        return x * x + y * y <= dr * dr;
    }

    private boolean isRectInPizza(int x, int y, int wi, int hi) {
        if (x * x + y * y > 10000) return false;
        int x1 = x + wi;
        int y1 = y + hi;
        if (x1 * x1 + y1 * y1 > 10000) return false;
        if (x * x + y1 * y1 > 10000) return false;
        if (x1 * x1 + y * y > 10000) return false;
        return true;
    }

    private void init(int c, int r, double xcr, int[] cr, int[] rw, int[] rh) {
        this.c = c;
        this.r = r;
        this.xcr = xcr;
        this.cr = cr;
        this.rw = rw;
        this.rh = rh;
        ac = new double[c];
        for (int i = 0; i < c; i++) {
            ac[i] = Math.PI * cr[i] * cr[i];
        }
        ar = new double[r];
        for (int i = 0; i < r; i++) {
            ar[i] = rw[i] * rh[i];
        }
        mbest = 1.25 - xcr * 0.25;
    }

    class Solution {
        int[] cx, cy, rx, ry;
        double csum, rsum;
        List<Integer> cPlaced = new ArrayList<Integer>();
        List<Integer> rPlaced = new ArrayList<Integer>();
        byte[] canCircle = new byte[65536];
        boolean[] canRect = new boolean[65536];

        void placeCircle(int idx, int x, int y) {
            cx[idx] = x;
            cy[idx] = y;
            csum += ac[idx];
            cPlaced.add(idx);
        }

        boolean circleInter(int x0, int y0, int r0, int x1, int y1, int r1) {
            int dr = r0 + r1;
            int dx = x0 - x1;
            if (dr <= dx || dr <= -dx) return false;
            int dy = y0 - y1;
            if (dr <= dy || dr <= -dy) return false;
            return dx * dx + dy * dy < dr * dr;
        }

        boolean rectInter(int x0, int y0, int w0, int h0, int x1, int y1, int w1, int h1) {
            if (x1 >= x0 + w0) return false;
            if (x0 >= x1 + w1) return false;
            if (y1 >= y0 + h0) return false;
            if (y0 >= y1 + h1) return false;
            return true;
        }

        boolean rectCicleInter(int x0, int y0, int w0, int h0, int x1, int y1, int r1) {
            if (x1 >= x0 && x1 <= x0 + w0 && y1 >= y0 && y1 <= y0 + h0) return true;
            if (x1 + r1 <= x0) return false;
            if (x1 - r1 >= x0 + w0) return false;
            if (y1 + r1 <= y0) return false;
            if (y1 - r1 >= y0 + h0) return false;
            Ellipse2D e = new Ellipse2D.Double(x1 - r1, y1 - r1, r1 * 2, r1 * 2);
            return e.intersects(x0, y0, w0, h0);
            //return true;
        }

        boolean canPlaceCircle(int idx, int x, int y) {
            int key = (x + 100) | ((y + 100) << 8);
            int v = canCircle[key];
            int ridx = cr[idx];
            if (ridx >= v) return false;
            for (int i : cPlaced) {
                if (circleInter(x, y, ridx, cx[i], cy[i], cr[i])) {
                    canCircle[key] = (byte) ridx;
                    return false;
                }
            }
            for (int i : rPlaced) {
                if (rectCicleInter(rx[i], ry[i], rw[i], rh[i], x, y, ridx)) {
                    canCircle[key] = (byte) ridx;
                    return false;
                }
            }
            return true;
        }

        boolean canPlaceRect(int idx, int x, int y) {
            int key = (x + 100) | ((y + 100) << 8);
            if (!canRect[key]) return false;
            for (int i : rPlaced) {
                if (rectInter(x, y, 5, 5, rx[i], ry[i], rw[i], rh[i])) return canRect[key] = false;
            }
            for (int i : cPlaced) {
                if (rectCicleInter(x, y, 5, 5, cx[i], cy[i], cr[i])) return canRect[key] = false;
            }
            return canPlaceRectFull(idx, x, y);
        }

        boolean canPlaceRectFull(int idx, int x, int y) {
            int widx = rw[idx];
            int hidx = rh[idx];
            for (int i : rPlaced) {
                if (rectInter(x, y, widx, hidx, rx[i], ry[i], rw[i], rh[i])) return false;
            }
            for (int i : cPlaced) {
                if (rectCicleInter(x, y, widx, hidx, cx[i], cy[i], cr[i])) return false;
            }
            return true;
        }

        void placeRect(int idx, int x, int y) {
            rx[idx] = x;
            ry[idx] = y;
            rsum += ar[idx];
            rPlaced.add(idx);
        }

        double score() {
            return csum + rsum - Math.abs(xcr * csum - (1 - xcr) * rsum);
        }

        public Solution() {
            cx = new int[c];
            cy = new int[c];
            rx = new int[r];
            ry = new int[r];
            Arrays.fill(cx, unused);
            Arrays.fill(rx, unused);
            Arrays.fill(canCircle, (byte) 32);
            Arrays.fill(canRect, true);
        }

        public String toString() {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < c; i++) {
                int x = cx[i];
                if (x == unused) sb.append("NA");
                else sb.append(x).append(' ').append(cy[i]);
                sb.append('\n');
            }
            for (int i = 0; i < r; i++) {
                int x = rx[i];
                if (x == unused) sb.append("NA");
                else sb.append(x).append(' ').append(ry[i]);
                sb.append('\n');
            }
            return sb.toString();
        }
    }

    public static void main(String[] args) {
        TastyPizza sol = new TastyPizza();
        try {
            BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
            int c = Integer.parseInt(br.readLine());
            int r = Integer.parseInt(br.readLine());
            double x = Double.parseDouble(br.readLine());
            int[] cr = new int[c];
            for (int i = 0; i < c; i++) {
                cr[i] = Integer.parseInt(br.readLine());
            }
            int[] rw = new int[r];
            int[] rh = new int[r];
            for (int i = 0; i < r; i++) {
                String[] s = br.readLine().split(" ");
                rw[i] = Integer.parseInt(s[0]);
                rh[i] = Integer.parseInt(s[1]);
            }
            String ret = sol.findSolution(c, r, x, cr, rw, rh);
            System.out.println(c + r);
            System.out.print(ret);
            System.out.flush();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}