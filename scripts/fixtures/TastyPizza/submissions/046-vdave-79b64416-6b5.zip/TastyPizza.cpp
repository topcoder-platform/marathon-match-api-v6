﻿// Topcoder Open 2020 - Finals - TastyPizza.
// Author: vdave, Hungary.

#define NOMINMAX
#define _CRT_SECURE_NO_WARNINGS

//#pragma GCC target "avx"

#include <algorithm>
#include <cstdio>
#include <cfloat>
#include <cmath>
#include <cstring>
#include <iostream>
#include <map>
#include <random>
#include <set>
#include <string>
#include <utility>
#include <vector>
#include <unordered_map>
#include <unordered_set>

using namespace std;

#define TC_DEBUG

#ifdef TC_DEBUG
#define DEBUG(...) fprintf(fDebug, __VA_ARGS__)
#define GDEBUG(s, ...) { sprintf(sTmp, __VA_ARGS__); s.append(sTmp); }
#else
#define DEBUG(...)
#define GDEBUG(...)
#endif

// Platform specific stuff (timer, alignment, some intrinsics).

#ifdef _WIN32

// WIN32 platform definitions

#define ALIGN_SSE __declspec(align(64))
#define NOINLINE __declspec(noinline)

#include <ctime>
#include <intrin.h>
#include <windows.h>

typedef LARGE_INTEGER hp_timer_t;
LARGE_INTEGER gl_timer_freq;
double gl_timer_multiplier;

void InitTimer() {
	QueryPerformanceFrequency(&gl_timer_freq);
	gl_timer_multiplier = 1000000.0 / (double)gl_timer_freq.QuadPart;
}

void FetchTime(hp_timer_t* timer_value) {
	QueryPerformanceCounter(timer_value);
}

double GetElapsedMicros(hp_timer_t& timer_value_begin, hp_timer_t& timer_value_end) {
	return gl_timer_multiplier * (timer_value_end.QuadPart - timer_value_begin.QuadPart);
}

int __gcd(int a, int b) {
	if (b == 0) return a;
	return __gcd(b, a % b);
}

#else

// LINUX platform definitions

#define ALIGN_SSE __attribute__((aligned (64)))
#define NOINLINE

#include <sys/time.h>
#include <ctime>
#include <random>

typedef struct timeval hp_timer_t;

void InitTimer() {
}

void FetchTime(hp_timer_t* timer_value) {
	gettimeofday(timer_value, nullptr);
}

double GetElapsedMicros(hp_timer_t& timer_value_begin,
	hp_timer_t& timer_value_end) {
	return (timer_value_end.tv_sec * 1000000.0 + timer_value_end.tv_usec)
		- (timer_value_begin.tv_sec * 1000000.0 + timer_value_begin.tv_usec);
}

#endif



// Debug information for local runs.
bool dbgHasExtraInput;
int dbgSeed;
FILE* fDebug = stderr;
char sTmp[65536];

// Global tweaking constants.
constexpr double kMaxRuntimeMicros = 9.6 * 1000.0 * 1000.0;
constexpr int kDeltaX[4] = { 1, -1, 0, 0 };
constexpr int kDeltaY[4] = { 0, 0, 1, -1 };

// Problem-specific tweaking constants.
constexpr double kTempInitial = 100.0;
constexpr double kTempCoolFactor = 0.9995;
constexpr int kSAIterations = 100000;

// Global randomness.
mt19937 randEngine;
std::uniform_real_distribution<double> randProb(0.0, 1.0);

// Timekeeping.
hp_timer_t tBegin, tInit, tCurrent;
int currentRound, numIters;
int roundsPerTimeCheck = 1;
double estimatedProgress = 0.0;

// Input copied.
struct TCircle {
	int r;
	int cx;
	int cy;
	double A;
};

struct TRectangle {
	int w;
	int h;
	int x0;
	int y0;
	int x1;
	int y1;
	double A;
};

constexpr double kPI = 3.14159265359;
constexpr int kBaseRadius = 100;
constexpr int kBaseRadiusSq = kBaseRadius * kBaseRadius;
constexpr int kUnused = -10000000;

int C, R;
double X;
TCircle inputC[512];
TRectangle inputR[512];
int orderC[512];
int orderR[512];


// Currently evaluated solution.
double currentScore;
TCircle currentC[512];
TRectangle currentR[512];
double currentAreaC, currentAreaR;
int currentNumC, currentNumR;
int currentIndexC[512], currentIndexR[512];

int packHeight[512];

// Best answer and score so far.
double bestScore, bestAreaC, bestAreaR;
TCircle bestC[512];
TRectangle bestR[512];

// Solver API.
class TastyPizza {
public:
	vector<string> findSolution(int aC, int aR, double aX, const vector<int>& aCircles, const vector<pair<int, int>>& aRects);
};



// Updates the best solution with the current one if the score is better (lower).
void MaybeUpdateBest() {
	if (currentScore > bestScore) {
		bestScore = currentScore;
		bestAreaC = currentAreaC;
		bestAreaR = currentAreaR;
		for (int c = 0; c < C; ++c) {
			bestC[c] = currentC[c];
		}
		for (int r = 0; r < R; ++r) {
			bestR[r] = currentR[r];
		}
		DEBUG("[S=%d, R=%d] New Best = %.8lf\n", dbgSeed, currentRound, bestScore);
	}
}

double ScoreDiffFactor() {
	return X * currentAreaC - (1.0 - X) * currentAreaR;
}

double Score() {
	return currentAreaC + currentAreaR - std::abs(ScoreDiffFactor());
}

inline bool InsidePizza(int x, int y) {
	return (x * x + y * y) <= kBaseRadiusSq;
}

inline bool FitsPizza(const TCircle& c) {
	const int deltaR = kBaseRadius - c.r;
	return (c.cx * c.cx) + (c.cy * c.cy) <= deltaR * deltaR;
}

inline bool FitsPizza(const TRectangle& r) {
	return InsidePizza(r.x0, r.y0) && InsidePizza(r.x0 + r.w, r.y0) && InsidePizza(r.x0, r.y0 + r.h) && InsidePizza(r.x0 + r.w, r.y0 + r.h);
}

inline bool Overlap(const TCircle& c1, const TCircle& c2) {
	const int dx = c1.cx - c2.cx;
	const int dy = c1.cy - c2.cy;
	const int sum_r = c1.r + c2.r;
	return (dx * dx + dy * dy) < (sum_r * sum_r);

}

inline bool Overlap(const TRectangle& r1, const TRectangle& r2) {
	const int maxL = std::max(r1.x0, r2.x0);
	const int minR = std::min(r1.x1, r2.x1);
	if (maxL >= minR) return false;
	const int maxB = std::max(r1.y0, r2.y0);
	const int minT = std::min(r1.y1, r2.y1);
	return maxB < minT;
}

// TODO: Fix for precise checking, this now handles bounding boxes only.
inline bool Overlap(const TRectangle& r, const TCircle& c) {
	TRectangle bb = { 2 * c.r, 2 * c.r, c.cx - c.r, c.cy - c.r, c.cx + c.r, c.cy + c.r};
	return Overlap(r, bb);
}



// MAIN SOLVER BEGINS HERE.

// IDEAS:
// 1) Generate a large block of rectangle closely packed.



vector<string> TastyPizza::findSolution(int aC, int aR, double aX, const vector<int>& aCircles, const vector<pair<int, int>>& aRects) {
	// Initalize timing, randomness.
	InitTimer();
	FetchTime(&tBegin);
	randEngine.seed(0xdeadbeef);

	// Save input.
	C = aC;
	R = aR;
	X = aX;
	for (int c = 0; c < C; ++c) {
		inputC[c].r = aCircles[c];
	}
	for (int r = 0; r < R; ++r) {
		inputR[r].w = aRects[r].first;
		inputR[r].h = aRects[r].second;
	}

	// Initialize best solution.
	for (int c = 0; c < C; ++c) {
		bestC[c].cx = kUnused;
	}
	for (int r = 0; r < R; ++r) {
		bestR[r].x0 = kUnused;
	}
	bestScore = 0.0;

	// Precalculate stuff.

	// Precalculate circle and rectangle area.
	for (int c = 0; c < C; ++c) {
		inputC[c].A = kPI * inputC[c].r * inputC[c].r;
	}
	for (int r = 0; r < R; ++r) {
		inputR[r].A = inputR[r].w * inputR[r].h;
	}

	// Precalculate order of circles and rectangles.
	vector<pair<int, int>> C_by_radius(C);
	for (int c = 0; c < C; ++c) {
		C_by_radius.emplace_back(-inputC[c].r, c);
	}
	std::sort(C_by_radius.begin(), C_by_radius.end());
	for (int c = 0; c < C; ++c) {
		orderC[c] = C_by_radius[c].second;
	}

	vector<pair<pair<int, int>, int>> R_by_W_and_H(R);
	for (int r = 0; r < R; ++r) {
		R_by_W_and_H.emplace_back(make_pair(-inputR[r].w, -inputR[r].h), r);
	}
	std::sort(R_by_W_and_H.begin(), R_by_W_and_H.end());
	for (int r = 0; r < R; ++r) {
		orderR[r] = R_by_W_and_H[r].second;
	}


	FetchTime(&tInit);
	DEBUG("Initialization time: %.3lf us.\n", GetElapsedMicros(tBegin, tInit));

	// Optimal circle / rectangle ratio
	// X * C == (1 - X) * R
	// C + R = PI * 100^2
	// C = PI * 100^2 - R
	// X * (PI * 100^2 - R) == (1 - X) * R
	// X * PI * 100^2 - X * R == R - X * R
	// R = X * PI * 100 ^2
	

	





	// SOLVE PROBLEM.
	currentRound = 0;
	roundsPerTimeCheck = 1;
	while (true) {
		// Initialize candidate solution, no circles / rectangles are used.
		// TODO: Build structures initially and just do a memcpy().
		for (int c = 0; c < C; ++c) {
			currentC[c].r = inputC[c].r;
			currentC[c].cx = kUnused;
		}
		for (int r = 0; r < R; ++r) {
			currentR[r].w = inputR[r].w;
			currentR[r].h = inputR[r].h;
			currentR[r].x0 = kUnused;
		}
		currentNumC = 0;
		currentNumR = 0;
		currentAreaC = 0.0;
		currentAreaR = 0.0;
		currentScore = 0.0;

		// Try to pack rectangles densly in a packW * packH rectangle in the middle of the base circle
		// with aiming to have a total area around the optimal total area for rectangles.
		double optimalAreaR = X * kPI * kBaseRadiusSq;
		int packW = (randEngine() % kBaseRadius) + kBaseRadius / 2;
		// Find a good height which still fits inside the pizza.
		int packH = 1;
		int packX0 = -packW / 2;
		int packY0 = 0;
		for (;; packH++) {
			if (packW * packH > optimalAreaR) break;
			packY0 = -packH / 2;

			TRectangle packRect = { packW, packH, packX0, packY0, packX0 + packW, packY0 + packH };
			if (!FitsPizza(packRect)) {
				packH--;
				break;
			}
		}
		//DEBUG("Tryinto to pack into: [%d, %d] .. [%d, %d] (%d x %d) (OptR = %.2lf)\n", packX0, packY0, packX0 + packW, packY0 + packH, packW, packH, optimalAreaR);
		if (packH > 0) {
			// Algorithm 1 First fit
			for (int i = 0; i < packW; ++i) {
				packHeight[i] = 0;
			}
			int startCol = 0, currentColW = 0;
			int colHeight = 0;
			for (int ri = 0; ri < R; ++ri) {
				const int changeR = orderR[ri];
				const auto& rect = currentR[changeR];
				if (startCol + rect.w > packW) {
					// Too wide
					continue;
				}
				if (colHeight + rect.h > packH) {
					startCol += currentColW;
					currentColW = 0;
					colHeight = 0;
					if (startCol + rect.w > packW) {
						// Too wide
						continue;
					}
				}
				if (colHeight + rect.h <= packH) {
					// Fits to the current column.
					currentColW = std::max(currentColW, rect.w);
					currentR[changeR].x0 = packX0 + startCol;
					currentR[changeR].y0 = packY0 + colHeight;
					currentR[changeR].x1 = currentR[changeR].x0 + inputR[changeR].w;
					currentR[changeR].y1 = currentR[changeR].y0 + inputR[changeR].h;
					currentIndexR[currentNumR++] = changeR;
					currentAreaR += inputR[changeR].A;
					currentScore = Score();
					colHeight += rect.h;
				}
			}
		}

		// Fine tune solution.
		double T = kTempInitial;
		int lastChangeIter = 0;
		int cIndex = 0;
		for (int iter = 0; iter < kSAIterations; ++iter) {
			T *= kTempCoolFactor;

			if (iter % 1000 == 0) {
				FetchTime(&tCurrent);
				const double elapsedMicros = GetElapsedMicros(tBegin, tCurrent);
				if (elapsedMicros > kMaxRuntimeMicros)
					break;
			}

			// No changes in 5000 iterations, stop improving this candidate.
			if (iter > lastChangeIter + 5000) break;

			// Factor inside the abs(), positive => more rectangles needed, negative => more circles needed.
			double diffFactor = ScoreDiffFactor();
			//const bool isCircle = randEngine() % 2;
			bool isCircle = diffFactor < 0;
			if (currentNumC == C) isCircle = false;
			if (currentNumR == R) isCircle = true;
			if (isCircle) {
				// Try to place a circle.
				//const int changeC = randEngine() % C;
				const int changeC = orderC[cIndex++ % C];
				if (currentC[changeC].cx != kUnused) continue;

				// Try 50 different positions.
				bool isPlaced = false;
				for (int subIter = 0; subIter < 50; ++subIter) {
					currentC[changeC].cx = (randEngine() % (2 * kBaseRadius)) - kBaseRadius;
					currentC[changeC].cy = (randEngine() % (2 * kBaseRadius)) - kBaseRadius;
					if (!FitsPizza(currentC[changeC])) continue;

					// Check overlap with existing circles.
					bool noOverlap = true;
					for (int ci = 0; ci < currentNumC; ++ci) {
						const int c = currentIndexC[ci];
						if (Overlap(currentC[changeC], currentC[c])) {
							noOverlap = false;
							break;
						}
					}

					// Check overlap with existing rectangles.
					if (noOverlap) {
						for (int ri = 0; ri < currentNumR; ++ri) {
							const int r = currentIndexR[ri];
							if (Overlap(currentR[r], currentC[changeC])) {
								noOverlap = false;
								break;
							}
						}
					}

					if (noOverlap) {
						isPlaced = true;
						break;
					}
				}

				if (isPlaced) {
					currentIndexC[currentNumC++] = changeC;
					currentAreaC += inputC[changeC].A;
					currentScore = Score();

					lastChangeIter = iter;
				}
				else {
					currentC[changeC].cx = kUnused;
				}
			}
			else {
				// Try to place a rectangle.
				const int changeR = randEngine() % R;
				if (currentR[changeR].x0 != kUnused) continue;

				// Try 50 different positions.
				bool isPlaced = false;
				for (int subIter = 0; subIter < 50; ++subIter) {
					currentR[changeR].x0 = (randEngine() % (2 * kBaseRadius)) - kBaseRadius;
					currentR[changeR].y0 = (randEngine() % (2 * kBaseRadius)) - kBaseRadius;
					currentR[changeR].x1 = currentR[changeR].x0 + inputR[changeR].w;
					currentR[changeR].y1 = currentR[changeR].y0 + inputR[changeR].h;
					if (!FitsPizza(currentR[changeR])) continue;

					// Check overlap with existing circles.
					bool noOverlap = true;
					for (int ci = 0; ci < currentNumC; ++ci) {
						const int c = currentIndexC[ci];
						if (Overlap(currentR[changeR], currentC[c])) {
							noOverlap = false;
							break;
						}
					}

					// Check overlap with existing rectangles.
					if (noOverlap) {
						for (int ri = 0; ri < currentNumR; ++ri) {
							const int r = currentIndexR[ri];
							if (Overlap(currentR[r], currentR[changeR])) {
								noOverlap = false;
								break;
							}
						}
					}

					if (noOverlap) {
						isPlaced = true;
						break;
					}
				}

				if (isPlaced) {
					currentIndexR[currentNumR++] = changeR;
					currentAreaR += inputR[changeR].A;
					currentScore = Score();

					lastChangeIter = iter;
				}
				else {
					currentR[changeR].x0 = kUnused;
				}
			}

			//double oldScore = currentScore;
			//bool keepChange = currentScore > oldScore;
			//if (currentScore > oldScore) {
			//	const double keepProb = std::exp(1.0 * (currentScore - oldScore) / T);
			//	if (randProb(randEngine) < keepProb) keepChange = true;
			//}
			//if (keepChange) {
			//	// Intentionally left empty.
			//}
			//else {
			//	// Revert changes.
			//}
		}

		// Update best possible solution if the current one is better.
		MaybeUpdateBest();

		// This round is over, check system time every 10ms and update progress.
		currentRound++;
		if (currentRound % roundsPerTimeCheck == 0) {
			FetchTime(&tCurrent);
			const double elapsedMicros = GetElapsedMicros(tBegin, tCurrent);
			if (elapsedMicros > kMaxRuntimeMicros)
				break;
		}
	}

	FetchTime(&tCurrent);
	DEBUG("DATA_HEADER,Seed,C,R,X,AreaC,AreaR,AreaSum,AreaBase,Score,Runtime,Rounds\n");
	DEBUG("DATA_EXPORT,%d,%d,%d,%.6lf,%.6lf,%.6lf,%.6lf,%.6lf,%.6lf,%.2lf,%d\n", dbgSeed, C, R, X, bestAreaC, bestAreaR, bestAreaC + bestAreaR, 31415.92654, bestScore,
		GetElapsedMicros(tBegin, tCurrent), currentRound);
	fflush(fDebug);

	vector<string> retVal(C + R);
	for (int c = 0; c < C; ++c) {
		if (bestC[c].cx == kUnused) {
			retVal[c] = "NA";
		}
		else {
			sprintf(sTmp, "%d %d", bestC[c].cx, bestC[c].cy);
			retVal[c] = sTmp;
		}
	}
	for (int r = 0; r < R; ++r) {
		if (bestR[r].x0 == kUnused) {
			retVal[C + r] = "NA";
		}
		else {
			sprintf(sTmp, "%d %d", bestR[r].x0, bestR[r].y0);
			retVal[C + r] = sTmp;
		}
	}

	return retVal;
}




// Tester wrapper.
int main(int argc, char* argv[]) {
	dbgHasExtraInput = false;

#ifdef TC_DEBUG
	for (int i = 1; i < argc; ++i) {
		if (!strncmp(argv[i], "-s=", 3)) {
			dbgSeed = atoi(argv[i] + 3);
		}
		else if (!strncmp(argv[i], "-o=", 3)) {
			fDebug = fopen(argv[i] + 3, "at");
		}
		else if (!strncmp(argv[i], "-d", 2)) {
			dbgHasExtraInput = true;
		}
	}
	fprintf(fDebug, "=========== SEED: %d ===========\n", dbgSeed);
#endif

	int genC, genR;
	double genX;
	cin >> genC;
	cin >> genR;
	cin >> genX;

	vector<int> genCircles(genC);
	for (int i = 0; i < genC; ++i) {
		cin >> genCircles[i];
	}

	vector<pair<int, int>> genRects(genR);
	for (int i = 0; i < genR; ++i) {
		cin >> genRects[i].first;
		cin >> genRects[i].second;
	}

	TastyPizza solver;
	auto retVal = solver.findSolution(genC, genR, genX, genCircles, genRects);

	if (fDebug != stderr) {
		fflush(fDebug);
		fclose(fDebug);
	}

	cout << retVal.size() << endl;
	for (auto x : retVal) {
		cout << x << endl;
	}
	cout.flush();
	cerr.flush();

	return 0;
}
