//#define NDEBUG

#pragma GCC target "avx"

#include <algorithm>
#include <bitset>
#include <cassert>
#include <cctype>
#include <climits>
#include <cmath>
#include <complex>
//#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <limits>
#include <list>
#include <map>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <string>
#include <utility>
#include <vector>
#include <array>

#include <sys/time.h>
#include <random>
#include <chrono>
#include <unordered_map>
#include <unordered_set>

#include <x86intrin.h>
#include <emmintrin.h>

using namespace std;
//#define DEBUG              // general information//

template<class T, class V> std::ostream&  operator <<(std::ostream& stream, const pair<T,V> & p) {
  stream << p.first << "," << p.second << " ";
  return stream;
}

template<class T> std::ostream&  operator <<(std::ostream& stream, const vector<T> & v) {
  for (auto el : v)
    stream << el << " ";
  return stream;
}

template<class T> std::ostream&  operator << (std::ostream& stream, const vector< vector<T> > & v) {
  for (auto line : v) {
    for (auto el : line)
      stream << el << " ";
    stream << "\n";
  }
  return stream;
}

class debugger {
public:
  template<class T> void output (const T& v) {
    cerr << v << " ";
  }
  
  template<class T> debugger& operator , (const T& v) {
    output(v);
    return *this;
  }
} dbg;

// Adapted from http://codeforces.com/blog/entry/15643
vector<string> debug_split(const string& s, char c) {
    vector<string> v; stringstream ss(s); string x;
    while (getline(ss, x, c)) v.emplace_back(x); return move(v);}

//void debug_err(vector<string>::iterator it) {cerr << "\n";}
template<typename T, typename... Args>
void debug_err(vector<string>::iterator it, T a, Args... args) {
    cerr << it -> substr((*it)[0] == ' ', it -> length()) << " = " << a << " | ";
    debug_err(++it, args...);
}

// End debug

////////////////
// templates  //
////////////////

// general
//template size
template<typename T> int size(const T& c) { return int(c.size()); }
//template abs
template<typename T> T abs(T x) { return x < 0 ? -x : x; }
//template sqr
template<typename T> T sqr(T x) { return x*x; }
//template remin
template<typename T> bool remin(T& x, T y) { if (x <= y) return false; x = y; return true; }
//template remax
template<typename T> bool remax(T& x, T y) { if (x >= y) return false; x = y; return true; }
//template toStr
template<typename T> string toStr(T x) { stringstream ss; ss << x; return ss.str(); }
//helper len
inline int len(const string & x){ return x.length(); }
//helper print_mask
inline void print_mask(int mask, int n){for (int i = 0; i < n; ++i) cerr << (char)('0' + (mask >> i & 1));}
//helper stoi
//int stoi(const string & s){stringstream ss(s); int res; ss >> res; return res;}
//helper itos
string itos(const int & x){stringstream ss; ss << x; return ss.str();}

// types
//template int64
typedef long long            int64 ;
//template uint64
typedef unsigned long long   uint64 ;
typedef unsigned char uchar;
typedef unsigned short ushort;
typedef int64 hash_type;

// shortcuts
#define all(_xx)             _xx.begin(), _xx.end()

#define pb                   push_back
#define vl                   vector<long long>
#define vs                   vector<string>
#define vvs                  vector<vector<string>>
#define vvi                  vector<vector<int>>
#define vvl                  vector<vector<long long>>
#define vd                   vector<double>
#define vvd                  vector<vector<double>>
#define vc                   vector<char>
#define vvc                  vector<vector<char>>
#define vpdd                 vector<pair<double,double> >

#define vi                   vector<int>
#define vpii                 vector<pair<int,int>> 
//#define vpii                 vector<pair<short,short> >


#define pii                  pair<int, int>
#define pcc                  pair<char, char>
#define pucc                 pair<uchar, uchar>
#define pll                  pair<long long, long long>
#define pdd                  pair<double, double>
#define mp(XX, YY)           make_pair(XX, YY)
#define fi                   first
#define se                   second

#define ll                   long long
#define ull                  unsigned long long
#define SS                   stringstream

#define ptype unsigned short

// for loops
#define re(II, NN)           for (int II(0), _NN(NN); (II) < (_NN); ++(II))
#define fod(II, XX, YY)      for (int II(XX), _YY(YY); (II) >= (_YY); --(II))
#define fo(II, XX, YY)       for (int II(XX), _YY(YY); (II) <= (_YY); ++(II))
#define foreach(it,c) for(__typeof((c).begin()) it=(c).begin();it!=(c).end();++it)

// Useful hardware instructions
#define bitcount             __builtin_popcount
#define gcd                  __gcd

// Useful all around
#define checkbit(n,b)        ((n >> (b)) & 1)
#define pt2(b)               (1LL<<(b))
#define DREP(a)              sort(a.begin(), a.end());a.erase(unique(a.begin(), a.end()),a.end())
#define INDEX(arr,ind)       (lower_bound(arr.begin(), arr.end(),ind)-arr.begin())
#define PAUSE cerr << "Press any key to continue ..."; char xxxx; scanf("%c", &xxxx);

#define v_fill(xx,val) fill(all(xx), val)
#define m_fill(xx,val) memset(xx, val, sizeof(xx))

#define SUM(vv) accumulate(vv.begin(), vv.end(), 0)
#define oo (10001)

#define ALWAYS_INLINE inline __attribute__((always_inline))
#define ALIGNED __attribute__ ((aligned(16)))

#define likely(x)  __builtin_expect(!!(x),1)
#define unlikely(x) __builtin_expect(!!(x),0)

#define SSE_LOAD(a)    _mm_load_si128((const __m128i*)&a)
#define SSE_STORE(a, b) _mm_store_si128((__m128i*)&a, b)


ull getTicks() {
#ifdef __i386
    ull time;
    __asm__ volatile ("rdtsc" : "=A" (time));
    return time;
#else
    ull timelo, timehi;
    __asm__ volatile ("rdtsc" : "=a" (timelo), "=d" (timehi));
    return (timehi << 32) + timelo;
#endif
}

#define SUBMIT

// changed NON SUBMIT from 3.6e9 * 1.32

const double inv_frequency = 1.0 / 2.8e9;

double convertTicks(ull time) {
#ifndef SUBMIT  
    return time / 3.3e9 * 1.23;
#else
    return time * inv_frequency;
    //return time / 3.6e9 * 1.46;
#endif
}

double getTime() {
  return convertTicks(getTicks()) * 1.0;
}

struct Timer {
  ull ticks;
  const string name;
  bool running;
  int count;
  
  Timer() {;}

  Timer(string _name) : name(_name) {
    ticks = 0;
    count = 0;
    running = false;
  }

  void reset() {
    ticks = 0;
    count = 0;
    running = false; 
  }

  double elapsed() {
    return convertTicks(running ? getTicks() - ticks : ticks);
  }

  void start() {
    if (running) return;
    ticks = getTicks() - ticks;
    running = true;
  }
  
  void stop() {
    if (!running) return;
    ticks = getTicks() - ticks;
    running = false;
    count++;
  }
  
  void check() {
    double delta = elapsed();
    cerr << name << ": " << delta << " count: " << count;
    if (count) cerr << " mean per sec: " << (1 / delta) * count;
    cerr << endl;
  }

//  double elapsed() {;}
//  void startTimer() {;}
//  void stopTimer() {;}
//  void checkTimer() {;}

};

// class ChronoTimer {
// public:
//   double start, end, total;
  
//   double getTime()
//   { 
//     timeval tv;
//     gettimeofday(&tv, 0);
//     return (tv.tv_sec + tv.tv_usec * 0.000001);
//   }

//   void startTimer() {
//     start = getTime();
//   }
  
//   double stopTimer() {
//     double elapsed_seconds = checkTimer();
//     // total += elapsed_seconds;
//     // cerr << "ChronoTimer: " << elapsed_seconds << "\n";
//     return elapsed_seconds;
//   }
  
//   double checkTimer() {
//     timeval tv;
//     gettimeofday(&tv, 0);
//     return tv.tv_sec + tv.tv_usec * 0.000001 - start;
//   }
  
//   ChronoTimer() {total = 0.0; startTimer();}
// };

namespace Color {
  enum Code {
    FG_RED      = 31,
    FG_GREEN    = 32,
    FG_YELLOW   = 33,
    FG_BLUE     = 34,
    FG_DEFAULT  = 39,
    BG_RED      = 41,
    BG_GREEN    = 42,
    BG_BLUE     = 44,
    BG_DEFAULT  = 49
  };
  
  class Modifier {
    Code code;
  public:
    Modifier(Code pCode) : code(pCode) {}
    friend std::ostream&
    operator<<(std::ostream& os, const Modifier& mod) {
      return os << "\033[" << mod.code << "m";
    }
  };
}

const uchar
v_white[3]  = { 255, 255, 255 }, v_black[3] = { 0, 0, 0 },     v_red[3] = { 120, 50, 80 },
v_yellow[3] = { 200, 155, 0 },   v_green[3] = { 30, 200, 70 }, v_purple[3] = { 175, 32, 186 },
v_blue[3]   = { 55, 140, 185 },  v_grey[3] = { 127, 127, 127 };

Color::Modifier green(Color::FG_GREEN);
Color::Modifier red(Color::FG_RED);
Color::Modifier yellow(Color::FG_YELLOW);
Color::Modifier blue(Color::FG_BLUE);
Color::Modifier def(Color::FG_DEFAULT);

///////////////////////////////////////////////////////////

template <class T>
pair<T, T> operator - (const pair<T, T> & a, const pair<T, T> & b) {
    return mp(a.fi - b.fi, a.se - b.se);
}

template <class T>
pair<T, T> operator + (const pair<T, T> & a, const pair<T, T> & b) {
    return mp(a.fi + b.fi, a.se + b.se);
}

template <class T, class U>
pair<T, T> operator / (const pair<T, T> & a, const U d) {
    return mp(a.fi / d, a.se / d);
}

template <class T, class U>
pair<T, T> operator * (const U d, const pair<T, T> & a) {
    return mp(a.fi * d, a.se * d);
}

///////////////////////////////////////////////////////////

// void SSE_CLEAR(const char * v, int size) {
//     auto zero = _mm_set1_epi8 (0);
//     for (int k = 0; k < size; k += 16) {
//         SSE_STORE(v[k], zero);
//     }
// }

// void SSE_CLEAR(const short * v, int size) {
//     auto zero = _mm_set1_epi16 (0);
//     for (int k = 0; k < size; k += 8) {
//         SSE_STORE(v[k], zero);
//     }
// }

// void SSE_CLEAR(const int * v, int size) {
//     auto zero = _mm_set1_epi32 (0);
//     for (int k = 0; k < size; k += 4) {
//         SSE_STORE(v[k], zero);
//     }
// }

// void SSE_COPY(const char * v, const char * to, int size) {
//     for (int i = 0; i < size; i += 16) {
//       __m128i m = SSE_LOAD(v[i]);
//       SSE_STORE(to[i], m);
//     }
// }

// void SSE_COPY(const short * v, const short * to, int size) {
//     for (int i = 0; i < size; i += 8) {
//       __m128i m = SSE_LOAD(v[i]);
//       SSE_STORE(to[i], m);
//     }
// }
////////////////////////////////////////////////////////////

template <typename T>
vector<T> join_vector(const vector<T> & left, const vector<T> & right) {
    if (!size(right)) return left;
    auto res = vector<T>(left);
    res.insert(res.end(), all(right));
    return res;
}

template <typename T>
void concat_vector(vector<T> & left, const vector<T> & right) {
  if (!size(right)) return;
    left.insert(left.end(), all(right));
}

template <typename T>
T sum_vector(vector<T> & v) {
    return accumulate(all(v), 0);
}

template <typename T>
T mean_vector(vector<T> & v) {
    return sum_vector(v) / size(v);
}

vi string_to_vector(const string & s) {
  vi res; for (auto c : s) res.pb(c); return res;
}

template <typename T>
vector<T> operator + (const vector<T>& left, const vector<T>& right) {
  return join_vector(left, right);
}

/////////////////////////////////////////////////////////////

mt19937 random_engine;

double nextDouble() {return 1.0 * (random_engine() % (1<<30) + 1) / ((1<<30)-1);}
int nextInt() {return random_engine();}
int nextInt(int range) {return random_engine() % range;}
int nextInt(int first, int last) {return random_engine() % (last - first + 1) + first;}

/////////////////////////////////////////////////////////////

struct RNG {
  unsigned int x = 123456789;
  unsigned int y = 362436069;
  unsigned int z = 521288629;
  
  unsigned int rand() {
    x ^= x << 16;
    x ^= x >> 5;
    x ^= x << 1;

    unsigned int t = x;
    x = y;
    y = z;
    z = t ^ x ^ y;

    return z;   
  }
    
  inline int nextInt(int x) {
    return rand() % x;
  }
    
  inline int nextInt(int a, int b) {
    return a + (rand() % (b - a + 1));
  }
    
  inline double nextDouble() {
    return (rand() + 0.5) * (1.0 / 4294967296.0);
  }

  void seed(int val) {
    random_engine.seed(val);
    x = nextInt((1<<30));
    y = nextInt((1<<30));
    z = nextInt((1<<30));
  }
};

static RNG rng;

template<typename T>
T ChooseRandom (const vector<T>& vec) {
  assert (size(vec));
  return vec[rng.nextInt(size(vec))];
}

template<typename T>
void FastShuffle(vector<T>& vec) {
    fod (i, size(vec) - 1, 0) {
        swap(vec[i], vec[rng.nextInt(0, i)]);
    }
}
////////////////////////////////////////////////////////////
double dist_l2 (const pii& A, const pii& B) {
  return hypot (1.0*A.fi - B.fi, 1.0 * A.se - B.se);
}

template<typename T>
pair<double, double> computeMeanVariance (const vector<T>& v) {
  pair<double, double> result;
  for (const auto& x : v) {
    result.fi += x;
  } 
  result.fi /= size(v);
  for (const auto& x : v) {
    result.se += sqr(x - result.fi);
  }
  result.se = sqrt(result.se / size(v));
  return result;
}

template<typename T>
double computePercentage (vector<T>& v, int index) {
  return 1.0 * v[index] / sum_vector(v);
}

template<typename T>
vector<double> computeAllPercentages (vector<T>& v) {
  vd result (size(v));
  auto S = sum_vector(v);
  re (i, size(v))
    result[i] = 1.0 * v[i] / S;
  return result;
}

///////////////////////////////////////////////////////////

#ifdef __APPLE__
#define HOME_COMPUTER
#define LOCAL
#endif

//#define LOCAL

#ifdef LOCAL
#define WARN
#define HIGHLIGHT
#define DEBUG
#define INFO
#endif

#ifdef DEBUG
#define debug(args...)            {dbg,args; cerr<<"\n"; cerr.flush();}
#define trace(args...) { vector<string> _v = debug_split(#args, ','); debug_err(_v.begin(), args); }
#define echo(arg) {cerr << #arg << ": "; dbg,arg; cerr << "\n"; cerr.flush();}
#else
#define debug(args...) {}
#define echo(arg) {}
#define trace(args...) {} 
#endif

#ifdef WARN
#define warn(args...)             {dbg,args; cerr<<"\n"; cerr.flush();}
#else
#define warn(args...)
#endif

#ifdef INFO
#define info(args...)             {cerr << blue; dbg,args; cerr<<def<<"\n"; cerr.flush();}  
#else
#define info(args...)
#endif

#ifdef HIGHLIGHT
#define highlight(args...)        {cerr << red; dbg,args; cerr<<def<<"\n"; cerr.flush();}
#else
#define highlight(args...)
#endif

#ifdef LOCAL
#define MAX_TIME 9.6
#define TIME_BUFFER 0.5
#else
// DON'T CHANGE
#define MAX_TIME 9.6
#define TIME_BUFFER 0.5
#endif

#define MAX_SAFE_TIME 4.0
#define EPS 1e-9

#define delta_type double
#define double_type double

//////////////////////////////////////////////
const double TIME_BUF = 9.0;
//////////////////////////////////////////////
//////////////////////////////////////////////
Timer solution_timer("solution");
//////////////////////////////////////////////
unordered_map<string, int64> Counter;
//////////////////////////////////////////////
const int RAD = 100;
const int RAD2 = 10000;
const int CIRCLE = 0;
const int RECT = 1;
const double AREA = 100 * 100 * M_PI;

int N, C, R;
double X;
double P;

double SUM;

vi aCircles;
vpii aRects;

struct Pos {
    int y;
    int x;
    bool OK() {return sqr(y) + sqr(x) <= RAD2;}
    Pos() {;}
    Pos(int _y, int _x) {y = _y, x = _x;}

    bool operator == (const Pos& other) const {
        return x == other.x && y == other.y;
    }
};

struct Shape {
    int id;
    int type;
    int r;
    int h;
    int w;
    int y;
    int x;

    void Place(Pos p) {
        y = p.y, x = p.x;
    }

    bool OK() {
        if (circle()) {
            return sqr(RAD - r) >= sqr(y) + sqr(x);
        } else {
            vector<Pos> corners = {Pos{y, x}, Pos{y + h, x}, Pos{y, x + w}, Pos{y + h, x + w}};
            for (auto p : corners) {
                if (!p.OK())
                    return false;
            }
            return true;
        }
    }

    double Area() const {
        if (circle()) {
            return M_PI * sqr(r);  
        } else {
            return h * w;
        }
    }

    double Bonus() const {
        if (circle()) {
            return 0.0;
        } else {
            return 0.0; //(25 - h) * 0.2;
        }
    }

    double Util() const {
        double area = Area();

        double fC = X;
        double fR = 1.0 - X;

        double malus = 0;
        // if (area >= 550)
        //     malus += 200;

        if (circle()) {
            return fC * (225 * 3.1415 - area);
        } else {
            // TODO: Factor in aspect ratio of rects
            double factor = 1.0 * min(h, w) / max(h, w); 
            factor = abs(1.0 - factor);

            //return (1 - X) * area - h;
            
            //return (1 - X) * area * 1.0;
            //return (1 - X) * area * (1.0 - abs(h - w) / max(h, w));
            return fR * (625 - area);
        };
        // return Area();
        return area;
    }

    bool circle() const {return type == CIRCLE;}
    bool rect() const {return type == RECT;}

    bool operator < (const Shape& other) const {
        double delta = Util() - other.Util();
    
        if (abs(delta) > EPS)
            return delta < -EPS;
        else
            return id < other.id;
    }

    void PutOcc(vvc& occ) {
        if (circle()) {
            fo (dy, -r, r) {
                fo (dx, -r, r) {
                    if (sqr(dy) + sqr(dx) >= sqr(r))
                        continue;

                    auto ny = y + dy;
                    auto nx = x + dx;

                    ny += RAD;
                    nx += RAD;

                    if (ny >= 0 && ny <= 2*RAD && nx >= 0 && nx <= 2 * RAD) {
                        occ[ny][nx] = true;   
                    }
                }
            } 
        } else {
            fo (dy, - 3, h - 1) {
                fo (dx, - 3, w - 1) {
                    auto ny = y + dy;
                    auto nx = x + dx;

                    ny += RAD;
                    nx += RAD;

                    if (ny >= 0 && ny <= 2 * RAD && nx >= 0 && nx <= 2 * RAD) {
                        occ[ny][nx] = true;   
                    }
                }
            }
        }
    }

    string Serialize() {
        SS ss;
        if (circle()) {
            ss << x << " " << y;
        } else {
            ss << x << " " << y;
        }
        return ss.str();
    }
};

// Can be better
bool IntersectCC(const Shape& s1, const Shape& s2) {
    assert(s1.circle());
    assert(s2.circle());

    return sqr(s1.r + s2.r) > sqr(s1.y-s2.y) + sqr(s1.x-s2.x);
}

// Fast
bool IntersectRR(const Shape& A, const Shape& B) {
    return A.x < B.x+B.w  && A.x+A.w > B.x &&
             A.y < B.y+B.h && A.y+A.h > B.y;
}

// Slowish
bool IntersectCR(const Shape& A, const Shape& B) {
    double x = abs(A.x - (B.x+B.w/2.0));
    double y = abs(A.y - (B.y+B.h/2.0));
    if (x+EPS > B.w/2.0 + A.r) return false;
    if (y+EPS > B.h/2.0 + A.r) return false;
    if (x+EPS < B.w/2.0) return true;
    if (y+EPS < B.h/2.0) return true;
    double cornerDist = sqr(x - B.w/2.0) + sqr(y - B.h/2.0);
    return (cornerDist+EPS < sqr(A.r));
}

bool Overlap(const Shape& s1, const Shape& s2) {
    if (s1.circle() && s2.circle()) {
        return IntersectCC(s1, s2);
    } else if (s1.rect() && s2.rect()) {
        return IntersectRR(s1, s2);
    } else {
        if (s1.circle()) {
            return IntersectCR(s1, s2);
        } else {
            return IntersectCR(s2, s1);
        }
    }
}

vector<Pos> pos;
vector<Shape> shapes;

Pos BAD = Pos {-RAD, -RAD};

Pos where_cr[16][26][26];
bool where_rcc[26][26][16][16];

// TODO: What to keep in state?
double IGNORE_BALANCE = 0.0;

struct State {
    double tot_area;
    double balance;
    double score;
    double CA;
    double RA;
    vector<Shape> S;

    vc used;

    State() {
        tot_area = 0;
        balance = 0;
        score = 0;
        CA = RA = 0;
        S.clear();
        used.assign(N, false);
    }

    void Add(int id, Pos p) {
        assert(!used[id]);
        used[id] = true;

        auto s = shapes[id];
        s.Place(p);
        S.pb(s);

        tot_area += s.Area();
        if (s.circle()) CA += s.Area();
        else RA += s.Area();
        balance = abs(X * CA - (1 - X) * RA);
        score = tot_area - balance;
    }

    bool CanFit(int id, Pos p) {
        auto ns = shapes[id];
        ns.Place(p);
        fod (i, size(S) - 1, 0) {
            if (Overlap(ns, S[i]))
                return false;
        }
        return true;
    }

    void Remove(int id) {
        bool found = false;
        re (i, size(S)) {
            if (S[i].id == id) {
                auto s = S[i];
                tot_area -= s.Area();
                if (s.circle()) CA -= s.Area();
                else RA -= s.Area();
                balance = abs(X * CA - (1 - X) * RA);
                score = tot_area - balance;
                S.erase(S.begin() + i);
                found = true;
                
                assert(used[id]);
                used[id] = false;

                break;
            }
        }
        assert(found);
    }

    double TryAdd(const Shape& s) {
        double nCA = CA;
        double nRA = RA;
        double nArea = tot_area;

        assert(abs(nArea - nCA - nRA) <= 1e-4);

        nArea += s.Area();
        
        if (s.circle()) nCA += s.Area();
        else nRA += s.Area();

        double nScore = nCA + nRA - abs(X * nCA - (1 - X) * nRA);         
        if (IGNORE_BALANCE == 1.0) {
            return nCA + nRA - (CA + RA);
        } else {
            return nScore - Score();
        }
    }

    void PutOcc(vvc& occ) {
        for (auto s : S) {
            s.PutOcc(occ);
        }
    }

    vs Serialize() {
        vs ret(N, "NA");
        for (auto s : S) {
            //warn("?", s.id, s.y, s.x);
            ret[s.id] = s.Serialize();
        }
        return ret;
    }

    double Score() const {
        return score;
    }

    bool operator > (const State& other) const {
        return Score() > other.Score();
    }
};
namespace Solver {
    Timer improve_timer("improve");
    Timer fill_timer("fill");
    Timer sort_timer("sort");
    Timer can_fit_timer("can_fit");
    Timer can_ok_timer("can_ok");

    double MAX_RA = 1e9;
    double MAX_CA = 1e9;

    State start;

    char cache[1000][200][200];

    void Init() {
        pos.clear();
        fo (y, -100, 100) {
            fo (x, -100, 100) {
                if (sqr(y) + sqr(x) <= RAD2) {
                    pos.emplace_back(y, x);
                }
            }
        }

        fo (r, 5, 15) {
            fo (h, 5, 25) {
                fo (w, 5, 25) {
                    where_cr[r][h][w] = BAD;

                    fo (dy, -r, r) {
                        fo (dx, -r, r) {
                            if (sqr(dy) + sqr(dx) <= sqr(r)) {

                                vector<Pos> corn = {
                                    Pos{dy, dx},
                                    Pos{dy, dx + w},
                                    Pos{dy + h, dx},
                                    Pos{dy + h, dx + w}
                                };

                                bool ok = true;
                                for (auto c : corn) {
                                    if (sqr(c.y) + sqr(c.x) > sqr(r)) {
                                        ok = false;
                                        break;
                                    }
                                }

                                if (ok) {
                                    where_cr[r][h][w] = Pos{dy, dx};
                                    goto END_SEARCH;
                                }

                            }
                        }
                    }

                    END_SEARCH:;
                }
            }
        }

        fo (h, 5, 25) {
            fo (w, 5, 25) {
                fo (r1, 5, 15) {
                    fo (r2, 5, 15) {
                        where_rcc[h][w][r1][r2] = false;
                        Pos c1 {r1, r1};
                        Pos c2 = {h - r2, w - r2};
                        int mdim = min(h, w);
                        if (mdim >= 2 * r1 && mdim >= 2 * r2 && sqr(r1 + r2) <= sqr(c1.y-c2.y) + sqr(c1.x-c2.x)) {
                            where_rcc[h][w][r1][r2] = true;
                        }
                    }
                }
            }
        }
    }

    State Sample() {
        State state;
        state.Add(0, Pos{0, 0});
        return state;
    }

    State Improve(State state) {
        //improve_timer.start();
        //warn("Start improve:", state.Score());
        while (true) {
            if (solution_timer.elapsed() >= TIME_BUF) {
                //improve_timer.stop();
                warn("improve bail!");
                return state;
            }
            bool found = false;
            
            Shape cs;
            Shape rs;
            Shape cs2;
            bool rem_circle = false;
            bool both = false;
            double bst = 0;

            if (state.CA * X < (1 - X) * state.RA) {
                for (auto s : state.S) if (s.rect()) {
                    int mdim = min(s.h, s.w);    

                    re (i, N) if (!state.used[i] && shapes[i].circle()) {
                        assert(shapes[i].id == i);
                        auto ns = shapes[i];
                        if (2 * ns.r <= mdim) {
                            double nCA = state.CA;
                            double nRA = state.RA;
                            double nArea = 0;

                            nRA -= s.Area();
                            nCA += ns.Area();
                            nArea = nCA + nRA;

                            double nScore = nCA + nRA - abs(X * nCA - (1 - X) * nRA);         
                            double delta = nScore - state.Score();
                            if (delta > bst) {
                                rem_circle = true;
                                bst = delta;
                                rs = s;
                                cs = ns;
                                both = false;
                            }

                            re (j, N) if (j != i && !state.used[j] && shapes[j].circle()) {
                                if (where_rcc[s.h][s.w][shapes[i].r][shapes[j].r]) {
                                    auto ns2 = shapes[j];

                                    nCA = state.CA;
                                    nRA = state.RA;
                                   
                                    nRA -= s.Area();
                                    nCA += ns.Area();
                                    nCA += ns2.Area();

                                    nArea = nCA + nRA;
                                
                                    double nScore = nCA + nRA - abs(X * nCA - (1 - X) * nRA);         
                                    double delta = nScore - state.Score();
                                
                                    if (delta > bst) {
                                        rem_circle = true;
                                        bst = delta;
                                        rs = s;
                                        cs = ns;
                                        cs2 = ns2;
                                        both = true;
                                    }
                                }
                            }
                        }
                    }
                }
            }
            // } else if (true) {
                for (auto s : state.S) if (s.circle()) {
                    //int mdim = min(s.h, s.w);    

                    re (i, N) if (!state.used[i]) {
                        assert(shapes[i].id == i);
                        auto ns = shapes[i];
                        
                        if (ns.rect() ) {
                            double nCA = state.CA;
                            double nRA = state.RA;
                            double nArea = state.tot_area;

                            nArea -= s.Area();
                            nArea += ns.Area();

                            nCA -= s.Area();
                            nRA += ns.Area();
                        
                            double nScore = nCA + nRA - abs(X * nCA - (1 - X) * nRA);         
                            double delta = nScore - state.Score();
                            if (delta > bst) {
                                // Check if can do Rect

                                auto nstate = state;

                                nstate.Remove(s.id);

                                fo (dy, -s.r - 10, 0) {
                                    fo (dx, -s.r - 10, 0) {
                                        auto np = Pos {s.y + dy, s.x + dx};

                                        if (np.OK()) {
                                            ns.Place(np);
                                            if (ns.OK() && nstate.CanFit(ns.id, np)) {
                                                bst = delta;
                                                cs = s;
                                                rs = ns;
                                                rem_circle = false;
                                                assert(rs.OK());

                                                goto FOUND_RECT;
                                            }
                                        }
                                    }
                                }
                                FOUND_RECT:;
                               
                            }
                        }

                        // if (ns.rect() && where_cr[s.r][ns.h][ns.w].y != -RAD) {
                        //     double nCA = state.CA;
                        //     double nRA = state.RA;
                        //     double nArea = state.tot_area;

                        //     nArea -= s.Area();
                        //     nArea += ns.Area();

                        //     nCA -= s.Area();
                        //     nRA += ns.Area();
                        
                        //     double nScore = nCA + nRA - abs(X * nCA - (1 - X) * nRA);         
                        //     double delta = nScore - state.Score();
                        //     if (delta > bst) {
                        //         bst = delta;
                        //         cs = s;
                        //         rs = ns;
                        //     }
                        // }
                    }
                }

                if (rem_circle) {
                    if (bst > 0) {
                        if (!both) {
                            //warn("improve circle:", bst);
                            state.Remove(rs.id);
                            auto p = Pos {rs.y + cs.r, rs.x + cs.r};
                            state.Add(cs.id, p);
                        } else {
                            //warn("improve both circle:", bst);
                            state.Remove(rs.id);
                            auto p1 = Pos {rs.y + cs.r, rs.x + cs.r};
                            state.Add(cs.id, p1);
                            auto p2 = Pos {rs.y + rs.h - cs2.r, rs.x + rs.w - cs2.r};
                            state.Add(cs2.id, p2);
                        } 
                        found = true;
                        //goto END_SEARCH;
                    }
                } else {
                    if (bst > 0) {   
                        //warn("improve rect:", bst);
                        
                        state.Remove(cs.id);
                        
                        //auto d = where_cr[cs.r][rs.h][rs.w];
                        //auto p = Pos {cs.y + d.y, cs.x + d.x};
                        
                        auto p = Pos {rs.y, rs.x};

                        state.Add(rs.id, p);    
                        found = true;
                        //goto END_SEARCH;
                    }
                }
            // }


            END_SEARCH:;
            if (!found) {
                // Try to grow
                bool can_grow = false;
                
                for (auto s : state.S) {
                    if (s.circle()) {
                        vc bad(N);
                        auto nstate = state;
                        nstate.Remove(s.id);
                        re (k, N) if (!state.used[k] && shapes[k].circle() && shapes[k].r > s.r && !bad[shapes[k].r]) {
                            bool can = false;
                            fo (dy, -2, 2) {
                                fo (dx, -2, 2) {
                                    Pos p = {s.y + dy, s.x + dx};

                                    if (p.OK()) {
                                        auto ns = shapes[k];
                                        ns.Place(p);
                                        if (ns.OK() && nstate.CanFit(ns.id, p)) {
                                            nstate.Add(ns.id, p);
                                            state = nstate;
                                            can = true;
                                            can_grow = true;
                                            warn("+1");
                                            goto GOOD_SEARCH;
                                        }
                                    }
                                }
                            }
                            if (!can) {
                                bad[shapes[k].r] = true;
                            }
                        }

                        
                    }
                }
                GOOD_SEARCH:;

                for (auto s : state.S) {
                    if (s.rect()) {
                        vc bad(N);
                        auto nstate = state;
                        nstate.Remove(s.id);
                        re (k, N) if (!state.used[k] && shapes[k].rect() && shapes[k].Area() > s.Area()) {
                            bool can = false;
                            Pos p = {s.y, s.x};

                            if (p.OK()) {
                                auto ns = shapes[k];
                                ns.Place(p);
                                if (ns.OK() && nstate.CanFit(ns.id, p)) {
                                    nstate.Add(ns.id, p);
                                    state = nstate;
                                    can_grow = true;
                                    warn("+1 rect");
                                    goto GOOD_SEARCH2;
                                }
                            }
                        }

                        
                    }
                }

                GOOD_SEARCH2:;

                if (!can_grow)
                    break;
            }
        }
        //improve_timer.stop();
        return state;
    }

    State SA(State state) {
        State bst_state = state;
        auto occ = vvc (2*RAD+1, vc(2*RAD+1, false));

        auto S = shapes;
        sort(all(S));
        reverse(all(S));

        re (tries, 10) {
            if (solution_timer.elapsed() >= TIME_BUF)
                return bst_state;
            int idx1 = rng.nextInt(size(state.S));

            auto nstate = state;
            auto rem = state.S[idx1];
            nstate.Remove(rem.id);

            Pos c1 = Pos {rem.y, rem.x};
            if (rem.circle()) {
                c1.y -= rem.r, c1.x -= rem.r;
            }


            auto cS = S;

            sort(all(cS), [&] (const Shape& s1, const Shape& s2) {
                double v1 = nstate.TryAdd(s1) + state.Score() + s1.Bonus();
                double v2 = nstate.TryAdd(s2) + state.Score() + s2.Bonus();
                return v1  > v2;
                //return state.TryAdd(s1) > state.TryAdd(s2);
            });

            int tried = 0;

            for (auto s : cS) if (s.id != rem.id && !nstate.used[s.id]) {
                const int B = 3;
                fo (dy, -B, B) {
                    fo (dx, -B, B) {
                        Pos c2 = {c1.y + dy, c1.x + dx};
                        if (c2.OK()) {
                            auto ns = s;
                            ns.Place(c2);
                            if (ns.OK() && nstate.CanFit(ns.id, c2)) {
                                if (nstate.Score() + nstate.TryAdd(ns) - state.Score() > 50) {
                                    double delta = nstate.Score() + nstate.TryAdd(ns) - state.Score();
                                    //warn(nstate.TryAdd(ns));
                                    nstate.Add(ns.id, c2);
                                    
                                    warn(tries, "=>", delta);
                                    state = nstate;
                                    bst_state = state;
                                    goto END_SEARCH;
                                }
                            }
                        }
                    }
                }
                // tried++;
                // if (tried >= 10)
                //     break;
            }
            END_SEARCH:;
        }

        return bst_state;
    }

    State Greedy(double buf, int niter) {
        auto S = shapes;
        sort(all(S));
        reverse(all(S));

        // bool funny = false;

        // if (niter >= 5 && !rng.nextInt(3)) {
        //     S = start.S;
        //     funny = true;
        // }

        memset(cache, 0, sizeof(cache));

        double CA = 0;
        double RA = 0;

        vc used(N);

        State state;

        bool last_chance = false;

        auto occ = vvc (2*RAD+1, vc(2*RAD+1, false));

        auto rpos = pos;
        auto cpos = pos;

        int coin = rng.nextInt(2);
        int coin2 = rng.nextInt(2);

        Pos dir = {rng.nextInt(10), rng.nextInt(10)};

        if (coin) {
            int edge = rng.nextInt(0, 2);
            sort (all(rpos), [&](const Pos & _p1, const Pos& _p2) {
                Pos p1 = {_p1.y + edge, _p1.x + edge};
                Pos p2 = {_p2.y + edge, _p2.x + edge};

                int d1 = sqr(p1.y) + sqr(p1.x);
                int d2 = sqr(p2.y) + sqr(p2.x);

                if (d1 != d2) {
                    if (coin2)
                        return d1 > d2;
                    else
                        return d1 < d2;
                } else if (p1.y != p2.y) {
                    return p1.y < p2.y;
                } else {
                    return p1.x < p2.x;
                }

            });
        } else {
            sort (all(rpos), [&](const Pos & p1, const Pos& p2) {
                int v1 = p1.y * dir.y + p1.x * dir.x;
                int v2 = p2.y * dir.y + p2.x * dir.x;

                if (v1 != v2) return v1 < v2;
                //if (p1.y != p2.y) return p1.y > p2.y;
                else {
                    if (niter & 1)
                        return p1.x < p2.x;
                    else
                        return p1.x > p2.x;
                }

            });
        }

        sort(all(cpos), [&] (const Pos &p1, const Pos& p2) {
            if (!coin) {
                int v1 = p1.y * dir.y + p1.x * dir.x;
                int v2 = p2.y * dir.y + p2.x * dir.x;


                if (v1 != v2) return v1 > v2;
                // if (p1.y != p2.y) return p1.y > p2.y;
                else {
                    if (niter & 1)
                        return p1.x < p2.x;
                    else
                        return p1.x > p2.x;
                }
            }
        
            int d1 = sqr(p1.y) + sqr(p1.x);
            int d2 = sqr(p2.y) + sqr(p2.x);

            if (d1 != d2) {
                if (coin2)
                    return d1 < d2;
                else
                    return d1 > d2;
            } else if (p1.y != p2.y) {
                return p1.y > p2.y;
            } else {
                return p1.x < p2.x;
            }
        });

        // cpos = rpos;

        int type = X > 0.5;

        int skip = ceil(abs(X - 0.5) / 0.1);

        double estimate = 26000 + niter * 500;

        double shouldCA = estimate / (1.0 + X / (1 - X));
        double shouldRA = X / (1 - X) * shouldCA;

        vc cant(N, false);
        vd fudge(N);

        re (i, N) {
            fudge[i] = rng.nextDouble() * (10);
            if (niter <= 1)
                fudge[i] = 0;
        }

        // if (niter >= 2) {
        //     FastShuffle(rpos);
        //     FastShuffle(cpos);
        // }

        //if (niter >= 50) {
        if (solution_timer.elapsed() >= 0.25 * TIME_BUF) {
            state = start;

            int remove = min(size(state.S), rng.nextInt(5, 10));

            re (tries, remove) {
                int rid = rng.nextInt(size(state.S));
                // cant[state.S[rid].id] = true;
                state.Remove(state.S[rid].id);
            }

            // re (tries, remove) {
            //     int rid = state.S.back().id;
            //     state.Remove(state.S[rid].id);
            // }
        }

        state.PutOcc(occ);

        re (iter, N + 1) {
            if (solution_timer.elapsed() >= TIME_BUF)
                return state;

            bool found = false;

            auto cS = S;

            // if (iter <= 10) IGNORE_BALANCE = 1;
            // else IGNORE_BALANCE = 0;

            vd fitness(N);

            // if (size(state.S) < skip) {
            //     IGNORE_BALANCE = 1.0;
            // } else {
            //     IGNORE_BALANCE = 0.0;
            // }

            

            // IGNORE_BALANCE = 0.0;
            sort_timer.start();
            re (i, N) {
                fitness[i] = fudge[i] + state.TryAdd(shapes[i]) + state.Score() + shapes[i].Bonus();
            }
            sort(all(cS), [&] (const Shape& s1, const Shape& s2) {
                // double v1 = state.TryAdd(s1) + state.Score() + s1.Bonus();
                // double v2 = state.TryAdd(s2) + state.Score() + s2.Bonus();
                // return v1 + fudge[s1.id] > v2 + fudge[s2.id];
                return fitness[s1.id] > fitness[s2.id];
                //return state.TryAdd(s1) > state.TryAdd(s2);
            });
            sort_timer.stop();


            for (auto s : cS) if (!state.used[s.id] && !cant[s.id]) {
                auto Skip = [&] () {
                    // if (niter >= 4) {
                    //     if (s.circle() && state.CA + s.Area() >= start.CA + 50)
                    //         return true;
                    //     else if (s.rect() && state.RA + s.Area() >= start.RA + 50)
                    //         return true;
                    // }

                    if (size(state.S) < skip) {
                    // if (!size(state.S)) {
                        if (s.circle() && type) return true;
                        else if (s.rect() && !type) return true;
                        return false;
                    } else {
                        return false;
                    }
                };

                if (Skip() && !last_chance)
                    continue;

                vector<Pos> upos = cpos;
                if (s.circle()) {
                    upos = cpos;
                } else {
                    upos = rpos;
                }

                bool can_ok = false;
                for (auto p : upos) {

                    if (occ[p.y + RAD][p.x + RAD] || cache[s.id][p.y + RAD][p.x + RAD])
                        continue;

                    auto ns = s;
                    ns.Place(p);

                    if (!ns.OK())
                        continue;
                    //can_fit_timer.start();
                    if (state.CanFit(ns.id, p)) {
                        state.Add(ns.id, p);
                        used[ns.id] = true;
                        if (ns.circle()) CA += ns.Area();
                        else RA += ns.Area();
                        found = true;
                        can_ok = true;
                        ns.PutOcc(occ);
                        //can_fit_timer.stop();
                        goto END_SEARCH;
                    } else {
                        cache[s.id][p.y + RAD][p.x + RAD] = 1;
                    }
                    //can_fit_timer.stop();
                }

                can_ok_timer.start();
                if (!can_ok) {
                    cant[s.id] = true;
                    // if (ns.circle())
                    //     seenC[ns.r] = true;
                    re (k, N) if (!state.used[k] && !cant[k]) {
                        auto bs = shapes[k];
                        if (s.circle()) {
                            if (bs.circle() && bs.r >= s.r) {
                                cant[k] = true;
                            } else if (bs.rect() && min(bs.h, bs.w) >= 2 * s.r) {
                                cant[k] = true;
                            }
                        } else {
                            if (bs.rect() && bs.h >= s.h && bs.w >= s.w) {
                                cant[k] = true;
                            } else if (bs.circle() && where_cr[bs.r][s.h][s.w].y != -RAD) {
                                cant[k] = true;
                            }
                        }
                    }
                }
                can_ok_timer.stop();
                // END_SEARCH:;
            }
            END_SEARCH:;
            if (!found) {
                if (last_chance)
                    break;
                last_chance = true;
            }

            if (iter % 100 == 0) {
                vector<Pos> tmp;
                for (auto p : cpos) if (!occ[p.y + RAD][p.x + RAD]) {
                    tmp.pb(p);
                }
                cpos = tmp;
                tmp.clear();
                for (auto p : rpos) if (!occ[p.y + RAD][p.x + RAD]) {
                    tmp.pb(p);
                }
                rpos = tmp;
            }
        }

        IGNORE_BALANCE = 0;

        // return state;

        double sCA = X * state.CA;
        double sRA = (1 - X) * state.RA;

        if (sCA > sRA + 50) {
            MAX_CA = CA - 200;
            MAX_RA = 1e9;
        } else if (sRA > sCA + 50) {
            MAX_RA = RA - 200;
            MAX_CA = 1e9;
        } else {
            MAX_CA = MAX_RA = 1e9;
        }

        improve_timer.start();
        state = Improve(state);
        improve_timer.stop();

        //warn("=>", state.Score(), "/", state.balance);
        return state;
    }

    State Fill(State state) {
        auto S = shapes;
        sort(all(S));
        reverse(all(S));

        auto occ = vvc(2*RAD+1, vc(2*RAD+1, false));
        fill_timer.start();
        state.PutOcc(occ);

        re (iter, N) {
            auto cS = S;
            sort(all(cS), [&] (const Shape& s1, const Shape& s2) {
                double v1 = state.TryAdd(s1) + state.Score();
                double v2 = state.TryAdd(s2) + state.Score();
                return v1 > v2;
                //return state.TryAdd(s1) > state.TryAdd(s2);
            });
            bool found = false;
            for (auto s : cS) if (!state.used[s.id]) {
                if (solution_timer.elapsed() >= TIME_BUF)
                    break;
                for (auto p : pos) if (!occ[p.y+RAD][p.x+RAD]) {
                    auto ns = s;
                    ns.Place(p);
                    if (ns.OK() && state.CanFit(ns.id, p)) {
                        double pScore = state.Score();
                        state.Add(ns.id, p);
                        ns.PutOcc(occ);
                        warn("Fill:", state.Score() - pScore);
                        found = true;
                        goto END_ADD;
                    }
                }
            }
            END_ADD:;
            if (!found) break;
        }
       
        fill_timer.stop();

        return state;
    }

    State SolveAll() {
        State bst_state;
        double buf = 1.0;
        int iter = 0;
        while (solution_timer.elapsed() < TIME_BUF - 1.0) {
            auto state = Greedy(buf, iter);            
            if (state > bst_state) {
                bst_state = state;
                warn(iter, "+", bst_state.Score(), "/", bst_state.balance);

                start = bst_state;
            }
            //break;
            buf += 0.05;
            iter++;
        }

        highlight("#iter=", iter);
        // bst_state = Fill(bst_state);

        #ifdef LOCAL
        improve_timer.check();
        fill_timer.check();
        sort_timer.check();
        can_fit_timer.check();
        can_ok_timer.check();
        #endif

        return bst_state;
    }
}
//////////////////////////////////////////////
class TastyPizza {
public:
    void Log() {
        ofstream fout("logXXX.aux", ofstream::out | ofstream::app);
        fout << N << " " << C << " " << R << " " << X << "\n";
        fout.close();
        exit(0);
    }

    void Info() {
        highlight("N:", N, "C:", C, "R:", R, "X:", X);
    }

    vector<string> findSolution(int _C, int _R, double _X, vector<int> &_aCircles, vector<pair<int, int> > &_aRects) {
        solution_timer.start();
        random_engine.seed(0);
        rng.seed(0);           

        

        C = _C;
        R = _R;
        N = C + R;
        X = _X;

        //Log();

        SUM = 0;

        aCircles = _aCircles;
        aRects = _aRects;

        shapes.clear();
        re (i, C) {
            shapes.push_back(Shape{i, CIRCLE, aCircles[i], 0, 0});
        }

        re (i, R) {
            shapes.push_back(Shape{i + C, RECT, 0, aRects[i].se, aRects[i].fi});
        }

        Info();
        Solver::Init();

        warn("Init done!");

        State bst_state;
        vs final_ret;

        //bst_state = Solver::Greedy();
        //final_ret = bst_state.Serialize();

        bst_state = Solver::SolveAll();
        final_ret = bst_state.Serialize();
        solution_timer.stop();
        return final_ret;
    } 
};

////////////////////////
#define PERSONAL

template<class T> void getVector(vector<T>& v) {
    for (int i = 0; i < v.size(); ++i)
        cin >> v[i];
}

void RunTester() {
    std::ios::sync_with_stdio(false);
    cin.tie(0);
    
    TastyPizza prog;
    int R, C;
    double X;
    cin >> C >> R >> X;
    vector< pair<int, int> > aRect(R);
    vector<int> aCircles(C);
    for (int i=0;i<C;i++)
    {
    cin >> aCircles[i];
    }
    for (int i=0;i<R;i++)
    {
    cin >> aRect[i].first >> aRect[i].second;
    }
    vector<string> ret = prog.findSolution(C, R, X, aCircles, aRect);
    cout << ret.size() << endl;
    for (int i = 0; i < (int)ret.size(); ++i)
      cout << ret[i] << endl;
    cout.flush();
}

int main(int argc, char ** argv) {
    if (argc == 1) {
        RunTester();
    } else {
        assert(false);
    }
    return 0;
}