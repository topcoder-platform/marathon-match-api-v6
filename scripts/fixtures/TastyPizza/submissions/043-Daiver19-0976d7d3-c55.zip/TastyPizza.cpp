//#define SUBMISSION

#ifdef SUBMISSION
#define CHECKER_TEST
#endif
#define CHECKER_TEST
//#define RUN_ITER

#include <stdarg.h>

#include <algorithm>
#include <bitset>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <iostream>
#include <list>
#include <map>
#include <memory>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <vector>
#ifdef WIN32
#include "windows.h"
#endif

using namespace std;

void dbg(const char* fmt, ...) {
#ifndef SUBMISSION
  va_list args;
  va_start(args, fmt);
  vfprintf(stderr, fmt, args);
  va_end(args);
  fflush(stderr);
#endif
}

#ifdef max
#undef max
#endif

#ifdef min
#undef min
#endif

#define mp make_pair
#define sqr(a) ((a) * (a))

#define BIT(n, k) (((n) >> (k)) & 1)

#ifdef LOCAL_TEST
#define ASSERT(cond)              \
  if (!(cond)) {                  \
    dbg("assert %d\n", __LINE__); \
    throw 1;                      \
  }
#else
#define ASSERT(cond)
#endif

typedef pair<int, int> pi;
typedef pair<double, double> pd;
typedef unsigned long long ull;
typedef vector<int> vi;
typedef vector<vi> vvi;
typedef vector<string> vs;
typedef vector<char> vc;
typedef vector<double> vd;
typedef vector<vd> vvd;

typedef unsigned char u8;
typedef unsigned short u16;
typedef unsigned int u32;
typedef unsigned long long u64;

typedef long long i64;

#ifndef WIN32
double GetTickCountMy() {
  u64 timelo, timehi;
  __asm__ volatile("rdtsc" : "=a"(timelo), "=d"(timehi));
  return ((timehi << 32) + timelo) / 2.8e9;
}
#else
double GetTickCountMy() { return GetTickCount() / 1000.; }
#endif

double rnd() { return (double)rand() / RAND_MAX; }

#ifndef LOCAL_TEST
const double TimeLimit = 9.8;
#else
#ifndef RUN_ITER
const double TimeLimit = 7.7;
#else
const double TimeLimit = 10.8;
#endif
#endif

const double EPS = 1e-9;
const int BaseRadius = 100;
const int Size = 200;
const double PI = 2 * acos(0.0);

struct Point {
  Point() : x(0), y(0) {}

  Point(int x, int y) : x(x), y(y) {}

  Point& operator+=(const Point& other) {
    x += other.x;
    y += other.y;
    return *this;
  }

  bool operator!=(const Point& other) const {
    return x != other.x || y != other.y;
  }

  bool operator==(const Point& other) const {
    return x == other.x && y == other.y;
  }

  int x, y;
};

Point operator+(const Point& a, const Point& b) {
  Point res = a;
  res += b;
  return res;
}

int distSq(const Point& a, const Point& b) {
  return sqr(a.x - b.x) + sqr(a.y - b.y);
}

struct Rect {
  Rect() = default;
  Rect(int h, int w) : height(h), width(w) {}
  int height;
  int width;
  int area;
  Point origin;
  int id = -1;
  bool used = false;
};

struct Circle {
  Circle() = default;
  Circle(int r) : r(r) {}
  Point origin;
  double area;
  int r = -1;
  int id = -1;
  bool used = false;

  bool isInside(int x, int y) const {
    return sqr(origin.x - x) + sqr(origin.y - y) <= sqr(r);
  }

  bool isInside(const Circle& a) const {
    return distSq(a.origin, origin) <= sqr(r - a.r);
  }

  bool isInside(const Point& p) const { return distSq(origin, p) <= sqr(r); }

  bool isInside(const Rect& r) const {
    return isInside(r.origin) && isInside(r.origin.x, r.origin.y + r.height) &&
           isInside(r.origin.x + r.width, r.origin.y) &&
           isInside(r.origin.x + r.width, r.origin.y + r.height);
  }

  bool touchInside(const Circle& a) const {
    return r - sqrt(distSq(origin, a.origin)) - a.r < 1;
  }

  bool touchInside(int x, int y) const {
    return sqr(r) - distSq(origin, Point(x, y)) <= 1;
  }

  bool touchInside(const Rect& r) const {
    return touchInside(r.origin.x, r.origin.y) ||
           touchInside(r.origin.x, r.origin.y + r.height) ||
           touchInside(r.origin.x + r.width, r.origin.y) ||
           touchInside(r.origin.x + r.width, r.origin.y + r.height);
  }
};

bool overlap(const Circle& a, const Circle& b) {
  return distSq(a.origin, b.origin) < sqr(a.r + b.r);
}

bool touch(const Circle& a, const Circle& b) {
  return sqrt(distSq(a.origin, b.origin)) - a.r - b.r < 1;
}

bool between(int from, int to, int v) { return from <= v && v <= to; }

bool touch(const Rect& a, const Rect& b) {
  return ((a.origin.x == b.origin.x + b.width ||
           b.origin.x == a.origin.x + a.width) &&
          (between(a.origin.y, a.origin.y + a.height, b.origin.y) ||
           between(b.origin.y, b.origin.y + b.height, a.origin.y))) ||
         ((a.origin.y == b.origin.y + b.height ||
           b.origin.y == a.origin.y + a.height) &&
          (between(a.origin.x, a.origin.x + a.width, b.origin.x) ||
           between(b.origin.x, b.origin.x + b.width, a.origin.x)));
}

bool touch(const Circle& a, const Rect& b) {
  return ((a.origin.x - a.r == b.origin.x + b.width ||
           b.origin.x == a.origin.x + a.r) &&
          between(b.origin.y, b.origin.y + b.height, a.origin.y)) ||
         ((a.origin.y - a.r == b.origin.y + b.height ||
           b.origin.y == a.origin.y + a.r) &&
          between(b.origin.x, b.origin.x + b.width, a.origin.x));
}

// rectangle-rectangle overlap
bool overlap(const Rect& a, const Rect& b) {
  return a.origin.x < b.origin.x + b.width &&
         a.origin.x + a.width > b.origin.x &&
         a.origin.y < b.origin.y + b.height &&
         a.origin.y + a.height > b.origin.y;
}

bool overlap(const Circle& a, const Rect& b) {
  double x = abs(a.origin.x - (b.origin.x + b.width * 0.5));
  double y = abs(a.origin.y - (b.origin.y + b.height * 0.5));
  if (x + EPS > b.width * 0.5 + a.r) return false;
  if (y + EPS > b.height * 0.5 + a.r) return false;
  if (x + EPS < b.width * 0.5) return true;
  if (y + EPS < b.height * 0.5) return true;
  double cornerDist = sqr(x - b.width * 0.5) + sqr(y - b.height * 0.5);
  return cornerDist + EPS < sqr(a.r);
}

class RandomSelector {
 public:
  void init(int size) {
    cell_index_.resize(size * size + 1);
    for (int i = 0; i < size; ++i) {
      for (int j = 0; j < size; ++j) {
        int cell = i * size + j;
        cells_.push_back(cell);
        cell_index_[cell] = cells_.size() - 1;
      }
    }
    alive_count_ = select_count_ = cells_.size();
    size_ = size;
  }

  void reset() { alive_count_ = select_count_ = cells_.size(); }

  void resetToAlive() { select_count_ = alive_count_; }

  Point selectPos() {
    int cell_index = rand() % select_count_;
    int cell = cells_[cell_index];
    swapCells(cell_index, select_count_ - 1);
    --select_count_;
    return Point(cell % size_, cell / size_);
  }

  bool hasChoices() const { return select_count_ != 0; }

  void addPos(int x, int y) {
    int cell = y * size_ + x;
    int cell_index = cell_index_[cell];
    if (cell_index < alive_count_) {
      return;
    }
    swapCells(cell_index, alive_count_);
    ++alive_count_;
    select_count_ = alive_count_;
  }

  void erasePos(int x, int y) {
    int cell = y * size_ + x;
    int cell_index = cell_index_[cell];
    if (cell_index >= alive_count_) {
      return;
    }
    swapCells(cell_index, alive_count_ - 1);
    --alive_count_;
    select_count_ = alive_count_;
  }

  void erasePos(const Point& cell_point) {
    erasePos(cell_point.x, cell_point.y);
  }

 private:
  void swapCells(int id1, int id2) {
    int c1 = cells_[id1];
    int c2 = cells_[id2];
    swap(cells_[id1], cells_[id2]);
    cell_index_[c1] = id2;
    cell_index_[c2] = id1;
  }

  int size_;
  int alive_count_;
  int select_count_;
  vi cells_;
  vi cell_index_;
};

const int MoveWeight = 80;
const int MoveDist = 5;

class TastyPizza {
 public:
  pair<vector<Point>, vector<Point>> findSolution(const vi& circles,
                                                  const vector<pi>& rects,
                                                  double circle_weight) {
    start_time_ = GetTickCountMy();
    circle_cnt_ = circles.size();
    rect_cnt_ = rects.size();

    base_circle_ = Circle(BaseRadius);
    base_circle_.origin = Point(BaseRadius, BaseRadius);

    circle_weight_ = circle_weight;

    for (int i = 0; i < circle_cnt_; ++i) {
      circles_.emplace_back(circles[i]);
      circles_.back().id = i;
      circles_.back().area = PI * sqr(circles_.back().r);
    }
    for (int i = 0; i < rect_cnt_; ++i) {
      rects_.emplace_back(rects[i].second, rects[i].first);
      rects_.back().id = i;
      rects_.back().area = rects_.back().height * rects_.back().width;
    }

    sort(circles_.begin(), circles_.end(),
         [](const Circle& a, const Circle& b) { return a.r > b.r; });
    sort(rects_.begin(), rects_.end(), [](const Rect& a, const Rect& b) {
      return a.area > b.area ||
             (a.area == b.area &&
              abs(a.height - a.width) < abs(b.height - b.width));
    });

    double total_area = PI * sqr(base_circle_.r);
    double circle_area_fraction =
        total_area / (1 + circle_weight / (1 - circle_weight));
    double rect_area_fraction = total_area - circle_area_fraction;
    int circle_area_cnt = 0;
    double circle_area_sum = 0;
    while (circle_area_cnt < circle_cnt_ &&
           circle_area_sum < circle_area_fraction) {
      circle_area_sum += circles_[circle_area_cnt].area;
      ++circle_area_cnt;
    }
    circle_area_cnt = max(1, circle_area_cnt);

    int rect_area_cnt = 0;
    double rect_area_sum = 0;
    while (rect_area_cnt < rect_cnt_ && rect_area_sum < rect_area_fraction) {
      rect_area_sum += rects_[rect_area_cnt].area;
      ++rect_area_cnt;
    }
    rect_area_cnt = max(1, rect_area_cnt);

    circle_choice_weight_ = circle_area_cnt;
    rect_choice_weight_ = rect_area_cnt;

    dbg("Area ratio %d/%d\n", circle_choice_weight_, rect_choice_weight_);

    selector_.init(Size + 1);
    // computePos();
    vector<Circle> best_circles = circles_;
    vector<Rect> best_rects = rects_;
    double best_score = 0;
    double circle_area, rect_area;
    double iter_start_time = GetTickCountMy();
    randomSol(best_circles, best_rects, best_score, circle_area_fraction,
              rect_area);
    double iter_time = GetTickCountMy() - iter_start_time;
    int iter = 0;
    while (GetTickCountMy() - start_time_ + 1.2 * iter_time < TimeLimit) {
      vector<Circle> curr_circles = circles_;
      vector<Rect> curr_rects = rects_;
      double curr_score = 0;
      randomSol(curr_circles, curr_rects, curr_score, circle_area_fraction,
                rect_area);
      if (curr_score > best_score) {
        best_score = curr_score;
        best_circles.swap(curr_circles);
        best_rects.swap(curr_rects);
        dbg("%d: Update %.5lf\n", iter, best_score);
      }
      ++iter;
    }
    dbg("Total iter %d, score %lf\n", iter, best_score);
    return convertRes(best_circles, best_rects);
  }

 private:
  void randomSol(vector<Circle>& circles, vector<Rect>& rects, double& score,
                 double& circle_area, double& rect_area) {
    double CircleRelax = 1 + rnd() * 0.5;
    selector_.reset();
    for (int x = 0; x <= Size; ++x) {
      for (int y = 0; y <= Size; ++y) {
        if (!base_circle_.isInside(x, y)) {
          selector_.erasePos(x, y);
        }
      }
    }
    int tot_weight = circle_choice_weight_ + rect_choice_weight_;

    int circle_id = 0;
    int rect_id = 0;
    circle_area = 0;
    rect_area = 0;
    while (circle_id < circle_cnt_ || rect_id < rect_cnt_) {
      if (circle_id < circle_cnt_ &&
          (rect_id == rect_cnt_ ||
           circle_area * circle_weight_ <
               CircleRelax * rect_area * (1 - circle_weight_))) {
        findPos(circles[circle_id], circle_area, circles, rects, circle_id,
                rect_id);
        ++circle_id;
      } else {
        findPos(rects[rect_id], rect_area, circles, rects, circle_id, rect_id);
        ++rect_id;
      }
    }
    circle_id = rect_id = 0;
    while (circle_id < circle_cnt_ || rect_id < rect_cnt_) {
      if (circle_id < circle_cnt_ &&
          (rect_id == rect_cnt_ ||
           circle_area * circle_weight_ <=
               CircleRelax * rect_area * (1 - circle_weight_))) {
        if (!circles[circle_id].used) {
          findPos(circles[circle_id], circle_area, circles, rects, circle_cnt_,
                  rect_cnt_, true);
        }
        ++circle_id;
      } else {
        if (!rects[rect_id].used) {
          findPos(rects[rect_id], rect_area, circles, rects, circle_cnt_,
                  rect_cnt_, true);
        }
        ++rect_id;
      }
    }
    score = getScore(circle_area, rect_area);

    // int c_used = 0, r_used = 0;
    // for (auto& c : circles) {
    //  c_used += c.used;
    //   if (!c.used) {
    //     for (int x = 0; x <= Size; ++x) {
    //       for (int y = 0; y <= Size; ++y) {
    //         c.origin = Point(x, y);
    //         if (base_circle_.isInside(c) &&
    //             !hasOverlaps(c, circles, rects, circle_cnt_, rect_cnt_)) {
    //           throw 1;
    //         }
    //       }
    //     }
    //   }
    //}
    // for (auto& r : rects) {
    //  r_used += r.used;
    //  if (!r.used) {
    //    for (int x = 0; x <= Size; ++x) {
    //      for (int y = 0; y <= Size; ++y) {
    //        r.origin = Point(x, y);
    //        if (base_circle_.isInside(r) &&
    //            !hasOverlaps(r, circles, rects, circle_cnt_, rect_cnt_)) {
    //          throw 1;
    //        }
    //      }
    //    }
    //  }
    //}
    // dbg("Used %d %d\n", c_used, r_used);
  }

  template <typename Shape>
  void findPos(Shape& shape, double& shape_area, const vector<Circle>& circles,
               const vector<Rect>& rects, int circle_id, int rect_id,
               bool allow_no_touches = false) {
    bool found = false;
    int max_touches = allow_no_touches ? -1 : 0;
    Point best_pos;
    while (selector_.hasChoices()) {
      shape.origin = selector_.selectPos();
      if (base_circle_.isInside(shape) &&
          !hasOverlaps(shape, circles, rects, circle_id, rect_id)) {
        int touch_cnt = touchCnt(shape, circles, rects, circle_id, rect_id);
        if (touch_cnt > max_touches) {
          max_touches = touch_cnt;
          best_pos = shape.origin;
          found = true;
        }
      }
    }
    selector_.resetToAlive();
    if (found) {
      shape.origin = best_pos;
      shape.used = true;
      shape_area += shape.area;
      removePos(shape);
    }
  }

  inline double getScore(double circle_area, double rect_area) {
    return circle_area + rect_area -
           fabs(circle_area * circle_weight_ -
                rect_area * (1 - circle_weight_));
  }

  void removePos(const Circle& circle) {
    for (int x = circle.origin.x - circle.r; x < circle.origin.x + circle.r;
         ++x) {
      for (int y = circle.origin.y - circle.r; y < circle.origin.y + circle.r;
           ++y) {
        if (circle.isInside(x, y)) {
          selector_.erasePos(x, y);
        }
      }
    }
  }

  void removePos(const Rect& rect) {
    for (int x = rect.origin.x; x < rect.origin.x + rect.width; ++x) {
      for (int y = rect.origin.y; y < rect.origin.y + rect.height; ++y) {
        selector_.erasePos(x, y);
      }
    }
  }

  int touchCnt(const Circle& circle, const vector<Circle>& circles,
               const vector<Rect>& rects, int max_circle_id, int max_rect_id) {
    int res = 0;
    res += base_circle_.touchInside(circle);
    for (int circle_id = 0; circle_id < max_circle_id; ++circle_id) {
      res += circles[circle_id].used && touch(circles[circle_id], circle);
    }
    return res;
  }

  int touchCnt(const Rect& rect, const vector<Circle>& circles,
               const vector<Rect>& rects, int max_circle_id, int max_rect_id) {
    int res = 0;
    res += base_circle_.touchInside(rect);
    for (int rect_id = 0; rect_id < max_rect_id; ++rect_id) {
      res += rects[rect_id].used && touch(rect, rects[rect_id]);
    }
    return res;
  }

  // template <typename Shape>
  // int touchCnt(const Shape& shape, const vector<Circle>& circles,
  //             const vector<Rect>& rects, int max_circle_id, int max_rect_id)
  //             {
  //  int res = 0;
  //  res += base_circle_.touchInside(shape);
  //  for (int circle_id = 0; circle_id < max_circle_id; ++circle_id) {
  //    res += circles[circle_id].used && touch(circles[circle_id], shape);
  //  }
  //  for (int rect_id = 0; rect_id < max_rect_id; ++rect_id) {
  //    res += rects[rect_id].used && touch(shape, rects[rect_id]);
  //  }
  //  return res;
  //}

  template <typename Shape>
  bool hasOverlaps(const Shape& shape, const vector<Circle>& circles,
                   const vector<Rect>& rects, int max_circle_id,
                   int max_rect_id) {
    for (int circle_id = 0; circle_id < max_circle_id; ++circle_id) {
      if (circles[circle_id].used && overlap(circles[circle_id], shape)) {
        return true;
      }
    }
    for (int rect_id = 0; rect_id < max_rect_id; ++rect_id) {
      if (rects[rect_id].used && overlap(shape, rects[rect_id])) {
        return true;
      }
    }
    return false;
  }

  pair<vector<Point>, vector<Point>> convertRes(const vector<Circle>& circles,
                                                const vector<Rect>& rects) {
    pair<vector<Point>, vector<Point>> res;
    res.first.resize(circles.size());
    res.second.resize(rects.size());
    for (const auto& c : circles) {
      if (c.used) {
        res.first[c.id] = c.origin + Point(-100, -100);
      } else {
        res.first[c.id] = Point(-100, -100);
      }
    }
    for (const auto& r : rects) {
      if (r.used) {
        res.second[r.id] = r.origin + Point(-100, -100);
      } else {
        res.second[r.id] = Point(-100, -100);
      }
    }
    return res;
  }

  int encode(int x, int y) {
    return (x + BaseRadius) * (2 * BaseRadius) + (y + BaseRadius);
  }

  vector<Circle> circles_;
  vector<Rect> rects_;

  RandomSelector selector_;
  Circle base_circle_;

  double circle_weight_;

  int rect_choice_weight_;
  int circle_choice_weight_;

  double start_time_;
  int circle_cnt_;
  int rect_cnt_;
};

pair<vector<Point>, vector<Point>> solutionFromInput(vi& circles,
                                                     vector<pi>& rects,
                                                     double& circle_weight,
                                                     int seed = -1) {
  if (seed != -1) {
    char buf[100] = {0};
    sprintf(buf, "seeds/%d.in", seed);
    freopen(buf, "r", stdin);
  }

  int rect_cnt, circle_cnt;
  scanf("%d%d%lf", &circle_cnt, &rect_cnt, &circle_weight);
  rects.resize(rect_cnt);
  circles.resize(circle_cnt);
  for (int i = 0; i < circle_cnt; i++) {
    scanf("%d", &circles[i]);
  }
  for (int i = 0; i < rect_cnt; i++) {
    scanf("%d%d", &rects[i].first, &rects[i].second);
  }
  TastyPizza tp;
  return tp.findSolution(circles, rects, circle_weight);
}

void checkerTest() {
  vi circles;
  vector<pi> rects;
  double circle_weight;
  auto res = solutionFromInput(circles, rects, circle_weight);
  printf("%d\n", res.first.size() + res.second.size());
  for (const auto& p : res.first) {
    if (p.x == -100) {
      printf("NA\n");
    } else {
      printf("%d %d\n", p.x, p.y);
    }
  }
  for (const auto& p : res.second) {
    if (p.x == -100) {
      printf("NA\n");
    } else {
      printf("%d %d\n", p.x, p.y);
    }
  }
  fflush(stdout);
}

#ifdef LOCAL_TEST
class Checker {
 public:
  double run(int seed) {
    vi in_circles;
    vector<pi> in_rects;
    double circle_weight;
    auto sol = solutionFromInput(in_circles, in_rects, circle_weight, seed);
    vector<CheckerCircle> circles;
    vector<CheckerRect> rects;
    for (int i = 0; i < in_circles.size(); ++i) {
      circles.emplace_back(in_circles[i]);
      if (sol.first[i].x != -100) {
        circles[i].x = sol.first[i].x;
        circles[i].y = sol.first[i].y;
      } else {
        circles[i].used = false;
      }
    }

    for (int i = 0; i < in_rects.size(); ++i) {
      rects.emplace_back(in_rects[i].second, in_rects[i].first);
      if (sol.second[i].x != -100) {
        rects[i].x = sol.second[i].x;
        rects[i].y = sol.second[i].y;
      } else {
        rects[i].used = false;
      }
    }

    int circle_cnt = circles.size();
    int rect_cnt = rects.size();
    // check that two circles don't overlap
    for (int i = 0; i < circle_cnt; i++) {
      for (int k = i + 1; k < circle_cnt; k++) {
        if (circles[i].used && circles[k].used &&
            overlap(circles[i], circles[k])) {
          dbg("circles overlap %d %d\n", i, k);
          throw 1;
        }
      }
    }

    // check that two rectangles don't overlap
    for (int i = 0; i < rect_cnt; i++) {
      for (int k = i + 1; k < rect_cnt; k++)
        if (rects[i].used && rects[k].used && overlap(rects[i], rects[k])) {
          dbg("rects overlap %d %d\n", i, k);
          throw 1;
        }
    }

    // check that circles don't overlap with rectangles
    for (int i = 0; i < circle_cnt; i++) {
      for (int k = 0; k < rect_cnt; k++) {
        if (circles[i].used && rects[k].used && overlap(circles[i], rects[k])) {
          dbg("rect-circle overlap %d %d\n", i, k);
          throw 1;
        }
      }
    }

    // check that circles don't go outside the base
    for (int i = 0; i < circle_cnt; i++) {
      if (circles[i].used) {
        if (distance2(circles[i].x, circles[i].y, 0, 0) >
            sqr(BaseRadius - circles[i].radius)) {
          dbg("bad circle coord %d\n", i);
          throw 1;
        }
      }
    }

    // check that rectangles don't go outside the base
    for (int i = 0; i < rect_cnt; i++) {
      if (rects[i].used) {
        // check all corners
        if (distance2(rects[i].x, rects[i].y, 0, 0) > sqr(BaseRadius) ||
            distance2(rects[i].x + rects[i].width, rects[i].y, 0, 0) >
                sqr(BaseRadius) ||
            distance2(rects[i].x, rects[i].y + rects[i].height, 0, 0) >
                sqr(BaseRadius) ||
            distance2(rects[i].x + rects[i].width, rects[i].y + rects[i].height,
                      0, 0) > sqr(BaseRadius)) {
          dbg("bad rect coord %d\n", i);
          throw 1;
        }
      }
    }

    // compute ingredients area
    double circle_area = 0;
    int circles_placed = 0;
    for (int i = 0; i < circle_cnt; i++) {
      if (circles[i].used) {
        circles_placed++;
        circle_area += sqr(circles[i].radius) * PI;
      }
    }

    double rect_area = 0;
    int rects_placed = 0;
    for (int i = 0; i < rect_cnt; i++) {
      if (rects[i].used) {
        rects_placed++;
        rect_area += rects[i].height * rects[i].width;
      }
    }

    double score =
        circle_area + rect_area -
        fabs(circle_weight * circle_area - (1 - circle_weight) * rect_area);
    dbg("Seed %d, score %.5lf, circles %d/%d (%.5lf), rects %d/%d(%.5lf)\n",
        seed, score, circles_placed, circle_cnt, circle_area, rects_placed,
        rect_cnt, rect_area);

    return score;
  }

 private:
  struct CheckerCircle {
    bool used = true;
    int radius;
    // center of the circle
    int x;
    int y;

    CheckerCircle(int r) { radius = r; }
  };

  struct CheckerRect {
    bool used = true;
    int height;
    int width;
    // bottom-left of the rectangle
    int x;
    int y;

    CheckerRect(int h, int w) {
      height = h;
      width = w;
    }
  };

  int distance2(int x1, int y1, int x2, int y2) {
    return sqr(x1 - x2) + sqr(y1 - y2);
  }

  // circle-circle overlap
  bool overlap(const CheckerCircle& a, const CheckerCircle& b) {
    return distance2(a.x, a.y, b.x, b.y) < sqr(a.radius + b.radius);
  }

  // rectangle-rectangle overlap
  bool overlap(const CheckerRect& a, const CheckerRect& b) {
    return a.x < b.x + b.width && a.x + a.width > b.x && a.y < b.y + b.height &&
           a.y + a.height > b.y;
  }

  bool overlap(const CheckerCircle& a, const CheckerRect& b) {
    double x = abs(a.x - (b.x + b.width * 0.5));
    double y = abs(a.y - (b.y + b.height * 0.5));
    if (x + EPS > b.width * 0.5 + a.radius) return false;
    if (y + EPS > b.height * 0.5 + a.radius) return false;
    if (x + EPS < b.width * 0.5) return true;
    if (y + EPS < b.height * 0.5) return true;
    double cornerDist = sqr(x - b.width * 0.5) + sqr(y - b.height * 0.5);
    return (cornerDist + EPS < sqr(a.radius));
  }
};

int myTest(int seed) {
  Checker checker;
  double res = checker.run(seed);
  dbg("Seed %d score: %lf\n", seed, res);
  return res;
}
#endif

int main(int argc, char* argv[]) {
  // freopen("log", "w", stderr);

#ifdef CHECKER_TEST
  checkerTest();
#else
#ifndef RUN_ITER
  int seed = 4;
  myTest(seed);
#else
  int seed;
  sscanf(argv[1], "%d", &seed);
  int score = myTest(seed);
  printf("%d\n", score);
  fflush(stdout);
#endif
#endif
  return 0;
}