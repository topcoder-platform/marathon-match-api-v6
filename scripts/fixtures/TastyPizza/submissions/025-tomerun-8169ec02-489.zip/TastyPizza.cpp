#include <algorithm>
#include <utility>
#include <vector>
#include <iostream>
#include <array>
#include <numeric>
#include <memory>
#include <cstring>
#include <cstdlib>
#include <cstdio>
#include <cmath>
#include <sys/time.h>

#ifdef LOCAL
// #define MEASURE_TIME
#ifndef NDEBUG
#define DEBUG
#endif
#else
#define NDEBUG
// #define DEBUG
#endif
#include <cassert>

using namespace std;
using u8=uint8_t;
using u16=uint16_t;
using u32=uint32_t;
using u64=uint64_t;
using i64=int64_t;
using ll=int64_t;
using ull=uint64_t;
using vi=vector<int>;
using vvi=vector<vi>;

namespace {

#ifdef LOCAL
constexpr double CLOCK_PER_SEC = 2.2e9;
constexpr ll TL = 1000;
#else
constexpr double CLOCK_PER_SEC = 2.5e9;
constexpr ll TL = 9500;
#endif

ll start_time; // msec

inline ll get_time() {
  struct timeval tv;
  gettimeofday(&tv, NULL);
  ll result =  tv.tv_sec * 1000LL + tv.tv_usec / 1000LL;
  return result;
}

inline ll get_elapsed_msec() {
  return get_time() - start_time;
}

inline bool reach_time_limit() {
  return get_elapsed_msec() >= TL;
}

inline ull get_tsc() {
#ifdef __i386
  ull ret;
  __asm__ volatile ("rdtsc" : "=A" (ret));
  return ret;
#else
  ull high,low;
  __asm__ volatile ("rdtsc" : "=a" (low), "=d" (high));
  return (high << 32) | low;
#endif
}

struct XorShift {
  uint32_t x,y,z,w;
  static const double TO_DOUBLE;

  XorShift() {
    x = 123456789;
    y = 362436069;
    z = 521288629;
    w = 88675123;
  }

  uint32_t nextUInt(uint32_t n) {
    uint32_t t = x ^ (x << 11);
    x = y;
    y = z;
    z = w;
    w = (w ^ (w >> 19)) ^ (t ^ (t >> 8));
    return w % n;
  }

  uint32_t nextUInt() {
    uint32_t t = x ^ (x << 11);
    x = y;
    y = z;
    z = w;
    return w = (w ^ (w >> 19)) ^ (t ^ (t >> 8));
  }

  double nextDouble() {
    return nextUInt() * TO_DOUBLE;
  }
};
const double XorShift::TO_DOUBLE = 1.0 / (1LL << 32);

struct Counter {
  vector<ull> cnt;

  void add(int i) {
    if (i >= cnt.size()) {
      cnt.resize(i+1);
    }
    ++cnt[i];
  }

  void print() {
    cerr << "counter:[";
    for (int i = 0; i < cnt.size(); ++i) {
      cerr << cnt[i] << ", ";
      if (i % 10 == 9) cerr << endl;
    }
    cerr << "]" << endl;
  }
};

struct Timer {
  vector<ull> at;
  vector<ull> sum;

  void start(int i) {
    if (i >= at.size()) {
      at.resize(i+1);
      sum.resize(i+1);
    }
    at[i] = get_tsc();
  }

  void stop(int i) {
    sum[i] += (get_tsc() - at[i]);
  }

  void print() {
    cerr << "timer:[";
    for (int i = 0; i < at.size(); ++i) {
      cerr << (int)(sum[i] / CLOCK_PER_SEC * 1000) << ", ";
      if (i % 10 == 9) cerr << endl;
    }
    cerr << "]" << endl;
  }
};

}

#ifdef MEASURE_TIME
#define START_TIMER(i) (timer.start(i))
#define STOP_TIMER(i) (timer.stop(i))
#define PRINT_TIMER() (timer.print())
#define ADD_COUNTER(i) (counter.add(i))
#define PRINT_COUNTER() (counter.print())
#else
#define START_TIMER(i)
#define STOP_TIMER(i)
#define PRINT_TIMER()
#define ADD_COUNTER(i)
#define PRINT_COUNTER()
#endif

#ifdef DEBUG
#define debug(format, ...) fprintf(stderr, format, __VA_ARGS__)
#define debugStr(str) fprintf(stderr, str)
#define debugln() fprintf(stderr, "\n")
#else
#define debug(format, ...)
#define debugStr(str)
#define debugln()
#endif

template<class T>
constexpr inline T sq(T v) { return v * v; }

void debug_vec(const vi& vec) {
  for (int i = 0; i < vec.size(); ++i) {
    debug("%d ", vec[i]);
  }
  debugln();
}

XorShift rnd;
Timer timer;
Counter counter;

constexpr double PI = 3.141592653589793238;

//////// end of template ////////

struct Pos {
  int x, y;
};

bool operator==(const Pos& p1, const Pos& p2) {
  return p1.x == p2.x && p1.y == p2.y;
}

struct Size {
  int w, h;
};

struct Result {
  vector<Pos> pos_c, pos_r;
  double score;
};

constexpr int INF = 1 << 28;
constexpr int BR = 100;
constexpr int INVALID_COORD = 255;
const Pos INVALID_POS = {INVALID_COORD, INVALID_COORD};
int C, R;
double X;
array<int, 500> CS;
array<Size, 500> RS;
array<vector<Pos>, 16> avail_c;
array<vector<Pos>, 26> avail_r;
array<array<bool, 2 * BR + 1>, 2 * BR + 1> placed;

int rnd_int(int min, int max) {
  return (int)rnd.nextUInt(max - min + 1) + min;
}

bool inside_c(const Pos& p, int r) {
  return sq(p.x - BR) + sq(p.y - BR) <= sq(BR - r);
}

bool inside_r(const Pos& p, const Size& s) {
  if (sq(p.x - BR) + sq(p.y - BR) > sq(BR)) return false;
  if (sq(p.x - BR + s.w) + sq(p.y - BR) > sq(BR)) return false;
  if (sq(p.x - BR) + sq(p.y - BR + s.h) > sq(BR)) return false;
  if (sq(p.x - BR + s.w) + sq(p.y - BR + s.h) > sq(BR)) return false;
  return true;
}

bool overlap_cc(const Pos& p1, int r1, const Pos& p2, int r2) {
  return sq(p1.x - p2.x) + sq(p1.y - p2.y) < sq(r1 + r2);
}

bool overlap_rr(const Pos& p1, const Size& s1, const Pos& p2, const Size&  s2) {
  if (p1.x + s1.w <= p2.x) return false;
  if (p1.x >= p2.x + s2.w) return false;
  if (p1.y + s1.h <= p2.y) return false;
  if (p1.y >= p2.y + s2.h) return false;
  return true;
}

bool overlap_cr(const Pos& p1, int r1, const Pos& p2, const Size&  s2) {
  int x = p1.x * 2 - (p2.x * 2 + s2.w);
  int y = p1.y * 2 - (p2.y * 2 + s2.h);
  if (x >= s2.w + r1 * 2) return false;
  if (y >= s2.h + r1 * 2) return false;
  if (x < s2.w) return true;
  if (y < s2.h) return true;
  return sq(x - s2.w) + sq(y - s2.h) < sq(r1 * 2);
}

// inline bool accept(int diff) {
//   if (diff <= 0) return true;
//   double v = diff * sa_cooler;
//   if (v > 7) return false;
//   return rnd.nextDouble() < exp(-v);
// }

Result solve_one() {
  Result res;
  double area_c = 0.0;
  double area_r = 0.0;
  // const int TRY = 10000;
  for (auto& row : placed) {
    row.fill(false);
  }
  res.pos_c.resize(C, INVALID_POS);
  res.pos_r.resize(R, INVALID_POS);
  vi cands_c(C);
  iota(cands_c.begin(), cands_c.end(), 0);
  sort(cands_c.begin(), cands_c.end(), [](int i1, int i2){
    return CS[i1] > CS[i2];
  });
  vi cands_r(R);
  sort(cands_r.begin(), cands_r.end(), [](int i1, int i2){
    return RS[i1].w * RS[i1].h > RS[i2].w * RS[i2].h;
  });
  iota(cands_r.begin(), cands_r.end(), 0);
  int ci = 0;
  int ri = 0;
  for (int i = 0; i < C + R; ++i) {
    bool use_c;
    if (ci == C) {
      use_c = false;
    } else if (ri == R) {
      use_c = true;
    } else {
      use_c = rnd.nextDouble() > X;
    }
    // debug("i:%d use_c:%d\n", i, use_c);
    if (use_c) {
      int swp = rnd.nextUInt(min(5, C - ci)) + ci;
      swap(cands_c[ci], cands_c[swp]);
      const int cidx = cands_c[ci];
      int rad = CS[cidx];
      int min_d = INF;
      for (int j = 0; j < avail_c[rad].size(); ++j) {
        const Pos pos = avail_c[rad][j];
        int cx = pos.x;
        int cy = pos.y;
        assert(inside_c(pos, rad));
        if (placed[cx][cy]) continue;
        // target to (BR, 2 * BR)
        if (sq(cy + rad - 2 * BR) >= min_d) break;
        int cur_d = sq(cx - BR) + sq(cy + rad - 2 * BR);
        if (cur_d >= min_d) continue;
        bool ok = true;
        for (int k = 0; k < ci; ++k) {
          int cii = cands_c[k];
          if (res.pos_c[cii].x == INVALID_COORD) continue;
          if (overlap_cc({cx, cy}, rad, res.pos_c[cii], CS[cii])) {
            ok = false;
            break;
          }
        }
        for (int k = 0; k < ri; ++k) {
          int rii = cands_r[k];
          if (res.pos_r[rii].x == INVALID_COORD) continue;
          if (overlap_cr({cx, cy}, rad, res.pos_r[rii], RS[rii])) {
            ok = false;
            break;
          }
        }
        if (ok) {
          res.pos_c[cidx] = pos;
          min_d = cur_d;
        }
      }
      if (min_d != INF) {
        // res.pos_c[cidx] = place_c(res, res.pos_c[cidx], rad);
        int cx = res.pos_c[cidx].x;
        int cy = res.pos_c[cidx].y;
        area_c += rad * rad * PI;
        const int rad2 = sq(rad);
        for (int x = cx - rad; x <= cx + rad; ++x) {
          for (int y = cy - rad; y <= cy + rad; ++y) {
            if (placed[x][y]) continue;
            const int d2 = sq(x) + sq(y);
            if (d2 < rad2 || (d2 == rad2 && (x < cx || y < cy))) {
              placed[x][y] = true;
            }
          }
        }
      }
      ci++;
    } else {
      int swp = rnd.nextUInt(min(5, R - ri)) + ri;
      swap(cands_r[ri], cands_r[swp]);
      const int ridx = cands_r[ri];
      const Size& sz = RS[ridx];
      int min_d = INF;
      int ms = min(sz.w, sz.h);
      for (int j = 0; j < avail_r[ms].size(); ++j) {
        const Pos pos = avail_r[ms][j];
        int cx = pos.x;
        int cy = pos.y;
        if (placed[cx][cy]) continue;
        if (!inside_r({cx, cy}, sz)) continue;
        // target to (BR, 0)
        if (sq(cy + sz.h) >= min_d) break;
        int cur_d = sq(cx + (sz.w >> 1) - BR) + sq(cy + sz.h);
        if (cur_d >= min_d) continue;
        bool ok = true;
        for (int k = 0; k < ci; ++k) {
          int cii = cands_c[k];
          if (res.pos_c[cii].x == INVALID_COORD) continue;
          if (overlap_cr(res.pos_c[cii], CS[cii], {cx, cy}, sz)) {
            ok = false;
            break;
          }
        }
        for (int k = 0; k < ri && ok; ++k) {
          int rii = cands_r[k];
          if (res.pos_r[rii].x == INVALID_COORD) continue;
          if (overlap_rr(res.pos_r[rii], RS[rii], {cx, cy}, sz)) {
            ok = false;
            break;
          }
        }
        if (ok) {
          res.pos_r[ridx] = pos;
          min_d = cur_d;
        }
      }
      if (min_d != INF) {
        int cx = res.pos_r[ridx].x;
        int cy = res.pos_r[ridx].y;
        area_r += sz.w * sz.h;
        for (int x = cx; x < cx + sz.w; ++x) {
          for (int y = cy; y < cy + sz.h; ++y) {
            placed[x][y] = true;
          }
        }
      }
      ri++;
    }
    // debug("%d %d %d\n", cand_pos[i].x, cand_pos[i].y, cands[i]);
  }
  res.score = area_c + area_r - abs(area_c * X - area_r * (1 - X));
  return res;
}

class TastyPizza {
public:
  Result findSolution() {
    Result best_res;
    best_res.score = 0.0;
    for (int turn = 0; ; ++turn) {
      if (get_elapsed_msec() > TL) {
        debug("total_turn:%d\n", turn);
        break;
      }
      Result res = solve_one();
      if (res.score > best_res.score) {
        debug("turn:%d score:%f\n", turn, res.score);
        best_res = res;
      }
    }
    return best_res;
  }
};

int main() {
  scanf("%d %d %lf", &C, &R, &X);
  start_time = get_time();
  debug("C:%d R:%d X:%f\n", C, R, X);
  for (int i = 0; i < C; ++i) {
    scanf("%d", &CS[i]);
  }
  for (int i = 0; i < R; ++i) {
    scanf("%d %d", &RS[i].w, &RS[i].h);
  }
  for (int i = 5; i <= 15; ++i) {
    for (int y = 2 * BR - 5; y >= 5; --y) {
      for (int x = 5; x <= 2 * BR - 5; ++x) {
        if (inside_c({x, y}, i)) {
          avail_c[i].push_back({x, y});
        }
      }
    }
  }
  for (int i = 5; i <= 25; ++i) {
    for (int y = 5; y <= 2 * BR - 5; ++y) {
      for (int x = 5; x <= 2 * BR - 5; ++x) {
        if (inside_r({x, y}, {i, i})) {
          avail_r[i].push_back({x, y});
        }
      }
    }
  }
  TastyPizza prog;
  const Result res = prog.findSolution();
  printf("%d\n", C + R);
  for (const auto& p : res.pos_c) {
    if (p.x == INVALID_COORD) {
      printf("NA\n");
    } else {
      printf("%d %d\n", p.x - BR, p.y - BR);
    }
  }
  for (const auto& p : res.pos_r) {
    if (p.x == INVALID_COORD) {
      printf("NA\n");
    } else {
      printf("%d %d\n", p.x - BR, p.y - BR);
    }
  }
  fflush(stdout);
  debug("elapsed:%lld\n", get_elapsed_msec());
  PRINT_TIMER();
  PRINT_COUNTER();
}