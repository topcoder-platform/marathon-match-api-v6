#define _CRT_SECURE_NO_WARNINGS

#pragma comment(linker, "/STACK:500000000")
#include <cstdio>
#include <cstdarg>
#include <cstring>
#include <cmath>
#include <ctime>
#include <vector>
#include <string>
#include <set>
#include <map>
#include <queue>
#include <algorithm>
#include <fstream>
#include <iostream>
#include <thread>
#include <random>
#include <unordered_map>
#include <unordered_set>
using namespace std;
typedef unsigned short ushort;
typedef unsigned int uint;
typedef unsigned long long ull;

#ifndef LOCAL
#define __forceinline __attribute__((always_inline)) inline
#endif


#pragma region Timer

const double TL=9.0;

const double CPU=2.8E9;
const double CPUCOEF=1/CPU;
#ifndef LOCAL
uint64_t rdtsc()
{
	unsigned int lo, hi;
	__asm__ __volatile__ ("rdtsc" : "=a" (lo), "=d" (hi));
	return ((uint64_t)hi<<32)|lo;
}
#else
#include <intrin.h>
uint64_t rdtsc()
{
	return __rdtsc();
}
#endif
uint64_t stt=rdtsc();
void RestartTimer() { stt=rdtsc(); }
__forceinline double Time() { return (rdtsc()-stt)*CPUCOEF; }
#pragma endregion


#pragma region Logging
string ToString(char x) { return string()+x; }
string ToString(const char* x) { return string(x); }
string ToString(const string& s) { return s; }
template <class T>
string ToString(const T& x) { return to_string(x); }
template <class T, class... Types>
string ToString(const T& t, const Types&... args) { return ToString(t)+" "+ToString(args...); }
void Log(const string& s) { fprintf(stderr, "%s\n", s.substr(0, 1000).c_str()); }
template <class T, class... Types>
void Log(const T& t, const Types&... args) { Log(ToString(t, args...)); }
void Logf(const char* format, ...) { va_list args; va_start(args, format); vfprintf(stderr, format, args); fprintf(stderr, "\n"); va_end(args); }
#pragma endregion


#pragma region Rand
class Rand
{
	static unsigned int xs[1<<16], ys[1<<16];
	static bool initialized;
	unsigned int x;
public:
	Rand() : x(0) {}
	Rand(int seed) : x(seed) {}
	__forceinline unsigned int next() { return xs[x&65535]^ys[++x>>16]; }
	__forceinline bool b() { return next()&1; }
	__forceinline int i() { return next()>>1; }
	__forceinline int i(int n) { return next()%n; }
	__forceinline int i(int l, int r) { return next()%(r-l+1)+l; }
	__forceinline double d() { return next()*2.3283064370807973754314699618685e-10; }
	template<class T>
	void Shuffle(T* a, int n)
	{
		for (; n--; swap(a[n], a[i(n+1)]));
	}
	static bool Initialize()
	{
		unsigned int x=123456789, y=362436, z=521288629, c=7654321;
		unsigned long long t, a=698769069LL;
		unsigned int *m=xs;
		for(int i=0; i<2; m=ys, i++)
			for(int j=0; j<(1<<16); ++j)
			{
				x=69069*x+12345;
				y^=y<<13; y^=y>>17; y^=y<<5;
				t=a*z+c; c=t>>32;
				m[j]=x+y+(z=t);
			}
		return 1;
	}
};
unsigned int Rand::xs[1<<16], Rand::ys[1<<16];
bool Rand::initialized=Rand::Initialize();
Rand rnd;
#pragma endregion


template<class T>
void Append(vector<T>& u, const vector<T>& v)
{
	u.insert(u.end(), v.begin(), v.end());
}
template<class T>
void Remove(vector<T>& u, const T& v)
{
	u.erase(find(u.begin(), u.end(), v));
}

struct Config
{
	int i0, i1, inferredLimit;
	double d0, d1;

#define nameof(a) #a
	FILE* configFile;
	map<string, int*> intProperties=
	{ 
		{nameof(i0), &i0},
		{nameof(i1), &i1},
	};
	map<string, double*> doubleProperties=
	{
		{nameof(d0), &d0},
		{nameof(d1), &d1},
	};
	int ReadInt()
	{
		int x=0; fscanf(configFile, "%d", &x); return x;
	}
	double ReadDouble()
	{
		double x=0; fscanf(configFile, "%lf", &x); return x;
	}
	string ReadString()
	{
		char x[100]=""; fscanf(configFile, "%s", x); return x;
	}
	void Read(string file)
	{
		configFile=fopen(file.c_str(), "r");
		for(; ; )
		{
			string propertyName=ReadString();
			if(propertyName.empty()) break;
			ReadString();
			if(intProperties.count(propertyName)) *intProperties[propertyName]=ReadInt();
			else if(doubleProperties.count(propertyName)) *doubleProperties[propertyName]=ReadDouble();
		}
		fclose(configFile);
	}
	void Read()
	{
		Read("config.txt");
	}
	void Print()
	{
		for(auto& p : intProperties) Logf("%s=%d;", p.first.c_str(), *p.second);
		for(auto& p : doubleProperties) Logf("%s=%lf;", p.first.c_str(), *p.second);
	}
	void Default()
	{
		i0=394;
		i1=426;
		d0=165;
		d1=434;
	}
}config;

const double Pi=acos(-1.0);
const int N=500;
const int C=100;

struct P
{
	int x, y;
	P(int x, int y): x(x), y(y) {}
	P() : x(0), y(0) {}
};
P invalid(C+1, C+1);
P operator +(const P& a, const P& b) { return P(a.x+b.x, a.y+b.y); }
P operator -(const P& a, const P& b) { return P(a.x-b.x, a.y-b.y); }
P operator *(const P& a, int b) { return P(a.x*b, a.y*b); }
P operator /(const P& a, int b) { return P(a.x/b, a.y/b); }
void operator +=(P& a, const P& b) { a.x+=b.x; a.y+=b.y; }
void operator -=(P& a, const P& b) { a.x-=b.x; a.y-=b.y; }
void operator *=(P& a, int b) { a.x*=b; a.y*=b; }
long long operator &(const P& a, const P& b) { return (long long)a.x*b.x+(long long)a.y*b.y; }
long long operator *(const P& a, const P& b) { return (long long)a.x*b.y-(long long)a.y*b.x; }
double operator !(const P& a) { return a&a; }
P operator -(const P& a) { return P(-a.x, -a.y); }
bool operator <(const P& a, const P& b) { return a.x<b.x || (a.x==b.x && a.y<b.y); }
bool operator ==(const P& a, const P& b) { return a.x==b.x && a.y==b.y; }
bool operator !=(const P& a, const P& b) { return a.x!=b.x || a.y!=b.y; }

int nr, nc, n;
P dm[2*N];
double sq[2*N];
double X;

namespace Relationships
{
	const int CMIN=5, CMAX=15, RMIN=5, RMAX=25, CT=CMAX-CMIN+1, RT=RMAX/2-RMIN/2+1;
	int cc[2*CT][2*CMAX+1][2*CMAX+1];
	int rc[RT][RT][CT][RMAX/2+CMAX+1][RMAX/2+CMAX+1];
	int cb[CT][C+1][C+1];
	int rb[RT+1][RT+1][C+1][C+1];
	int CircleCircle(const P& a, int ar, const P& b, int br)
	{
		int x=abs(b.x-a.x), y=abs(b.y-a.y);
		int r=ar+br;
		if(x>=2*CMAX || y>=2*CMAX) return 0;
		return cc[r-2*CMIN][x][y];
	}
	int RectCircle(const P& a, const P& d, const P& b, int br)
	{
		int x, y;
		if(2*b.x<2*a.x+d.x) x=a.x-b.x;
		else x=b.x-a.x-d.x;
		if(2*b.y<2*a.y+d.y) y=a.y-b.y;
		else y=b.y-a.y-d.y;
		if(x>=br || y>=br) return 0;
		return rc[d.x/2-RMIN/2][d.y/2-RMIN/2][br-CMIN][x+d.x/2][y+d.y/2];
	}
	int SegmentSegment(int a, int b, int c, int d)
	{
		return max(min(b-c, d-a), 0);
	}
	int RectRect(const P& a, const P&ad, const P& b, const P& bd)
	{
		return min(SegmentSegment(a.x, a.x+ad.x, b.x, b.x+bd.x), SegmentSegment(a.y, a.y+ad.y, b.y, b.y+bd.y));
	}
	int CircleBorder(const P& a, int r)
	{
		if(a.x*a.x+a.y*a.y<=(C-r)*(C-r)) return 0;
		return cb[r-CMIN][abs(a.x)][abs(a.y)];
	}
	int RectBorder(const P& a, const P& d)
	{
		int x, y;
		if(-a.x>a.x+d.x) x=-a.x;
		else x=a.x+d.x;
		if(-a.y>a.y+d.y) y=-a.y;
		else y=a.y+d.y;
		if(x*x+y*y<=C*C) return 0;
		return rb[(d.x+1)/2-(RMIN+1)/2][(d.y+1)/2-(RMIN+1)/2][x][y];
	}
	bool Intersect(int r, int x, int y)
	{
		if(x<=0 && y<=0) return 1;
		if(x<=0) return y<r;
		if(y<=0) return x<r;
		return x*x+y*y<r*r;
	}
	void Initialize()
	{
		for(int c=2*CMIN; c<=2*CMAX; c++)
			for(int x=c; x>=0; x--)
				for(int y=c; y>=0; y--)
					if(x*x+y*y>=c*c) cc[c-2*CMIN][x][y]=0;
					else cc[c-2*CMIN][x][y]=1+min(cc[c-2*CMIN][x+1][y], cc[c-2*CMIN][x][y+1]);
		for(int w=RMIN/2; w<=RMAX/2; w++)
			for(int h=RMIN/2; h<=RMAX/2; h++)
				for(int c=CMIN; c<=CMAX; c++)
					for(int x=w+c; x>=0; x--)
						for(int y=h+c; y>=0; y--)
							if(!Intersect(c, x-w, y-h)) rc[w-RMIN/2][h-RMIN/2][c-CMIN][x][y]=0;
							else rc[w-RMIN/2][h-RMIN/2][c-CMIN][x][y]=1+min(rc[w-RMIN/2][h-RMIN/2][c-CMIN][x+1][y], rc[w-RMIN/2][h-RMIN/2][c-CMIN][x][y+1]);
		for(int c=CMIN; c<=CMAX; c++)
			for(int x=0; x<=C; x++)
				for(int y=0; y<=C; y++)
					if(x*x+y*y<=(C-c)*(C-c)) cb[c-CMIN][x][y]=0;
					else 
					{
						cb[c-CMIN][x][y]=C;
						if(x>0) cb[c-CMIN][x][y]=min(cb[c-CMIN][x][y], cb[c-CMIN][x-1][y]+1);
						if(y>0) cb[c-CMIN][x][y]=min(cb[c-CMIN][x][y], cb[c-CMIN][x][y-1]+1);
					}
		int d0=(RMIN+1)/2;
		for(int w=(RMIN+1)/2; w<=(RMAX+1)/2; w++)
			for(int h=(RMIN+1)/2; h<=(RMAX+1)/2; h++)
				for(int x=0; x<=C; x++)
					for(int y=0; y<=C; y++)
						if(x*x+y*y<=C*C) rb[w-d0][h-d0][x][y]=0;
						else
						{
							rb[w-d0][h-d0][x][y]=C;
							if(x>w) rb[w-d0][h-d0][x][y]=min(rb[w-d0][h-d0][x][y], rb[w-d0][h-d0][x-1][y]+1);
							if(y>h) rb[w-d0][h-d0][x][y]=min(rb[w-d0][h-d0][x][y], rb[w-d0][h-d0][x][y-1]+1);
						}
	}
}

struct State
{
	vector<P> p;
	double sc, sr, score, sascore, cost, costCoef;
	State() : p(n, invalid), sc(0), sr(0), sascore(C*C*Pi), score(C*C*Pi), cost(0), costCoef(0) {}
	double IntersectCost(int x)
	{
		if(x==0) return 0;
		return ((x>0)+x)*costCoef;
	}
	void UpdateCircleCost(int i, int k)
	{
		sc+=k*sq[i];
		cost+=k*IntersectCost(Relationships::CircleBorder(p[i], dm[i].x));
		for(int j=0; j<nc; j++)
			if(j!=i && p[j].x!=invalid.x) cost+=k*IntersectCost(Relationships::CircleCircle(p[i], dm[i].x, p[j], dm[j].x));
		for(int j=nc; j<n; j++)
			if(p[j].x!=invalid.x) cost+=k*IntersectCost(Relationships::RectCircle(p[j], dm[j], p[i], dm[i].x));
	}
	void UpdateRectCost(int i, int k)
	{
		sr+=k*sq[i];
		cost+=k*IntersectCost(Relationships::RectBorder(p[i], dm[i]));
		for(int j=0; j<nc; j++)
			if(p[j].x!=invalid.x)
				cost+=k*IntersectCost(Relationships::RectCircle(p[i], dm[i], p[j], dm[j].x));
		for(int j=nc; j<n; j++)
			if(j!=i && p[j].x!=invalid.x) cost+=k*IntersectCost(Relationships::RectRect(p[j], dm[j], p[i], dm[i]));
	}
	void UpdateScore()
	{
		double x=C*C*Pi-(sc+sr-abs(X*sc-(1-X)*sr));
		score=x+(cost>0)*1E6;
		sascore=x+cost;
	}
	void Remove(int i)
	{
		if(p[i].x==invalid.x) return;
		if(dm[i].y==0) UpdateCircleCost(i, -1);
		else UpdateRectCost(i, -1);
		p[i]=invalid;
		UpdateScore();
	}
	void Place(int i, P t)
	{
		if(p[i].x!=invalid.x) return;
		p[i]=t;
		if(dm[i].y==0) UpdateCircleCost(i, 1);
		else UpdateRectCost(i, 1);
		UpdateScore();
	}
};

namespace SA
{
	double temp;
	double bs;
	P bp;
	bool Check(double de, double t)
	{
		return de<=0 || de*de*rnd.d()<t;
	}
	P GetRandomLocation(const P& f)
	{
		if(f.y==0) return P(rnd.i(-C+f.x, C-f.x), rnd.i(-C+f.x, C-f.x));
		else return P(rnd.i(-C, C-f.x), rnd.i(-C, C-f.y));
	}
	void TryRemove(State& a, int i)
	{
		if(a.p[i].x==invalid.x) return;
		P t=a.p[i];
		a.Remove(i);
		if(Check(a.sascore-bs, temp)) { bs=a.sascore; bp=invalid; }
		a.Place(i, t);
	}
	void TryPlace(State& a, int i, int n)
	{
		if(a.p[i].x!=invalid.x) return;
		for(; n--; )
		{
			P t=GetRandomLocation(dm[i]);
			a.Place(i, t);
			if(Check(a.sascore-bs, temp)) { bs=a.sascore; bp=t; }
			a.Remove(i);
		}
	}
	void TryShift(State& a, int i, int h)
	{
		if(a.p[i].x==invalid.x) return;
		P p=a.p[i];
		P t;
		a.Remove(i);
		int x0=p.x-h, x1=p.x+h, y0=p.y-h, y1=p.y+h;
		if(dm[i].y==0) { x0=max(x0, -C+dm[i].x); x1=min(x1, C-dm[i].x); y0=max(y0, -C+dm[i].x); y1=min(y1, C-dm[i].x); }
		else { x0=max(x0, -C); x1=min(x1, C-dm[i].x); y0=max(y0, -C); y1=min(y1, C-dm[i].y); }
		for(t.x=x0; t.x<=x1; t.x++)
			for(t.y=y0; t.y<=y1; t.y++)
			{
				a.Place(i, t);
				if(Check(a.sascore-bs, temp)) { bs=a.sascore; bp=t; }
				a.Remove(i);
			}
		a.Place(i, p);
	}
	void TryRelocate(State& a, int i, int n)
	{
		if(a.p[i].x==invalid.x) return;
		P p=a.p[i];
		a.Remove(i);
		for(; n--; )
		{
			P t=GetRandomLocation(dm[i]);
			a.Place(i, t);
			if(Check(a.sascore-bs, temp)) { bs=a.sascore; bp=t; }
			a.Remove(i);
		}
		a.Place(i, p);
	}
	State Run(State a, double duration, double startTemp)
	{
		double timeLimit=min(Time()+duration, TL);
		State r=a, c=a;
		int it=0;
		int itlimit=10000;
		for(; ; it++)
		//for(; it<itlimit; it++)
		{
			if(it%1000==0)
				if(a.sascore>c.sascore) a=c;
				else c=a;
			//temp=(double)(itlimit-it)/itlimit;
			temp=(timeLimit-Time())/duration;
			if(temp<0) break;
			a.costCoef=pow(1-temp, 0.3/(0.1+min(X, 1-X)))*500;
			temp=temp*temp*startTemp;
			int i=rnd.i(n);
			bs=a.sascore;
			bp=a.p[i];
			TryRemove(a, i);
			TryPlace(a, i, 10);
			TryRelocate(a, i, 10);
			TryShift(a, i, 3);
			if(bp!=a.p[i]) { a.Remove(i); a.Place(i, bp); }
			if(a.score<r.score) r=a;
		}
		Log("Iter:", it);
		return r;
	}
}

namespace Solve
{
	vector<P> Run(double x, vector<int> cs, vector<P> rs)
	{
		nc=cs.size();
		nr=rs.size();
		n=nc+nr;
		X=x;
		for(int i=0; i<nc; dm[i]=P(cs[i], 0), sq[i]=cs[i]*cs[i]*Pi, i++);
		for(int i=0; i<nr; dm[i+nc]=rs[i], sq[i+nc]=rs[i].x*rs[i].y, i++);
		Relationships::Initialize();
		State a, r;
		a=SA::Run(a, 3.0, 1.0);
		if(a.score<r.score) r=a;
		return r.p;
	}
}

class TastyPizza
{
public:
	double x;
	vector<int> cs;
	vector<P> rs;
	vector<P> res;
	vector<P> findSolution(double x, vector<int> cs, vector<P> rs)
	{
		RestartTimer();
		config.Default();
		return Solve::Run(x, cs, rs);
	}
	void Run()
	{
		res=findSolution(x, cs, rs);
	}
	void Read(FILE* f)
	{
		int c, r;
		fscanf(f, "%d%d%lf", &c, &r, &x);
		cs.resize(c);
		for(auto& t : cs) fscanf(f, "%d", &t);
		rs.resize(r);
		for(auto& t : rs) fscanf(f, "%d%d", &t.x, &t.y);
	}
	void Write(FILE* f)
	{
		fprintf(f, "%d\n", res.size());
		for(auto& t : res) 
			if(t==invalid) fprintf(f, "NA\n");
			else fprintf(f, "%d %d\n", t.x, t.y);
		fflush(f);
	}
	void Save(FILE* f)
	{
		fprintf(f, "%d %d %.13lf\n", cs.size(), rs.size(), x);
		for(auto& t : cs) fprintf(f, "%d\n", t);
		for(auto& t : rs) fprintf(f, "%d %d\n", t.x, t.y);
	}
	void TestGen(Rand& rnd)
	{
	}
	void TestGen()
	{
		static Rand rnd;
		TestGen(rnd);
	}
	double Score()
	{
		return 0;
	}
};

namespace Runner
{
	TastyPizza a;
	void Run()
	{
		a.Read(stdin);
		a.Run();
		a.Write(stdout);
	}
	void SaveTest()
	{
		a.Read(stdin);
		FILE* f=fopen("test.txt", "w");
		a.Save(f);
		fclose(f);
		a.Run();
		a.Write(stdout);
	}
	void Sleep(int ms)
	{
		for(int t=clock(); clock()-t<ms; );
	}
	void SaveAllTests(int t)
	{
		for(int i=1; i<=t; i++)
		{
			string com="java -jar tester.jar -exec SaveTest.exe -novis -seed "+to_string(i);
			system(com.c_str());
			Sleep(300);
			com="copy test.txt Tests\\"+to_string(i)+".txt";
			system(com.c_str());
		}
	}
	void Debug(int seed)
	{
		//Log(seed);
		string test="Release/Tests/"+to_string(seed)+".txt";
		FILE* f=fopen(test.c_str(), "r");
		a.Read(f);
		fclose(f);
		a.Run();
	}
	void RandTest(int n)
	{
		a.TestGen();
		a.Run();
	}
	void RandTests(int t)
	{
		double aver=0;
		for(int i=0; i<t; i++)
		{
			a.TestGen();
			a.Run();
			double score=a.Score();
			aver+=score;
		}
		aver/=t;
		Log(aver);
		Log(Time());
	}
};
int main(int narg, char *args[])
{
	//unner::SaveTest();
	//Runner::SaveAllTests(atoi(args[1]));
#if _DEBUG
	Runner::Debug(22);
#else
	Runner::Run();
#endif
	//Runner::DebugFull(1);
	//for(int seed; ; scanf("%d", &seed), Runner::Debug(seed));
	//for(int i=1; i<=1000; Runner::Debug(i), i++);
	//Runner::RandTests(100, 55, -1, 0);
	//Runner::LearnConfig();
	return 0;
}
