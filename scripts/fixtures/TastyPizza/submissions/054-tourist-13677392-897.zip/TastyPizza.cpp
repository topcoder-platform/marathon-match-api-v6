#undef _GLIBCXX_DEBUG

#include <bits/stdc++.h>
#include <sys/time.h>

using namespace std;

const double TL = 9.0;

double start_time_ = -1;
bool first_time = true;

double get_time() {
  timeval tv; 
  gettimeofday(&tv, 0); 
  auto ret = tv.tv_sec + tv.tv_usec * 1e-6;
  if (first_time) {
    start_time_ = ret;
    first_time = false;
  }
  return ret - start_time_;
}

const int CNT = 16384;
double logs[CNT];

struct rand_gen {
  static const int MAX = 2147483647;
  static constexpr double Q_MAX = 1.0 / MAX;

  int x = 8753, y = 239017, z = 1000000123;

  inline int next_int() {
    int t = x ^ (x << 11);
    x = y;
    y = z;
    z ^= (z >> 19) ^ t ^ (t >> 8);
    return z;
  }

  double next_double() {
    return next_int() * Q_MAX;
  }
} rng;

template <typename A, typename B>
string to_string(pair<A, B> p);

template <typename A, typename B, typename C>
string to_string(tuple<A, B, C> p);

template <typename A, typename B, typename C, typename D>
string to_string(tuple<A, B, C, D> p);

string to_string(const string& s) {
  return '"' + s + '"';
}

string to_string(const char* s) {
  return to_string((string) s);
}

string to_string(bool b) {
  return (b ? "true" : "false");
}

string to_string(vector<bool> v) {
  bool first = true;
  string res = "{";
  for (int i = 0; i < static_cast<int>(v.size()); i++) {
    if (!first) {
      res += ", ";
    }
    first = false;
    res += to_string(v[i]);
  }
  res += "}";
  return res;
}

template <size_t N>
string to_string(bitset<N> v) {
  string res = "";
  for (size_t i = 0; i < N; i++) {
    res += static_cast<char>('0' + v[i]);
  }
  return res;
}

template <typename A>
string to_string(A v) {
  bool first = true;
  string res = "{";
  for (const auto &x : v) {
    if (!first) {
      res += ", ";
    }
    first = false;
    res += to_string(x);
  }
  res += "}";
  return res;
}

template <typename A, typename B>
string to_string(pair<A, B> p) {
  return "(" + to_string(p.first) + ", " + to_string(p.second) + ")";
}

template <typename A, typename B, typename C>
string to_string(tuple<A, B, C> p) {
  return "(" + to_string(get<0>(p)) + ", " + to_string(get<1>(p)) + ", " + to_string(get<2>(p)) + ")";
}

template <typename A, typename B, typename C, typename D>
string to_string(tuple<A, B, C, D> p) {
  return "(" + to_string(get<0>(p)) + ", " + to_string(get<1>(p)) + ", " + to_string(get<2>(p)) + ", " + to_string(get<3>(p)) + ")";
}

void debug_out() { cerr << endl; }

template <typename Head, typename... Tail>
void debug_out(Head H, Tail... T) {
  cerr << " " << to_string(H);
  debug_out(T...);
}

#ifdef LOCAL
#define debug(...) cerr << "[" << #__VA_ARGS__ << "]:", debug_out(__VA_ARGS__)
#else
#define debug(...) 42
#endif

const double pi = acos(-1.0);

int floorsqrt[123456];

class TastyPizza 
{
public:
  vector<string> findSolution(int C, int R, double X, vector<int> &aCircles, vector<pair<int, int> > &aRect)
  { 
    for (int i = 0; i < 123456; i++) floorsqrt[i] = (int) floor(sqrt(i));
    vector<string> bestRet(C + R, "NA");
    double bestAns = 0;
    double coeff = 0.8;
    for (int outer = 0; ; outer++) {
      if (get_time() > TL) {
        break;
      }
      vector<string> ret(C + R, "NA");
      const int MAX = 200;
      vector<vector<int>> grid(MAX, vector<int>(MAX));
      for (int i = 0; i < MAX; i++) {
        for (int j = 0; j < MAX; j++) {
          int x = max(abs(i - 100), abs(i - 100 + 1));
          int y = max(abs(j - 100), abs(j - 100 + 1));
          if (x * x + y * y > 100 * 100) {
            grid[i][j] = 1;
          }
        }
      }
      vector<vector<int>> sum(MAX + 1, vector<int>(MAX + 1));
      auto Calc = [&]() {
        for (int i = 0; i < MAX; i++) {
          for (int j = 0; j < MAX; j++) {
            sum[i + 1][j + 1] = sum[i + 1][j] + sum[i][j + 1] - sum[i][j] + grid[i][j];
          }
        }
      };
      Calc();
      auto Sum = [&](int i1, int j1, int i2, int j2) {
        return sum[i2 + 1][j2 + 1] - sum[i2 + 1][j1] - sum[i1][j2 + 1] + sum[i1][j1];
      };
      double area = pi * 100 * 100;
      double have = 0;
  /*    while (true) {
        int value = -1;
        int bi = -1;
        int bj = -1;
        int bid = -1;
        for (int id = 0; id < R; id++) {
          if (ret[C + id] != "NA") {
            continue;
          }
          int w = aRect[id].first;
          int h = aRect[id].second;
          for (int i = 0; i <= MAX - w; i++) {
            for (int j = 0; j <= MAX - h; j++) {
              if (Sum(i, j, i + w - 1, j + h - 1) == 0) {
                int cur = Sum(i - 1, j - 1, i + w, j + h) - grid[i - 1][j - 1] - grid[i + w][j + h] - grid[i - 1][j + h] - grid[i + w][j - 1];
                if (cur > value) {
                  value = cur;
                  bi = i;
                  bj = j;
                  bid = id;
                }
              }
            }
          }
        }
        if (value == -1) {
          break;
        }
  //      debug(value, bi, bj, bid);
        int id = bid;
        int w = aRect[id].first;
        int h = aRect[id].second;
        ret[C + id] = to_string(bi - 100) + " " + to_string(bj - 100);
        for (int i = bi; i <= bi + w - 1; i++) {
          for (int j = bj; j <= bj + h - 1; j++) {
            assert(grid[i][j] == 0);
            grid[i][j] = 1;
          }
        }
        Calc();
        have += w * h;
        if (have > area * X * 0.8) {
          break;
        }
      }*/
      vector<int> order(C);
      iota(order.begin(), order.end(), 0);
  /*    sort(order.begin(), order.end(), [&](int i, int j) {
        return aCircles[i] > aCircles[j];
      });*/
  //    for (int id : order) {
      vector<vector<int>> by_radius(16);
      for (int i = 0; i < C; i++) {
        by_radius[aCircles[i]].push_back(i);
      }

      vector<vector<int>> limit(MAX, vector<int>(MAX, 15));
      vector<vector<int>> cost(MAX, vector<int>(MAX));

  //    debug("go?");
      for (int i = 0; i < MAX; i++) {
        for (int j = 0; j < MAX; j++) {
          int z = (int) (100 - sqrt((i - 100) * (i - 100) + (j - 100) * (j - 100)));
          if (z <= 15) {
            limit[i][j] = z;
            cost[i][j] = 1;
          }
        }
      }
  //    debug("go!!");

  //    mt19937 rng((unsigned int) chrono::steady_clock::now().time_since_epoch().count());
      for (int iter = 0; iter < C; iter++) {
        int value = -1;
        int bi = -1;
        int bj = -1;
        int bid = -1;
        vector<tuple<int, int, int>> cand;
        for (int i = 0; i < MAX; i++) {
          for (int j = 0; j < MAX; j++) {
            if (limit[i][j] >= 5 && !by_radius[limit[i][j]].empty()) {
              int cur = cost[i][j] * 100 + ((outer & 15) ? limit[i][j] : 100 - limit[i][j]);
              if (cur > value) {
                value = cur;
                cand.clear();
              }
              if (cur == value) {
                cand.emplace_back(i, j, by_radius[limit[i][j]].back());
              }
            }
          }
        }
  //      debug(value, bi, bj, bid, bi == -1 ? -1 : limit[bi][bj]);
        if (value == -1) {
  //        continue;
          break;
        }
//        double coeff = (outer == 0 ? 0.8 : 0.77 + rng.next_double() * 0.08);
        auto tup = cand[outer == 0 ? 0 : rng.next_int() % (int) cand.size()];
        bi = get<0>(tup);
        bj = get<1>(tup);
        bid = get<2>(tup);
        int id = bid;
        int r = aCircles[id];
        by_radius[r].pop_back();
        ret[id] = to_string(bi - 100) + " " + to_string(bj - 100);
        for (int x = bi - r; x < bi + r; x++) {
          for (int y = bj - r; y < bj + r; y++) {
            int dx = min(abs(x - bi), abs(x + 1 - bi));
            int dy = min(abs(y - bj), abs(y + 1 - bj));
            if (dx * dx + dy * dy < r * r) {
  //            assert(grid[x][y] == 0);
              grid[x][y] = 1;
            }
  /*            for (auto& t : inside[x][y]) {
                valid[get<0>(t)][get<1>(t)][get<2>(t)] = false;
              }*/
  /*            for (auto& t : friends[x][y]) {
                cost[get<0>(t)][get<1>(t)][get<2>(t)] += 1;
              }*/
          }
        }
        for (int i = bi - 15 - r - 1; i <= bi + 15 + r + 1; i++) {
          for (int j = bj - 15 - r - 1; j <= bj + 15 + r + 1; j++) {
            if (i < 0 || j < 0 || i >= MAX || j >= MAX) continue;
            int rad = floorsqrt[(i - bi) * (i - bi) + (j - bj) * (j - bj)] - r;
            if (limit[i][j] > rad) {
              limit[i][j] = rad;
              cost[i][j] = 0;
            }
            if (limit[i][j] == rad) {
              cost[i][j] += 1;
            }
          }
        }
        have += pi * r * r;
        if (have > area * (1 - X) * coeff) {
          break;
        }
      }

      vector<vector<vector<int>>> by_size(26, vector<vector<int>>(26));
      for (int i = 0; i < R; i++) {
        int w = aRect[i].first;
        int h = aRect[i].second;
        by_size[w][h].push_back(i);
      }

      vector<vector<int>> fake(MAX, vector<int>(MAX));

      bool changed = true;
      while (changed) {
        changed = false;
        for (int i = 0; i < MAX; i++) {
          int t = 0;
          for (int j = 0; j < MAX; j++) {
            if (grid[i][j] == 1) {
              if (t > 0 && t < 5) {
                for (int k = j - 1; k >= j - t; k--) {
                  grid[i][k] = 1;
                  fake[i][k] = 1;
                }
                changed = true;
              }
              t = 0;
            } else {
              t += 1;
            }
          }
        }
        for (int i = 0; i < MAX; i++) {
          int t = 0;
          for (int j = 0; j < MAX; j++) {
            if (grid[j][i] == 1) {
              if (t > 0 && t < 5) {
                for (int k = j - 1; k >= j - t; k--) {
                  grid[k][i] = 1;
                  fake[k][i] = 1;
                }
                changed = true;
              }
              t = 0;
            } else {
              t += 1;
            }
          }
        }
      }

      Calc();

      while (true) {
        int value = -1;
        int bi = -1;
        int bj = -1;
        int bid = -1;
        for (int i1 = MAX - 5; i1 >= 0; i1--) {
          vector<int> aux(MAX, 0);
          for (int i2 = i1 + 1; i2 < MAX - 1 && i2 <= i1 + 25; i2++) {
            for (int j = 0; j < MAX; j++) {
              aux[j] += grid[i2][j];
            }
            int start = -1;
            bool any = false;
            for (int j = 0; j < MAX; j++) {
              if (aux[j] > 0) {
                int finish = j - 1;
                if (finish - start + 1 >= 5) {
                  any = true;
                  if (i2 - i1 >= 5) {
                    for (int len = min(finish - start + 1, 25); len >= 5; len--) {
                      if (by_size[i2 - i1][len].empty()) {
                        continue;
                      }
                      int id = by_size[i2 - i1][len].back();
                      int w = aRect[id].first;
                      int h = aRect[id].second;
                      for (int pos = start; pos <= finish - len + 1; pos += max(1, (finish - len + 1) - start)) {
                        int i = i1 + 1;
                        int j = pos;
//                        assert(i <= MAX - w && j <= MAX - h && Sum(i, j, i + w - 1, j + h - 1) == 0);
                        int cur = Sum(i - 1, j - 1, i + w, j + h) - grid[i - 1][j - 1] - grid[i + w][j + h] - grid[i - 1][j + h] - grid[i + w][j - 1];
                        if (cur > value) {
                          value = cur;
                          bi = i;
                          bj = j;
                          bid = id;
                        }
                      }
                      break;
                    }
                  }
                }
                start = j + 1;
              }
            }
            if (!any) {
              i1 = min(i1, i2 - 5);
              break;
            }
          }
        }
/*        for (int i = 0; i <= MAX - 5; i++) {
          for (int j = 0; j <= MAX - 5; j++) {
            if (Sum(i, j, i + 4, j + 4) == 0) {
              for (int id = 0; id < R; id++) {
                if (ret[C + id] != "NA") {
                  continue;
                }
                int w = aRect[id].first;
                int h = aRect[id].second;
                if (i <= MAX - w && j <= MAX - h && Sum(i, j, i + w - 1, j + h - 1) == 0) {
    //              int cur = Sum(i - 1, j - 1, i + w, j + h);
                  int cur = Sum(i - 1, j - 1, i + w, j + h) - grid[i - 1][j - 1] - grid[i + w][j + h] - grid[i - 1][j + h] - grid[i + w][j - 1];
                  if (cur > value) {
                    value = cur;
                    bi = i;
                    bj = j;
                    bid = id;
                  }
                }
              }
            }
          }
        }*/
        if (value == -1) {
          break;
        }
//        debug(value, bi, bj, bid);
        int id = bid;
        int w = aRect[id].first;
        int h = aRect[id].second;
        by_size[w][h].pop_back();
        ret[C + id] = to_string(bi - 100) + " " + to_string(bj - 100);
        for (int i = bi; i <= bi + w - 1; i++) {
          for (int j = bj; j <= bj + h - 1; j++) {
            assert(grid[i][j] == 0);
            grid[i][j] = 1;
          }
        }
        Calc();
      }

      
      if (R < 100) {

      vector<vector<pair<int, int>>> obstacles(16);
      for (int x = -15; x < 15; x++) {
        for (int y = -15; y < 15; y++) {
          int dx = min(abs(x), abs(x + 1));
          int dy = min(abs(y), abs(y + 1));
          int r = floorsqrt[dx * dx + dy * dy];
          if (r <= 15) {
            obstacles[r].emplace_back(x, y);
          }
        }
      }

      vector<tuple<int, int, int>> anti_obstacles;
      for (int i = -15 - 1; i <= 15 + 1; i++) {
        for (int j = -15 - 1; j <= 15 + 1; j++) {
          int dx = min(abs(-i), abs(1 - i));
          int dy = min(abs(-j), abs(1 - j));
          int rad = floorsqrt[dx * dx + dy * dy];
          if (rad <= 15) {
            anti_obstacles.emplace_back(i, j, rad);
          }
        }
      }



  //    debug("go?");
      for (int i = 0; i < MAX; i++) {
        for (int j = 0; j < MAX; j++) {
          limit[i][j] = 15;
          cost[i][j] = 0;
          for (int k = 0; k <= 15; k++) {
            for (auto& p : obstacles[k]) {
              int x = i + p.first;
              int y = j + p.second;
              if (x < 0 || y < 0 || x >= MAX || y >= MAX || grid[x][y] == 0 || fake[x][y] == 1) {
                continue;
              }
              cost[i][j] += 1;
            }
            if (cost[i][j] > 0) {
              limit[i][j] = k;
              break;
            }
          }
        }
      }
  //    debug("go!!");

      for (int iter = 0; iter < C; iter++) {
        int value = -1;
        int bi = -1;
        int bj = -1;
        int bid = -1;
        for (int i = 0; i < MAX; i++) {
          for (int j = 0; j < MAX; j++) {
            if (limit[i][j] >= 5 && !by_radius[limit[i][j]].empty()) {
              int cur = cost[i][j];
              if (cur > value) {
                value = cur;
                bi = i;
                bj = j;
                bid = by_radius[limit[i][j]].back();
              }
            }
          }
        }
  //      debug(value, bi, bj, bid, bi == -1 ? -1 : limit[bi][bj]);
        if (value == -1) {
  //        continue;
          break;
        }
        int id = bid;
        int r = aCircles[id];
        by_radius[r].pop_back();
        ret[id] = to_string(bi - 100) + " " + to_string(bj - 100);
/*        for (int x = bi - r; x < bi + r; x++) {
          for (int y = bj - r; y < bj + r; y++) {
            int dx = min(abs(x - bi), abs(x + 1 - bi));
            int dy = min(abs(y - bj), abs(y + 1 - bj));
            if (dx * dx + dy * dy < r * r) {
              assert(grid[x][y] == 0);
              grid[x][y] = 1;
              for (auto& p : anti_obstacles) {
                int i = x + get<0>(p);
                int j = y + get<1>(p);
                if (i < 0 || j < 0 || i >= MAX || j >= MAX) continue;
                int rad = get<2>(p);
                if (limit[i][j] >= rad) {
                  if (limit[i][j] > rad) {
                    limit[i][j] = rad;
                    cost[i][j] = 0;
                  }
                  cost[i][j] += 1;
                }
              }
            }
          }
        }*/
        for (int i = bi - 15 - r - 1; i <= bi + 15 + r + 1; i++) {
          for (int j = bj - 15 - r - 1; j <= bj + 15 + r + 1; j++) {
            if (i < 0 || j < 0 || i >= MAX || j >= MAX) continue;
            int rad = (int) sqrt((i - bi) * (i - bi) + (j - bj) * (j - bj)) - r;
            if (limit[i][j] > rad) {
              limit[i][j] = rad;
              cost[i][j] = 0;
            }
            if (limit[i][j] == rad) {
              cost[i][j] += 1;
            }
          }
        }

      }
      
      }

      double sumC = 0;
      double sumR = 0;
      for (int i = 0; i < C; i++) {
        if (ret[i] != "NA") {
          sumC += pi * aCircles[i] * aCircles[i];
        }
      }
      for (int i = 0; i < R; i++) {
        if (ret[C + i] != "NA") {
          sumR += aRect[i].first * aRect[i].second;
        }
      }
      if (sumC * X > sumR * (1 - X)) {
        coeff = max(0.1, coeff - 0.01);
      } else {
        coeff = min(2.0, coeff + 0.01);
      }
      double ans = sumC + sumR - abs(X * sumC - (1 - X) * sumR);
      debug(outer, ans, bestAns, get_time(), coeff);
      if (ans > bestAns) {
        bestAns = ans;
        bestRet = ret;
      }
    }

    double allow = bestAns * 0.9;
    vector<string> finalRet(C + R, "NA");
    double sumC = 0;
    double sumR = 0;
    bool changed = true;
    while (changed) {
      changed = false;
      for (int i = 0; i < C; i++) {
        if (bestRet[i] != "NA" && finalRet[i] == "NA") {
          double newSumC = sumC + pi * aCircles[i] * aCircles[i];
          double newAns = newSumC + sumR - abs(X * newSumC - (1 - X) * sumR);
          if (newAns <= allow) {
            sumC = newSumC;
            finalRet[i] = bestRet[i];
            changed = true;
          }
        }
      }
      for (int i = 0; i < R; i++) {
        if (bestRet[C + i] != "NA" && finalRet[C + i] == "NA") {
          double newSumR = sumR + aRect[i].first * aRect[i].second;
          double newAns = sumC + newSumR - abs(X * sumC - (1 - X) * newSumR);
          if (newAns <= allow) {
            sumR = newSumR;
            finalRet[C + i] = bestRet[C + i];
            changed = true;
          }
        }
      }
    }
    double newAns = sumC + sumR - abs(X * sumC - (1 - X) * sumR);
    debug(newAns, allow);

    return finalRet; 
  }
};

int main() 
{
  TastyPizza prog;
  int R, C;
  double X;
  cin >> C >> R >> X;
  vector< pair<int, int> > aRect(R);
  vector<int> aCircles(C);
  for (int i=0;i<C;i++)
  {
    cin >> aCircles[i];
  }
  for (int i=0;i<R;i++)
  {
    cin >> aRect[i].first >> aRect[i].second;
  }
  vector<string> ret = prog.findSolution(C, R, X, aCircles, aRect);
  cout << ret.size() << endl;
  for (int i = 0; i < (int)ret.size(); ++i)
      cout << ret[i] << endl;
  cout.flush();
}