#pragma GCC optimize "O3,omit-frame-pointer,inline"
#define _LOCAL
#define DEBUG
#define _DEBUG2
#define _DEBUG3
#include <algorithm>
#include <cstdlib>
#include <iostream>
#include <fstream>
#include <vector>
#include <cmath>
#include "bits/stdc++.h"
#include <sys/time.h>
#include <emmintrin.h>
#include <string>
#include <bitset>
#include <unistd.h>

using namespace std;

#ifdef LOCAL
inline double GetSeconds() {
  return static_cast<double>(chrono::duration_cast<chrono::nanoseconds>(
        chrono::steady_clock::now().time_since_epoch()).count())/1000000000;
}
#else
inline long long GetTSC() {
  long long lo, hi;
  asm volatile ("rdtsc": "=a"(lo), "=d"(hi));
  return lo + (hi << 32);
}
inline double GetSeconds() {
  return GetTSC() / 2.8e9;
}
#endif

struct XorShift {
  uint64_t x = 88172645463325252ULL;
  double nl[65536];
  XorShift() {}

  void init(){
    double n2 = 1.0 / 65536*2;
    for(int i=0; i<65536; i++) nl[i] = log(i / 65536.0 + n2);
  }

  void setSeed(uint64_t seed) { x = seed; init(); }

  uint64_t next() {
    x ^= x << 13; x ^= x >> 7; x ^= x << 17;
    return x;
  }

  int nextInt(int n) {
    uint64_t upper = 0xFFFFFFFFFFFFFFFFULL / n * n;
    uint64_t v = next();
    while (v >= upper) v = next();
    return v % n;
  }

  double nextDouble() {
    uint64_t v = next() >> 11; // 53bit
    return (double)v / (1ULL << 53);
  }

  double nextLog() {
    return nl[nextInt(65536)];
  }
};


XorShift xs;
#ifdef LOCAL
const double TO = 9.8 / 1.2 * 1e-0;
#else
const double TO = 9.8;
#endif

double starttime, gt;
int att,btt,ctt,dtt,ett;

const int MAX_R = 500;
const int MAX_C = 500;
const int NA = -1000;

int C,R;
double X;
int CR[MAX_C];
double CA[MAX_C];
int RW[MAX_R];
int RH[MAX_R];
double RA[MAX_R];
int CX[MAX_C], CY[MAX_C];
int RX[MAX_C], RY[MAX_C];
int MCX[MAX_C], MCY[MAX_C];
const int BM = 201;
bitset<BM> BIN[BM];
bitset<BM> SIN[BM];
vector<tuple<int, int, int>> RIN[16];
vector<int> R2I[16];
vector<int> M2I[MAX_C];

void init(){
  cin >> C >> R >> X;
  for(int i=0; i<C; i++) cin >> CR[i];
  for(int i=0; i<R; i++) cin >> RW[i] >> RH[i];

  for(int i=0; i<C; i++) CA[i] = pow(CR[i], 2) * M_PI;
  for(int i=0; i<R; i++) RA[i] = RW[i] * RH[i];

  for(int i=0; i<BM; i++) for(int j=0; j<BM; j++){
    BIN[i][j] = pow(i-100, 2) + pow(j-100, 2) <= 10000;
  }

  for(int r=5; r<16; r++){
    int rr = r * r;
    RIN[r].clear();
    for(int i=0; i<r; i++) for(int j=0; j<r; j++){
      if(pow(i+1, 2) + pow(j+1, 2) < rr){
        int s = -i*i - j*j;
        RIN[r].emplace_back(s, i,j);
        if(i > 0){
          RIN[r].emplace_back(s, -i, j);
          if(j > 0) RIN[r].emplace_back(s, -i, j);
        }
        if(j > 0) RIN[r].emplace_back(s, i, -j);
      }
    }
    sort(RIN[r].begin(), RIN[r].end());
  }

  for(int i=0; i<16; i++) R2I[i].clear();
  for(int i=0; i<C; i++) R2I[CR[i]].emplace_back(i);
  for(int i=0; i<R; i++){
    int a = RA[i], w = RW[i], h = RH[i];
    int m = max(w, h);
    vector<tuple<int, int>> tv;
    for(int j=0; j<R; j++) if(RA[j] < a && a-RA[j] <= m && RW[j] <= w && RH[j] <= h) tv.emplace_back(-RA[j], j);
    sort(tv.begin(), tv.end());
    M2I[i].clear();
    for(auto t : tv) M2I[i].emplace_back(get<1>(t));
  }

  cerr << "init_time: " << (GetSeconds() - starttime) << endl;
}

inline bool over_cc(int ci, int x, int y, int r){
  int cx = CX[ci], cy = CY[ci], cr = CR[ci];
  return pow(pow(x-cx, 2) + pow(y-cy, 2), 0.5) < r + cr;
}

inline bool over_rc(int ri, int x, int y, int r){
  int rx = RX[ri], ry = RY[ri], rw = RW[ri], rh = RH[ri];
  int tx = x, ty = y;
  if(x < rx) tx = rx;
  else if(x > rx + rw) tx = rx + rw;
  if(y < ry) ty = ry;
  else if(y > ry + rh) ty = ry + rh;
  return pow(pow(x-tx, 2) + pow(y-ty, 2), 0.5) < r;
}

inline bool over_cr(int ci, int x, int y, int w, int h){
  int cx = CX[ci], cy = CY[ci], cr = CR[ci];
  int tx = cx, ty = cy;
  if(cx < x) tx = x;
  else if(cx > x + w) tx = x + w;
  if(cy < y) ty = y;
  else if(cy > y + h) ty = y + h;
  return pow(pow(cx-tx, 2) + pow(cy-ty, 2), 0.5) < cr;
}

inline bool over_rr(int ri, int x, int y, int w, int h){
  int rx = RX[ri], ry = RY[ri], rw = RW[ri], rh = RH[ri];
  return rx < x+w && rx+rw > x && ry < y+h && ry+rh > y;
}


void solve(){
  double ms = 0;

  for(int i=0; i<C; i++) CX[i] = CY[i] = NA;
  for(int i=0; i<R; i++) RX[i] = RY[i] = NA;
  for(int i=0; i<BM; i++) SIN[i] = BIN[i];

  double sca = 0; for(int i=0; i<C; i++) sca += CA[i];
  double sra = 0; for(int i=0; i<R; i++) sra += RA[i];
  sca /= C; sra /= R;
  double rx = X * sca / (sca + sra);
  cerr << "rx: " << sca << " " << sra << " " << rx << endl;

  unordered_set<int> ucs, urs;
  unordered_set<int> dcs, drs;
  bitset<MAX_C> ics;
  bitset<MAX_R> irs;
  const long I1 = 256;
  const long I2 = I1 * I1;
  unordered_set<long> ixycs, ixyrs;
  double mc = 0, mr = 0;
  double gtt = 5;
  while(1){
    gt = 1 - (GetSeconds() - starttime) / TO;
    if(gt <= 0) break;

    att++;

    double tc = mc;
    double tr = mr;
    dcs.clear(); drs.clear();
    ics.reset(); irs.reset();
    ixycs.clear(); ixyrs.clear();
    if(xs.nextDouble() > rx){
      int ci = xs.nextInt(C);
      if(gt > 0.5){
        int cii = xs.nextInt(C);
        if(CA[ci] < CA[cii]) ci = cii;
      }
      int r = CR[ci];
      if(CX[ci] == NA){
        int x = NA, y = NA;
        for(auto i : ucs) if(CA[i] < CA[ci] && xs.nextInt(64) == 0){
          int ty = xs.nextInt(5);
          x = CX[i]; y = CY[i];
          int s = CR[ci] - CR[i];
          if(ty == 0) x -= s;
          else if(ty == 1) x += s;
          else if(ty == 2) y -= s;
          else if(ty == 3) y += s;
          if(x < r || x >= BM-r || y < r || y >= BM-r){
            x = y = NA;
          }else{
            break;
          }
        }

        if(x == NA){
          x = xs.nextInt(BM-r*2) + r;
          if(gt > 0.25) for(int i=0; i<2; i++) x = min(x, xs.nextInt(BM-r*2) + r);
          y = xs.nextInt(BM-r*2) + r;
        }
        if(!BIN[x][y] || r + pow(pow(100-x, 2) + pow(100-y, 2), 0.5) > 100) continue;

        tc += CA[ci];
        CX[ci] = x; CY[ci] = y;
        for(auto i : ucs) if(over_cc(i, x, y, r)){
          dcs.insert(i); tc -= CA[i];
          int ix = CX[i], iy = CY[i], ir = CR[i];
          int ox = -1, oy = -1, ro = -1;
          for(int rr=ir-1; rr>=5; rr--){
            int s = ir - rr;
            if(!over_cc(ci, ix, iy, rr)){ ox=ix; oy=iy; ro=rr; break; }
            if(!over_cc(ci, ix-s, iy, rr)){ ox=ix-s; oy=iy; ro=rr; break; }
            if(!over_cc(ci, ix+s, iy, rr)){ ox=ix+s; oy=iy; ro=rr; break; }
            if(!over_cc(ci, ix, iy-s, rr)){ ox=ix; oy=iy-s; ro=rr; break; }
            if(!over_cc(ci, ix, iy+s, rr)){ ox=ix; oy=iy+s; ro=rr; break; }
          }
          bool oo = 0;
          for(int rr=ro; !oo && rr>=5; rr--) for(auto ii : R2I[rr]){
            if(CX[ii] != NA || ics[ii]) continue;
            ics[ii] = 1;
            ixycs.emplace(ii*I2 + ox*I1 + oy);
            tc += CA[ii];
            oo = 1; break;
          }
        }
        for(auto i : urs) if(over_rc(i, x, y, r)){
          drs.insert(i); tr -= RA[i];
          int ix = RX[i], iy = RY[i], iw = RW[i], ih = RH[i];
          int ox = -1, oy = -1, oi = -1;
          for(int ii : M2I[i]){
            if(RX[ii] != NA || irs[ii]) continue;
            int w = RW[ii], h = RH[ii];
            if(!over_cr(ci, ix, iy, w, h)){ oi=ii; ox=ix; oy=iy; break; }
            if(iw != w && !over_cr(ci, ix+iw-w, iy, w, h)){ oi=ii; ox=ix+iw-w; oy=iy; break; }
            if(ih != h && !over_cr(ci, ix+iw-w, iy+ih-h, w, h)){ oi=ii; ox=ix; oy=iy+ih-h; break; }
            if(iw != w && ih != h && !over_cr(ci, ix+iw-w, iy+ih-h, w, h)){ oi=ii; ox=ix+iw-w; oy=iy+ih-h; break; }
          }
          if(oi >= 0){
            irs[oi] = 1;
            ixyrs.emplace(oi*I2 + ox*I1 + oy);
            tr += RA[oi];
          }
        }

        double ts = tc + tr - abs(tc*X - tr*(1-X));
        if(ms <= ts || ts - ms > gtt * gt * xs.nextLog()){
          btt++;
          auto mmc = mc;
          ms = ts; mc = tc; mr = tr;
          for(auto i : dcs){ CX[i] = NA; ucs.erase(i); }
          for(auto t : ixycs){
            int ti = t / I2, tx = t / I1 % I1, ty = t % I1;
            ucs.insert(ti); CX[ti] = tx; CY[ti] = ty;
          }
          for(auto i : drs){ RX[i] = NA; urs.erase(i); }
          for(auto t : ixyrs){
            int ti = t / I2, tx = t / I1 % I1, ty = t % I1;
            urs.insert(ti); RX[ti] = tx; RY[ti] = ty;
          }
          ucs.insert(ci);
        }else{
          CX[ci] = CY[ci] = NA;
        }
      }else{
        int x = CX[ci];
        int y = CY[ci];
        int dx = 0, dy = 0;
        int ty = xs.nextInt(4);
        if(ty == 0) dx = -1;
        else if(ty == 1) dx = 1;
        else if(ty == 2) dy = -1;
        else dy = 1;
        bool ok = 1;
        while(ok){
          CX[ci] = x; CY[ci] = y;
          x += dx; y += dy;
          if(x < 0 || x >= BM || y < 0 || y >= BM) break;
          if(!BIN[x][y] || r + pow(pow(100-x, 2) + pow(100-y, 2), 0.5) > 100) break;
          for(auto i : ucs) if(i != ci && over_cc(i, x, y, r)){ ok = 0; break; }
          if(ok) for(auto i : urs) if(over_rc(i, x, y, r)){ ok = 0; break; }
        }
      }
    }else{
      int ri = xs.nextInt(R);
      if(gt > 0.5){
        int rii = xs.nextInt(R);
        if(RA[ri] < RA[rii]) ri = rii;
      }
      int w = RW[ri];
      int h = RH[ri];
      if(RX[ri] == NA){
        int x = NA, y = NA;
        for(auto i : urs) if(RA[i] < RA[ri] && xs.nextInt(64) == 0){
          int ty = xs.nextInt(4);
          if(ty == 0){ x = RX[i]; y = RY[i]; }
          else if(ty == 1){ x = RX[i]; y = RY[i] + RH[i] - h; }
          else if(ty == 2){ x = RX[i] + RW[i] - w; y = RY[i]; }
          else { x = RX[i] + RW[i] - w; y = RY[i] + RH[i] - h; }
          if(x < 0 || x >= BM-w || y < 0 || y >= BM-h){
            x = y = NA;
          }else{
            break;
          }
        }

        if(x == NA){
          x = xs.nextInt(BM-w);
          if(gt > 0.25) for(int i=0; i<2; i++) x = max(x, xs.nextInt(BM-w));
          y = xs.nextInt(BM-h);
        }
        if(!BIN[x][y] || !BIN[x+w][y] || !BIN[x][y+h] || !BIN[x+w][y+h]) continue;

        tr += RA[ri];
        RX[ri] = x; RY[ri] = y;
        for(auto i : ucs) if(over_cr(i, x, y, w, h)){
          dcs.insert(i); tc -= CA[i];
          int ix = CX[i], iy = CY[i], ir = CR[i];
          int ox = -1, oy = -1, ro = -1;
          for(int rr=ir-1; rr>=5; rr--){
            int s = ir - rr;
            if(!over_rc(ri, ix, iy, rr)){ ox=ix; oy=iy; ro=rr; break; }
            if(!over_rc(ri, ix-s, iy, rr)){ ox=ix-s; oy=iy; ro=rr; break; }
            if(!over_rc(ri, ix+s, iy, rr)){ ox=ix+s; oy=iy; ro=rr; break; }
            if(!over_rc(ri, ix, iy-s, rr)){ ox=ix; oy=iy-s; ro=rr; break; }
            if(!over_rc(ri, ix, iy+s, rr)){ ox=ix; oy=iy+s; ro=rr; break; }
          }
          bool oo = 0;
          for(int rr=ro; !oo && rr>=5; rr--) for(auto ii : R2I[rr]){
            if(CX[ii] != NA || ics[ii]) continue;
            ics[ii] = 1;
            ixycs.emplace(ii*I2 + ox*I1 + oy);
            tc += CA[ii];
            oo = 1; break;
          }
        }
        for(auto i : urs) if(over_rr(i, x, y, w, h)){
          drs.insert(i); tr -= RA[i];
          int ix = RX[i], iy = RY[i], iw = RW[i], ih = RH[i];
          int ox = -1, oy = -1, oi = -1;
          for(int ii : M2I[i]){
            if(RX[ii] != NA || irs[ii]) continue;
            int w = RW[ii], h = RH[ii];
            if(!over_rr(ri, ix, iy, w, h)){ oi=ii; ox=ix; oy=iy; break; }
            if(iw != w && !over_rr(ri, ix+iw-w, iy, w, h)){ oi=ii; ox=ix+iw-w; oy=iy; break; }
            if(ih != h && !over_rr(ri, ix+iw-w, iy+ih-h, w, h)){ oi=ii; ox=ix; oy=iy+ih-h; break; }
            if(iw != w && ih != h && !over_rr(ri, ix+iw-w, iy+ih-h, w, h)){ oi=ii; ox=ix+iw-w; oy=iy+ih-h; break; }
          }
          if(oi >= 0){
            irs[oi] = 1;
            ixyrs.emplace(oi*I2 + ox*I1 + oy);
            tr += RA[oi];
          }
        }

        double ts = tc + tr - abs(tc*X - tr*(1-X));
        if(ms <= ts || ts - ms > gtt * gt * xs.nextLog()){
          ctt++;
          ms = ts; mc = tc; mr = tr;
          for(auto i : dcs){ CX[i] = NA; ucs.erase(i); }
          for(auto t : ixycs){
            int ti = t / I2, tx = t / I1 % I1, ty = t % I1;
            ucs.insert(ti); CX[ti] = tx; CY[ti] = ty;
          }
          for(auto i : drs){ RX[i] = NA; urs.erase(i); }
          for(auto t : ixyrs){
            int ti = t / I2, tx = t / I1 % I1, ty = t % I1;
            urs.insert(ti); RX[ti] = tx; RY[ti] = ty;
          }
          urs.insert(ri);
        }else{
          RX[ri] = RY[ri] = NA;
        }
      }else{
        int x = RX[ri];
        int y = RY[ri];
        int dx = 0, dy = 0;
        int ty = xs.nextInt(4);
        if(ty == 0) dx = -1;
        else if(ty == 1) dx = 1;
        else if(ty == 2) dy = -1;
        else dy = 1;
        bool ok = 1;
        while(ok){
          RX[ri] = x; RY[ri] = y;
          x += dx; y += dy;
          if(x < 0 || x >= BM-w || y < 0 || y >= BM-w) break;
          if(!BIN[x][y] || !BIN[x+w][y] || !BIN[x][y+h] || !BIN[x+w][y+h]) break;
          for(auto i : ucs) if(over_cr(i, x, y, w, h)){ ok = 0; break; }
          if(ok) for(auto i : urs) if(i != ri && over_rr(i, x, y, w, h)){ ok = 0; break; }
        }
      }
    }
  }

  cerr << "ms: " << ms << " time: " << (GetSeconds() - starttime);
  cerr << " att: " << att << " btt: " << btt;
  cerr << " ctt: " << ctt << " dtt: " << dtt << " ett: " << ett << endl;
}

void output(){
  cout << C + R << "\n";
  for(int i=0; i<C; i++){
    if(CX[i] == NA) cout << "NA\n";
    else{
      cout << CX[i] - 100 << " " << CY[i] - 100 << "\n";
      // cerr << "C: " << CX[i] - 100 << " " << CY[i] - 100 << "\n";
    }
  }
  for(int i=0; i<R; i++){
    if(RX[i] == NA) cout << "NA\n";
    else{
      cout << RX[i] - 100 << " " << RY[i] - 100 << "\n";
      // cerr << "R: " << RX[i] - 100 << " " << RY[i] - 100 << "\n";
    }
  }
}

int main() {
  starttime = GetSeconds();
  srand((unsigned) time(NULL));
  xs.setSeed(rand() % 65536 + 65537);
  // xs.x = 85202;
  cerr << "x: " << xs.x << endl;
  init();
  solve();
#ifdef LOCAL
  // sleep(0.5);
#endif
  output();
  cerr << "output time: " << (GetSeconds() - starttime) << endl;
  // sleep(0.1);

  return 0;
}
