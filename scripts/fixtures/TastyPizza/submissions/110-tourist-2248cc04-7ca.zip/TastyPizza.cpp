#undef _GLIBCXX_DEBUG

#include <bits/stdc++.h>
#include <sys/time.h>

using namespace std;

const double TL = 9.7;

double start_time_ = -1;
bool first_time = true;

double get_time() {
  timeval tv; 
  gettimeofday(&tv, 0); 
  auto ret = tv.tv_sec + tv.tv_usec * 1e-6;
  if (first_time) {
    start_time_ = ret;
    first_time = false;
  }
  return ret - start_time_;
}

const int CNT = 16384;
double logs[CNT];

struct rand_gen {
  static const int MAX = 2147483647;
  static constexpr double Q_MAX = 1.0 / MAX;

  int x = 8753, y = 239017, z = 1000000123;

  inline int next_int() {
    int t = x ^ (x << 11);
    x = y;
    y = z;
    z ^= (z >> 19) ^ t ^ (t >> 8);
    return z;
  }

  double next_double() {
    return next_int() * Q_MAX;
  }
} rng;

template <typename A, typename B>
string to_string(pair<A, B> p);

template <typename A, typename B, typename C>
string to_string(tuple<A, B, C> p);

template <typename A, typename B, typename C, typename D>
string to_string(tuple<A, B, C, D> p);

string to_string(const string& s) {
  return '"' + s + '"';
}

string to_string(const char* s) {
  return to_string((string) s);
}

string to_string(bool b) {
  return (b ? "true" : "false");
}

string to_string(vector<bool> v) {
  bool first = true;
  string res = "{";
  for (int i = 0; i < static_cast<int>(v.size()); i++) {
    if (!first) {
      res += ", ";
    }
    first = false;
    res += to_string(v[i]);
  }
  res += "}";
  return res;
}

template <size_t N>
string to_string(bitset<N> v) {
  string res = "";
  for (size_t i = 0; i < N; i++) {
    res += static_cast<char>('0' + v[i]);
  }
  return res;
}

template <typename A>
string to_string(A v) {
  bool first = true;
  string res = "{";
  for (const auto &x : v) {
    if (!first) {
      res += ", ";
    }
    first = false;
    res += to_string(x);
  }
  res += "}";
  return res;
}

template <typename A, typename B>
string to_string(pair<A, B> p) {
  return "(" + to_string(p.first) + ", " + to_string(p.second) + ")";
}

template <typename A, typename B, typename C>
string to_string(tuple<A, B, C> p) {
  return "(" + to_string(get<0>(p)) + ", " + to_string(get<1>(p)) + ", " + to_string(get<2>(p)) + ")";
}

template <typename A, typename B, typename C, typename D>
string to_string(tuple<A, B, C, D> p) {
  return "(" + to_string(get<0>(p)) + ", " + to_string(get<1>(p)) + ", " + to_string(get<2>(p)) + ", " + to_string(get<3>(p)) + ")";
}

void debug_out() { cerr << endl; }

template <typename Head, typename... Tail>
void debug_out(Head H, Tail... T) {
  cerr << " " << to_string(H);
  debug_out(T...);
}

#ifdef LOCAL
#define debug(...) cerr << "[" << #__VA_ARGS__ << "]:", debug_out(__VA_ARGS__)
#else
#define debug(...) 42
#endif

const double pi = acos(-1.0);
const double area = pi * 100 * 100;

const int MAX = 200;

char grid[MAX][MAX];
int sum[MAX + 1][MAX + 1];

int limit[MAX][MAX];
int cost[MAX][MAX];

vector<pair<int, int>> by_dist[123];
vector<int> by_radius[16];
vector<int> by_size[26][26];
vector<pair<int, int>> obstacles[16];

int prev_h[26][26];
int aux[MAX];

pair<int, int> st[MAX];

class TastyPizza 
{
public:
  vector<string> findSolution(int C, int R, double X, vector<int> &aCircles, vector<pair<int, int> > &aRect)
  { 
    for (int i = -30; i <= 30; i++) {
      for (int j = -30; j <= 30; j++) {
        int r = (int) floor(sqrt(i * i + j * j));
        by_dist[r].emplace_back(i, j);
      }
    }
    
    for (int x = -15; x < 15; x++) {
      for (int y = -15; y < 15; y++) {
        int dx = min(abs(x), abs(x + 1));
        int dy = min(abs(y), abs(y + 1));
        int r = (int) floor(sqrt(dx * dx + dy * dy));
        if (r <= 15) {
          obstacles[r].emplace_back(x, y);
        }
      }
    }

    vector<string> bestRet(C + R, "NA");
    double bestAns = 0;
    double coeff = 0.8;

    for (int outer = 0; ; outer++) {
      if (get_time() > TL) {
        break;
      }
     
      vector<string> ret(C + R, "NA");
      for (int i = 0; i < MAX; i++) {
        for (int j = 0; j < MAX; j++) {
          int x = max(abs(i - 100), abs(i - 100 + 1));
          int y = max(abs(j - 100), abs(j - 100 + 1));
          grid[i][j] = (x * x + y * y > 100 * 100);
        }
      }
      
      auto Calc = [&]() {
        for (int i = 0; i < MAX; i++) {
          for (int j = 0; j < MAX; j++) {
            sum[i + 1][j + 1] = sum[i + 1][j] + sum[i][j + 1] - sum[i][j] + grid[i][j];
          }
        }
      };
      auto Sum = [&](int i1, int j1, int i2, int j2) {
        return sum[i2 + 1][j2 + 1] - sum[i2 + 1][j1] - sum[i1][j2 + 1] + sum[i1][j1];
      };
      Calc();
      
      double have = 0;

      for (int r = 5; r <= 15; r++) {
        by_radius[r].clear();
      }
      for (int i = 0; i < C; i++) {
        by_radius[aCircles[i]].push_back(i);
      }

      for (int i = 0; i < MAX; i++) {
        for (int j = 0; j < MAX; j++) {
          int z = (int) (100 - sqrt((i - 100) * (i - 100) + (j - 100) * (j - 100)));
          if (z <= 15) {
            limit[i][j] = z;
            cost[i][j] = 15;
          } else {
            limit[i][j] = 15;
            cost[i][j] = 0;
          }
        }
      }

      for (int iter = 0; iter < C; iter++) {
        double value = -1e9;
        int bi = -1;
        int bj = -1;
        for (int i = 0; i < MAX; i++) {
          for (int j = 0; j < MAX; j++) {
            if (limit[i][j] >= 5 && !by_radius[limit[i][j]].empty()) {
              double cur = cost[i][j] * 100 + ((outer & 7) ? limit[i][j] : 100 - limit[i][j]) + rng.next_double() * 2;
              if (cur > value) {
                value = cur;
                bi = i;
                bj = j;
              }
            }
          }
        }
        if (value < -1e8) {
          break;
        }
        int r = limit[bi][bj];
        int id = by_radius[r].back();
        by_radius[r].pop_back();
        ret[id] = to_string(bi - 100) + " " + to_string(bj - 100);
        for (int x = bi - r; x < bi + r; x++) {
          for (int y = bj - r; y < bj + r; y++) {
            int dx = min(abs(x - bi), abs(x + 1 - bi));
            int dy = min(abs(y - bj), abs(y + 1 - bj));
            if (dx * dx + dy * dy < r * r) {
              grid[x][y] = 1;
            }
          }
        }
        for (int d = 0; d <= r + 15; d++) {
          int rad = d - r;
          for (auto& p : by_dist[d]) {
            int i = bi + p.first;
            int j = bj + p.second;
            if (i < 0 || j < 0 || i >= MAX || j >= MAX) {
              continue;
            }
            if (limit[i][j] >= rad) {
              if (limit[i][j] > rad) {
                limit[i][j] = rad;
                cost[i][j] = r;
              } else {
                cost[i][j] += r;
              }
            }
          }
        }
        have += pi * r * r;
        if (have > area * (1 - X) * coeff) {
          break;
        }
      }

      for (int w = 5; w <= 25; w++) {
        for (int h = 5; h <= 25; h++) {
          by_size[w][h].clear();
        }
      }
      for (int i = 0; i < R; i++) {
        int w = aRect[i].first;
        int h = aRect[i].second;
        by_size[w][h].push_back(i);
      }

      Calc();

      for (int w = 5; w <= 25; w++) {
        prev_h[w][4] = -1;
        for (int h = 5; h <= 25; h++) {
          prev_h[w][h] = (by_size[w][h].empty() ? prev_h[w][h - 1] : h);
        }
      }

      while (true) {
        double value = -1e9;
        int bi = -1;
        int bj = -1;
        int bid = -1;
        for (int j = 0; j < MAX; j++) {
          aux[j] = 0;
        }
        for (int i = MAX - 1; i >= 0; i--) {
          int stp = 0;
          for (int j = MAX - 1; j >= 0; j--) {
            if (grid[i][j] == 1) {
              aux[j] = 0;
            } else {
              aux[j] += 1;
            }
            int saved = 0;
            while (stp > 0 && st[stp - 1].first > aux[j]) {
              int i1 = i;
              int j1 = j + 1;
              int i2 = i + st[stp - 1].first - 1;
              int j2 = j + st[stp - 1].second + saved;
              int w = min(i2 - i1 + 1, 25);
              int h = prev_h[w][min(j2 - j1 + 1, 25)];
              if (h >= 5) {
                i2 = i1 + w - 1;
                j2 = j1 + h - 1;
                int cur = Sum(i1 - 1, j1 - 1, i2 + 1, j2 + 1) - grid[i1 - 1][j1 - 1] - grid[i2 + 1][j2 + 1] - grid[i1 - 1][j2 + 1] - grid[i2 + 1][j1 - 1];
                cur = cur * 1000 + 1000 + ((outer & 1) == 0 ? w * h : -w * h);//((outer & 3) == 1 ? -w * h : ((outer & 3) == 2 ? w + h : -(w + h))));
                if (cur > value) {
                  value = cur;
                  bi = i1;
                  bj = j1;
                  bid = by_size[w][h].back();
                }
              }
              saved += st[stp - 1].second;
              stp -= 1;
            }
            if (aux[j] >= 5) {
              if (stp > 0 && st[stp - 1].first == aux[j]) {
                st[stp - 1].second += saved + 1;
              } else {
                st[stp++] = make_pair(aux[j], saved + 1);
              }
            }
          }
        }
        if (value < -1e8) {
          break;
        }
        int id = bid;
        int w = aRect[id].first;
        int h = aRect[id].second;
        by_size[w][h].pop_back();
        ret[C + id] = to_string(bi - 100) + " " + to_string(bj - 100);
        for (int i = bi; i <= bi + w - 1; i++) {
          for (int j = bj; j <= bj + h - 1; j++) {
            assert(grid[i][j] == 0);
            grid[i][j] = 1;
          }
        }
        Calc();

        if (by_size[w][h].empty()) {
          prev_h[w][4] = -1;
          for (h = 5; h <= 25; h++) {
            prev_h[w][h] = (by_size[w][h].empty() ? prev_h[w][h - 1] : h);
          }
        }
      }

      
      if (R < 150) {

        for (int i = 0; i < MAX; i++) {
          for (int j = 0; j < MAX; j++) {
            if (limit[i][j] >= 5) {
              limit[i][j] = 15;
              cost[i][j] = 0;
              for (int k = 0; k <= 15; k++) {
                for (auto& p : obstacles[k]) {
                  int x = i + p.first;
                  int y = j + p.second;
                  if (x < 0 || y < 0 || x >= MAX || y >= MAX || grid[x][y] == 0) {
                    continue;
                  }
                  cost[i][j] += 1;
                }
                if (cost[i][j] > 0) {
                  limit[i][j] = k;
                  break;
                }
              }
            }
          }
        }

        for (int iter = 0; iter < C; iter++) {
          double value = -1e9;
          int bi = -1;
          int bj = -1;
          int bid = -1;
          for (int i = 0; i < MAX; i++) {
            for (int j = 0; j < MAX; j++) {
              if (limit[i][j] >= 5 && !by_radius[limit[i][j]].empty()) {
                int cur = cost[i][j];
                if (cur > value) {
                  value = cur;
                  bi = i;
                  bj = j;
                  bid = by_radius[limit[i][j]].back();
                }
              }
            }
          }
          if (value < -1e8) {
            break;
          }
          int id = bid;
          int r = aCircles[id];
          by_radius[r].pop_back();
          ret[id] = to_string(bi - 100) + " " + to_string(bj - 100);
          for (int d = 0; d <= r + 15; d++) {
            for (auto& p : by_dist[d]) {
              int i = bi + p.first;
              int j = bj + p.second;
              if (i < 0 || j < 0 || i >= MAX || j >= MAX || limit[i][j] < 5) {
                continue;
              }
              int rad = d - r;
              if (limit[i][j] >= rad) {
                if (limit[i][j] > rad) {
                  limit[i][j] = rad;
                  cost[i][j] = r;
                } else {
                  cost[i][j] += r;
                }
              }
            }
          }

        }
      
      }

      double sumC = 0;
      double sumR = 0;
      for (int i = 0; i < C; i++) {
        if (ret[i] != "NA") {
          sumC += pi * aCircles[i] * aCircles[i];
        }
      }
      for (int i = 0; i < R; i++) {
        if (ret[C + i] != "NA") {
          sumR += aRect[i].first * aRect[i].second;
        }
      }
      coeff = (1 * coeff + 1 * ((sumC + sumR) / area)) / 2;
      double ans = sumC + sumR - abs(X * sumC - (1 - X) * sumR);
      debug(outer, ans, bestAns, get_time(), coeff);
      if (ans > bestAns) {
        bestAns = ans;
        bestRet = ret;
      }
    }

    return bestRet; 
  }
};

int main() 
{
  TastyPizza prog;
  int R, C;
  double X;
  cin >> C >> R >> X;
  vector< pair<int, int> > aRect(R);
  vector<int> aCircles(C);
  for (int i=0;i<C;i++)
  {
    cin >> aCircles[i];
  }
  for (int i=0;i<R;i++)
  {
    cin >> aRect[i].first >> aRect[i].second;
  }
  vector<string> ret = prog.findSolution(C, R, X, aCircles, aRect);
  cout << ret.size() << endl;
  for (int i = 0; i < (int)ret.size(); ++i)
      cout << ret[i] << endl;
  cout.flush();
}