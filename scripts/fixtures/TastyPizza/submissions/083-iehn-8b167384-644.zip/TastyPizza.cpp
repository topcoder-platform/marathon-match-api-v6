#pragma GCC optimize "O3,omit-frame-pointer,inline"
#define _LOCAL
#define DEBUG
#define _DEBUG2
#define _DEBUG3
#include <algorithm>
#include <cstdlib>
#include <iostream>
#include <fstream>
#include <vector>
#include <cmath>
#include "bits/stdc++.h"
#include <sys/time.h>
#include <emmintrin.h>
#include <string>
#include <bitset>
#include <unistd.h>

using namespace std;

#ifdef LOCAL
inline double GetSeconds() {
  return static_cast<double>(chrono::duration_cast<chrono::nanoseconds>(
        chrono::steady_clock::now().time_since_epoch()).count())/1000000000;
}
#else
inline long long GetTSC() {
  long long lo, hi;
  asm volatile ("rdtsc": "=a"(lo), "=d"(hi));
  return lo + (hi << 32);
}
inline double GetSeconds() {
  return GetTSC() / 2.8e9;
}
#endif

struct XorShift {
  uint64_t x = 88172645463325252ULL;
  double nl[65536];
  XorShift() {}

  void init(){
    double n2 = 1.0 / 65536*2;
    for(int i=0; i<65536; i++) nl[i] = log(i / 65536.0 + n2);
  }

  void setSeed(uint64_t seed) { x = seed; init(); }

  uint64_t next() {
    x ^= x << 13; x ^= x >> 7; x ^= x << 17;
    return x;
  }

  int nextInt(int n) {
    uint64_t upper = 0xFFFFFFFFFFFFFFFFULL / n * n;
    uint64_t v = next();
    while (v >= upper) v = next();
    return v % n;
  }

  double nextDouble() {
    uint64_t v = next() >> 11; // 53bit
    return (double)v / (1ULL << 53);
  }

  double nextLog() {
    return nl[nextInt(65536)];
  }
};


XorShift xs;
#ifdef LOCAL
const double TO = 9.8 / 1.2 * 1e-0;
#else
const double TO = 9.8;
#endif

double starttime, gt;
int att,btt,ctt,dtt,ett;

const int MAX_R = 500;
const int MAX_C = 500;
const int NA = -1000;

int C,R;
double X;
int CR[MAX_C];
double CA[MAX_C];
int RW[MAX_R];
int RH[MAX_R];
double RA[MAX_R];
int CX[MAX_C], CY[MAX_C];
int RX[MAX_C], RY[MAX_C];
int MCX[MAX_C], MCY[MAX_C];
const int BM = 201;
bitset<BM> BIN[BM];
bitset<BM> SIN[BM];
vector<tuple<int, int, int>> RIN[16];
vector<int> R2I[16];
vector<int> M2I[MAX_C];
const int CM = 32;
const int CMM = CM * CM;
vector<int> C2I[CM*CM];
vector<tuple<int, int>> R2R[16][16];
double PXY[BM][BM];

void init(){
  cin >> C >> R >> X;
  for(int i=0; i<C; i++) cin >> CR[i];
  for(int i=0; i<R; i++) cin >> RW[i] >> RH[i];

  for(int i=0; i<C; i++) CA[i] = pow(CR[i], 2) * M_PI;
  for(int i=0; i<R; i++) RA[i] = RW[i] * RH[i];

  for(int i=0; i<BM; i++) for(int j=0; j<BM; j++){
    BIN[i][j] = pow(i-100, 2) + pow(j-100, 2) <= 10000;
  }

  for(int r=5; r<16; r++){
    int rr = r * r;
    RIN[r].clear();
    for(int i=0; i<r; i++) for(int j=0; j<r; j++){
      if(pow(i+1, 2) + pow(j+1, 2) < rr){
        int s = -i*i - j*j;
        RIN[r].emplace_back(s, i,j);
        if(i > 0){
          RIN[r].emplace_back(s, -i, j);
          if(j > 0) RIN[r].emplace_back(s, -i, j);
        }
        if(j > 0) RIN[r].emplace_back(s, i, -j);
      }
    }
    sort(RIN[r].begin(), RIN[r].end());
  }

  for(int i=0; i<16; i++) R2I[i].clear();
  for(int i=0; i<C; i++) R2I[CR[i]].emplace_back(i);

  for(int i=0; i<CMM; i++) C2I[i].clear();
  for(int i=0; i<R; i++) C2I[RW[i]*CM + RH[i]].emplace_back(i);
  for(int i=0; i<R; i++){
    int w = RW[i], h = RH[i];
    M2I[i].clear();
    vector<tuple<int, int>> tv;
    for(int cw=w; cw>4; cw--) for(int ch=h; ch>4; ch--){
      if(cw == w && ch == h) continue;
      int cwh = cw*CM + ch;
      if(C2I[cwh].size() > 0) tv.emplace_back(-cw*ch, cwh);
    }
    sort(tv.begin(), tv.end());
    int ts = tv.size();
    for(int ti=0; ti<ts; ti++) M2I[i].emplace_back(get<1>(tv[ti]));
  }

  for(int i=5; i<16; i++) for(int j=5; j<i; j++){
    R2R[i][j].clear();
    int s = i - j;
    int s2 = s * s;
    vector<tuple<int, int, int>> tv;
    for(int k=0; k<=s; k++) for(int l=1; l<s+2; l++){
      if(k*k+l*l > s2){
        tv.emplace_back(-k*k-pow(l-1, 2), k, l-1);
        break;
      }
    }
    sort(tv.begin(), tv.end());
    for(auto t : tv){
      int k = get<1>(t);
      int l = get<2>(t);
      R2R[i][j].emplace_back(k, l);
      if(k > 0) R2R[i][j].emplace_back(-k, l);
      if(l > 0) R2R[i][j].emplace_back(k, -l);
      if(k > 0 && l > 0) R2R[i][j].emplace_back(-k, -l);
      if(R2R[i][j].size() >= 16) break;
    }
  }

  for(int x=0; x<BM; x++) for(int y=0; y<BM; y++){
    PXY[x][y] = pow(pow(100-x, 2) + pow(100-y, 2), 0.5);
  }

  cerr << "init_time: " << (GetSeconds() - starttime) << endl;
}

inline bool over_cc(int ci, int x, int y, int r){
  return pow(x-CX[ci], 2) + pow(y-CY[ci], 2) < pow(r + CR[ci], 2);
}

inline bool over_rc(int ri, int x, int y, int r){
  int rx = RX[ri], ry = RY[ri], rw = RW[ri], rh = RH[ri];
  int tx = x, ty = y;
  if(x < rx) tx = rx;
  else if(x > rx + rw) tx = rx + rw;
  if(y < ry) ty = ry;
  else if(y > ry + rh) ty = ry + rh;
  return pow(x-tx, 2) + pow(y-ty, 2) < r*r;
}

inline bool over_cr(int ci, int x, int y, int w, int h){
  int cx = CX[ci], cy = CY[ci], cr = CR[ci];
  int tx = cx, ty = cy;
  if(cx < x) tx = x;
  else if(cx > x + w) tx = x + w;
  if(cy < y) ty = y;
  else if(cy > y + h) ty = y + h;
  return pow(cx-tx, 2) + pow(cy-ty, 2) < cr*cr;
}

inline bool over_rr(int ri, int x, int y, int w, int h){
  int rx = RX[ri], ry = RY[ri], rw = RW[ri], rh = RH[ri];
  return rx < x+w && rx+rw > x && ry < y+h && ry+rh > y;
}


void solve(){
  double ms = 0;

  for(int i=0; i<C; i++) CX[i] = CY[i] = NA;
  for(int i=0; i<R; i++) RX[i] = RY[i] = NA;
  for(int i=0; i<BM; i++) SIN[i] = BIN[i];

  double sca = 0; for(int i=0; i<C; i++) sca += CA[i];
  double sra = 0; for(int i=0; i<R; i++) sra += RA[i];
  sca /= C; sra /= R;
  double cat = sca * X, rat = sra * (1 - X);
  double rx = min(0.95, max(0.05, cat / (cat + rat)));
  cerr << "rx: " << sca << " " << sra << " " << rx << endl;

  vector<int> ucsv, ursv;
  vector<int> dcs, drs;
  bitset<MAX_C> ucs, ics;
  bitset<MAX_R> urs, irs;
  vector<tuple<int, int, int>> ixycs, ixyrs;
  double mc = 0, mr = 0;
  double gtt = 16;
  while(1){
    gt = 1 - (GetSeconds() - starttime) / TO;
    if(gt <= 0) break;

    att++;

    double tc = mc;
    double tr = mr;
    dcs.clear(); drs.clear();
    ics.reset(); irs.reset();
    ixycs.clear(); ixyrs.clear();
    if(xs.nextDouble() > rx){
      int ci = xs.nextInt(C);
      if(gt > 0.5){
        int cii = xs.nextInt(C);
        if(CA[ci] < CA[cii]) ci = cii;
      }
      int r = CR[ci];
      if(CX[ci] == NA){
        int x = NA, y = NA;
        for(auto i : ucsv) if(CA[i] < CA[ci] && xs.nextInt(32) == 0){
          int ty = xs.nextInt(4);
          x = CX[i]; y = CY[i];
          int s = CR[ci] - CR[i];
          if(ty == 0) x -= s;
          else if(ty == 1) x += s;
          else if(ty == 2) y -= s;
          else y += s;
          if(x < r || x >= BM-r || y < r || y >= BM-r){
            x = y = NA;
          }else{
            break;
          }
        }

        if(x == NA){
          x = xs.nextInt(BM-r*2) + r;
          if(gt > 0.25) for(int i=0; i<2; i++) x = min(x, xs.nextInt(BM-r*2) + r);
          y = xs.nextInt(BM-r*2) + r;
        }
        if(!BIN[x][y] || r + PXY[x][y] > 100) continue;

        tc += CA[ci];
        CX[ci] = x; CY[ci] = y;
        for(auto i : ucsv) if(over_cc(i, x, y, r)){
          dcs.emplace_back(i); tc -= CA[i];
          int ix = CX[i], iy = CY[i], ir = CR[i];
          int ox = -1, oy = -1, ro = -1;
          for(int rr=ir-1; rr>=5; rr--){
            bool ex = 0;
            for(auto ii : R2I[rr]) if(CX[ii] == NA) { ex=1; break; }
            if(!ex) continue;
            for(auto r2r : R2R[ir][rr]){
              int sx = ix + get<0>(r2r);
              int sy = iy + get<1>(r2r);
              if(!over_cc(ci, sx, sy, rr)){ ox=sx; oy=sy; ro=rr; break; }
            }
            if(ro > 0) break;
          }
          bool oo = 0;
          for(int rr=ro; !oo && rr>=5; rr--) for(auto ii : R2I[rr]){
            if(CX[ii] != NA || ics[ii]) continue;
            ics[ii] = 1;
            ixycs.emplace_back(ii, ox, oy);
            tc += CA[ii];
            oo = 1; break;
          }
        }
        for(auto i : ursv) if(over_rc(i, x, y, r)){
          drs.emplace_back(i); tr -= RA[i];
          int ix = RX[i], iy = RY[i], iw = RW[i], ih = RH[i];
          int ox = -1, oy = -1, oi = -1;
          for(int cwh : M2I[i]){
            for(int ii : C2I[cwh]){
              if(RX[ii] != NA || irs[ii]) continue;
              int w = RW[ii], h = RH[ii];
              if(!over_cr(ci, ix, iy, w, h)){ oi=ii; ox=ix; oy=iy; break; }
              if(iw != w && !over_cr(ci, ix+iw-w, iy, w, h)){ oi=ii; ox=ix+iw-w; oy=iy; break; }
              if(ih != h && !over_cr(ci, ix, iy+ih-h, w, h)){ oi=ii; ox=ix; oy=iy+ih-h; break; }
              if(iw != w && ih != h && !over_cr(ci, ix+iw-w, iy+ih-h, w, h)){ oi=ii; ox=ix+iw-w; oy=iy+ih-h; break; }
              break;
            }
            if(oi >= 0) break;
          }
          if(oi >= 0){
            irs[oi] = 1;
            ixyrs.emplace_back(oi, ox, oy);
            tr += RA[oi];
          }
        }

        double ts = tc + tr - abs(tc*X - tr*(1-X));
        if(ms <= ts || ts - ms > gtt * gt * xs.nextLog()){
          btt++;
          auto mmc = mc;
          ms = ts; mc = tc; mr = tr;
          for(auto i : dcs){ CX[i] = NA; ucs[i] = 0;
            for(int j=0; j<C; j++) if(ucsv[j] == i) { ucsv.erase(ucsv.begin() + j); break; }
          }
          for(auto t : ixycs){
            int ti = get<0>(t), tx = get<1>(t), ty = get<2>(t);
            ucs[ti] = 1; ucsv.emplace_back(ti); CX[ti] = tx; CY[ti] = ty;
          }
          for(auto i : drs){ RX[i] = NA; urs[i] = 0;
            for(int j=0; j<R; j++) if(ursv[j] == i) { ursv.erase(ursv.begin() + j); break; }
          }
          for(auto t : ixyrs){
            int ti = get<0>(t), tx = get<1>(t), ty = get<2>(t);
            urs[ti] = 1; ursv.emplace_back(ti); RX[ti] = tx; RY[ti] = ty;
          }
          ucs[ci] = 1; ucsv.emplace_back(ci);
        }else{
          CX[ci] = CY[ci] = NA;
        }
      }else{
        int x = CX[ci];
        int y = CY[ci];
        int dx = 0, dy = 0;
        while(dx == 0 && dy == 0){
          dx = xs.nextInt(5) - 2;
          dy = xs.nextInt(5) - 2;
        }
        if(dx == 0) dy /= abs(dy);
        else if(dy == 0) dx /= abs(dx);
        bool ok = 1;
        while(ok){
          CX[ci] = x; CY[ci] = y;
          x += dx; y += dy;
          if(x < 0 || x >= BM || y < 0 || y >= BM) break;
          if(!BIN[x][y] || r + PXY[x][y] > 100) break;
          for(auto i : ucsv) if(i != ci && over_cc(i, x, y, r)){ ok = 0; break; }
          if(ok) for(auto i : ursv) if(over_rc(i, x, y, r)){ ok = 0; break; }
        }
      }
    }else{
      int ri = xs.nextInt(R);
      if(gt > 0.5){
        int rii = xs.nextInt(R);
        if(RA[ri] < RA[rii]) ri = rii;
      }
      int w = RW[ri];
      int h = RH[ri];
      if(RX[ri] == NA){
        int x = NA, y = NA;
        for(auto i : ursv) if(RA[i] < RA[ri] && xs.nextInt(32) == 0){
          int ty = xs.nextInt(4);
          if(ty == 0){ x = RX[i]; y = RY[i]; }
          else if(ty == 1){ x = RX[i]; y = RY[i] + RH[i] - h; }
          else if(ty == 2){ x = RX[i] + RW[i] - w; y = RY[i]; }
          else { x = RX[i] + RW[i] - w; y = RY[i] + RH[i] - h; }
          if(x < 0 || x >= BM-w || y < 0 || y >= BM-h){
            x = y = NA;
          }else{
            break;
          }
        }

        if(x == NA){
          x = xs.nextInt(BM-w);
          if(gt > 0.25) for(int i=0; i<2; i++) x = max(x, xs.nextInt(BM-w));
          y = xs.nextInt(BM-h);
        }
        if(!BIN[x][y] || !BIN[x+w][y] || !BIN[x][y+h] || !BIN[x+w][y+h]) continue;

        tr += RA[ri];
        RX[ri] = x; RY[ri] = y;
        for(auto i : ucsv) if(over_cr(i, x, y, w, h)){
          dcs.emplace_back(i); tc -= CA[i];
          int ix = CX[i], iy = CY[i], ir = CR[i];
          int ox = -1, oy = -1, ro = -1;
          for(int rr=ir-1; rr>=5; rr--){
            bool ex = 0;
            for(auto ii : R2I[rr]) if(CX[ii] == NA) { ex=1; break; }
            if(!ex) continue;
            for(auto r2r : R2R[ir][rr]){
              int sx = ix + get<0>(r2r);
              int sy = iy + get<1>(r2r);
              if(!over_rc(ri, sx, sy, rr)){ ox=sx; oy=sy; ro=rr; break; }
            }
            if(ro > 0) break;
          }
          bool oo = 0;
          for(int rr=ro; !oo && rr>=5; rr--) for(auto ii : R2I[rr]){
            if(CX[ii] != NA || ics[ii]) continue;
            ics[ii] = 1;
            ixycs.emplace_back(ii, ox, oy);
            tc += CA[ii];
            oo = 1; break;
          }
        }
        for(auto i : ursv) if(over_rr(i, x, y, w, h)){
          drs.emplace_back(i); tr -= RA[i];
          int ix = RX[i], iy = RY[i], iw = RW[i], ih = RH[i];
          int ox = -1, oy = -1, oi = -1;
          for(int cwh : M2I[i]){
            for(int ii : C2I[cwh]){
              if(RX[ii] != NA || irs[ii]) continue;
              int w = RW[ii], h = RH[ii];
              if(!over_rr(ri, ix, iy, w, h)){ oi=ii; ox=ix; oy=iy; break; }
              if(iw != w && !over_rr(ri, ix+iw-w, iy, w, h)){ oi=ii; ox=ix+iw-w; oy=iy; break; }
              if(ih != h && !over_rr(ri, ix, iy+ih-h, w, h)){ oi=ii; ox=ix; oy=iy+ih-h; break; }
              if(iw != w && ih != h && !over_rr(ri, ix+iw-w, iy+ih-h, w, h)){ oi=ii; ox=ix+iw-w; oy=iy+ih-h; break; }
              break;
            }
            if(oi >= 0) break;
          }
          if(oi >= 0){
            irs[oi] = 1;
            ixyrs.emplace_back(oi, ox, oy);
            tr += RA[oi];
          }
        }

        double ts = tc + tr - abs(tc*X - tr*(1-X));
        if(ms <= ts || ts - ms > gtt * gt * xs.nextLog()){
          ctt++;
          ms = ts; mc = tc; mr = tr;
          for(auto i : dcs){ CX[i] = NA; ucs[i] = 0;
            for(int j=0; j<C; j++) if(ucsv[j] == i) { ucsv.erase(ucsv.begin() + j); break; }
          }
          for(auto t : ixycs){
            int ti = get<0>(t), tx = get<1>(t), ty = get<2>(t);
            ucs[ti] = 1; ucsv.emplace_back(ti); CX[ti] = tx; CY[ti] = ty;
          }
          for(auto i : drs){ RX[i] = NA; urs[i] = 0;
            for(int j=0; j<R; j++) if(ursv[j] == i) { ursv.erase(ursv.begin() + j); break; }
          }
          for(auto t : ixyrs){
            int ti = get<0>(t), tx = get<1>(t), ty = get<2>(t);
            urs[ti] = 1; ursv.emplace_back(ti); RX[ti] = tx; RY[ti] = ty;
          }
          urs[ri] = 1; ursv.emplace_back(ri);
        }else{
          RX[ri] = RY[ri] = NA;
        }
      }else{
        int x = RX[ri];
        int y = RY[ri];
        int dx = 0, dy = 0;
        int ty = xs.nextInt(4);
        if(ty == 0) dx = -1;
        else if(ty == 1) dx = 1;
        else if(ty == 2) dy = -1;
        else dy = 1;
        bool ok = 1;
        while(ok){
          RX[ri] = x; RY[ri] = y;
          x += dx; y += dy;
          if(x < 0 || x >= BM-w || y < 0 || y >= BM-w) break;
          if(!BIN[x][y] || !BIN[x+w][y] || !BIN[x][y+h] || !BIN[x+w][y+h]) break;
          for(auto i : ucsv) if(over_cr(i, x, y, w, h)){ ok = 0; break; }
          if(ok) for(auto i : ursv) if(i != ri && over_rr(i, x, y, w, h)){ ok = 0; break; }
        }
      }
    }
  }

  cerr << "ms: " << ms << " time: " << (GetSeconds() - starttime);
  cerr << " att: " << att << " btt: " << btt;
  cerr << " ctt: " << ctt << " dtt: " << dtt << " ett: " << ett << endl;
}

void output(){
  cout << C + R << "\n";
  for(int i=0; i<C; i++){
    if(CX[i] == NA) cout << "NA\n";
    else{
      cout << CX[i] - 100 << " " << CY[i] - 100 << "\n";
      // cerr << "C: " << CX[i] - 100 << " " << CY[i] - 100 << "\n";
    }
  }
  for(int i=0; i<R; i++){
    if(RX[i] == NA) cout << "NA\n";
    else{
      cout << RX[i] - 100 << " " << RY[i] - 100 << "\n";
      // cerr << "R: " << RX[i] - 100 << " " << RY[i] - 100 << "\n";
    }
  }
}

int main() {
  starttime = GetSeconds();
  srand((unsigned) time(NULL));
  xs.setSeed(rand() % 65536 + 65537);
  // xs.x = 95469;
  cerr << "x: " << xs.x << endl;
  init();
  solve();
#ifdef LOCAL
  // sleep(0.5);
#endif
  output();
  cerr << "output time: " << (GetSeconds() - starttime) << endl;
  // sleep(0.1);

  return 0;
}
