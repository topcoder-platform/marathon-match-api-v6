const double TL = 9.0;
#include <bits/stdc++.h>
using namespace std;
#define F0(i,n) for (int i=0; i<n; i++)
#define FR(i,n) for (int i=n-1; i>=0; i--)
#define F1(i,n) for (int i=1; i<=n; i++)
#define CL(a,x) memset(x, a, sizeof(x));
#define SZ(x) ((int)x.size())
const int inf = 1000009;
const double pi = acos(-1.0);
typedef pair<int, int> pii;
typedef long long ll;
const double EPS = 1e-9;
#define PR(x) cerr << #x << "=" << x << endl

inline ll GetTSC() {
    ll lo, hi;
    asm volatile ("rdtsc": "=a"(lo), "=d"(hi));
    return lo + (hi << 32);
}
inline double GetSeconds() {
    return GetTSC() / 2.79e9;
}

const int MAX_RAND = 1 << 30;
struct Rand {
    ll x, y, z, w, o;
    Rand(ll seed) { reseed(seed); o = 0; }
    inline void reseed(ll seed) { x = 0x498b3bc5 ^ seed; y = 0; z = 0; w = 0;  F0(i, 10) mix(); }
    inline void mix() { ll t = x ^ (x << 11); x = y; y = z; z = w; w = w ^ (w >> 19) ^ t ^ (t >> 8); }
    inline ll rand() { mix(); return x & (MAX_RAND - 1); }
    inline int nextInt(int n) { return rand() % n; }
    inline int nextInt(int L, int R) { return rand()%(R - L + 1) + L; }
    inline int nextBool() { if (o < 4) o = rand(); o >>= 2; return o & 1; }
    double nextDouble() { return rand() * 1.0 / MAX_RAND; }
};
Rand my(2019);
double saveTime;
double t_o[20];
ll c_o[20];
void Init() {
    saveTime = GetSeconds();
    F0(i, 20) t_o[i] = 0.0;
    F0(i, 20) c_o[i] = 0;
}
double Elapsed() { return GetSeconds() - saveTime; }
void Report() {
    cerr << "-------------------------------------" << endl;
    cerr << "Elapsed time: " << Elapsed() << " sec" << endl;
    double total = 0.0; F0(i, 20) { if (t_o[i] > 0) cerr << "t_o[" << i << "] = " << t_o[i] << endl; total += t_o[i]; } cerr << endl; //if (total > 0) cerr << "Total spent: " << total << endl;
    F0(i, 20) if (c_o[i] > 0) cerr << "c_o[" << i << "] = " << c_o[i] << endl;
    cerr << "-------------------------------------" << endl;
}
struct AutoTimer {
    int x;
    double t;
    AutoTimer(int x) : x(x) {
        t = Elapsed();
    }
    ~AutoTimer() {
        t_o[x] += Elapsed() - t;
    }
};
//#define AT(i) AutoTimer a##i(i)
#define AT(i)

// CONSTANTS
const int N = 1024;
const int CR = 100;
const int B = 32;
const int MAXG = 2*CR/B+10;
int n, C, R;
double X;
double bestScore, score, cscore, rscore;
vector<pii> bestSol, sol;
int r[N], w[N], h[N], ax[N], ay[N];
int cZ, checkz[N];
int tn[MAXG][MAXG], t[MAXG][MAXG][128];
pii gvalues[64], sgvalus[64];
int gn, sgn;
int curr_rem[N], curr_remn;

double area[N];
const int LOGN = 1 << 16;
double logs[LOGN];

void UpdateBest() {
    if (score > bestScore) {
        bestScore = score;
        F0(i, n) bestSol[i] = pii(ax[i], ay[i]);
    }
}

double F(double c, double r) {
    return c + r - abs(X*c - (1-X)*r);
}

int sq(int x) { return x * x; }
double sq(double x) { return x * x; }
int d2(int x1, int y1, int x2, int y2) {
    return sq(x1-x2)+sq(y1-y2);
}

void PrepG(int i) {
    int X1 = 0, Y1 = 0, X2 = 0, Y2 = 0;
    if (i < C) {
        X1 = ax[i] - r[i];
        Y1 = ay[i] - r[i];
        X2 = ax[i] + r[i];
        Y2 = ay[i] + r[i];
    } else {
        X1 = ax[i];
        Y1 = ay[i];
        X2 = ax[i] + w[i];
        Y2 = ay[i] + h[i];
    }
    X1 += CR;
    Y1 += CR;
    X2 += CR;
    Y2 += CR;
    X1 /= B;
    Y1 /= B;
    X2 /= B;
    Y2 /= B;
    gn = 1;
    gvalues[0] = pii(X1, Y1);
    if (X1 != X2) {
        gvalues[gn++] = pii(X2, Y1);
        if (Y1 != Y2) gvalues[gn++] = pii(X2, Y2);
    }
    if (Y1 != Y2) gvalues[gn++] = pii(X1, Y2);
}

void AddTValue(int x, int y, int i) {
    if (x < 0 || y < 0 || x >= MAXG || y >= MAXG) throw;
    t[x][y][tn[x][y]++] = i;
}

void RemTValue(int x, int y, int i) {
    F0(k, tn[x][y]) if (t[x][y][k] == i) {
        for (int l = k; l + 1 < tn[x][y]; l++) t[x][y][l] = t[x][y][l + 1];
        tn[x][y]--;
        return;
    }
    throw;
}

void AddT(int i) {
    PrepG(i);
    F0(g, gn) AddTValue(gvalues[g].first, gvalues[g].second, i);
}

void RemT(int i) {
    PrepG(i);
    F0(g, gn) RemTValue(gvalues[g].first, gvalues[g].second, i);
    ax[i] = inf;
}

bool int_circle_circle(int i, int j) {
    return d2(ax[i], ay[i], ax[j], ay[j]) < sq(r[i] + r[j]);
}

bool int_rect_rect(int i, int j) {
    return ax[i] < ax[j] + w[j] && ax[i] + w[i] > ax[j] &&
            ay[i] < ay[j] + h[j] && ay[i] + h[i] > ay[j];
}

bool int_circle_rect(int i, int j) {
    double dx = fabs(ax[i] - (ax[j] + w[j] / 2.0));
    double dy = fabs(ay[i] - (ay[j] + h[j] / 2.0));
    // TODO
    if (dx+EPS > w[j]/2.0 + r[i]) return false;
    if (dy+EPS > h[j]/2.0 + r[i]) return false;
    if (dx+EPS < w[j]/2.0) return true;
    if (dy+EPS < h[j]/2.0) return true;
    double cd = sq(dx-w[j]/2.0)+sq(dy-h[j]/2.0);
    return cd+EPS < sq(r[i]);
}

bool int_circle_any(int i, int j) {
    if (j < C) return int_circle_circle(i, j);
    return int_circle_rect(i, j);
}

bool int_rect_any(int i, int j) {
    if (j < C) return int_circle_rect(j, i);
    return int_rect_rect(i, j);
}

void Improve() {
    int numStages = 20;
    int itc = 1000000000;
    itc = 10000000;
    double T1 = 0.0, T2 = 16.0, T = 0.0;
    int tot = 1, acc = 0, lastStage = -1;
    double startTime = Elapsed(), endTime = TL;
    F0(iter, itc) {
        if ((iter & 255) == 0) {
            double r = 1.0 * (itc - iter) / itc;
            //double r = (endTime - Elapsed()) / (endTime - startTime);
            if (1) {
                int newStage = (1 - r) * numStages;
                if (newStage != lastStage) {
                    lastStage = newStage;
                    cerr << "St: " << newStage << " " << 100.0*acc/tot << endl;
                }
            }
            if (r <= 0) {
                PR(iter);
                break;
            }
            T = T1 + (T2 - T1) * r;
        }
        int i = my.nextInt(n);
        if (ax[i] != inf) continue;

        ax[i] = my.nextInt(2*CR+1) - CR;
        ay[i] = my.nextInt(2*CR+1) - CR;

        bool outside = false;
        if (i < C) {
            if (d2(ax[i], ay[i], 0, 0) > sq(CR - r[i])) {
                outside = true;
            }
        } else {
            if (d2(ax[i], ay[i], 0, 0) > sq(CR) ||
                d2(ax[i]+w[i], ay[i], 0, 0) > sq(CR) ||
                d2(ax[i]+w[i], ay[i]+h[i], 0, 0) > sq(CR) ||
                d2(ax[i], ay[i]+h[i], 0, 0) > sq(CR)) {
                outside = true;
            }

        }
        if (outside) {
            ax[i] = inf;
            continue;
        }
        double nc = cscore, nr = rscore;
        cZ++;
        curr_remn = 0;
        PrepG(i);
        if (i < C) {
            nc += area[i];

            if (1)
            F0(g, gn) {
                int x = gvalues[g].first, y = gvalues[g].second;
                F0(k, tn[x][y]) {
                    int j = t[x][y][k];
                    if (checkz[j] == cZ) continue;
                    checkz[j] = cZ;
                    if (int_circle_any(i, j)) {
                        curr_rem[curr_remn++] = j;
                        if (j < C) nc -= area[j]; else nr -= area[j];
                    }
                }
            }

            if (0)
            F0(j, n) if (ax[j] != inf && j != i) {
                if (j < C) {
                    if (int_circle_circle(i, j)) nc -= area[j];
                } else {
                    if (int_circle_rect(i, j)) nr -= area[j];
                }
            }
        } else {
            nr += area[i];

            if (1)
            F0(g, gn) {
                int x = gvalues[g].first, y = gvalues[g].second;
                F0(k, tn[x][y]) {
                    int j = t[x][y][k];
                    if (checkz[j] == cZ) continue;
                    checkz[j] = cZ;
                    if (int_rect_any(i, j)) {
                        curr_rem[curr_remn++] = j;
                        if (j < C) nc -= area[j]; else nr -= area[j];
                    }
                }
            }

            if (0)
            F0(j, n) if (ax[j] != inf && j != i) {
                if (j < C) {
                    if (int_circle_rect(j, i)) nc -= area[j];
                } else {
                    if (int_rect_rect(i, j)) nr -= area[j];
                }
            }
        }
        double nscore = F(nc, nr);
        double delta = nscore - score;

        tot++;
        if (delta >= 0 || delta >= -T * logs[my.nextInt(LOGN)]) {
            acc++;
            score = nscore;
            cscore = nc;
            rscore = nr;

            F0(k, curr_remn) RemT(curr_rem[k]);
            if (0) {
                if (i < C) {
                    if (1) {
                        F0(j, n) if (ax[j] != inf && j != i) {
                            if (j < C) {
                                if (int_circle_circle(i, j)) RemT(j);
                            } else {
                                if (int_circle_rect(i, j)) RemT(j);
                            }
                        }
                    }
                } else {
                    F0(j, n) if (ax[j] != inf && j != i) {
                        if (j < C) {
                            if (int_circle_rect(j, i)) RemT(j);
                        } else {
                            if (int_rect_rect(i, j)) RemT(j);
                        }
                    }
                }
            }

            AddT(i);
            UpdateBest();
        } else {
            ax[i] = inf;
        }
    }
}

void Prep() {
    F0(i, LOGN) logs[i] = -log((i+0.5)/LOGN);
}

struct TastyPizza {
vector<string> findSolution(int _C, int _R, double _X, vector<int> &aCircles, vector<pair<int, int> > &aRect) {
    Init();
    C = _C; R = _R; X = _X; n = C + R;
    PR(C); PR(R); PR(X);
    F0(i, C) {
        r[i] = aCircles[i];
        area[i] = pi * r[i] * r[i];
    }
    F0(i, R) {
        w[i + C] = aRect[i].first;
        h[i + C] = aRect[i].second;
        area[i + C] = w[i + C] * h[i + C];
    }
    bestSol.assign(C+R, pii(inf, inf));
    bestScore = 0.0;
    Prep();

    cscore = 0.0;
    rscore = 0.0;
    score = F(cscore, rscore);
    F0(i, n) ax[i] = ay[i] = inf;

    Improve();

    PR(bestScore);
    vector<string> ret;
    F0(i, C+R) if (bestSol[i].first != inf) {
        ret.push_back(to_string(bestSol[i].first) + " " + to_string(bestSol[i].second));
    } else {
        ret.push_back("NA");
    }
    Report();
    return ret;
}};

void RunVis() {
    TastyPizza prog;
    int R, C;
    double X;
    cin >> C >> R >> X;
    vector< pair<int, int> > aRect(R);
    vector<int> aCircles(C);
    for (int i=0;i<C;i++)
    {
      cin >> aCircles[i];
    }
    for (int i=0;i<R;i++)
    {
      cin >> aRect[i].first >> aRect[i].second;
    }
    vector<string> ret = prog.findSolution(C, R, X, aCircles, aRect);
    cout << ret.size() << endl;
    for (int i = 0; i < (int)ret.size(); ++i)
        cout << ret[i] << endl;
    cout.flush();
}

void RunFromSave() {
    ignore = freopen("1.txt", "r", stdin);
    RunVis();
}

void RunVisSave() {
    ignore = freopen("1.txt", "w", stdout);
    int R, C;
    double X;
    cin >> C >> R >> X;
    cout << C << " " << R << " " << X << endl;
    vector< pair<int, int> > aRect(R);
    vector<int> aCircles(C);
    for (int i=0;i<C;i++)
    {
      cin >> aCircles[i];
      cout << aCircles[i] << endl;
    }
    for (int i=0;i<R;i++)
    {
      cin >> aRect[i].first >> aRect[i].second;
      cout << aRect[i].first << " " << aRect[i].second << endl;
    }
}

int main(int argc, char* argv[]) {
#ifdef RED
    auto x = freopen("log.txt", "w", stderr); (void)x;
#endif
    (void)argv; if (argc > 1) {
        RunFromSave(); exit(0);
    }
    //RunVisSave(); exit(0);
    RunVis();

    return 0;
}
