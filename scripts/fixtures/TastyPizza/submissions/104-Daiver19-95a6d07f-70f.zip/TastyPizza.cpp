//#define SUBMISSION

#ifdef SUBMISSION
#define CHECKER_TEST
#endif
#define CHECKER_TEST
//#define RUN_ITER

#include <stdarg.h>

#include <algorithm>
#include <bitset>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <iostream>
#include <list>
#include <map>
#include <memory>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <vector>
#ifdef WIN32
#include "windows.h"
#endif

using namespace std;

void dbg(const char* fmt, ...) {
#ifndef SUBMISSION
  va_list args;
  va_start(args, fmt);
  vfprintf(stderr, fmt, args);
  va_end(args);
  fflush(stderr);
#endif
}

#ifdef max
#undef max
#endif

#ifdef min
#undef min
#endif

#define mp make_pair
#define sqr(a) ((a) * (a))

#define BIT(n, k) (((n) >> (k)) & 1)

#ifdef LOCAL_TEST
#define ASSERT(cond)              \
  if (!(cond)) {                  \
    dbg("assert %d\n", __LINE__); \
    throw 1;                      \
  }
#else
#define ASSERT(cond)
#endif

typedef pair<int, int> pi;
typedef pair<double, double> pd;
typedef unsigned long long ull;
typedef vector<int> vi;
typedef vector<vi> vvi;
typedef vector<string> vs;
typedef vector<char> vc;
typedef vector<double> vd;
typedef vector<vd> vvd;

typedef unsigned char u8;
typedef unsigned short u16;
typedef unsigned int u32;
typedef unsigned long long u64;

typedef long long i64;

#ifndef WIN32
double GetTickCountMy() {
  u64 timelo, timehi;
  __asm__ volatile("rdtsc" : "=a"(timelo), "=d"(timehi));
  return ((timehi << 32) + timelo) / 2.8e9;
}
#else
double GetTickCountMy() { return GetTickCount() / 1000.; }
#endif

double rnd() { return (double)rand() / RAND_MAX; }

#ifndef LOCAL_TEST
const double TimeLimit = 9.8;
#else
#ifndef RUN_ITER
#ifndef _DEBUG
const double TimeLimit = 7.7;
#else
const double TimeLimit = 17.7;
#endif
#else
const double TimeLimit = 10.8;
#endif
#endif

const double EPS = 1e-9;
const int BaseRadius = 100;
const int Size = 200;
const double PI = 2 * acos(0.0);

struct Point {
  Point() : x(0), y(0) {}

  Point(int x, int y) : x(x), y(y) {}

  Point& operator+=(const Point& other) {
    x += other.x;
    y += other.y;
    return *this;
  }

  bool operator!=(const Point& other) const {
    return x != other.x || y != other.y;
  }

  bool operator==(const Point& other) const {
    return x == other.x && y == other.y;
  }

  int x, y;
};

Point operator+(const Point& a, const Point& b) {
  Point res = a;
  res += b;
  return res;
}

int distSq(const Point& a, const Point& b) {
  return sqr(a.x - b.x) + sqr(a.y - b.y);
}

struct Rect {
  Rect() = default;
  Rect(int h, int w) : height(h), width(w) {}
  int height;
  int width;
  int area;
  Point origin;
  int overlap_used_id = 0;
  int id = -1;
  bool used = false;
  bool not_placeable = false;
};

struct Circle {
  Circle() = default;
  Circle(int r) : r(r) {}
  Point origin;
  double area;
  int r = -1;
  int id = -1;
  int overlap_used_id = 0;
  bool used = false;
  bool not_placeable = false;

  bool isInside(int x, int y) const {
    return sqr(origin.x - x) + sqr(origin.y - y) <= sqr(r);
  }

  bool isInside(const Circle& a) const {
    return distSq(a.origin, origin) <= sqr(r - a.r);
  }

  bool isInside(const Point& p) const { return distSq(origin, p) <= sqr(r); }

  bool isInside(const Rect& r) const {
    return isInside(r.origin) && isInside(r.origin.x, r.origin.y + r.height) &&
           isInside(r.origin.x + r.width, r.origin.y) &&
           isInside(r.origin.x + r.width, r.origin.y + r.height);
  }

  bool touchInside(const Circle& a) const {
    return r - sqrt(distSq(origin, a.origin)) - a.r < 1.5;
  }

  bool touchInside(int x, int y) const {
    return sqr(r) - distSq(origin, Point(x, y)) <= 4;
  }

  bool touchInside(const Rect& r) const {
    return touchInside(r.origin.x, r.origin.y) ||
           touchInside(r.origin.x, r.origin.y + r.height) ||
           touchInside(r.origin.x + r.width, r.origin.y) ||
           touchInside(r.origin.x + r.width, r.origin.y + r.height);
  }
};

bool overlap(const Circle& a, const Circle& b) {
  return distSq(a.origin, b.origin) < sqr(a.r + b.r);
}

bool touch(const Circle& a, const Circle& b) {
  return sqrt(distSq(a.origin, b.origin)) - a.r - b.r < 0.5;
}

bool between(int from, int to, int v) { return from <= v && v <= to; }

bool touch(const Rect& a, const Rect& b) {
  return ((a.origin.x == b.origin.x + b.width ||
           b.origin.x == a.origin.x + a.width) &&
          (between(a.origin.y, a.origin.y + a.height, b.origin.y) ||
           between(b.origin.y, b.origin.y + b.height, a.origin.y))) ||
         ((a.origin.y == b.origin.y + b.height ||
           b.origin.y == a.origin.y + a.height) &&
          (between(a.origin.x, a.origin.x + a.width, b.origin.x) ||
           between(b.origin.x, b.origin.x + b.width, a.origin.x)));
}

bool touch(const Circle& a, const Rect& b) {
  return ((a.origin.x - a.r == b.origin.x + b.width ||
           b.origin.x == a.origin.x + a.r) &&
          between(b.origin.y, b.origin.y + b.height, a.origin.y)) ||
         ((a.origin.y - a.r == b.origin.y + b.height ||
           b.origin.y == a.origin.y + a.r) &&
          between(b.origin.x, b.origin.x + b.width, a.origin.x));
}

bool touch(const Rect& b, const Circle& a) { return touch(a, b); }

// rectangle-rectangle overlap
bool overlap(const Rect& a, const Rect& b) {
  return a.origin.x < b.origin.x + b.width &&
         a.origin.x + a.width > b.origin.x &&
         a.origin.y < b.origin.y + b.height &&
         a.origin.y + a.height > b.origin.y;
}

bool overlap(const Circle& a, const Rect& b) {
  double x = abs(a.origin.x - (b.origin.x + b.width * 0.5));
  double y = abs(a.origin.y - (b.origin.y + b.height * 0.5));
  if (x + EPS > b.width * 0.5 + a.r) return false;
  if (y + EPS > b.height * 0.5 + a.r) return false;
  if (x + EPS < b.width * 0.5) return true;
  if (y + EPS < b.height * 0.5) return true;
  double cornerDist = sqr(x - b.width * 0.5) + sqr(y - b.height * 0.5);
  return cornerDist + EPS < sqr(a.r);
}

bool overlap(const Rect& a, const Circle& b) { return overlap(b, a); }

class RandomSelector {
 public:
  void init(int size) {
    cell_index_.resize(size * size + 1);
    for (int i = 0; i < size; ++i) {
      for (int j = 0; j < size; ++j) {
        int cell = i * size + j;
        cells_.push_back(cell);
        cell_index_[cell] = cells_.size() - 1;
      }
    }
    alive_count_ = select_count_ = cells_.size();
    size_ = size;
  }

  void reset() { alive_count_ = select_count_ = cells_.size(); }

  void resetToAlive() { select_count_ = alive_count_; }

  Point selectPos() {
    int cell_index = rand() % select_count_;
    int cell = cells_[cell_index];
    swapCells(cell_index, select_count_ - 1);
    --select_count_;
    return Point(cell % size_, cell / size_);
  }

  bool hasChoices() const { return select_count_ != 0; }

  bool hasPos(int x, int y) const {
    int cell = y * size_ + x;
    int cell_index = cell_index_[cell];
    return cell_index < alive_count_;
  }

  void addPos(int x, int y) {
    int cell = y * size_ + x;
    int cell_index = cell_index_[cell];
    if (cell_index < alive_count_) {
      return;
    }
    swapCells(cell_index, alive_count_);
    ++alive_count_;
    select_count_ = alive_count_;
  }

  void erasePos(int x, int y) {
    int cell = y * size_ + x;
    int cell_index = cell_index_[cell];
    if (cell_index >= alive_count_) {
      return;
    }
    swapCells(cell_index, alive_count_ - 1);
    --alive_count_;
    select_count_ = alive_count_;
  }

  void erasePos(const Point& cell_point) {
    erasePos(cell_point.x, cell_point.y);
  }

 private:
  void swapCells(int id1, int id2) {
    int c1 = cells_[id1];
    int c2 = cells_[id2];
    swap(cells_[id1], cells_[id2]);
    cell_index_[c1] = id2;
    cell_index_[c2] = id1;
  }

  int size_;
  int alive_count_;
  int select_count_;
  vi cells_;
  vi cell_index_;
};

const int MoveWeight = 80;
const int MoveDist = 5;
const double CircleFillCoef = 0.8;
const double RectFillCoef = 0.94;

const int BucketSize = 25;
const int BucketCnt =
    2 * BaseRadius / BucketSize + (2 * BaseRadius % BucketSize != 0);

class TastyPizza {
 public:
  pair<vector<Point>, vector<Point>> findSolution(const vi& circles,
                                                  const vector<pi>& rects,
                                                  double circle_weight) {
    start_time_ = GetTickCountMy();
    circle_cnt_ = circles.size();
    rect_cnt_ = rects.size();

    base_circle_ = Circle(BaseRadius);
    base_circle_.origin = Point(BaseRadius, BaseRadius);

    circle_weight_ = circle_weight;

    for (int i = 0; i < circle_cnt_; ++i) {
      circles_.emplace_back(circles[i]);
      circles_.back().id = i;
      circles_.back().area = PI * sqr(circles_.back().r);
    }
    for (int i = 0; i < rect_cnt_; ++i) {
      rects_.emplace_back(rects[i].second, rects[i].first);
      rects_.back().id = i;
      rects_.back().area = rects_.back().height * rects_.back().width;
    }

    circle_buckets_.resize(BucketCnt, vector<vector<Circle*>>(BucketCnt));
    rect_buckets_.resize(BucketCnt, vector<vector<Rect*>>(BucketCnt));

    sort(circles_.begin(), circles_.end(),
         [](const Circle& a, const Circle& b) { return a.r > b.r; });
    sort(rects_.begin(), rects_.end(), [](const Rect& a, const Rect& b) {
      return a.area > b.area ||
             (a.area == b.area &&
              abs(a.height - a.width) < abs(b.height - b.width));
    });

    // double total_area = PI * sqr(base_circle_.r);
    double total_area = 27000 + sqr(circle_weight_) * 2000;
    circle_area_fraction_ =
        total_area / (1 + circle_weight / (1 - circle_weight));
    rect_area_fraction_ = total_area - circle_area_fraction_;
    // circle_area_fraction_ =
    //    total_area / (1 / CircleFillCoef +
    //                  circle_weight / (1 - circle_weight) / RectFillCoef);
    // rect_area_fraction_ =
    //    RectFillCoef * (total_area - circle_area_fraction_ / CircleFillCoef);
    dbg("Area fractions %.5lf, %.5lf\n", circle_area_fraction_,
        rect_area_fraction_);
    int circle_area_cnt = 0;
    double circle_area_sum = 0;
    while (circle_area_cnt < circle_cnt_ &&
           circle_area_sum < circle_area_fraction_) {
      circle_area_sum += circles_[circle_area_cnt].area;
      ++circle_area_cnt;
    }
    circle_area_cnt = max(1, circle_area_cnt);

    int rect_area_cnt = 0;
    double rect_area_sum = 0;
    while (rect_area_cnt < rect_cnt_ && rect_area_sum < rect_area_fraction_) {
      rect_area_sum += rects_[rect_area_cnt].area;
      ++rect_area_cnt;
    }
    rect_area_cnt = max(1, rect_area_cnt);

    circle_choice_weight_ = circle_area_cnt;
    rect_choice_weight_ = rect_area_cnt;

    dbg("Area ratio %d/%d\n", circle_choice_weight_, rect_choice_weight_);

    selector_.init(Size + 1);
    // computePos();
    vector<Circle> best_circles = circles_;
    vector<Rect> best_rects = rects_;
    double best_score = 0;
    double circle_area, rect_area;
    double iter_start_time = GetTickCountMy();
    randomSol(best_circles, best_rects, best_score, circle_area, rect_area);
    dbg("Init score %.5lf, diff %.5lf (%.5lf) = %.5lf-%.5lf\n", best_score,
        fabs(circle_area * circle_weight_ - (1 - circle_weight_) * rect_area),
        max(circle_area * circle_weight_, (1 - circle_weight_) * rect_area) /
            min(circle_area * circle_weight_, (1 - circle_weight_) * rect_area),
        circle_area * circle_weight_, (1 - circle_weight_) * rect_area);
    double iter_time = GetTickCountMy() - iter_start_time;
    int iter = 0;
    double tot_circle_area = circle_area;
    double tot_rect_area = rect_area;
    int tot_cnt = 1;

    double curr_rect_area_f = rect_area_fraction_;
    // double curr_rect_area_f = 10;
    double delta = 0.1 * rect_area_fraction_;
    int total_iter =
        (TimeLimit - (GetTickCountMy() - start_time_ + 1.2 * iter_time)) /
        iter_time;
    double coef = pow(1. / delta, 1. / total_iter);
    dbg("Projected iter: %d, coef: %.5lf\n", total_iter, coef);

    while (GetTickCountMy() - start_time_ + 1.2 * iter_time < TimeLimit) {
      // double avg_circle_area = tot_circle_area / tot_cnt;
      // double avg_rect_area = tot_rect_area / tot_cnt;
      // double empty = total_area - avg_circle_area - avg_rect_area;
      // double rect_fill_coef = 1;
      // double circle_fill_coef =
      //    avg_circle_area / (avg_circle_area + empty -
      //                       (avg_rect_area / rect_fill_coef -
      //                       avg_rect_area));

      //// rect_area / (rect_area + rect_area / total_area * empty);
      //// double circle_fill_coef = 0.5 + rnd() * 0.5;
      //// double rect_fill_coef = 0.9 + rnd() * 0.1;
      // circle_area_fraction_ =
      //    total_area / (1 / circle_fill_coef +
      //                  circle_weight / (1 - circle_weight) / rect_fill_coef);
      // rect_area_fraction_ =
      //    rect_fill_coef *
      //    (total_area - circle_area_fraction_ / circle_fill_coef);

      double circle_w_area = circle_area * circle_weight_;
      double rect_w_area = rect_area * (1 - circle_weight_);
      // rect_area_fraction_ += delta;
      if (circle_w_area > rect_w_area) {
        double coef =
            rect_w_area < EPS ? 3 : min(3., circle_w_area / rect_w_area);
        rect_area_fraction_ += delta * coef;

      } else {
        double coef =
            circle_w_area < EPS ? 3 : min(3., rect_w_area / circle_w_area);
        rect_area_fraction_ -= delta * coef;
      }
      // double coef;
      // if (circle_w_area < rect_w_area && circle_w_area > EPS) {
      //  coef = sqrt(sqrt(rect_w_area / circle_w_area));
      //  circle_area_fraction_ *= coef;
      //  rect_area_fraction_ /= coef;
      //} else if (circle_w_area > rect_w_area && rect_w_area > EPS) {
      //  coef = sqrt(sqrt(circle_w_area / rect_w_area));
      //  circle_area_fraction_ /= coef;
      //  rect_area_fraction_ *= coef;
      //}

      // double new_c = total_area / (1 + circle_weight_ / (1 - circle_weight_))
      // /
      //               circle_area;
      // double new_r = (total_area - new_c * circle_area) / rect_area;
      // circle_area_fraction_ = new_c * circle_area;
      // rect_area_fraction_ = new_r * rect_area;

      vector<Circle> curr_circles = circles_;
      vector<Rect> curr_rects = rects_;
      double curr_score = 0;
      randomSol(curr_circles, curr_rects, curr_score, circle_area, rect_area);
       dbg("Rect area fraction %.5lf, diff %.5lf\n", rect_area_fraction_,
          max(circle_area * circle_weight_, (1 - circle_weight_) * rect_area)
          /
              min(circle_area * circle_weight_,
                  (1 - circle_weight_) * rect_area));
      if (curr_score > best_score) {
        best_score = curr_score;
        best_circles.swap(curr_circles);
        best_rects.swap(curr_rects);
        dbg("%d: Update %.5lf, diff %.5lf (%.5lf) = %.5lf-%.5lf\n", iter,
            best_score,
            fabs(circle_area * circle_weight_ -
                 (1 - circle_weight_) * rect_area),
            max(circle_area * circle_weight_,
                (1 - circle_weight_) * rect_area) /
                min(circle_area * circle_weight_,
                    (1 - circle_weight_) * rect_area),
            circle_area * circle_weight_, (1 - circle_weight_) * rect_area);
        tot_circle_area = circle_area;
        tot_rect_area = rect_area;
        curr_rect_area_f = rect_area_fraction_;
        // delta = 0.1 * rect_area_fraction_;

        //++tot_cnt;
      }
      delta *= coef;
      ++iter;
    }
    dbg("Total iter %d, score %lf\n", iter, best_score);
    return convertRes(best_circles, best_rects);
  }

 private:
  // template <typename Shape>
  // void shuffleWithStep(vector<Shape>& v, int step) {
  //  for (int i = 0; i < v.size(); i += step) {
  //    int bound = min((int)v.size(), i + step);
  //    random_shuffle(v.begin() + i, v.begin() + bound);
  //  }
  //}

  void randomSol(vector<Circle>& circles, vector<Rect>& rects, double& score,
                 double& circle_area, double& rect_area) {
    for (int i = 0; i < rects.size(); ++i) {
      int next = i;
      while (next < rects.size() && rects[i].area == rects[next].area) {
        ++next;
      }
      random_shuffle(rects.begin() + i, rects.begin() + next);
      i = next - 1;
    }

    double CircleRelax = 1 + 0.5 * rnd();
    selector_.reset();
    for (int x = 0; x <= Size; ++x) {
      for (int y = 0; y <= Size; ++y) {
        if (!base_circle_.isInside(x, y)) {
          selector_.erasePos(x, y);
        }
      }
    }

    for (auto& row : circle_buckets_) {
      for (auto& cell : row) {
        cell.clear();
      }
    }
    for (auto& row : rect_buckets_) {
      for (auto& cell : row) {
        cell.clear();
      }
    }

    int tot_weight = circle_choice_weight_ + rect_choice_weight_;

    int circle_id = 0;
    int rect_id = 0;
    circle_area = 0;
    rect_area = 0;
    vector<Rect*> init_rects;

    while (rect_id < rect_cnt_ && rect_area < rect_area_fraction_) {
      if (rect_area + rects[rect_id].area <= rect_area_fraction_) {
        findPosMinX(rects[rect_id], rect_area);
        init_rects.push_back(&rects[rect_id]);
        ++rect_id;
        break;
      }
      ++rect_id;
    }

    vector<Point> cand_origins(8);

    if (!init_rects.empty()) {
      while (rect_id < rect_cnt_ && rect_area < rect_area_fraction_) {
        if (rect_area + rects[rect_id].area > rect_area_fraction_) {
          ++rect_id;
          continue;
        }
        vector<Point> best_pos;
        int max_touches = 0;
        int max_dist_to_center = 0;
        int min_x = 1000;
        auto& rect = rects[rect_id];
        for (auto* from_rect : init_rects) {
          cand_origins[0] = Point(from_rect->origin.x,
                                  from_rect->origin.y + from_rect->height);
          cand_origins[1] =
              Point(from_rect->origin.x + from_rect->width - rect.width,
                    from_rect->origin.y + from_rect->height);

          cand_origins[2] =
              Point(from_rect->origin.x, from_rect->origin.y - rect.height);
          cand_origins[3] =
              Point(from_rect->origin.x + from_rect->width - rect.width,
                    from_rect->origin.y - rect.height);

          cand_origins[4] =
              Point(from_rect->origin.x - rect.width, from_rect->origin.y);
          cand_origins[5] =
              Point(from_rect->origin.x - rect.width,
                    from_rect->origin.y + from_rect->height - rect.height);

          cand_origins[6] = Point(from_rect->origin.x + from_rect->width,
                                  from_rect->origin.y);
          cand_origins[7] =
              Point(from_rect->origin.x + from_rect->width,
                    from_rect->origin.y + from_rect->height - rect.height);

          for (const auto& p : cand_origins) {
            rect.origin = p;
            if (base_circle_.isInside(rect) && !hasOverlaps(rect)) {
              // int touch_cnt = horVerTouchCnt(rect);
              int touch_cnt = touchCnt(rect);
              // int dist_to_center = distToCenter(rect);
              if (touch_cnt > max_touches ||
                  (touch_cnt == max_touches && p.x < min_x)) {
                // max_touches = touch_cnt;
                // max_dist_to_center = dist_to_center;
                max_touches = touch_cnt;
                min_x = p.x;
                best_pos.clear();
              }
              // if (touch_cnt == max_touches) {
              if (touch_cnt == max_touches && p.x == min_x) {
                best_pos.push_back(p);
              }
            }
          }
        }
        // if (max_touches > 3) {
        //  int t = 0;
        //}
        if (!best_pos.empty()) {
          rect.origin = best_pos[rand() % best_pos.size()];
          rect.used = true;
          rect_area += rect.area;
          removePos(rect);
          addToBuckets(rect);
          init_rects.push_back(&rect);
        }

        ++rect_id;
      }
    }

    if (circle_weight_ < 0.2) {
      while (circle_id < circle_cnt_) {
        findPos(circles[circle_id], circle_area);
        ++circle_id;
      }
    } else {
      while (circle_id < circle_cnt_) {
        findPosMinX(circles[circle_id], circle_area);
        ++circle_id;
      }
    }

    circle_id = rect_id = 0;

    // if (circle_weight_ < 0.2) {
    //  while (rect_id < rect_cnt_) {
    //    findPos(rects[rect_id], rect_area, true);
    //    ++rect_id;
    //  }
    //} else {
    while (rect_id < rect_cnt_) {
      findPosMinX(rects[rect_id], rect_area, true);
      ++rect_id;
    }
    //}

    score = getScore(circle_area, rect_area);

    // int c_used = 0, r_used = 0;
    // for (auto& c : circles) {
    //  c_used += c.used;
    //   if (!c.used) {
    //     for (int x = 0; x <= Size; ++x) {
    //       for (int y = 0; y <= Size; ++y) {
    //         c.origin = Point(x, y);
    //         if (base_circle_.isInside(c) &&
    //             !hasOverlaps(c, circles, rects, circle_cnt_, rect_cnt_)) {
    //           throw 1;
    //         }
    //       }
    //     }
    //   }
    //}
    // for (auto& r : rects) {
    //  r_used += r.used;
    //  if (!r.used) {
    //    for (int x = 0; x <= Size; ++x) {
    //      for (int y = 0; y <= Size; ++y) {
    //        r.origin = Point(x, y);
    //        if (base_circle_.isInside(r) &&
    //            !hasOverlaps(r, circles, rects, circle_cnt_, rect_cnt_)) {
    //          throw 1;
    //        }
    //      }
    //    }
    //  }
    //}
    // dbg("Used %d %d\n", c_used, r_used);
  }

  template <typename Shape>
  void findPos(Shape& shape, double& shape_area,
               bool allow_no_touches = false) {
    if (shape.used || shape.not_placeable) {
      return;
    }
    bool found = false;
    int max_touches = allow_no_touches ? -1 : 0;
    Point best_pos;
    while (selector_.hasChoices()) {
      shape.origin = selector_.selectPos();
      if (base_circle_.isInside(shape) && !hasOverlaps(shape)) {
        int touch_cnt = touchCnt(shape);
        if (touch_cnt > max_touches) {
          max_touches = touch_cnt;
          best_pos = shape.origin;
          found = true;
        }
      }
    }
    selector_.resetToAlive();
    if (found) {
      shape.origin = best_pos;
      shape.used = true;
      shape_area += shape.area;
      removePos(shape);
      addToBuckets(shape);
    } else {
      shape.not_placeable = true;
    }
  }

  void findPosMinCenterDist(Circle& shape, double& shape_area,
                            bool allow_no_touches = false) {
    if (shape.used || shape.not_placeable) {
      return;
    }
    bool found = false;
    int max_touches = allow_no_touches ? -1 : 0;
    int min_center_dist = 0x7f7f7f7f;
    Point best_pos;
    while (selector_.hasChoices()) {
      shape.origin = selector_.selectPos();
      if (base_circle_.isInside(shape) && !hasOverlaps(shape)) {
        int touch_cnt = touchCnt(shape);
        int center_dist = distSq(base_circle_.origin, shape.origin);
        if (touch_cnt > max_touches ||
            (touch_cnt == max_touches && center_dist < min_center_dist)) {
          max_touches = touch_cnt;
          best_pos = shape.origin;
          min_center_dist = center_dist;
          found = true;
        }
      }
    }
    selector_.resetToAlive();
    if (found) {
      shape.origin = best_pos;
      shape.used = true;
      shape_area += shape.area;
      removePos(shape);
      addToBuckets(shape);
    } else {
      shape.not_placeable = true;
    }
  }

  template <typename Shape>
  void findPosMinX(Shape& shape, double& shape_area,
                   bool allow_no_touches = false) {
    if (shape.used || shape.not_placeable) {
      return;
    }
    bool found = false;
    int max_touches = allow_no_touches ? -1 : 0;
    int min_x = 1000;
    Point best_pos;
    while (selector_.hasChoices()) {
      shape.origin = selector_.selectPos();
      if (base_circle_.isInside(shape) && !hasOverlaps(shape)) {
        int touch_cnt = touchCnt(shape);
        if (touch_cnt > max_touches ||
            (touch_cnt == max_touches && shape.origin.x < min_x)) {
          max_touches = touch_cnt;
          best_pos = shape.origin;
          min_x = shape.origin.x;
          found = true;
        }
      }
    }
    selector_.resetToAlive();
    if (found) {
      shape.origin = best_pos;
      shape.used = true;
      shape_area += shape.area;
      removePos(shape);
      addToBuckets(shape);
    } else {
      shape.not_placeable = true;
    }
  }

  inline double getScore(double circle_area, double rect_area) {
    return circle_area + rect_area -
           fabs(circle_area * circle_weight_ -
                rect_area * (1 - circle_weight_));
  }

  void removePos(const Circle& circle) {
    for (int x = circle.origin.x - circle.r; x < circle.origin.x + circle.r;
         ++x) {
      for (int y = circle.origin.y - circle.r; y < circle.origin.y + circle.r;
           ++y) {
        if (circle.isInside(x, y)) {
          selector_.erasePos(x, y);
        }
      }
    }
  }

  void removePos(const Rect& rect) {
    for (int x = rect.origin.x; x < rect.origin.x + rect.width; ++x) {
      for (int y = rect.origin.y; y < rect.origin.y + rect.height; ++y) {
        selector_.erasePos(x, y);
      }
    }
  }

  int touchCnt(const Circle& circle) {
    int res = 0;
    res += base_circle_.touchInside(circle);
    ++overlap_used_id_;
    int min_x, max_x, min_y, max_y;
    getBuckets(circle, min_x, max_x, min_y, max_y);
    for (int i = min_y; i <= max_y; ++i) {
      for (int j = min_x; j <= max_x; ++j) {
        res += 2 * touchCntInBucket(circle, rect_buckets_[i][j]);
        res += 4 * touchCntInBucket(circle, circle_buckets_[i][j]);
      }
    }
    return res;
  }

  int horVerTouchCnt(const Rect& rect) {
    int res = 0;
    res += base_circle_.touchInside(rect);
    ++overlap_used_id_;
    int min_x, max_x, min_y, max_y;
    getBuckets(rect, min_x, max_x, min_y, max_y);
    bool was_left = false;
    bool was_right = false;
    bool was_top = false;
    bool was_bot = false;

    for (int i = min_y; i <= max_y; ++i) {
      for (int j = min_x; j <= max_x; ++j) {
        for (auto* other_rect : rect_buckets_[i][j]) {
          if (!other_rect->used ||
              other_rect->overlap_used_id == overlap_used_id_) {
            continue;
          }
          other_rect->overlap_used_id = overlap_used_id_;
          was_left |= rect.origin.x + rect.width == other_rect->origin.x;
          was_right |=
              rect.origin.x == other_rect->origin.x + other_rect->width;

          was_top |= rect.origin.y + rect.height == other_rect->origin.y;
          was_bot |= rect.origin.y == other_rect->origin.y + other_rect->height;
        }
      }
    }
    return res + was_left + was_right + was_top + was_bot;
  }

  int distToCenter(const Rect& rect) {
    return min(
        min(distSq(rect.origin, base_circle_.origin),
            distSq(base_circle_.origin,
                   Point(rect.origin.x + rect.width, rect.origin.y))),
        min(distSq(base_circle_.origin,
                   Point(rect.origin.x, rect.origin.y + rect.height)),
            distSq(base_circle_.origin, Point(rect.origin.x + rect.width,
                                              rect.origin.y + rect.height))));
  }

  int touchCnt(const Rect& rect) {
    int res = 0;
    res += 2 * base_circle_.touchInside(rect);
    ++overlap_used_id_;
    int min_x, max_x, min_y, max_y;
    getBuckets(rect, min_x, max_x, min_y, max_y);
    for (int i = min_y; i <= max_y; ++i) {
      for (int j = min_x; j <= max_x; ++j) {
        res += 2 * touchCntInBucket(rect, rect_buckets_[i][j]);
        res += touchCntInBucket(rect, circle_buckets_[i][j]);
      }
    }
    return res;
  }

  void getCoordBucket(int from_x, int to_x, int& min_x, int& max_x) {
    min_x = max(0, from_x / BucketSize - (from_x % BucketSize == 0));
    max_x = min(BucketCnt - 1, to_x / BucketSize + (to_x % BucketSize == 0));
  }

  void getBuckets(const Circle& circle, int& min_x, int& max_x, int& min_y,
                  int& max_y) {
    getCoordBucket(circle.origin.x - circle.r, circle.origin.x + circle.r,
                   min_x, max_x);
    getCoordBucket(circle.origin.y - circle.r, circle.origin.y + circle.r,
                   min_y, max_y);
  }

  void getBuckets(const Rect& rect, int& min_x, int& max_x, int& min_y,
                  int& max_y) {
    getCoordBucket(rect.origin.x, rect.origin.x + rect.width, min_x, max_x);
    getCoordBucket(rect.origin.y, rect.origin.y + rect.height, min_y, max_y);
  }

  void addToBuckets(Circle& circle) {
    int min_x, max_x, min_y, max_y;
    getBuckets(circle, min_x, max_x, min_y, max_y);
    for (int i = min_y; i <= max_y; ++i) {
      for (int j = min_x; j <= max_x; ++j) {
        circle_buckets_[i][j].push_back(&circle);
      }
    }
  }

  void addToBuckets(Rect& rect) {
    int min_x, max_x, min_y, max_y;
    getBuckets(rect, min_x, max_x, min_y, max_y);
    for (int i = min_y; i <= max_y; ++i) {
      for (int j = min_x; j <= max_x; ++j) {
        rect_buckets_[i][j].push_back(&rect);
      }
    }
  }

  template <typename Shape>
  bool hasOverlaps(const Shape& shape) {
    ++overlap_used_id_;
    int min_x, max_x, min_y, max_y;
    getBuckets(shape, min_x, max_x, min_y, max_y);
    for (int i = min_y; i <= max_y; ++i) {
      for (int j = min_x; j <= max_x; ++j) {
        if (hasOverlapsInBucket(shape, circle_buckets_[i][j])) {
          return true;
        }
        if (hasOverlapsInBucket(shape, rect_buckets_[i][j])) {
          return true;
        }
      }
    }
    return false;
  }

  template <typename Shape, typename BucketShape>
  bool hasOverlapsInBucket(const Shape& shape, vector<BucketShape*>& bucket) {
    for (auto* other_shape : bucket) {
      if (!other_shape->used ||
          other_shape->overlap_used_id == overlap_used_id_) {
        continue;
      }
      other_shape->overlap_used_id = overlap_used_id_;
      if (overlap(shape, *other_shape)) {
        return true;
      }
    }
    return false;
  }

  template <typename Shape, typename BucketShape>
  int touchCntInBucket(const Shape& shape, vector<BucketShape*>& bucket) {
    int res = 0;
    for (auto* other_shape : bucket) {
      if (!other_shape->used ||
          other_shape->overlap_used_id == overlap_used_id_) {
        continue;
      }
      other_shape->overlap_used_id = overlap_used_id_;
      res += touch(shape, *other_shape);
    }
    return res;
  }

  pair<vector<Point>, vector<Point>> convertRes(const vector<Circle>& circles,
                                                const vector<Rect>& rects) {
    pair<vector<Point>, vector<Point>> res;
    res.first.resize(circles.size());
    res.second.resize(rects.size());
    for (const auto& c : circles) {
      if (c.used) {
        res.first[c.id] = c.origin + Point(-100, -100);
      } else {
        res.first[c.id] = Point(-100, -100);
      }
    }
    for (const auto& r : rects) {
      if (r.used) {
        res.second[r.id] = r.origin + Point(-100, -100);
      } else {
        res.second[r.id] = Point(-100, -100);
      }
    }
    return res;
  }

  int encode(int x, int y) {
    return (x + BaseRadius) * (2 * BaseRadius) + (y + BaseRadius);
  }

  vector<Circle> circles_;
  vector<Rect> rects_;

  int overlap_used_id_ = 0;
  vector<vector<vector<Circle*>>> circle_buckets_;
  vector<vector<vector<Rect*>>> rect_buckets_;

  RandomSelector selector_;
  Circle base_circle_;

  double circle_area_fraction_;
  double rect_area_fraction_;

  double circle_weight_;

  int rect_choice_weight_;
  int circle_choice_weight_;

  double start_time_;
  int circle_cnt_;
  int rect_cnt_;
};

pair<vector<Point>, vector<Point>> solutionFromInput(vi& circles,
                                                     vector<pi>& rects,
                                                     double& circle_weight,
                                                     int seed = -1) {
  if (seed != -1) {
    char buf[100] = {0};
    sprintf(buf, "seeds/%d.in", seed);
    freopen(buf, "r", stdin);
  }

  int rect_cnt, circle_cnt;
  scanf("%d%d%lf", &circle_cnt, &rect_cnt, &circle_weight);
  rects.resize(rect_cnt);
  circles.resize(circle_cnt);
  for (int i = 0; i < circle_cnt; i++) {
    scanf("%d", &circles[i]);
  }
  for (int i = 0; i < rect_cnt; i++) {
    scanf("%d%d", &rects[i].first, &rects[i].second);
  }
  TastyPizza tp;
  return tp.findSolution(circles, rects, circle_weight);
}

void checkerTest() {
  vi circles;
  vector<pi> rects;
  double circle_weight;
  auto res = solutionFromInput(circles, rects, circle_weight);
  printf("%d\n", res.first.size() + res.second.size());
  for (const auto& p : res.first) {
    if (p.x == -100) {
      printf("NA\n");
    } else {
      printf("%d %d\n", p.x, p.y);
    }
  }
  for (const auto& p : res.second) {
    if (p.x == -100) {
      printf("NA\n");
    } else {
      printf("%d %d\n", p.x, p.y);
    }
  }
  fflush(stdout);
}

#ifdef LOCAL_TEST
class Checker {
 public:
  double run(int seed) {
    vi in_circles;
    vector<pi> in_rects;
    double circle_weight;
    auto sol = solutionFromInput(in_circles, in_rects, circle_weight, seed);
    vector<CheckerCircle> circles;
    vector<CheckerRect> rects;
    for (int i = 0; i < in_circles.size(); ++i) {
      circles.emplace_back(in_circles[i]);
      if (sol.first[i].x != -100) {
        circles[i].x = sol.first[i].x;
        circles[i].y = sol.first[i].y;
      } else {
        circles[i].used = false;
      }
    }

    for (int i = 0; i < in_rects.size(); ++i) {
      rects.emplace_back(in_rects[i].second, in_rects[i].first);
      if (sol.second[i].x != -100) {
        rects[i].x = sol.second[i].x;
        rects[i].y = sol.second[i].y;
      } else {
        rects[i].used = false;
      }
    }

    int circle_cnt = circles.size();
    int rect_cnt = rects.size();
    // check that two circles don't overlap
    for (int i = 0; i < circle_cnt; i++) {
      for (int k = i + 1; k < circle_cnt; k++) {
        if (circles[i].used && circles[k].used &&
            overlap(circles[i], circles[k])) {
          dbg("circles overlap %d %d\n", i, k);
          throw 1;
        }
      }
    }

    // check that two rectangles don't overlap
    for (int i = 0; i < rect_cnt; i++) {
      for (int k = i + 1; k < rect_cnt; k++)
        if (rects[i].used && rects[k].used && overlap(rects[i], rects[k])) {
          dbg("rects overlap %d %d\n", i, k);
          throw 1;
        }
    }

    // check that circles don't overlap with rectangles
    for (int i = 0; i < circle_cnt; i++) {
      for (int k = 0; k < rect_cnt; k++) {
        if (circles[i].used && rects[k].used && overlap(circles[i], rects[k])) {
          dbg("rect-circle overlap %d %d\n", i, k);
          throw 1;
        }
      }
    }

    // check that circles don't go outside the base
    for (int i = 0; i < circle_cnt; i++) {
      if (circles[i].used) {
        if (distance2(circles[i].x, circles[i].y, 0, 0) >
            sqr(BaseRadius - circles[i].radius)) {
          dbg("bad circle coord %d\n", i);
          throw 1;
        }
      }
    }

    // check that rectangles don't go outside the base
    for (int i = 0; i < rect_cnt; i++) {
      if (rects[i].used) {
        // check all corners
        if (distance2(rects[i].x, rects[i].y, 0, 0) > sqr(BaseRadius) ||
            distance2(rects[i].x + rects[i].width, rects[i].y, 0, 0) >
                sqr(BaseRadius) ||
            distance2(rects[i].x, rects[i].y + rects[i].height, 0, 0) >
                sqr(BaseRadius) ||
            distance2(rects[i].x + rects[i].width, rects[i].y + rects[i].height,
                      0, 0) > sqr(BaseRadius)) {
          dbg("bad rect coord %d\n", i);
          throw 1;
        }
      }
    }

    // compute ingredients area
    double circle_area = 0;
    int circles_placed = 0;
    for (int i = 0; i < circle_cnt; i++) {
      if (circles[i].used) {
        circles_placed++;
        circle_area += sqr(circles[i].radius) * PI;
      }
    }

    double rect_area = 0;
    int rects_placed = 0;
    for (int i = 0; i < rect_cnt; i++) {
      if (rects[i].used) {
        rects_placed++;
        rect_area += rects[i].height * rects[i].width;
      }
    }

    double score =
        circle_area + rect_area -
        fabs(circle_weight * circle_area - (1 - circle_weight) * rect_area);
    dbg("Seed %d, score %.5lf, circles %d/%d (%.5lf), rects %d/%d(%.5lf)\n",
        seed, score, circles_placed, circle_cnt, circle_area, rects_placed,
        rect_cnt, rect_area);

    return score;
  }

 private:
  struct CheckerCircle {
    bool used = true;
    int radius;
    // center of the circle
    int x;
    int y;

    CheckerCircle(int r) { radius = r; }
  };

  struct CheckerRect {
    bool used = true;
    int height;
    int width;
    // bottom-left of the rectangle
    int x;
    int y;

    CheckerRect(int h, int w) {
      height = h;
      width = w;
    }
  };

  int distance2(int x1, int y1, int x2, int y2) {
    return sqr(x1 - x2) + sqr(y1 - y2);
  }

  // circle-circle overlap
  bool overlap(const CheckerCircle& a, const CheckerCircle& b) {
    return distance2(a.x, a.y, b.x, b.y) < sqr(a.radius + b.radius);
  }

  // rectangle-rectangle overlap
  bool overlap(const CheckerRect& a, const CheckerRect& b) {
    return a.x < b.x + b.width && a.x + a.width > b.x && a.y < b.y + b.height &&
           a.y + a.height > b.y;
  }

  bool overlap(const CheckerCircle& a, const CheckerRect& b) {
    double x = abs(a.x - (b.x + b.width * 0.5));
    double y = abs(a.y - (b.y + b.height * 0.5));
    if (x + EPS > b.width * 0.5 + a.radius) return false;
    if (y + EPS > b.height * 0.5 + a.radius) return false;
    if (x + EPS < b.width * 0.5) return true;
    if (y + EPS < b.height * 0.5) return true;
    double cornerDist = sqr(x - b.width * 0.5) + sqr(y - b.height * 0.5);
    return (cornerDist + EPS < sqr(a.radius));
  }
};

int myTest(int seed) {
  Checker checker;
  double res = checker.run(seed);
  dbg("Seed %d score: %lf\n", seed, res);
  return res;
}
#endif

int main(int argc, char* argv[]) {
  // freopen("log", "w", stderr);

#ifdef CHECKER_TEST
  checkerTest();
#else
#ifndef RUN_ITER
  int seed = 1075;
  myTest(seed);
#else
  int seed;
  sscanf(argv[1], "%d", &seed);
  int score = myTest(seed);
  printf("%d\n", score);
  fflush(stdout);
#endif
#endif
  return 0;
}