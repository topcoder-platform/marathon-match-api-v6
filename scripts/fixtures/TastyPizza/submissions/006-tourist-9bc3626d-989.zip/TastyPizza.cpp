#include <bits/stdc++.h>

using namespace std;

template <typename A, typename B>
string to_string(pair<A, B> p);

template <typename A, typename B, typename C>
string to_string(tuple<A, B, C> p);

template <typename A, typename B, typename C, typename D>
string to_string(tuple<A, B, C, D> p);

string to_string(const string& s) {
  return '"' + s + '"';
}

string to_string(const char* s) {
  return to_string((string) s);
}

string to_string(bool b) {
  return (b ? "true" : "false");
}

string to_string(vector<bool> v) {
  bool first = true;
  string res = "{";
  for (int i = 0; i < static_cast<int>(v.size()); i++) {
    if (!first) {
      res += ", ";
    }
    first = false;
    res += to_string(v[i]);
  }
  res += "}";
  return res;
}

template <size_t N>
string to_string(bitset<N> v) {
  string res = "";
  for (size_t i = 0; i < N; i++) {
    res += static_cast<char>('0' + v[i]);
  }
  return res;
}

template <typename A>
string to_string(A v) {
  bool first = true;
  string res = "{";
  for (const auto &x : v) {
    if (!first) {
      res += ", ";
    }
    first = false;
    res += to_string(x);
  }
  res += "}";
  return res;
}

template <typename A, typename B>
string to_string(pair<A, B> p) {
  return "(" + to_string(p.first) + ", " + to_string(p.second) + ")";
}

template <typename A, typename B, typename C>
string to_string(tuple<A, B, C> p) {
  return "(" + to_string(get<0>(p)) + ", " + to_string(get<1>(p)) + ", " + to_string(get<2>(p)) + ")";
}

template <typename A, typename B, typename C, typename D>
string to_string(tuple<A, B, C, D> p) {
  return "(" + to_string(get<0>(p)) + ", " + to_string(get<1>(p)) + ", " + to_string(get<2>(p)) + ", " + to_string(get<3>(p)) + ")";
}

void debug_out() { cerr << endl; }

template <typename Head, typename... Tail>
void debug_out(Head H, Tail... T) {
  cerr << " " << to_string(H);
  debug_out(T...);
}

#ifdef LOCAL
#define debug(...) cerr << "[" << #__VA_ARGS__ << "]:", debug_out(__VA_ARGS__)
#else
#define debug(...) 42
#endif

class TastyPizza 
{
public:
  vector<string> findSolution(int C, int R, double X, vector<int> &aCircles, vector<pair<int, int> > &aRect)
  { 
    vector<string> ret(C + R, "NA");
    const int MAX = 200;
    vector<vector<int>> grid(MAX, vector<int>(MAX));
    for (int i = 0; i < MAX; i++) {
      for (int j = 0; j < MAX; j++) {
        int x = max(abs(i - 100), abs(i - 100 + 1));
        int y = max(abs(j - 100), abs(j - 100 + 1));
        if (x * x + y * y > 100 * 100) {
          grid[i][j] = 1;
        }
      }
    }
    vector<vector<int>> sum(MAX + 1, vector<int>(MAX + 1));
    auto Calc = [&]() {
      for (int i = 0; i < MAX; i++) {
        for (int j = 0; j < MAX; j++) {
          sum[i + 1][j + 1] = sum[i + 1][j] + sum[i][j + 1] - sum[i][j] + grid[i][j];
        }
      }
    };
    Calc();
    auto Sum = [&](int i1, int j1, int i2, int j2) {
      return sum[i2 + 1][j2 + 1] - sum[i2 + 1][j1] - sum[i1][j2 + 1] + sum[i1][j1];
    };
    for (int id = 0; id < R; id++) {
      int w = aRect[id].first;
      int h = aRect[id].second;
      int value = -1;
      int bi = -1;
      int bj = -1;
      for (int i = 0; i <= MAX - w; i++) {
        for (int j = 0; j <= MAX - h; j++) {
          if (Sum(i, j, i + w - 1, j + h - 1) == 0) {
            int cur = Sum(i - 1, j - 1, i + w, j + h);
            if (cur > value) {
              value = cur;
              bi = i;
              bj = j;
            }
          }
        }
      }
      if (value == -1) {
        continue;
      }
      ret[C + id] = to_string(bi - 100) + " " + to_string(bj - 100);
      for (int i = bi; i <= bi + w - 1; i++) {
        for (int j = bj; j <= bj + h - 1; j++) {
          assert(grid[i][j] == 0);
          grid[i][j] = 1;
        }
      }
      Calc();
    }
    return ret; 
  }
};

int main() 
{
  TastyPizza prog;
  int R, C;
  double X;
  cin >> C >> R >> X;
  vector< pair<int, int> > aRect(R);
  vector<int> aCircles(C);
  for (int i=0;i<C;i++)
  {
    cin >> aCircles[i];
  }
  for (int i=0;i<R;i++)
  {
    cin >> aRect[i].first >> aRect[i].second;
  }
  vector<string> ret = prog.findSolution(C, R, X, aCircles, aRect);
  cout << ret.size() << endl;
  for (int i = 0; i < (int)ret.size(); ++i)
      cout << ret[i] << endl;
  cout.flush();
}