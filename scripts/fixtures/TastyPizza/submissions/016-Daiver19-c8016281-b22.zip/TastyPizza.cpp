//#define SUBMISSION

#ifdef SUBMISSION
#define CHECKER_TEST
#endif
#define CHECKER_TEST
//#define RUN_ITER

#include <stdarg.h>

#include <algorithm>
#include <bitset>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <iostream>
#include <list>
#include <map>
#include <memory>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <vector>
#ifdef WIN32
#include "windows.h"
#endif

using namespace std;

void dbg(const char* fmt, ...) {
#ifndef SUBMISSION
  va_list args;
  va_start(args, fmt);
  vfprintf(stderr, fmt, args);
  va_end(args);
  fflush(stderr);
#endif
}

#ifdef max
#undef max
#endif

#ifdef min
#undef min
#endif

#define mp make_pair
#define sqr(a) ((a) * (a))

#define BIT(n, k) (((n) >> (k)) & 1)

#ifdef LOCAL_TEST
#define ASSERT(cond)              \
  if (!(cond)) {                  \
    dbg("assert %d\n", __LINE__); \
    throw 1;                      \
  }
#else
#define ASSERT(cond)
#endif

typedef pair<int, int> pi;
typedef pair<double, double> pd;
typedef unsigned long long ull;
typedef vector<int> vi;
typedef vector<vi> vvi;
typedef vector<string> vs;
typedef vector<char> vc;
typedef vector<double> vd;
typedef vector<vd> vvd;

typedef unsigned char u8;
typedef unsigned short u16;
typedef unsigned int u32;
typedef unsigned long long u64;

typedef long long i64;

#ifndef WIN32
double GetTickCountMy() {
  u64 timelo, timehi;
  __asm__ volatile("rdtsc" : "=a"(timelo), "=d"(timehi));
  return ((timehi << 32) + timelo) / 2.8e9;
}
#else
double GetTickCountMy() { return GetTickCount() / 1000.; }
#endif

double rnd() { return (double)rand() / RAND_MAX; }

#ifndef LOCAL_TEST
const double TimeLimit = 9.8;
#else
#ifndef RUN_ITER
const double TimeLimit = 7.7;
#else
const double TimeLimit = 10.8;
#endif
#endif

const double EPS = 1e-9;
const int BaseRadius = 100;
const int Size = 200;
const double PI = 2 * acos(0.0);
const int Margin = 2;

struct Point {
  Point() : x(0), y(0) {}

  Point(int x, int y) : x(x), y(y) {}

  Point& operator+=(const Point& other) {
    x += other.x;
    y += other.y;
    return *this;
  }

  bool operator!=(const Point& other) const {
    return x != other.x || y != other.y;
  }

  bool operator==(const Point& other) const {
    return x == other.x && y == other.y;
  }

  int x, y;
};

Point operator+(const Point& a, const Point& b) {
  Point res = a;
  res += b;
  return res;
}

int distSq(const Point& a, const Point& b) {
  return sqr(a.x - b.x) + sqr(a.y - b.y);
}

struct Rect {
  Rect() = default;
  Rect(int h, int w) : height(h), width(w) {}
  int height;
  int width;
  double area;
  Point corner;
  int id = -1;
  bool used = false;
};

struct Circle {
  Circle() = default;
  Circle(int r) : r(r) {}
  Point center;
  double area;
  int r = -1;
  int id = -1;
  bool used = false;

  bool isInside(int x, int y) const {
    return sqr(center.x - x) + sqr(center.y - y) <= sqr(r);
  }

  bool isInside(const Circle& a) const {
    return distSq(a.center, center) <= sqr(r - a.r);
  }

  bool isInside(const Point& p) const { return distSq(center, p) <= sqr(r); }

  bool isInside(const Rect& r) const {
    return isInside(r.corner) && isInside(r.corner.x, r.corner.y + r.height) &&
           isInside(r.corner.x + r.width, r.corner.y) &&
           isInside(r.corner.x + r.width, r.corner.y + r.height);
  }
};

bool overlap(const Circle& a, const Circle& b) {
  return distSq(a.center, b.center) < sqr(a.r + b.r);
}

// rectangle-rectangle overlap
bool overlap(const Rect& a, const Rect& b) {
  return a.corner.x < b.corner.x + b.width &&
         a.corner.x + a.width > b.corner.x &&
         a.corner.y < b.corner.y + b.height &&
         a.corner.y + a.height > b.corner.y;
}

bool overlap(const Circle& a, const Rect& b) {
  double x = abs(a.center.x - (b.corner.x + b.width * 0.5));
  double y = abs(a.center.y - (b.corner.y + b.height * 0.5));
  if (x + EPS > b.width * 0.5 + a.r) return false;
  if (y + EPS > b.height * 0.5 + a.r) return false;
  if (x + EPS < b.width * 0.5) return true;
  if (y + EPS < b.height * 0.5) return true;
  double cornerDist = sqr(x - b.width * 0.5) + sqr(y - b.height * 0.5);
  return cornerDist + EPS < sqr(a.r);
}

class RandomSelector {
 public:
  void init(int size) {
    cell_index_.resize(size * size + 1);
    for (int i = 0; i < size; ++i) {
      for (int j = 0; j < size; ++j) {
        int cell = i * size + j;
        cells_.push_back(cell);
        cell_index_[cell] = cells_.size() - 1;
      }
    }
    alive_count_ = select_count_ = cells_.size();
    size_ = size;
  }

  void reset() { alive_count_ = select_count_ = cells_.size(); }

  void resetToAlive() { select_count_ = alive_count_; }

  Point selectPos() {
    int cell_index = rand() % select_count_;
    int cell = cells_[cell_index];
    swapCells(cell_index, select_count_ - 1);
    --select_count_;
    return Point(cell % size_, cell / size_);
  }

  bool hasChoices() const { return select_count_ != 0; }

  void erasePos(int x, int y) {
    int cell = y * size_ + x;
    int cell_index = cell_index_[cell];
    if (cell_index >= alive_count_) {
      return;
    }
    swapCells(cell_index, alive_count_ - 1);
    --alive_count_;
    select_count_ = alive_count_;
  }

  void erasePos(const Point& cell_point) {
    erasePos(cell_point.x, cell_point.y);
  }

 private:
  void swapCells(int id1, int id2) {
    int c1 = cells_[id1];
    int c2 = cells_[id2];
    swap(cells_[id1], cells_[id2]);
    cell_index_[c1] = id2;
    cell_index_[c2] = id1;
  }

  int size_;
  int alive_count_;
  int select_count_;
  vi cells_;
  vi cell_index_;
};

class TastyPizza {
 public:
  pair<vector<Point>, vector<Point>> findSolution(const vi& circles,
                                                  const vector<pi>& rects,
                                                  double circle_weight) {
    start_time_ = GetTickCountMy();
    circle_cnt_ = circles.size();
    rect_cnt_ = rects.size();
    circle_weight_ = circle_weight;

    base_circle_ = Circle(BaseRadius);
    base_circle_.center = Point(BaseRadius, BaseRadius);

    double rects_per_circle = circle_weight_ / (1 - circle_weight);
    double circles_per_rect = 1 / rects_per_circle;
    if (rects_per_circle < 1) {
      rects_per_circle_ = 0;
      circles_per_rect_ = max(1, (int)ceil(circles_per_rect));
    } else {
      rects_per_circle_ = max(1, (int)ceil(rects_per_circle));
      circles_per_rect_ = 0;
    }

    dbg("Rects-per-circle: %d(%d)\n", rects_per_circle_, circles_per_rect_);

    for (int i = 0; i < circle_cnt_; ++i) {
      circles_.emplace_back(circles[i]);
      circles_.back().id = i;
      circles_.back().area = PI * sqr(circles_.back().r);
    }
    for (int i = 0; i < rect_cnt_; ++i) {
      rects_.emplace_back(rects[i].second, rects[i].first);
      rects_.back().id = i;
      rects_.back().area = rects_.back().height * rects_.back().width;
    }
    selector_.init(Size + 1);
    // computePos();
    vector<Circle> best_circles = circles_;
    vector<Rect> best_rects = rects_;
    double best_score = 0;
    randomSol(best_circles, best_rects, best_score);
    int iter = 0;
    while (GetTickCountMy() - start_time_ < TimeLimit) {
      vector<Circle> curr_circles = circles_;
      vector<Rect> curr_rects = rects_;
      double curr_score = 0;
      if (curr_score > best_score) {
        best_score = curr_score;
        best_circles.swap(curr_circles);
        best_rects.swap(curr_rects);
      }
      ++iter;
    }
    dbg("Total iter %d, score %lf\n", iter, best_score);
    //solve(best_circles, best_rects, best_score);
    return convertRes(best_circles, best_rects);
  }

 private:
  void randomSol(vector<Circle>& circles, vector<Rect>& rects, double& score) {
    // random_shuffle(circles.begin(), circles.end());
    // random_shuffle(rects.begin(), rects.end());

    selector_.reset();
    for (int x = 0; x <= Size; ++x) {
      for (int y = 0; y <= Size; ++y) {
        if (!base_circle_.isInside(x, y) || x < Margin || y < Margin ||
            x > Size - Margin || y > Size - Margin) {
          selector_.erasePos(x, y);
        }
      }
    }

    int circle_step = rects_per_circle_ > 0 ? 1 : circles_per_rect_;
    int rect_step = circles_per_rect_ > 0 ? 1 : rects_per_circle_;
    int circle_id = 0;
    int rect_id = 0;
    double circle_area = 0;
    double rect_area = 0;
    while (circle_id < circle_cnt_ || rect_id < rect_cnt_) {
      for (int i = 0; i < circle_step; ++i) {
        if (circle_id + i >= circle_cnt_) {
          break;
        }
        auto& circle = circles[circle_id];
        bool found = false;
        while (selector_.hasChoices()) {
          circle.center = selector_.selectPos();
          if (base_circle_.isInside(circle) &&
              !hasOverlaps(circle, circles, rects, circle_id, rect_id)) {
            found = true;
            break;
          }
        }
        selector_.resetToAlive();
        if (found) {
          circle.used = true;
          circle_area += circle.area;
          removePos(circle);
        }
        ++circle_id;
      }

      for (int i = 0; i < rect_step; ++i) {
        if (rect_id + i >= rect_cnt_) {
          break;
        }
        auto& rect = rects[rect_id];
        bool found = false;
        if (rect_id == 4) {
          int t = 0;
        }
        while (selector_.hasChoices()) {
          rect.corner = selector_.selectPos();
          if (base_circle_.isInside(rect) &&
              !hasOverlaps(rect, circles, rects, circle_id, rect_id)) {
            found = true;
            break;
          }
        }
        selector_.resetToAlive();
        if (found) {
          rect.used = true;
          rect_area += rect.area;
          removePos(rect);
        }
        ++rect_id;
      }
    }
    score = getScore(circle_area, rect_area);
  }

  inline double getScore(double circle_area, double rect_area) {
    return circle_area + rect_area -
           fabs(circle_area * circle_weight_ -
                rect_area * (1 - circle_weight_));
  }

  void removePos(const Circle& circle) {
    Circle bounding_circle = circle;
    bounding_circle.r += Margin;
    int min_x = max(0, bounding_circle.center.x - bounding_circle.r);
    int min_y = max(0, bounding_circle.center.y - bounding_circle.r);
    int max_x = min(Size, bounding_circle.center.x + bounding_circle.r);
    int max_y = min(Size, bounding_circle.center.y + bounding_circle.r);
    for (int x = min_x; x <= max_x; ++x) {
      for (int y = min_y; y <= max_y; ++y) {
        if (bounding_circle.isInside(x, y)) {
          selector_.erasePos(x, y);
        }
      }
    }
  }

  void removePos(const Rect& rect) {
    int h = rect.height + Margin;
    int w = rect.width + Margin;
    int min_x = max(0, rect.corner.x - Margin);
    int min_y = max(0, rect.corner.y - Margin);
    int max_x = min(Size, rect.corner.x + h);
    int max_y = min(Size, rect.corner.y + w);
    for (int x = min_x; x <= max_x; ++x) {
      for (int y = min_y; y <= max_y; ++y) {
        selector_.erasePos(x, y);
      }
    }
  }

  template <typename Shape>
  bool hasOverlaps(const Shape& shape, const vector<Circle>& circles,
                   const vector<Rect>& rects, int max_circle_id,
                   int max_rect_id) {
    for (int circle_id = 0; circle_id < max_circle_id; ++circle_id) {
      if (overlap(circles[circle_id], shape)) {
        return true;
      }
    }
    for (int rect_id = 0; rect_id < max_rect_id; ++rect_id) {
      if (overlap(shape, rects[rect_id])) {
        return true;
      }
    }
    return false;
  }

  void solve(vector<Circle>& best_circles, vector<Rect>& best_rects,
             double& best_score) {
    const double InitTemp = 5;
    const double Coef = 0.9995;
    double coef = 1. / Coef;
    double temp = 1. / InitTemp;

    best_circles = circles_;
    best_rects = rects_;

    randomSol(best_circles, best_rects, best_score);

    best_score = 0;
    double curr_score = 0;
    double curr_circle_area = 0;
    double curr_rect_area = 0;

    auto curr_circles = best_circles;
    auto curr_rects = best_rects;

    int accepted = 0;
    int iter = 0;
    int no_change = 0;

    // TODO: use circle_weight too
    int tot_shapes = circle_cnt_ + rect_cnt_;

    // while (GetTickCountMy() - start_time_ < TimeLimit) {
    //  bool is_circle = rand() % tot_shapes < circle_cnt_;
    //  int curr_id = is_circle ? rand() % circle_cnt_ : rand() % rect_cnt_;

    //  int new_score;

    //  no_change += !was_change;

    //  int delta = new_score - curr_score;
    //  if (delta < 0 || rnd() < exp(-delta * temp)) {
    //    ++accepted;
    //    curr_res = new_res;
    //    if (curr_score < best_score) {
    //      best_res = curr_res;
    //      best_score = curr_score;
    //      dbg("Update %d, %lf: %d\n", iter, 1. / temp, best_score);
    //    }
    //  }
    //  temp *= coef;
    //  ++iter;
    //}
    // dbg("Final score: %d\n", best_score);
    // dbg("Total iter: %d, accepted %d, no change %d\n", iter, accepted,
    //    no_change);
  }

  pair<vector<Point>, vector<Point>> convertRes(const vector<Circle>& circles,
                                                const vector<Rect>& rects) {
    pair<vector<Point>, vector<Point>> res;
    res.first.resize(circles.size());
    res.second.resize(rects.size());
    for (const auto& c : circles) {
      if (c.used) {
        res.first[c.id] = c.center + Point(-100, -100);
      } else {
        res.first[c.id] = Point(-100, -100);
      }
    }
    for (const auto& r : rects) {
      if (r.used) {
        res.second[r.id] = r.corner + Point(-100, -100);
      } else {
        res.second[r.id] = Point(-100, -100);
      }
    }
    return res;
  }

  // void computePos() {
  // circle_pos_.resize(circle_cnt_);
  // rect_pos_.resize(rect_cnt_);

  // for (auto& v : circle_pos_) {
  //  v.reserve(25000);
  //}
  // for (auto& v : rect_pos_) {
  //  v.reserve(25000);
  //}
  // inside_circle_.resize(Size + 1, vc(Size + 1));
  // for (int x = Margin; x <= Size - Margin; ++x) {
  //  for (int y = Margin; y <= Size - Margin; ++y) {
  //    Point curr(x, y);
  //    if (!isInside(curr)) {
  //      continue;
  //    }
  //    inside_circle_[y][x] = true;
  //  bool was = false;
  //  for (int i = 0; i < circle_cnt_; ++i) {
  //    circles_[i].center = curr;
  //    if (isInside(circles_[i])) {
  //      circle_pos_[i].emplace_back(curr);
  //      was = true;
  //    }
  //  }
  //  for (int i = 0; i < rect_cnt_; ++i) {
  //    rects_[i].corner = curr;
  //    if (isInside(rects_[i])) {
  //      rect_pos_[i].emplace_back(curr);
  //      was = true;
  //    }
  //  }
  //  inside_circle_[y][x] = true;
  //}
  //}
  //}

  int encode(int x, int y) {
    return (x + BaseRadius) * (2 * BaseRadius) + (y + BaseRadius);
  }

  vector<Circle> circles_;
  vector<Rect> rects_;

  // vector<vector<char>> inside_circle_;
  // vector<vector<Point>> circle_pos_;
  // vector<vector<Point>> rect_pos_;

  RandomSelector selector_;
  Circle base_circle_;

  double circle_weight_;
  int rects_per_circle_;
  int circles_per_rect_;

  double start_time_;
  int circle_cnt_;
  int rect_cnt_;
};

pair<vector<Point>, vector<Point>> solutionFromInput(vi& circles,
                                                     vector<pi>& rects,
                                                     double& circle_weight,
                                                     int seed = -1) {
  if (seed != -1) {
    char buf[100] = {0};
    sprintf(buf, "seeds/%d.in", seed);
    freopen(buf, "r", stdin);
  }

  int rect_cnt, circle_cnt;
  scanf("%d%d%lf", &circle_cnt, &rect_cnt, &circle_weight);
  rects.resize(rect_cnt);
  circles.resize(circle_cnt);
  for (int i = 0; i < circle_cnt; i++) {
    scanf("%d", &circles[i]);
  }
  for (int i = 0; i < rect_cnt; i++) {
    scanf("%d%d", &rects[i].first, &rects[i].second);
  }
  TastyPizza tp;
  return tp.findSolution(circles, rects, circle_weight);
}

void checkerTest() {
  vi circles;
  vector<pi> rects;
  double circle_weight;
  auto res = solutionFromInput(circles, rects, circle_weight);
  printf("%d\n", res.first.size() + res.second.size());
  for (const auto& p : res.first) {
    if (p.x == -100) {
      printf("NA\n");
    } else {
      printf("%d %d\n", p.x, p.y);
    }
  }
  for (const auto& p : res.second) {
    if (p.x == -100) {
      printf("NA\n");
    } else {
      printf("%d %d\n", p.x, p.y);
    }
  }
  fflush(stdout);
}

#ifdef LOCAL_TEST
class Checker {
 public:
  double run(int seed) {
    vi in_circles;
    vector<pi> in_rects;
    double circle_weight;
    auto sol = solutionFromInput(in_circles, in_rects, circle_weight, seed);
    vector<CheckerCircle> circles;
    vector<CheckerRect> rects;
    for (int i = 0; i < in_circles.size(); ++i) {
      circles.emplace_back(in_circles[i]);
      if (sol.first[i].x != -100) {
        circles[i].x = sol.first[i].x;
        circles[i].y = sol.first[i].y;
      } else {
        circles[i].used = false;
      }
    }

    for (int i = 0; i < in_rects.size(); ++i) {
      rects.emplace_back(in_rects[i].second, in_rects[i].first);
      if (sol.second[i].x != -100) {
        rects[i].x = sol.second[i].x;
        rects[i].y = sol.second[i].y;
      } else {
        rects[i].used = false;
      }
    }

    int circle_cnt = circles.size();
    int rect_cnt = rects.size();
    // check that two circles don't overlap
    for (int i = 0; i < circle_cnt; i++) {
      for (int k = i + 1; k < circle_cnt; k++) {
        if (circles[i].used && circles[k].used &&
            overlap(circles[i], circles[k])) {
          dbg("circles overlap %d %d\n", i, k);
          throw 1;
        }
      }
    }

    // check that two rectangles don't overlap
    for (int i = 0; i < rect_cnt; i++) {
      for (int k = i + 1; k < rect_cnt; k++)
        if (rects[i].used && rects[k].used && overlap(rects[i], rects[k])) {
          dbg("rects overlap %d %d\n", i, k);
          throw 1;
        }
    }

    // check that circles don't overlap with rectangles
    for (int i = 0; i < circle_cnt; i++) {
      for (int k = 0; k < rect_cnt; k++) {
        if (circles[i].used && rects[k].used && overlap(circles[i], rects[k])) {
          dbg("rect-circle overlap %d %d\n", i, k);
          throw 1;
        }
      }
    }

    // check that circles don't go outside the base
    for (int i = 0; i < circle_cnt; i++) {
      if (circles[i].used) {
        if (distance2(circles[i].x, circles[i].y, 0, 0) >
            sqr(BaseRadius - circles[i].radius)) {
          dbg("bad circle coord %d\n", i);
          throw 1;
        }
      }
    }

    // check that rectangles don't go outside the base
    for (int i = 0; i < rect_cnt; i++) {
      if (rects[i].used) {
        // check all corners
        if (distance2(rects[i].x, rects[i].y, 0, 0) > sqr(BaseRadius) ||
            distance2(rects[i].x + rects[i].width, rects[i].y, 0, 0) >
                sqr(BaseRadius) ||
            distance2(rects[i].x, rects[i].y + rects[i].height, 0, 0) >
                sqr(BaseRadius) ||
            distance2(rects[i].x + rects[i].width, rects[i].y + rects[i].height,
                      0, 0) > sqr(BaseRadius)) {
          dbg("bad rect coord %d\n", i);
          throw 1;
        }
      }
    }

    // compute ingredients area
    double circle_area = 0;
    int circles_placed = 0;
    for (int i = 0; i < circle_cnt; i++) {
      if (circles[i].used) {
        circles_placed++;
        circle_area += sqr(circles[i].radius) * PI;
      }
    }

    double rect_area = 0;
    int rects_placed = 0;
    for (int i = 0; i < rect_cnt; i++) {
      if (rects[i].used) {
        rects_placed++;
        rect_area += rects[i].height * rects[i].width;
      }
    }

    double score =
        circle_area + rect_area -
        fabs(circle_weight * circle_area - (1 - circle_weight) * rect_area);
    dbg("Seed %d, score %.5lf, circles %d/%d (%.5lf), rects %d/%d(%.5lf)\n",
        seed, score, circles_placed, circle_cnt, circle_area, rects_placed,
        rect_cnt, rect_area);

    return score;
  }

 private:
  struct CheckerCircle {
    bool used = true;
    int radius;
    // center of the circle
    int x;
    int y;

    CheckerCircle(int r) { radius = r; }
  };

  struct CheckerRect {
    bool used = true;
    int height;
    int width;
    // bottom-left of the rectangle
    int x;
    int y;

    CheckerRect(int h, int w) {
      height = h;
      width = w;
    }
  };

  int distance2(int x1, int y1, int x2, int y2) {
    return sqr(x1 - x2) + sqr(y1 - y2);
  }

  // circle-circle overlap
  bool overlap(const CheckerCircle& a, const CheckerCircle& b) {
    return distance2(a.x, a.y, b.x, b.y) < sqr(a.radius + b.radius);
  }

  // rectangle-rectangle overlap
  bool overlap(const CheckerRect& a, const CheckerRect& b) {
    return a.x < b.x + b.width && a.x + a.width > b.x && a.y < b.y + b.height &&
           a.y + a.height > b.y;
  }

  bool overlap(const CheckerCircle& a, const CheckerRect& b) {
    double x = abs(a.x - (b.x + b.width * 0.5));
    double y = abs(a.y - (b.y + b.height * 0.5));
    if (x + EPS > b.width * 0.5 + a.radius) return false;
    if (y + EPS > b.height * 0.5 + a.radius) return false;
    if (x + EPS < b.width * 0.5) return true;
    if (y + EPS < b.height * 0.5) return true;
    double cornerDist = sqr(x - b.width * 0.5) + sqr(y - b.height * 0.5);
    return (cornerDist + EPS < sqr(a.radius));
  }
};

int myTest(int seed) {
  Checker checker;
  double res = checker.run(seed);
  dbg("Seed %d score: %lf\n", seed, res);
  return res;
}
#endif

int main(int argc, char* argv[]) {
  // freopen("log", "w", stderr);

#ifdef CHECKER_TEST
  checkerTest();
#else
#ifndef RUN_ITER
  int seed = 1;
  myTest(seed);
#else
  int seed;
  sscanf(argv[1], "%d", &seed);
  int score = myTest(seed);
  printf("%d\n", score);
  fflush(stdout);
#endif
#endif
  return 0;
}