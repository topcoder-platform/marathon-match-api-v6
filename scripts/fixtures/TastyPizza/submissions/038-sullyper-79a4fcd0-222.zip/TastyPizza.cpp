// C++11
#include <bits/stdc++.h>
#include <sys/time.h>

#ifdef LOCAL
#include "../headers/logger.hpp"
// #include "../TCClient.hpp"
#define LOG_TC(...) LOG_INFO(__VA_ARGS__);
void Initialize(int argc, char** argv);
#else
void Initialize(int argc, char** argv) {}
#define SHOW(...);
#define LOG_DEBUG(...);
#define LOG_INFO(...);
#define LOG_WARNING(...);
#define LOG_ERROR(...);
#define LOG_TC(...) {fprintf(stderr, __VA_ARGS__);fprintf(stderr, "\n"); }
#define PANIC(...);
#define ASSERT(...);
#endif

#ifdef USEPROFILER
#include "../headers/Profiler.hpp"
#else
#define PROFILER_VAR(var, name);
#define PROFILER(name);
#endif

static inline double get_time() {
  timeval tv;
  gettimeofday(&tv, 0);
  return tv.tv_sec + tv.tv_usec * 1e-6;
}

// Need calibration
static inline double get_fast_time() {
  unsigned long long timelo, timehi;
  __asm__ volatile("rdtsc" : "=a"(timelo), "=d"(timehi));
  return ((timehi << 32) + timelo) * 3.5714286e-10;
}

const double END_TIME = 9.5;
double start_time = get_time();
double end_time = start_time + END_TIME;
double final_limit = start_time + 9.95;

class FastMap { public:
  FastMap(){size_ = 0; std::fill(&pos_[0], &pos_[512], -1); }
  void clear() { while (size_) { pos_[taken_[--size_]] = -1; }}
  inline void safeInsert(int v) { if (has(v)) return; insert(v);}
  inline void insert(int v) { taken_[pos_[v] = size_++] = v; }
  inline void push_back(int v) { taken_[pos_[v] = size_++] = v; }
  inline void pop_back() { pos_[taken_[--size_]] = -1; }
  inline int back() { return taken_[size_-1]; }
  inline void erase(int v) {
    const int p = pos_[v];
    const int last = taken_[--size_];
    pos_[last] = p;
    taken_[p] = last;
    pos_[v] = -1;
  }
  inline int operator[](int i) { return taken_[i]; }
  inline void safeErase(int v) { if (has(v)) erase(v); }
  inline bool has(int v) { return pos_[v] >= 0; }
  std::vector<int> toVector() {
    std::vector<int> ret;
    ret.insert(ret.begin(), begin(), end());
    return ret;
  }
  inline int size() { return size_; }
  inline bool empty() { return size_ == 0; }
  inline int* begin() { return &taken_[0]; }
  inline int* end() { return &taken_[size_]; }

 private:
  std::array<int, 512> pos_;
  std::array<int, 512> taken_;
  int size_;
};

struct rand_gen {
  static constexpr uint32_t kMax = 2147483647;
  static constexpr double kInvMax = 1.0 / (double)kMax;
  static constexpr __uint128_t kAdd = 0x60bee2bee120fc15ull;
  static constexpr __uint128_t kMul1 = 0xa3b195354a39b70dull;
  static constexpr __uint128_t kMul2 = 0x1b03738712fad5c9ull;
  uint64_t state = 7;
  inline void seed(uint64_t seed) { state = seed; }
  inline uint32_t next_int() {
    state += kAdd; __uint128_t tmp = (__uint128_t)state * kMul1;
    uint64_t m1 = (tmp >> 64) ^ tmp; tmp = (__uint128_t)m1 * kMul2;
    uint64_t m2 = (tmp >> 64) ^ tmp; return (uint32_t)m2;
  }
  inline uint32_t next_int(uint32_t max) { return next_int()%max; }
  inline uint32_t next_int(uint32_t min, uint32_t max) { return min + (next_int()%(max-min)); }
  inline double next_float() { return next_int(kMax) * kInvMax; }
} rng;
inline int Square(int a) { return a*a; }

int numRectangles, numCircles;
double X;

constexpr int kMinRadius = 5;
constexpr int kMaxRadius = 15;
constexpr int kOffsite = -4242;
constexpr int kPizza = 100;
constexpr int kMaxSize = 11;
constexpr int kGridSize = kPizza / kMaxSize + 1;
constexpr int kSquaredPizza = kPizza*kPizza;
double circle_area = 0.0;
double rectangle_area = 0.0;
double best_score = -1.0;

inline double Score() {
  return circle_area + rectangle_area - std::abs(circle_area * X - (1.0 - X) * rectangle_area);
}

struct Rectangle {
  int rows, cols;
  int row = kOffsite, col = kOffsite;
  double area_;
  inline bool valid(int row, int col) const {
    return Square(row) + Square(col) <= kSquaredPizza && Square(row+rows) + Square(col+cols) <= kSquaredPizza &&
           Square(row) + Square(col+cols) <= kSquaredPizza && Square(row+rows) + Square(col) <= kSquaredPizza;
  }
  inline bool offsite() const { return row == kOffsite; }
  inline double area() const { return area_; }
  inline int mr() const {return row / kMaxSize; }
  inline int mR() const {return (row+rows) / kMaxSize; }
  inline int mc() const {return col / kMaxSize; }
  inline int mC() const {return (col+cols) / kMaxSize; }
  inline int mr(int r) const {return r / kMaxSize; }
  inline int mR(int r) const {return (r+rows) / kMaxSize; }
  inline int mc(int c) const {return c / kMaxSize; }
  inline int mC(int c) const {return (c+cols) / kMaxSize; }
};
std::vector<Rectangle> best_rectangles;
std::vector<Rectangle> rectangles;
FastMap used_rectangles;
FastMap available_rectangles;

FastMap CirclesList[2 * kGridSize + 1][2 * kGridSize + 1];
FastMap RectanglesList[2 * kGridSize + 1][2 * kGridSize + 1];

std::vector<std::pair<int, int>> ListC[kMaxRadius + 1];
std::vector<std::pair<int, int>> ListR[512];

struct Circle {
  int radius;
  int row = kOffsite, col = kOffsite;
  double area_;
  inline bool valid() const {
    return row * row + col * col <= Square(kPizza - radius);
  }
  inline bool valid(int row, int col) const {
    return row * row + col * col <= Square(kPizza - radius);
  }
  inline bool offsite() const { return row == kOffsite; }
  inline double area() const { return area_; }
  inline int mr() const {return (row-radius) / kMaxSize; }
  inline int mR() const {return (row+radius) / kMaxSize; }
  inline int mc() const {return (col-radius) / kMaxSize; }
  inline int mC() const {return (col+radius) / kMaxSize; }
  inline int mr(int r) const {return (r-radius) / kMaxSize; }
  inline int mR(int r) const {return (r+radius) / kMaxSize; }
  inline int mc(int c) const {return (c-radius) / kMaxSize; }
  inline int mC(int c) const {return (c+radius) / kMaxSize; }
};
std::vector<Circle> best_circles;
std::vector<Circle> circles;
FastMap used_circles;
FastMap available_circles;

inline void Save(double sc = Score()) {
  if (sc <= best_score) return;
  best_score = sc;
  best_circles = circles;
  best_rectangles = rectangles;
}

inline bool Intersect(const Rectangle& a, const Rectangle& b) {
  int mr = std::max(a.row, b.row);
  int Mr = std::min(a.row + a.rows, b.row + b.rows);
  if (Mr <= mr) return false;
  int mc = std::max(a.col, b.col);
  int Mc = std::min(a.col + a.cols, b.col + b.cols);
  return Mc > mc;
}
inline bool Intersect(const Circle& a, const Circle& b) {
  const int x2 = Square(a.col - b.col);
  const int y2 = Square(a.row - b.row);
  const int r2 = Square(a.radius + b.radius);
  return x2 + y2 < r2;
}
inline bool Intersect(const Rectangle& a, const Circle& b) {
  const int row = a.row >= b.row ? a.row : (a.row+a.rows <= b.row ? a.row+a.rows : b.row);
  const int col = a.col >= b.col ? a.col : (a.col+a.cols <= b.col ? a.col+a.cols : b.col);
  return Square(row-b.row) + Square(col - b.col) < Square(b.radius);
}
inline bool Intersect(const Circle& b, const Rectangle& a) {
  const int row = a.row >= b.row ? a.row : (a.row+a.rows <= b.row ? a.row+a.rows : b.row);
  const int col = a.col >= b.col ? a.col : (a.col+a.cols <= b.col ? a.col+a.cols : b.col);
  return Square(row - b.row) + Square(col - b.col) < Square(b.radius);
}

void PlaceCircle(int id, int row, int col) {
  ASSERT(available_circles.has(id), "Logic error, PlaceCircle");
  auto& circle = circles[id];
  circle_area += circle.area();
  available_circles.erase(id);
  used_circles.insert(id);
  circle.row = row;
  circle.col = col;
  const int mR = circle.mR();
  const int mC = circle.mC();
  for (int r = circle.mr(); r <= mR; r++) {
    for (int c = circle.mc(); c <= mC; c++) {
      CirclesList[kGridSize+r][kGridSize+c].insert(id);
    }
  }
}

void RemoveCircle(int id) {
  ASSERT(used_circles.has(id), "Logic error: RemoveCircle");
  auto& circle = circles[id];
  circle_area -= circle.area();
  available_circles.insert(id);
  used_circles.erase(id);
  const int mR = circle.mR();
  const int mC = circle.mC();
  for (int r = circle.mr(); r <= mR; r++) {
    for (int c = circle.mc(); c <= mC; c++) {
      CirclesList[kGridSize+r][kGridSize+c].erase(id);
    }
  }
  circle.row = kOffsite;
  circle.col = kOffsite;
}

void PlaceRectangle(int id, int row, int col) {
  ASSERT(available_rectangles.has(id), "Logic error, PlaceRectangle");
  auto& rectangle = rectangles[id];
  rectangle_area += rectangle.area();
  available_rectangles.erase(id);
  used_rectangles.insert(id);
  rectangle.row = row;
  rectangle.col = col;
  const int mR = rectangle.mR();
  const int mC = rectangle.mC();
  for (int r = rectangle.mr(); r <= mR; r++) {
    for (int c = rectangle.mc(); c <= mC; c++) {
      RectanglesList[kGridSize+r][kGridSize+c].insert(id);
    }
  }
}

void RemoveRectangle(int id) {
  ASSERT(used_rectangles.has(id), "Logic error: RemoveRectangle");
  auto& rectangle = rectangles[id];
  rectangle_area -= rectangle.area();
  available_rectangles.insert(id);
  used_rectangles.erase(id);
  const int mR = rectangle.mR();
  const int mC = rectangle.mC();
  for (int r = rectangle.mr(); r <= mR; r++) {
    for (int c = rectangle.mc(); c <= mC; c++) {
      RectanglesList[kGridSize+r][kGridSize+c].erase(id);
    }
  }
  rectangle.row = kOffsite;
  rectangle.col = kOffsite;
}

template<class T>
inline bool CanPlace(T& piece) {
  // PROFILER("CanPlace");
  const int mR = piece.mR();
  const int mC = piece.mC();
  for (int r = piece.mr(); r <= mR; r++) {
    for (int c = piece.mc(); c <= mC; c++) {
      for (int i : CirclesList[kGridSize+r][kGridSize+c]) {
        if (Intersect(piece, circles[i])) return false;
      }
      for (int i : RectanglesList[kGridSize+r][kGridSize+c]) {
        if (Intersect(piece, rectangles[i])) return false;
      }
    }
  }
  return true;
}

template<class T>
bool Place(T& piece, const std::vector<std::pair<int, int>>& list) {
  PROFILER("Place");

  for (const auto& it : list) {
    piece.row = it.first;
    piece.col = it.second;
    if (CanPlace(piece)) {
      return true;
    }
  }

  piece.row = kOffsite;
  piece.col = kOffsite;
  return false;
}

int SA(double end_time = end_time) {
  PROFILER("SA");
  double tempmax = 20.0;
  double tempmin = 5.0;
  double temp = tempmax;

  const double stime = get_time();
  double delta = end_time - stime;

  const double update = 0.025;
  double next_update = update;
  double sc = Score();

  LOG_INFO("Start SA at %lf for %lfs", sc, delta);
  const int check = 100;
  if (delta < 0) return sc;

  for (int64_t it = 0;; it++) {
    PROFILER("Iteration");
    if (it % check == 0) {
      double dd = (get_time() - stime) / delta;
      if (dd > 1.0) break;
      temp = tempmax * std::pow(tempmin/tempmax, dd);
      if (dd > next_update) {
        next_update += update;
        LOG_INFO("%.1lf%% - Iterations: %d, Score: %lf, Best: %lf, temp: %lf", 100.0 * dd, it, sc, best_score, temp);
      }
    }

    // {{type, id}, {prev_row, prev_col}};
    std::vector<std::pair<std::pair<int, int>, std::pair<int, int>>> moves;

    for (int i = rng.next_int(2); i>=0; i--) {
      switch(rng.next_int(2)) {
        case 0: {
          int id = rng.next_int(numCircles);
          moves.push_back({{0, id}, {circles[id].row, circles[id].col}});
          if (available_circles.has(id)) {
            if (Place(circles[id], ListC[circles[id].radius])) {
              PlaceCircle(id, circles[id].row, circles[id].col);
            } else {
              moves.pop_back();
            }
          } else {
            RemoveCircle(id);
          }
          break;
        }
        case 1: {
          int id = rng.next_int(numRectangles);
          moves.push_back({{1, id}, {rectangles[id].row, rectangles[id].col}});
          if (available_rectangles.has(id)) {
            if (Place(rectangles[id], ListR[id])) {
              PlaceRectangle(id, rectangles[id].row, rectangles[id].col);
            } else {
              moves.pop_back();
            }
          } else {
            RemoveRectangle(id);
          }
          break;
        }
      }
    }

    double nsc = Score();
    if (nsc >= sc || rng.next_float() <= std::exp((nsc - sc)/temp)) {
      PROFILER("accept");
      sc = nsc;
      Save(sc);
    } else {
      PROFILER("revert");
      std::reverse(moves.begin(), moves.end());
      for (auto& m : moves) {
        switch(m.first.first) {
          case 0: {
            int id = m.first.second;
            if (available_circles.has(id)) {
              PlaceCircle(id,  m.second.first,  m.second.second);
            } else {
              RemoveCircle(id);
            }
            break;
          }
          case 1: {
            int id = m.first.second;
            if (available_rectangles.has(id)) {
              PlaceRectangle(id,  m.second.first,  m.second.second);
            } else {
              RemoveRectangle(id);
            }
            break;
          }
        }
      }
    }
  }
  return sc;
}

void Reset() {
  while (!used_circles.empty()) RemoveCircle(used_circles.back());
  while (!used_rectangles.empty()) RemoveRectangle(used_rectangles.back());
}

void Greedy() {
  PROFILER("Greedy");
  Reset();
  int circle_id = 0;
  int rectangle_id = 0;
  std::vector<int> circle_idx;
  for (int i = 0; i < numCircles; i++) circle_idx.push_back(i);
  std::sort(circle_idx.begin(), circle_idx.end(), [&](int a, int b) { return circles[a].radius > circles[b].radius; });
  std::vector<int> rectangle_idx;
  for (int i = 0; i < numRectangles; i++) rectangle_idx.push_back(i);
  std::sort(rectangle_idx.begin(), rectangle_idx.end(), [&](int a, int b) {
    return rectangles[a].rows * rectangles[a].cols > rectangles[b].rows * rectangles[b].cols;
  });

  while (circle_id < numCircles || rectangle_id < numRectangles) {
    if (circle_id < numCircles && (X * circle_area < (1.0 - X) * rectangle_area || rectangle_id == numRectangles)) {
      auto& circle = circles[circle_idx[circle_id]];
      if (Place(circle, ListC[circle.radius])) {
        PlaceCircle(circle_idx[circle_id], circle.row, circle.col);
        circle_id++;
      } else {
        while (circle_id < numCircles && circle.radius == circles[circle_idx[circle_id]].radius) {
          circle_id++;
        }
      }
    } else {
      auto& rectangle = rectangles[rectangle_idx[rectangle_id]];
      if (Place(rectangle, ListR[rectangle_idx[rectangle_id]])) {
        PlaceRectangle(rectangle_idx[rectangle_id], rectangle.row, rectangle.col);
      }
      rectangle_id++;
    }
  }
}

void NewGreedy() {
  PROFILER("NewGreedy");
  Reset();
  double target = kSquaredPizza * M_PI * (0.11 * X + 0.82);
  double tcircle = (1-X) * target;
  double trect = X * target;
  int circle_id = 0;
  int rectangle_id = 0;
  std::vector<int> circle_idx;
  for (int i = 0; i < numCircles; i++) circle_idx.push_back(i);
  std::sort(circle_idx.begin(), circle_idx.end(), [&](int a, int b) { return circles[a].radius > circles[b].radius; });
  std::vector<int> rectangle_idx;
  for (int i = 0; i < numRectangles; i++) rectangle_idx.push_back(i);
  std::sort(rectangle_idx.begin(), rectangle_idx.end(), [&](int a, int b) {
    return rectangles[a].rows * rectangles[a].cols > rectangles[b].rows * rectangles[b].cols;
  });

  while (circle_id < numCircles && circle_area < tcircle) {
    auto& circle = circles[circle_idx[circle_id]];
    if (Place(circle, ListC[circle.radius])) {
      PlaceCircle(circle_idx[circle_id], circle.row, circle.col);
      circle_id++;
    } else {
      while (circle_id < numCircles && circle.radius == circles[circle_idx[circle_id]].radius) {
        circle_id++;
      }
    }
  }
  while (rectangle_id < numRectangles) {
    auto& rectangle = rectangles[rectangle_idx[rectangle_id]];
    if (Place(rectangle, ListR[rectangle_idx[rectangle_id]])) {
      PlaceRectangle(rectangle_idx[rectangle_id], rectangle.row, rectangle.col);
    }
    rectangle_id++;
  }
}

void Initialize() {
  PROFILER("Initialize");
  for (int rad = kMinRadius; rad <= kMaxRadius; rad++) {
    Circle c;
    c.radius = rad;
    for (int row = -kPizza; row <= kPizza; row++) {
      for (int col = -kPizza; col <= kPizza; col++) {
        if (c.valid(-row, -col)) ListC[rad].push_back({-row, -col});
      }
    }
    // std::random_shuffle(ListC[rad].begin(), ListC[rad].end());
    std::sort(ListC[rad].begin(), ListC[rad].end(),
              [](const std::pair<int, int>& a, const std::pair<int, int>& b) {
                return Square(a.first) + Square(a.second) > Square(b.first) + Square(b.second);
              });
  }
  for (int id = 0; id < numRectangles; id++) {
    const int maxRow = kPizza - rectangles[id].rows;
    const int maxCol = kPizza - rectangles[id].cols;
    for (int row = -kPizza; row <= maxRow; row++) {
      for (int col = -kPizza; col <= maxCol; col++) {
        if (rectangles[id].valid(row, col)) ListR[id].push_back({row, col});
      }
    }
    std::sort(ListR[id].begin(), ListR[id].end(),
              [&](const std::pair<int, int>& a, const std::pair<int, int>& b) {
                 return Square(a.first + rectangles[id].rows/2) + Square(a.second + rectangles[id].cols/2) >
                        Square(b.first + rectangles[id].rows/2) + Square(b.second + rectangles[id].cols/2);
              });
    // std::random_shuffle(ListR[id].begin(), ListR[id].end());
  }
}

int main() {
  std::cin >> numCircles >> numRectangles >> X;
  circles.resize(numCircles);
  rectangles.resize(numRectangles);
  for (int i=0; i<numCircles; i++) {
    std::cin >> circles[i].radius;
    circles[i].area_ = circles[i].radius * circles[i].radius * M_PI;
    available_circles.insert(i);
  }
  for (int i=0; i<numRectangles; i++) {
    std::cin >> rectangles[i].rows >> rectangles[i].cols;
    rectangles[i].area_ = rectangles[i].rows * rectangles[i].cols;
    available_rectangles.insert(i);
  }

  LOG_TC("%d Circles, %d Rectangles, %lf X", numCircles, numRectangles, X);

  Initialize();

  NewGreedy();
  Save();
  Greedy();
  Save();
  // SA();

  LOG_TC("Score: %lf - (%lf)", best_score, (circle_area + rectangle_area) / (M_PI * kSquaredPizza));

  LOG_TC("Total time: %lfs", get_time() - start_time);
  ASSERT(get_time() < final_limit, "Out of time");

  printf("%d\n", numRectangles + numCircles);
  for (const auto& circle : best_circles) {
    if (circle.offsite()) printf("NA\n");
    else printf("%d %d\n", circle.row, circle.col);
  }
  for (const auto& rectangle : best_rectangles) {
    if (rectangle.offsite()) printf("NA\n");
    else printf("%d %d\n", rectangle.row, rectangle.col);
  }
  std::cout.flush();
  return 0;
}