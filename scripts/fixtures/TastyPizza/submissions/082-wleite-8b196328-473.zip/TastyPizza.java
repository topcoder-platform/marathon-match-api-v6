import java.awt.geom.Ellipse2D;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.SplittableRandom;

public class TastyPizza {
    private int c, r, cycles;
    private double xcr, mbest;
    private int[] cr, rw, rh;
    private int[][] circleUpdIn, circleUpdBorder, circleChk, rectUpd, rectChk;
    private double[] ac, ar;
    private static final int unused = -1000;
    private final Beam<Solution> bestSolutions = new Beam<Solution>(50);
    private final SplittableRandom rnd = new SplittableRandom(9);
    private final long timeout1 = System.currentTimeMillis() + 9200;
    private final long timeout2 = timeout1 + 300;
    private final byte[] initState = new byte[65536];
    private final byte[] boardState = new byte[65536];
    private final int[][] boardStateCircles = new int[65536][4];

    public String findSolution(int c, int r, double xcr, int[] cr, int[] rw, int[] rh) {
        init(c, r, xcr, cr, rw, rh);
        while (System.currentTimeMillis() < timeout1) {
            place();
            cycles++;
        }
        Solution ret = null;
        for (int i = 0; i < bestSolutions.size() && System.currentTimeMillis() < timeout2; i++) {
            Solution sol = bestSolutions.get(i);
            improveRect(sol);
            if (ret == null || sol.score() > ret.score()) ret = sol;
        }
        System.err.println(cycles);
        return ret.toString();
    }

    private void improveRect(Solution sol) {
        OUT: for (int k = 0; k < sol.rPlaced.size(); k++) {
            int idx = sol.rPlaced.get(k);
            int x0 = sol.rx[idx];
            int y0 = sol.ry[idx];
            int w0 = rw[idx];
            int h0 = rh[idx];
            double ar0 = ar[idx];
            sol.rx[idx] = unused;
            for (int i = 0; i < r; i++) {
                if (i == idx || sol.rx[i] != unused) continue;
                if (ar[i] <= ar0) continue;
                int w1 = rw[i];
                if (Math.abs(w1 - w0) > 5) continue;
                int h1 = rh[i];
                if (Math.abs(h1 - h0) > 5) continue;
                for (int j = 0; j < 4; j++) {
                    int x1 = (j & 1) == 0 ? x0 : x0 + w0 - w1;
                    int y1 = (j & 2) == 0 ? y0 : y0 + h0 - h1;
                    if (isRectInPizza(x1, y1, w1, h1)) {
                        if (sol.canPlaceRectFull(i, x1, y1)) {
                            sol.rPlaced.set(k, i);
                            sol.placeRect(i, x1, y1);
                            sol.rsum -= ar0;
                            k--;
                            continue OUT;
                        }
                    }
                }
            }
            sol.rx[idx] = x0;
        }
    }

    private void place() {
        System.arraycopy(initState, 0, boardState, 0, initState.length);
        Solution sol = new Solution();
        int[] copt = new int[c];
        int cc = c;
        int[] ropt = new int[r];
        int rr = r;
        for (int i = 0; i < c; i++) {
            copt[i] = i;
        }
        for (int i = 0; i < r; i++) {
            ropt[i] = i;
        }
        int[] xmin = new int[16];
        for (int i = 5; i <= 15; i++) {
            xmin[i] = -100 + i;
        }
        double m = mbest + rnd.nextDouble(-0.05, 0.05);//TODO: tune
        Solution ref = bestSolutions.size() == 0 ? null : bestSolutions.get(rnd.nextInt(Math.min(bestSolutions.size(), 10)));//TODO pegar de outras???
        int reuse = cycles < 20 ? 0 : rnd.nextInt((ref.rPlaced.size() + ref.cPlaced.size()) * 4 / 5 + 1);
        int ccnt = 0;
        int rcnt = 0;
        for (int k = 0; k < reuse; k++) {
            if (rr > 0 && (xcr * sol.csum > (1 - xcr) * sol.rsum * m || cc == 0)) {
                if (rcnt == ref.rPlaced.size()) continue;
                int i = ref.rPlaced.get(rcnt++);
                sol.placeRect(i, ref.rx[i], ref.ry[i]);
                for (int j = 0; j < rr; j++) {
                    if (ropt[j] == i) {
                        ropt[j] = ropt[--rr];
                        break;
                    }
                }
            } else if (cc > 0) {
                if (ccnt == ref.cPlaced.size()) continue;
                int i = ref.cPlaced.get(ccnt++);
                sol.placeCircle(i, ref.cx[i], ref.cy[i]);
                for (int j = 0; j < cc; j++) {
                    if (copt[j] == i) {
                        copt[j] = copt[--cc];
                        break;
                    }
                }
            }
        }

        NEXT: while ((rr > 0 || cc > 0) && System.currentTimeMillis() < timeout1) {
            if (rr > 0 && (xcr * sol.csum > (1 - xcr) * sol.rsum * m || cc == 0)) {
                int i = ropt[rnd.nextInt(rr)];
                for (int j = 0; j < 20; j++) {
                    int k = ropt[rnd.nextInt(rr)];
                    if (ar[i] < ar[k]) i = k;
                }
                int wi = rw[i];
                int hi = rh[i];
                int hi2 = -hi / 2;
                for (int x = 100 - wi - 1; x > -100; x--) {
                    for (int y = 0; y < 100; y++) {
                        int yy = hi2 + y;
                        if (sol.canPlaceRect(i, x, yy)) {
                            sol.placeRect(i, x, yy);
                            for (int j = 0; j < rr; j++) {
                                if (ropt[j] == i) {
                                    ropt[j] = ropt[--rr];
                                    break;
                                }
                            }
                            continue NEXT;
                        }
                        if (y > 0) {
                            yy = hi2 - y;
                            if (sol.canPlaceRect(i, x, yy)) {
                                sol.placeRect(i, x, yy);
                                for (int j = 0; j < rr; j++) {
                                    if (ropt[j] == i) {
                                        ropt[j] = ropt[--rr];
                                        break;
                                    }
                                }
                                continue NEXT;
                            }
                        }
                    }
                }
                for (int j = 0; j < rr; j++) {
                    if (ropt[j] == i) {
                        ropt[j--] = ropt[--rr];
                    } else {
                        int k = ropt[j];
                        if (rw[k] >= wi && rh[k] >= hi) {
                            ropt[j--] = ropt[--rr];
                        }
                    }
                }
            } else if (cc > 0) {
                int i = copt[rnd.nextInt(cc)];
                for (int j = 0; j < 25; j++) {
                    int k = copt[rnd.nextInt(cc)];
                    if (ac[i] < ac[k]) i = k;
                }
                int ri = cr[i];
                int xrm = xmin[ri];
                for (int x = xrm; x < 100 - ri; x++) {
                    for (int y = 100 - ri; y >= 0; y--) {
                        int cell = boardState[((y + 128) << 8) | (x + 128)];
                        if (cell == 9) continue;
                        for (int j = y == 0 ? 1 : 0; j <= 1; j++) {
                            int yy = j == 0 ? y : -y;
                            if (sol.canPlaceCircle(i, x, yy)) {
                                sol.placeCircle(i, x, yy);
                                for (int k = 0; k < cc; k++) {
                                    if (copt[k] == i) {
                                        copt[k] = copt[--cc];
                                        break;
                                    }
                                }
                                continue NEXT;
                            }
                        }
                    }
                    xmin[ri] = x + 1;
                }
                for (int j = 0; j < cc; j++) {
                    if (copt[j] == i) {
                        copt[j--] = copt[--cc];
                    } else {
                        int k = copt[j];
                        if (cr[k] >= ri) {
                            copt[j--] = copt[--cc];
                        }
                    }
                }
            }
        }
        if (bestSolutions.add(sol)) {
            if (bestSolutions.get(0).equals(sol)) {
                //System.err.println(cycles + "\t" + sol.score());
                mbest = m;
            }
        }
    }

    private boolean isCircleInPizza(int x, int y, int ri) {
        int dr = 100 - ri;
        return x * x + y * y <= dr * dr;
    }

    private boolean isRectInPizza(int x, int y, int wi, int hi) {
        if (x * x + y * y > 10000) return false;
        int x1 = x + wi;
        int y1 = y + hi;
        if (x1 * x1 + y1 * y1 > 10000) return false;
        if (x * x + y1 * y1 > 10000) return false;
        if (x1 * x1 + y * y > 10000) return false;
        return true;
    }

    private void init(int c, int r, double xcr, int[] cr, int[] rw, int[] rh) {
        this.c = c;
        this.r = r;
        this.xcr = xcr;
        this.cr = cr;
        this.rw = rw;
        this.rh = rh;
        ac = new double[c];
        for (int i = 0; i < c; i++) {
            ac[i] = Math.PI * cr[i] * cr[i];
        }
        ar = new double[r];
        for (int i = 0; i < r; i++) {
            ar[i] = rw[i] * rh[i];
        }
        mbest = 1.25 - xcr * 0.25;
        circleUpdIn = new int[c][];
        circleUpdBorder = new int[c][];
        circleChk = new int[c][];
        rectUpd = new int[r][];
        rectChk = new int[r][];
        Arrays.fill(initState, (byte) 9);
        for (int y = -100; y < 100; y++) {
            int y2 = y * y;
            int ym = (128 + y) << 8;
            for (int x = -100; x < 100; x++) {
                int in = 0;
                int x2 = x * x;
                if (x2 + y2 < 10000) in++;
                if (x2 + y2 + 2 * x + 1 < 10000) in++;
                if (x2 + y2 + 2 * y + 1 < 10000) in++;
                if (x2 + y2 + 2 * x + 1 + 2 * y + 1 < 10000) in++;
                if (in == 0) continue;
                int mm = ym | (x + 128);
                if (in == 4) initState[mm] = 0;
                else {
                    initState[mm] = 1;
                    boardStateCircles[mm][0] = -1;
                }
            }
        }
        int[] auxUpdIn = new int[1024];
        int[] auxUpdBorder = new int[1024];
        int[] auxChk = new int[1024];
        for (int ray = 5; ray <= 15; ray++) {
            int inCnt = 0;
            int borderCnt = 0;
            int chkCnt = 0;
            int r2 = ray * ray;
            for (int y = -ray; y < ray; y++) {
                int y2 = y * y;
                int ym = (128 + y) << 8;
                for (int x = -ray; x < ray; x++) {
                    int in = 0;
                    int x2 = x * x;
                    if (x2 + y2 < r2) in++;
                    if (x2 + y2 + 2 * x + 1 < r2) in++;
                    if (x2 + y2 + 2 * y + 1 < r2) in++;
                    if (x2 + y2 + 2 * x + 1 + 2 * y + 1 < r2) in++;
                    if (in == 0) continue;
                    int mm = ym | (x + 128);
                    if (in == 4) {
                        auxUpdIn[inCnt++] = mm;
                        if (y % 5 == 0 && x % 5 == 0) auxChk[chkCnt++] = mm;
                    } else {
                        auxUpdBorder[borderCnt++] = mm;
                    }
                }
            }
            int[] updIn = Arrays.copyOf(auxUpdIn, inCnt);
            int[] updBorder = Arrays.copyOf(auxUpdBorder, borderCnt);
            int[] chk = Arrays.copyOf(auxChk, chkCnt);
            sort(chk);
            sort(updBorder);
            for (int i = 0; i < c; i++) {
                if (cr[i] == ray) {
                    circleUpdIn[i] = updIn;
                    circleUpdBorder[i] = updBorder;
                    circleChk[i] = chk;
                }
            }
        }
        NEXT: for (int i = 0; i < r; i++) {
            int inCnt = 0;
            int chkCnt = 0;
            int wi = rw[i];
            int hi = rh[i];
            for (int j = 0; j < i; j++) {
                if (hi == rh[j] && wi == rw[j]) {
                    rectUpd[i] = rectUpd[j];
                    rectChk[i] = rectChk[j];
                    continue NEXT;
                }
            }
            for (int y = 0; y < hi; y++) {
                int ym = (128 + y) << 8;
                for (int x = 0; x < wi; x++) {
                    int mm = ym | (x + 128);
                    auxUpdIn[inCnt++] = mm;
                    if ((x == 0 || y == 0 || x == wi - 1 || y == hi - 1) || (y % 5 == 0 && x % 5 == 0)) auxChk[chkCnt++] = mm;
                }
            }
            int[] updIn = Arrays.copyOf(auxUpdIn, inCnt);
            int[] chk = Arrays.copyOf(auxChk, chkCnt);
            sort(chk);
            rectUpd[i] = updIn;
            rectChk[i] = chk;
        }
    }

    private void sort(int[] v) {
        for (int i = 1; i < v.length; i++) {
            int idx = i;
            int minDist = 0;
            for (int j = i; j < v.length; j++) {
                int currDist = 9999;
                int chkj = v[j];
                int xj = chkj & 255;
                int yj = chkj >>> 8;
                for (int k = 0; k < i; k++) {
                    int chkk = v[k];
                    int xk = chkk & 255;
                    int yk = chkk >>> 8;
                    currDist = Math.min(currDist, Math.abs(xk - xj) + Math.abs(yk - yj));
                    if (currDist <= minDist) break;
                }
                if (currDist > minDist) {
                    minDist = currDist;
                    idx = j;
                }
            }
            if (idx != i) {
                int aux = v[i];
                v[i] = v[idx];
                v[idx] = aux;
            }
        }
    }

    class Solution implements Comparable<Solution> {
        int[] cx, cy, rx, ry;
        double csum, rsum;
        final List<Integer> cPlaced = new ArrayList<Integer>(128);
        final List<Integer> rPlaced = new ArrayList<Integer>(128);

        boolean circleInter(int x0, int y0, int r0, int x1, int y1, int r1) {
            int dr = r0 + r1;
            int dx = x0 - x1;
            if (dr <= dx || dr <= -dx) return false;
            int dy = y0 - y1;
            if (dr <= dy || dr <= -dy) return false;
            return dx * dx + dy * dy < dr * dr;
        }

        boolean rectInter(int x0, int y0, int w0, int h0, int x1, int y1, int w1, int h1) {
            if (x1 >= x0 + w0) return false;
            if (x0 >= x1 + w1) return false;
            if (y1 >= y0 + h0) return false;
            if (y0 >= y1 + h1) return false;
            return true;
        }

        boolean rectCicleInter(int x0, int y0, int w0, int h0, int x1, int y1, int r1) {
            if (x1 >= x0 && x1 <= x0 + w0 && y1 >= y0 && y1 <= y0 + h0) return true;
            if (x1 + r1 <= x0) return false;
            if (x1 - r1 >= x0 + w0) return false;
            if (y1 + r1 <= y0) return false;
            if (y1 - r1 >= y0 + h0) return false;
            Ellipse2D e = new Ellipse2D.Double(x1 - r1 + 1e-9, y1 - r1 + 1e-9, r1 * 2 - 2e-9, r1 * 2 - 2e-9);
            return e.intersects(x0, y0, w0, h0);
        }

        boolean canPlaceRect(int idx, int x, int y) {
            int off = x + y * 256;
            int[] chk = rectChk[idx];
            for (int i : chk) {
                if (boardState[i + off] != 0) return false;
            }
            return true;
        }

        void placeCircle(int idx, int x, int y) {
            cx[idx] = x;
            cy[idx] = y;
            csum += ac[idx];
            cPlaced.add(idx);
            int[] upd = circleUpdIn[idx];
            int off = x + y * 256;
            for (int i : upd) {
                boardState[i + off] = 7;
            }
            upd = circleUpdBorder[idx];
            for (int i : upd) {
                i += off;
                boardStateCircles[i][boardState[i]++] = idx;
            }
        }

        boolean canPlaceCircle(int idx, int x, int y) {
            int off = x + y * 256;
            int[] chk = circleChk[idx];
            for (int i : chk) {
                if (boardState[i + off] != 0) return false;
            }
            chk = circleUpdBorder[idx];
            for (int i : chk) {
                i += off;
                int v = boardState[i];
                if (v == 0) continue;
                if (v >= 4) return false;
                int[] chkCircles = boardStateCircles[i];
                for (int j = 0; j < v; j++) {
                    int k = chkCircles[j];
                    if (k == -1) {
                        if (!isCircleInPizza(x, y, cr[idx])) return false;
                    } else {
                        if (circleInter(x, y, cr[idx], cx[k], cy[k], cr[k])) return false;
                    }
                }
            }
            return true;
        }

        boolean canPlaceRectFull(int idx, int x, int y) {
            int widx = rw[idx];
            int hidx = rh[idx];
            for (int i : rPlaced) {
                if (rectInter(x, y, widx, hidx, rx[i], ry[i], rw[i], rh[i])) return false;
            }
            for (int i : cPlaced) {
                if (rectCicleInter(x, y, widx, hidx, cx[i], cy[i], cr[i])) return false;
            }
            return true;
        }

        void placeRect(int idx, int x, int y) {
            rx[idx] = x;
            ry[idx] = y;
            rsum += ar[idx];
            rPlaced.add(idx);
            int[] upd = rectUpd[idx];
            int off = x + y * 256;
            for (int i : upd) {
                boardState[i + off] = 7;
            }
        }

        double score() {
            return csum + rsum - Math.abs(xcr * csum - (1 - xcr) * rsum);
        }

        public Solution() {
            cx = new int[c];
            cy = new int[c];
            rx = new int[r];
            ry = new int[r];
            Arrays.fill(cx, unused);
            Arrays.fill(rx, unused);
        }

        public String toString() {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < c; i++) {
                int x = cx[i];
                if (x == unused) sb.append("NA");
                else sb.append(x).append(' ').append(cy[i]);
                sb.append('\n');
            }
            for (int i = 0; i < r; i++) {
                int x = rx[i];
                if (x == unused) sb.append("NA");
                else sb.append(x).append(' ').append(ry[i]);
                sb.append('\n');
            }
            return sb.toString();
        }

        public int compareTo(Solution o) {
            return Double.compare(o.score(), score());
        }
    }

    public static void main(String[] args) {
        try {
            BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
            int c = Integer.parseInt(br.readLine());
            int r = Integer.parseInt(br.readLine());
            double x = Double.parseDouble(br.readLine());
            int[] cr = new int[c];
            for (int i = 0; i < c; i++) {
                cr[i] = Integer.parseInt(br.readLine());
            }
            int[] rw = new int[r];
            int[] rh = new int[r];
            for (int i = 0; i < r; i++) {
                String[] s = br.readLine().split(" ");
                rw[i] = Integer.parseInt(s[0]);
                rh[i] = Integer.parseInt(s[1]);
            }
            TastyPizza sol = new TastyPizza();
            String ret = sol.findSolution(c, r, x, cr, rw, rh);
            System.out.println(c + r);
            System.out.print(ret);
            System.out.flush();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

class Beam<T extends Comparable<T>> {
    private int beamWidth;
    private T[] items;
    private int size;

    @SuppressWarnings("unchecked")
    Beam(int beamWidth) {
        this.beamWidth = beamWidth;
        items = (T[]) new Comparable<?>[beamWidth];
    }

    void addAll(Beam<T> other) {
        System.arraycopy(other.items, 0, items, 0, size = other.size);
    }

    boolean add(T item) {
        if (size >= beamWidth && ((Comparable<T>) items[beamWidth - 1]).compareTo(item) <= 0) return false;
        int pos = Arrays.binarySearch(items, 0, size, item);
        if (pos >= 0) return false;
        pos = -pos - 1;
        if (pos >= beamWidth) return false;
        if (size < beamWidth) size++;
        for (int i = size - 1; i > pos; i--) {
            items[i] = items[i - 1];
        }
        items[pos] = item;
        return true;
    }

    T last() {
        if (size < beamWidth) return null;
        return items[beamWidth - 1];
    }

    T get(int idx) {
        return items[idx];
    }

    int size() {
        return size;
    }

    void clear() {
        size = 0;
    }
}