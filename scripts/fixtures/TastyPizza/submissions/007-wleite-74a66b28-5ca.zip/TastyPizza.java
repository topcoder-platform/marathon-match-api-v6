import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.SplittableRandom;

public class TastyPizza {
    private int c, r;
    private double xcr;
    private int[] cr, rw, rh;
    private double[] ac, ar;
    private static final int unused = -1000;
    private Solution best;
    private SplittableRandom rnd = new SplittableRandom(9);
    private long timeout = System.currentTimeMillis() + 9000;

    public String findSolution(int c, int r, double xcr, int[] cr, int[] rw, int[] rh) {
        init(c, r, xcr, cr, rw, rh);
        while (System.currentTimeMillis() < timeout) {
            place();
        }
        return best.toString();
    }

    private void place() {
        Solution sol = new Solution();
        int fail = 0;
        boolean[] cout = new boolean[c];
        boolean[] rout = new boolean[r];
        NEXT: while (++fail < 1000 && System.currentTimeMillis() < timeout) {
            boolean dr = sol.rPlaced.size() == r;
            boolean dc = sol.cPlaced.size() == c;
            if (!dr && (xcr * sol.csum > (1 - xcr) * sol.rsum || dc)) {
                int i = rnd.nextInt(r);
                if (sol.rx[i] != unused || rout[i]) continue;
                int wi = rw[i];
                int hi = rh[i];
                OUT: for (int x = 100 - wi - 1; x > -100; x--) {
                    for (int y = 0; y < 100; y++) {
                        boolean up = true;
                        boolean down = true;
                        if (up) {
                            if (isRectInPizza(x, y, wi, hi)) {
                                if (sol.canPlaceRect(i, x, y)) {
                                    sol.placeRect(i, x, y);
                                    fail = 0;
                                    continue NEXT;
                                }
                            } else {
                                if (!down) continue OUT;
                                up = false;
                            }
                        }
                        if (down) {
                            if (isRectInPizza(x, -y, wi, hi)) {
                                if (sol.canPlaceRect(i, x, -y)) {
                                    sol.placeRect(i, x, -y);
                                    fail = 0;
                                    continue NEXT;
                                }
                            } else {
                                if (!up) continue OUT;
                                down = false;
                            }
                        }
                    }
                }
                rout[i] = true;
            } else if (!dc) {
                int i = rnd.nextInt(c);
                if (sol.cx[i] != unused || cout[i]) continue;
                int ri = cr[i];
                OUT: for (int x = -100 + ri; x <= 100 - ri; x++) {
                    for (int y = 0; y <= 100 - ri; y++) {
                        if (!isCircleInPizza(x, y, ri)) continue OUT;
                        for (int j = y == 0 ? 1 : 0; j <= 1; j++) {
                            int yy = j == 0 ? y : -y;
                            if (sol.canPlaceCircle(i, x, yy)) {
                                sol.placeCircle(i, x, yy);
                                fail = 0;
                                continue NEXT;
                            }
                        }
                    }
                }
                cout[i] = true;
            }
        }
        //System.err.println(sol.score());
        if (best == null || sol.score() > best.score()) best = sol;
    }

    private boolean isCircleInPizza(int x, int y, int ri) {
        int dr = 100 - ri;
        return x * x + y * y <= dr * dr;
    }

    private boolean isRectInPizza(int x, int y, int wi, int hi) {
        if (x * x + y * y > 10000) return false;
        int x1 = x + wi;
        int y1 = y + hi;
        if (x1 * x1 + y1 * y1 > 10000) return false;
        if (x * x + y1 * y1 > 10000) return false;
        if (x1 * x1 + y * y > 10000) return false;
        return true;
    }

    private void init(int c, int r, double xcr, int[] cr, int[] rw, int[] rh) {
        this.c = c;
        this.r = r;
        this.xcr = xcr;
        this.cr = cr;
        this.rw = rw;
        this.rh = rh;
        ac = new double[c];
        for (int i = 0; i < c; i++) {
            ac[i] = Math.PI * cr[i] * cr[i];
        }
        ar = new double[r];
        for (int i = 0; i < r; i++) {
            ar[i] = rw[i] * rh[i];
        }
    }

    class Solution {
        int[] cx, cy, rx, ry;
        double csum, rsum;
        List<Integer> cPlaced = new ArrayList<Integer>();
        List<Integer> rPlaced = new ArrayList<Integer>();

        void placeCircle(int idx, int x, int y) {
            cx[idx] = x;
            cy[idx] = y;
            csum += ac[idx];
            cPlaced.add(idx);
        }

        boolean circleInter(int x0, int y0, int r0, int x1, int y1, int r1) {
            int dx = x0 - x1;
            int dy = y0 - y1;
            int dr = r0 + r1;
            return dx * dx + dy * dy < dr * dr;
        }

        boolean rectInter(int x0, int y0, int w0, int h0, int x1, int y1, int w1, int h1) {
            if (x1 >= x0 + w0) return false;
            if (x0 >= x1 + w1) return false;
            if (y1 >= y0 + h0) return false;
            if (y0 >= y1 + h1) return false;
            return true;
        }

        boolean rectCicleInter(int x0, int y0, int w0, int h0, int x1, int y1, int r1) {
            if (x1 >= x0 && x1 <= x0 + w0 && y1 >= y0 && y1 <= y0 + h0) return true;
            if (x1 + r1 <= x0) return false;
            if (x1 - r1 >= x0 + w0) return false;
            if (y1 + r1 <= y0) return false;
            if (y1 - r1 >= y0 + h0) return false;
            //TODO
            //Ellipse2D e = new Ellipse2D.Double(x1 - r1, y1 - r1, r1 * 2, r1 * 2);
            //return e.intersects(x0, y0, w0, h0);
            return true;
        }

        boolean canPlaceCircle(int idx, int x, int y) {
            int ridx = cr[idx];
            for (int i : cPlaced) {
                if (circleInter(x, y, ridx, cx[i], cy[i], cr[i])) return false;
            }
            for (int i : rPlaced) {
                if (rectCicleInter(rx[i], ry[i], rw[i], rh[i], x, y, ridx)) return false;
            }
            return true;
        }

        boolean canPlaceRect(int idx, int x, int y) {
            int widx = rw[idx];
            int hidx = rh[idx];
            for (int i : rPlaced) {
                if (rectInter(x, y, widx, hidx, rx[i], ry[i], rw[i], rh[i])) return false;
            }
            for (int i : cPlaced) {
                if (rectCicleInter(x, y, widx, hidx, cx[i], cy[i], cr[i])) return false;
            }
            return true;
        }

        void placeRect(int idx, int x, int y) {
            rx[idx] = x;
            ry[idx] = y;
            rsum += ar[idx];
            rPlaced.add(idx);
        }

        double score() {
            return csum + rsum - Math.abs(xcr * csum - (1 - xcr) * rsum);
        }

        public Solution() {
            cx = new int[c];
            cy = new int[c];
            rx = new int[r];
            ry = new int[r];
            Arrays.fill(cx, unused);
            Arrays.fill(rx, unused);
        }

        public String toString() {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < c; i++) {
                int x = cx[i];
                if (x == unused) sb.append("NA");
                else sb.append(x).append(' ').append(cy[i]);
                sb.append('\n');
            }
            for (int i = 0; i < r; i++) {
                int x = rx[i];
                if (x == unused) sb.append("NA");
                else sb.append(x).append(' ').append(ry[i]);
                sb.append('\n');
            }
            return sb.toString();
        }
    }

    public static void main(String[] args) {
        TastyPizza sol = new TastyPizza();
        try {
            BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
            int c = Integer.parseInt(br.readLine());
            int r = Integer.parseInt(br.readLine());
            double x = Double.parseDouble(br.readLine());
            int[] cr = new int[c];
            for (int i = 0; i < c; i++) {
                cr[i] = Integer.parseInt(br.readLine());
            }
            int[] rw = new int[r];
            int[] rh = new int[r];
            for (int i = 0; i < r; i++) {
                String[] s = br.readLine().split(" ");
                rw[i] = Integer.parseInt(s[0]);
                rh[i] = Integer.parseInt(s[1]);
            }
            String ret = sol.findSolution(c, r, x, cr, rw, rh);
            System.out.println(c + r);
            System.out.print(ret);
            System.out.flush();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}