// C++11
#include <bits/stdc++.h>
#include <sys/time.h>

#ifdef LOCAL
#include "../headers/logger.hpp"
// #include "../TCClient.hpp"
#define LOG_TC(...) LOG_INFO(__VA_ARGS__);
void Initialize(int argc, char** argv);
#else
void Initialize(int argc, char** argv) {}
#define SHOW(...);
#define LOG_DEBUG(...);
#define LOG_INFO(...);
#define LOG_WARNING(...);
#define LOG_ERROR(...);
#define LOG_TC(...) {fprintf(stderr, __VA_ARGS__);fprintf(stderr, "\n"); }
#define PANIC(...);
#define ASSERT(...);
#endif

#ifdef USEPROFILER
#include "../headers/Profiler.hpp"
#else
#define PROFILER_VAR(var, name);
#define PROFILER(name);
#endif

static inline double get_time() {
  timeval tv;
  gettimeofday(&tv, 0);
  return tv.tv_sec + tv.tv_usec * 1e-6;
}

// Need calibration
static inline double get_fast_time() {
  unsigned long long timelo, timehi;
  __asm__ volatile("rdtsc" : "=a"(timelo), "=d"(timehi));
  return ((timehi << 32) + timelo) * 3.5714286e-10;
}

const double END_TIME = 9.5;
double start_time = get_time();
double end_time = start_time + END_TIME;
double final_limit = start_time + 9.95;

class FastMap { public:
  FastMap(){size_ = 0; std::fill(&pos_[0], &pos_[512], -1); }
  void clear() { while (size_) { pos_[taken_[--size_]] = -1; }}
  inline void safeInsert(int v) { if (has(v)) return; insert(v);}
  inline void insert(int v) { taken_[pos_[v] = size_++] = v; }
  inline void push_back(int v) { taken_[pos_[v] = size_++] = v; }
  inline void pop_back() { pos_[taken_[--size_]] = -1; }
  inline int back() { return taken_[size_-1]; }
  inline void erase(int v) {
    const int p = pos_[v];
    const int last = taken_[--size_];
    pos_[last] = p;
    taken_[p] = last;
    pos_[v] = -1;
  }
  inline int operator[](int i) { return taken_[i]; }
  inline void safeErase(int v) { if (has(v)) erase(v); }
  inline bool has(int v) { return pos_[v] >= 0; }
  std::vector<int> toVector() {
    std::vector<int> ret;
    ret.insert(ret.begin(), begin(), end());
    return ret;
  }
  inline int size() { return size_; }
  inline bool empty() { return size_ == 0; }
  inline int* begin() { return &taken_[0]; }
  inline int* end() { return &taken_[size_]; }

 private:
  std::array<int, 512> pos_;
  std::array<int, 512> taken_;
  int size_;
};

struct rand_gen {
  static constexpr uint32_t kMax = 2147483647;
  static constexpr double kInvMax = 1.0 / (double)kMax;
  static constexpr __uint128_t kAdd = 0x60bee2bee120fc15ull;
  static constexpr __uint128_t kMul1 = 0xa3b195354a39b70dull;
  static constexpr __uint128_t kMul2 = 0x1b03738712fad5c9ull;
  uint64_t state = 7;
  inline void seed(uint64_t seed) { state = seed; }
  inline uint32_t next_int() {
    state += kAdd; __uint128_t tmp = (__uint128_t)state * kMul1;
    uint64_t m1 = (tmp >> 64) ^ tmp; tmp = (__uint128_t)m1 * kMul2;
    uint64_t m2 = (tmp >> 64) ^ tmp; return (uint32_t)m2;
  }
  inline uint32_t next_int(uint32_t max) { return next_int()%max; }
  inline uint32_t next_int(uint32_t min, uint32_t max) { return min + (next_int()%(max-min)); }
  inline double next_float() { return next_int(kMax) * kInvMax; }
} rng;
inline int Square(int a) { return a*a; }

int numRectangles, numCircles;
double X;

constexpr int kMinRadius = 5;
constexpr int kMaxRadius = 15;
constexpr int kOffsite = -4242;
constexpr int kPizza = 100;
constexpr int kMaxSize = 11;
constexpr int kGridSize = kPizza / kMaxSize + 1;
constexpr int kSquaredPizza = kPizza*kPizza;
double circle_area = 0.0;
double rectangle_area = 0.0;
double best_score = -1.0;

inline double Score() {
  return circle_area + rectangle_area - std::abs(circle_area * X - (1.0 - X) * rectangle_area);
}

inline int getIdx(int r) { return std::floor(r / kMaxSize); }

struct Rectangle {
  int rows, cols;
  int row = kOffsite, col = kOffsite;
  double area_;
  inline bool valid(int row, int col) const {
    return Square(row) + Square(col) <= kSquaredPizza && Square(row+rows) + Square(col+cols) <= kSquaredPizza &&
           Square(row) + Square(col+cols) <= kSquaredPizza && Square(row+rows) + Square(col) <= kSquaredPizza;
  }
  inline bool offsite() const { return row == kOffsite; }
  inline double area() const { return area_; }
  inline int mr() const {return getIdx(row); }
  inline int mR() const {return getIdx(row+rows); }
  inline int mc() const {return getIdx(col); }
  inline int mC() const {return getIdx(col+cols); }
  inline int mr(int r) const {return getIdx(r); }
  inline int mR(int r) const {return getIdx(r+rows); }
  inline int mc(int c) const {return getIdx(c); }
  inline int mC(int c) const {return getIdx(c+cols); }
};
std::vector<Rectangle> best_rectangles;
std::vector<Rectangle> rectangles;
FastMap used_rectangles;
FastMap available_rectangles;

FastMap CirclesList[2 * kGridSize + 1][2 * kGridSize + 1];
FastMap RectanglesList[2 * kGridSize + 1][2 * kGridSize + 1];

bool FullBlock[2 * kGridSize + 1][2 * kGridSize + 1];

std::vector<std::pair<int, int>> ListC[kMaxRadius + 1];
std::vector<std::pair<int, int>> ListR[512];
std::vector<std::pair<int, int>> List55;

struct Circle {
  int radius;
  int row = kOffsite, col = kOffsite;
  double area_;
  inline bool valid() const {
    return row * row + col * col <= Square(kPizza - radius);
  }
  inline bool valid(int row, int col) const {
    return row * row + col * col <= Square(kPizza - radius);
  }
  inline bool offsite() const { return row == kOffsite; }
  inline double area() const { return area_; }
  inline int mr() const {return getIdx(row-radius); }
  inline int mR() const {return getIdx(row+radius); }
  inline int mc() const {return getIdx(col-radius); }
  inline int mC() const {return getIdx(col+radius); }
  inline int mr(int r) const {return getIdx(r-radius); }
  inline int mR(int r) const {return getIdx(r+radius); }
  inline int mc(int c) const {return getIdx(c-radius); }
  inline int mC(int c) const {return getIdx(c+radius); }
};
std::vector<Circle> best_circles;
std::vector<Circle> circles;
FastMap used_circles;
FastMap available_circles;
FastMap CircleByRadius[kMaxRadius + 1];

inline void Save(double sc = Score()) {
  if (sc <= best_score) return;
  best_score = sc;
  best_circles = circles;
  best_rectangles = rectangles;
}

inline bool Intersect(const Rectangle& a, const Rectangle& b) {
  int mr = std::max(a.row, b.row);
  int Mr = std::min(a.row + a.rows, b.row + b.rows);
  if (Mr <= mr) return false;
  int mc = std::max(a.col, b.col);
  int Mc = std::min(a.col + a.cols, b.col + b.cols);
  return Mc > mc;
}
inline bool Intersect(const Circle& a, const Circle& b) {
  const int x2 = Square(a.col - b.col);
  const int y2 = Square(a.row - b.row);
  const int r2 = Square(a.radius + b.radius);
  return x2 + y2 < r2;
}
inline bool Intersect(const Rectangle& a, const Circle& b) {
  const int row = a.row >= b.row ? a.row : (a.row+a.rows <= b.row ? a.row+a.rows : b.row);
  const int col = a.col >= b.col ? a.col : (a.col+a.cols <= b.col ? a.col+a.cols : b.col);
  return Square(row-b.row) + Square(col - b.col) < Square(b.radius);
}
inline bool Intersect(const Circle& b, const Rectangle& a) {
  const int row = a.row >= b.row ? a.row : (a.row+a.rows <= b.row ? a.row+a.rows : b.row);
  const int col = a.col >= b.col ? a.col : (a.col+a.cols <= b.col ? a.col+a.cols : b.col);
  return Square(row - b.row) + Square(col - b.col) < Square(b.radius);
}

void PlaceCircle(int id, int row, int col) {
  ASSERT(available_circles.has(id), "Logic error, PlaceCircle");
  auto& circle = circles[id];
  // LOG_DEBUG("Place: %d (%d) at %d %d", id, circle.radius, row, col);
  circle_area += circle.area();
  available_circles.erase(id);
  used_circles.insert(id);
  circle.row = row;
  circle.col = col;
  const int mR = circle.mR();
  const int mC = circle.mC();
  const int rad_squared = Square(circle.radius);
  for (int r = circle.mr(); r <= mR; r++) {
    for (int c = circle.mc(); c <= mC; c++) {
      CirclesList[kGridSize+r][kGridSize+c].insert(id);
      FullBlock[kGridSize+r][kGridSize+c] |=
          (Square(r * kMaxSize) + Square(c * kMaxSize)) <= rad_squared &&
          (Square(r * kMaxSize + kMaxSize-1) + Square(c * kMaxSize)) <= rad_squared &&
          (Square(r * kMaxSize) + Square(c * kMaxSize + kMaxSize-1)) <= rad_squared &&
          (Square(r * kMaxSize + kMaxSize-1) + Square(c * kMaxSize + kMaxSize-1)) <= rad_squared;
    }
  }
}

void RemoveCircle(int id) {
  ASSERT(used_circles.has(id), "Logic error: RemoveCircle");
  auto& circle = circles[id];
  circle_area -= circle.area();
  available_circles.insert(id);
  used_circles.erase(id);
  const int mR = circle.mR();
  const int mC = circle.mC();
  for (int r = circle.mr(); r <= mR; r++) {
    for (int c = circle.mc(); c <= mC; c++) {
      CirclesList[kGridSize+r][kGridSize+c].erase(id);
      FullBlock[kGridSize+r][kGridSize+c] = false;  // FIXME?
    }
  }
  circle.row = kOffsite;
  circle.col = kOffsite;
}

void PlaceRectangle(int id, int row, int col) {
  ASSERT(available_rectangles.has(id), "Logic error, PlaceRectangle");
  auto& rectangle = rectangles[id];
  rectangle_area += rectangle.area();
  available_rectangles.erase(id);
  used_rectangles.insert(id);
  rectangle.row = row;
  rectangle.col = col;
  const int mR = rectangle.mR();
  const int mC = rectangle.mC();
  for (int r = rectangle.mr(); r <= mR; r++) {
    for (int c = rectangle.mc(); c <= mC; c++) {
      RectanglesList[kGridSize+r][kGridSize+c].insert(id);
      FullBlock[kGridSize+r][kGridSize+c] |=
          r * kMaxSize >= rectangle.row &&
          r * kMaxSize + kMaxSize - 1 <= rectangle.row + rectangle.rows &&
          c * kMaxSize >= rectangle.col &&
          c * kMaxSize + kMaxSize - 1 <= rectangle.col + rectangle.cols;
    }
  }
}

void RemoveRectangle(int id) {
  ASSERT(used_rectangles.has(id), "Logic error: RemoveRectangle");
  auto& rectangle = rectangles[id];
  rectangle_area -= rectangle.area();
  available_rectangles.insert(id);
  used_rectangles.erase(id);
  const int mR = rectangle.mR();
  const int mC = rectangle.mC();
  for (int r = rectangle.mr(); r <= mR; r++) {
    for (int c = rectangle.mc(); c <= mC; c++) {
      RectanglesList[kGridSize+r][kGridSize+c].erase(id);
      FullBlock[kGridSize+r][kGridSize+c] = false;  // FIXME?
    }
  }
  rectangle.row = kOffsite;
  rectangle.col = kOffsite;
}

template<class T>
inline bool CanPlace(T& piece) {
  // PROFILER("CanPlace");
  const int mR = piece.mR();
  const int mC = piece.mC();
  for (int r = piece.mr(); r <= mR; r++) {
    for (int c = piece.mc(); c <= mC; c++) {
      for (int i : CirclesList[kGridSize+r][kGridSize+c]) {
        if (Intersect(piece, circles[i])) return false;
      }
      for (int i : RectanglesList[kGridSize+r][kGridSize+c]) {
        if (Intersect(piece, rectangles[i])) return false;
      }
    }
  }
  return true;
}

std::vector<std::pair<int, int>> blocks;
std::vector<std::pair<int, int>> in_blocks;

template<class T>
bool Place(T& piece) {
  PROFILER("Place");
  for (auto& b : blocks) {
    if (FullBlock[b.first][b.second]) continue;
    for (auto& ib : in_blocks) {
      piece.row = b.first * kMaxSize + ib.first;
      piece.col = b.second * kMaxSize + ib.second;
      if (piece.valid(piece.row, piece.col) && CanPlace(piece)) {
        return true;
      }
    }
  }
  piece.row = kOffsite;
  piece.col = kOffsite;
  return false;
}

template<class T>
bool Place(T& piece, int dir) {
  PROFILER("Place");
  for (int row = -kPizza; row <= kPizza; row++) {
    for (int col = -kPizza; col <= kPizza; col++) {
      piece.row = row * dir;
      piece.col = col * dir;
      if (piece.valid(piece.row, piece.col) && CanPlace(piece)) {
        return true;
      }
    }
  }
  piece.row = kOffsite;
  piece.col = kOffsite;
  return false;
}

template<class T>
bool Place(T& piece, const std::vector<std::pair<int, int>>& list) {
  PROFILER("Place");

  for (const auto& it : list) {
    piece.row = it.first;
    piece.col = it.second;
    if (piece.valid(piece.row, piece.col) && CanPlace(piece)) {
      return true;
    }
  }

  piece.row = kOffsite;
  piece.col = kOffsite;
  return false;
}

int SA(double end_time = end_time) {
  PROFILER("SA");
  double tempmax = 10.0;
  double tempmin = 5.0;
  double temp = tempmax;

  const double stime = get_time();
  double delta = end_time - stime;

  const double update = 0.025;
  double next_update = update;
  double sc = Score();

  LOG_INFO("Start SA at %lf for %lfs", sc, delta);
  const int check = 100;
  if (delta < 0) return sc;

  for (int64_t it = 0;; it++) {
    PROFILER("Iteration");
    if (it % check == 0) {
      double dd = (get_time() - stime) / delta;
      if (dd > 1.0) break;
      temp = tempmax * std::pow(tempmin/tempmax, dd);
      std::random_shuffle(blocks.begin(), blocks.end());
      std::random_shuffle(in_blocks.begin(), in_blocks.end());
      if (dd > next_update) {
        next_update += update;
        LOG_INFO("%.1lf%% - Iterations: %d, Score: %lf, Best: %lf, temp: %lf", 100.0 * dd, it, sc, best_score, temp);
      }
    }

    // {{type, id}, {prev_row, prev_col}};
    std::vector<std::pair<std::pair<int, int>, std::pair<int, int>>> moves;

    for (int i = rng.next_int(2); i>=0; i--) {
      switch(rng.next_int(2)) {
        case 0: {
          int id = rng.next_int(numCircles);
          auto& circle = circles[id];
          moves.push_back({{0, id}, {circle.row, circle.col}});
          if (available_circles.has(id)) {
            if (Place(circle)) {
            // if (Place(circle, ListC[circle.radius])) {
              PlaceCircle(id, circle.row, circle.col);
            } else {
              moves.pop_back();
            }
          } else {
            RemoveCircle(id);
            switch(rng.next_int(4)) {
              case 0: {
                int rad = -1;
                for (int r = kMaxRadius; r > circle.radius && rad < 0; r--) {
                  Circle c;
                  c.radius = r;
                  for (int rr = -2; rr <= 2 && rad < 0; rr++) {
                    for (int cc = -2; cc <= 2 && rad < 0; cc++) {
                      c.row = moves.back().second.first + rr;
                      c.col = moves.back().second.second + cc;
                      if (c.valid(c.row, c.col) && CanPlace(c)) {
                        for (int i : CircleByRadius[r]) {
                          if (available_circles.has(i)) {
                            moves.push_back({{0, i}, {kOffsite, kOffsite}});
                            PlaceCircle(i, c.row, c.col);
                            rad = r;
                            break;
                          }
                        }
                      }
                    }
                  }
                }
                break;
              }
              case 1: {
                for (int i = 0; i < 3; i++) {
                  int dr = rng.next_int(-2, 3);
                  int dc = rng.next_int(-2, 3);
                  if ((dr || dc) && circle.valid(moves.back().second.first + dr, moves.back().second.second + dc)) {
                    circle.row = moves.back().second.first + dr;
                    circle.col = moves.back().second.second + dc;
                    if (CanPlace(circle)) {
                      moves.push_back({{0, id}, {kOffsite, kOffsite}});
                      PlaceCircle(id, circle.row, circle.col);
                      break;
                    } else {
                      circle.row = kOffsite;
                      circle.col = kOffsite;
                    }
                  }
                }
                break;
              }
              case 2: {
                if (circle.radius == kMinRadius) break;
                int r = rng.next_int(kMinRadius, circle.radius);
                for (int i : CircleByRadius[r]) {
                  if (available_circles.has(i)) {
                    PlaceCircle(i, moves.back().second.first,
                                moves.back().second.second);
                    moves.push_back({{0, i}, {kOffsite, kOffsite}});
                    break;
                  }
                }
                break;
              }
              case 3: {
                if (Place(circle)) {
                  PlaceCircle(id, circle.row, circle.col);
                  moves.push_back({{0, id}, {kOffsite, kOffsite}});
                }
                break;
              }
            }
            break;
          }
        }
        case 1: {
          int id = rng.next_int(numRectangles);
          auto& rectangle = rectangles[id];
          moves.push_back({{1, id}, {rectangle.row, rectangle.col}});
          if (available_rectangles.has(id)) {
            if (Place(rectangle)) {
            // if (Place(rectangle, ListR[id])) {
              PlaceRectangle(id, rectangle.row, rectangle.col);
            } else {
              moves.pop_back();
            }
          } else {
            RemoveRectangle(id);
            switch (rng.next_int(2)) {
              case 0: {
                for (int i = 0; i < 3; i++) {
                  int dr = rng.next_int(-2, 3);
                  int dc = rng.next_int(-2, 3);
                  if ((dr || dc) && rectangle.valid(moves.back().second.first + dr, moves.back().second.second + dc)) {
                    rectangle.row = moves.back().second.first + dr;
                    rectangle.col = moves.back().second.second + dc;
                    if (CanPlace(rectangle)) {
                      moves.push_back({{1, id}, {kOffsite, kOffsite}});
                      PlaceRectangle(id, rectangle.row, rectangle.col);
                      break;
                    } else {
                      rectangle.row = kOffsite;
                      rectangle.col = kOffsite;
                    }
                  }
                }
                break;
              }
              case 1: {
                if (Place(rectangle)) {
                  PlaceRectangle(id, rectangle.row, rectangle.col);
                  moves.push_back({{1, id}, {kOffsite, kOffsite}});
                }
                break;
              }
            }
          }
          break;
        }
      }
    }

    double nsc = Score();
    if (nsc >= sc || rng.next_float() <= std::exp((nsc - sc)/temp)) {
      PROFILER("accept");
      sc = nsc;
      Save(sc);
    } else {
      PROFILER("revert");
      std::reverse(moves.begin(), moves.end());
      for (auto& m : moves) {
        switch(m.first.first) {
          case 0: {
            int id = m.first.second;
            if (available_circles.has(id)) {
              PlaceCircle(id,  m.second.first,  m.second.second);
            } else {
              RemoveCircle(id);
            }
            break;
          }
          case 1: {
            int id = m.first.second;
            if (available_rectangles.has(id)) {
              PlaceRectangle(id,  m.second.first,  m.second.second);
            } else {
              RemoveRectangle(id);
            }
            break;
          }
        }
      }
    }
  }
  return sc;
}

void Reset() {
  while (!used_circles.empty()) RemoveCircle(used_circles.back());
  while (!used_rectangles.empty()) RemoveRectangle(used_rectangles.back());
}

void GreedyRectangle(const std::vector<int>& idx, bool clear = true) {
  PROFILER("GreedyRectangle");
  if (clear) while (!used_rectangles.empty()) RemoveRectangle(used_rectangles.back());
  std::vector<std::pair<int, int>> list = List55;
  int reset = 0;
  auto resetList = [&]() {
    PROFILER("resetList");
    auto cpy = std::move(list);
    list.reserve(cpy.size());
    Rectangle piece;
    for (auto it : cpy) {
      piece.row = it.first;
      piece.col = it.second;
      if (CanPlace(piece)) {
        list.push_back(it);
      }
    }
    reset = 5;
  };
  for (int id : idx) {
    auto& rectangle = rectangles[id];
    if (!rectangle.offsite()) continue;
    if (reset == 0) resetList();
    if (Place(rectangle, list)) {
      PlaceRectangle(id, rectangle.row, rectangle.col);
      reset--;
    }
  }
}
void GreedyCircle(const std::vector<int>& idx, bool clear = false) {
  PROFILER("GreedyCircle");
  std::vector<bool> poss(kMaxRadius, true);
  if (clear) while (!used_circles.empty()) RemoveCircle(used_circles.back());
  for (int id : idx) {
    auto& circle = circles[id];
    if (!circle.offsite() || !poss[circle.radius]) continue;
    if (Place(circle, ListC[circle.radius])) {
      PlaceCircle(id, circle.row, circle.col);
    } else {
      poss[circle.radius] = false;
    }
  }
}

void Greedy() {
  PROFILER("Greedy");
  Reset();
  int circle_id = 0;
  int rectangle_id = 0;
  std::vector<int> circle_idx;
  for (int i = 0; i < numCircles; i++) circle_idx.push_back(i);
  std::sort(circle_idx.begin(), circle_idx.end(), [&](int a, int b) { return circles[a].radius > circles[b].radius; });
  std::vector<int> rectangle_idx;
  for (int i = 0; i < numRectangles; i++) rectangle_idx.push_back(i);
  std::sort(rectangle_idx.begin(), rectangle_idx.end(), [&](int a, int b) {
    return rectangles[a].rows * rectangles[a].cols > rectangles[b].rows * rectangles[b].cols;
  });

  while (circle_id < numCircles || rectangle_id < numRectangles) {
    if (circle_id < numCircles && (X * circle_area < (1.0 - X) * rectangle_area || rectangle_id == numRectangles)) {
      auto& circle = circles[circle_idx[circle_id]];
      if (Place(circle, -1)) {
        PlaceCircle(circle_idx[circle_id], circle.row, circle.col);
        circle_id++;
      } else {
        while (circle_id < numCircles && circle.radius == circles[circle_idx[circle_id]].radius) {
          circle_id++;
        }
      }
    } else {
      auto& rectangle = rectangles[rectangle_idx[rectangle_id]];
      if (Place(rectangle, 1)) {
        PlaceRectangle(rectangle_idx[rectangle_id], rectangle.row, rectangle.col);
      }
      rectangle_id++;
    }
  }
}

void NewGreedy() {
  PROFILER("NewGreedy");
  Reset();
  double target = kSquaredPizza * M_PI * (0.11 * X + 0.85);
  double tcircle = (1-X) * target;
  double trect = X * target;
  LOG_DEBUG("Target: %lf %lf", tcircle, trect);
  int circle_id = 0;
  std::vector<int> circle_idx;
  for (int i = 0; i < numCircles; i++) circle_idx.push_back(i);
  std::sort(circle_idx.begin(), circle_idx.end(), [&](int a, int b) { return circles[a].radius > circles[b].radius; });
  std::vector<int> rectangle_idx;
  for (int i = 0; i < numRectangles; i++) rectangle_idx.push_back(i);
  std::sort(rectangle_idx.begin(), rectangle_idx.end(), [&](int a, int b) {
    return rectangles[a].rows * rectangles[a].cols > rectangles[b].rows * rectangles[b].cols;
  });
  while (circle_id < numCircles && circle_area < tcircle) {
    auto& circle = circles[circle_idx[circle_id]];
    if (Place(circle, ListC[circle.radius])) {
      PlaceCircle(circle_idx[circle_id], circle.row, circle.col);
      // LOG_DEBUG("place: %d at %d %d", circle.radius, circle.row, circle.col);
      circle_id++;
    } else {
      while (circle_id < numCircles && circle.radius == circles[circle_idx[circle_id]].radius) {
        circle_id++;
      }
    }
  }
  GreedyRectangle(rectangle_idx);
}

void BestGreedyRect() {
  PROFILER("BestGreedy");
  if (get_time() > end_time) return;
  Reset();
  double best_score = 0.0;
  double target = kSquaredPizza * M_PI * (0.11 * X + 0.85);
  double tcircle = (1-X) * target - 2.0 * kMaxRadius * kMaxRadius * M_PI;
  double trect = X * target - 25*25*2;
  LOG_DEBUG("Target: %lf %lf", tcircle, trect);
  int id = 0;
  std::vector<int> circle_idx;
  for (int i = 0; i < numCircles; i++) circle_idx.push_back(i);
  std::sort(circle_idx.begin(), circle_idx.end(), [&](int a, int b) { return circles[a].radius > circles[b].radius; });
  std::vector<int> rectangle_idx;
  for (int i = 0; i < numRectangles; i++) rectangle_idx.push_back(i);
  std::sort(rectangle_idx.begin(), rectangle_idx.end(), [&](int a, int b) {
    if (rectangles[a].rows != rectangles[b].rows) return rectangles[a].rows > rectangles[b].rows;
    return rectangles[a].rows * rectangles[a].cols > rectangles[b].rows * rectangles[b].cols;
  });
  while (id < numRectangles && rectangle_area < trect) {
    auto& rectangle = rectangles[rectangle_idx[id]];
    if (Place(rectangle, ListR[rectangle_idx[id]])) {
      PlaceRectangle(rectangle_idx[id], rectangle.row, rectangle.col);
    }
    id++;
  }
  while (get_time() < end_time) {
    GreedyCircle(rectangle_idx);
    double sc = Score();
    Save(sc);
    best_score = std::max(sc, best_score);
    LOG_DEBUG("%lf (%lf - %d, %lf %d)", sc, circle_area, used_circles.size(), rectangle_area, used_rectangles.size());
    if (sc < 0.95 * best_score) break;
    if (id == numRectangles) break;
    if (circle_area * X < rectangle_area * (1.0 - X) && !available_circles.empty()) {
      int idd = used_rectangles.back();
      RemoveRectangle(idd);
    }
    while (!used_circles.empty()) RemoveCircle(used_circles.back());
    while (id < numRectangles) {
      auto& rectangle = rectangles[rectangle_idx[id]];
      if (Place(rectangle, ListR[rectangle_idx[id]])) {
        PlaceRectangle(rectangle_idx[id], rectangle.row, rectangle.col);
        id++;
        break;
      }
      id++;
    }
  }
}

void BestGreedy() {
  PROFILER("BestGreedy");
  if (get_time() > end_time) return;
  Reset();
  double best_score = 0.0;
  double target = kSquaredPizza * M_PI * (0.11 * X + 0.85);
  double tcircle = (1-X) * target - 2.0 * kMaxRadius * kMaxRadius * M_PI;
  double trect = X * target;
  LOG_DEBUG("Target: %lf %lf", tcircle, trect);
  int circle_id = 0;
  std::vector<int> circle_idx;
  for (int i = 0; i < numCircles; i++) circle_idx.push_back(i);
  std::sort(circle_idx.begin(), circle_idx.end(), [&](int a, int b) { return circles[a].radius > circles[b].radius; });
  std::vector<int> rectangle_idx;
  for (int i = 0; i < numRectangles; i++) rectangle_idx.push_back(i);
  std::sort(rectangle_idx.begin(), rectangle_idx.end(), [&](int a, int b) {
    if (rectangles[a].rows != rectangles[b].rows) return rectangles[a].rows > rectangles[b].rows;
    return rectangles[a].rows * rectangles[a].cols > rectangles[b].rows * rectangles[b].cols;
  });
  std::vector<int> rectangle_idx2;
  for (int i = 0; i < numRectangles; i++) rectangle_idx2.push_back(i);
  std::sort(rectangle_idx2.begin(), rectangle_idx2.end(), [&](int a, int b) {
    if (rectangles[a].cols != rectangles[b].cols) return rectangles[a].cols > rectangles[b].cols;
    return rectangles[a].rows * rectangles[a].cols > rectangles[b].rows * rectangles[b].cols;
  });
  while (circle_id < numCircles && circle_area < tcircle) {
    auto& circle = circles[circle_idx[circle_id]];
    if (Place(circle, ListC[circle.radius])) {
      PlaceCircle(circle_idx[circle_id], circle.row, circle.col);
      LOG_DEBUG("place: %d at %d %d", circle.radius, circle.row, circle.col);
      circle_id++;
    } else {
      while (circle_id < numCircles && circle.radius == circles[circle_idx[circle_id]].radius) {
        circle_id++;
      }
    }
  }
  while (get_time() < end_time) {
    GreedyRectangle(rectangle_idx);
    double sc1 = Score();
    Save(sc1);
    if (get_time() > end_time) break;
    GreedyRectangle(rectangle_idx2);
    double sc2 = Score();
    Save(sc2);
    best_score = std::max(sc1, std::max(sc2, best_score));
    LOG_DEBUG("%lf - %lf (%lf - %d, %lf %d)", sc1, sc2, circle_area, used_circles.size(), rectangle_area, used_rectangles.size());
    if (std::max(sc1, sc2) < 0.95 * best_score) break;
    if (circle_id == numCircles) break;
    if (circle_area * X > rectangle_area * (1.0 - X) && !available_rectangles.empty()) {
    // if (std::max(sc1, sc2) < best_score) {
      int id = used_circles.back();
      RemoveCircle(id);
      while (circle_id < numCircles && circles[id].radius == circles[circle_idx[circle_id]].radius) {
        circle_id++;
      }
    }
    while (!used_rectangles.empty()) RemoveRectangle(used_rectangles.back());
    while (circle_id < numCircles) {
      auto& circle = circles[circle_idx[circle_id]];
      if (Place(circle, ListC[circle.radius])) {
        PlaceCircle(circle_idx[circle_id], circle.row, circle.col);
        circle_id++;
        break;
      } else {
        LOG_INFO("Failed size: %d", circle.radius);
        while (circle_id < numCircles && circle.radius == circles[circle_idx[circle_id]].radius) {
          circle_id++;
        }
      }
    }
  }
}

void Greedy(const std::vector<int>& circle_idx, const std::vector<int>& rectangle_idx) {
  PROFILER("Greedy");
  Reset();
  int circle_id = 0;
  int rectangle_id = 0;
  while (circle_id < numCircles || rectangle_id < numRectangles) {
    if (circle_id < numCircles && (X * circle_area < (1.0 - X) * rectangle_area || rectangle_id == numRectangles)) {
      auto& circle = circles[circle_idx[circle_id]];
      if (Place(circle, -1)) {
        PlaceCircle(circle_idx[circle_id], circle.row, circle.col);
        circle_id++;
      } else {
        while (circle_id < numCircles && circle.radius == circles[circle_idx[circle_id]].radius) {
          circle_id++;
        }
      }
    } else {
      auto& rectangle = rectangles[rectangle_idx[rectangle_id]];
      if (Place(rectangle)) {
        PlaceRectangle(rectangle_idx[rectangle_id], rectangle.row, rectangle.col);
      }
      rectangle_id++;
    }
  }
}

void Initialize() {
  PROFILER("Initialize");
  std::vector<std::pair<int, int>> list;
  list.reserve(kSquaredPizza * 4);
  for (int row = -kPizza; row <= kPizza; row++) {
    for (int col = -kPizza; col <= kPizza; col++) {
      if (Square(row) + Square(col) <= kSquaredPizza) {
        list.push_back({row, col});
      }
    }
  }

  std::sort(list.begin(), list.end(),
            [](const std::pair<int, int>& a, const std::pair<int, int>& b) {
              if ((a.first >= 0) != (b.first >= 0)) return a.first > b.first;
              if (a.first != b.first) return std::abs(a.first) < std::abs(b.first);
              return a.second < b.second;
            });

  for (int id = 0; id < numRectangles; id++) {
    ListR[id].reserve(list.size());
    for (auto it : list) {
      if (rectangles[id].valid(it.first, it.second)) ListR[id].push_back(it);
    }
  }
  Rectangle rr;
  rr.cols = 5;
  rr.rows = 5;
  for (auto it : list) {
    if (rr.valid(it.first, it.second)) List55.push_back(it);
  }

  std::sort(list.begin(), list.end(),
            [](const std::pair<int, int>& a, const std::pair<int, int>& b) {
              if ((a.first >= 0) != (b.first >= 0)) return a.first > b.first;
              if ((a.second >= 0) != (b.second >= 0)) return a.second < b.second;
              if (a.first != b.first) return std::abs(a.first) < std::abs(b.first);
              return a.second < b.second;
            });

  for (int rad = kMinRadius; rad <= kMaxRadius; rad++) {
    ListC[rad].reserve(list.size());
    Circle c;
    c.radius = rad;
    for (auto it : list) {
      if (c.valid(it.first, it.second)) ListC[rad].push_back(it);
    }
  }
}
void Initialize2() {
  PROFILER("Initialize2");
  std::vector<std::pair<int, int>> list;
  for (int row = -kPizza; row <= kPizza; row++) {
    for (int col = -kPizza; col <= kPizza; col++) {
      if (Square(row) + Square(col) <= kSquaredPizza) {
        list.push_back({row, col});
      }
    }
  }
  std::sort(list.begin(), list.end(),
            [](const std::pair<int, int>& a, const std::pair<int, int>& b) {
              if ((a.first >= 0) != (b.first >= 0)) return a.first > b.first;
              if (a.first != b.first) return std::abs(a.first) < std::abs(b.first);
              return a.second < b.second;
            });

  for (int id = 0; id < numRectangles; id++) {
    ListR[id].clear();
    for (auto it : list) {
      if (rectangles[id].valid(it.first, it.second)) ListR[id].push_back(it);
    }
  }
  Rectangle rr;
  rr.cols = 5;
  rr.rows = 5;
  for (auto it : list) {
    if (rr.valid(it.first, it.second)) List55.push_back(it);
  }

  for (int rad = kMinRadius; rad <= kMaxRadius; rad++) {
    ListC[rad].clear();
    Circle c;
    c.radius = rad;
    for (auto it : list) {
      if (c.valid(it.first, it.second)) ListC[rad].push_back(it);
    }
  }
}

void ResetBest() {
  Reset();
  for (int id = 0; id < numCircles; id++) {
    auto& c = best_circles[id];
    if (!c.offsite()) PlaceCircle(id, c.row, c.col);
  }
  for (int id = 0; id < numRectangles; id++) {
    auto& c = best_rectangles[id];
    if (!c.offsite()) PlaceRectangle(id, c.row, c.col);
  }
}

void Manual() {
  std::vector<int> rectangle_idx;
  for (int i = 0; i < numRectangles; i++) rectangle_idx.push_back(i);
  std::sort(rectangle_idx.begin(), rectangle_idx.end(), [&](int a, int b) {
    if (rectangles[a].rows != rectangles[b].rows) return rectangles[a].rows > rectangles[b].rows;
    return rectangles[a].rows * rectangles[a].cols > rectangles[b].rows * rectangles[b].cols;
  });

  std::vector<int> circle_idx;
  for (int i = 0; i < numCircles; i++) circle_idx.push_back(i);
  std::sort(circle_idx.begin(), circle_idx.end(), [&](int a, int b) { return circles[a].radius > circles[b].radius; });

  int id = 0;
  while (circles[circle_idx[id]].radius >= 16) id++;
  double best_score = 0.0;
  for (double rad = kPizza; rad >= 0; rad -= 0.5) {
    for (double angle = 0.0; angle <= 2 * M_PI; angle += 0.01) {
      if (id == numCircles) break;
      auto& back = circles[used_circles.back()];
      auto& c = circles[circle_idx[id]];
      c.col = (rad - c.radius) * std::cos(angle);
      c.row = (rad - c.radius) * std::sin(angle);
      if (!CanPlace(c)) {
        c.row = kOffsite;
        c.col = kOffsite;
        continue;
      }
      PlaceCircle(circle_idx[id++], c.row, c.col);
      GreedyRectangle(rectangle_idx);
      double sc = Score();
      Save(sc);
      LOG_DEBUG("%lf - (%lf - %d, %lf %d)", sc, circle_area, used_circles.size(), rectangle_area, used_rectangles.size());
      if (sc > best_score) {
        best_score = sc;
      } else {
        RemoveCircle(used_circles.back());
        while (id < numCircles && circles[circle_idx[id]].radius == c.radius) id++;
        angle = 0.0;
      }
      while (!used_rectangles.empty()) RemoveRectangle(used_rectangles.back());
    }
  }

  Save();
}

int main() {
  std::cin >> numCircles >> numRectangles >> X;
  circles.resize(numCircles);
  rectangles.resize(numRectangles);
  for (int i=0; i<numCircles; i++) {
    std::cin >> circles[i].radius;
    circles[i].area_ = circles[i].radius * circles[i].radius * M_PI;
    available_circles.insert(i);
    CircleByRadius[circles[i].radius].insert(i);
  }
  for (int i=0; i<numRectangles; i++) {
    std::cin >> rectangles[i].rows >> rectangles[i].cols;
    rectangles[i].area_ = rectangles[i].rows * rectangles[i].cols;
    available_rectangles.insert(i);
  }

  LOG_TC("%d Circles, %d Rectangles, %lf X", numCircles, numRectangles, X);

  for (int row = getIdx(-kPizza); row <= getIdx(kPizza); row++) {
    for (int col = getIdx(-kPizza); col <= getIdx(kPizza); col++) {
      int mr = kMaxSize * row + kMaxSize / 2;
      int mc = kMaxSize * col + kMaxSize / 2;
      if (Square(mr) + Square(mc) > Square(kPizza + 1.5 * kMaxSize)) continue;
      blocks.push_back({row, col});
    }
  }
  for (int row = 0; row < kMaxSize; row++) {
    for (int col = 0; col < kMaxSize; col++) {
      in_blocks.push_back({row, col});
    }
  }

  Initialize();
  // Greedy();
  // Save();
  // LOG_INFO("Second greedy: %lf", Score());
  // BestGreedyRev();

  if (X >= 0.75) {
    Manual();
  }

  // BestGreedyRect();

  BestGreedy();
  LOG_INFO("Best greedy: %lf", Score());
  if (get_time() < end_time) {
    Initialize2();
    BestGreedy();
    LOG_INFO("Best greedy: %lf", Score());
  }

  // NewGreedy();
  // Save();
  // LOG_INFO("First greedy: %lf", Score());
  if (get_time() < end_time) {
    if (Score() != best_score) ResetBest();
    SA();
  }

  LOG_TC("Score: %lf - (%lf)", best_score, (circle_area + rectangle_area) / (M_PI * kSquaredPizza));

  LOG_TC("Total time: %lfs", get_time() - start_time);
  ASSERT(get_time() < final_limit, "Out of time");

  printf("%d\n", numRectangles + numCircles);
  for (const auto& circle : best_circles) {
    if (circle.offsite()) printf("NA\n");
    else printf("%d %d\n", circle.row, circle.col);
  }
  for (const auto& rectangle : best_rectangles) {
    if (rectangle.offsite()) printf("NA\n");
    else printf("%d %d\n", rectangle.row, rectangle.col);
  }

// #ifdef LOCAL
//   std::map<std::pair<int, int>, int> rec;
//   std::map<int, int> cir;
//   for (int i : available_rectangles) rec[{rectangles[i].rows, rectangles[i].cols}]++;
//   for (int i : available_circles) cir[circles[i].radius]++;
//   for (auto& it : rec) LOG_DEBUG("%d x %d => %d", it.first.first, it.first.second, it.second);
//   for (auto& it : cir) LOG_DEBUG("R %d => %d", it.first, it.second);
// #endif

  std::cout.flush();
  return 0;
}