// C++11
#include <bits/stdc++.h>
#include <sys/time.h>

#ifdef LOCAL
#include "../headers/logger.hpp"
// #include "../TCClient.hpp"
#define LOG_TC(...) LOG_INFO(__VA_ARGS__);
void Initialize(int argc, char** argv);
#else
void Initialize(int argc, char** argv) {}
#define SHOW(...);
#define LOG_DEBUG(...);
#define LOG_INFO(...);
#define LOG_WARNING(...);
#define LOG_ERROR(...);
#define LOG_TC(...) {fprintf(stderr, __VA_ARGS__);fprintf(stderr, "\n"); }
#define PANIC(...);
#define ASSERT(...);
#endif

#ifdef USEPROFILER
#include "../headers/Profiler.hpp"
#else
#define PROFILER_VAR(var, name);
#define PROFILER(name);
#endif

static inline double get_time() {
  timeval tv;
  gettimeofday(&tv, 0);
  return tv.tv_sec + tv.tv_usec * 1e-6;
}

// Need calibration
static inline double get_fast_time() {
  unsigned long long timelo, timehi;
  __asm__ volatile("rdtsc" : "=a"(timelo), "=d"(timehi));
  return ((timehi << 32) + timelo) * 3.5714286e-10;
}

const double END_TIME = 9.5;
double start_time = get_time();
double end_time = start_time + END_TIME;
double final_limit = start_time + 9.95;

class FastMap { public:
  FastMap(){size_ = 0;}
  FastMap(int size){size_ = 0;}
  void clear() { while (size_) { pos_[taken_[--size_]] = -1; }}
  inline void safeInsert(int v) { if (has(v)) return; insert(v);}
  inline void insert(int v) { taken_[pos_[v] = size_++] = v; }
  inline void push_back(int v) { taken_[pos_[v] = size_++] = v; }
  inline void pop_back() { pos_[taken_[--size_]] = -1; }
  inline int back() { return taken_[size_-1]; }
  inline void erase(int v) {
    const int p = pos_[v];
    const int last = taken_[--size_];
    pos_[last] = p;
    taken_[p] = last;
    pos_[v] = -1;
  }
  inline int operator[](int i) { return taken_[i]; }
  inline void safeErase(int v) { if (has(v)) erase(v); }
  inline bool has(int v) { return pos_[v] >= 0; }
  std::vector<int> toVector() {
    std::vector<int> ret;
    ret.insert(ret.begin(), begin(), end());
    return ret;
  }
  inline int size() { return size_; }
  inline bool empty() { return size_ == 0; }
  inline int* begin() { return &taken_[0]; }
  inline int* end() { return &taken_[size_]; }

 private:
  std::array<int, 512> pos_;
  std::array<int, 512> taken_;
  int size_;
};

struct rand_gen {
  static constexpr uint32_t kMax = 2147483647;
  static constexpr double kInvMax = 1.0 / (double)kMax;
  static constexpr __uint128_t kAdd = 0x60bee2bee120fc15ull;
  static constexpr __uint128_t kMul1 = 0xa3b195354a39b70dull;
  static constexpr __uint128_t kMul2 = 0x1b03738712fad5c9ull;
  uint64_t state = 7;
  inline void seed(uint64_t seed) { state = seed; }
  inline uint32_t next_int() {
    state += kAdd; __uint128_t tmp = (__uint128_t)state * kMul1;
    uint64_t m1 = (tmp >> 64) ^ tmp; tmp = (__uint128_t)m1 * kMul2;
    uint64_t m2 = (tmp >> 64) ^ tmp; return (uint32_t)m2;
  }
  inline uint32_t next_int(uint32_t max) { return next_int()%max; }
  inline uint32_t next_int(uint32_t min, uint32_t max) { return min + (next_int()%(max-min)); }
  inline double next_float() { return next_int(kMax) * kInvMax; }
} rng;
inline int Square(int a) { return a*a; }

int numRectangles, numCircles;
double X;

constexpr int kOffsite = -4242;
constexpr int kPizza = 100;
constexpr int kSquaredPizza = kPizza*kPizza;

struct Rectangle {
  int rows, cols;
  int row = kOffsite, col = kOffsite;
  inline bool valid(int row, int col) const {
    return Square(row) + Square(col) <= kSquaredPizza && Square(row+rows) + Square(col+cols) <= kSquaredPizza &&
           Square(row) + Square(col+cols) <= kSquaredPizza && Square(row+rows) + Square(col) <= kSquaredPizza;
  }
  inline bool offsite() const { return row == kOffsite; }
  inline double area() const { return rows * cols; }
};
std::vector<Rectangle> rectangles;
FastMap used_rectangles;

struct Circle {
  int radius;
  int row = kOffsite, col = kOffsite;
  inline bool valid() const {
    return row * row + col * col <= Square(kPizza - radius);
  }
  inline bool valid(int row, int col) const {
    return row * row + col * col <= Square(kPizza - radius);
  }
  inline bool offsite() const { return row == kOffsite; }
  inline double area() const { return radius * radius * M_PI; }
};
std::vector<Circle> circles;
FastMap used_circles;

inline bool Intersect(const Rectangle& a, const Rectangle& b) {
  int mr = std::max(a.row, b.row);
  int Mr = std::min(a.row + a.rows, b.row + b.rows);
  if (Mr <= mr) return false;
  int mc = std::max(a.col, b.col);
  int Mc = std::min(a.col + a.cols, b.col + b.cols);
  return Mc > mc;
}
inline bool Intersect(const Circle& a, const Circle& b) {
  const int x2 = Square(a.col - b.col);
  const int y2 = Square(a.row - b.row);
  const int r2 = Square(a.radius + b.radius);
  return x2 + y2 < r2;
}
inline bool Intersect(const Rectangle& a, const Circle& b) {
  const int row = a.row >= b.row ? a.row : (a.row+a.rows <= b.row ? a.row+a.rows : b.row);
  const int col = a.col >= b.col ? a.col : (a.col+a.cols <= b.col ? a.col+a.cols : b.col);
  return Square(row-b.row) + Square(col - b.col) < Square(b.radius);
}
inline bool Intersect(const Circle& b, const Rectangle& a) {
  const int row = a.row >= b.row ? a.row : (a.row+a.rows <= b.row ? a.row+a.rows : b.row);
  const int col = a.col >= b.col ? a.col : (a.col+a.cols <= b.col ? a.col+a.cols : b.col);
  return Square(row - b.row) + Square(col - b.col) < Square(b.radius);
}

template<class T>
bool Place(T& piece) {
  for (int row = -kPizza; row <= kPizza; row++) {
    for (int col = -kPizza; col <= kPizza; col++) {
      if (piece.valid(row, col)) {
        piece.row = row;
        piece.col = col;
        bool found = true;
        for (int idx : used_circles) {
          if (Intersect(piece, circles[idx])) {
            found = false;
            break;
          }
        }
        if (found)
        for (int idx : used_rectangles) {
          if (Intersect(piece, rectangles[idx])) {
            found = false;
            break;
          }
        }
        if (found) return true;
      }
    }
  }
  return false;
}

bool Greedy() {
  int circle_id = 0;
  int rectangle_id = 0;
  std::vector<int> circle_idx;
  for (int i = 0; i < numCircles; i++) circle_idx.push_back(i);
  std::sort(circle_idx.begin(), circle_idx.end(), [&](int a, int b) {
    return circles[a].radius > circles[b].radius;
  });
  std::vector<int> rectangle_idx;
  for (int i = 0; i < numRectangles; i++) rectangle_idx.push_back(i);
  std::sort(rectangle_idx.begin(), rectangle_idx.end(), [&](int a, int b) {
    return rectangles[a].rows * rectangles[a].cols > rectangles[b].rows * rectangles[b].cols;
  });

  double circle_area = 0.0;
  double rectangle_area = 0.0;

  while (circle_id < numCircles || rectangle_id < numRectangles) {
    if (circle_id < numCircles && (X * circle_area < (1.0 - X) * rectangle_area || rectangle_id == numRectangles)) {
      auto& circle = circles[circle_idx[circle_id]];
      if (Place(circle)) {
        used_circles.insert(circle_idx[circle_id]);
        circle_area += circle.area();
      } else {
        circle.row = kOffsite;
        circle.col = kOffsite;
      }
      circle_id++;
    } else {
      auto& rectangle = rectangles[rectangle_idx[rectangle_id]];
      if (Place(rectangle)) {
        used_rectangles.insert(rectangle_idx[rectangle_id]);
        rectangle_area += rectangle.area();
      } else {
        rectangle.row = kOffsite;
        rectangle.col = kOffsite;
      }
      rectangle_id++;
    }
  }
}

int main() {
  std::cin >> numCircles >> numRectangles >> X;
  circles.resize(numCircles);
  rectangles.resize(numRectangles);
  for (int i=0; i<numCircles; i++) {
    std::cin >> circles[i].radius;
  }
  for (int i=0; i<numRectangles; i++) {
    std::cin >> rectangles[i].rows >> rectangles[i].cols;
  }

  Greedy();

  LOG_TC("Total time: %lfs", get_time() - start_time);
  ASSERT(get_time() < final_limit, "Out of time");

  printf("%d\n", numRectangles + numCircles);
  for (const auto& circle : circles) {
    if (circle.offsite()) printf("NA\n");
    else printf("%d %d\n", circle.row, circle.col);
  }
  for (const auto& rectangle : rectangles) {
    if (rectangle.offsite()) printf("NA\n");
    else printf("%d %d\n", rectangle.row, rectangle.col);
  }
  std::cout.flush();
  return 0;
}