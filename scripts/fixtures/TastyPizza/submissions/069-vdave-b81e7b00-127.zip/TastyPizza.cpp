﻿// Topcoder Open 2020 - Finals - TastyPizza.
// Author: vdave, Hungary.

#define NOMINMAX
#define _CRT_SECURE_NO_WARNINGS

//#pragma GCC target "avx"

#include <algorithm>
#include <cstdio>
#include <cfloat>
#include <cmath>
#include <cstring>
#include <iostream>
#include <map>
#include <random>
#include <set>
#include <string>
#include <utility>
#include <vector>
#include <unordered_map>
#include <unordered_set>

using namespace std;

#define TC_DEBUG

#ifdef TC_DEBUG
#define DEBUG(...) fprintf(fDebug, __VA_ARGS__)
#define GDEBUG(s, ...) { sprintf(sTmp, __VA_ARGS__); s.append(sTmp); }
#else
#define DEBUG(...)
#define GDEBUG(...)
#endif

// Platform specific stuff (timer, alignment, some intrinsics).

#ifdef _WIN32

// WIN32 platform definitions

#define ALIGN_SSE __declspec(align(64))
#define NOINLINE __declspec(noinline)

#include <ctime>
#include <intrin.h>
#include <windows.h>

typedef LARGE_INTEGER hp_timer_t;
LARGE_INTEGER gl_timer_freq;
double gl_timer_multiplier;

void InitTimer() {
	QueryPerformanceFrequency(&gl_timer_freq);
	gl_timer_multiplier = 1000000.0 / (double)gl_timer_freq.QuadPart;
}

void FetchTime(hp_timer_t* timer_value) {
	QueryPerformanceCounter(timer_value);
}

double GetElapsedMicros(hp_timer_t& timer_value_begin, hp_timer_t& timer_value_end) {
	return gl_timer_multiplier * (timer_value_end.QuadPart - timer_value_begin.QuadPart);
}

int __gcd(int a, int b) {
	if (b == 0) return a;
	return __gcd(b, a % b);
}

#else

// LINUX platform definitions

#define ALIGN_SSE __attribute__((aligned (64)))
#define NOINLINE

#include <sys/time.h>
#include <ctime>
#include <random>

typedef struct timeval hp_timer_t;

void InitTimer() {
}

void FetchTime(hp_timer_t* timer_value) {
	gettimeofday(timer_value, nullptr);
}

double GetElapsedMicros(hp_timer_t& timer_value_begin,
	hp_timer_t& timer_value_end) {
	return (timer_value_end.tv_sec * 1000000.0 + timer_value_end.tv_usec)
		- (timer_value_begin.tv_sec * 1000000.0 + timer_value_begin.tv_usec);
}

#endif



// Debug information for local runs.
bool dbgHasExtraInput;
int dbgSeed;
FILE* fDebug = stderr;
char sTmp[65536];

// Global tweaking constants.
constexpr double kMaxRuntimeMicros = 9.6 * 1000.0 * 1000.0;

// Problem-specific tweaking constants.
constexpr double kTempInitial = 100.0;
constexpr double kTempCoolFactor = 0.99995;
constexpr int kSAIterations = 100000;
constexpr bool kUseTiledOverlapPrediction = true;

// Global randomness.
mt19937 randEngine;
std::uniform_real_distribution<double> randProb(0.0, 1.0);

// Timekeeping.
hp_timer_t tBegin, tInit, tCurrent;
int currentRound, numIters;
int roundsPerTimeCheck = 1;
double estimatedProgress = 0.0;

// Input copied.
struct TCircle {
	int r;
	int cx;
	int cy;
	double A;
	unsigned long long areaMask;
};

struct TRectangle {
	int w;
	int h;
	int x0;
	int y0;
	int x1;
	int y1;
	double A;
	unsigned long long areaMask;
};

struct PackingItem {
	// Index into currentR[]
	int ri;
	// (x0, y0) is relative to the packing box.
	int x0;
	int y0;
};

constexpr double kPI = 3.14159265359;
constexpr int kBaseRadius = 100;
constexpr int kBaseRadiusSq = kBaseRadius * kBaseRadius;
constexpr int kUnused = -10000000;

int C, R;
double X;
TCircle inputC[512];
TRectangle inputR[512];
int orderC[512];
int orderR[512];
double sumC, sumR;

// Precalculated overlap coverage masks.
// maskCircle[CenterX][CenterY][Radius]
unsigned long long maskCircle[210][210][16];
// maskRectangle[X0][Y0][W][H].
unsigned long long maskRectangle[210][210][32][32];
// Points inside the pizza circle ordered descending by their distance from the center.
int numCheckPos;
pair<int, int> circleCheckPos[65536];


// Currently evaluated solution.
double currentScore;
TCircle currentC[512];
TRectangle currentR[512];
double currentAreaC, currentAreaR;
int currentNumC, currentNumR;
int currentIndexC[512], currentIndexR[512];

// Variable for the rectangle packing subproblem.
int packNumCol;
int packColX[200];
int packColHeight[200];
int packColWidth[200];
int packResultSize;
double packResultArea;
PackingItem packResult[512];
double bestPackCompactness, bestPackCoverage;
pair<int, int> bestPackRect[512];


// Best answer and score so far.
double bestScore, bestAreaC, bestAreaR;
double bestFillRatio;
TCircle bestC[512];
TRectangle bestR[512];

// Solver API.
class TastyPizza {
public:
	vector<string> findSolution(int aC, int aR, double aX, const vector<int>& aCircles, const vector<pair<int, int>>& aRects);
};



// Updates the best solution with the current one if the score is better (lower).
void MaybeUpdateBest() {
	if (currentScore > bestScore) {
		bestScore = currentScore;
		bestAreaC = currentAreaC;
		bestAreaR = currentAreaR;
		bestFillRatio = (bestAreaC + bestAreaR) / (kPI * kBaseRadiusSq);
		for (int c = 0; c < C; ++c) {
			bestC[c] = currentC[c];
		}
		for (int r = 0; r < R; ++r) {
			bestR[r] = currentR[r];
		}
		DEBUG("[S=%d, R=%d] New Best = %.8lf [FillRation = %.6lf]\n", dbgSeed, currentRound, bestScore, bestFillRatio);
	}
}

double ScoreDiffFactor() {
	return X * currentAreaC - (1.0 - X) * currentAreaR;
}

double Score() {
	return currentAreaC + currentAreaR - std::abs(ScoreDiffFactor());
}

inline bool InsidePizza(int x, int y) {
	return (x * x + y * y) <= kBaseRadiusSq;
}

inline bool FitsPizza(const TCircle& c) {
	const int deltaR = kBaseRadius - c.r;
	return (c.cx * c.cx) + (c.cy * c.cy) <= deltaR * deltaR;
}

inline bool FitsPizza(const TRectangle& r) {
	return InsidePizza(r.x0, r.y0) && InsidePizza(r.x0 + r.w, r.y0) && InsidePizza(r.x0, r.y0 + r.h) && InsidePizza(r.x0 + r.w, r.y0 + r.h);
}

inline bool Overlap(const TCircle& c1, const TCircle& c2) {
	if ((c1.areaMask & c2.areaMask) == 0) return false;

	const int dx = c1.cx - c2.cx;
	const int dy = c1.cy - c2.cy;
	const int sum_r = c1.r + c2.r;
	return (dx * dx + dy * dy) < (sum_r * sum_r);
}

inline double Distance(const TCircle& c1, const TCircle& c2) {
	const int dx = c1.cx - c2.cx;
	const int dy = c1.cy - c2.cy;
	const int sum_r = c1.r + c2.r;
	return sqrt(dx * dx + dy * dy) - sum_r;
}

inline bool OverlapForce(const TRectangle& r1, const TRectangle& r2) {
	const int maxL = std::max(r1.x0, r2.x0);
	const int minR = std::min(r1.x1, r2.x1);
	if (maxL >= minR) return false;
	const int maxB = std::max(r1.y0, r2.y0);
	const int minT = std::min(r1.y1, r2.y1);
	return maxB < minT;
}

inline bool Overlap(const TRectangle& r1, const TRectangle& r2) {
	if ((r1.areaMask & r2.areaMask) == 0) return false;

	return OverlapForce(r1, r2);
}

inline bool OverlapForce(const TRectangle& r, const TCircle& c) {
	int cx_nearest = c.cx < r.x0 ? r.x0 : c.cx > r.x1 ? r.x1 : c.cx;
	int cy_nearest = c.cy < r.y0 ? r.y0 : c.cy > r.y1 ? r.y1 : c.cy;
	const int dx = cx_nearest - c.cx;
	const int dy = cy_nearest - c.cy;
	return (dx * dx + dy * dy) < c.r * c.r;
}

inline bool Overlap(const TRectangle& r, const TCircle& c) {
	if ((r.areaMask & c.areaMask) == 0) return false;

	return OverlapForce(r, c);
}


// Place circle #changeC to the pizza, assume currentC[changeC] is already filled out with coordinates.
void PlaceCircle(int changeC) {
	currentIndexC[currentNumC++] = changeC;
	currentAreaC += inputC[changeC].A;
	currentScore = Score();

	// Calculate the area mask for the circle
	const int tileSize = 25;
	unsigned long long resultMask = 0;
	unsigned long long currentBit = 1;
	TRectangle tileRect;
	tileRect.w = tileSize;
	tileRect.h = tileSize;
	for (int yTile = 0; yTile < 8; yTile++) {
		tileRect.y0 = -kBaseRadius + (tileSize * yTile);
		tileRect.y1 = tileRect.y0 + tileSize;
		for (int xTile = 0; xTile < 8; xTile++) {
			tileRect.x0 = -kBaseRadius + (tileSize * xTile);
			tileRect.x1 = tileRect.x0 + tileSize;

			if (OverlapForce(tileRect, currentC[changeC])) {
				resultMask |= currentBit;
			}
			currentBit = currentBit << 1;
		}
	}
	currentC[changeC].areaMask = resultMask;
}

// Place rectange #changeR to the pizza, assume currentR[changeR] is already filled out with coordinates.
void PlaceRectangle(int changeR) {
	currentIndexR[currentNumR++] = changeR;
	currentAreaR += inputR[changeR].A;
	currentScore = Score();

	// Calculate the area mask for the rectangle.
	const int tileSize = 25;
	unsigned long long resultMask = 0;
	unsigned long long currentBit = 1;
	TRectangle tileRect;
	tileRect.w = tileSize;
	tileRect.h = tileSize;
	for (int yTile = 0; yTile < 8; yTile++) {
		tileRect.y0 = -kBaseRadius + (tileSize * yTile);
		tileRect.y1 = tileRect.y0 + tileSize;
		for (int xTile = 0; xTile < 8; xTile++) {
			tileRect.x0 = -kBaseRadius + (tileSize * xTile);
			tileRect.x1 = tileRect.x0 + tileSize;

			if (OverlapForce(tileRect, currentR[changeR])) {
				resultMask |= currentBit;
			}
			currentBit = currentBit << 1;
		}
	}

	currentR[changeR].areaMask = resultMask;
}

void PrefillMask(TRectangle& r) {
	int startTileY = (r.y0 + 100) / 25;
	int endTileY = std::min(7, (r.y1 + 100) / 25);
	int startTileX = (r.x0 + 100) / 25;
	int endTileX = std::min(7, (r.x1 + 100) / 25);

	unsigned long long mask = 0;
	for (int yTile = startTileY; yTile <= endTileY; ++yTile) {
		for (int xTile = startTileX; xTile <= endTileX; ++xTile) {
			mask |= 1ull << (yTile * 8 + xTile);
		}
	}
	r.areaMask = mask;
}

void PrefillMask(TCircle& c) {
	int startTileY = (c.cy - c.r + 100) / 25;
	int endTileY = std::min(7, (c.cy + c.r + 100) / 25);
	int startTileX = (c.cx - c.r + 100) / 25;
	int endTileX = std::min(7, (c.cx + c.r + 100) / 25);

	unsigned long long mask = 0;
	for (int yTile = startTileY; yTile <= endTileY; ++yTile) {
		for (int xTile = startTileX; xTile <= endTileX; ++xTile) {
			mask |= 1ull << (yTile * 8 + xTile);
		}
	}
	c.areaMask = mask;
}

// Create an as dense as possible packing of rectangles of the given size, result is stored in packResult.
void PackRectangles(int packW, int packH) {
	// Try packing by rows or by columns.



	packResultSize = 0;
	packResultArea = 0.0;

	packNumCol = 0;
	int startCol = 0;
	for (int ri = 0; ri < R; ++ri) {
		const int changeR = orderR[ri];
		const auto& rect = currentR[changeR];
		if (rect.x0 != kUnused) continue;

		// Find the first column the entry fits into.
		int matchCol = 0;
		while (matchCol < packNumCol) {
			if (packColWidth[matchCol] >= rect.w && packColHeight[matchCol] + rect.h <= packH) break;
			matchCol++;
		}

		if (matchCol == packNumCol) {
			// Did not fit into existing columns, check if it can be the base of a new column
			if (startCol + rect.w > packW) continue;
			if (rect.h > packH) continue;

			// Yes, create the new column with this single entry.
			packColWidth[packNumCol] = rect.w;
			packColHeight[packNumCol] = 0;
			packColX[packNumCol] = startCol;
			startCol += packColWidth[packNumCol];
			packNumCol++;
		}
		if (packColHeight[matchCol] + rect.h <= packH) {
			// Fits to the current column.
			packResult[packResultSize].ri = changeR;
			packResult[packResultSize].x0 = packColX[matchCol];
			packResult[packResultSize].y0 = packColHeight[matchCol];
			packResultSize++;
			packResultArea += inputR[changeR].A;

			packColHeight[matchCol] += rect.h;
		}
	}
}



// MAIN SOLVER BEGINS HERE.

vector<string> TastyPizza::findSolution(int aC, int aR, double aX, const vector<int>& aCircles, const vector<pair<int, int>>& aRects) {
	// Initalize timing, randomness.
	InitTimer();
	FetchTime(&tBegin);
	randEngine.seed(0xdeadbeef);

	// Save input.
	C = aC;
	R = aR;
	X = aX;
	for (int c = 0; c < C; ++c) {
		inputC[c].r = aCircles[c];
		currentC[c].r = inputC[c].r;
	}
	for (int r = 0; r < R; ++r) {
		inputR[r].w = aRects[r].first;
		inputR[r].h = aRects[r].second;
		currentR[r].w = inputR[r].w;
		currentR[r].h = inputR[r].h;
	}

	// Initialize best solution.
	for (int c = 0; c < C; ++c) {
		bestC[c].cx = kUnused;
	}
	for (int r = 0; r < R; ++r) {
		bestR[r].x0 = kUnused;
	}
	bestScore = 0.0;
	// Pizza is harder to fill with circles.
	bestFillRatio = 0.75 + 0.1 * X;

	// Precalculate stuff.

	// Precalculat circle and rectangle area.
	sumC = 0.0;
	for (int c = 0; c < C; ++c) {
		inputC[c].A = kPI * inputC[c].r * inputC[c].r;
		currentC[c].A = inputC[c].A;
		sumC += inputC[c].A;
	}
	sumR = 0.0;
	for (int r = 0; r < R; ++r) {
		inputR[r].A = inputR[r].w * inputR[r].h;
		currentR[r].A = inputR[r].A;
		sumR = inputR[r].A;
	}

	// Precalculate order of circles and rectangles.
	vector<pair<int, int>> C_by_radius(C);
	for (int c = 0; c < C; ++c) {
		C_by_radius.emplace_back(-inputC[c].r, c);
	}
	std::sort(C_by_radius.begin(), C_by_radius.end());
	for (int c = 0; c < C; ++c) {
		orderC[c] = C_by_radius[c].second;
	}
	vector<pair<pair<int, int>, int>> R_by_W_and_H(R);
	for (int r = 0; r < R; ++r) {
		R_by_W_and_H.emplace_back(make_pair(-inputR[r].w, -inputR[r].h), r);
	}
	std::sort(R_by_W_and_H.begin(), R_by_W_and_H.end());
	for (int r = 0; r < R; ++r) {
		orderR[r] = R_by_W_and_H[r].second;
	}

	// Precalculate the order of in-pizza points in decreasing distance from center order.
	vector<pair<int, pair<int, int>>> P_by_Distance;
	for (int y = -99; y < 100; ++y) {
		for (int x = -99; x < 100; ++x) {
			const int d2 = (x * x) + (y * y);
			if (d2 >= kBaseRadiusSq) continue;
			P_by_Distance.emplace_back(-d2, make_pair(x, y));
		}
	}
	std::sort(P_by_Distance.begin(), P_by_Distance.end());
	numCheckPos = (int) P_by_Distance.size();
	for (int i = 0; i < numCheckPos; ++i) {
		circleCheckPos[i] = P_by_Distance[i].second;
	}

	// Precalculate 64-bit tile coverage mask for all possible circles and rectangles.
	TCircle circle;
	for (int cx = -99; cx <= 99; ++cx) {
		circle.cx = cx;
		for (int cy = -99; cy <= 99; ++cy) {
			circle.cy = cy;
			for (int r = 5; r <= 15; ++r) {
				circle.r = r;
				PrefillMask(circle);
				maskCircle[100 + cx][100 + cy][r] = circle.areaMask;
			}
		}
	}

	TRectangle rect;
	for (int x0 = -99; x0 <= 99; ++x0) {
		rect.x0 = x0;
		for (int y0 = -99; y0 <= 99; ++y0) {
			rect.y0 = y0;
			for (int w = 5; w <= 25; ++w) {
				rect.w = w;
				rect.x1 = rect.x0 + w;
				for (int h = 5; h <= 25; ++h) {
					rect.h = h;
					rect.y1 = rect.y0 + h;
					PrefillMask(rect);
					maskRectangle[100 + x0][100 + y0][w][h] = rect.areaMask;
				}
			}
		}
	}

	FetchTime(&tInit);
	DEBUG("Initialization time: %.3lf us.\n", GetElapsedMicros(tBegin, tInit));

	// IDEAS
	// (3) If there are plenty of rectangles compared to what's needed, use smaller ones instead.
	// (4) Dynamic programming for optimal columns in rect packing.
	// (5) More rectangle packing variations (columns / rows / Guillotine???)
	// PENDING
	// (1) Always place circle as far out as possible and as close to neighboring circles.
	//     => Too slow to check all possible positions, would need the circle placing bitmap (#7)
	// (7) Have a constantly updated bitmap of 200 x 200 x 11 to see if a circle with given center and radius is still feasible or not, it's MUCH
	//     cheaper to update that bitmap than running the overlap checking gazillions of times.
	// DONE
	// (6) Fast overlap prediction, divide 200 x 200 area to 25 x 25 tiles => 64 bits of data if a given shape overlaps that tile, if
	//     two shapes have no common bits in the bitmask, they clearly never overlap.
	// (2) Skip large circles / rectangles. If we need AreaC amount of circles, use the smallest set whose total area is around that (times X).
	//     => For circles it mysteriously did not work.

	// SOLVE PROBLEM.
	currentRound = 0;
	roundsPerTimeCheck = 1;
	while (true) {
		// Use the current best results's fill ratio to estimate the expected R and C areas
		const double expectedFillRate = bestFillRatio;
		double optimalAreaR = expectedFillRate * X * kPI * kBaseRadiusSq;
		double optimalAreaC = expectedFillRate * (1.0 - X) * kPI * kBaseRadiusSq;

		// Special case can be when there are only few circles, in those cases it's essential that all circles are used, packing can happen later.

		// Do multiple iterations of rectangle packing trying to get to the optimal area, optimizing on the packed area used.
		bestPackCompactness = -1.0;
		bestPackCoverage = -1.0;
		for (int packIter = 0; packIter < 200; ++packIter) {
			// Initialize candidate solution, no circles / rectangles are used.
			for (int c = 0; c < C; ++c) {
				currentC[c].cx = kUnused;
			}
			for (int r = 0; r < R; ++r) {
				currentR[r].x0 = kUnused;
			}
			currentNumC = 0;
			currentNumR = 0;
			currentAreaC = 0.0;
			currentAreaR = 0.0;
			currentScore = 0.0;

			double packTotalCoverArea = 0.0;
			double packTotalRectArea = 0.0;
			double targetRectArea = optimalAreaR;

			// Pick a randomish target rectangle as the bounding box for the packing.

			// Maximum rectangle in circle ~ square with sides R * sqrt(2) (due to integer coordinates, it could be one less),
			int maxPackW = static_cast<int>(floor(R * sqrt(2)));
			int packW = (randEngine() % kBaseRadius) + kBaseRadius / 2;
			if (targetRectArea > maxPackW * maxPackW) {
				// Only allow small deviations from maximum possible box
				packW = 141 + (randEngine() % 11 - 5);
			}
			int packH = 1;
			int packX0 = -packW / 2;
			int packY0 = 0;
			for (;; packH++) {
				packY0 = -packH / 2;
				TRectangle packRect = { packW, packH, packX0, packY0, packX0 + packW, packY0 + packH };
				if (!FitsPizza(packRect)) {
					packH--;
					packY0 = -packH / 2;
					break;
				}

				// Assume 98% packing efficiency, can be tuned later.
				if (packW * packH > targetRectArea * 1.02) break;
			}
			if (packH == 0) continue;

			// Pick a random starting point for the packed box within the circle (if size allows, large bounding boxes only fit in the center)
			bool packRandomOk = false;
			for (int packPosIter = 0; packPosIter < 100; ++packPosIter) {
				packX0 = (randEngine() % 200) - 100;
				packY0 = (randEngine() % 200) - 100;
				TRectangle packRect = { packW, packH, packX0, packY0, packX0 + packW, packY0 + packH };
				if (FitsPizza(packRect)) {
					packRandomOk = true;
					break;
				}
			}
			if (!packRandomOk) {
				packX0 = -packW / 2;
				packY0 = -packH / 2;
			}

			PackRectangles(packW, packH);
			for (int i = 0; i < packResultSize; ++i) {
				int r = packResult[i].ri;
				currentR[r].x0 = packX0 + packResult[i].x0;
				currentR[r].y0 = packY0 + packResult[i].y0;
				currentR[r].x1 = currentR[r].x0 + currentR[r].w;
				currentR[r].y1 = currentR[r].y0 + currentR[r].h;
				PlaceRectangle(r);
			}

			targetRectArea -= packResultArea;
			packTotalCoverArea += packW * packH;
			packTotalRectArea += packResultArea;

			//DEBUG("Base: %.4lf %.4lf %d x %d\n", packTotalCoverArea, packTotalRectArea, packW, packH);

			if (targetRectArea > 0) {
				for (int dir = 0; dir < 4; ++dir) {
					// Try to pack an additional rectange next to the main one
					// Main box: [PackX0, PackY0] ... [PackX0 + PackW, PackY0 + PackH]
					// Dir == 0 (ABOVE)
					if (dir == 0) {
						// Find a suitable box on the top
						int bestSPW = -1, bestSPH = -1;
						int bestDelta = 99999999;
						for (int sidePackW = 5; sidePackW <= 195; sidePackW++) {
							for (int sidePackH = 5; sidePackH <= 100 - packH / 2; sidePackH++) {
								TRectangle packRect = { sidePackW, sidePackH, -sidePackW / 2, packY0 + packH, -sidePackW / 2 + sidePackW, packY0 + packH + sidePackH };
								if (FitsPizza(packRect)) {
									int sidePackA = sidePackW * sidePackH;
									int deltaA = abs(sidePackA - targetRectArea);
									if (deltaA < bestDelta) {
										bestDelta = deltaA;
										bestSPW = sidePackW;
										bestSPH = sidePackH;
									}
								}

							}
						}

						if (bestSPW > 0) {
							const int sidePackX0 = -bestSPW / 2;
							const int sidePackY0 = packY0 + packH;
							PackRectangles(bestSPW, bestSPH);
							for (int i = 0; i < packResultSize; ++i) {
								int r = packResult[i].ri;
								currentR[r].x0 = sidePackX0 + packResult[i].x0;
								currentR[r].y0 = sidePackY0 + packResult[i].y0;
								currentR[r].x1 = currentR[r].x0 + currentR[r].w;
								currentR[r].y1 = currentR[r].y0 + currentR[r].h;
								PlaceRectangle(r);
							}
							targetRectArea -= packResultArea;
							packTotalCoverArea += bestSPW * bestSPH;
							packTotalRectArea += packResultArea;
							//DEBUG("Dir0: %.4lf %.4lf %d x %d\n", packTotalCoverArea, packTotalRectArea, packW, packH);
						}
					}
					// Dir == 1 (BELOW)
					if (dir == 1) {
						// Find a suitable box on the bottom
						int bestSPW = -1, bestSPH = -1;
						int bestDelta = 99999999;
						for (int sidePackW = 5; sidePackW <= 195; sidePackW++) {
							for (int sidePackH = 5; sidePackH <= 100 - packH / 2; sidePackH++) {
								TRectangle packRect = { sidePackW, sidePackH, -sidePackW / 2, packY0 - sidePackH, -sidePackW / 2 + sidePackW, packY0 };
								if (FitsPizza(packRect)) {
									int sidePackA = sidePackW * sidePackH;
									int deltaA = abs(sidePackA - targetRectArea);
									if (deltaA < bestDelta) {
										bestDelta = deltaA;
										bestSPW = sidePackW;
										bestSPH = sidePackH;
									}
								}

							}
						}

						if (bestSPW > 0) {
							const int sidePackX0 = -bestSPW / 2;
							const int sidePackY0 = packY0 - bestSPH;
							PackRectangles(bestSPW, bestSPH);
							for (int i = 0; i < packResultSize; ++i) {
								int r = packResult[i].ri;
								currentR[r].x0 = sidePackX0 + packResult[i].x0;
								currentR[r].y0 = sidePackY0 + packResult[i].y0;
								currentR[r].x1 = currentR[r].x0 + currentR[r].w;
								currentR[r].y1 = currentR[r].y0 + currentR[r].h;
								PlaceRectangle(r);
							}
							targetRectArea -= packResultArea;
							packTotalCoverArea += bestSPW * bestSPH;
							packTotalRectArea += packResultArea;
							//DEBUG("Dir1: %.4lf %.4lf %d x %d\n", packTotalCoverArea, packTotalRectArea, packW, packH);
						}
					}
					// Dir == 2 (LEFT)
					if (dir == 2) {
						// Find a suitable box on the left
						int bestSPW = -1, bestSPH = -1;
						int bestDelta = 99999999;
						for (int sidePackW = 5; sidePackW <= 195; sidePackW++) {
							for (int sidePackH = 5; sidePackH <= 100 - packH / 2; sidePackH++) {
								TRectangle packRect = { sidePackW, sidePackH, packX0 - sidePackW, -sidePackH / 2, packX0, -sidePackH / 2 + sidePackH };
								if (FitsPizza(packRect)) {
									int sidePackA = sidePackW * sidePackH;
									int deltaA = abs(sidePackA - targetRectArea);
									if (deltaA < bestDelta) {
										bestDelta = deltaA;
										bestSPW = sidePackW;
										bestSPH = sidePackH;
									}
								}

							}
						}

						if (bestSPW > 0) {
							const int sidePackX0 = packX0 - bestSPW;
							const int sidePackY0 = -bestSPH / 2;
							PackRectangles(bestSPW, bestSPH);
							for (int i = 0; i < packResultSize; ++i) {
								int r = packResult[i].ri;
								currentR[r].x0 = sidePackX0 + packResult[i].x0;
								currentR[r].y0 = sidePackY0 + packResult[i].y0;
								currentR[r].x1 = currentR[r].x0 + currentR[r].w;
								currentR[r].y1 = currentR[r].y0 + currentR[r].h;
								PlaceRectangle(r);
							}
							targetRectArea -= packResultArea;
							packTotalCoverArea += bestSPW * bestSPH;
							packTotalRectArea += packResultArea;
							//DEBUG("Dir1: %.4lf %.4lf %d x %d\n", packTotalCoverArea, packTotalRectArea, packW, packH);
						}
					}
					// Dir == 3 (RIGHT)
					if (dir == 3) {
						// Find a suitable box on the left
						int bestSPW = -1, bestSPH = -1;
						int bestDelta = 99999999;
						for (int sidePackW = 5; sidePackW <= 195; sidePackW++) {
							for (int sidePackH = 5; sidePackH <= 100 - packH / 2; sidePackH++) {
								TRectangle packRect = { sidePackW, sidePackH, packX0 + packW, -sidePackH / 2, packX0 + packW + sidePackW, -sidePackH / 2 + sidePackH };
								if (FitsPizza(packRect)) {
									int sidePackA = sidePackW * sidePackH;
									int deltaA = abs(sidePackA - targetRectArea);
									if (deltaA < bestDelta) {
										bestDelta = deltaA;
										bestSPW = sidePackW;
										bestSPH = sidePackH;
									}
								}

							}
						}

						if (bestSPW > 0) {
							const int sidePackX0 = packX0 + packW;
							const int sidePackY0 = -bestSPH / 2;
							PackRectangles(bestSPW, bestSPH);
							for (int i = 0; i < packResultSize; ++i) {
								int r = packResult[i].ri;
								currentR[r].x0 = sidePackX0 + packResult[i].x0;
								currentR[r].y0 = sidePackY0 + packResult[i].y0;
								currentR[r].x1 = currentR[r].x0 + currentR[r].w;
								currentR[r].y1 = currentR[r].y0 + currentR[r].h;
								PlaceRectangle(r);
							}
							targetRectArea -= packResultArea;
							packTotalCoverArea += bestSPW * bestSPH;
							packTotalRectArea += packResultArea;
							//DEBUG("Dir1: %.4lf %.4lf %d x %d\n", packTotalCoverArea, packTotalRectArea, packW, packH);
						}
					}
				}
			}

			double compactness = packTotalRectArea / packTotalCoverArea;
			double coverage = packTotalRectArea / optimalAreaR;
			if (compactness + coverage > bestPackCompactness + bestPackCoverage) {
				bestPackCompactness = compactness;
				bestPackCoverage = coverage;
				for (int r = 0; r < R; ++r) {
					bestPackRect[r] = { currentR[r].x0, currentR[r].y0 };
				}
			}
		}

		// Restore the best packing result as a starting solution for fitting circles
		for (int c = 0; c < C; ++c) {
			currentC[c].cx = kUnused;
		}
		for (int r = 0; r < R; ++r) {
			currentR[r].x0 = kUnused;
		}
		currentNumC = 0;
		currentNumR = 0;
		currentAreaC = 0.0;
		currentAreaR = 0.0;
		currentScore = 0.0;
		for (int r = 0; r < R; ++r) {
			if (bestPackRect[r].first != kUnused) {
				currentR[r].x0 = bestPackRect[r].first;
				currentR[r].y0 = bestPackRect[r].second;
				currentR[r].x1 = currentR[r].x0 + currentR[r].w;
				currentR[r].y1 = currentR[r].y0 + currentR[r].h;
				PlaceRectangle(r);
			}
		}

		// Fine tune solution.
		double T = kTempInitial * 10.0;
		int lastChangeIter = 0;
		int cIndex = 0;
		for (int iter = 0; iter < kSAIterations * 10; ++iter) {
			T *= kTempCoolFactor;

			if (iter % 1000 == 0) {
				FetchTime(&tCurrent);
				const double elapsedMicros = GetElapsedMicros(tBegin, tCurrent);
				if (elapsedMicros > kMaxRuntimeMicros)
					break;
			}

			// No changes in 5000 iterations, stop improving this candidate.
			if (iter > lastChangeIter + 100000) break;

			// Factor inside the abs(), positive => more rectangles needed, negative => more circles needed.
			double diffFactor = ScoreDiffFactor();
			//const bool isCircle = randEngine() % 2;
			bool isCircle = diffFactor < 0;
			//isCircle = true;
			if (currentNumR == R) isCircle = true;
			if (currentNumC == C) isCircle = false;
			if (isCircle) {
				// Try to place a circle.
				const int changeC = randEngine() % C;
				//const int changeC = orderC[cIndex++ % C];
				if (currentC[changeC].cx != kUnused) continue;

				// Try 500 different positions.
				bool isPlaced = false;
				//double minDist = 999999999.999;
				//int minDist_X = -1, minDist_Y = -1;
				//for (int subIter = 0; subIter < numCheckPos; ++subIter) {
				//	currentC[changeC].cx = circleCheckPos[subIter].first;
				//	currentC[changeC].cy = circleCheckPos[subIter].second;
				//	if (!FitsPizza(currentC[changeC])) continue;

				//	// Fetch precalculated 64-bit tile mask for faster overlaps.
				//	currentC[changeC].areaMask = maskCircle[currentC[changeC].cx + 100][currentC[changeC].cy + 100][currentC[changeC].r];

				//	// Check overlap with existing circles.
				//	bool noOverlap = true;
				//	double minCircleDist = 999999.999;
				//	for (int ci = 0; ci < currentNumC; ++ci) {
				//		const int c = currentIndexC[ci];
				//		if (Overlap(currentC[changeC], currentC[c])) {
				//			noOverlap = false;
				//			break;
				//		}
				//		minCircleDist = std::min(minCircleDist, Distance(currentC[changeC], currentC[c]));
				//	}

				//	// Check overlap with existing rectangles.
				//	if (noOverlap) {
				//		for (int ri = 0; ri < currentNumR; ++ri) {
				//			const int r = currentIndexR[ri];
				//			if (Overlap(currentR[r], currentC[changeC])) {
				//				noOverlap = false;
				//				break;
				//			}
				//		}
				//	}

				//	if (noOverlap) {
				//		isPlaced = true;

				//		if (minCircleDist < minDist) {
				//			minDist = minCircleDist;
				//			minDist_X = currentC[changeC].cx;
				//			minDist_Y = currentC[changeC].cy;
				//		}
				//		break;
				//	}
				//}
				//if (isPlaced) {
				//	currentC[changeC].cx = minDist_X;
				//	currentC[changeC].cy = minDist_Y;
				//}

				//// Try 500 different positions.
				for (int subIter = 0; subIter < 1; ++subIter) {
					currentC[changeC].cx = (randEngine() % (2 * kBaseRadius)) - kBaseRadius;
					currentC[changeC].cy = (randEngine() % (2 * kBaseRadius)) - kBaseRadius;
					if (!FitsPizza(currentC[changeC])) continue;

					// Fetch precalculated 64-bit tile mask for faster overlaps.
					currentC[changeC].areaMask = maskCircle[currentC[changeC].cx + 100][currentC[changeC].cy + 100][currentC[changeC].r];

					// Check overlap with existing rectangles.
					bool noOverlap = true;
					for (int ri = 0; ri < currentNumR; ++ri) {
						const int r = currentIndexR[ri];
						if (Overlap(currentR[r], currentC[changeC])) {
							noOverlap = false;
							break;
						}
					}
					if (!noOverlap) break;

					// Check overlap with existing circles, measure overlapped circle size
					double conflictSize = 0.0;
					int conflictCount = 0;
					for (int ci = 0; ci < currentNumC; ++ci) {
						const int c = currentIndexC[ci];
						if (Overlap(currentC[changeC], currentC[c])) {
							noOverlap = false;
							conflictSize += currentC[c].A;
							conflictCount++;
						}
					}

					if (noOverlap) {
						isPlaced = true;
						break;
					}
					else {
						// Calculate score change with removing the overlapping ones.
						double oldScore = currentScore;
						double oldAreaC = currentAreaC;
						currentAreaC -= conflictSize;
						currentAreaC += currentC[changeC].A;
						currentScore = Score();

						bool keepChange = currentScore > oldScore;
						if (currentScore < oldScore) {
							double keepProb = std::exp(1.0 * (currentScore - oldScore) / T);
							if (randProb(randEngine) < keepProb) keepChange = true;
						}
						if (keepChange) {
							// Remove the overlapping circles.
							currentAreaC = oldAreaC;
							for (int ci = 0; ci < currentNumC; ++ci) {
								const int c = currentIndexC[ci];
								if (Overlap(currentC[changeC], currentC[c])) {
									currentC[c].cx = kUnused;
									currentAreaC -= currentC[c].A;
									std::swap(currentIndexC[ci], currentIndexC[currentNumC - 1]);
									currentNumC--;
									ci--;
								}
							}
							isPlaced = true;
						}
						else {
							// Revert changes.
							currentScore = oldScore;
							currentAreaC = oldAreaC;
						}
					}
				}

				if (isPlaced) {
					PlaceCircle(changeC);

					double debugA = 0.0;
					for (int ci = 0; ci < currentNumC; ++ci) {
						const int c = currentIndexC[ci];
						debugA += currentC[c].A;
					}
					lastChangeIter = iter;
				}
				else {
					currentC[changeC].cx = kUnused;
				}
			}
			else {
				// Try to place a rectangle.
				const int changeR = randEngine() % R;
				if (currentR[changeR].x0 != kUnused) continue;

				// Try 500 different positions.
				bool isPlaced = false;
				for (int subIter = 0; subIter < 500; ++subIter) {
					currentR[changeR].x0 = (randEngine() % (2 * kBaseRadius)) - kBaseRadius;
					currentR[changeR].y0 = (randEngine() % (2 * kBaseRadius)) - kBaseRadius;
					currentR[changeR].x1 = currentR[changeR].x0 + inputR[changeR].w;
					currentR[changeR].y1 = currentR[changeR].y0 + inputR[changeR].h;
					if (!FitsPizza(currentR[changeR])) continue;

					// Fetch precalculated 64-bit tile mask for faster overlaps.
					currentR[changeR].areaMask = maskRectangle[currentR[changeR].x0 + 100][currentR[changeR].y0 + 100][currentR[changeR].w][currentR[changeR].h];

					// Check overlap with existing circles.
					bool noOverlap = true;
					for (int ci = 0; ci < currentNumC; ++ci) {
						const int c = currentIndexC[ci];
						if (Overlap(currentR[changeR], currentC[c])) {
							noOverlap = false;
							break;
						}
					}

					// Check overlap with existing rectangles.
					if (noOverlap) {
						for (int ri = 0; ri < currentNumR; ++ri) {
							const int r = currentIndexR[ri];
							if (Overlap(currentR[r], currentR[changeR])) {
								noOverlap = false;
								break;
							}
						}
					}

					if (noOverlap) {
						isPlaced = true;
						break;
					}
				}

				if (isPlaced) {
					PlaceRectangle(changeR);
					lastChangeIter = iter;
				}
				else {
					currentR[changeR].x0 = kUnused;
				}
			}

		}

		// Update best possible solution if the current one is better.
		MaybeUpdateBest();

		// This round is over, check system time every 10ms and update progress.
		currentRound++;
		if (currentRound % roundsPerTimeCheck == 0) {
			FetchTime(&tCurrent);
			const double elapsedMicros = GetElapsedMicros(tBegin, tCurrent);
			if (elapsedMicros > kMaxRuntimeMicros)
				break;
		}
	}

	FetchTime(&tCurrent);
	DEBUG("DATA_HEADER,Seed,C,R,X,AreaC,AreaR,AreaSum,AreaBase,Score,Runtime,Rounds\n");
	DEBUG("DATA_EXPORT,%d,%d,%d,%.6lf,%.6lf,%.6lf,%.6lf,%.6lf,%.6lf,%.2lf,%d\n", dbgSeed, C, R, X, bestAreaC, bestAreaR, bestAreaC + bestAreaR, 31415.92654, bestScore,
		GetElapsedMicros(tBegin, tCurrent), currentRound);
	fflush(fDebug);

	vector<string> retVal(C + R);
	for (int c = 0; c < C; ++c) {
		if (bestC[c].cx == kUnused) {
			retVal[c] = "NA";
		}
		else {
			sprintf(sTmp, "%d %d", bestC[c].cx, bestC[c].cy);
			retVal[c] = sTmp;
		}
	}
	for (int r = 0; r < R; ++r) {
		if (bestR[r].x0 == kUnused) {
			retVal[C + r] = "NA";
		}
		else {
			sprintf(sTmp, "%d %d", bestR[r].x0, bestR[r].y0);
			retVal[C + r] = sTmp;
		}
	}

	return retVal;
}




// Tester wrapper.
int main(int argc, char* argv[]) {
	dbgHasExtraInput = false;

#ifdef TC_DEBUG
	for (int i = 1; i < argc; ++i) {
		if (!strncmp(argv[i], "-s=", 3)) {
			dbgSeed = atoi(argv[i] + 3);
		}
		else if (!strncmp(argv[i], "-o=", 3)) {
			fDebug = fopen(argv[i] + 3, "at");
		}
		else if (!strncmp(argv[i], "-d", 2)) {
			dbgHasExtraInput = true;
		}
	}
	fprintf(fDebug, "=========== SEED: %d ===========\n", dbgSeed);
#endif

	int genC, genR;
	double genX;
	cin >> genC;
	cin >> genR;
	cin >> genX;

	vector<int> genCircles(genC);
	for (int i = 0; i < genC; ++i) {
		cin >> genCircles[i];
	}

	vector<pair<int, int>> genRects(genR);
	for (int i = 0; i < genR; ++i) {
		cin >> genRects[i].first;
		cin >> genRects[i].second;
	}

	TastyPizza solver;
	auto retVal = solver.findSolution(genC, genR, genX, genCircles, genRects);

	if (fDebug != stderr) {
		fflush(fDebug);
		fclose(fDebug);
	}

	cout << retVal.size() << endl;
	for (auto x : retVal) {
		cout << x << endl;
	}
	cout.flush();
	cerr.flush();

	return 0;
}
