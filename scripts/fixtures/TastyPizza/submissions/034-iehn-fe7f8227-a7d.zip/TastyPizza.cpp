#pragma GCC optimize "O3,omit-frame-pointer,inline"
#define _LOCAL
#define DEBUG
#define _DEBUG2
#define _DEBUG3
#include <algorithm>
#include <cstdlib>
#include <iostream>
#include <fstream>
#include <vector>
#include <cmath>
#include "bits/stdc++.h"
#include <sys/time.h>
#include <emmintrin.h>
#include <string>
#include <bitset>
#include <unistd.h>

using namespace std;

#ifdef LOCAL
inline double GetSeconds() {
  return static_cast<double>(chrono::duration_cast<chrono::nanoseconds>(
        chrono::steady_clock::now().time_since_epoch()).count())/1000000000;
}
#else
inline long long GetTSC() {
  long long lo, hi;
  asm volatile ("rdtsc": "=a"(lo), "=d"(hi));
  return lo + (hi << 32);
}
inline double GetSeconds() {
  return GetTSC() / 2.8e9;
}
#endif

struct XorShift {
  uint64_t x = 88172645463325252ULL;
  double nl[65536];
  XorShift() {}

  void init(){
    double n2 = 1.0 / 65536*2;
    for(int i=0; i<65536; i++) nl[i] = log(i / 65536.0 + n2);
  }

  void setSeed(uint64_t seed) { x = seed; init(); }

  uint64_t next() {
    x ^= x << 13; x ^= x >> 7; x ^= x << 17;
    return x;
  }

  int nextInt(int n) {
    uint64_t upper = 0xFFFFFFFFFFFFFFFFULL / n * n;
    uint64_t v = next();
    while (v >= upper) v = next();
    return v % n;
  }

  double nextDouble() {
    uint64_t v = next() >> 11; // 53bit
    return (double)v / (1ULL << 53);
  }

  double nextLog() {
    return nl[nextInt(65536)];
  }
};


XorShift xs;
#ifdef LOCAL
const double TO = 9.8 / 1.2 * 1e-1;
#else
const double TO = 9.8;
#endif

double starttime, gt;
int att,btt,ctt,dtt,ett;

const int MAX_R = 500;
const int MAX_C = 500;
const int NA = -1000;

int C,R;
double X;
int CR[MAX_C];
int RW[MAX_R];
int RH[MAX_R];
int CX[MAX_C], CY[MAX_C];
int RX[MAX_C], RY[MAX_C];
int MCX[MAX_C], MCY[MAX_C];
int MRX[MAX_C], MRY[MAX_C];
vector<tuple<double, int, int>> CV;
vector<tuple<int, int, int, int>> RV;
const int BM = 201;
bitset<BM> BIN[BM];
bitset<BM> SIN[BM];
vector<tuple<int, int, int>> RIN[16];

void init(){
  cin >> C >> R >> X;
  for(int i=0; i<C; i++) cin >> CR[i];
  for(int i=0; i<R; i++) cin >> RW[i] >> RH[i];

  CV.clear(); RV.clear();
  for(int i=0; i<C; i++) CV.emplace_back(-CR[i]*CR[i]*M_PI, CR[i], i);
  for(int i=0; i<R; i++) RV.emplace_back(-RW[i]*RH[i], RW[i], RH[i], i);
  sort(CV.begin(), CV.end());
  sort(RV.begin(), RV.end());

  for(int i=0; i<BM; i++) for(int j=0; j<BM; j++){
    BIN[i][j] = pow(i-100, 2) + pow(j-100, 2) <= 10000;
  }

  for(int r=5; r<16; r++){
    int rr = r * r;
    RIN[r].clear();
    for(int i=0; i<r; i++) for(int j=0; j<r; j++){
      if(pow(i+1, 2) + pow(j+1, 2) < rr){
        int s = -i*i - j*j;
        RIN[r].emplace_back(s, i,j);
        if(i > 0){
          RIN[r].emplace_back(s, -i, j);
          if(j > 0) RIN[r].emplace_back(s, -i, j);
        }
        if(j > 0) RIN[r].emplace_back(s, i, -j);
      }
    }
    sort(RIN[r].begin(), RIN[r].end());
  }

  cerr << "init_time: " << (GetSeconds() - starttime) << endl;
}

inline bool over_cc(int ci, int x, int y, int r){
  int cx = CX[ci], cy = CY[ci], cr = CR[ci];
  return pow(pow(x-cx, 2) + pow(y-cy, 2), 0.5) < r + cr;
}

inline bool over_rc(int ri, int x, int y, int r){
  int rx = RX[ri], ry = RY[ri], rw = RW[ri], rh = RH[ri];
  int tx = x, ty = y;
  if(x < rx) tx = rx;
  else if(x > rx + rw) tx = rx + rw;
  if(y < ry) ty = ry;
  else if(y > ry + rh) ty = ry + rh;
  return pow(pow(x-tx, 2) + pow(y-ty, 2), 0.5) < r;
}

inline bool over_cr(int ci, int x, int y, int w, int h){
  int cx = CX[ci], cy = CY[ci], cr = CR[ci];
  int tx = cx, ty = cy;
  if(cx < x) tx = x;
  else if(cx > x + w) tx = x + w;
  if(cy < y) ty = y;
  else if(cy > y + h) ty = y + h;
  return pow(pow(cx-tx, 2) + pow(cy-ty, 2), 0.5) < cr;
}

inline bool over_rr(int ri, int x, int y, int w, int h){
  int rx = RX[ri], ry = RY[ri], rw = RW[ri], rh = RH[ri];
  return rx < x+w && rx+rw > x && ry < y+h && ry+rh > y;
}

inline tuple<int, int> solve_(){
  for(int i=0; i<BM; i++) SIN[i] = BIN[i];

  vector<tuple<bool, int, int, int>> v;
  double mc = 0, cc = 0, tc = 0, tr = 0;
  int nc = 0, nr = 0;
  int vs = 0;
  while(nc < C || nr < R){
    double uc = -1e9, ur = -1e9;
    if(nc < C){
      auto t = CV[nc];
      double pc = tc - get<0>(t);
      uc = pc + tr - abs(X*pc - (1-X)*tr);
    }
    if(nr < R){
      auto t = RV[nr];
      double pr = tr - get<0>(t);
      ur = tc + pr - abs(X*tc - (1-X)*pr);
    }

    if(nr == R || (nc < C && (uc - cc) / -get<0>(CV[nc]) > (ur - cc) / -get<0>(RV[nr]))){
      auto t = CV[nc++];
      v.emplace_back(1, get<1>(t), 0, get<2>(t));
      cc = uc;
      tc -= get<0>(t);
    }else{
      auto t = RV[nr++];
      v.emplace_back(0, get<1>(t), get<2>(t), get<3>(t));
      cc = ur;
      tr -= get<0>(t);
    }
    if(mc < cc){
      mc = cc;
      vs = nc + nr;
    }
  }

  int cs = 0, rs = 0;
  for(int vi=0; vi<vs; vi++){
    auto t = v[vi];
    if(get<0>(t)){ // C
      int r = get<1>(t);
      bool ok = 0;
      for(int i=r; !ok && i<BM-r; i++) for(int j=r; !ok && j<BM-r; j++){
        if(!SIN[i][j] || r + pow(pow(100-i, 2)+pow(100-j, 2), 0.5) > 100) continue;
        ett++;

        bool o = 1;
        for(auto t : RIN[r]) if(!SIN[i+get<1>(t)][j+get<2>(t)]){
          o = 0;
          break;
        }
        if(!o) continue;

        for(int vj=0; vj<vi; vj++){
          auto u = v[vj];
          if(get<0>(u)){ // C
            if(over_cc(get<3>(u), i, j, r)){ o = 0; break; }
          }else{ // R
            if(over_rc(get<3>(u), i, j, r)){ o = 0; break; }
          }
        }
        if(o){
          ok = 1;
          CX[get<3>(t)] = i;
          CY[get<3>(t)] = j;
          for(auto t : RIN[r]) SIN[i+get<1>(t)][j+get<2>(t)] = 0;
          cs++;
        }
      }
      if(!ok) return make_tuple(cs, rs);
    }else{ // R
      int w = get<1>(t);
      int h = get<2>(t);
      bool ok = 0;
      for(int i=w; !ok && i<BM-w; i++) for(int j=h; !ok && j<BM-h; j++){
        if(!SIN[i][j] || !SIN[i+w][j] || !SIN[i][j+h] || !SIN[i+w][j+h]) continue;

        bool o = 1;
        for(int vj=0; vj<vi; vj++){
          auto u = v[vj];
          if(get<0>(u)){ // C
            if(over_cr(get<3>(u), i, j, w, h)){ o = 0; break; }
          }else{ // R
            if(over_rr(get<3>(u), i, j, w, h)){ o = 0; break; }
          }
        }
        if(o){
          ok = 1;
          RX[get<3>(t)] = i;
          RY[get<3>(t)] = j;
          for(int ii=i; ii<i+w; ii++) for(int jj=j; jj<j+h; jj++) SIN[ii][jj] = 0;
          rs++;
        }
      }
      if(!ok) return make_tuple(cs, rs);
    }
  }
  return make_tuple(cs, rs);
}

void solve(){
  double ms = 0;

  for(int i=0; i<C; i++) MCX[i] = MCY[i] = NA;
  for(int i=0; i<R; i++) MRX[i] = MRY[i] = NA;

  int ngc = 0;
  while(1){
    gt = GetSeconds() - starttime;
    if(gt >= TO) break;

    att++;

    auto ot = solve_();
    int tc = get<0>(ot);
    int tr = get<1>(ot);
    double cs = 0, rs = 0;
    int nc = 0, nr = 0;
    for( ; nc<tc; nc++) cs -= get<0>(CV[nc]);
    for( ; nr<tr; nr++) rs -= get<0>(RV[nr]);
    double ts = cs + rs - abs(X*cs - (1-X)*rs);
    if(ms < ts){
      cerr << ts << " " << cs << " " << rs << endl;
      ms = ts;
      btt++;

      for(int i=0; i<C; i++) MCX[i] = MCY[i] = NA;
      for(int i=0; i<R; i++) MRX[i] = MRY[i] = NA;
      for(int i=0; i<nc; i++){
        int ci = get<2>(CV[i]);
        MCX[ci] = CX[ci];
        MCY[ci] = CY[ci];
      }
      for(int i=0; i<nr; i++){
        int ri = get<3>(RV[i]);
        MRX[ri] = RX[ri];
        MRY[ri] = RY[ri];
      }
      if(nc == C && nr == R) break;
    }else{
      ngc++;
    }
    for( ; nc<C; nc++) swap(CV[nc], CV[nc + xs.nextInt(C - nc)]);
    for( ; nr<R; nr++) swap(RV[nr], RV[nr + xs.nextInt(R - nr)]);
  }

  cerr << "ms: " << ms << " time: " << (GetSeconds() - starttime);
  cerr << " att: " << att << " btt: " << btt;
  cerr << " ctt: " << ctt << " dtt: " << dtt << " ett: " << ett << endl;
}

void output(){
  cout << C + R << "\n";
  for(int i=0; i<C; i++){
    if(MCX[i] == NA) cout << "NA\n";
    else{
      cout << MCX[i] - 100 << " " << MCY[i] - 100 << "\n";
      // cerr << "C: " << MCX[i] - 100 << " " << MCY[i] - 100 << "\n";
    }
  }
  for(int i=0; i<R; i++){
    if(MRX[i] == NA) cout << "NA\n";
    else{
      cout << MRX[i] - 100 << " " << MRY[i] - 100 << "\n";
      // cerr << "R: " << MRX[i] - 100 << " " << MRY[i] - 100 << "\n";
    }
  }
}

int main() {
  starttime = GetSeconds();
  srand((unsigned) time(NULL));
  xs.setSeed(rand() % 65536 + 65537);
  cerr << "x: " << xs.x << endl;
  init();
  solve();
#ifdef LOCAL
  // sleep(0.5);
#endif
  output();
  cerr << "output time: " << (GetSeconds() - starttime) << endl;
  // sleep(0.1);

  return 0;
}
