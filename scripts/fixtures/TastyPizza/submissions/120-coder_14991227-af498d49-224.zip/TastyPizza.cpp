﻿// Topcoder Open 2020 - Finals - TastyPizza.
// Author: vdave, Hungary.

#define NOMINMAX
#define _CRT_SECURE_NO_WARNINGS

//#pragma GCC target "avx"

#include <algorithm>
#include <cstdio>
#include <cfloat>
#include <cmath>
#include <cstring>
#include <iostream>
#include <map>
#include <random>
#include <set>
#include <string>
#include <utility>
#include <vector>
#include <unordered_map>
#include <unordered_set>

using namespace std;

#define TC_DEBUG

#ifdef TC_DEBUG
#define DEBUG(...) fprintf(fDebug, __VA_ARGS__)
#define GDEBUG(s, ...) { sprintf(sTmp, __VA_ARGS__); s.append(sTmp); }
#else
#define DEBUG(...)
#define GDEBUG(...)
#endif

// Platform specific stuff (timer, alignment, some intrinsics).

#ifdef _WIN32

// WIN32 platform definitions

#define ALIGN_SSE __declspec(align(64))
#define NOINLINE __declspec(noinline)

#include <ctime>
#include <intrin.h>
#include <windows.h>

typedef LARGE_INTEGER hp_timer_t;
LARGE_INTEGER gl_timer_freq;
double gl_timer_multiplier;

void InitTimer() {
	QueryPerformanceFrequency(&gl_timer_freq);
	gl_timer_multiplier = 1000000.0 / (double)gl_timer_freq.QuadPart;
}

void FetchTime(hp_timer_t* timer_value) {
	QueryPerformanceCounter(timer_value);
}

double GetElapsedMicros(hp_timer_t& timer_value_begin, hp_timer_t& timer_value_end) {
	return gl_timer_multiplier * (timer_value_end.QuadPart - timer_value_begin.QuadPart);
}

int __gcd(int a, int b) {
	if (b == 0) return a;
	return __gcd(b, a % b);
}

#else

// LINUX platform definitions

#define ALIGN_SSE __attribute__((aligned (64)))
#define NOINLINE

#include <sys/time.h>
#include <ctime>
#include <random>

typedef struct timeval hp_timer_t;

void InitTimer() {
}

void FetchTime(hp_timer_t* timer_value) {
	gettimeofday(timer_value, nullptr);
}

double GetElapsedMicros(hp_timer_t& timer_value_begin,
	hp_timer_t& timer_value_end) {
	return (timer_value_end.tv_sec * 1000000.0 + timer_value_end.tv_usec)
		- (timer_value_begin.tv_sec * 1000000.0 + timer_value_begin.tv_usec);
}

#endif



// Debug information for local runs.
bool dbgHasExtraInput;
int dbgSeed;
FILE* fDebug = stderr;
char sTmp[65536];

// Global tweaking constants.
constexpr double kMaxRuntimeMicros = 9.6 * 1000.0 * 1000.0;

// Problem-specific tweaking constants.
constexpr double kTempInitial = 1000.0;
constexpr double kTempCoolFactor = 0.99999;
constexpr int kSAIterations = 2000000;
constexpr bool kUseTiledOverlapPrediction = true;

// Global randomness.
mt19937 randEngine;
std::uniform_real_distribution<double> randProb(0.0, 1.0);

// Timekeeping.
hp_timer_t tBegin, tInit, tCurrent;
int currentRound, numIters;
int roundsPerTimeCheck = 1;
double estimatedProgress = 0.0;

// Input copied.
struct TCircle {
	int r;
	int cx;
	int cy;
	double A;
	unsigned long long areaMask;
};

struct TRectangle {
	int w;
	int h;
	int x0;
	int y0;
	int x1;
	int y1;
	double A;
	unsigned long long areaMask;
};

struct PackingItem {
	// Index into currentR[]
	int ri;
	// (x0, y0) is relative to the packing box.
	int x0;
	int y0;
};

constexpr double kPI = 3.14159265359;
constexpr int kBaseRadius = 100;
constexpr int kBaseRadiusSq = kBaseRadius * kBaseRadius;
constexpr int kUnused = -10000000;

int C, R;
double X;
TCircle inputC[512];
TRectangle inputR[512];
int orderC[512];
int orderR[512];
double sumC, sumR;

// Precalculated overlap coverage masks.
// maskCircle[CenterX][CenterY][Radius]
unsigned long long maskCircle[210][210][16];
// maskRectangle[X0][Y0][W][H].
unsigned long long maskRectangle[210][210][32][32];
// Points inside the pizza circle ordered descending by their distance from the center.
int numCheckPos;
pair<int, int> circleCheckPos[65536];


// Currently evaluated solution.
double currentScore;
TCircle currentC[512];
TRectangle currentR[512];
double currentAreaC, currentAreaR;
int currentNumC, currentNumR;
int currentIndexC[512], currentIndexR[512];

// Variable for the rectangle packing subproblem (one particular packing)
int packResultSize;
double packResultArea;
PackingItem packResult[512];
bool packUsedRect[512];

int bestPackResultSize;
double bestPackResultArea;
PackingItem bestPackResult[512];


int packNumCol;
int packColX[200];
int packColHeight[200];
int packColWidth[200];

int packNumRow;
int packRowY[200];
int packRowHeight[200];
int packRowWidth[200];

double bestPackCompactness, bestPackCoverage;
pair<int, int> bestPackRect[512];

int packCount;
TRectangle packRectangles[512];


// Best answer and score so far.
double bestScore, bestAreaC, bestAreaR;
double bestFillRatio;
TCircle bestC[512];
TRectangle bestR[512];

// Solver API.
class TastyPizza {
public:
	vector<string> findSolution(int aC, int aR, double aX, const vector<int>& aCircles, const vector<pair<int, int>>& aRects);
};



// Updates the best solution with the current one if the score is better (lower).
void MaybeUpdateBest() {
	if (currentScore > bestScore) {
		bestScore = currentScore;
		bestAreaC = currentAreaC;
		bestAreaR = currentAreaR;
		bestFillRatio = (bestAreaC + bestAreaR) / (kPI * kBaseRadiusSq);
		for (int c = 0; c < C; ++c) {
			bestC[c] = currentC[c];
		}
		for (int r = 0; r < R; ++r) {
			bestR[r] = currentR[r];
		}
		DEBUG("[S=%d, R=%d] New Best = %.8lf [FillRation = %.6lf]\n", dbgSeed, currentRound, bestScore, bestFillRatio);
	}
}

double ScoreDiffFactor() {
	return X * currentAreaC - (1.0 - X) * currentAreaR;
}

double Score() {
	return currentAreaC + currentAreaR - std::abs(ScoreDiffFactor());
}

inline bool InsidePizza(int x, int y) {
	return (x * x + y * y) <= kBaseRadiusSq;
}

inline bool FitsPizza(const TCircle& c) {
	const int deltaR = kBaseRadius - c.r;
	return (c.cx * c.cx) + (c.cy * c.cy) <= deltaR * deltaR;
}

inline bool FitsPizza(const TRectangle& r) {
	return InsidePizza(r.x0, r.y0) && InsidePizza(r.x0 + r.w, r.y0) && InsidePizza(r.x0, r.y0 + r.h) && InsidePizza(r.x0 + r.w, r.y0 + r.h);
}

inline bool Overlap(const TCircle& c1, const TCircle& c2) {
	if ((c1.areaMask & c2.areaMask) == 0) return false;

	const int dx = c1.cx - c2.cx;
	const int dy = c1.cy - c2.cy;
	const int sum_r = c1.r + c2.r;
	return (dx * dx + dy * dy) < (sum_r * sum_r);
}

inline double Distance(const TCircle& c1, const TCircle& c2) {
	const int dx = c1.cx - c2.cx;
	const int dy = c1.cy - c2.cy;
	const int sum_r = c1.r + c2.r;
	return sqrt(dx * dx + dy * dy) - sum_r;
}

inline bool OverlapForce(const TRectangle& r1, const TRectangle& r2) {
	const int maxL = std::max(r1.x0, r2.x0);
	const int minR = std::min(r1.x1, r2.x1);
	if (maxL >= minR) return false;
	const int maxB = std::max(r1.y0, r2.y0);
	const int minT = std::min(r1.y1, r2.y1);
	return maxB < minT;
}

inline bool Overlap(const TRectangle& r1, const TRectangle& r2) {
	if ((r1.areaMask & r2.areaMask) == 0) return false;

	return OverlapForce(r1, r2);
}

inline bool OverlapForce(const TRectangle& r, const TCircle& c) {
	int cx_nearest = c.cx < r.x0 ? r.x0 : c.cx > r.x1 ? r.x1 : c.cx;
	int cy_nearest = c.cy < r.y0 ? r.y0 : c.cy > r.y1 ? r.y1 : c.cy;
	const int dx = cx_nearest - c.cx;
	const int dy = cy_nearest - c.cy;
	return (dx * dx + dy * dy) < c.r * c.r;
}

inline bool Overlap(const TRectangle& r, const TCircle& c) {
	if ((r.areaMask & c.areaMask) == 0) return false;

	return OverlapForce(r, c);
}


// Place circle #changeC to the pizza, assume currentC[changeC] is already filled out with coordinates.
void PlaceCircle(int changeC) {
	currentIndexC[currentNumC++] = changeC;
	currentAreaC += inputC[changeC].A;
	currentScore = Score();

	// Calculate the area mask for the circle
	const int tileSize = 25;
	unsigned long long resultMask = 0;
	unsigned long long currentBit = 1;
	TRectangle tileRect;
	tileRect.w = tileSize;
	tileRect.h = tileSize;
	for (int yTile = 0; yTile < 8; yTile++) {
		tileRect.y0 = -kBaseRadius + (tileSize * yTile);
		tileRect.y1 = tileRect.y0 + tileSize;
		for (int xTile = 0; xTile < 8; xTile++) {
			tileRect.x0 = -kBaseRadius + (tileSize * xTile);
			tileRect.x1 = tileRect.x0 + tileSize;

			if (OverlapForce(tileRect, currentC[changeC])) {
				resultMask |= currentBit;
			}
			currentBit = currentBit << 1;
		}
	}
	currentC[changeC].areaMask = resultMask;
}

// Place rectange #changeR to the pizza, assume currentR[changeR] is already filled out with coordinates.
void PlaceRectangle(int changeR) {
	currentIndexR[currentNumR++] = changeR;
	currentAreaR += inputR[changeR].A;
	currentScore = Score();

	// Calculate the area mask for the rectangle.
	const int tileSize = 25;
	unsigned long long resultMask = 0;
	unsigned long long currentBit = 1;
	TRectangle tileRect;
	tileRect.w = tileSize;
	tileRect.h = tileSize;
	for (int yTile = 0; yTile < 8; yTile++) {
		tileRect.y0 = -kBaseRadius + (tileSize * yTile);
		tileRect.y1 = tileRect.y0 + tileSize;
		for (int xTile = 0; xTile < 8; xTile++) {
			tileRect.x0 = -kBaseRadius + (tileSize * xTile);
			tileRect.x1 = tileRect.x0 + tileSize;

			if (OverlapForce(tileRect, currentR[changeR])) {
				resultMask |= currentBit;
			}
			currentBit = currentBit << 1;
		}
	}

	currentR[changeR].areaMask = resultMask;
}

void PrefillMask(TRectangle& r) {
	int startTileY = (r.y0 + 100) / 25;
	int endTileY = std::min(7, (r.y1 + 100) / 25);
	int startTileX = (r.x0 + 100) / 25;
	int endTileX = std::min(7, (r.x1 + 100) / 25);

	unsigned long long mask = 0;
	for (int yTile = startTileY; yTile <= endTileY; ++yTile) {
		for (int xTile = startTileX; xTile <= endTileX; ++xTile) {
			mask |= 1ull << (yTile * 8 + xTile);
		}
	}
	r.areaMask = mask;
}

void PrefillMask(TCircle& c) {
	int startTileY = (c.cy - c.r + 100) / 25;
	int endTileY = std::min(7, (c.cy + c.r + 100) / 25);
	int startTileX = (c.cx - c.r + 100) / 25;
	int endTileX = std::min(7, (c.cx + c.r + 100) / 25);

	unsigned long long mask = 0;
	for (int yTile = startTileY; yTile <= endTileY; ++yTile) {
		for (int xTile = startTileX; xTile <= endTileX; ++xTile) {
			mask |= 1ull << (yTile * 8 + xTile);
		}
	}
	c.areaMask = mask;
}

// Create an as dense as possible packing of rectangles of the given size, result is stored in packResult.
void PackRectangles(int packW, int packH) {
	// Try packing by rows or by columns.
	bestPackResultArea = 0.0;
	bestPackResultSize = 0;
	for (int method = 0; method < 4; method++) {
		for (int subMethod = 0; subMethod < 25; ++subMethod) {
			// Initialize packing.
			packResultSize = 0;
			packResultArea = 0.0;
			for (int r = 0; r < R; ++r) {
				packUsedRect[r] = currentR[r].x0 != kUnused;
			}

			// Method [0 - 3]: Try to make optimal columns.
			if (method == 0) {
				int heightMargin = subMethod / 5;
				int widthMargin = subMethod % 5;

				int remainingW = packW;
				int currentCol = 0;
				for (int colSize = 25; colSize >= 5; --colSize) {
					// Don't make an unfillable void on the right.
					if (remainingW < colSize) continue;
					if (remainingW != colSize && remainingW - colSize < 7) continue;

					vector<int> possibleHeights(packH + 1, -1);
					possibleHeights[0] = 0;

					for (int r = 0; r < R; ++r) {
						if (packUsedRect[r]) continue;
						if (currentR[r].w > colSize) continue;
						if (currentR[r].w < colSize -  widthMargin) continue;
						for (int z = packH; z >= 0; --z) {
							if (possibleHeights[z] >= 0 && z + currentR[r].h <= packH && possibleHeights[z + currentR[r].h] < 0) {
								possibleHeights[z + currentR[r].h] = r;
							}
						}
					}

					for (int h = packH; h > 0; h--) {
						if (possibleHeights[h] >= 0 && h > packH - heightMargin) {
							while (h > 0) {
								const int changeR = possibleHeights[h];
								const int Rh = currentR[changeR].h;

								packUsedRect[changeR] = true;
								packResult[packResultSize].ri = changeR;
								packResult[packResultSize].x0 = currentCol;
								packResult[packResultSize].y0 = h - Rh;
								packResultSize++;
								packResultArea += inputR[changeR].A;

								h -= Rh;
							}

							currentCol += colSize;
							remainingW -= colSize;
							colSize++;
							break;
						}
					}

					if (remainingW == 0) break;
				}
			}
			else if (method == 1) {
				int heightMargin = subMethod / 5;
				int widthMargin = subMethod % 5;

				int remainingH = packH;
				int currentRow = 0;
				for (int rowSize = 25; rowSize >= 5; --rowSize) {
					// Don't make an unfillable void on the top.
					if (remainingH < rowSize) continue;
					if (remainingH != rowSize && remainingH - rowSize < 7) continue;

					vector<int> possibleWidths(packW + 1, -1);
					possibleWidths[0] = 0;

					for (int r = 0; r < R; ++r) {
						if (packUsedRect[r]) continue;
						if (currentR[r].h > rowSize) continue;
						if (currentR[r].h < rowSize - heightMargin) continue;
						for (int z = packW; z >= 0; --z) {
							if (possibleWidths[z] >= 0 && z + currentR[r].w <= packW && possibleWidths[z + currentR[r].w] < 0) {
								possibleWidths[z + currentR[r].w] = r;
							}
						}
					}

					for (int w = packW; w > 0; w--) {
						if (possibleWidths[w] >= 0 && w > packW - widthMargin) {
							while (w > 0) {
								const int changeR = possibleWidths[w];
								const int Rw = currentR[changeR].w;

								packUsedRect[changeR] = true;
								packResult[packResultSize].ri = changeR;
								packResult[packResultSize].x0 = w - Rw;
								packResult[packResultSize].y0 = currentRow;
								packResultSize++;
								packResultArea += inputR[changeR].A;

								w -= Rw;
							}

							currentRow += rowSize;
							remainingH -= rowSize;
							rowSize++;
							break;
						}
					}

					if (remainingH == 0) break;
				}
			}
			else if (method == 2 && subMethod == 0) {
				packNumCol = 0;
				int startCol = 0;
				for (int ri = 0; ri < R; ++ri) {
					const int changeR = orderR[ri];
					const auto& rect = currentR[changeR];
					if (rect.x0 != kUnused) continue;

					// Find the first column the entry fits into.
					int matchCol = 0;
					while (matchCol < packNumCol) {
						if (packColWidth[matchCol] >= rect.w && packColHeight[matchCol] + rect.h <= packH) break;
						matchCol++;
					}

					if (matchCol == packNumCol) {
						// Did not fit into existing columns, check if it can be the base of a new column
						if (startCol + rect.w > packW) continue;
						if (rect.h > packH) continue;

						// Yes, create the new column with this single entry.
						packColWidth[packNumCol] = rect.w;
						packColHeight[packNumCol] = 0;
						packColX[packNumCol] = startCol;
						startCol += packColWidth[packNumCol];
						packNumCol++;
					}
					if (packColHeight[matchCol] + rect.h <= packH) {
						// Fits to the current column.
						packResult[packResultSize].ri = changeR;
						packResult[packResultSize].x0 = packColX[matchCol];
						packResult[packResultSize].y0 = packColHeight[matchCol];
						packResultSize++;
						packResultArea += inputR[changeR].A;

						packColHeight[matchCol] += rect.h;
					}
				}
			}

			if (packResultArea > bestPackResultArea) {
				bestPackResultArea = packResultArea;
				bestPackResultSize = packResultSize;
				for (int i = 0; i < bestPackResultSize; i++) {
					bestPackResult[i] = packResult[i];
				}
			}
		}
	}

	packResultArea = bestPackResultArea;
	packResultSize = bestPackResultSize;
	for (int i = 0; i < packResultSize; i++) {
		packResult[i] = bestPackResult[i];
	}
}



// MAIN SOLVER BEGINS HERE.

void InitializeBest() {
	// Initialize best solution.
	for (int c = 0; c < C; ++c) {
		bestC[c].cx = kUnused;
	}
	for (int r = 0; r < R; ++r) {
		bestR[r].x0 = kUnused;
	}
	bestScore = 0.0;
	bestFillRatio = 0.75 + 0.1 * X;
}

void PrecalculateArea() {
	// Precalculat circle and rectangle area.
	sumC = 0.0;
	for (int c = 0; c < C; ++c) {
		inputC[c].A = kPI * inputC[c].r * inputC[c].r;
		currentC[c].A = inputC[c].A;
		sumC += inputC[c].A;
	}
	sumR = 0.0;
	for (int r = 0; r < R; ++r) {
		inputR[r].A = inputR[r].w * inputR[r].h;
		currentR[r].A = inputR[r].A;
		sumR += inputR[r].A;
	}
}

void PrecalculateSizeOrder() {
	// Precalculate order of circles and rectangles.
	vector<pair<int, int>> C_by_radius(C);
	for (int c = 0; c < C; ++c) {
		C_by_radius.emplace_back(-inputC[c].r, c);
	}
	std::sort(C_by_radius.begin(), C_by_radius.end());
	for (int c = 0; c < C; ++c) {
		orderC[c] = C_by_radius[c].second;
	}
	vector<pair<pair<int, int>, int>> R_by_W_and_H(R);
	for (int r = 0; r < R; ++r) {
		R_by_W_and_H.emplace_back(make_pair(-inputR[r].w, -inputR[r].h), r);
	}
	std::sort(R_by_W_and_H.begin(), R_by_W_and_H.end());
	for (int r = 0; r < R; ++r) {
		orderR[r] = R_by_W_and_H[r].second;
	}
}

void PrecalculateInternalPoints() {
	// Precalculate the order of in-pizza points in decreasing distance from center order.
	vector<pair<int, pair<int, int>>> P_by_Distance;
	for (int y = -99; y < 100; ++y) {
		for (int x = -99; x < 100; ++x) {
			const int d2 = (x * x) + (y * y);
			if (d2 >= kBaseRadiusSq) continue;
			P_by_Distance.emplace_back(-d2, make_pair(x, y));
		}
	}
	std::sort(P_by_Distance.begin(), P_by_Distance.end());
	numCheckPos = (int)P_by_Distance.size();
	for (int i = 0; i < numCheckPos; ++i) {
		circleCheckPos[i] = P_by_Distance[i].second;
	}
}

void PrecalculateCoverageBitmask() {
	// Precalculate 64-bit tile coverage mask for all possible circles and rectangles.
	TCircle circle;
	for (int cx = -99; cx <= 99; ++cx) {
		circle.cx = cx;
		for (int cy = -99; cy <= 99; ++cy) {
			circle.cy = cy;
			for (int r = 5; r <= 15; ++r) {
				circle.r = r;
				PrefillMask(circle);
				maskCircle[100 + cx][100 + cy][r] = circle.areaMask;
			}
		}
	}

	TRectangle rect;
	for (int x0 = -99; x0 <= 99; ++x0) {
		rect.x0 = x0;
		for (int y0 = -99; y0 <= 99; ++y0) {
			rect.y0 = y0;
			for (int w = 5; w <= 25; ++w) {
				rect.w = w;
				rect.x1 = rect.x0 + w;
				for (int h = 5; h <= 25; ++h) {
					rect.h = h;
					rect.y1 = rect.y0 + h;
					PrefillMask(rect);
					maskRectangle[100 + x0][100 + y0][w][h] = rect.areaMask;
				}
			}
		}
	}
}

void DisplayTheoreticalLimit() {
	// Calculate maximum obtainable score (everything placed perfectly)
	double maxScore = 0.0;
	double maxAreaR = X * kPI * kBaseRadiusSq;
	double maxAreaC = (1.0 - X) * kPI * kBaseRadiusSq;
	if (sumR >= maxAreaR && sumC >= maxAreaC) {
		double optC = maxAreaC;
		double optR = maxAreaR;
		maxScore = optC + optR - abs(X * optC - (1.0 - X) * optR);
	}
	else if (sumR >= maxAreaR && sumC < maxAreaC) {
		double optC = sumC;
		double optR = std::min(sumR, kPI * kBaseRadiusSq - sumC);
		maxScore = optC + optR - abs(X * optC - (1.0 - X) * optR);
	}
	else if (sumR < maxAreaR && sumC >= maxAreaC) {
		double optC = std::min(sumC, kPI * kBaseRadiusSq - sumR);
		double optR = sumR;
		maxScore = optC + optR - abs(X * optC - (1.0 - X) * optR);
	}
	else {
		maxScore = sumC + sumR - abs(X * sumC - (1.0 - X) * sumR);
	}
	DEBUG("Theoritical max score = %.4lf [C = %.4lf (opt) vs %.4lf (max)] [R = %.4lf (opt) vs %.4lf (max)]\n", maxScore, maxAreaC, sumC, maxAreaR, sumR);
}

// Tries to compact existing circles (assuming no rectangles have been placed yet).
void CompactCircles(int maxIterations, bool isRect = false) {
	for (int forceIter = 0; forceIter < maxIterations; ++forceIter) {
		const int ci = randEngine() % currentNumC;
		const int c = currentIndexC[ci];
		auto& circle = currentC[c];
		// Try to push the circles to the left and towards the Y = 0 axis.
		double forceX = -100.0;
		double forceY = -circle.cy;
		// Try to push the circles closer together.
		for (int i = 0; i < currentNumC; ++i) {
			if (i == ci) continue;
			const int c2 = currentIndexC[i];
			auto& circle2 = currentC[c2];
			int dx = circle2.cx - circle.cx;
			int dy = circle2.cy - circle.cy;
			double d = 1.0 * (dx * dx + dy * dy);
			forceX += 20.81 * dx / (d + 1);
			forceY += 20.81 * dy / (d + 1);
		}

		int oldCX = circle.cx;
		int oldCY = circle.cy;
		int newCX = circle.cx;
		int newCY = circle.cy;

		// In the first 25% allow random movements.

		int action = randEngine() % 16;
		if (forceIter > maxIterations / 4) action += 16;
		if (action == 0) {
			newCX++;
		}
		else if (action == 1) {
			newCX--;
		}
		else if (action == 2) {
			newCY++;
		}
		else if (action == 3) {
			newCY--;
		}
		else {
			// Otherwise push towards the force.
			bool dominantX = abs(forceX) > abs(forceY);
			if (action % 8 == 0) dominantX = !dominantX;
			if (dominantX) {
				if (forceX > 0) {
					newCX++;
				}
				else {
					newCX--;
				}
			}
			else {
				if (forceY > 0) {
					newCY++;
				}
				else {
					newCY--;
				}
			}
		}

		// Check if moving to the new position does not cause overlap
		circle.cx = newCX;
		circle.cy = newCY;
		circle.areaMask = maskCircle[circle.cx + 100][circle.cy + 100][circle.r];
		bool noOverlap = true;
		if (!FitsPizza(circle)) {
			noOverlap = false;
		}
		else {
			for (int i = 0; i < currentNumC; ++i) {
				if (i == ci) continue;
				if (Overlap(circle, currentC[currentIndexC[i]])) {
					noOverlap = false;
					break;
				}
			}
			if (isRect) {
				for (int ri = 0; ri < currentNumR; ++ri) {
					if (Overlap(currentR[currentIndexR[ri]], circle)) {
						noOverlap = false;
						break;
					}
				}

			}
		}

		if (noOverlap) {
			circle.areaMask = maskCircle[circle.cx + 100][circle.cy + 100][circle.r];
		}
		else {
			circle.cx = oldCX;
			circle.cy = oldCY;
			circle.areaMask = maskCircle[circle.cx + 100][circle.cy + 100][circle.r];
		}
	}
}

vector<string> TastyPizza::findSolution(int aC, int aR, double aX, const vector<int>& aCircles, const vector<pair<int, int>>& aRects) {
	// Initalize timing, randomness.
	InitTimer();
	FetchTime(&tBegin);
	randEngine.seed(0xdeadbeef);

	// Save input.
	C = aC;
	R = aR;
	X = aX;
	for (int c = 0; c < C; ++c) {
		inputC[c].r = aCircles[c];
		currentC[c].r = inputC[c].r;
	}
	for (int r = 0; r < R; ++r) {
		inputR[r].w = aRects[r].first;
		inputR[r].h = aRects[r].second;
		currentR[r].w = inputR[r].w;
		currentR[r].h = inputR[r].h;
	}

	InitializeBest();
	PrecalculateArea();
	PrecalculateSizeOrder();
	PrecalculateInternalPoints();
	PrecalculateCoverageBitmask();
	DisplayTheoreticalLimit();

	FetchTime(&tInit);
	DEBUG("Initialization time: %.3lf us.\n", GetElapsedMicros(tBegin, tInit));

	// IDEAS
	// PENDING
	// (1) Always place circle as far out as possible and as close to neighboring circles.
	//     => Too slow to check all possible positions, would need the circle placing bitmap (#7)
	// (7) Have a constantly updated bitmap of 200 x 200 x 11 to see if a circle with given center and radius is still feasible or not, it's MUCH
	//     cheaper to update that bitmap than running the overlap checking gazillions of times. Not compatible with removing circles.
	// DONE
	// (6) Fast overlap prediction, divide 200 x 200 area to 25 x 25 tiles => 64 bits of data if a given shape overlaps that tile, if
	//     two shapes have no common bits in the bitmask, they clearly never overlap.
	// (2) Skip large circles / rectangles. If we need AreaC amount of circles, use the smallest set whose total area is around that (times X).
	//     => For circles it mysteriously did not work.
	// (4) Dynamic programming for optimal columns in rect packing.
	// (5) More rectangle packing variations (columns / rows / Guillotine???)

	// SOLVE PROBLEM.
	currentRound = 0;
	roundsPerTimeCheck = 1;
	while (true) {
		currentRound++;
		if (currentRound % roundsPerTimeCheck == 0) {
			FetchTime(&tCurrent);
			const double elapsedMicros = GetElapsedMicros(tBegin, tCurrent);
			if (elapsedMicros > kMaxRuntimeMicros)
				break;
		}

		// Use the current best results's fill ratio to estimate the expected R and C areas
		const double expectedFillRate = bestFillRatio;
		double optimalAreaR = expectedFillRate * X * kPI * kBaseRadiusSq * 1.01;
		double optimalAreaC = expectedFillRate * (1.0 - X) * kPI * kBaseRadiusSq;
		double targetAreaC = std::min(optimalAreaC, sumC);

		// Initialize candidate solution, no circles / rectangles are used.
		for (int c = 0; c < C; ++c) {
			currentC[c].cx = kUnused;
		}
		for (int r = 0; r < R; ++r) {
			currentR[r].x0 = kUnused;
		}
		currentNumC = 0;
		currentNumR = 0;
		currentAreaC = 0.0;
		currentAreaR = 0.0;
		currentScore = 0.0;

		int packLowX = -100;
		double packTargetA = optimalAreaR;
		bool preAssignCircles = false;
		if (std::min(optimalAreaC, sumC) < 10000.0) {
			preAssignCircles = randEngine() % 4 != 0;
		}
		else {
			preAssignCircles = randEngine() % 4 == 0;
		}

		if (!preAssignCircles) {
			if (randEngine() % 3 == 0) {
				double sumA = 0.0;
				for (packLowX = 100; sumA < optimalAreaR * 1.15;) {
					packLowX--;
					sumA += 2.0 * sqrt(10000 - packLowX * packLowX);
				}
			}
		}

		if (preAssignCircles) {
			// Special implementation for cases where small amount of circles needed, try to pack them to the left side of the circle.
			int circlesMaxW = 200;

			double T = kTempInitial * 0.1;
			int lastChangeIter = 0;
			int cIndex = 0;
			for (int iter = 0; iter < kSAIterations; ++iter) {
				T *= kTempCoolFactor;

				if (iter % 1000 == 0) {
					FetchTime(&tCurrent);
					const double elapsedMicros = GetElapsedMicros(tBegin, tCurrent);
					if (elapsedMicros > kMaxRuntimeMicros)
						break;
				}

				// No changes in 5000 iterations, stop improving this candidate.
				if (iter > lastChangeIter + 100000) break;

				// Try to place a circle.
				//const int changeC = randEngine() % C;
				const int changeC = orderC[C - 1 - (cIndex++ % C)];
				if (currentC[changeC].cx != kUnused) continue;

				bool isPlaced = false;
				for (int subIter = 0; subIter < 1; ++subIter) {
					currentC[changeC].cx = (randEngine() % (circlesMaxW - currentC[changeC].r)) - kBaseRadius + currentC[changeC].r;
					currentC[changeC].cy = (randEngine() % (2 * kBaseRadius)) - kBaseRadius;

					if (!FitsPizza(currentC[changeC])) continue;

					// Fetch precalculated 64-bit tile mask for faster overlaps.
					currentC[changeC].areaMask = maskCircle[currentC[changeC].cx + 100][currentC[changeC].cy + 100][currentC[changeC].r];

					// Check overlap with existing circles, measure overlapped circle size
					bool noOverlap = true;
					double conflictSize = 0.0;
					int conflictCount = 0;
					for (int ci = 0; ci < currentNumC; ++ci) {
						const int c = currentIndexC[ci];
						if (Overlap(currentC[changeC], currentC[c])) {
							noOverlap = false;
							conflictSize += currentC[c].A;
							conflictCount++;
						}
					}

					if (noOverlap) {
						double oldDeltaC = std::abs(currentAreaC - targetAreaC);
						double newDeltaC = std::abs(currentAreaC + currentC[changeC].A - targetAreaC);
						isPlaced = newDeltaC < oldDeltaC;
						break;
					}
					else {
						// Calculate score change with removing the overlapping ones.
						double oldAreaC = currentAreaC;
						double oldDeltaC = std::abs(oldAreaC - targetAreaC);
						currentAreaC -= conflictSize;
						currentAreaC += currentC[changeC].A;
						double newDeltaC = std::abs(currentAreaC - targetAreaC);

						bool keepChange = newDeltaC < oldDeltaC;
						if (newDeltaC > oldDeltaC) {
							double keepProb = std::exp(1.0 * (oldDeltaC - newDeltaC) / T);
							if (randProb(randEngine) < keepProb) keepChange = true;
						}
						if (keepChange) {
							// Remove the overlapping circles.
							currentAreaC = oldAreaC;
							for (int ci = 0; ci < currentNumC; ++ci) {
								const int c = currentIndexC[ci];
								if (Overlap(currentC[changeC], currentC[c])) {
									currentC[c].cx = kUnused;
									currentAreaC -= currentC[c].A;
									std::swap(currentIndexC[ci], currentIndexC[currentNumC - 1]);
									currentNumC--;
									ci--;
								}
							}
							isPlaced = true;
						}
						else {
							// Revert changes.
							currentAreaC = oldAreaC;
						}
					}
				}

				if (isPlaced) {
					PlaceCircle(changeC);
					//CompactCircles(1000);
					lastChangeIter = iter;
				}
				else {
					currentC[changeC].cx = kUnused;
				}
			}

			CompactCircles(80000);

			packLowX = -100;
			for (int ci = 0; ci < currentNumC; ++ci) {
				const int c = currentIndexC[ci];
				const auto& circle = currentC[c];
				packLowX = std::max(packLowX, circle.cx + circle.r);
			}

			packTargetA = 1000000.0;
		}

		int maxPackArea = 1000000.0;
		int maxPackX0, maxPackY0, maxPackW = -1, maxPackH;
		for (int packW = 5; packW <= 200; packW++) {
			for (int packH = 5; packH <= 200; ++packH) {
				double targetDelta = std::abs(packW * packH - packTargetA);
				if (targetDelta >= maxPackArea) continue;

				int packX0 = packLowX == -100 ? -packW / 2 : packLowX;
				int packY0 = -packH / 2;
				TRectangle packRect = { packW, packH, packX0, packY0, packX0 + packW, packY0 + packH };
				if (FitsPizza(packRect)) {
					maxPackArea = targetDelta;
					maxPackX0 = packX0;
					maxPackY0 = packY0;
					maxPackW = packW;
					maxPackH = packH;
				}
				else {
					break;
				}
			}
		}

		if (maxPackW != -1) {
			PackRectangles(maxPackW, maxPackH);
			for (int i = 0; i < packResultSize; ++i) {
				int r = packResult[i].ri;
				currentR[r].x0 = maxPackX0 + packResult[i].x0;
				currentR[r].y0 = maxPackY0 + packResult[i].y0;
				currentR[r].x1 = currentR[r].x0 + currentR[r].w;
				currentR[r].y1 = currentR[r].y0 + currentR[r].h;
				PlaceRectangle(r);
				packTargetA -= currentR[r].A;
			}

			// Find extra packing area on top
			int maxTopPackArea = 1000000.0;
			int maxTopPackX0, maxTopPackY0, maxTopPackW = -1, maxTopPackH;
			for (int topPackX0 = maxPackX0; topPackX0 <= 100; topPackX0++) {
				for (int topPackW = 5; topPackW < 100 - topPackX0; topPackW++) {
					for (int topPackH = 5; topPackH < 100; ++topPackH) {
						double targetDelta = std::abs(topPackW * topPackH - packTargetA);
						if (targetDelta >= maxTopPackArea) continue;

						int topPackY0 = maxPackY0 + maxPackH;
						TRectangle packRect = { topPackW, topPackH, topPackX0, topPackY0, topPackX0 + topPackW, topPackY0 + topPackH };
						if (FitsPizza(packRect)) {
							maxTopPackArea = targetDelta;
							maxTopPackX0 = topPackX0;
							maxTopPackY0 = topPackY0;
							maxTopPackW = topPackW;
							maxTopPackH = topPackH;
						}
						else {
							break;
						}
					}
				}
			}
			if (maxTopPackW != -1) {
				PackRectangles(maxTopPackW, maxTopPackH);
				for (int i = 0; i < packResultSize; ++i) {
					int r = packResult[i].ri;
					currentR[r].x0 = maxTopPackX0 + packResult[i].x0;
					currentR[r].y0 = maxTopPackY0 + packResult[i].y0;
					currentR[r].x1 = currentR[r].x0 + currentR[r].w;
					currentR[r].y1 = currentR[r].y0 + currentR[r].h;
					PlaceRectangle(r);
					packTargetA -= currentR[r].A;
				}
			}

			// Find extra packing area on bottom.
			int maxBottomPackArea = 1000000.0;
			int maxBottomPackX0, maxBottomPackY0, maxBottomPackW = -1, maxBottomPackH;
			for (int bottomPackX0 = maxPackX0; bottomPackX0 <= 100; bottomPackX0++) {
				for (int bottomPackW = 5; bottomPackW < 100 - bottomPackX0; bottomPackW++) {
					for (int bottomPackH = 5; bottomPackH < 100; ++bottomPackH) {
						double targetDelta = std::abs(bottomPackW * bottomPackH - packTargetA);
						if (targetDelta >= maxBottomPackArea) continue;

						int bottomPackY0 = maxPackY0 - bottomPackH;
						TRectangle packRect = { bottomPackW, bottomPackH, bottomPackX0, bottomPackY0, bottomPackX0 + bottomPackW, bottomPackY0 + bottomPackH };
						if (FitsPizza(packRect)) {
							maxBottomPackArea = targetDelta;
							maxBottomPackX0 = bottomPackX0;
							maxBottomPackY0 = bottomPackY0;
							maxBottomPackW = bottomPackW;
							maxBottomPackH = bottomPackH;
						}
						else {
							break;
						}
					}
				}
			}
			if (maxBottomPackW != -1) {
				PackRectangles(maxBottomPackW, maxBottomPackH);
				for (int i = 0; i < packResultSize; ++i) {
					int r = packResult[i].ri;
					currentR[r].x0 = maxBottomPackX0 + packResult[i].x0;
					currentR[r].y0 = maxBottomPackY0 + packResult[i].y0;
					currentR[r].x1 = currentR[r].x0 + currentR[r].w;
					currentR[r].y1 = currentR[r].y0 + currentR[r].h;
					PlaceRectangle(r);
					packTargetA -= currentR[r].A;
				}
			}

			// Find extra packing area on right.
			int maxRightPackArea = 1000000.0;
			int maxRightPackX0, maxRightPackY0, maxRightPackW = -1, maxRightPackH;
			for (int rightPackY0 = -100; rightPackY0 <= 100; rightPackY0++) {
				for (int rightPackH = 5; rightPackH < 100 - rightPackY0; rightPackH++) {
					for (int rightPackW = 5; rightPackW < 100; ++rightPackW) {
						double targetDelta = std::abs(rightPackW * rightPackH - packTargetA);
						if (targetDelta >= maxRightPackArea) continue;

						int rightPackX0 = maxPackX0 + maxPackW;
						TRectangle packRect = { rightPackW, rightPackH, rightPackX0, rightPackY0, rightPackX0 + rightPackW, rightPackY0 + rightPackH };
						if (FitsPizza(packRect)) {
							maxRightPackArea = targetDelta;
							maxRightPackX0 = rightPackX0;
							maxRightPackY0 = rightPackY0;
							maxRightPackW = rightPackW;
							maxRightPackH = rightPackH;
						}
						else {
							break;
						}
					}
				}
			}
			if (maxRightPackW != -1) {
				PackRectangles(maxRightPackW, maxRightPackH);
				for (int i = 0; i < packResultSize; ++i) {
					int r = packResult[i].ri;
					currentR[r].x0 = maxRightPackX0 + packResult[i].x0;
					currentR[r].y0 = maxRightPackY0 + packResult[i].y0;
					currentR[r].x1 = currentR[r].x0 + currentR[r].w;
					currentR[r].y1 = currentR[r].y0 + currentR[r].h;
					PlaceRectangle(r);
					packTargetA -= currentR[r].A;
				}
			}

			// Find extra packing area on left.
			int maxLeftPackArea = 1000000.0;
			int maxLeftPackX0, maxLeftPackY0, maxLeftPackW = -1, maxLeftPackH;
			if (packLowX == -100) {
				for (int leftPackY0 = -100; leftPackY0 <= 100; leftPackY0++) {
					for (int leftPackH = 5; leftPackH < 100 - leftPackY0; leftPackH++) {
						for (int leftPackW = 5; leftPackW < 100; ++leftPackW) {
							double targetDelta = std::abs(leftPackW * leftPackH - packTargetA);
							if (targetDelta >= maxLeftPackArea) continue;

							int leftPackX0 = maxPackX0 - leftPackW;
							if (leftPackX0 < packLowX) continue;
							TRectangle packRect = { leftPackW, leftPackH, leftPackX0, leftPackY0, leftPackX0 + leftPackW, leftPackY0 + leftPackH };
							if (FitsPizza(packRect)) {
								maxLeftPackArea = targetDelta;
								maxLeftPackX0 = leftPackX0;
								maxLeftPackY0 = leftPackY0;
								maxLeftPackW = leftPackW;
								maxLeftPackH = leftPackH;
							}
							else {
								break;
							}
						}
					}
				}
				if (maxLeftPackW != -1) {
					PackRectangles(maxLeftPackW, maxLeftPackH);
					for (int i = 0; i < packResultSize; ++i) {
						int r = packResult[i].ri;
						currentR[r].x0 = maxLeftPackX0 + packResult[i].x0;
						currentR[r].y0 = maxLeftPackY0 + packResult[i].y0;
						currentR[r].x1 = currentR[r].x0 + currentR[r].w;
						currentR[r].y1 = currentR[r].y0 + currentR[r].h;
						PlaceRectangle(r);
						packTargetA -= currentR[r].A;
					}
				}
			}

			// Find extra packing area on top of the top.
			if (maxTopPackW != -1) {
				int maxTop2PackArea = 1000000.0;
				int maxTop2PackX0, maxTop2PackY0, maxTop2PackW = -1, maxTop2PackH;
				for (int top2PackX0 = maxTopPackX0; top2PackX0 <= 100; top2PackX0++) {
					for (int top2PackW = 5; top2PackW < 100 - top2PackX0; top2PackW++) {
						for (int top2PackH = 5; top2PackH < 100; ++top2PackH) {
							double targetDelta = std::abs(top2PackW * top2PackH - packTargetA);
							if (targetDelta >= maxTop2PackArea) continue;

							int top2PackY0 = maxTopPackY0 + maxTopPackH;
							TRectangle packRect = { top2PackW, top2PackH, top2PackX0, top2PackY0, top2PackX0 + top2PackW, top2PackY0 + top2PackH };
							if (FitsPizza(packRect)) {
								maxTop2PackArea = targetDelta;
								maxTop2PackX0 = top2PackX0;
								maxTop2PackY0 = top2PackY0;
								maxTop2PackW = top2PackW;
								maxTop2PackH = top2PackH;
							}
							else {
								break;
							}
						}
					}
				}
				if (maxTop2PackW != -1) {
					PackRectangles(maxTop2PackW, maxTop2PackH);
					for (int i = 0; i < packResultSize; ++i) {
						int r = packResult[i].ri;
						currentR[r].x0 = maxTop2PackX0 + packResult[i].x0;
						currentR[r].y0 = maxTop2PackY0 + packResult[i].y0;
						currentR[r].x1 = currentR[r].x0 + currentR[r].w;
						currentR[r].y1 = currentR[r].y0 + currentR[r].h;
						PlaceRectangle(r);
						packTargetA -= currentR[r].A;
					}
				}

				// Try the top-left corner.
				int maxTopLeftPackArea = 1000000.0;
				int maxTopLeftPackX0, maxTopLeftPackY0, maxTopLeftPackW = -1, maxTopLeftPackH;
				for (int topLeftPackW = 5; topLeftPackW < 100; topLeftPackW++) {
					for (int topLeftPackH = 5; topLeftPackH < 100; ++topLeftPackH) {
						double targetDelta = std::abs(topLeftPackW * topLeftPackH - packTargetA);
						if (targetDelta >= maxTopLeftPackArea) continue;

						int topLeftPackX0 = maxTopPackX0 - topLeftPackW;
						if (topLeftPackX0 < packLowX) continue;
						int topLeftPackY0 = maxTopPackY0;
						TRectangle packRect = { topLeftPackW, topLeftPackH, topLeftPackX0, topLeftPackY0, topLeftPackX0 + topLeftPackW, topLeftPackY0 + topLeftPackH };
						if (FitsPizza(packRect)) {
							maxTopLeftPackArea = targetDelta;
							maxTopLeftPackX0 = topLeftPackX0;
							maxTopLeftPackY0 = topLeftPackY0;
							maxTopLeftPackW = topLeftPackW;
							maxTopLeftPackH = topLeftPackH;
						}
						else {
							break;
						}
					}
				}
				if (maxTopLeftPackW != -1) {
					PackRectangles(maxTopLeftPackW, maxTopLeftPackH);
					for (int i = 0; i < packResultSize; ++i) {
						int r = packResult[i].ri;
						currentR[r].x0 = maxTopLeftPackX0 + packResult[i].x0;
						currentR[r].y0 = maxTopLeftPackY0 + packResult[i].y0;
						currentR[r].x1 = currentR[r].x0 + currentR[r].w;
						currentR[r].y1 = currentR[r].y0 + currentR[r].h;
						PlaceRectangle(r);
						packTargetA -= currentR[r].A;
					}
				}

				// Try the top-right corner.
				int maxTopRightPackArea = 1000000.0;
				int maxTopRightPackX0, maxTopRightPackY0, maxTopRightPackW = -1, maxTopRightPackH;
				for (int topRightPackW = 5; topRightPackW < 100; topRightPackW++) {
					for (int topRightPackH = 5; topRightPackH < 100; ++topRightPackH) {
						double targetDelta = std::abs(topRightPackW * topRightPackH - packTargetA);
						if (targetDelta >= maxTopRightPackArea) continue;

						int topRightPackX0 = maxTopPackX0 + maxTopPackW;
						int topRightPackY0 = maxTopPackY0;
						TRectangle packRect = { topRightPackW, topRightPackH, topRightPackX0, topRightPackY0, topRightPackX0 + topRightPackW, topRightPackY0 + topRightPackH };
						if (FitsPizza(packRect)) {
							maxTopRightPackArea = targetDelta;
							maxTopRightPackX0 = topRightPackX0;
							maxTopRightPackY0 = topRightPackY0;
							maxTopRightPackW = topRightPackW;
							maxTopRightPackH = topRightPackH;
						}
						else {
							break;
						}
					}
				}
				if (maxTopRightPackW != -1) {
					PackRectangles(maxTopRightPackW, maxTopRightPackH);
					for (int i = 0; i < packResultSize; ++i) {
						int r = packResult[i].ri;
						currentR[r].x0 = maxTopRightPackX0 + packResult[i].x0;
						currentR[r].y0 = maxTopRightPackY0 + packResult[i].y0;
						currentR[r].x1 = currentR[r].x0 + currentR[r].w;
						currentR[r].y1 = currentR[r].y0 + currentR[r].h;
						PlaceRectangle(r);
						packTargetA -= currentR[r].A;
					}
				}
			}

			// Find extra packing area on bottom of the bottom.
			if (maxBottomPackW != -1) {
				int maxBottom2PackArea = 1000000.0;
				int maxBottom2PackX0, maxBottom2PackY0, maxBottom2PackW = -1, maxBottom2PackH;
				for (int bottom2PackX0 = maxBottomPackX0; bottom2PackX0 <= 100; bottom2PackX0++) {
					for (int bottom2PackW = 5; bottom2PackW < 100 - bottom2PackX0; bottom2PackW++) {
						for (int bottom2PackH = 5; bottom2PackH < 100; ++bottom2PackH) {
							double targetDelta = std::abs(bottom2PackW * bottom2PackH - packTargetA);
							if (targetDelta >= maxBottom2PackArea) continue;

							int bottom2PackY0 = maxBottomPackY0 - bottom2PackH;
							TRectangle packRect = { bottom2PackW, bottom2PackH, bottom2PackX0, bottom2PackY0, bottom2PackX0 + bottom2PackW, bottom2PackY0 + bottom2PackH };
							if (FitsPizza(packRect)) {
								maxBottom2PackArea = targetDelta;
								maxBottom2PackX0 = bottom2PackX0;
								maxBottom2PackY0 = bottom2PackY0;
								maxBottom2PackW = bottom2PackW;
								maxBottom2PackH = bottom2PackH;
							}
							else {
								break;
							}
						}
					}
				}
				if (maxBottom2PackW != -1) {
					PackRectangles(maxBottom2PackW, maxBottom2PackH);
					for (int i = 0; i < packResultSize; ++i) {
						int r = packResult[i].ri;
						currentR[r].x0 = maxBottom2PackX0 + packResult[i].x0;
						currentR[r].y0 = maxBottom2PackY0 + packResult[i].y0;
						currentR[r].x1 = currentR[r].x0 + currentR[r].w;
						currentR[r].y1 = currentR[r].y0 + currentR[r].h;
						PlaceRectangle(r);
						packTargetA -= currentR[r].A;
					}
				}

				// Try the bottom-left corner.
				int maxBottomLeftPackArea = 1000000.0;
				int maxBottomLeftPackX0, maxBottomLeftPackY0, maxBottomLeftPackW = -1, maxBottomLeftPackH;
				for (int bottomLeftPackW = 5; bottomLeftPackW < 100; bottomLeftPackW++) {
					for (int bottomLeftPackH = 5; bottomLeftPackH < 100; ++bottomLeftPackH) {
						double targetDelta = std::abs(bottomLeftPackW * bottomLeftPackH - packTargetA);
						if (targetDelta >= maxBottomLeftPackArea) continue;

						int bottomLeftPackX0 = maxBottomPackX0 - bottomLeftPackW;
						if (bottomLeftPackX0 < packLowX) continue;
						int bottomLeftPackY0 = maxPackY0 - bottomLeftPackH;
						TRectangle packRect = { bottomLeftPackW, bottomLeftPackH, bottomLeftPackX0, bottomLeftPackY0, bottomLeftPackX0 + bottomLeftPackW, bottomLeftPackY0 + bottomLeftPackH };
						if (FitsPizza(packRect)) {
							maxBottomLeftPackArea = targetDelta;
							maxBottomLeftPackX0 = bottomLeftPackX0;
							maxBottomLeftPackY0 = bottomLeftPackY0;
							maxBottomLeftPackW = bottomLeftPackW;
							maxBottomLeftPackH = bottomLeftPackH;
						}
						else {
							break;
						}
					}
				}
				if (maxBottomLeftPackW != -1) {
					PackRectangles(maxBottomLeftPackW, maxBottomLeftPackH);
					for (int i = 0; i < packResultSize; ++i) {
						int r = packResult[i].ri;
						currentR[r].x0 = maxBottomLeftPackX0 + packResult[i].x0;
						currentR[r].y0 = maxBottomLeftPackY0 + packResult[i].y0;
						currentR[r].x1 = currentR[r].x0 + currentR[r].w;
						currentR[r].y1 = currentR[r].y0 + currentR[r].h;
						PlaceRectangle(r);
						packTargetA -= currentR[r].A;
					}
				}

				// Try the bottom-right corner.
				int maxBottomRightPackArea = 1000000.0;
				int maxBottomRightPackX0, maxBottomRightPackY0, maxBottomRightPackW = -1, maxBottomRightPackH;
				for (int bottomRightPackW = 5; bottomRightPackW < 100; bottomRightPackW++) {
					for (int bottomRightPackH = 5; bottomRightPackH < 100; ++bottomRightPackH) {
						double targetDelta = std::abs(bottomRightPackW * bottomRightPackH - packTargetA);
						if (targetDelta >= maxBottomRightPackArea) continue;

						int bottomRightPackX0 = maxBottomPackX0 + maxBottomPackW;
						int bottomRightPackY0 = maxPackY0 - bottomRightPackH;
						TRectangle packRect = { bottomRightPackW, bottomRightPackH, bottomRightPackX0, bottomRightPackY0, bottomRightPackX0 + bottomRightPackW, bottomRightPackY0 + bottomRightPackH };
						if (FitsPizza(packRect)) {
							maxBottomRightPackArea = targetDelta;
							maxBottomRightPackX0 = bottomRightPackX0;
							maxBottomRightPackY0 = bottomRightPackY0;
							maxBottomRightPackW = bottomRightPackW;
							maxBottomRightPackH = bottomRightPackH;
						}
						else {
							break;
						}
					}
				}
				if (maxBottomRightPackW != -1) {
					PackRectangles(maxBottomRightPackW, maxBottomRightPackH);
					for (int i = 0; i < packResultSize; ++i) {
						int r = packResult[i].ri;
						currentR[r].x0 = maxBottomRightPackX0 + packResult[i].x0;
						currentR[r].y0 = maxBottomRightPackY0 + packResult[i].y0;
						currentR[r].x1 = currentR[r].x0 + currentR[r].w;
						currentR[r].y1 = currentR[r].y0 + currentR[r].h;
						PlaceRectangle(r);
						packTargetA -= currentR[r].A;
					}
				}
			}

			// Find extra packing area on right of the right;
			if (maxRightPackW != -1) {
				int maxRight2PackArea = 1000000.0;
				int maxRight2PackX0, maxRight2PackY0, maxRight2PackW = -1, maxRight2PackH;
				for (int right2PackY0 = -100; right2PackY0 <= 100; right2PackY0++) {
					for (int right2PackH = 5; right2PackH < 100 - right2PackY0; right2PackH++) {
						for (int right2PackW = 5; right2PackW < 100; ++right2PackW) {
							double targetDelta = std::abs(right2PackW * right2PackH - packTargetA);
							if (targetDelta >= maxRight2PackArea) continue;

							int right2PackX0 = maxRightPackX0 + maxRightPackW;
							TRectangle packRect = { right2PackW, right2PackH, right2PackX0, right2PackY0, right2PackX0 + right2PackW, right2PackY0 + right2PackH };
							if (FitsPizza(packRect)) {
								maxRight2PackArea = targetDelta;
								maxRight2PackX0 = right2PackX0;
								maxRight2PackY0 = right2PackY0;
								maxRight2PackW = right2PackW;
								maxRight2PackH = right2PackH;
							}
							else {
								break;
							}
						}
					}
				}
				if (maxRight2PackW != -1) {
					PackRectangles(maxRight2PackW, maxRight2PackH);
					for (int i = 0; i < packResultSize; ++i) {
						int r = packResult[i].ri;
						currentR[r].x0 = maxRight2PackX0 + packResult[i].x0;
						currentR[r].y0 = maxRight2PackY0 + packResult[i].y0;
						currentR[r].x1 = currentR[r].x0 + currentR[r].w;
						currentR[r].y1 = currentR[r].y0 + currentR[r].h;
						PlaceRectangle(r);
						packTargetA -= currentR[r].A;
					}
				}

				// Try the right-top corner.
				int maxRightTopPackArea = 1000000.0;
				int maxRightTopPackX0, maxRightTopPackY0, maxRightTopPackW = -1, maxRightTopPackH;
				for (int rightTopPackW = 5; rightTopPackW < 100; rightTopPackW++) {
					for (int rightTopPackH = 5; rightTopPackH < 100; ++rightTopPackH) {
						double targetDelta = std::abs(rightTopPackW * rightTopPackH - packTargetA);
						if (targetDelta >= maxRightTopPackArea) continue;

						int rightTopPackX0 = maxRightPackX0;
						int rightTopPackY0 = maxRightPackY0 + maxRightPackH;
						TRectangle packRect = { rightTopPackW, rightTopPackH, rightTopPackX0, rightTopPackY0, rightTopPackX0 + rightTopPackW, rightTopPackY0 + rightTopPackH };
						if (FitsPizza(packRect)) {
							maxRightTopPackArea = targetDelta;
							maxRightTopPackX0 = rightTopPackX0;
							maxRightTopPackY0 = rightTopPackY0;
							maxRightTopPackW = rightTopPackW;
							maxRightTopPackH = rightTopPackH;
						}
						else {
							break;
						}
					}
				}
				if (maxRightTopPackW != -1) {
					PackRectangles(maxRightTopPackW, maxRightTopPackH);
					for (int i = 0; i < packResultSize; ++i) {
						int r = packResult[i].ri;
						currentR[r].x0 = maxRightTopPackX0 + packResult[i].x0;
						currentR[r].y0 = maxRightTopPackY0 + packResult[i].y0;
						currentR[r].x1 = currentR[r].x0 + currentR[r].w;
						currentR[r].y1 = currentR[r].y0 + currentR[r].h;
						PlaceRectangle(r);
						packTargetA -= currentR[r].A;
					}
				}

				// Try the top-right corner.
				int maxRightBottomPackArea = 1000000.0;
				int maxRightBottomPackX0, maxRightBottomPackY0, maxRightBottomPackW = -1, maxRightBottomPackH;
				for (int rightBottomPackW = 5; rightBottomPackW < 100; rightBottomPackW++) {
					for (int rightBottomPackH = 5; rightBottomPackH < 100; ++rightBottomPackH) {
						double targetDelta = std::abs(rightBottomPackW * rightBottomPackH - packTargetA);
						if (targetDelta >= maxRightBottomPackArea) continue;

						int rightBottomPackX0 = maxRightPackX0;
						int rightBottomPackY0 = maxRightPackY0 - rightBottomPackH;
						TRectangle packRect = { rightBottomPackW, rightBottomPackH, rightBottomPackX0, rightBottomPackY0, rightBottomPackX0 + rightBottomPackW, rightBottomPackY0 + rightBottomPackH };
						if (FitsPizza(packRect)) {
							maxRightBottomPackArea = targetDelta;
							maxRightBottomPackX0 = rightBottomPackX0;
							maxRightBottomPackY0 = rightBottomPackY0;
							maxRightBottomPackW = rightBottomPackW;
							maxRightBottomPackH = rightBottomPackH;
						}
						else {
							break;
						}
					}
				}
				if (maxRightBottomPackW != -1) {
					PackRectangles(maxRightBottomPackW, maxRightBottomPackH);
					for (int i = 0; i < packResultSize; ++i) {
						int r = packResult[i].ri;
						currentR[r].x0 = maxRightBottomPackX0 + packResult[i].x0;
						currentR[r].y0 = maxRightBottomPackY0 + packResult[i].y0;
						currentR[r].x1 = currentR[r].x0 + currentR[r].w;
						currentR[r].y1 = currentR[r].y0 + currentR[r].h;
						PlaceRectangle(r);
						packTargetA -= currentR[r].A;
					}
				}
			}
		}

		// Fine tune solution.
		double T = kTempInitial;
		int lastChangeIter = 0;
		int cIndex = 0;
		for (int iter = 0; iter < kSAIterations; ++iter) {
			T *= kTempCoolFactor;

			if (iter % 1000 == 0) {
				FetchTime(&tCurrent);
				const double elapsedMicros = GetElapsedMicros(tBegin, tCurrent);
				if (elapsedMicros > kMaxRuntimeMicros)
					break;
			}

			if (iter % 10000 == 9999) {
				CompactCircles(25000, true);
			}

			// No changes in 5000 iterations, stop improving this candidate.
			if (iter > lastChangeIter + 100000) break;

			// Factor inside the abs(), positive => more rectangles needed, negative => more circles needed.
			double diffFactor = ScoreDiffFactor();
			//const bool isCircle = randEngine() % 2;
			bool isCircle = diffFactor < 0;
			if (currentNumR == R) isCircle = true;
			if (currentNumC == C) isCircle = false;
			if (isCircle) {
				// Try to place a circle.
				const int changeC = randEngine() % C;
				//const int changeC = orderC[cIndex++ % C];
				if (currentC[changeC].cx != kUnused) continue;

				// Try 500 different positions.
				bool isPlaced = false;

				//// Try 500 different positions.
				for (int subIter = 0; subIter < 1; ++subIter) {
					currentC[changeC].cx = (randEngine() % (2 * kBaseRadius)) - kBaseRadius;
					currentC[changeC].cy = (randEngine() % (2 * kBaseRadius)) - kBaseRadius;
					if (!FitsPizza(currentC[changeC])) continue;

					// Fetch precalculated 64-bit tile mask for faster overlaps.
					currentC[changeC].areaMask = maskCircle[currentC[changeC].cx + 100][currentC[changeC].cy + 100][currentC[changeC].r];

					// Check overlap with existing rectangles.
					bool noOverlap = true;
					for (int ri = 0; ri < currentNumR; ++ri) {
						const int r = currentIndexR[ri];
						if (Overlap(currentR[r], currentC[changeC])) {
							noOverlap = false;
							break;
						}
					}
					if (!noOverlap) break;

					// Check overlap with existing circles, measure overlapped circle size
					double conflictSize = 0.0;
					int conflictCount = 0;
					for (int ci = 0; ci < currentNumC; ++ci) {
						const int c = currentIndexC[ci];
						if (Overlap(currentC[changeC], currentC[c])) {
							noOverlap = false;
							conflictSize += currentC[c].A;
							conflictCount++;
						}
					}

					if (noOverlap) {
						isPlaced = true;
						break;
					}
					else {
						// Calculate score change with removing the overlapping ones.
						double oldScore = currentScore;
						double oldAreaC = currentAreaC;
						currentAreaC -= conflictSize;
						currentAreaC += currentC[changeC].A;
						currentScore = Score();

						bool keepChange = currentScore > oldScore;
						if (currentScore < oldScore) {
							double keepProb = std::exp(1.0 * (currentScore - oldScore) / T);
							if (randProb(randEngine) < keepProb) keepChange = true;
						}
						if (keepChange) {
							// Remove the overlapping circles.
							currentAreaC = oldAreaC;
							for (int ci = 0; ci < currentNumC; ++ci) {
								const int c = currentIndexC[ci];
								if (Overlap(currentC[changeC], currentC[c])) {
									currentC[c].cx = kUnused;
									currentAreaC -= currentC[c].A;
									std::swap(currentIndexC[ci], currentIndexC[currentNumC - 1]);
									currentNumC--;
									ci--;
								}
							}
							isPlaced = true;
						}
						else {
							// Revert changes.
							currentScore = oldScore;
							currentAreaC = oldAreaC;
						}
					}
				}

				if (isPlaced) {
					PlaceCircle(changeC);

					lastChangeIter = iter;
				}
				else {
					currentC[changeC].cx = kUnused;
				}
			}
			else {
				int changeR = randEngine() % R;
				int maxTries = 100;
				if (currentNumC == C) {
					changeR = orderR[R / 2 + changeR / 2];
				}
				// Try to place a rectangle.
				if (currentR[changeR].x0 != kUnused) continue;

				// Try 500 different positions.
				bool isPlaced = false;
				for (int subIter = 0; subIter < maxTries; ++subIter) {
					currentR[changeR].x0 = (randEngine() % (2 * kBaseRadius)) - kBaseRadius;
					currentR[changeR].y0 = (randEngine() % (2 * kBaseRadius)) - kBaseRadius;
					currentR[changeR].x1 = currentR[changeR].x0 + inputR[changeR].w;
					currentR[changeR].y1 = currentR[changeR].y0 + inputR[changeR].h;
					if (!FitsPizza(currentR[changeR])) continue;

					// Fetch precalculated 64-bit tile mask for faster overlaps.
					currentR[changeR].areaMask = maskRectangle[currentR[changeR].x0 + 100][currentR[changeR].y0 + 100][currentR[changeR].w][currentR[changeR].h];

					// Check overlap with existing circles.
					bool noOverlap = true;
					for (int ci = 0; ci < currentNumC; ++ci) {
						const int c = currentIndexC[ci];
						if (Overlap(currentR[changeR], currentC[c])) {
							noOverlap = false;
							break;
						}
					}

					// Check overlap with existing rectangles.
					if (noOverlap) {
						for (int ri = 0; ri < currentNumR; ++ri) {
							const int r = currentIndexR[ri];
							if (Overlap(currentR[r], currentR[changeR])) {
								noOverlap = false;
								break;
							}
						}
					}

					if (noOverlap) {
						isPlaced = true;
						break;
					}
				}

				if (isPlaced) {
					PlaceRectangle(changeR);
					lastChangeIter = iter;
				}
				else {
					currentR[changeR].x0 = kUnused;
				}
			}

		}

		// Update best possible solution if the current one is better.
		MaybeUpdateBest();

		// This round is over, check system time every 10ms and update progress.
		currentRound++;
		if (currentRound % roundsPerTimeCheck == 0) {
			FetchTime(&tCurrent);
			const double elapsedMicros = GetElapsedMicros(tBegin, tCurrent);
			if (elapsedMicros > kMaxRuntimeMicros)
				break;
		}
	}

	FetchTime(&tCurrent);
	DEBUG("DATA_HEADER,Seed,C,R,X,AreaC,AreaR,AreaSum,AreaBase,Score,Runtime,Rounds\n");
	DEBUG("DATA_EXPORT,%d,%d,%d,%.6lf,%.6lf,%.6lf,%.6lf,%.6lf,%.6lf,%.2lf,%d\n", dbgSeed, C, R, X, bestAreaC, bestAreaR, bestAreaC + bestAreaR, 31415.92654, bestScore,
		GetElapsedMicros(tBegin, tCurrent), currentRound);
	fflush(fDebug);

	vector<string> retVal(C + R);
	for (int c = 0; c < C; ++c) {
		if (bestC[c].cx == kUnused) {
			retVal[c] = "NA";
		}
		else {
			sprintf(sTmp, "%d %d", bestC[c].cx, bestC[c].cy);
			retVal[c] = sTmp;
		}
	}
	for (int r = 0; r < R; ++r) {
		if (bestR[r].x0 == kUnused) {
			retVal[C + r] = "NA";
		}
		else {
			sprintf(sTmp, "%d %d", bestR[r].x0, bestR[r].y0);
			retVal[C + r] = sTmp;
		}
	}

	return retVal;
}




// Tester wrapper.
int main(int argc, char* argv[]) {
	dbgHasExtraInput = false;

#ifdef TC_DEBUG
	for (int i = 1; i < argc; ++i) {
		if (!strncmp(argv[i], "-s=", 3)) {
			dbgSeed = atoi(argv[i] + 3);
		}
		else if (!strncmp(argv[i], "-o=", 3)) {
			fDebug = fopen(argv[i] + 3, "at");
		}
		else if (!strncmp(argv[i], "-d", 2)) {
			dbgHasExtraInput = true;
		}
	}
	fprintf(fDebug, "=========== SEED: %d ===========\n", dbgSeed);
#endif

	int genC, genR;
	double genX;
	cin >> genC;
	cin >> genR;
	cin >> genX;

	vector<int> genCircles(genC);
	for (int i = 0; i < genC; ++i) {
		cin >> genCircles[i];
	}

	vector<pair<int, int>> genRects(genR);
	for (int i = 0; i < genR; ++i) {
		cin >> genRects[i].first;
		cin >> genRects[i].second;
	}

	TastyPizza solver;
	auto retVal = solver.findSolution(genC, genR, genX, genCircles, genRects);

	if (fDebug != stderr) {
		fflush(fDebug);
		fclose(fDebug);
	}

	cout << retVal.size() << endl;
	for (auto x : retVal) {
		cout << x << endl;
	}
	cout.flush();
	cerr.flush();

	return 0;
}
