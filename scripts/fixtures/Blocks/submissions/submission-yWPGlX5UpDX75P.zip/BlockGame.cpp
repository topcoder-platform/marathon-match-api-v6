#include <cassert>
#include <cmath>
#include <algorithm>
#include <iostream>
#include <iomanip>
#include <climits>
#include <map>
#include <queue>
#include <set>
#include <cstring>
#include <vector>

using namespace std;
typedef long long ll;

const ll CYCLE_PER_SEC = 2700000000;
double TIME_LIMIT = 0.01;

unsigned long long int get_cycle() {
  unsigned int low, high;
  __asm__ volatile ("rdtsc" : "=a" (low), "=d" (high));
  return ((unsigned long long int) low) | ((unsigned long long int) high << 32);
}

double get_time(unsigned long long int begin_cycle) {
  return (double) (get_cycle() - begin_cycle) / CYCLE_PER_SEC;
}

unsigned long long xor128() {
  static unsigned long long rx = 123456789, ry = 362436069, rz = 521288629, rw = 88675123;
  unsigned long long rt = (rx ^ (rx << 11));
  rx = ry;
  ry = rz;
  rz = rw;
  return (rw = (rw ^ (rw >> 19)) ^ (rt ^ (rt >> 8)));
}

const int WALL = -1;
const int EMPTY = 0;
const int MAX_N = 20;
const int MAX_T = 5;
const int MAX_C = 5;
const int MAX_TURN = 1000;
const int S = 3;
const int GRID_SIZE = MAX_N + 4;

int N, T, C;
double F, P;
char g_grid[GRID_SIZE * GRID_SIZE];
char g_tiles[MAX_T][S][S];
char g_storage[S][S];
ll g_cleaned_H[GRID_SIZE];
ll g_cleaned_W[GRID_SIZE];
ll g_clean_id;
ll g_updated_at_H[GRID_SIZE];
ll g_updated_at_W[GRID_SIZE];
ll g_updated_at;
ll g_visited[GRID_SIZE * GRID_SIZE];
ll g_vid;

int calc_z(int y, int x) {
  return y * GRID_SIZE + x;
}

struct Command {
  int tid;
  int z;

  Command(int tid = -1, int z = -1) {
    this->tid = tid;
    this->z = z;
  }

  string to_str() {
    int y = z / GRID_SIZE;
    int x = z % GRID_SIZE;

    if (tid == -1) {
      return "-1";
    } else if (z == -1) {
      return to_string(tid);
    } else {
      return to_string(tid) + " " + to_string(y - 2) + " " + to_string(x - 2);
    }
  }
};

struct NodePointer {
  int parent;
  int tid;
  int z;
  double value;

  NodePointer(int parent, int tid, int z, double value) {
    this->parent = parent;
    this->tid = tid;
    this->z = z;
    this->value = value;
  }

  bool operator>(const NodePointer &np) const {
    return value < np.value;
  }
};

struct Node {
  int value;
  bool used[MAX_T];
  Command first_cmd;
  char grid[GRID_SIZE * GRID_SIZE];

  Node(int value = -1) {
    this->value = value;
    memset(used, false, sizeof(used));
  }

  Node copy() {
    Node copy_node;
    copy_node.value = value;
    copy_node.first_cmd = first_cmd;
    memcpy(copy_node.grid, grid, sizeof(grid));
    memcpy(copy_node.used, used, sizeof(used));

    return copy_node;
  }

  bool operator>(const Node &n) const {
    return value < n.value;
  }
};

const int MAX_NODE_NUM = 100000;
Node g_nodes[2][MAX_NODE_NUM];

class TCO22 {
public:
  void load_data() {
    g_clean_id = 0;
    memset(g_cleaned_H, -1, sizeof(g_cleaned_H));
    memset(g_cleaned_W, -1, sizeof(g_cleaned_W));
    g_updated_at = 0;
    memset(g_updated_at_H, -1, sizeof(g_updated_at_H));
    memset(g_updated_at_W, -1, sizeof(g_updated_at_W));
    g_vid = 0;
    memset(g_visited, -1, sizeof(g_visited));

    cin >> N >> T >> C >> F >> P;
    fprintf(stderr, "N = %d\n", N);
    fprintf(stderr, "C = %d\n", C);
    fprintf(stderr, "T = %d\n", T);

    memset(g_grid, WALL, sizeof(g_grid));
    for (int y = 2; y <= N + 1; y++) {
      for (int x = 2; x <= N + 1; x++) {
        int z = calc_z(y, x);
        char ch;
        cin >> ch;
        g_grid[z] = ch - '0';
        assert(g_grid[z] >= 0);
      }
    }

    read_tiles();
  }

  void read_tiles() {
    for (int i = 0; i < T; i++) {
      read_tile(i);
    }
  }

  void read_tile(int tid) {
    string line;
    cin >> line;
    // cerr << line << endl;
    for (int y = 0; y < S; y++) {
      for (int x = 0; x < S; x++) {
        g_tiles[tid][y][x] = line[y * S + x] - '0';
        // fprintf(stderr, "y: %d, x: %d, ft: %d\n", y, x, g_tiles[tid][y][x]);
        assert(0 <= g_tiles[tid][y][x]);
      }
    }
  }

  void run() {
    load_data();
    int elapsed_time = 0;
    int drop_cnt = 0;

    for (int turn = 0; turn < MAX_TURN; ++turn) {
      // fprintf(stderr, "turn: %d\n", i);
      Command cmd = search_best_command(turn, elapsed_time);
      cout << cmd.to_str() << endl;

      if (cmd.tid == -1) {
        break;
      } else if (cmd.z == -1) {
        ++drop_cnt;
        // NOOP
      } else {
        int y = cmd.z / GRID_SIZE;
        int x = cmd.z % GRID_SIZE;
        /*
        show_grid(g_grid);
        fprintf(stderr, "use_tile: %d\n", cmd.tid);
        for (int dy = 0; dy < S; ++dy) {
          for (int dx = 0; dx < S; ++dx) {
            fprintf(stderr, "%d ", g_tiles[cmd.tid][dy][dx]);
          }
          fprintf(stderr, "\n");
        }
         */
        put_tile(cmd.z, cmd.tid, g_grid);

        ++g_clean_id;
        calc_row_score(y, g_grid);
        calc_row_score(y + 1, g_grid);
        calc_row_score(y + 2, g_grid);
        calc_col_score(x, g_grid);
        calc_col_score(x + 1, g_grid);
        calc_col_score(x + 2, g_grid);

        clean_row(y, g_grid);
        clean_row(y + 1, g_grid);
        clean_row(y + 2, g_grid);
        clean_col(x, g_grid);
        clean_col(x + 1, g_grid);
        clean_col(x + 2, g_grid);
      }

      // show_grid(g_grid);
      read_tile(cmd.tid);

      cin >> elapsed_time;

      if (elapsed_time >= 9800) {
        cout << -1 << endl;
        break;
      }
    }

    fprintf(stderr, "DROP_CNT = %d\n", drop_cnt);
    cout.flush();
  }

  Node build_root_node() {
    Node node(0);
    memcpy(node.grid, g_grid, sizeof(g_grid));

    return node;
  }

  Command search_best_command(int turn, int elapsed_time) {
    int depth_limit = min(MAX_TURN - turn, min(3, T));

    Command best_command;
    Node root = build_root_node();
    g_nodes[0][0] = root;

    int beam_width = 50;
    if (elapsed_time >= 8000) beam_width = 10;
    queue<int> que;
    que.push(0);
    const double R = 0.09;

    for (int depth = 0; depth < depth_limit; ++depth) {
      priority_queue <NodePointer, vector<NodePointer>, greater<NodePointer>> pque;

      while (not que.empty()) {
        int node_id = que.front();
        que.pop();
        Node &node = g_nodes[depth % 2][node_id];

        for (int tid = 0; tid < T; ++tid) {
          if (node.used[tid]) continue;

          int min_y = S;
          int max_y = 0;
          int min_x = S;
          int max_x = 0;
          int tile_num = 0;
          for (int dy = 0; dy < S; ++dy) {
            for (int dx = 0; dx < S; ++dx) {
              if (g_tiles[tid][dy][dx] != EMPTY) {
                min_y = min(min_y, dy);
                max_y = max(max_y, dy);
                min_x = min(min_x, dx);
                max_x = max(max_x, dx);
                ++tile_num;
              }
            }
          }

          // drop pattern
          NodePointer np(node_id, tid, -1, node.value);
          pque.push(np);
          int empty_cnt = 0;

          for (int y = 2; y <= N + 1; ++y) {
            for (int x = 2; x <= N + 1; ++x) {
              int z = calc_z(y, x);
              if (node.grid[z] == EMPTY) ++empty_cnt;
            }
          }

          double empty_rate = empty_cnt * 1.0 / (N * N);

          for (int y = 0; y <= N + 1; ++y) {
            for (int x = 0; x <= N + 1; ++x) {
              int z = calc_z(y, x);
              // node.show_grid();

              /*
              for (int cy = 2; cy <= N + 1; ++cy) {
                for (int cx = 2; cx <= N + 1; ++cx) {
                  int cz = calc_z(cy, cx);
                  assert(g_grid[cz] == node.grid[cz]);
                }
              }
               */

              bool res = put_tile(z, tid, node.grid);

              ++g_clean_id;
              double value = 0;
              if (res) {
                value += calc_row_score(y, node.grid);
                value += calc_row_score(y + 1, node.grid);
                value += calc_row_score(y + 2, node.grid);
                value += calc_col_score(x, node.grid);
                value += calc_col_score(x + 1, node.grid);
                value += calc_col_score(x + 2, node.grid);

                int chain_cnt = 0;
                if (g_cleaned_H[y] == g_clean_id) ++chain_cnt;
                if (g_cleaned_H[y + 1] == g_clean_id) ++chain_cnt;
                if (g_cleaned_H[y + 2] == g_clean_id) ++chain_cnt;
                if (g_cleaned_W[x] == g_clean_id) ++chain_cnt;
                if (g_cleaned_W[x + 1] == g_clean_id) ++chain_cnt;
                if (g_cleaned_W[x + 2] == g_clean_id) ++chain_cnt;

                if (chain_cnt == 1 && (C <= 2 || empty_rate > 0.1) && depth == 0 && turn < MAX_TURN - 2) {
                  value *= 0.01;
                }
                NodePointer np(node_id, tid, z, pow(R, depth) * node.value + value);
                if (T == 1) {
                  np.value += N * N * N - N * lake_count(node.grid);
                }

                np.value -= 0.125 * tile_num;
                // np.value -= (max_y - min_y + 1) * (max_x - min_x + 1);
                np.value = max(node.value + (xor128() % 10000) / 10000.0, np.value);
                pque.push(np);
              } else {
                // fprintf(stderr, "y: %d, x: %d, failed\n", y, x);
              }

              restore_tile(z, node.grid);
            }
          }
        }
      }

      for (int i = 0; i < beam_width && not pque.empty(); ++i) {
        NodePointer np = pque.top();
        int y = np.z / GRID_SIZE;
        int x = np.z % GRID_SIZE;
        pque.pop();

        Node &node = g_nodes[depth % 2][np.parent];
        Node next = node.copy();
        next.used[np.tid] = true;
        if (depth == 0) {
          next.first_cmd = Command(np.tid, np.z);
        }

        if (i == 0) {
          best_command = next.first_cmd;
        }

        if (np.z != -1) {
          ++g_clean_id;
          bool res = put_tile(np.z, np.tid, next.grid);
          assert(res);
          next.value *= R;
          next.value += calc_row_score(y, next.grid);
          next.value += calc_row_score(y + 1, next.grid);
          next.value += calc_row_score(y + 2, next.grid);
          next.value += calc_col_score(x, next.grid);
          next.value += calc_col_score(x + 1, next.grid);
          next.value += calc_col_score(x + 2, next.grid);

          clean_row(y, next.grid);
          clean_row(y + 1, next.grid);
          clean_row(y + 2, next.grid);
          clean_col(x, next.grid);
          clean_col(x + 1, next.grid);
          clean_col(x + 2, next.grid);
        }

        g_nodes[(depth + 1) % 2][i] = next;
        que.push(i);
      }
    }

    return best_command;
  }

  void clean_row(int y, char *grid) {
    if (g_cleaned_H[y] != g_clean_id) return;

    for (int x = 2; x <= N + 1; ++x) {
      int z = calc_z(y, x);
      // assert(grid[z] != EMPTY);
      grid[z] = EMPTY;
    }
  }

  void clean_col(int x, char *grid) {
    if (g_cleaned_W[x] != g_clean_id) return;

    for (int y = 2; y <= N + 1; ++y) {
      int z = calc_z(y, x);
      // assert(grid[z] != EMPTY);
      grid[z] = EMPTY;
    }
  }

  double calc_row_score(int y, char *grid) {
    double score = 0;
    if (y < 2 || N + 1 < y) return score;
    if (g_updated_at_H[y] != g_updated_at) return score;

    int fruit_counter[MAX_C + 1];
    memset(fruit_counter, 0, sizeof(fruit_counter));
    int block_cnt = 0;
    int max_cnt = 0;
    int max_chain = 0;
    int chain_cnt = 0;
    int seg_cnt = 0;

    for (int x = 2; x <= N + 1; ++x) {
      int z = calc_z(y, x);
      int fruit_type = grid[z];
      // fprintf(stderr, "y: %d, x: %d, type: %d\n", y, x, fruit_type);
      assert(0 <= fruit_type && fruit_type <= MAX_C);

      if (fruit_type != EMPTY) {
        fruit_counter[fruit_type]++;
        max_cnt = max(max_cnt, fruit_counter[fruit_type]);
        ++block_cnt;
        ++chain_cnt;
        max_chain = max(max_chain, chain_cnt);
      } else {
        if (chain_cnt > 0) ++seg_cnt;
        chain_cnt = 0;
      }
    }

    if (block_cnt == N) {
      g_cleaned_H[y] = g_clean_id;
      return 2 * max_cnt * max_cnt;
    } else if (block_cnt == N - 1 || seg_cnt == 1) {
      return max_cnt * max_cnt;
    } else {
      if (T == 1) {
        return max_cnt * max_cnt * (max_cnt * 1.0 / block_cnt) + block_cnt - seg_cnt;
      } else {
        return max_cnt * max_cnt * (max_cnt * 1.0 / block_cnt) + chain_cnt - seg_cnt;
      }
    }
  }

  int lake_count(char *grid) {
    int cnt = 0;
    ++g_vid;

    for (int y = 2; y <= N + 1; ++y) {
      for (int x = 2; x <= N + 1; ++x) {
        int z = calc_z(y, x);
        if (grid[z] != EMPTY) continue;
        if (g_visited[z] == g_vid) continue;

        ++cnt;
        walk(z, grid);
      }
    }

    return cnt;
  }

  void walk(int z, char *grid) {
    const int DZ[4] = {-GRID_SIZE, 1, GRID_SIZE, -1};
    g_visited[z] = g_vid;

    for (int dir = 0; dir < 4; ++dir) {
      int nz = z + DZ[dir];
      if (grid[nz] == WALL) continue;
      if (grid[nz] != EMPTY) continue;
      if (g_visited[nz] == g_vid) continue;

      walk(nz, grid);
    }
  }

  double calc_col_score(int x, char *grid) {
    int score = 0;
    if (x < 2 || N + 1 < x) return score;
    if (g_updated_at_W[x] != g_updated_at) return score;

    int fruit_counter[MAX_C + 1];
    memset(fruit_counter, 0, sizeof(fruit_counter));
    int block_cnt = 0;
    int max_cnt = 0;
    int max_chain = 0;
    int chain_cnt = 0;
    int seg_cnt = 0;

    for (int y = 2; y <= N + 1; ++y) {
      int z = calc_z(y, x);
      int fruit_type = grid[z];
      // fprintf(stderr, "y: %d, x: %d, type: %d\n", y, x, fruit_type);
      assert(0 <= fruit_type && fruit_type <= MAX_C);

      if (fruit_type != EMPTY) {
        fruit_counter[fruit_type]++;
        max_cnt = max(max_cnt, fruit_counter[fruit_type]);
        ++block_cnt;
        ++chain_cnt;
        max_chain = max(max_chain, chain_cnt);
      } else {
        if (chain_cnt > 0) ++seg_cnt;
        chain_cnt = 0;
      }
    }

    if (block_cnt == N) {
      g_cleaned_W[x] = g_clean_id;
      return 2 * max_cnt * max_cnt;
    } else if (block_cnt == N - 1 || seg_cnt == 1) {
      return max_cnt * max_cnt;
    } else {
      if (T == 1) {
        return max_cnt * max_cnt * (max_cnt * 1.0 / block_cnt) + block_cnt - seg_cnt;
      } else {
        return max_cnt * max_cnt * (max_cnt * 1.0 / block_cnt) + chain_cnt - seg_cnt;
      }
    }
  }

  bool put_tile(int z, int tid, char *grid) {
    int y = z / GRID_SIZE;
    int x = z % GRID_SIZE;
    bool ok = true;
    ++g_updated_at;

    for (int dy = 0; dy < S; ++dy) {
      for (int dx = 0; dx < S; ++dx) {
        int ny = y + dy;
        int nx = x + dx;
        int nz = calc_z(ny, nx);
        g_storage[dy][dx] = grid[nz];
        int fruit_type = g_tiles[tid][dy][dx];
        if (fruit_type == EMPTY) continue;
        if (fruit_type < 0) {
          cerr << fruit_type << endl;
        }
        assert(fruit_type >= 0);

        if (grid[nz] != EMPTY && fruit_type > 0) {
          ok = false;
        }
        g_updated_at_H[ny] = g_updated_at;
        g_updated_at_W[nx] = g_updated_at;
        grid[nz] = fruit_type;
      }
    }

    return ok;
  }

  void restore_tile(int z, char *grid) {
    int y = z / GRID_SIZE;
    int x = z % GRID_SIZE;

    for (int dy = 0; dy < S; ++dy) {
      for (int dx = 0; dx < S; ++dx) {
        int ny = y + dy;
        int nx = x + dx;
        int nz = calc_z(ny, nx);

        grid[nz] = g_storage[dy][dx];
      }
    }
  }

  void show_grid(char *grid) {
    for (int y = 2; y <= N + 1; ++y) {
      for (int x = 2; x <= N + 1; ++x) {
        int z = calc_z(y, x);
        fprintf(stderr, "%d ", grid[z]);
      }
      fprintf(stderr, "\n");
    }
  }
};

int main() {
  TCO22 tco22;
  tco22.run();
}