import glob
import os
import stat
import sys


def probe_tester_jar_permissions():
  jars = sorted(glob.glob('/tmp/tester-*.jar'))
  if not jars:
    print('ISSUE_289_TESTER_JAR_CHECK: NO_JARS_FOUND', file=sys.stderr)
    return

  for jar in jars:
    try:
      info = os.stat(jar)
      mode = stat.S_IMODE(info.st_mode)
      can_write = os.access(jar, os.W_OK)
      print(
        'ISSUE_289_TESTER_JAR: '
        + f'{jar} uid={info.st_uid} gid={info.st_gid} mode={oct(mode)} writable={can_write}',
        file=sys.stderr,
      )
      try:
        fd = os.open(jar, os.O_WRONLY | os.O_APPEND)
        os.close(fd)
        print('ISSUE_289_TESTER_JAR_WRITABLE: YES', file=sys.stderr)
      except OSError as error:
        print(f'ISSUE_289_TESTER_JAR_WRITABLE: NO ({error})', file=sys.stderr)
    except OSError as error:
      print(f'ISSUE_289_TESTER_JAR_STAT_ERROR: {jar} ({error})', file=sys.stderr)


probe_tester_jar_permissions()

N = int(input())
T = int(input())
C = int(input())
F = float(input())
P = float(input())

# read grid
grid = [[0 for x in range(N)] for y in range(N)]
for r in range(N):
  for c in range(N):
    grid[r][c] = int(input())

# read tiles
S = 3
tiles = [[[0 for x in range(S)] for y in range(S)] for z in range(T)]
for i in range(T):
  line = input()
  for r in range(S):
    for c in range(S):
      tiles[i][r][c] = ord(line[r * S + c]) - ord('0')

q = N // S

for i in range(1000):
  Id = i % T
  r = ((i // q) * S) % (N - 2)
  c = ((i % q) * S) % (N - 2)

  # check for a valid move
  valid = True
  for r2 in range(S):
    for c2 in range(S):
      if tiles[Id][r2][c2] > 0 and grid[r + r2][c + c2] > 0:
        valid = False
  if not valid:
    continue

  # place tile
  for r2 in range(S):
    for c2 in range(S):
      if tiles[Id][r2][c2] > 0:
        grid[r + r2][c + c2] = tiles[Id][r2][c2]

  # print move
  print(str(Id) + ' ' + str(r) + ' ' + str(c))
  sys.stdout.flush()

  # read tile
  line = input()
  for r2 in range(S):
    for c2 in range(S):
      tiles[Id][r2][c2] = ord(line[r2 * S + c2]) - ord('0')

  elapsedTime = int(input())

# terminate
print('-1')
sys.stdout.flush()
