﻿
#define CODETEST 0
#define OPTUNE 0
#define PERFORMANCE 0
#define EVAL 0
#define UNIT_TEST 0

#define TIME_LIMIT (9500)

#define BENCH 0

#define NOT_SUBMIT 0
#define VALIDATION 0

#define IO_FILE 0

#define OUTPUT_INFO 0
#define OUTPUT_FINAL_INFO 1
#define OUTPUT_LOG 0
#define OUTPUT_VISUAL 0

#define FIX_RESULT 0


#define TIME_LIMIT_US (TIME_LIMIT * 1000)

#ifdef __clang_version__
#pragma clang diagnostic ignored "-Wunknown-pragmas"
#pragma clang diagnostic ignored "-Wunknown-warning-option"
#pragma clang diagnostic ignored "-Wmissing-braces"
#endif

#ifndef _MSC_VER 

#pragma GCC target("sse,sse2,sse3,ssse3,sse4,popcnt,abm,mmx,avx,tune=native")

#pragma GCC optimize ("O3,inline,omit-frame-pointer,unroll-loops")



#endif

#define _USE_MATH_DEFINES
#include <bits/stdc++.h>
using namespace std;


#define FOR(i, s, e) for (int i = int(s); i < int(e); ++i)
#define RFOR(i, s, e) for (int i = int(e) - 1; i >= int(s); --i)
#define REP(i, n) for (int i = 0, i##_size = int(n); i < i##_size; ++i)
#define RREP(i, n) for (int i = int(n) - 1; i >= 0; --i)


#define ALL(x) (x).begin(),(x).end()

template <class T, class U> inline void chmin(T& a, U b) { if (b < a) { a = b; } }
template <class T, class U> inline void chmax(T& a, U b) { if (a < b) { a = b; } }
template <class T> inline constexpr T square(T v) { return v * v; }

#define cauto const auto

#include <cstdint>

using u8 = uint8_t;
using u16 = uint16_t;
using u32 = uint32_t;
using u64 = uint64_t;
using s8 = int8_t;
using s16 = int16_t;
using s32 = int32_t;
using s64 = int64_t;



struct MemoryException {};


#define VALIDATE_ABORT()
#define VALIDATE_ASSERT(exp)


#define VABORT() VALIDATE_ABORT()
#define VASSERT(exp) VALIDATE_ASSERT(exp)




using TimePoint = chrono::high_resolution_clock::time_point;

struct ChronoTimer {
private:
	TimePoint startTime_;
	TimePoint endTime_;

public:
	inline void Init() {
		startTime_ = chrono::high_resolution_clock::now();
		endTime_ = startTime_;
	}

	inline void Start(int limit) {
		endTime_ = startTime_ + chrono::milliseconds(limit);
	}
	inline void StartMs(int limit) {
		endTime_ = startTime_ + chrono::milliseconds(limit);
	}
	inline void StartUs(int limit) {
		endTime_ = startTime_ + chrono::microseconds(limit);
	}

	inline void Join() {
	}

	inline bool IsOver() const {
		return chrono::high_resolution_clock::now() >= endTime_;
	}

	inline int ElapseTimeMs() const {
		return (int)chrono::duration_cast<chrono::milliseconds>(chrono::high_resolution_clock::now() - startTime_).count();
	}
	inline int ElapseTimeUs() const {
		return (int)chrono::duration_cast<chrono::microseconds>(chrono::high_resolution_clock::now() - startTime_).count();
	}

	void SetElapseTimeMs(int ms) {
		auto now = chrono::high_resolution_clock::now();
		auto limit = endTime_ - startTime_;
		startTime_ = now - chrono::milliseconds(ms);
		endTime_ = startTime_ + limit;
	}

	inline int LeftToUS(const TimePoint& limit) const {
		return (int)chrono::duration_cast<chrono::microseconds>(limit - chrono::high_resolution_clock::now()).count();
	}

	inline double NowRate() const {
		return (chrono::high_resolution_clock::now() - startTime_).count() / (double)(endTime_ - startTime_).count();
	}

	inline TimePoint Now() const {
		return chrono::high_resolution_clock::now();
	}
	inline TimePoint StartTime() const {
		return startTime_;
	}
	inline TimePoint EndTime() const {
		return endTime_;
	}

	TimePoint GetLimitTimePointUs(int limit) const {
		return startTime_ + chrono::microseconds(limit);
	}
};

TimePoint Now() {
	return chrono::high_resolution_clock::now();
}

using Timer = ChronoTimer;
Timer timer;

template <class T>
void InstanceRun(int argc, const char* argv[]) {
	timer.Init();
	T* m = new T;
	m->Run(argc, argv);
	quick_exit(0);
}

struct Main;
signed main(int argc, const char* argv[]) {
	cin.tie(0);
	ios::sync_with_stdio(0);
	cout << fixed << setprecision(numeric_limits<double>::digits10);
	cerr << fixed << setprecision(numeric_limits<double>::digits10);
	InstanceRun<Main>(argc, argv);
}




template <class A, class B>
struct pr {
	union {
		A a;
		A key;
		A first;
		A x;
	};
	union {
		B b;
		B value;
		B second;
		B y;
	};

	bool operator == (pr const& r) const { return a == r.a && b == r.b; }
	bool operator != (pr const& r) const { return !((*this) == r); }
	bool operator < (pr const& r) const {
		if (a == r.a) {
			return b < r.b;
		}
		return a < r.a;
	}
	bool operator > (pr const& r) const {
		return r < (*this);
	}


	pr& operator += (pr const& v) {
		a += v.a;
		b += v.b;
		return *this;
	}
	pr& operator -= (pr const& v) {
		a -= v.a;
		b -= v.b;
		return *this;
	}

	template <class C, class D>
	auto operator + (pr<C, D> const& v) const {
		return pr<decltype(a + v.a), decltype(b + v.b)>{ a + v.a, b + v.b };
	}

	template <class C, class D>
	auto operator - (pr<C, D> const& v) const {
		return pr<decltype(a - v.a), decltype(b - v.b)>{ a - v.a, b - v.b };
	}

	template <class C, class D>
	explicit operator pr<C, D>() const {
		return { C(a), D(b) };
	}

	template <class T>
	auto operator * (T const& v) const -> pr<decltype(x * v), decltype(y * v)> {
		return { x * v, y * v };
	}
	template <class T>
	auto operator / (T const& v) const -> pr<decltype(x / v), decltype(y / v)> {
		return { x / v, y / v };
	}

	template <class T>
	pr& operator *= (T const& v) {
		x *= v;
		y *= v;
		return *this;
	}
	template <class T>
	pr& operator /= (T const& v) {
		x /= v;
		y /= v;
		return *this;
	}

	pr operator -() const {
		return pr{ -x, -y };
	}

	void flip() { swap(x, y); }

	friend istream& operator>>(istream& is, pr& p) {
		is >> p.a >> p.b;
		return is;
	}
	friend ostream& operator<<(ostream& os, pr const& p) {
		os << p.a << " " << p.b;
		return os;
	}

	template <size_t I>
	auto get() const {
		if constexpr (I == 0) {
			return x;
		}
		else if constexpr (I == 1) {
			return y;
		}
	}
};
using pint = pr<int, int>;
using pdouble = pr<double, double>;

static_assert(is_trivially_copyable<pint>::value, "not trivially_copyable");

template <class A, class B>
struct tuple_size<pr<A, B>> : integral_constant<size_t, 2> {};

template <class A, class B>
struct tuple_element<0, pr<A, B>> { using type = A; };
template <class A, class B>
struct tuple_element<1, pr<A, B>> { using type = B; };

inline pdouble ToDouble(const pint& p) {
	return pdouble{ double(p.x), double(p.y) };
}
inline pint round(const pdouble& d) {
	return pint{ (int)round(d.x), (int)round(d.y) };
}
inline double norm(const pdouble& d) {
	return sqrt((d.x * d.x) + (d.y * d.y));
}
inline pdouble normalized(const pdouble& d) {
	return d / norm(d);
}
inline double dot(const pdouble& a, const pdouble& b) {
	return a.x * b.x + a.y * b.y;
}
inline double cross(const pdouble& a, const pdouble& b) {
	return a.x * b.y - a.y * b.x;
}

template <class T, int CAPACITY>
class CapacityArray {
	static_assert(is_trivially_copyable<T>::value);

private:
	array<T, CAPACITY> array_ = {};
	int count_ = 0;

public:
	CapacityArray() {
	}

	explicit CapacityArray(int count) {
		resize(count);
	}

	bool operator == (const CapacityArray<T, CAPACITY>& r) const {
		return memcmp(array_.data(), r.array_.data(), sizeof(T) * count_) == 0;
	}

	void CopyFrom(const CapacityArray<T, CAPACITY>& r) {
		memcpy(array_.data(), r.array_.data(), sizeof(T) * r.count_);
		count_ = r.count_;
	}

	constexpr int capacity() const {
		return CAPACITY;
	}

	inline void clear() {
		count_ = 0;
	}
	inline void Clear() {
		clear();
	}

	inline void resize(int count) {
		count_ = count;
	}
	inline void Resize(int count) {
		resize(count);
	}

	inline void assign(int count, const T& e) {
		count_ = count;
		for (int i = 0; i < count; ++i) {
			array_[i] = e;
		}
	}

	const T* data() const {
		return array_.data();
	}
	T* data() {
		return array_.data();
	}

	inline T* PushBack() {
		return &array_[count_++];
	}

	inline void push_back(const T& e) {
		array_[count_++] = e;
	}
	inline void PushBack(const T& e) {
		push_back(e);
	}

	inline void pop_back() {
		--count_;
	}
	inline void PopBack() {
		pop_back();
	}

	T& front() {
		return array_[0];
	}
	const T& front() const {
		return array_[0];
	}

	T& back() {
		return array_[count_ - 1];
	}
	const T& back() const {
		return array_[count_ - 1];
	}

	inline void RemoveSwap(int i) {
		array_[i] = array_[count_ - 1];
		--count_;
	}

	inline int GetCount() const {
		return count_;
	}
	inline int size() const {
		return count_;
	}
	inline int sz() const {
		return count_;
	}

	inline bool empty() const {
		return count_ == 0;
	}

	inline T& operator[](int index) {
		return array_[index];
	}

	inline const T& operator[](int index) const {
		return array_[index];
	}

	inline auto begin() -> decltype(array_.begin()) {
		return array_.begin();
	}

	inline auto end() -> decltype(array_.begin()) {

		return array_.begin() + count_;
	}

	inline auto begin() const -> decltype(array_.begin()) {
		return array_.begin();
	}

	inline auto end() const -> decltype(array_.begin()) {

		return array_.begin() + count_;
	}

	inline int Find(const T& value) const {
		REP(i, count_) {
			if (array_[i] == value) {
				return i;
			}
		}
		return -1;
	}
	inline bool IsContain(const T& value) const {
		for (const auto& v : *this) {
			if (v == value) {
				return true;
			}
		}
		return false;
	}

	inline void MemInsert(int index, const T* mem, int count) {
		if (index == count_) {
			memcpy(array_.data() + index, mem, sizeof(T) * count);
			count_ += count;
		}
		else {
			memmove(array_.data() + index + count, array_.data() + index, sizeof(T) * (count_ - index));
			memcpy(array_.data() + index, mem, sizeof(T) * count);
			count_ += count;
		}
	}

	void insert(int index, const T& value) {
		MemInsert(index, &value, 1);
	}

	inline void Insert(int start, int end, const T* p, int size) {
		int newEnd = start + size;
		if (count_ - end > 0 && newEnd != end) {
			memmove(array_.data() + newEnd, array_.data() + end, sizeof(T) * (count_ - end));
		}

		memcpy(array_.data() + start, p, sizeof(T) * size);

		count_ -= end - start;
		count_ += size;
	}

	inline void Remove(int start, int end) {
		int size = end - start;
		memmove(array_.data() + start, array_.data() + end, sizeof(T) * (count_ - end));
		count_ -= size;
	}


};

template <class T, int CAPACITY>
using CapArr = CapacityArray<T, CAPACITY>;




template <int S>
struct CheckMapS {
private:
    array<u32, S> checked_ = {};
    u32 mark_ = 1;

public:
    void Clear() {
        ++mark_;

        if (mark_ == 0) {
            checked_ = {};
            ++mark_;
        }
    }
    bool IsChecked(int i) const {
        return checked_[i] == mark_;
    }
    void Check(int i) {
        checked_[i] = mark_;
    }
    void Reset(int i) {
        checked_[i] = mark_ - 1;
    }
    bool operator[](int i) const {
        return checked_[i] == mark_;
    }

    bool operator == (const CheckMapS<S>& r) const {
        REP(i, S) {
            if (this->IsChecked(i) != r.IsChecked(i)) {
                return false;
            }
        }
        return true;
    }
};

template <class T, int S>
struct CheckMapDataS {
private:
    array<T, S> data_;
    array<u32, S> checked_ = {};
    u32 mark_ = 1;

public:
    void Clear() {
        ++mark_;

        if (mark_ == 0) {
            checked_ = {};
            ++mark_;
        }
    }

    bool IsChecked(int i) const {
        return checked_[i] == mark_;
    }
    void Check(int i) {
        checked_[i] = mark_;
    }

    void Set(int i, const T& value) {
        checked_[i] = mark_;
        data_[i] = value;
    }

    void Reset(int i) {
        checked_[i] = mark_ - 1;
    }
    const T& Get(int i) const {
        VASSERT(checked_[i] == mark_);
        return data_[i];
    }
    T& Ref(int i) {
        VASSERT(checked_[i] == mark_);
        return data_[i];
    }
    const T& Ref(int i) const {
        VASSERT(checked_[i] == mark_);
        return data_[i];
    }
    T& operator[](int i) {
        VASSERT(checked_[i] == mark_);
        return data_[i];
    }
    const T& operator[](int i) const {
        VASSERT(checked_[i] == mark_);
        return data_[i];
    }

    T GetIf(int i, const T& defaultValue) const {
        if (checked_[i] == mark_) {
            return data_[i];
        }
        return defaultValue;
    }
};


struct CheckMapD {
private:
    vector<u32> checked_;
    u32 mark_ = 1;

public:
    void Init(int size) {
        checked_.resize(size, mark_);
        Clear();
    }

    void SetSize(int size) {
        checked_.resize(size, mark_);
    }
    void Clear() {
        ++mark_;

        if (mark_ == 0) {
            checked_.assign(checked_.size(), 0);
            ++mark_;
        }
    }
    inline bool IsChecked(int i) const {
        return checked_[i] == mark_;
    }

    inline bool operator[](int i) const {
        return checked_[i] == mark_;
    }

    inline void Check(int i) {
        checked_[i] = mark_;
    }

    inline void Reset(int i) {
        checked_[i] = mark_ - 1;
    }
};

struct CheckMapLightD {
private:
    vector<u8> checked_;
    u8 mark_ = 1;

public:
    void Init(int size) {
        checked_.resize(size, mark_);
        Clear();
    }

    void SetSize(int size) {
        checked_.resize(size, mark_);
    }
    void Clear() {
        ++mark_;

        if (mark_ == 0) {
            checked_.assign(checked_.size(), 0);
            ++mark_;
        }
    }
    inline bool IsChecked(int i) const {
        return checked_[i] == mark_;
    }

    inline bool operator[](int i) {
        return checked_[i] == mark_;
    }

    inline void Check(int i) {
        checked_[i] = mark_;
    }

    inline void Reset(int i) {
        checked_[i] = mark_ - 1;
    }
};

template <class T>
struct CheckMapDataD {
private:
    vector<T> data_;
    vector<u32> checked_;
    u32 mark_ = 1;

public:
    void Init(int size) {
        SetSize(size);
        Clear();
    }

    void SetSize(int size) {
        checked_.resize(size, mark_);
        data_.resize(size);
    }

    void Clear() {
        ++mark_;

        if (mark_ == 0) {
            checked_.assign(checked_.size(), 0);
            ++mark_;
        }
    }

    bool IsChecked(int i) const {
        return checked_[i] == mark_;
    }
    void Check(int i) {
        checked_[i] = mark_;
    }

    void Set(int i, const T& value) {
        checked_[i] = mark_;
        data_[i] = value;
    }

    void Reset(int i) {
        checked_[i] = mark_ - 1;
    }
    const T& Get(int i) const {
        VASSERT(checked_[i] == mark_);
        return data_[i];
    }
    T& Ref(int i) {
        VASSERT(checked_[i] == mark_);
        return data_[i];
    }
    const T& operator[](int i) const {
        VASSERT(checked_[i] == mark_);
        return data_[i];
    }
    T& operator[](int i) {
        VASSERT(checked_[i] == mark_);
        return data_[i];
    }
};

enum class Dir : int8_t {
	L = 0,
	U,
	R,
	D,
	N,
	Invalid,
};

constexpr array<Dir, 4> Dir4 = {
	Dir::L,
	Dir::U,
	Dir::R,
	Dir::D,
};

constexpr array<pint, 4> Around4 = { pint{-1, 0}, pint{0, -1}, pint{1, 0}, pint{0, 1} };

inline Dir RotateRight(Dir d) {
	return Dir(((int)d + 1) % 4);
}
inline Dir RotateLeft(Dir d) {
	return Dir(((int)d + 3) % 4);
}

inline Dir Back(Dir d) {
	return Dir(s8(d) ^ 2);
}

bool IsHorizontal(Dir dir) {
	return dir == Dir::L || dir == Dir::R;
}
bool IsVertical(Dir dir) {
	return dir == Dir::U || dir == Dir::D;
}

inline Dir CalcDir(const pint& from, const pint& to) {
	if (from.x > to.x) {
		return Dir::L;
	}
	else if (from.y > to.y) {
		return Dir::U;
	}
	else if (from.x < to.x) {
		return Dir::R;
	}
	else if (from.y < to.y) {
		return Dir::D;
	}
	else {
		return Dir::N;
	}
}


inline const string& DirString(Dir dir) {
	static const string strs[6] = {
		"LEFT",
		"UP",
		"RIGHT",
		"DOWN",
		"WAIT",
		"INVALID",
	};
	return strs[(int)dir];
}

inline char DirToChar(Dir dir) {
	static const char chars[6] = {
		'L',
		'U',
		'R',
		'D',
		'N',
		'*',
	};
	return chars[(int)dir];
}

inline Dir CharToDir(char c) {
	if (c == 'L') {
		return Dir::L;
	}
	else if (c == 'U') {
		return Dir::U;
	}
	else if (c == 'R') {
		return Dir::R;
	}
	else if (c == 'D') {
		return Dir::D;
	}
	else if (c == 'N') {
		return Dir::N;
	}
	VABORT();
	return Dir::Invalid;
}

struct GridSystemD {
	int W;
	int H;
	int WH;	
	void Init(int w, int h) {
		W = w;
		H = h;
		WH= W * H;
	}

	inline int ToId(int x, int y) const {
		return x + W * y;
	}
	inline int ToId(const pint& p) const {
		return p.x + W * p.y;
	}
	inline pint ToPos(int id) const {
		return pint{ id % W, id / W };
	}

	inline int CalcL1Dist(const pint& a, const pint& b) const {
		return abs(a.x - b.x) + abs(a.y - b.y);
	}
	inline int CalcL1Dist(int a, int b) const {
		return CalcL1Dist(ToPos(a), ToPos(b));
	}

	inline int CalcL2Dist2(const pint& a, const pint& b) const {
		return square(a.x - b.x) + square(a.y - b.y);
	}
	inline int CalcL2Dist2(int a, int b) const {
		return CalcL2Dist2(ToPos(a), ToPos(b));
	}

	inline double CalcL2Dist(const pint& a, const pint& b) const {
		return sqrt(CalcL2Dist2(a, b));
	}
	inline double CalcL2Dist(int a, int b) const {
		return CalcL2Dist(ToPos(a), ToPos(b));
	}

	inline bool IsOut(int x, int y) const {
		if (x < 0 || x >= W ||
			y < 0 || y >= H) {
			return true;
		}
		return false;
	}
	inline bool IsOut(const pint& p) const {
		return IsOut(p.x, p.y);
	}
	inline bool IsIn(int x, int y) const {
		return !IsOut(x, y);
	}
	inline bool IsIn(const pint& p) const {
		return !IsOut(p.x, p.y);
	}

	inline bool IsBorder(int x, int y) const {
		if (IsOut(x, y)) {
			return false;
		}
		if (x == 0 || x == W - 1 ||
			y == 0 || y == H - 1) {
			return true;
		}
		return false;
	}
	inline bool IsBorder(const pint& p) const {
		return IsBorder(p.x, p.y);
	}
	inline bool IsBorder(int cell) const {
		return IsBorder(ToPos(cell));
	}

	inline int RotateRight90(int id) const {
		pint p = ToPos(id);
		return ToId(W - 1 - p.y, p.x);
	}

};

template <class T, int CAP>
struct CCA {
private:
    T ar[CAP];
    int s;

public:
    inline constexpr void push(const T& v) {
        ar[s++] = v;
    }
    inline constexpr const T* begin() const {
        return &ar[0];
    }
    inline constexpr const T* end() const {
        return &ar[s];
    }

    inline constexpr const T& operator ()(int i) const {
        return ar[i];
    }
    inline constexpr const T& operator [](int i) const {
        return ar[i];
    }
    inline constexpr int size() const {
        return s;
    }
};

template <int W, int H, int AROUND_COUNT>
struct AroundMapS {
    using CA = CCA<int, AROUND_COUNT>;
    CA table[W * H];

    constexpr AroundMapS(const array<pint, AROUND_COUNT>& aroundDirs) : table{} {
        REP(cellId, W * H) {
            pint p = { cellId % W, cellId / W };
            for (const pint& a : aroundDirs) {
                int x = p.a + a.a;
                int y = p.b + a.b;
                if (x >= 0 && x < W &&
                    y >= 0 && y < H) {
                    table[cellId].push(x + y * W);
                }
            }
        }
    }

    inline constexpr const CA& operator ()(int id) const {
        return table[id];
    }
    inline constexpr const CA& operator [](int id) const {
        return table[id];
    }
};

template <int AROUND_COUNT>
struct AroundMapD {
    using CA = CCA<int, AROUND_COUNT>;
    vector<CA> table_;
    int width_ = 1;

    void Init(int width, int height, const array<pint, AROUND_COUNT>& aroundDirs) {
        width_ = width;
        int count = width * height;
        table_.clear();
        table_.resize(count);

        REP(i, count) {
            pint p = { i % width, i / width };
            for (const pint& a : aroundDirs) {
                pint n = p + a;
                if (n.a >= 0 && n.a < width &&
                    n.b >= 0 && n.b < height) {
                    table_[i].push(n.a + n.b * width);
                }
            }
        }
    }

    inline const CA& operator[](int i) const {
        return table_[i];
    }
    inline const CA& operator[](const pint& p) const {
        return table_[p.x + p.y * width_];
    }
};

template <int W, int H, int AROUND_COUNT>
struct DirMapS {
    using CA = CCA<int, AROUND_COUNT>;
    CA table[W * H];

    constexpr DirMapS(const array<pint, AROUND_COUNT>& aroundDirs) : table{} {
        REP(cellId, W * H) {
            pint p = { cellId % W, cellId / W };
            for (const pint& a : aroundDirs) {
                int x = p.a + a.a;
                int y = p.b + a.b;
                int n = -1;
                if (x >= 0 && x < W &&
                    y >= 0 && y < H) {
                    n = x + y * W;
                }
                table[cellId].push(n);
            }
        }
    }

    inline constexpr const CA& operator ()(int id) const {
        return table[id];
    }
    inline constexpr const CA& operator [](int id) const {
        return table[id];
    }
};

template <int AROUND_COUNT>
struct DirMapD {
    using CA = CCA<int, AROUND_COUNT>;
    vector<CA> table_;
    int width_ = 1;

    void Init(int W, int H, const array<pint, AROUND_COUNT>& aroundDirs) {
        width_ = W;
        int count = W * H;
        table_.clear();
        table_.resize(count);

        REP(cellId, count) {
            pint p = { cellId % W, cellId / W };
            for (const pint& a : aroundDirs) {
                int x = p.a + a.a;
                int y = p.b + a.b;
                int n = -1;
                if (x >= 0 && x < W &&
                    y >= 0 && y < H) {
                    n = x + y * W;
                }
                table_[cellId].push(n);
            }
        }
    }

    inline const CA& operator ()(int id) const {
        return table_[id];
    }
    inline const CA& operator [](int id) const {
        return table_[id];
    }
};

constexpr double LinearParam(double ax, double ay, double bx, double by, double cx) {
	double r = (cx - ax) / (bx - ax);
	double cy = ay + (by - ay) * r;
	return cy;
}

int LinearParamInt(double ax, double ay, double bx, double by, double cx) {
	return (int)round(LinearParam(ax, ay, bx, by, cx));
}


#include <cstdint>


struct Xor64 {
	using result_type = uint64_t;
	static constexpr result_type min() { return 0; }
	static constexpr result_type max() { return UINT64_MAX; }

private:
	Xor64(const Xor64& r) = delete;
	Xor64& operator =(const Xor64& r) = delete;
public:

	uint64_t x;
	inline Xor64(uint64_t seed = 0) {
		x = 88172645463325252ULL + seed;
	}

	inline uint64_t operator()() {
		x = x ^ (x << 7);
		return x = x ^ (x >> 9);
	}

	inline uint64_t operator()(uint64_t l, uint64_t r) {
		return ((*this)() % (r - l)) + l;
	}

	inline uint64_t operator()(uint64_t r) {
		return (*this)() % r;
	}
	inline double GetDouble() {
		return (*this)() / (double)UINT64_MAX;
	}
};


struct Random {
	static inline Xor64& Instnce() {
		static Xor64 x;
		return x;
	}

	static inline uint64_t Get() {
		return Instnce()();
	}
	static inline uint64_t Get(uint64_t l, uint64_t r) {
		return Instnce()(l, r);
	}
	static inline uint64_t Get(uint64_t r) {
		return Instnce()(r);
	}

	static inline void Get2(uint64_t N, uint64_t& a, uint64_t& b) {
		VASSERT(N >= 2);
		a = Get(N);
		b = Get(N - 1);
		if (b >= a) {
			++b;
		}
	}

	static inline double GetDouble() {
		return Get() / (double)UINT64_MAX;
	}

	static inline double GetDouble(double l, double r) {
		return l + GetDouble() * (r - l);
	}
};

#define PARAM_CATEGORY(NAME, VALUE, VALUE_LIST) const char* NAME = VALUE;
#define PARAM_INT(NAME, VALUE, LOWER_VALUE, UPPER_VALUE) int NAME = VALUE;
#define PARAM_DOUBLE(NAME, VALUE, LOWER_VALUE, UPPER_VALUE) double NAME = VALUE;


#define PARAM_INT_RANGE(NAME, VALUE, LOWER_VALUE, UPPER_VALUE, LOWER_LIMIT, UPPER_LIMIT) int NAME = VALUE;
#define PARAM_DOUBLE_RANGE(NAME, VALUE, LOWER_VALUE, UPPER_VALUE, LOWER_LIMIT, UPPER_LIMIT) double NAME = VALUE;


#define PARAM_LOWER(v)
#define PARAM_UPPER(v)
#define START_TUNING
#define END_TUNING




constexpr
struct {

	PARAM_DOUBLE(SingleColorLine1, 1.0, 0.0, 2.0);
	PARAM_DOUBLE(SingleColorLine2, 1.0, 0.0, 2.0);



	START_TUNING;
	PARAM_DOUBLE(LineRateBest, 0.9825095557609776, 0.0, 2.0);
	PARAM_DOUBLE(LineRateOther, 0.4120029687139691, 0.0, 1.0);
	PARAM_DOUBLE(CanPutScore, 2.7894487144521785, 0.0, 2.0);
	PARAM_DOUBLE(DetailReachRate, 0.11112224920151231, 0.0, 1.0);
	PARAM_DOUBLE(SinglePenaltyNN, 0.4331935587884715, 0.0, 2.0);PARAM_LOWER(0.0);
	PARAM_DOUBLE(SinglePenaltyP, 0.7422525158467617, 0.0, 1.0);PARAM_LOWER(0.0);
	END_TUNING;
} HP;

constexpr int N_MIN = 6;
constexpr int N_MAX = 20;
constexpr int NN_MIN = N_MIN * N_MIN;
constexpr int NN_MAX = N_MAX* N_MAX;

constexpr int S = 3;
constexpr int SS = S*S;

constexpr int T_MAX = 5;
constexpr int C_MAX = 5;

constexpr double P_MIN = 0.2;
constexpr double P_MAX = 0.5;

constexpr int TURN_MAX = 1000;

template <class T>
using Grid = CapArr<T, NN_MAX>;

template <class T>
using Tile = array<T, SS>;

GridSystemD gs;
AroundMapD<4> aroundMap;
DirMapD<4> dirMap;
Grid<array<int, SS>> tileCellsGrid;		


#define DISP_GRID 0
#define USE_BIT_CHECK 1

struct TilePattern {
	s8 color;
	bitset<9> bits;

	void Init(s8 color, const bitset<9>& bits) {
		VASSERT(color > 0);
		this->color = color;
		this->bits = bits;
	}

	s8 GetColor(int i) const {
		return bits[i] ? color : 0;
	}
};
using TileCells = array<int, SS>;


struct Action {
	int id;		
	int cell;	

	void SetEnd() {
		id = -1;
		cell = -1;
	}
	void SetDrop(int id) {
		this->id = id;
		cell = -1;
	}
	void SetPut(int id, int cell) {
		this->id = id;
		this->cell = cell;
	}
};

struct LineState {
	s8 totalCount;					
	CapArr<s8, C_MAX> counts;		

	void Init(int N, int C) {
		totalCount = 0;
		counts.assign(C, 0);
	}

	void Put(int v) {
		++totalCount;
		++counts[v - 1];
	}

	bool IsFull(int N) const {
		return totalCount == N;
	}
	int Score() const {
		int mc = 0;
		REP(i, counts.size()) {
			chmax(mc, counts[i]);
		}
		return mc * mc;
	}
	void Remove(int v) {
		--totalCount;
		--counts[v - 1];
	}
	void Clear() {
		totalCount = 0;
		counts.assign(counts.size(), 0);
	}
};

struct GridState {
	Grid<s8> grid;
	array<CapArr<LineState, N_MAX>, 2> lines;		
	Grid<bitset<9>> bitGrid;		

	int GetN() const {
		return lines[0].size();
	}

	void SetBit(const pint& cp, bool val = true) {
		REP(oy, 3) {
			REP(ox, 3) {
				pint p = cp + pint{ ox - 2, oy - 2 };
				if (gs.IsOut(p)) {
					continue;
				}
				int cell = gs.ToId(p);
				int putBit = (2 - oy) * 3 + (2 - ox);
				bitGrid[cell].set(putBit, val);
			}
		}
	}
	void SetBit(int putCell, bool val = true) {
		SetBit(gs.ToPos(putCell), val);
	}
	void ResetBit(int putCell) {
		SetBit(putCell, false);
	}

	void Init(int N, int C) {
		int NN = N * N;
		grid.assign(NN, 0);
		lines[0].resize(N);
		lines[1].resize(N);
		REP(i, N) {
			lines[0][i].Init(N, C);
			lines[1][i].Init(N, C);
		}
		bitGrid.assign(NN, 0);

	}

	void Input(istream& is) {
		REP(i, grid.size()) {
			int v;
			is >> v;
			grid[i] = v;

			if (v > 0) {
				pint p = gs.ToPos(i);
				lines[0][p.y].Put(v);
				lines[1][p.x].Put(v);

				SetBit(i);
			}
		}
	}

	void Put(const TilePattern& tile, const TileCells& cells, Grid<bool>* updateMap = nullptr) {
		REP(i, SS) {
			VASSERT(!(tile.bits[i] && grid[cells[i]] > 0));
			auto v = tile.GetColor(i);
			if (v > 0) {
				int cell = cells[i];
				grid[cell] = v;

				pint p = gs.ToPos(cell);
				lines[0][p.y].Put(v);
				lines[1][p.x].Put(v);
				SetBit(cell);
			}
		}

		if (updateMap) {
			pint cp = gs.ToPos(cells[0]);
			REP(oy, 5) {
				REP(ox, 5) {
					pint p = cp + pint{ox - 2, oy - 2};
					if (gs.IsOut(p)) {
						continue;
					}
					int cell = gs.ToId(p);
					(*updateMap)[cell] = true;
				}
			}
		}
	}
	void Put(const TilePattern& tile, int cell, Grid<bool>* updateMap = nullptr) {
		Put(tile, tileCellsGrid[cell], updateMap);
	}

	bool CanPut(const bitset<9>& bits, int cell) const {
		if (tileCellsGrid[cell][0] < 0) {
			return false;
		}
		return (bits & bitGrid[cell]).none();
	}
	bool CanPut(const TilePattern& tile, int cell) const {
		return CanPut(tile.bits, cell);
	}

	int CheckLine(int& removeLineCount, Grid<bool>* updateMap = nullptr) {
		int score = 0;
		int N = lines[0].size();
		array<CapArr<s8, N_MAX>, 2> removeLines;
		array<array<bool, N_MAX>, 2> removeLineFlags;
		REP(i, 2) {
			removeLineFlags[i].fill(false);
			REP(l, N) {
				if (!lines[i][l].IsFull(N)) {
					continue;
				}
				int s = lines[i][l].Score();
				score += s;
				removeLines[i].push_back(l);
				removeLineFlags[i][l] = true;
			}
		}

		removeLineCount = removeLines[0].size() + removeLines[1].size();
		score *= removeLineCount;

		REP(i, 2) {
			auto& crossLines = lines[1 - i];
			for (int l : removeLines[i]) {
				REP(m, N) {
					int cell = -1;
					if (i == 0) {
						cell = gs.ToId(m, l);
					}
					else {
						cell = gs.ToId(l, m);
					}
					int v = grid[cell];
					if (v > 0) {
						grid[cell] = 0;
						crossLines[m].Remove(v);
						ResetBit(cell);
					}
				}
				lines[i][l].Clear();
			}
		}

		if (updateMap) {

			for (int l : removeLines[0]) {
				FOR(y, max(l - 2, 0), l + 1) {
					REP(x, N) {
						int cell = gs.ToId(x, y);
						(*updateMap)[cell] = true;
					}
				}
			}

			for (int l : removeLines[1]) {
				FOR(x, max(l - 2, 0), l + 1) {
					REP(y, N) {
						int cell = gs.ToId(x, y);
						(*updateMap)[cell] = true;
					}
				}
			}
		}

		return score;
	}

	int CalcPutScore(const TilePattern& tile, const TileCells& cells, int& removeLineCount) const {
		auto& mutableLines = const_cast<GridState&>(*this).lines;		

		REP(i, SS) {
			VASSERT(!(tile.bits[i] && grid[cells[i]] > 0));
			auto v = tile.GetColor(i);
			if (v > 0) {
				int cell = cells[i];
				pint p = gs.ToPos(cell);
				mutableLines[0][p.y].Put(v);
				mutableLines[1][p.x].Put(v);
			}
		}

		int score = 0;
		int N = lines[0].size();
		removeLineCount = 0;
		REP(i, 2) {
			REP(l, N) {
				if (!lines[i][l].IsFull(N)) {
					continue;
				}
				int s = lines[i][l].Score();
				score += s;
				++removeLineCount;
			}
		}
		score *= removeLineCount;

		REP(i, SS) {
			auto v = tile.GetColor(i);
			if (v > 0) {
				int cell = cells[i];
				pint p = gs.ToPos(cell);
				mutableLines[0][p.y].Remove(v);
				mutableLines[1][p.x].Remove(v);
			}
		}
		return score;
	}
	int CalcPutScore(const TilePattern& tile, int cell, int& removeLineCount) const {
		return CalcPutScore(tile, tileCellsGrid[cell], removeLineCount);
	}


};

struct IOServer {
	int turn_;
	int score_;
	int N, T, C;
	double F, P;
	GridState grid;
	int NN;
	int dropCount;
	int putCount;

	CapArr<TilePattern, T_MAX> tiles;

public:
	void InitInput() {
		istream& is = cin;
		timer.Init();		

		is >> N >> T >> C >> F >> P;
		NN = N * N;

		gs.Init(N, N);
		aroundMap.Init(N, N, Around4);
		dirMap.Init(N, N, Around4);

		grid.Init(N, C);
		grid.Input(is);

		tiles.resize(T);
		REP(id, T) {
			string line;
			is >> line;
			REP(i, SS) {
				int v = (int)(line[i] - '0');
				if (v == 0) {
					tiles[id].bits[i] = false;
				}
				else {
					tiles[id].color = v;
					tiles[id].bits[i] = true;
				}
			}
		}

		tileCellsGrid.resize(NN);
		REP(i, NN) {
			auto& g = tileCellsGrid[i];
			pint p = gs.ToPos(i);
			if (p.x + 2 >= N || p.y + 2 >= N) {
				g[0] = -1;
				continue;
			}
			REP(j, SS) {
				g[j] = i + (j % 3) + (j / 3) * N;
			}
		}

		turn_ = 0;
		score_ = 0;
		dropCount = 0;
		putCount = 0;

		DispGrid();
	}

	void TurnInput(int id) {
		istream& is = cin;
		{
			string line;
			is >> line;
			REP(i, SS) {
				int v = (int)(line[i] - '0');
				if (v == 0) {
					tiles[id].bits[i] = false;
				}
				else {
					tiles[id].color = v;
					tiles[id].bits[i] = true;
				}
			}
		}
		int elapsedTime;
		is >> elapsedTime;
		timer.SetElapseTimeMs(elapsedTime);
	}

	void Output(const Action& action, int& removeLineCount) {
		removeLineCount = 0;
		ostream& os = cout;

		if (action.id < 0) {
			os << -1 << endl;
			return;
		}
		if (action.cell < 0) {
			os << action.id << endl;
			++dropCount;
		}
		else {
			pint p = gs.ToPos(action.cell);
			os << action.id << " " << p.y << " " << p.x << endl;

			cauto& tile = tiles[action.id];
			cauto& cells = tileCellsGrid[action.cell];
			grid.Put(tile, cells);

			score_ += grid.CheckLine(removeLineCount);

			++putCount;
		}


		++turn_;


			TurnInput(action.id);

	}

	void Finalize() {
	}

	void DispGrid() const {
	}

	bool CanPut(int id, int cell) const {
		cauto& tile = tiles[id];
		return grid.CanPut(tile, cell);
	}
};
IOServer server;




void Sample() {
    int N, T, C;
    double F, P;
    cin >> N >> T >> C >> F >> P;

    vector<vector<int>> grid(N);
    for (int r = 0; r < N; r++) {
        grid[r].resize(N);
        for (int c = 0; c < N; c++)
        {
            cin >> grid[r][c];
        }
    }

    const int S = 3;
    vector<vector<vector<int>>> tiles(T);
    tiles.resize(T);
    REP(i, T) {
        tiles[i].resize(S);
        REP(j, S) {
            tiles[i][j].resize(S);
        }
    }
    for (int i = 0; i < T; i++)
    {
        string line;
        cin >> line;
        for (int r = 0; r < S; r++)
            for (int c = 0; c < S; c++)
                tiles[i][r][c] = (int)(line[r * S + c] - '0');
    }

    int q = N / S;

    for (int i = 0; i < 1000; i++)
    {
        int id = i % T;
        int r = ((i / q) * S) % (N - 2);
        int c = ((i % q) * S) % (N - 2);

        bool valid = true;
        for (int r2 = 0; r2 < S; r2++)
            for (int c2 = 0; c2 < S; c2++)
                if (tiles[id][r2][c2] > 0 && grid[r + r2][c + c2] > 0) valid = false;
        if (!valid) continue;

        for (int r2 = 0; r2 < S; r2++)
            for (int c2 = 0; c2 < S; c2++)
                if (tiles[id][r2][c2] > 0)
                    grid[r + r2][c + c2] = tiles[id][r2][c2];

        cout << id << " " << r << " " << c << endl;
        cout.flush();

        string line;
        cin >> line;
        for (int r2 = 0; r2 < S; r2++)
            for (int c2 = 0; c2 < S; c2++)
                tiles[id][r2][c2] = (int)(line[r2 * S + c2] - '0');

        int elapsedTime;
        cin >> elapsedTime;
    }

    cout << "-1" << endl;
    cout.flush();
}

namespace solver1 {

	array<double, 512> spawnRates = {};
	void InitSpawnRate(double P) {
		double sum = 0;
		FOR(bit, 1, 1 << 9) {
			bitset<9> b(bit);
			int on = (int)b.count();
			int off = 9 - on;
			double prob = pow(P, on) * pow(1.0 - P, off);
			spawnRates[bit] = prob;
			sum += prob;
		}
		FOR(bit, 1, 1 << 9) {
			spawnRates[bit] /= sum;
		}

	}

	struct CanPutScore {
		double totalScore;				
		Grid<double> putProbGrid;		

		void Init(const GridState& grid) {
			int N = grid.GetN();
			int NN = N * N;
			totalScore = 0;
			putProbGrid.assign(NN, 0);
			REP(cell, NN) {
				double s = 0;
				REP(bit, 1 << 9) {
					if (grid.CanPut(bit, cell)) {
						s += spawnRates[bit];
					}
				}
				putProbGrid[cell] = s;
				totalScore += s;
			}
		}

		void Update(const GridState& grid, int cell) {
			totalScore -= putProbGrid[cell];
			double s = 0;
			REP(bit, 1 << 9) {
				if (grid.CanPut(bit, cell)) {
					s += spawnRates[bit];
				}
			}
			putProbGrid[cell] = s;
			totalScore += s;
		}

		void Update(const GridState& grid, const Grid<bool>& updateMap) {
			REP(cell, updateMap.size()) {
				if (updateMap[cell]) {
					Update(grid, cell);
				}
			}
		}
	};

	struct Solver {
		double singlePenalty_ = 0;
		double lineRate_ = 1;

		void Run() {
			InitSpawnRate(server.P);

			singlePenalty_ = 0;
			singlePenalty_ += LinearParam(NN_MIN, 0.0, NN_MAX, 1.0, server.NN) * HP.SinglePenaltyNN;
			singlePenalty_ += LinearParam(P_MIN, 1.0, P_MAX, 0, server.P) * HP.SinglePenaltyP;

			int N = server.N;
			int NN = server.NN;
			CanPutScore canPutScore;

			Action action;

			REP(turn, TURN_MAX) {
				if (timer.IsOver()) {
					action.SetEnd();
					int removeLineCount = 0;
					server.Output(action, removeLineCount);
					break;
				}

				canPutScore.Init(server.grid);

				bool canPut = false;
				int bestRemoveLine = 0;
				[&]() {

					int startY = 0;
					int startX = 0;
					int stepY = 1;
					int stepX = 1;
					double timeRate = timer.NowRate();
					if (timeRate > 0.5) {
						double turnRate = turn / (double)TURN_MAX;
						if (turnRate < timeRate) {
							int timing = turn % 4;
							startX = timing % 2;
							startY = timing / 2;
							stepX = 2;
							stepY = 2;

						}
					}

					double bestEvalScore = -1e100;

					{
						int ti = turn % server.T;
						action.SetDrop(ti);
						bestEvalScore = Eval(turn, true, ti, server.grid, server.grid, 0, 0, canPutScore);
					}
					REP(ti, server.tiles.size()) {
						cauto& tile = server.tiles[ti];
						for (int y = startY; y < N - 2; y += stepY) {
							for (int x = startX; x < N - 2; x += stepX) {
								int cell = gs.ToId(x, y);
								if (server.CanPut(ti, cell)) {
									canPut = true;
									auto tmpGrid = server.grid;

									static Grid<bool> updateMap;
									updateMap.assign(NN, false);
									tmpGrid.Put(tile, cell, &updateMap);

									int removeLineCount = 0;
									int gotRawScore = tmpGrid.CheckLine(removeLineCount, &updateMap);
									chmax(bestRemoveLine, removeLineCount);

									auto tmpCanPutScore = canPutScore;
									tmpCanPutScore.Update(tmpGrid, updateMap);

									double evalScore = Eval(turn, false, ti, server.grid, tmpGrid, gotRawScore, removeLineCount, tmpCanPutScore);

									if (evalScore > bestEvalScore) {
										bestEvalScore = evalScore;
										action.SetPut(ti, cell);
									}
								}
							}
						}
					}
				}();

				int removeLineCount = 0;
				server.Output(action, removeLineCount);
				if (action.id < 0) {
				}
				else if (action.cell < 0) {
					if (canPut) {
					}
					else {
					}

					singlePenalty_ *= 0.95;
				}
				else {
					if (removeLineCount == 1) {
						singlePenalty_ *= 1.05;
					}
				}
			}
		}

		double Eval(int turn, bool isDrop, int useTileId, const GridState& prevGrid, const GridState& grid, int gotRawScore, int removeLineCount, const CanPutScore& canPutScore) {
			int const N = server.N;
			int const NN = server.NN;
			int const C = server.C;

			double evalScore = 0;

			static Grid<s8> reachMap;		
			reachMap.assign(NN, 0);
			int totalReachCount = 0;
			int totalObjectCount = 0;
			{
				double lineScore = 0;
				const array<double, 2> dirRates = { 1.0, server.C == 1 ? 1.0 : 0 };
				REP(dir, 2) {
					REP(li, N) {
						cauto& line = grid.lines[dir][li];
						if (dir == 0) {
							totalObjectCount += line.totalCount;
						}

						int maxCount = 0;
						REP(ci, server.C) {
							int c = line.counts[ci];
							chmax(maxCount, c);
						}
						int otherCount = line.totalCount - maxCount;
						int freeCount = N - line.totalCount;


						lineScore += square(maxCount) / (double)NN * dirRates[dir] * HP.LineRateBest;
						lineScore -= otherCount / (double)N * dirRates[dir] * HP.LineRateOther;

						if (freeCount == 1) {
							REP(pi, N) {
								int cell = -1;
								if (dir == 0) {
									cell = gs.ToId(pi, li);
								}
								else {
									cell = gs.ToId(li, pi);
								}
								if (grid.grid[cell] == 0) {
									reachMap[cell] += 1;
									++totalReachCount;
								}
							}
						}
					}
				}
				evalScore += lineScore * lineRate_;		
			}
			int prevTotalObjectCount = 0;
			{
				REP(li, N) {
					cauto& line = prevGrid.lines[0][li];
					prevTotalObjectCount += line.totalCount;
				}
			}
			int prevBlankCount = NN - prevTotalObjectCount;



			if (removeLineCount == 1) {
				evalScore -= 1000 * singlePenalty_;
			}

			evalScore += (gotRawScore / (double)NN) * 1000;		
			{
				if (server.C == 1) {
					if (removeLineCount == 1) {
						evalScore -= 1000 * HP.SingleColorLine1;
					}
					else if (removeLineCount == 2) {
						evalScore -= 1000 * 2 * HP.SingleColorLine2;
					}
				}
			}





			{
				REP(putCell, NN) {
					cauto& cells = tileCellsGrid[putCell];
					if (cells[0] < 0) {
						continue;
					}
					CapArr<int, 6> reachCells;		
					for (int cell : cells) {
						if (reachMap[cell] > 0) {
							reachCells.push_back(cell);
						}
					}

					double P = server.P;
					auto CalcProb = [&](CapArr<int, 3>& targets) {
						double prob = 1;
						for (int cell : cells) {
							if (reachMap[cell] > 0 && targets.Find(cell) >= 0) {
								prob *= P;
							}
							else {
								if (grid.grid[cell] == 0) {
								}
								else {
									prob *= 1.0 - P;
								}
							}
						}
						return prob;
					};

					double totalProb = 0;
					CapArr<int, 3> targets;
					REP(i, reachCells.size()) {
						targets.push_back(reachCells[i]);

						{
							double prob = CalcProb(targets);
							totalProb += prob;
						}

						REP(j, i) {
							targets.push_back(reachCells[j]);

							{
								double prob = CalcProb(targets);
								totalProb += prob;
							}

							REP(k, j) {
								targets.push_back(reachCells[k]);
								{
									double prob = CalcProb(targets);
									totalProb += prob;
								}

								targets.pop_back();
							}
							targets.pop_back();
						}

						targets.pop_back();
					}
					evalScore += totalProb * HP.DetailReachRate;
				}
			}


			{
				evalScore += canPutScore.totalScore / (double)NN * HP.CanPutScore;

			}

			return evalScore;
		}
	};

} 

namespace solver3 {

	struct Solver {
		int finalTi_ = -1;
		int finalPutCell_ = -1;

		int dropCount_ = 0;
		int targetLine_ = 6;

		void Run() {
			int N = server.N;
			int NN = server.NN;

			Action action;

			REP(turn, TURN_MAX) {
				if (timer.IsOver()) {
					action.SetEnd();
					int removeLineCount = 0;
					server.Output(action, removeLineCount);
					break;
				}

				if (finalTi_ < 0) {
					REP(ti, server.T) {
						cauto& tile = server.tiles[ti];
						array<bool, 3> yflags = {};
						array<bool, 3> xflags = {};
						REP(y, 3) {
							REP(x, 3) {
								if (tile.bits[y * 3 + x]) {
									yflags[y] = true;
									xflags[x] = true;
								}
							}
						}
						int lineCount = 0;
						REP(i, 3) {
							if (yflags[i]) {
								++lineCount;
							}
							if (xflags[i]) {
								++lineCount;
							}
						}
						if (lineCount < targetLine_) {
							continue;
						}

						int putCell = -1;
						double bestScore = -1e100;
						REP(cell, NN) {
							if (server.grid.CanPut(tile, cell)) {
								pint putP = gs.ToPos(cell);

								if (putP.x < 2 || putP.x >= N - 5 || putP.y < 2 || putP.y >= N - 5) {
									continue;
								}

								double score = 0;
								cauto& grid = server.grid;
								REP(cell, NN) {
									pint p = gs.ToPos(cell);
									if (p.x >= putP.x && p.x < putP.x + 3 || p.y >= putP.y && p.y < putP.y + 3) {
										if (grid.grid[cell] == tile.color) {
											score += 10;
										}
									}
									else {
										if (grid.grid[cell] > 0) {
											score += 1;
										}
									}
								}
								if (score > bestScore) {
									bestScore = score;
									putCell = cell;
								}

							}
						}
						if (putCell >= 0) {
							finalTi_ = ti;
							finalPutCell_ = putCell;
							break;
						}
					}
				}

				[&]() {

					int startY = 0;
					int startX = 0;
					int stepY = 1;
					int stepX = 1;
					double timeRate = timer.NowRate();
					if (timeRate > 0.5) {
						double turnRate = turn / (double)TURN_MAX;
						if (turnRate < timeRate) {
							int timing = turn % 4;
							startX = timing % 2;
							startY = timing / 2;
							stepX = 2;
							stepY = 2;

						}
					}

					double bestEvalScore = -1e101;

					REP(ti, server.T) {
						double evalScore = Eval(turn, true, ti, server.grid, server.grid, 0, 0);
						if (evalScore > bestEvalScore) {
							bestEvalScore = evalScore;
							action.SetDrop(ti);
						}
					}
					REP(ti, server.tiles.size()) {
						cauto& tile = server.tiles[ti];
						for (int y = startY; y < N - 2; y += stepY) {
							for (int x = startX; x < N - 2; x += stepX) {
								int cell = gs.ToId(x, y);
								if (server.CanPut(ti, cell)) {
									auto tmpGrid = server.grid;

									static Grid<bool> updateMap;
									updateMap.assign(NN, false);
									tmpGrid.Put(tile, cell, &updateMap);

									int removeLineCount = 0;
									int gotRawScore = tmpGrid.CheckLine(removeLineCount, &updateMap);

									double evalScore = Eval(turn, false, ti, server.grid, tmpGrid, gotRawScore, removeLineCount);

									if (evalScore > bestEvalScore) {
										bestEvalScore = evalScore;
										action.SetPut(ti, cell);
									}
								}
							}
						}
					}
				}();

				int removeLineCount = 0;
				server.Output(action, removeLineCount);
			}
		}

		double Eval(int turn, bool isDrop, int useTileId, const GridState& prevGrid, const GridState& grid, int gotRawScore, int removeLineCount) {
			int const N = server.N;
			int const NN = server.NN;
			int const C = server.C;
			double evalScore = 0;

			if (finalTi_ < 0) {
				if (isDrop) {
					return 0;
				}
				return -1e100;
			}

			if (useTileId == finalTi_) {
				if (removeLineCount >= targetLine_) {
					finalTi_ = -1;
					targetLine_ = 6;
					return 1e100;
				}
				return -1e100;
			}

			cauto& tile = server.tiles[finalTi_];
			{
				if (!grid.CanPut(tile, finalPutCell_)) {
					return -1e100;
				}
			}

			pint putP = gs.ToPos(finalPutCell_);

			REP(cell, NN) {
				pint p = gs.ToPos(cell);
				if (p.x >= putP.x && p.x < putP.x + 3 || p.y >= putP.y && p.y < putP.y + 3) {
					if (grid.grid[cell] == tile.color) {
						evalScore += 10;
					}
				}
				else {
					if (grid.grid[cell] > 0) {
					}
				}
			}

			return evalScore;
		}
	};

} 

struct Main {
    void Run(int argc, const char* argv[]) {


        server.InitInput();

        timer.StartMs(TIME_LIMIT);
        bool use3 = false;
        if (server.T >= 2) {
            if (server.C == 1 && server.N >= 11) {
                use3 = true;
            }
            else if (server.C == 2 && server.N >= 12) {
                use3 = true;
            }
            else if (server.C == 3 && server.N >= 16) {
                use3 = true;
            }
            else if (server.C == 4 && server.N >= 20) {
                use3 = true;
            }
        }

        if (use3) {
            auto* solver = new solver3::Solver();
            solver->Run();
        }
        else {
            auto* solver = new solver1::Solver();
            solver->Run();
        }

        cerr << "time " << timer.ElapseTimeMs() << endl;
        server.Finalize();
    }
};
