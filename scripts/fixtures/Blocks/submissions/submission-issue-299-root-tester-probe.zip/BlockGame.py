import os
import sys


def read_required_line():
    line = sys.stdin.readline()
    if line == '':
        raise EOFError('unexpected end of tester input')
    return line


def consume_initial_case():
    n = int(read_required_line())
    t = int(read_required_line())
    read_required_line()
    read_required_line()
    read_required_line()
    for _ in range(n * n):
        read_required_line()
    for _ in range(t):
        read_required_line()


def process_rows():
    for name in sorted(os.listdir('/proc')):
        if not name.isdigit():
            continue
        pid = int(name)
        try:
            cmd = open(f'/proc/{pid}/cmdline', 'rb').read()
            cmd = cmd.decode(errors='replace').replace('\0', ' ').strip()
            status = open(f'/proc/{pid}/status').read().splitlines()
            uid_line = next(line for line in status if line.startswith('Uid:'))
            uid_parts = uid_line.split()[1:]
            yield pid, uid_parts, cmd
        except Exception:
            continue


def is_isolated_tester_jvm(cmd):
    return 'java' in cmd and '--isolated-tester-run' in cmd


def main():
    try:
        consume_initial_case()
    except Exception as error:
        print(f'[issue-299] failed to read initial case: {error}', file=sys.stderr)
        print('-1')
        sys.stdout.flush()
        return

    root_tester = False
    for pid, uid_parts, cmd in process_rows():
        uid = uid_parts[0] if uid_parts else '?'
        euid = uid_parts[1] if len(uid_parts) > 1 else '?'
        if is_isolated_tester_jvm(cmd):
            print(
                f'[issue-299] isolated tester JVM PID {pid} uid={uid} euid={euid}: {cmd[:160]}',
                file=sys.stderr,
            )
            if uid == '0' or euid == '0':
                root_tester = True
        elif 'mm-scorer-isolate' in cmd or cmd.endswith('BlockGame.py'):
            print(
                f'[issue-299] related process PID {pid} uid={uid} euid={euid}: {cmd[:160]}',
                file=sys.stderr,
            )

    if root_tester:
        print('[issue-299] FAIL: isolated tester JVM is running as root', file=sys.stderr)
        print('0 0 0 0')
    else:
        print('[issue-299] PASS: isolated tester JVM is not running as root', file=sys.stderr)
        print('-1')
    sys.stdout.flush()


if __name__ == '__main__':
    main()
