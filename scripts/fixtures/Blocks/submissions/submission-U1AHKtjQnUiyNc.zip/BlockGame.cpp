// Topcoder - TCO 22 Marathon Finals - BlockGame.
// Author: vdave, Hungary.

#define NOMINMAX
#define _CRT_SECURE_NO_WARNINGS

//#pragma GCC target "avx"

#include <algorithm>
#include <cstdio>
#include <cfloat>
#include <cstring>
#include <functional>
#include <iostream>
#include <map>
#include <random>
#include <set>
#include <string>
#include <utility>
#include <vector>
#include <unordered_map>
#include <unordered_set>

using namespace std;

#define TC_DEBUG

#ifdef TC_DEBUG
#define DEBUG(...) fprintf(fDebug, __VA_ARGS__)
#define GDEBUG(s, ...) { sprintf(sTmp, __VA_ARGS__); s.append(sTmp); }
#else
#define DEBUG(...)
#define GDEBUG(...)
#endif

// Platform specific stuff (timer, alignment, some intrinsics).

#ifdef _WIN32

// WIN32 platform definitions

#define ALIGN_SSE __declspec(align(64))
#define NOINLINE __declspec(noinline)

#include <ctime>
#include <intrin.h>
#include <windows.h>

typedef LARGE_INTEGER hp_timer_t;
LARGE_INTEGER gl_timer_freq;
double gl_timer_multiplier;

void InitTimer() {
	QueryPerformanceFrequency(&gl_timer_freq);
	gl_timer_multiplier = 1000000.0 / (double)gl_timer_freq.QuadPart;
}

void FetchTime(hp_timer_t* timer_value) {
	QueryPerformanceCounter(timer_value);
}

double GetElapsedMicros(hp_timer_t& timer_value_begin, hp_timer_t& timer_value_end) {
	return gl_timer_multiplier * (timer_value_end.QuadPart - timer_value_begin.QuadPart);
}

int __gcd(int a, int b) {
	if (b == 0) return a;
	return __gcd(b, a % b);
}

#else

// LINUX platform definitions

#define ALIGN_SSE __attribute__((aligned (64)))
#define NOINLINE

#include <sys/time.h>
#include <ctime>
#include <random>

typedef struct timeval hp_timer_t;

void InitTimer() {
}

void FetchTime(hp_timer_t* timer_value) {
	gettimeofday(timer_value, nullptr);
}

double GetElapsedMicros(hp_timer_t& timer_value_begin,
	hp_timer_t& timer_value_end) {
	return (timer_value_end.tv_sec * 1000000.0 + timer_value_end.tv_usec)
		- (timer_value_begin.tv_sec * 1000000.0 + timer_value_begin.tv_usec);
}

#endif



// Debug information for local runs.
bool dbgHasExtraInput;
int dbgSeed;
FILE* fDebug = stderr;
FILE* fTracking = nullptr;
char sTmp[65536];

// Global tweaking constants.
constexpr double kMaxRuntimeMicros = 9.6 * 1000.0 * 1000.0;
constexpr int kDeltaX[4] = { 1, -1, 0, 0, };
constexpr int kDeltaY[4] = { 0, 0, 1, -1, };
constexpr int kTileSize = 9;
constexpr int kTileDX[9] = { 0, 1, 2, 0, 1, 2, 0, 1, 2 };
constexpr int kTileDY[9] = { 0, 0, 0, 1, 1, 1, 2, 2, 2 };

// Problem-specific tweaking constants.
bool kRandomShuffleMatches = false;
double kSkipSimulationScoreThreshold = 1.5;
double kMinFillFactorForPoint = 0.7;
bool kPenalizeFragmentedEmpty = false;

// Global randomness.
mt19937 randEngine;
std::uniform_real_distribution<double> randProb(0.0, 1.0);

// Timekeeping.
hp_timer_t tBegin, tInit, tCurrent;
int currentRound, numIters;
int roundsPerTimeCheck = 1;
double estimatedProgress = 0.0;

// Input copied.
int N, T, C;
double F, P, OnePerSqrN;

// Current board and tile set, calculated next move (position is V * 356 + U on board).
ALIGN_SSE char currentBoard[32][32];
ALIGN_SSE char currentTiles[8][16];
int numMatches;
// Value is tileId << 16 | row << 8 | column.
int currentMatches[24 * 24 * 6];
unordered_set<int> pointToMatchList[24][24];
vector<int> matchToPointList[24 * 24 * 6];

int nextTileId, nextTilePos;

// State for simulations and scoring.
struct State {
	// The board layout at this state.
	ALIGN_SSE char board[24][32];
	// The distribution of colors 
	ALIGN_SSE char distC[40][8];

	// List of used matchIds (index into currentMatches) to build this state, the
	// matchIds are stored in 12 bit sections sorted.
	long long usedMatchIds;

	// Bitmask of tiles already used.
	int usedTileMask;

	// Number of tile placements simulated for this state.
	int simDepth;
	// Encoded match (combination of tileId and position) that generated this state.
	int matchMask;
	int prevStateId;

	// Actual game points gained in this state.
	int realScore;
	float fillFactor;

	// Overall score, all scoring aspects combined.
	int score;
};
typedef std::function<int(const State&)> ScorerFn;

// Cross-turn move and score tracking.
constexpr int kMaxMoves = 1000;
int moveCount;
int totalScore;

// Intermediate variables for various scoring parts.
ALIGN_SSE int numEmptyR[32];
ALIGN_SSE int numEmptyC[32];

// Simulation into the future, only using already provided tiles as it's extremely unlikely to
// figure out what the tester will give.
constexpr int kMinStates = 16;
constexpr int kMaxStates = 2048;
int currentBeamWidth = 64;
int numStates;
ALIGN_SSE State allStates[65536];
int numCurrStates, numNextStates;
ALIGN_SSE int currStateIds[kMaxStates];
ALIGN_SSE int nextStateIds[kMaxStates];

// Solver API.
class BlockGame {
public:
	void findSolution(int aN, int aT, int aC, double aF, double aP, const std::vector<std::string>& aBoard, const std::vector<std::string>& aTiles);
};

// Find the expected end time (compared to tBegin) on move 'moveCount'
double GetTargetEndMicros() {
	double moveFrac = 1.0 * moveCount / kMaxMoves;
	double initTime = GetElapsedMicros(tBegin, tInit);
	double nonInitTime = kMaxRuntimeMicros - initTime;
	double fracTime = moveFrac * nonInitTime;
	return initTime + fracTime;
}

// Display the full board (with 2 x 2 border) for debug purposes.
void Debug_ShowBoard() {
	for (int v = 0; v < N; ++v) {
		for (int u = 0; u < N; ++u) {
			DEBUG("%c", currentBoard[v][u] ? 'A' + currentBoard[v][u] : '.');
		}
		DEBUG("\n");
	}
	DEBUG("\n");
}

// Just drop a random tile, nothing is ever placed. Naive solution #1.
void FindNextMove_DropRandom() {
	nextTileId = randEngine() % T;
	nextTilePos = 0;
}

// Uniformly pick one of all possible tile placements, if no placement can happen,
// drop a random tile. Naive solution #2.
void FindNextMove_Random() {
	// Check if something can be placed
	int numPlacements = 0;
	nextTileId = randEngine() % T;
	nextTilePos = 0;
	for (int t = 0; t < T; ++t) {
		const char* tile = currentTiles[t];
		for (int v = -2; v < N; v++) {
			for (int u = -2; u < N; u++) {
				bool match = true;
				for (int i = 0; i < kTileSize; ++i) {
					const int tileV = v + kTileDY[i];
					const int tileU = u + kTileDX[i];
					if (tile[i] != 0 && (tileV < 0 || tileU < 0 || tileV >= N || tileU >= N || currentBoard[tileV][tileU] != 0)) {
						match = false;
						break;
					}
				}
				if (match) {
					++numPlacements;
					if (randEngine() % numPlacements == 0) {
						nextTileId = t;
						nextTilePos = v * 256 + u;
					}
				}
			}
		}
	}
}

// Find all matches on the board at the beginning of each turn. Since at every turn we simulate at most until
// the first clearing of lines, the matches can only strictly decrease => it's enough to verify if a match is
// still a match after a couple of moves.
void CalculateMatches() {
	numMatches = 0;
	for (int v = 0; v < N; ++v) {
		for (int u = 0; u < N; ++u) {
			pointToMatchList[v][u].clear();
		}
	}

	for (int t = 0; t < T; ++t) {
		const char* tile = currentTiles[t];
		for (int v = -2; v < N; v++) {
			for (int u = -2; u < N; u++) {
				bool match = true;
				for (int i = 0; i < kTileSize; ++i) {
					const int tileV = v + kTileDY[i];
					const int tileU = u + kTileDX[i];
					if (tile[i] != 0 && (tileV < 0 || tileV >= N || tileU < 0 || tileU >= N || currentBoard[tileV][tileU] != 0)) {
						match = false;
						break;
					}
				}
				if (match) {
					int matchId = numMatches;
					currentMatches[matchId] = (t << 16) | ((v + 2) << 8) | (u + 2);
					matchToPointList[matchId].clear();
					for (int i = 0; i < kTileSize; ++i) {
						if (tile[i] != 0) {
							const int tileV = v + kTileDY[i];
							const int tileU = u + kTileDX[i];
							pointToMatchList[tileV][tileU].insert(matchId);
							matchToPointList[matchId].push_back(tileV * 256 + tileU);
						}
					}

					numMatches++;
				}
			}
		}
	}
}

void CalculateLineDistributions(State& state);
void ScoreState(State& state);

int fsMatchId = 0, fsMatchScore = 0;

void FindMatchSetForPoints(std::vector<int>& points, int startIndex, int usedTileMask, unordered_set<int>& matches, unordered_set<int>& matchedPoints) {
	// Find a set of matches that all points are covered and matches do not intersect.
	if (startIndex == points.size()) {
		// Applying the list of moves in 'matches' (which covers points 'matchedPoints') results in some row / column getting cleared.
		// Calculate the score (per-step) for this action.
		std::vector<int> matchesSorted(matches.begin(), matches.end());
		std::sort(matchesSorted.begin(), matchesSorted.end());
		do {
			State state;
			memcpy(state.board, currentBoard, 24 * 32);
			CalculateLineDistributions(state);

			int firstMatchId = -1, numMatches = 0;
			for (const int matchId : matchesSorted) {
				numMatches++;
				if (firstMatchId < 0) firstMatchId = matchId;

				const int matchMask = currentMatches[matchId];
				const int tileId = matchMask >> 16;

				const char* tile = currentTiles[tileId];
				const int v = ((matchMask >> 8) & 255) - 2;
				const int u = (matchMask & 255) - 2;

				// Verify that the match is still a match.
				bool match = true;
				for (int i = 0; i < kTileSize; ++i) {
					const int tileV = v + kTileDY[i];
					const int tileU = u + kTileDX[i];
					if (tile[i] != 0 && state.board[tileV][tileU] != 0) {
						match = false;
						break;
					}
				}
				if (!match) {
					DEBUG("!!!ERROR!!! Match is not a match.\n");
					return;
				}

				for (int i = 0; i < kTileSize; ++i) {
					const int tileV = v + kTileDY[i];
					const int tileU = u + kTileDX[i];
					if (tile[i]) {
						state.board[tileV][tileU] = tile[i];
						state.distC[tileV][7] = std::max(state.distC[tileV][7], ++state.distC[tileV][tile[i]]);
						state.distC[N + tileU][7] = std::max(state.distC[N + tileU][7], ++state.distC[N + tileU][tile[i]]);
						state.distC[tileV][0]--;
						state.distC[N + tileU][0]--;
					}
				}
				ScoreState(state);

				if (state.realScore > 0) {
					int avgScore = state.realScore / numMatches;
					if (avgScore > fsMatchScore) {
						fsMatchScore = avgScore;
						fsMatchId = firstMatchId;
					}
					break;
				}
			}
		} while (next_permutation(matchesSorted.begin(), matchesSorted.end()));
		return;
	}

	int v = points[startIndex] >> 8;
	int u = points[startIndex] & 255;
	for (const int matchId : pointToMatchList[v][u]) {
		if (matches.find(matchId) == matches.end()) {
			// This match is not yet part of the selected set.

			// Check if this match is not using a tile already used previously.
			int tileId = currentMatches[matchId] >> 16;
			if (usedTileMask & (1 << tileId)) continue;

			// Check if this new match does not conflict with any of the other matches.
			bool conflict = false;
			for (const int point : matchToPointList[matchId]) {
				if (matchedPoints.find(point) != matchedPoints.end()) {
					conflict = true;
					break;
				}
			}
			if (conflict) continue;

			matches.insert(matchId);
			for (const int point : matchToPointList[matchId]) {
				matchedPoints.insert(point);
			}

			FindMatchSetForPoints(points, startIndex + 1, usedTileMask | (1 << tileId), matches, matchedPoints);

			matches.erase(matchId);
			for (const int point : matchToPointList[matchId]) {
				matchedPoints.erase(point);
			}
		}
	}
}

// Find a set of moves that could ensure that a given row or column is fully covered.
// Due to time constraints, this search is only executed if a row / column has at most
// 6 missing entries.
void FindMatchSetForBoard() {
	fsMatchId = -1;
	fsMatchScore = 0;

	// Check if there is any set of matches to complete a given row (or column).
	for (int v = 0; v < N; ++v) {
		std::vector<int> missingPoints;
		for (int u = 0; u < N; ++u) {
			if (currentBoard[v][u] == 0) missingPoints.push_back(v * 256 + u);
		}

		if (missingPoints.size() > 6) {
			continue;
		}

		unordered_set<int> matches, matchedPoints;
		FindMatchSetForPoints(missingPoints, 0, 0, matches, matchedPoints);
	}

	for (int u = 0; u < N; ++u) {
		std::vector<int> missingPoints;
		for (int v = 0; v < N; ++v) {
			if (currentBoard[v][u] == 0) missingPoints.push_back(v * 256 + u);
		}

		if (missingPoints.size() > 6) {
			continue;
		}

		unordered_set<int> matches, matchedPoints;
		FindMatchSetForPoints(missingPoints, 0, 0, matches, matchedPoints);
	}
}


// Calculate color distribution for all rows and columns. The results are written to the distC
// global variable, distC[0] .. distC[N - 1] correspond to rows, distC[N] .. distC[2 * N - 1] to columns;
// Distributions are sorted.
void CalculateLineDistributions(State& state) {
	memset(state.distC, 0, 2 * N * 8);

	for (int v = 0; v < N; ++v) {
		for (int u = 0; u < N; ++u) {
			const int boardVal = state.board[v][u];
			state.distC[v][boardVal]++;
			state.distC[N + u][boardVal]++;
		}
	}

	for (int i = 0; i < 2 * N; ++i) {
		state.distC[i][7] = state.distC[i][1];
		for (int c = 2; c <= C; ++c) {
			state.distC[i][7] = std::max(state.distC[i][7], state.distC[i][c]);
		}
	}
}

int ScoreFromFruitDistribution(const char* distC) {
	return ((int)distC[7]) * ((int)distC[7]);
	//int z = N - distC[0];
	//return z * distC[7];
}

// Checks if some rows / columns are complete in the current state and need clearing.
pair<int, int> ScoreCurrentClearing(const State& state) {
	int completedNum = 0, completedScore = 0;
	for (int i = 0; i < 2 * N; ++i) {
		if (state.distC[i][0] == 0) {
			completedNum++;
			completedScore += ((int) state.distC[i][7]) * ((int) state.distC[i][7]);
		}
	}

	return { completedNum, completedNum * completedScore };
}

// Calculate how many different tiles could be placed somewhere.
// This scoring might be good at the beginning until board starts to get full.
int ScoreFeasibility(const State& state) {
	int totalFeasability = 0;
	for (int v = 0; v < N - 2; v++) {
		for (int u = 0; u < N - 2; u++) {
			int numEmpty = 0;
			for (int i = 0; i < kTileSize; ++i) {
				if (state.board[v + kTileDY[i]][u + kTileDX[i]] == 0) numEmpty++;
			}
			//totalFeasability += (numEmpty == kTileSize);
			totalFeasability += (1 << numEmpty) - 1;
		}
	}

	return totalFeasability;
}

// Score isolated empty positions.
int ScoreIsolatedPenalty(const State& state) {
	int penalty = 0;
	for (int v = 0; v < N; v++) {
		for (int u = 0; u < N; u++) {
			int blockedNeighbor = (v == 0 || state.board[v - 1][u] != 0) + (v == N - 1 || state.board[v + 1][u] != 0) +
				(u == 0 || state.board[v][u - 1] != 0) + (u == N - 1 || state.board[v][u + 1] != 0);
			if (state.board[v][u] == 0) penalty += 16 - blockedNeighbor * blockedNeighbor;
		}
	}
	return penalty;
}

int bfsR, bfsW;
char bfsVisited[32][32];
int bfsQueue[1024];

int ScoreComponents(const State& state) {
	for (int v = 0; v < N; ++v) {
		for (int u = 0; u < N; ++u) {
			bfsVisited[v][u] = 0;
		}
	}
	int numComponents = 0;
	for (int v = 0; v < N; ++v) {
		for (int u = 0; u < N; ++u) {
			if (state.board[v][u] == 0 && !bfsVisited[v][u]) {
				numComponents++;
				bfsVisited[v][u] = 1;
				bfsQueue[0] = v * 256 + u;
				bfsR = 0;
				bfsW = 1;
				while (bfsR < bfsW) {
					const int pos = bfsQueue[bfsR++];
					const int v = pos / 256;
					const int u = pos % 256;
					for (int d = 0; d < 4; ++d) {
						const int nv = v + kDeltaY[d];
						const int nu = u + kDeltaX[d];
						if (nv < 0 || nv >= N || nu < 0 || nu >= N) continue;
						const int npos = nv * 256 + nu;
						if (bfsVisited[npos]) continue;
						bfsVisited[nv][nu] = 1;
						bfsQueue[bfsW++] = npos;
					}
				}
			}
		}
	}
	return numComponents;
}

// Score horizontal / vertical lines by uniformity of colors, 
int ScoreLines(const State& state) {
	int totalScore = 0;

	if (kPenalizeFragmentedEmpty) {
		for (int v = 0; v < N; v++) {
			int numCont = 0;
			for (int u = 1; u < N; u++) {
				if (state.board[v][u] == 0 && state.board[v][u - 1] != 0) numCont++;
			}
			totalScore += ScoreFromFruitDistribution(state.distC[v]) / (numCont + 1);
		}

		for (int u = 0; u < N; u++) {
			int numCont = 0;
			for (int v = 1; v < N; v++) {
				if (state.board[v][u] == 0 && state.board[v - 1][u] != 0) numCont++;
			}
			totalScore += ScoreFromFruitDistribution(state.distC[N + u]) / (numCont + 1);
		}
	}
	else {
		for (int i = 0; i < 2 * N; ++i) {
			totalScore += ScoreFromFruitDistribution(state.distC[i]);
		}
	}

	return totalScore;
}

// Calculate all scores for a given state.
void ScoreState(State& state) {
	state.realScore = 0;
	state.score = 0;

	int totalEmpty = 0;
	for (int i = 0; i < N; ++i) {
		totalEmpty += state.distC[i][0];
	}
	state.fillFactor = 1.0 - (totalEmpty * OnePerSqrN);

	auto clearingScore = ScoreCurrentClearing(state);
	if (clearingScore.first > 0) {
		state.realScore = clearingScore.second;
	}
	else {
		auto lineScore = ScoreLines(state);
		//auto lineScore = ScoreFeasibility(state);
		state.score = lineScore;
	}
}

// Simulate multiple moves in sequence (when available).
void Simulate() {
	State baseState;
	memcpy(baseState.board, currentBoard, 24 * 32);
	baseState.usedTileMask = 0;
	baseState.usedMatchIds = 0;
	baseState.simDepth = 0;
	baseState.matchMask = -1;
	baseState.prevStateId = -1;
	CalculateLineDistributions(baseState);
	ScoreState(baseState);
	int baseScore = baseState.score;
	//DEBUG("Fill Factor [%d] = %.4lf\n", moveCount, allStates[0].fillFactor);

	// Start with the actual current board and set of tiles as a single state.
	numStates = 1;
	allStates[0] = std::move(baseState);
	numCurrStates = 1;
	currStateIds[0] = 0;

	// A real score of $key is reached in simulation step $value. This is used to make sure that
	// for every possible clearing sequence we only keep the shortest path.
	unordered_map<int, int> endScoreDepth;
	unordered_set<long long> visitedStates;

	int simDepth = 1;
	while (true) {
		numNextStates = 0;
		std::map<int, std::vector<int>> posByScore;
		int countMinScore = 0;
		for (int stateIndex = 0; stateIndex < numCurrStates; ++stateIndex) {
			// This is the starting state for this simulation step.
			const int stateId = currStateIds[stateIndex];
			const auto& state = allStates[stateId];

			// Go over the precalculated matchings, verify if a match is still a match.
			for (int matchId = 0; matchId < numMatches; ++matchId) {
				// Check if the precalculated match uses a tile we already used in a previous step, if yes, ignore.
				const int matchMask = currentMatches[matchId];
				const int tileId = matchMask >> 16;
				if (state.usedTileMask & (1 << tileId)) continue;

				// Construct the sorted matchId sequence for this state to prevent duplicate states with two different
				// paths (e.g. [tile X followed by tile Y] vs [tile Y followed by tile X], which are identical.
				short usedMatches[5] = { 0, 0, 0, 0, 0 };
				usedMatches[0] = (state.usedMatchIds >> 0) & 4095;
				usedMatches[1] = (state.usedMatchIds >> 12) & 4095;
				usedMatches[2] = (state.usedMatchIds >> 24) & 4095;
				usedMatches[3] = (state.usedMatchIds >> 36) & 4095;
				usedMatches[4] = matchId + 1;
				std::sort(usedMatches, usedMatches + 5);
				long long usedMatchIds = (((long long)usedMatches[0]) << 48) |
					(((long long)usedMatches[1]) << 36) |
					(((long long)usedMatches[2]) << 24) |
					(((long long)usedMatches[3]) << 12) |
					(((long long)usedMatches[4]) << 0);
				if (visitedStates.find(usedMatchIds) != visitedStates.end()) {
					continue;
				}
				visitedStates.insert(usedMatchIds);

				const char* tile = currentTiles[tileId];
				const int v = ((matchMask >> 8) & 255) - 2;
				const int u = (matchMask & 255) - 2;

				// Verify that the match is still a match.
				bool match = true;
				for (int i = 0; i < kTileSize; ++i) {
					const int tileV = v + kTileDY[i];
					const int tileU = u + kTileDX[i];
					if (tile[i] != 0 && state.board[tileV][tileU] != 0) {
						match = false;
						break;
					}
				}
				if (!match) continue;

				State newState = state;
				for (int i = 0; i < kTileSize; ++i) {
					const int tileV = v + kTileDY[i];
					const int tileU = u + kTileDX[i];
					if (tile[i]) {
						newState.board[tileV][tileU] = tile[i];
						newState.distC[tileV][7] = std::max(newState.distC[tileV][7], ++newState.distC[tileV][tile[i]]);
						newState.distC[N + tileU][7] = std::max(newState.distC[N + tileU][7], ++newState.distC[N + tileU][tile[i]]);
						newState.distC[tileV][0]--;
						newState.distC[N + tileU][0]--;
					}
				}
				newState.usedTileMask |= (1 << tileId);
				newState.simDepth = simDepth;
				newState.prevStateId = stateId;
				newState.matchMask = matchMask;
				newState.usedMatchIds = usedMatchIds;
				ScoreState(newState);

				// Check if the new state is an end state (line clearing happens)
				if (newState.realScore > 0) {
					if (endScoreDepth.find(newState.realScore) != endScoreDepth.end() && endScoreDepth[newState.realScore] <= simDepth) {
						// We already have an equal point gain in less step, this path can be discarded.
					}
					else {
						// We have a path to a point gain, keep this state, but do not explore further paths from it
						endScoreDepth[newState.realScore] = simDepth;
						allStates[numStates] = std::move(newState);
						numStates++;
					}

					// We do not pursue states which already lead to clearing
					continue;
				}

				// Decide whether to keep the new state based on the score.
				int targetPosition = -1;
				if (numNextStates < currentBeamWidth) {
					targetPosition = numNextStates;
					numNextStates++;
				}
				else {
					const auto& worstState = posByScore.begin();
					if (newState.score > worstState->first || (newState.score == worstState->first && randEngine() % (countMinScore + 1) == 0)) {
						targetPosition = worstState->second.back();
						if (worstState->second.size() == 1) {
							posByScore.erase(worstState->first);
						}
						else {
							worstState->second.pop_back();
						}
					}
				}

				if (targetPosition >= 0) {
					//DEBUG("Simulation [%d]: %d => %d (%d, %d, %d)\n", moveCount, baseScore, newState.score, tileId, v, u);
					if (posByScore.empty() || newState.score < posByScore.begin()->first) {
						countMinScore = 0;
					}
					posByScore[newState.score].push_back(targetPosition);
					if (posByScore.begin()->first == newState.score) {
						countMinScore++;
					}
					allStates[numStates] = std::move(newState);
					nextStateIds[targetPosition] = numStates;
					numStates++;
				}
			}
		}

		// No more matches or unused tiles
		if (numNextStates == 0) break;

		numCurrStates = numNextStates;
		for (int i = 0; i < numCurrStates; ++i) {
			currStateIds[i] = nextStateIds[i];
		}
		simDepth++;
	}
	fflush(fDebug);

	// Check if there is any simulation results which lead to point gain, take that, otherwise take the best scoring first step for now.
	nextTileId = randEngine() % T;
	nextTilePos = -1;
	int bestRealScore = 0, bestScore = 0;
	for (int i = 1; i < numStates; ++i) {
		const auto& state = allStates[i];
		bool doUpdate = false;

		if ((state.fillFactor > kMinFillFactorForPoint || simDepth <= T || state.realScore > 2 * N * N) && state.realScore > 0) {
			if (state.realScore / state.simDepth > bestRealScore) {
				bestRealScore = state.realScore / state.simDepth;
				doUpdate = true;
			}
		}
		else if (state.simDepth >= 1) {
			if (state.score > bestScore && bestRealScore == 0 && randProb(randEngine) > 0.05) {
				// This state is better than the best so far and there is no path to actual point gain.
				bestScore = state.score;
				doUpdate = true;
			}
		}

		if (doUpdate) {
			// We aim to arrive in this state, trace back what was the first placement to get here.
			int stateId = i;
			while (allStates[stateId].prevStateId != 0) {
				stateId = allStates[stateId].prevStateId;
			}
			nextTileId = allStates[stateId].matchMask >> 16;
			nextTilePos = allStates[stateId].matchMask & 65535;
		}
	}
}

// Display the test case summary to stderr for debugging.
void WriteSummary() {
	FetchTime(&tCurrent);
	DEBUG("Seed = %d, Score = %d, Moves = %d\n", dbgSeed, totalScore, moveCount);
	DEBUG("DATA_HEADER,Seed,N,T,C,F,P,Score,Moves,Runtime\n");
	DEBUG("DATA_EXPORT,%d,%d,%d,%d,%.4lf,%.4lf,%d,%d,%.2lf\n", dbgSeed, N, T, C, F, P, totalScore,
		moveCount, 0.001 * GetElapsedMicros(tBegin, tCurrent));
	fflush(fDebug);
}

// Sends one tile placement to the tester and receives the new tile.
void SendMove() {
	//DEBUG("Before Move %d:\n", moveCount);
	//Debug_ShowBoard();

	// Do the tile placement and calculate score update before sending the move.
	const int tileStartV = nextTilePos / 256 - 2;
	const int tileStartU = nextTilePos % 256 - 2;
	if (nextTilePos >= 0) {
		// Place the tile on the board with verification.
		const char* tile = currentTiles[nextTileId];
		for (int i = 0; i < kTileSize; ++i) {
			const int tileV = tileStartV + kTileDY[i];
			const int tileU = tileStartU + kTileDX[i];
			if (tile[i] != 0 && (tileV < 0 || tileV >= N || tileU < 0 || tileU >= N || currentBoard[tileV][tileU] != 0)) {
				DEBUG("!!!ERROR!!! Incorrect tile placement, Move = %d, Tile = %d, Index = %d, Pos = (%d, %d), Contents: %d (tile) vs %d (board)\n",
					moveCount, nextTileId, i, tileV, tileU, (int)tile[i], (int)currentBoard[tileV][tileU]);
				continue;
			}
			if (tile[i] != 0) {
				currentBoard[tileV][tileU] = tile[i];
			}
		}

		// Collect full rows / columns, calculate score. ROW => index, COLUMN => 256 + index
		unordered_set<int> fullLine;
		unordered_map<int, unordered_map<char, int>> lineCounts;
		for (int v = 0; v < N; ++v) {
			int nonEmpty = 0;
			for (int u = 0; u < N; ++u) {
				if (currentBoard[v][u] != 0) {
					nonEmpty++;
					lineCounts[v][currentBoard[v][u]]++;
				}
			}
			if (nonEmpty == N) fullLine.insert(v);
		}
		for (int u = 0; u < N; ++u) {
			int nonEmpty = 0;
			for (int v = 0; v < N; ++v) {
				if (currentBoard[v][u] != 0) {
					nonEmpty++;
					lineCounts[u + 256][currentBoard[v][u]]++;
				}
			}
			if (nonEmpty == N) fullLine.insert(u + 256);
		}

		const int numFull = (int) fullLine.size();
		int roundScore = 0;
		if (numFull != 0) {
			for (const int lineId : fullLine) {
				int maxCount = 0;
				for (const auto& lineCount : lineCounts[lineId]) {
					maxCount = std::max(maxCount, lineCount.second);
				}
				roundScore += numFull * maxCount * maxCount;

				if (lineId < 256) {
					const int v = lineId;
					for (int u = 0; u < N; ++u) {
						currentBoard[v][u] = 0;
					}
				}
				else {
					const int u = lineId - 256;
					for (int v = 0; v < N; ++v) {
						currentBoard[v][u] = 0;
					}
				}
			}

			//DEBUG("Clearing [%d]: %d / %d\n", moveCount, numFull, roundScore);
		}
		totalScore += roundScore;
	}

	//DEBUG("After Move %d:\n", moveCount);
	//Debug_ShowBoard();

	if (moveCount == 1000) {
		WriteSummary();
	}

	// Send the lights to be switched and also update the light state.
	std::cout << nextTileId;
	if (nextTilePos >= 0) {
		std::cout << " " << tileStartV << " " << tileStartU;
	}
	std::cout << std::endl;
	std::cout.flush();

	// Read the replacement tile from the test.
	std::string newTile;
	cin >> newTile;
	char tileColor = 0, tileSize = 0;
	for (int i = 0; i < kTileSize; ++i) {
		currentTiles[nextTileId][i] = newTile[i] - '0';
		if (newTile[i] != '0') {
			tileColor = newTile[i] - '0';
			tileSize++;
		}
	}
	currentTiles[nextTileId][14] = tileSize;
	currentTiles[nextTileId][15] = tileColor;

	// Read elapsed time (unused).
	int unused_time_ms;
	cin >> unused_time_ms;
}

// MAIN SOLVER BEGINS HERE.

void BlockGame::findSolution(int aN, int aT, int aC, double aF, double aP, const std::vector<std::string>& aBoard, const std::vector<std::string>& aTiles) {
	// Initalize timing, randomness.
	InitTimer();
	FetchTime(&tBegin);
	randEngine.seed(0xdeadbeef);

	// Save input.
	N = aN;
	OnePerSqrN = 1.0 / (N * N);
	T = aT;
	C = aC;
	F = aF;
	P = aP;
	for (int v = 0; v < N; ++v) {
		for (int u = 0; u < N; ++u) {
			currentBoard[v][u] = aBoard[v][u] - '0';
		}
	}
	for (int t = 0; t < aT; ++t) {
		char tileColor = 0, tileSize = 0;
		for (int i = 0; i < kTileSize; ++i) {
			currentTiles[t][i] = aTiles[t][i] - '0';
			if (aTiles[t][i] != '0') {
				tileColor = aTiles[t][i] - '0';
				tileSize++;
			}
		}
		currentTiles[t][14] = tileSize;
		currentTiles[t][15] = tileColor;
	}

	if (P < 0.4) {
		kMinFillFactorForPoint = 0.7;
	}
	else {
		kMinFillFactorForPoint = 0.9 - P;
	}
	

	FetchTime(&tInit);
	DEBUG("Initialization time: %.3lf us.\n", GetElapsedMicros(tBegin, tInit));

	// SOLVE PROBLEM.
	moveCount = 0;
	totalScore = 0;

	while (moveCount < kMaxMoves) {
		moveCount++;
		//DEBUG("======== TURN %d ==========\n", moveCount);

		const double targetTime = GetTargetEndMicros();
		FetchTime(&tCurrent);
		const double realTime = GetElapsedMicros(tBegin, tCurrent);
		if (realTime < targetTime && currentBeamWidth < kMaxStates) {
			currentBeamWidth *= 2;
		}
		else if (realTime > targetTime && currentBeamWidth > kMinStates) {
			currentBeamWidth /= 2;
		}

		// Calculate all tile matches on the current board, this set of matches will
		// be used for the entirety of the move.
		CalculateMatches();
		if (kRandomShuffleMatches) {
			std::shuffle(currentMatches, currentMatches + numMatches, randEngine);
		}

		// Find set of moves that can guarantee a line to be cleared, but only exercise it,
		// when the gain is very large.
		fsMatchScore = 0;
		if (currentBeamWidth > kMinStates) {
			FindMatchSetForBoard();
		}
		if (fsMatchScore > kSkipSimulationScoreThreshold * N * N) {
			nextTileId = currentMatches[fsMatchId] >> 16;
			nextTilePos = currentMatches[fsMatchId] & 65535;
		}
		else {
			// Simulate at most as many tiles as we already know, try to find either a path to an
			// actual point gain or just pick the best possible outcome based on some score.
			Simulate();
		}

		// Send the chosen move to the tester, get back the new tile.
		SendMove();

		FetchTime(&tCurrent);
		//DEBUG("Move [%d], Beam = %d, Score = %d, Time = %d ms\n", moveCount, currentBeamWidth, totalScore, (int) (GetElapsedMicros(tBegin, tCurrent) * 0.001));
	}
}

// Tester wrapper.
int main(int argc, char* argv[]) {
	dbgHasExtraInput = false;

#ifdef TC_DEBUG
	for (int i = 1; i < argc; ++i) {
		if (!strncmp(argv[i], "-s=", 3)) {
			dbgSeed = atoi(argv[i] + 3);
		}
		else if (!strncmp(argv[i], "-o=", 3)) {
			fDebug = fopen(argv[i] + 3, "wt");
		}
		else if (!strncmp(argv[i], "-t=", 3)) {
			fTracking = fopen(argv[i] + 3, "wt");
		}
		else if (!strncmp(argv[i], "-d", 2)) {
			dbgHasExtraInput = true;
		}
	}
	fprintf(fDebug, "=========== SEED: %d ===========\n", dbgSeed);
#endif

	int genN, genT, genC;
	double genF, genP;
	std::cin >> genN;
	std::cin >> genT;
	std::cin >> genC;
	std::cin >> genF;
	std::cin >> genP;

	std::vector<std::string> genBoard(genN);
	for (int v = 0; v < genN; ++v) {
		for (int u = 0; u < genN; ++u) {
			std::cin >> sTmp[u];
		}
		sTmp[genN] = '\0';
		genBoard[v] = sTmp;
	}

	std::vector<std::string> genTiles(genT);
	for (int t = 0; t < genT; ++t) {
		std::cin >> genTiles[t];
		if (genTiles[t].length() != kTileSize) {
			DEBUG("!!!ERROR!!! Incorrect tile size in input: %d\n", (int) genTiles[t].length());
		}
	}

	BlockGame solver;
	solver.findSolution(genN, genT, genC, genF, genP, genBoard, genTiles);

	if (fDebug != stderr) {
		fflush(fDebug);
		fclose(fDebug);
	}

	if (fTracking != nullptr) {
		fflush(fTracking);
		fclose(fTracking);
	}

	return 0;
}
