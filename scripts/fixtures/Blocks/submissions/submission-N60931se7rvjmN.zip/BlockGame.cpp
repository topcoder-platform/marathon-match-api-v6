// C++11
#include <bits/stdc++.h>
#include <sys/time.h>

#ifdef LOCAL
#include "../logger.hpp"
// #include "../TCClient.hpp"
#define LOG_TC(...) LOG_INFO(__VA_ARGS__);
void Initialize(int, char**);
#else
void Initialize(int /*argc*/, char** /*argv*/) {}
#define SHOW(...);
#define LOG_DEBUG(...);
#define LOG_INFO(...);
#define LOG_WARNING(...);
#define LOG_ERROR(...);
#define LOG_TC(...) {fprintf(stderr, __VA_ARGS__);fprintf(stderr, "\n"); }
#define PANIC(...);
#define ASSERT(...);
#endif

#ifdef USEPROFILER
#include "../Profiler.hpp"
#else
#define PROFILER_VAR(var, name);
#define PROFILER(name);
#endif

static inline double get_time() {
  timeval tv;
  gettimeofday(&tv, 0);
  return tv.tv_sec + tv.tv_usec * 1e-6;
}

// Need calibration
static inline double get_fast_time() {
  unsigned long long timelo, timehi;
  __asm__ volatile("rdtsc" : "=a"(timelo), "=d"(timehi));
  return ((timehi << 32) + timelo) * 3.5714286e-10;
}

const double END_TIME = 4.9;
double start_time = get_time();
double end_time = start_time + END_TIME;

struct rand_gen {
  static constexpr uint32_t kMax = 2147483647;
  static constexpr double kInvMax = 1.0 / (double)kMax;
  static constexpr __uint128_t kAdd = 0x60bee2bee120fc15ull;
  static constexpr __uint128_t kMul1 = 0xa3b195354a39b70dull;
  static constexpr __uint128_t kMul2 = 0x1b03738712fad5c9ull;
  uint64_t state = 142857; //get_fast_time() * 1000000;
  inline void seed(uint64_t seed) { state = seed; }
  inline uint32_t next_int() {
    state += kAdd; __uint128_t tmp = (__uint128_t)state * kMul1;
    uint64_t m1 = (tmp >> 64) ^ tmp; tmp = (__uint128_t)m1 * kMul2;
    uint64_t m2 = (tmp >> 64) ^ tmp; return (uint32_t)m2;
  }
  inline uint32_t next_int(uint32_t max) { return next_int()%max; }
  inline uint32_t next_int(uint32_t min, uint32_t max) { return min + (next_int()%(max-min)); }
  inline double next_float() { return next_int(kMax) * kInvMax; }
  template <class T>
  inline T select(std::vector<T>& vec) { return vec[next_int(vec.size())]; }
} rng;

class FastMap { public:
  FastMap(){size_ = 0;}
  FastMap(int size){size_ = 0;resize(size);}
  void resize(int size) { pos_.resize(size, -1); taken_.resize(size);}
  void clear() { while (size_) { pos_[taken_[--size_]] = -1; }}
  inline void safeInsert(int v) { if (has(v)) return; insert(v);}
  inline void insert(int v) { taken_[pos_[v] = size_++] = v; }
  inline void push_back(int v) { taken_[pos_[v] = size_++] = v; }
  inline void pop_back() { pos_[taken_[--size_]] = -1; }
  inline int back() { return taken_[size_-1]; }
  inline void erase(int v) {
    const int p = pos_[v];
    const int last = taken_[--size_];
    pos_[last] = p;
    taken_[p] = last;
    pos_[v] = -1;
  }
  inline int operator[](int i) { return taken_[i]; }
  inline void safeErase(int v) { if (has(v)) erase(v); }
  inline bool has(int v) { return pos_[v] >= 0; }
  std::vector<int> toVector() {
    std::vector<int> ret;
    ret.insert(ret.begin(), begin(), end());
    return ret;
  }
  inline int size() { return size_; }
  inline bool empty() { return size_ == 0; }
  inline int* begin() { return taken_.data(); }
  inline int* end() { return taken_.data() + size_; }

 private:
  std::vector<int> pos_;
  std::vector<int> taken_;
  int size_;
};

int N, T, C;
double F, P;
int elapsedTime;

int Rows[12][32];
int Cols[12][32];
int Grid[32][32];
int* Grid1d = &Grid[0][0];

int CRows[12][32];
int CCols[12][32];
int CGrid[32][32];

int Score;

struct Tile {
  int p[3][3];
  int color;
  bool row[3];
  bool col[3];
  std::vector<std::pair<int, int>> pos;
  std::vector<int> pp;
};
struct Move {
  int tile, row, col;
};

Tile Tiles[16];
Tile TilesR[8096];
int turn;

inline bool ValidMove(int tile, int row, int col) {
  // PROFILER("ValidMove");
  auto& tt = Tiles[tile];
  const int idx = row*32 + col;
  switch (tt.pos.size()) {
    case 9:  if (Grid1d[idx+tt.pp[8]]) return false;
    case 8:  if (Grid1d[idx+tt.pp[7]]) return false;
    case 7:  if (Grid1d[idx+tt.pp[6]]) return false;
    case 6:  if (Grid1d[idx+tt.pp[5]]) return false;
    case 5:  if (Grid1d[idx+tt.pp[4]]) return false;
    case 4:  if (Grid1d[idx+tt.pp[3]]) return false;
    case 3:  if (Grid1d[idx+tt.pp[2]]) return false;
    case 2:  if (Grid1d[idx+tt.pp[1]]) return false;
    case 1:  if (Grid1d[idx+tt.pp[0]]) return false;
  }
  // for (auto& p : tt.pos) {
  //   if (Grid[row+p.first][col+p.second]) return false;
  // }
  return true;
}

void Save() {
  PROFILER("Save");
  std::copy(&Grid[0][0], &Grid[32][0], &CGrid[0][0]);
  std::copy(&Rows[0][0], &Rows[12][0], &CRows[0][0]);
  std::copy(&Cols[0][0], &Cols[12][0], &CCols[0][0]);
  // for (int c = 0; c <= C; c++) {
  //   std::copy(&Rows[c][2], &Rows[c][N+2], &CRows[c][2]);
  //   std::copy(&Cols[c][2], &Cols[c][N+2], &CCols[c][2]);
  // }
}

void Reset() {
  PROFILER("Reset");
  std::copy(&CGrid[0][0], &CGrid[32][0], &Grid[0][0]);
  std::copy(&CRows[0][0], &CRows[12][0], &Rows[0][0]);
  std::copy(&CCols[0][0], &CCols[12][0], &Cols[0][0]);
  // std::copy(&CGrid[2][0], &CGrid[N+2][0], &Grid[2][0]);
  // for (int c = 0; c <= C; c++) {
  //   std::copy(&CRows[c][2], &CRows[c][N+2], &Rows[c][2]);
  //   std::copy(&CCols[c][2], &CCols[c][N+2], &Cols[c][2]);
  // }
}


double Coverable[32][32];
double PP[32];
double PP2[10];
int Pa[10][10];
double Occ[512];
std::vector<int> Links[512];
void InitProba() {
  for (int i = 0; i < 10; i++) {
    Pa[i][0] = 1;
    for (int j = 1; j <= i; j++) {
      Pa[i][j] = Pa[i-1][j-1] + Pa[i-1][j];
    }
  }
  Occ[0] = std::pow(1.0 - P, 9);
  for (int i = 1; i < 512; i++) {
    // for (int j = 1; j < i; j++) if (((i^j) & ((i^j)-1)) == 0) Links[i].push_back(j);
    for (int j = 1; j < i; j++) if((i|j) == i) Links[i].push_back(j);
    int t = __builtin_popcount(i);
    Occ[i] = std::pow(1.0 - P, 9-t) * std::pow(P, t) / (1.0 - Occ[0]);
    // LOG_DEBUG("%d -> %lf (%d)", i, Occ[i], Links[i].size());
  }
  for (int i = 1; i < 512; i++) {
    for (int j : Links[i]) Occ[j] += Occ[i];
  }
  PP[25] = 1.0;
  for (int i = 24; i > 0; i--) PP[i] = PP[i+1] * std::pow(1.0 - P, 0.25);
}

int CanPlace[512];
double ComputeCover() {
  PROFILER("ComputeCover");
  double sc = 0;
  // for (int i = 1; i < 512; i++) CanPlace[i] = 0.0;
  {
    PROFILER("Gather");
    for (int row = 2; row < N; row++) {
      for (int col = 2; col < N; col++) {
        const int idx = row * 32 + col;
        if (Grid1d[idx]) {
          sc += 1.0;
          continue;
        }
        int cc = 0;
        for (int r = -2; r <= 2; r++) {
          for (int c = -2; c <= 2; c++) {
            if (Grid[row+r][col+c] == 0) cc++;
          }
        }
        sc += PP[cc];
      }
    }
  }
    // for (int row = 2; row < N; row++) {
    //   for (int col = 2; col < N; col++) {
    //     const int idx = row * 32 + col;
    //     int id =
    //       (Grid1d[idx     ]==0 ? 256 : 0) |
    //       (Grid1d[idx +  1]==0 ? 128 : 0) |
    //       (Grid1d[idx +  2]==0 ? 64 : 0) |
    //       (Grid1d[idx + 32]==0 ? 32 : 0) |
    //       (Grid1d[idx + 33]==0 ? 16 : 0) |
    //       (Grid1d[idx + 34]==0 ? 8 : 0) |
    //       (Grid1d[idx + 64]==0 ? 4 : 0) |
    //       (Grid1d[idx + 65]==0 ? 2 : 0) |
    //       (Grid1d[idx + 66]==0 ? 1 : 0);
    //     // sc += Occ[id];
    //     if (id == 0) sc += 1.0;
    //     // CanPlace[id]++;
    //   }
    // }
  // {
  //   PROFILER("Propagate");
  //   for (int i = 511; i > 0; i -= 8) {
  //     if (CanPlace[i]) for (int j : Links[i]) CanPlace[j] = 1;
  //     if (CanPlace[i-1]) for (int j : Links[i-1]) CanPlace[j] = 1;
  //     if (CanPlace[i-2]) for (int j : Links[i-2]) CanPlace[j] = 1;
  //     if (CanPlace[i-3]) for (int j : Links[i-3]) CanPlace[j] = 1;
  //     if (CanPlace[i-4]) for (int j : Links[i-4]) CanPlace[j] = 1;
  //     if (CanPlace[i-5]) for (int j : Links[i-5]) CanPlace[j] = 1;
  //     if (CanPlace[i-6]) for (int j : Links[i-6]) CanPlace[j] = 1;
  //     if (CanPlace[i-7]) for (int j : Links[i-7]) CanPlace[j] = 1;
  //   }
  // }
  // for (int i = 1; i < 512; i++) {
  //   sc += CanPlace[i] ? Occ[i] : 0.0;
  // }
  // LOG_DEBUG("%lf", sc);
  return sc * 1000.0;
}

int PCost[32];
int PCost2[32];

int Heuristic() {
  // if (C == 1) return 1 + ComputeCover();
  // PROFILER("Heuristic");
  int sc = 0;
  for (int i = 2; i <= N+1; i++) {
    int mr = 0;
    int mc = 0;
    switch (C) {
      case 5: sc += PCost2[Rows[5][i]] + PCost2[Cols[5][i]]; // mr = std::max(mr, Rows[5][i]); mc = std::max(mc, Cols[5][i]);
      case 4: sc += PCost2[Rows[4][i]] + PCost2[Cols[4][i]]; // mr = std::max(mr, Rows[4][i]); mc = std::max(mc, Cols[4][i]);
      case 3: sc += PCost2[Rows[3][i]] + PCost2[Cols[3][i]]; // mr = std::max(mr, Rows[3][i]); mc = std::max(mc, Cols[3][i]);
      case 2: sc += PCost2[Rows[2][i]] + PCost2[Cols[2][i]]; // mr = std::max(mr, Rows[2][i]); mc = std::max(mc, Cols[2][i]);
      case 1: sc += PCost2[Rows[1][i]] + PCost2[Cols[1][i]]; // mr = std::max(mr, Rows[1][i]); mc = std::max(mc, Cols[1][i]);
    }
    // sc += PCost2[mr + (N - Rows[0][i])] + PCost2[mc + (N - Cols[0][i])];
  }
  return sc;// + ComputeCover();
}

void LoadTile(int id) {
  PROFILER("LoadTile");
  std::string line;
  std::cin >> line;
  Tile& tt = Tiles[id];
  tt.color = 0;
  tt.pos.clear();
  tt.pp.clear();
  tt.row[0] = tt.row[1] = tt.row[2] = false;
  tt.col[0] = tt.col[1] = tt.col[2] = false;
  for (int r=0; r<3; r++) {
    for (int c=0; c<3; c++) {
      tt.p[r][c] = (int)(line[r*3+c]-'0');
      if (tt.p[r][c]) {
        tt.color = tt.p[r][c];
        tt.pos.push_back({r, c});
        tt.pp.push_back(r * 32 + c);
        tt.row[r] = true;
        tt.col[c] = true;
      }
    }
  }
}

void LoadRandomTile(Tile& tt, int color = 9) {
  PROFILER("LoadRandomTile");
  tt.color = color;
  tt.pos.clear();
  tt.pp.clear();
  tt.row[0] = tt.row[1] = tt.row[2] = false;
  tt.col[0] = tt.col[1] = tt.col[2] = false;
  while (tt.pos.empty()) {
    for (int r=0; r<3; r++) {
      for (int c=0; c<3; c++) {
        tt.p[r][c] = rng.next_float() < P ? color : 0;
        if (tt.p[r][c]) {
          tt.pos.push_back({r, c});
          tt.pp.push_back(r * 32 + c);
          tt.row[r] = true;
          tt.col[c] = true;
        }
      }
    }
  }
}

std::vector<int> clears_rows;
std::vector<int> clears_cols;
void PlaceTile(int id, int row, int col) {
  // PROFILER("PlaceTile");
  auto& tt = Tiles[id];
  const int idx = row * 32 + col;
  switch (tt.pp.size()) {
    case 9:  Grid1d[idx+tt.pp[8]] = tt.color;
    case 8:  Grid1d[idx+tt.pp[7]] = tt.color;
    case 7:  Grid1d[idx+tt.pp[6]] = tt.color;
    case 6:  Grid1d[idx+tt.pp[5]] = tt.color;
    case 5:  Grid1d[idx+tt.pp[4]] = tt.color;
    case 4:  Grid1d[idx+tt.pp[3]] = tt.color;
    case 3:  Grid1d[idx+tt.pp[2]] = tt.color;
    case 2:  Grid1d[idx+tt.pp[1]] = tt.color;
    case 1:  Grid1d[idx+tt.pp[0]] = tt.color;
  }
  for (auto& p : tt.pos) {
    // Grid[row + p.first][col + p.second] = tt.color;
    if (++Rows[0][row+p.first] == N) clears_rows.push_back(row + p.first);
    if (++Cols[0][col+p.second] == N) clears_cols.push_back(col + p.second);
    ++Rows[tt.color][row+p.first];
    ++Cols[tt.color][col+p.second];
  }
}

int LimLine = 1;

int HeuristicScore() {
  int tot = clears_rows.size() + clears_cols.size();
  if (tot <= LimLine) return tot;
  // PROFILER("HeuristicScore");
  int sc = 0;
  for (int r : clears_rows) {
    int mm = Rows[1][r];
    for (int i = 2; i <= C; i++) {
      if (mm < Rows[i][r]) mm = Rows[i][r];
    }
    sc += mm * tot;
  }
  for (int c : clears_cols) {
    int mm = Cols[1][c];
    for (int i = 2; i <= C; i++) {
      if (mm < Cols[i][c]) mm = Cols[i][c];
    }
    sc += mm * tot;
  }
  return sc;
}

int RealScore() {
  int tot = clears_rows.size() + clears_cols.size();
  if (tot == 0) return 0;
  PROFILER("RealScore");
  int sc = 0;
  for (int r : clears_rows) {
    int mm = Rows[1][r];
    for (int i = 2; i <= C; i++) {
      if (mm < Rows[i][r]) mm = Rows[i][r];
    }
    sc += mm * mm * tot;
  }
  for (int c : clears_cols) {
    int mm = Cols[1][c];
    for (int i = 2; i <= C; i++) {
      if (mm < Cols[i][c]) mm = Cols[i][c];
    }
    sc += mm * mm * tot;
  }
  return sc;
}

void ClearBoard() {
  PROFILER("ClearBoard");
  for (int r : clears_rows) {
    for (int c = 2; c <= N+1; c++) {
      Cols[0][c]--;
      Cols[Grid[r][c]][c]--;
      Grid[r][c] = 0;
    }
    for (int i = 0; i <= C; i++) Rows[i][r] = 0;
  }
  for (int c : clears_cols) {
    for (int r = 2; r <= N+1; r++) {
      if (Grid[r][c]) {
        Rows[Grid[r][c]][r]--;
        Rows[0][r]--;
        Grid[r][c] = 0;
      }
    }
    for (int i = 0; i <= C; i++) Cols[i][c] = 0;
  }
  clears_rows.clear();
  clears_cols.clear();
}
int RemoveTile(int id, int row, int col) {
  // PROFILER("RemoveTile");
  auto& tt = Tiles[id];
  const int idx = row * 32 + col;
  switch (tt.pp.size()) {
    case 9:  Grid1d[idx+tt.pp[8]] = 0;
    case 8:  Grid1d[idx+tt.pp[7]] = 0;
    case 7:  Grid1d[idx+tt.pp[6]] = 0;
    case 6:  Grid1d[idx+tt.pp[5]] = 0;
    case 5:  Grid1d[idx+tt.pp[4]] = 0;
    case 4:  Grid1d[idx+tt.pp[3]] = 0;
    case 3:  Grid1d[idx+tt.pp[2]] = 0;
    case 2:  Grid1d[idx+tt.pp[1]] = 0;
    case 1:  Grid1d[idx+tt.pp[0]] = 0;
  }
  for (auto& p : tt.pos) {
    --Rows[0][row+p.first];
    --Cols[0][col+p.second];
    --Rows[tt.color][row+p.first];
    --Cols[tt.color][col+p.second];
  }
  clears_rows.clear();
  clears_cols.clear();
}

std::vector<Move> GetMoves(int NT = T) {
  PROFILER("GetMoves");
  std::vector<Move> moves;
  for (int tile = 0; tile < NT; tile++) {
    auto& tt = Tiles[tile];
    // if (tt.color > 1) continue;
    // for (int row = (tt.color-1) * N/2; row < tt.color * N/2; row++) {
    for (int row = 0; row <= N+1; row++) {
      for (int col = 0; col <= N+1; col++) {
        if (ValidMove(tile, row, col)) {
          // LOG_INFO("Add: %d %d %d %zd", tile, row, col, moves.size());
          moves.push_back({tile, row, col});
        }
      }
    }
  }
  return moves;
}

std::pair<int, int> SimulateScore(const Move& move) {
  PROFILER("SimulateScore");
  PlaceTile(move.tile, move.row, move.col);
  int sc = HeuristicScore();
  int hh = Heuristic();
  RemoveTile(move.tile, move.row, move.col);
  return {sc, hh};
}
/*
Move GetRecursiveGreedy(std::vector<Move>& moves, int taken) {
  PROFILER("GetRecursiveGreedy");
  // for (int t = T; t < )
  // for (auto m : moves) {
  //   auto s = SimulateScore(m);
  //   LOG_INFO("%d %d -> %d %d", m.row, m.col, s.first, s.second);
  // }
  // LOG_INFO("Options: %d", moves.size());
  if (moves.empty()) return {-1, -1, -1};
  int depth = 1;
  int Lim = 100000;
  // if (elapsedTime > 2500) Lim /= 2;
  // if (elapsedTime > 5000) Lim /= 2;
  // if (elapsedTime > 7500) Lim /= 2;
  if (elapsedTime > 9000) Lim /= 10;
  while (turn + depth < 1000 && depth < T && std::pow(moves.size() * 1.0, depth+1) <= Lim) depth++;

  int bhh = 0;
  std::vector<int> bids;
  std::vector<int> cc;

  {
    const int idx = moves[taken].row * 32 + moves[taken].col;
    auto& tt = Tiles[moves[taken].tile];
    switch (tt.pp.size()) {
      case 9:  Grid1d[idx+tt.pp[8]] = tt.color;
      case 8:  Grid1d[idx+tt.pp[7]] = tt.color;
      case 7:  Grid1d[idx+tt.pp[6]] = tt.color;
      case 6:  Grid1d[idx+tt.pp[5]] = tt.color;
      case 5:  Grid1d[idx+tt.pp[4]] = tt.color;
      case 4:  Grid1d[idx+tt.pp[3]] = tt.color;
      case 3:  Grid1d[idx+tt.pp[2]] = tt.color;
      case 2:  Grid1d[idx+tt.pp[1]] = tt.color;
      case 1:  Grid1d[idx+tt.pp[0]] = tt.color;
    }
    for (auto& p : tt.pos) {
      ++Rows[tt.color][moves[taken].row+p.first];
      ++Cols[tt.color][moves[taken].col+p.second];
    }
  }

  Save();
  for (int i = 0; i < moves.size(); i++) {
    bool used[6] = {false, false, false, false, false, false};
    used[moves[taken].tile] = true;
    if (used[moves[i].tile]) continue;
    used[moves[i].tile] = true;
    cc.push_back(i);

    auto fct = [&](auto fct, int sc, int ss) {
      if (sc) return;
      int hh = Heuristic();

      if (hh > bhh) {
        bids = cc;
        bhh = hh;
      }
      if (sc) return;
      if (cc.size() == depth) return;
      for (int i = ss; i < moves.size(); i++) {
        if (used[moves[i].tile]) continue;
        if (!ValidMove(moves[i].tile, moves[i].row, moves[i].col)) continue;
        used[moves[i].tile] = true;
        cc.push_back(i);
        PlaceTile(moves[i].tile, moves[i].row, moves[i].col);
        fct(fct, HeuristicScore(), i+1);
        RemoveTile(moves[i].tile, moves[i].row, moves[i].col);
        cc.pop_back();
        used[moves[i].tile] = false;
      }
    };
    PlaceTile(moves[i].tile, moves[i].row, moves[i].col);
    int s = HeuristicScore();
    ClearBoard();
    fct(fct, s, i+1);
    Reset();
    cc.pop_back();
  }
  {
    const int idx = moves[taken].row * 32 + moves[taken].col;
    auto& tt = Tiles[moves[taken].tile];
    switch (tt.pp.size()) {
      case 9:  Grid1d[idx+tt.pp[8]] = 0;
      case 8:  Grid1d[idx+tt.pp[7]] = 0;
      case 7:  Grid1d[idx+tt.pp[6]] = 0;
      case 6:  Grid1d[idx+tt.pp[5]] = 0;
      case 5:  Grid1d[idx+tt.pp[4]] = 0;
      case 4:  Grid1d[idx+tt.pp[3]] = 0;
      case 3:  Grid1d[idx+tt.pp[2]] = 0;
      case 2:  Grid1d[idx+tt.pp[1]] = 0;
      case 1:  Grid1d[idx+tt.pp[0]] = 0;
    }
    for (auto& p : tt.pos) {
      --Rows[tt.color][moves[taken].row+p.first];
      --Cols[tt.color][moves[taken].col+p.second];
    }
  }
  return moves[bids[0]];
}
*/

Move PrepareBigMove(std::vector<Move>& moves, int target/*, bool fallback*/) {
  if (T < 3 || target > 6) return {-1, -1, -1};
  int valid[6] = {0, 0, 0, 0, 0, 0};
  for (int t = 0; t < T; t++) {
    valid[t] = Tiles[t].row[0] + Tiles[t].row[1] + Tiles[t].row[2]
             + Tiles[t].col[0] + Tiles[t].col[1] + Tiles[t].col[2];
  }

  std::random_shuffle(moves.begin(), moves.end());

  int tid = -1;
  int bmiss = 6*N;
  int bv = 0;
  int bh = 0;

  for (int t = 0; t < moves.size(); t++) {
    if (valid[moves[t].tile] < target) continue;
    int missing = -2*Tiles[moves[t].tile].pos.size();
    missing += 2*N - Rows[0][moves[t].row]     - Cols[0][moves[t].col];
    missing += 2*N - Rows[0][moves[t].row + 1] - Cols[0][moves[t].col + 1];
    missing += 2*N - Rows[0][moves[t].row + 2] - Cols[0][moves[t].col + 2];
    if (valid[moves[t].tile] > bv) bmiss = 6*N;
    if (valid[moves[t].tile] >= bv && missing < bmiss) bh = 0;
    if (valid[moves[t].tile] >= bv && missing <= bmiss) {
      int hh = Heuristic();
      if (hh > bh) {
        bv = valid[moves[t].tile];
        bmiss = missing;
        tid = t;
        bh = hh;
      }
    }
  }
  if (tid < 0) return {-1, -1, -1};

  PlaceTile(moves[tid].tile, moves[tid].row, moves[tid].col);
  // LOG_INFO("Let's try: %d at %d %d (missing: %d)", moves[tid].tile, moves[tid].row, moves[tid].col, bmiss);
  if (clears_cols.size() + clears_rows.size() == bv) {
    // LOG_INFO("YATA!");
    RemoveTile(moves[tid].tile, moves[tid].row, moves[tid].col);
    return moves[tid];
  }

  int si = tid;
  bh = 0;
  int add = clears_cols.size() + clears_rows.size() >= target ? 1 : -1;

  for (int t = 0; t < moves.size(); t++) {
    auto& m = moves[t];
    if (m.tile == moves[tid].tile) continue;
    if (!ValidMove(moves[t].tile, moves[t].row, moves[t].col)) continue;
    int a = 0;
    for (auto& p : Tiles[m.tile].pos) {
      int rr = m.row + p.first;
      int cc = m.col + p.second;
      a += rr >= moves[tid].row && rr < moves[tid].row+3;
      a += cc >= moves[tid].col && cc < moves[tid].col+3;
    }
    if (a > add) bh = 0;
    if (a >= add) {
      PlaceTile(m.tile, m.row, m.col);
      int hh = Heuristic();
      RemoveTile(m.tile, m.row, m.col);
      if (hh >bh) {
        add = a;
        si = t;
        bh = hh;
      }
    }
  }
  RemoveTile(moves[tid].tile, moves[tid].row, moves[tid].col);
  return moves[si];
}

Move GetRecursiveGreedy(std::vector<Move>& moves) {
  PROFILER("GetRecursiveGreedy");
  // for (int t = T; t < )
  // for (auto m : moves) {
  //   auto s = SimulateScore(m);
  //   LOG_INFO("%d %d -> %d %d", m.row, m.col, s.first, s.second);
  // }
  // LOG_INFO("Options: %d", moves.size());
  if (moves.empty()) return {-1, -1, -1};
  int depth = 1;
  int Lim = 100000;
  // if (elapsedTime > 2500) Lim /= 2;
  // if (elapsedTime > 5000) Lim /= 2;
  // if (elapsedTime > 7500) Lim /= 2;
  if (elapsedTime > 9000) Lim /= 10;
  while (turn + depth < 1000 && depth < T && std::pow(moves.size() * 1.0, depth+1) <= Lim) depth++;
  std::random_shuffle(moves.begin(), moves.end());
  // std::sort(moves.begin(), moves.end(), [&](const auto& a, const auto& b) {
  //   return Tiles[a.tile].pos.size() > Tiles[b.tile].pos.size();
  // });

  int bsc = 0;
  int bhh = 0;
  std::vector<int> bids;
  std::vector<int> cc;

  Save();
  for (int i = 0; i < moves.size(); i++) {
    bool used[6] = {false, false, false, false, false, false};
    used[moves[i].tile] = true;
    cc.push_back(i);

    auto fct = [&](auto fct, int sc) {
      int tsc = std::max(0, sc-LimLine);
      if (tsc >= bsc) {
        int hh = Heuristic();
        if (tsc > bsc || tsc == bsc && hh >= bhh) {
          bids = cc;
          bsc = tsc;
          bhh = hh;
        }
        if (cc.front() > cc.back()) return;
      }
      if (sc) return;
      if (cc.size() == depth) return;
      for (int i = 0; i < moves.size(); i++) {
        if (used[moves[i].tile]) continue;
        if (!ValidMove(moves[i].tile, moves[i].row, moves[i].col)) continue;
        used[moves[i].tile] = true;
        cc.push_back(i);
        PlaceTile(moves[i].tile, moves[i].row, moves[i].col);
        fct(fct, sc + HeuristicScore());
        RemoveTile(moves[i].tile, moves[i].row, moves[i].col);
        cc.pop_back();
        used[moves[i].tile] = false;
      }
    };
    PlaceTile(moves[i].tile, moves[i].row, moves[i].col);
    int s = HeuristicScore();
    ClearBoard();
    fct(fct, s);
    Reset();
    cc.pop_back();
  }
  return moves[bids[0]];
}

Move CorrectGetRecursiveGreedy() {
  PROFILER("CorrectGetRecursiveGreedy");
  int bsc = 0;
  int bhh = 0;
  Move bmove = {-1, -1, -1};
  std::vector<Move> cc;

  bool used[6] = {false, false, false, false, false, false};

  int depth = 1;
  auto fct = [&](auto fct, int sc) {
    if (cc.size() && sc >= bsc) {
      int hh = Heuristic();
      if (sc > bsc || sc == bsc && hh >= bhh) {
        bmove = cc[0];
        bsc = sc;
        bhh = hh;
      }
    }
    if (cc.size() == depth) return;
    auto moves =  GetMoves(T);
    if (moves.empty()) return;
    if (cc.empty()) {
      const int Lim = elapsedTime < 9000 ? 1000000 : 100000;
      while (turn + depth < 1000 && depth < T && std::pow(moves.size() * 1.0, depth+1) <= Lim) depth++;
      LOG_INFO("Depths: %d", depth);
    }
    std::random_shuffle(moves.begin(), moves.end());

    int CGrid[32][32];
    int CRows[12][32];
    int CCols[12][32];
    std::copy(&Grid[0][0], &Grid[32][0], &CGrid[0][0]);
    std::copy(&Rows[0][0], &Rows[12][0], &CRows[0][0]);
    std::copy(&Cols[0][0], &Cols[12][0], &CCols[0][0]);
    for (int i = 0; i < moves.size(); i++) {
      if (used[moves[i].tile]) continue;
      used[moves[i].tile] = true;
      cc.push_back(moves[i]);
      PlaceTile(moves[i].tile, moves[i].row, moves[i].col);
      int s = HeuristicScore();
      if (s) ClearBoard();
      fct(fct, sc + s);
      if (s) {
        PROFILER("Reset");
        std::copy(&CGrid[0][0], &CGrid[32][0], &Grid[0][0]);
        std::copy(&CRows[0][0], &CRows[12][0], &Rows[0][0]);
        std::copy(&CCols[0][0], &CCols[12][0], &Cols[0][0]);
      } else {
        RemoveTile(moves[i].tile, moves[i].row, moves[i].col);
      }
      cc.pop_back();
      used[moves[i].tile] = false;
    }
  };
  fct(fct, 0);
  return bmove;
}

Move GetRecursiveGreedyOld() {
  PROFILER("GetRecursiveGreedy");
  // for (int t = T; t < )
  auto moves =  GetMoves(T);
  // for (auto m : moves) {
  //   auto s = SimulateScore(m);
  //   LOG_INFO("%d %d -> %d %d", m.row, m.col, s.first, s.second);
  // }
  LOG_INFO("Options: %d", moves.size());
  if (moves.empty()) return {-1, -1, -1};
  int depth = 1;
  while (depth < T && std::pow(moves.size() * 1.0, depth+1) <= 1000000) depth++;
  std::random_shuffle(moves.begin(), moves.end());
  bool used[6] = {false, false, false, false, false, false};

  int bsc = 0;
  int bhh = 0;
  std::vector<int> bids;
  std::vector<int> cc;

  auto fct = [&](auto fct, int id, int sc) {
    if (cc.size() > 0) {
      if (sc >= bsc) {
        int hh = Heuristic();
        if (sc > bsc || sc == bsc && hh >= bhh) {
          bids = cc;
          bsc = sc;
          bhh = hh;
        }
        // if (cc.front() > cc.back()) return;
      }
      // if (sc * (10 - cc.size()) >= bsc * (10 - bids.size())) {
      //   int hh = Heuristic() * (10 - cc.size());
      //   if (sc * (10 - cc.size()) > bsc * (10 - bids.size()) || sc * (10 - cc.size()) == bsc * (10 - bids.size()) && hh >= bhh) {
      //     bids = cc;
      //     bsc = sc;
      //     bhh = hh;
      //   }
      //   // if (cc.front() > cc.back()) return;
      // }
      if (sc) return;
    }
    if (cc.size() == depth) return;
    for (int i = 0; i < moves.size(); i++) {
      if (used[moves[i].tile]) continue;
      if (!ValidMove(moves[i].tile, moves[i].row, moves[i].col)) continue;
      used[moves[i].tile] = true;
      cc.push_back(i);
      PlaceTile(moves[i].tile, moves[i].row, moves[i].col);
      fct(fct, i+1, sc + HeuristicScore());
      RemoveTile(moves[i].tile, moves[i].row, moves[i].col);
      cc.pop_back();
      used[moves[i].tile] = false;
    }
  };
  fct(fct, 0, 0);
  return moves[bids[0]];
}

Move GetMoveWithSimulation(double etime, int depth) {
  PROFILER("GetMoveWithSimulation");
  auto moves =  GetMoves();
  LOG_INFO("Options: %d, %lf, %d", moves.size(), etime - get_time(), depth);
  if (moves.empty()) return {-1, -1, -1};
  std::random_shuffle(moves.begin(), moves.end());

  int NumSim = std::min<int>(100, 1000 / moves.size());
  const int scale = 1000;
  std::vector<int64_t> Scores(moves.size(), 0);
  double stime = get_time();
  int sim = 0;
  while (true) {
    double time = get_time();
    sim++;
    if ((time - stime) / sim + time > etime) break;
    for (int d = 0; d < depth; d++) LoadRandomTile(Tiles[T+d]);
    auto smoves =  GetMoves(T+depth);
    std::vector<int> sidx(depth+2, smoves.size());
    for (int id = 0; id < smoves.size(); id++) {
      sidx[smoves[id].tile] = std::min(sidx[smoves[id].tile], id);
    }
    for (int d = depth; d > 0; d--) sidx[d] = std::min(sidx[d], sidx[d+1]);
    for (int d = 1; d <= depth; d++) {
      // LOG_DEBUG("%d %d", sidx[d], sidx[d+1]);
      std::random_shuffle(smoves.begin() + sidx[d], smoves.begin() + sidx[d+1]);
    }

    for (int id = 0; id < moves.size(); id++) {
      auto& m = moves[id];
      PlaceTile(m.tile, m.row, m.col);
      int sc = HeuristicScore();
      ClearBoard();
      for (int d = 1; d <= depth; d++) {
        std::pair<int, int> bsc = {-1, -1};
        int bid = -1;
        for (int id = sidx[d]; id < sidx[d+1]; id++) {
          auto& move = smoves[id];
          if (!ValidMove(d, move.row, move.col)) continue;
          PlaceTile(move.tile, move.row, move.col);
          int sc = HeuristicScore();
          if (sc >= bsc.first) {
            int hh = Heuristic();
            if (sc > bsc.first || hh > bsc.second) {
              bid = id;
              bsc = {sc, hh};
            }
          }
          RemoveTile(move.tile, move.row, move.col);
        }
        if (bid >= 0) {
          PlaceTile(smoves[bid].tile, smoves[bid].row, smoves[bid].col);
          sc += HeuristicScore();
          ClearBoard();
        }
      }
      Scores[id] += sc * scale + Heuristic();
      Reset();
      // auto sc = SimulateScore(m);
      // Scores[id] += sc.first * scale + sc.second;
    }
  }

  int bid = 0;
  for (int id = 0; id < moves.size(); id++) {
    // LOG_DEBUG("%d %d -> %lld", moves[id].row, moves[id].col, Scores[bid]);
    if (Scores[id] > Scores[bid]) bid = id;
  }
  LOG_DEBUG("Sim: %d", sim);
  return moves[bid];
}

int main()  {
  for (int i = 0; i < 32; i++) PCost[i] = i*i;
  for (int i = 0; i < 32; i++) PCost2[i] = i*i*i;
  std::cin >> N >> T >> C >> F >> P;
  LOG_INFO("N: %d, T: %d, C: %d, F: %lf, P: %lf", N, T, C, F, P);

  InitProba();
  std::fill(&Grid[0][0], &Grid[32][0], 10);
  for (int r = 0; r < N; r++) {
    for (int c = 0; c < N; c++) {
      std::cin >> Grid[2+r][2+c];
      if (Grid[2+r][2+c]) {
        Rows[0][2+r]++;
        Cols[0][2+c]++;
        Rows[Grid[2+r][2+c]][2+r]++;
        Cols[Grid[2+r][2+c]][2+c]++;
      }
    }
  }

  LimLine = 1;
  //*
  int ss[3] = {0, 0, 0};
  for (int i=0; i<8096; i++) LoadRandomTile(TilesR[i], 1 + rng.next_int(C));
  int MaxTurn = 1;
  double etime = get_time() + 2.0;
  // for (LimLine = 0; LimLine < 2; LimLine++) {
  for (LimLine = 1; LimLine >= 0; LimLine--) {
    int CGrid[32][32];
    int CRows[12][32];
    int CCols[12][32];
    std::copy(&Grid[0][0], &Grid[32][0], &CGrid[0][0]);
    std::copy(&Rows[0][0], &Rows[12][0], &CRows[0][0]);
    std::copy(&Cols[0][0], &Cols[12][0], &CCols[0][0]);
    for (int i=0; i<T; i++) Tiles[i] = TilesR[8000 + i];
    int drops = 0;
    for (int turn = 0; turn < MaxTurn && turn < 8000; turn++) {
      if (LimLine == 1 && get_time() < etime) MaxTurn++;
      auto moves =  GetMoves(T);
      auto m = GetRecursiveGreedy(moves);
      if (m.tile >= 0) {
        PlaceTile(m.tile, m.row, m.col);
        ss[LimLine] += RealScore();
        ClearBoard();
        Tiles[m.tile] = TilesR[turn%8096];
        // LOG_DEBUG("%d %d %d | %d %d %d | %d %d %d", Tiles[m.tile].p[0][0], Tiles[m.tile].p[0][1], Tiles[m.tile].p[0][2],
        //           Tiles[m.tile].p[1][0], Tiles[m.tile].p[1][1], Tiles[m.tile].p[1][2],
        //           Tiles[m.tile].p[2][0], Tiles[m.tile].p[2][1], Tiles[m.tile].p[2][2]);
      } else {
        Tiles[rng.next_int(T)] = TilesR[turn%8096];
        drops++;
      }
    }
    std::copy(&CGrid[0][0], &CGrid[32][0], &Grid[0][0]);
    std::copy(&CRows[0][0], &CRows[12][0], &Rows[0][0]);
    std::copy(&CCols[0][0], &CCols[12][0], &Cols[0][0]);
    LOG_INFO("LimLine: %d -> %d (%d/%d)", LimLine, ss[LimLine], drops, MaxTurn);
  }
  LimLine = ss[1] > ss[0] ? 1 : 0;

  int btarget = 7;
  if (T > 2){
    int bs = ss[LimLine];
    for (int target = 6; target > 4; target--) {
      int ss = 0;
      int CGrid[32][32];
      int CRows[12][32];
      int CCols[12][32];
      std::copy(&Grid[0][0], &Grid[32][0], &CGrid[0][0]);
      std::copy(&Rows[0][0], &Rows[12][0], &CRows[0][0]);
      std::copy(&Cols[0][0], &Cols[12][0], &CCols[0][0]);
      for (int i=0; i<T; i++) Tiles[i] = TilesR[8000 + i];
      int drops = 0;
      for (int turn = 0; turn < MaxTurn ; turn++) {
        auto moves =  GetMoves(T);
        auto m = PrepareBigMove(moves, target);
        if (m.tile < 0) m = GetRecursiveGreedy(moves);
        if (m.tile >= 0) {
          PlaceTile(m.tile, m.row, m.col);
          ss += RealScore();
          ClearBoard();
          Tiles[m.tile] = TilesR[turn%8096];
        } else {
          Tiles[rng.next_int(T)] = TilesR[turn%8096];
          drops++;
        }
      }
      std::copy(&CGrid[0][0], &CGrid[32][0], &Grid[0][0]);
      std::copy(&CRows[0][0], &CRows[12][0], &Rows[0][0]);
      std::copy(&CCols[0][0], &CCols[12][0], &Cols[0][0]);
      LOG_INFO("Target: %d -> %d (%d/%d)", target, ss, drops, MaxTurn);
      if (ss > bs) {
        bs = ss;
        btarget = target;
      }
    }
  }

  // LimLine = ss[2] > ss[LimLine] ? 2 : LimLine;
  //*/

  for (int i=0; i<T; i++) LoadTile(i);

  int drops = 0;
  int Lines[7] = {0, 0, 0, 0, 0, 0, 0};
  for (turn = 0; turn < 1000 && elapsedTime < 9900; turn++) {
    Move m = {-1, -1, -1};
    if (T == -1) {
      Save();
      m = GetMoveWithSimulation(get_time() + (7800 - elapsedTime) * 1.e-3 / (1000 - turn), 3);
    } else {
      auto moves =  GetMoves(T);
      m = PrepareBigMove(moves, turn > 990 ? 7 : btarget);
      if (m.tile < 0) m = turn > 990 ? CorrectGetRecursiveGreedy() : GetRecursiveGreedy(moves);
    }
    if (m.tile >= 0) {
      PlaceTile(m.tile, m.row, m.col);
      Score += RealScore();
      Lines[clears_cols.size() + clears_rows.size()]++;
      ClearBoard();
      //print move
      // std::cerr << m.tile << " " << m.row-2 << " " << m.col-2 << std::endl;
      std::cout << m.tile << " " << m.row-2 << " " << m.col-2 << std::endl;
      std::cout.flush();
      LoadTile(m.tile);
    } else {
      drops++;
      int t = rng.next_int(T);
      std::cout << t << std::endl;
      std::cout.flush();
      LoadTile(t);
    }
    
    std::cin >> elapsedTime;
    // LOG_DEBUG("%d -> %d (%d)", turn, Score, elapsedTime);
  }
  int tot = 0;
  int div = 0;
  for (int i = 1; i < 7; i++) {
    LOG_INFO("Combo %d: %d", i, Lines[i]);
    tot += Lines[i];
    div += Lines[i] * i * i;
  }
  LOG_INFO("Total: %d, average: %lf", tot, Score * 1.0 / div);
  LOG_TC("Score: %d (Time: %d, dops: %d)", Score, elapsedTime, drops);
#ifdef USEPROFILER
  PROFILER_STATS();
#endif
  //terminate
  std::cout << "-1" << std::endl;
  std::cout.flush();
  return 0;
}
