#!/usr/bin/env python3
import ctypes
import errno
import os
import platform
import socket
import sys


def socket_syscall_number():
    machine = platform.machine()
    if machine == "x86_64":
        return 41
    if machine == "aarch64":
        return 198
    raise RuntimeError(f"unsupported machine for Issue #101 probe: {machine}")


def assert_raw_inet_socket_blocked():
    libc = ctypes.CDLL("libc.so.6", use_errno=True)
    libc.syscall.restype = ctypes.c_long

    ctypes.set_errno(0)
    fd = libc.syscall(
        ctypes.c_long(socket_syscall_number()),
        socket.AF_INET,
        socket.SOCK_STREAM,
        0,
    )
    if fd >= 0:
        os.close(fd)
        print(
            "[ISSUE-101] raw AF_INET socket syscall succeeded",
            file=sys.stderr,
        )
        sys.exit(2)

    syscall_errno = ctypes.get_errno()
    if syscall_errno != errno.EPERM:
        print(
            f"[ISSUE-101] raw AF_INET socket syscall errno={syscall_errno}, expected {errno.EPERM}",
            file=sys.stderr,
        )
        sys.exit(3)

    print("[ISSUE-101] raw AF_INET socket syscall blocked", file=sys.stderr)


def read_initial_case():
    n = int(sys.stdin.readline())
    t = int(sys.stdin.readline())
    sys.stdin.readline()
    sys.stdin.readline()
    sys.stdin.readline()

    for _ in range(n * n + t):
        sys.stdin.readline()


assert_raw_inet_socket_blocked()
read_initial_case()
print("-1", flush=True)
