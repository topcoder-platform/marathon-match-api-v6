#include "cprob6.h"
//int cprob_int[1 << 24];

#include <assert.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#include <algorithm>
#include <set>
#include <unordered_map>
#include <vector>

using namespace std;

//#define LOCAL
#define NMAX 21
#define TMAX 5
#define CMAX 6
#define MAX_SIM 10
#define MAX_TURNS 1000
#define INF 1000000000
#define DEBUG_LEVEL 0 //0

#define DBG(debug_level, ...)         \
  {                                   \
    if (debug_level <= DEBUG_LEVEL) { \
      fprintf(stderr, __VA_ARGS__);   \
      fflush(stderr);                 \
    }                                 \
  }

#ifdef LOCAL
#define INV_TC_FREQ 3.3333333e-10
//#define INV_TC_FREQ 3.8461538e-10 //2.7027027e-10
#define TIME_LIMIT 9.8
#else
#define INV_TC_FREQ 3.5714286e-10
#define TIME_LIMIT 9.8
#endif

#define ELAPSED_THRESHOLD 9500

inline double GetTime() {
  unsigned long long timelo, timehi;
  __asm__ volatile("rdtsc" : "=a"(timelo), "=d"(timehi));
  return ((timehi << 32) + timelo) * INV_TC_FREQ;
}

double TSTART, TEND;

class Xor128 {
private:
unsigned int xx, yy, zz, uu;

public:
void reset(unsigned int seed) {
  xx = seed;
  yy = 362436069;
  zz = 521288629;
  uu = 786232308;
}

inline unsigned int rand() {
  unsigned int t = (xx ^ (xx << 11));
  xx = yy;
  yy = zz;
  zz = uu;
  return (uu = (uu ^ (uu >> 19)) ^ (t ^ (t >> 8)));
}
};

int N, N2, T, C;
double F, P;
char g[NMAX][NMAX];

struct Tile {
  char val[3][3];
  double prob;
};

char stile[10];
Tile tile[TMAX];

void StringToTile(const char* stile, struct Tile& t) {
  for (char i = 0; i < 3; ++i) {
    auto& tval_i = t.val[i];
    for (char j = 0; j < 3; ++j) {
      tval_i[j] = stile[i * 3 + j] - '0';
    }
  }
}

void ReadInput() {
  scanf("%d %d %d %lf %lf", &N, &T, &C, &F, &P);
  N2 = N * N;
  int x;
  for (char i = 0; i < N; ++i) {
    auto& g_i = g[i];
    for (char j = 0; j < N; ++j) {
      scanf("%d", &x);
      g_i[j] = x;
    }
  }
  for (char tid = 0; tid < T; ++tid) {
    scanf("%s", stile);
    auto& tile_tid = tile[tid];
    tile_tid.prob = 1.0;
    StringToTile(stile, tile_tid);
  }
}

double cprob[1 << 24];

void ReadCprob() {
  FILE* f = fopen("cprob.txt", "r");
  const int nstates = 1 << 24;
  for (int s = 0; s < nstates; ++s) {
    fscanf(f, "%lf", &cprob[s]);
  }
  fclose(f);
  DBG(0, "[ReadCprob] done: time=%.3lf\n", GetTime() - TSTART);
}

void ConvertCprob() {
  const int nstates = 1 << 24;
  int last_s = 0, idx = 0;
  while (last_s < nstates) {
    const auto& val = cprob_int[idx];
    const double pval = 1e-1 * val;
    const auto& cnt = cprob_int[idx + 1];
    idx += 2;
    for (int cnt1 = 0; cnt1 < cnt; ++cnt1) {
      cprob[last_s++] = pval;
    }
  }
  assert(last_s == nstates);
}

Tile sim_tile[MAX_SIM][MAX_TURNS];

void GenerateTilesForSimulations() {
  Xor128 xor128;
  xor128.reset(14012019U);
  const unsigned int VAL_AND = 1023;
  for (int sid = 0; sid < MAX_SIM; ++sid) {
    auto& sim_tile_sid = sim_tile[sid];
    for (int turn = 0; turn < MAX_TURNS; ++turn) {
      auto& curr_sim_tile = sim_tile_sid[turn];
      curr_sim_tile.prob = 1.0;
      int nfilled = 0;
      while (nfilled == 0) {
        for (char i = 0; i < 3; ++i) {
          auto& curr_sim_tile_val_i = curr_sim_tile.val[i];
          for (char j = 0; j < 3; ++j) {
            const unsigned int r = xor128.rand() & VAL_AND;
            if (r < P * VAL_AND) {
              curr_sim_tile_val_i[j] = (xor128.rand() % C) + 1;
              ++nfilled;
            }
          }
        }
      }
    }
  }
}

int nsubsets;
Tile all_tiles[1 << 9];

void GenerateAllTilesWithProbabilities() {
  nsubsets = 1 << 9;
  double sum_prob = 0.0;
  for (int s = 0; s < nsubsets; ++s) {
    auto& curr_tile = all_tiles[s];
    curr_tile.prob = 1.0;
    int bit = 0;
    for (char i = 0; i < 3; ++i) {
      auto& curr_tile_val_i = curr_tile.val[i];
      for (char j = 0; j < 3; ++j, ++bit) {
        auto& curr_tile_val_i_j = curr_tile_val_i[j];
        if (s & (1 << bit)) {
          curr_tile_val_i_j = 1;
          curr_tile.prob *= P;
        } else {
          curr_tile_val_i_j = 0;
          curr_tile.prob *= (1.0 - P);
        }
      }
    }
    sum_prob += curr_tile.prob;
  }
  assert(fabs(sum_prob - 1.0) < 1e-6);
  sum_prob -= all_tiles[0].prob;
  assert(sum_prob >= 1e-6);
  for (int s = 1; s < nsubsets; ++s) {
    all_tiles[s].prob /= sum_prob;
  }
}

#define PMAX 5
int rpow[PMAX][NMAX];

void InitPozCosts() {
  auto& rpow_0 = rpow[0];
  for (char i = 0; i <= N; ++i) {
    rpow_0[i] = 1;
  }
  for (char p = 1; p < PMAX; ++p) {
    const auto& rpow_pm1 = rpow[p - 1];
    auto& rpow_p = rpow[p];
    for (char i = 0; i <= N; ++i) {
      rpow_p[i] = rpow_pm1[i] * i;
    }
  }
}

char sboard[5][5];

void PrecomputeCoverageProbabilities() {
  FILE* f = fopen("cprob6.h", "w");
  fprintf(f, "int cprob_int[1<<24]={");
  const int nstates = 1 << 24; //24;
  int last_cprob = -1, last_cnt = 0, nprinted = 0;
  //for (int s = nstates - 1; s >= 0; --s) {
  for (int s = 0; s < nstates; ++s) {  
    int bit = 0;
    for (char r = 0; r < 5; ++r) {
      auto& sboard_r = sboard[r];
      for (char c = 0; c < 5; ++c) {
        if (r == 2 && c == 2) {
          sboard_r[c] = 0;
          continue;
        }
        if (s & (1 << bit)) {
          sboard_r[c] = 1;
        } else {
          sboard_r[c] = 0;
        }
        ++bit;
      }
    }
    
    /*if (s <= 20) {
      DBG(0, "\ns=%d\n", s);
      for (char i = 0; i < 5; ++i) {
        for (char j = 0; j < 5; ++j) {
          DBG(0, "%d", sboard[i][j]);
        }
        DBG(0, "\n");
      }
    } else exit(1);*/
    
    double cprob_s = 0.0;

    for (int tid = 1; tid < nsubsets; ++tid) {
      const auto& ctile = all_tiles[tid];
      const auto& ctile_val = ctile.val;
      char found_position = 0;
      for (char r = 0; r <= 2 && !found_position; ++r) {
        for (char c = 0; c <= 2 && !found_position; ++c) {
          if (ctile_val[2 - r][2 - c] != 1) continue;
          char overlaps_blocked_cell = 0;
          for (char i = 0; i < 3 && !overlaps_blocked_cell; ++i) {
            const char real_row = r + i;
            const auto& ctile_val_i = ctile_val[i];
            for (char j = 0; j < 3 && !overlaps_blocked_cell; ++j) {
              const char real_col = c + j;
              const auto& ctile_val_i_j = ctile_val_i[j];
              if (sboard[real_row][real_col] && ctile_val_i_j) {
                overlaps_blocked_cell = 1;
                break;
              }
            }
          }
          if (!overlaps_blocked_cell) {
            found_position = 1;
            break;
          }
        }
      }
      if (found_position) cprob_s += ctile.prob;
    }

    const int curr_cprob = (int) (10.0 * cprob_s);
    if (curr_cprob == last_cprob) {
      ++last_cnt;
    } else {
      if (last_cnt >= 1) {
        ++nprinted;
        fprintf(f, "%d,%d,", last_cprob, last_cnt);
      }
      last_cprob = curr_cprob;
      last_cnt = 1;
    }
    //fprintf(f, "%d,", curr_cprob - last_cprob);
    //fprintf(f, "%d,", curr_cprob);
    last_cprob = curr_cprob;
    if ((s % 1000) == 0) {
      DBG(0, "Done: s=%d npr=%d time=%.3lf\n", s, nprinted, GetTime() - TSTART);
    }
  }
  if (last_cnt >= 1) {
    ++nprinted;
    fprintf(f, "%d,%d,", last_cprob, last_cnt);
  }
  fprintf(f, "};\n");
  fclose(f);
  exit(0);
}

char cnt_row_val[NMAX][CMAX], cnt_row_total[NMAX];
char cnt_col_val[NMAX][CMAX], cnt_col_total[NMAX];
double cov_base[NMAX][NMAX], cov_all_tiles[NMAX][NMAX];

struct Cell {
  char row, col;
};

Cell cov_cells[TMAX][NMAX * NMAX];
int num_cov_cells[TMAX];
int covered[NMAX][NMAX], covered_idx;

char TileFits(const struct Tile& ctile, const char gboard[NMAX][NMAX], char r, char c) {
  for (char i = 0; i < 3; ++i) {
    const auto& ctile_val_i = ctile.val[i];
    const char real_row = r + i;
    for (char j = 0; j < 3; ++j) {
      const auto& ctile_val_i_j = ctile_val_i[j];
      if (ctile_val_i_j == 0) continue;
      const char real_col = c + j;
      if (real_row < 0 || real_row >= N || real_col < 0 || real_col >= N) return 0;
      if (gboard[real_row][real_col] >= 1) return 0;
    }
  }
  return 1;
}

void ComputeBaseTileCoverage(const char gboard[NMAX][NMAX], const Tile gtile[TMAX], char rmin, char rmax, char cmin, char cmax, double cov_base[NMAX][NMAX], char save_cov_cells, int excluded_tid = -1) {
  if (rmin < -2) rmin = -2;
  if (cmin < -2) cmin = -2;
  if (rmax >= N) rmax = N - 1;
  if (cmax >= N) cmax = N - 1;
  for (char tid = 0; tid < T; ++tid) {
    if (tid == excluded_tid) continue;
    const auto& curr_tile = gtile[tid];
    ++covered_idx;
    auto& num_cov_cells_tid = num_cov_cells[tid];
    auto& cov_cells_tid = cov_cells[tid];
    if (save_cov_cells) num_cov_cells_tid = 0;
    for (char r = rmin; r <= rmax; ++r) {
      for (char c = cmin; c <= cmax; ++c) {
        if (TileFits(curr_tile, gboard, r, c)) {
          for (char i = 0; i < 3; ++i) {
            const auto& curr_tile_val_i = curr_tile.val[i];
            const char real_row = r + i;
            for (char j = 0; j < 3; ++j) {
              const auto& curr_tile_val_i_j = curr_tile_val_i[j];
              const char real_col = c + j;
              if (curr_tile_val_i_j == 0) continue;
              assert(0 <= real_row && real_row < N && 0 <= real_col && real_col < N && gboard[real_row][real_col] == 0);
              if (covered[real_row][real_col] != covered_idx) {
                covered[real_row][real_col] = covered_idx;
                cov_base[real_row][real_col] += curr_tile.prob;
                if (save_cov_cells) {
                  auto& new_cell = cov_cells_tid[num_cov_cells_tid++];
                  new_cell.row = real_row;
                  new_cell.col = real_col;
                }
              }
            }
          }
        }
      }
    }
    //DBG(debug, "  tile %d: ncc=%d\n", tid, num_cov_cells_tid);
  }
}

void ComputeAllTilesCoverage(const char gboard[NMAX][NMAX], char rmin, char rmax, char cmin, char cmax, double cov_all_tiles[NMAX][NMAX]) {
  if (rmin < -2) rmin = -2;
  if (cmin < -2) cmin = -2;
  if (rmax >= N) rmax = N - 1;
  if (cmax >= N) cmax = N - 1;
  /*for (int tid = 1; tid < nsubsets; ++tid) {
    const auto& curr_tile = all_tiles[tid];
    ++covered_idx;
    for (char r = rmin; r <= rmax; ++r) {
      for (char c = cmin; c <= cmax; ++c) {
        if (TileFits(curr_tile, gboard, r, c)) {
          for (char i = 0; i < 3; ++i) {
            const auto& curr_tile_val_i = curr_tile.val[i];
            const char real_row = r + i;
            for (char j = 0; j < 3; ++j) {
              const auto& curr_tile_val_i_j = curr_tile_val_i[j];
              const char real_col = c + j;
              if (curr_tile_val_i_j == 0) continue;
              assert(0 <= real_row && real_row < N && 0 <= real_col && real_col < N && gboard[real_row][real_col] == 0);
              if (covered[real_row][real_col] != covered_idx) {
                covered[real_row][real_col] = covered_idx;
                cov_all_tiles[real_row][real_col] += curr_tile.prob;
              }
            }
          }
        }
      }
    }
  }*/
  
  for (char i = rmin; i <= rmax; ++i) {
    if (i < 0 || i >= N) continue;
    const auto& gboard_i = gboard[i];
    auto& cov_all_tiles_i = cov_all_tiles[i];
    for (char j = cmin; j <= cmax; ++j) {
      if (j < 0 || j >= N) continue;
      const auto& gboard_i_j = gboard_i[j];
      if (gboard_i_j == 0) {
        // Construct the state.
        int state = 0, bit = 0;
        for (char r = i - 2; r <= i + 2; ++r) {
          for (char c = j - 2; c <= j + 2; ++c) {
            if (r == i && c == j) continue;
            if (r < 0 || r >= N || c < 0 || c >= N || gboard[r][c] >= 1) {
              state |= (1 << bit);
            }
            ++bit;
          }
        }
        cov_all_tiles_i[j] = cprob[state];
      }
    }
  }
}

void FillGreedyInfo(const char gboard[NMAX][NMAX], const Tile gtile[TMAX]) {
  const int debug = 11; //10;
  DBG(debug, " [FillGreedyInfo]\n");
  for (char i = 0; i < N; ++i) {
    cnt_row_total[i] = cnt_col_total[i] = 0;
    memset(&cnt_row_val[i][1], 0, C * sizeof(char));
    memset(&cnt_col_val[i][1], 0, C * sizeof(char));    
  }
  for (char i = 0; i < N; ++i) {
    const auto& gboard_i = gboard[i];
    auto& cov_base_i = cov_base[i];
    auto& cov_all_tiles_i = cov_all_tiles[i];
    auto& covered_i = covered[i];
    for (char j = 0; j < N; ++j) {
      const auto& gboard_i_j = gboard_i[j];
      if (gboard_i_j >= 1) {
        ++cnt_row_total[i];
        ++cnt_col_total[j];
        ++cnt_row_val[i][gboard_i_j];
        ++cnt_col_val[j][gboard_i_j];
      }
      cov_base_i[j] = cov_all_tiles_i[j] = 0.0;
      covered_i[j] = 0;
    }
  }
  for (char i = 0; i < N; ++i) {
    DBG(debug, "  i=%d: cnt_row_total=%d cnt_row_val=[", i, cnt_row_total[i]);
    const auto& cnt_row_val_i = cnt_row_val[i];
    for (char c = 1; c <= C; ++c) {
      DBG(debug, "%d:%d, ", c, cnt_row_val_i[c]);
    }
    DBG(debug, "]\n");
  }
  for (char j = 0; j < N; ++j) {
    DBG(debug, "  j=%d: cnt_col_total=%d cnt_col_val=[", j, cnt_col_total[j]);
    const auto& cnt_col_val_j = cnt_col_val[j];
    for (char c = 1; c <= C; ++c) {
      DBG(debug, "%d:%d, ", c, cnt_col_val_j[c]);
    }
    DBG(debug, "]\n");
  }

  covered_idx = 0;
  
  if (C == 1) {
    ComputeBaseTileCoverage(gboard, gtile, -2, N - 1, -2, N - 1, cov_base, 1);
    ComputeAllTilesCoverage(gboard, -2, N - 1, -2, N - 1, cov_all_tiles);  
    for (char i = 0; i < N; ++i) {
      const auto& cov_base_i = cov_base[i];
      const auto& cov_all_tiles_i = cov_all_tiles[i];
      const auto& gboard_i = gboard[i];
      for (char j = 0; j < N; ++j) {
        const auto& cov_base_i_j = cov_base_i[j];
        const auto& cov_all_tiles_i_j = cov_all_tiles_i[j];
        const auto& gboard_i_j = gboard_i[j];
        if (gboard_i_j == 0) {
          DBG(debug, "  cell %d %d: cov_base=%.3lf cov_all_tiles=%.3lf\n", i, j, cov_base_i_j, cov_all_tiles_i_j);
        } else {
          assert(cov_base_i_j + cov_all_tiles_i_j < 1e-6);
        }
      }
    }
  }
}

struct GreedyParams {
  int val_score_pow, cnt_score_pow, cov_score_pow;
  double w_val_score, w_cnt_score, w_cov_score;
};

inline double ComputeCovScore(double x, int cov_score_pow) {
  assert(1 <= cov_score_pow && cov_score_pow <= 3);
  if (cov_score_pow == 1) return x;
  if (cov_score_pow == 2) return x * x;
  return x * x * x;
}

int val_score_base_row[NMAX], val_score_base_col[NMAX];

struct Move {
  char tid, row, col;
  int rscore1;
};

//Cell filled_cell[9];
//char filled_val[9];

struct MoveScore {
  int real_score;
  int val_score;
  int cnt_score;
  double cov_score;

  void Copy(const struct MoveScore& other) {
    real_score = other.real_score;
    val_score = other.val_score;
    cnt_score = other.cnt_score;
    cov_score = other.cov_score;
  }
  
  double ScaleValScore(const char val_score_pow) const {
    return 1.0 * val_score / (2 * N) / rpow[val_score_pow][N];
  }
  
  double ScaleCntScore(const char cnt_score_pow) const {
    //return 1.0 * cnt_score / (2 * N) / rpow[cnt_score_pow][N];
    return 0.0;
  }
  
  double ScaleCovScore() const {
    return (N2 - cov_score) / N2;
  }
  
  double NormalizedScore(const struct GreedyParams& params) const {
    return real_score + params.w_cov_score * ScaleCovScore() + params.w_cnt_score * ScaleCntScore(params.cnt_score_pow) + params.w_val_score * ScaleValScore(params.val_score_pow);
  }
  
  bool IsBetter(const struct MoveScore& other, const struct GreedyParams& params) {
    const double score = NormalizedScore(params);
    const double other_score = other.NormalizedScore(params);  
    return score > other_score;
  
    /*
    if (cov_score < other.cov_score + 1e-6) return true;
    if (cov_score > other.cov_score - 1e-6) return false;

    if (real_score > other.real_score) return true;
    if (real_score < other.real_score) return false;

    if (cnt_score > other.cnt_score) return true;
    if (cnt_score < other.cnt_score) return false;

    if (val_score > other.val_score) return true;
    if (val_score < other.val_score) return false;
    */
    
    return false;  
  }
};

char cnt_row_val_dif[NMAX][CMAX], cnt_row_total_dif[NMAX];
char cnt_col_val_dif[NMAX][CMAX], cnt_col_total_dif[NMAX];
char tmp_cnt_val_dif[CMAX];
char cleared_row[NMAX], cleared_col[NMAX];
char vcleared_row[NMAX], vcleared_col[NMAX];
char tmp_gboard[NMAX][NMAX];
double new_cov_base[NMAX][NMAX], new_cov_all_tiles[NMAX][NMAX];
double new_cov_base1[NMAX][NMAX];
char maybe_changed[NMAX][NMAX];

void EvalMove(const char gboard[NMAX][NMAX], const Tile gtile[TMAX], char tid, char r, char c, const int vcoef_val_score[], const int vcoef_cnt_score[], int cov_score_pow, char enable_cov_score, MoveScore& mscore) {
  const int debug = 11; //11;

  DBG(debug, "   EvalMove tid=%d r=%d c=%d\n", tid, r, c);

  const auto& curr_tile = gtile[tid];
  const auto& num_cov_cells_tid = num_cov_cells[tid];
  const auto& cov_cells_tid = cov_cells[tid];

  for (char i = 0; i < 3; ++i) {
    const char real_row = r + i;
    if (0 <= real_row && real_row < N) {
      cnt_row_total_dif[real_row] = 0;
      memset(&cnt_row_val_dif[real_row][1], 0, C * sizeof(char));
    }
  }
  for (char j = 0; j < 3; ++j) {
    const char real_col = c + j;
    if (0 <= real_col && real_col < N) {
      cnt_col_total_dif[real_col] = 0;
      memset(&cnt_col_val_dif[real_col][1], 0, C * sizeof(char));
    }
  }

  ++covered_idx;
  for (char i = 0; i < 3; ++i) {
    const auto& curr_tile_val_i = curr_tile.val[i];
    const char real_row = r + i;
    for (char j = 0; j < 3; ++j) {
      const auto& curr_tile_val_i_j = curr_tile_val_i[j];
      const char real_col = c + j;
      if (curr_tile_val_i_j == 0) continue;
      assert(0 <= real_row && real_row < N && 0 <= real_col && real_col < N && gboard[real_row][real_col] == 0);
      ++cnt_row_total_dif[real_row];
      ++cnt_row_val_dif[real_row][curr_tile_val_i_j];
      ++cnt_col_total_dif[real_col];
      ++cnt_col_val_dif[real_col][curr_tile_val_i_j];
      covered[real_row][real_col] = covered_idx;
      tmp_gboard[real_row][real_col] = curr_tile_val_i_j;
      const double x = (T - cov_base[real_row][real_col]) / T;
    }
  }

  // Compute the real score.
  memset(&cleared_row, 0, N * sizeof(char));
  memset(&cleared_col, 0, N * sizeof(char));

  int ncleared = 0, ncleared_rows = 0, ncleared_cols = 0, msum = 0;

  for (char i = 0; i < 3; ++i) {
    const char real_row = r + i;
    if (0 <= real_row && real_row < N) {
      if (cnt_row_total[real_row] + cnt_row_total_dif[real_row] == N && cnt_row_total_dif[real_row] >= 1) {
        ++ncleared;
        vcleared_row[ncleared_rows] = real_row;
        ++ncleared_rows;
        cleared_row[real_row] = 1;
        DBG(debug, "    cleared row: %d\n", real_row);
        const auto& cnt_row_val_real_row = cnt_row_val[real_row];
        const auto& cnt_row_val_dif_real_row = cnt_row_val_dif[real_row];
        int cnt_max = 0;
        for (char c = 1; c <= C; ++c) {
          const int cnt_c = cnt_row_val_real_row[c] + cnt_row_val_dif_real_row[c];
          if (cnt_c > cnt_max) cnt_max = cnt_c;
        }
        msum += cnt_max * cnt_max;
      }
    }
  }

  for (char j = 0; j < 3; ++j) {
    const char real_col = c + j;
    if (0 <= real_col && real_col < N) {
      if (cnt_col_total[real_col] + cnt_col_total_dif[real_col] == N && cnt_col_total_dif[real_col] >= 1) {
        ++ncleared;
        vcleared_col[ncleared_cols] = real_col;
        ++ncleared_cols;
        cleared_col[real_col] = 1;
        DBG(debug, "    cleared col: %d\n", real_col);
        const auto& cnt_col_val_real_col = cnt_col_val[real_col];
        const auto& cnt_col_val_dif_real_col = cnt_col_val_dif[real_col];
        int cnt_max = 0;
        for (char c = 1; c <= C; ++c) {
          int cnt_c = cnt_col_val_real_col[c] + cnt_col_val_dif_real_col[c];
          cnt_c *= cnt_c;
          if (cnt_c > cnt_max) cnt_max = cnt_c;
        }
        msum += cnt_max;
      }
    }
  }
  
  mscore.real_score = ncleared * msum;
  
  DBG(debug, "    ncl=%d nclr=%d nclc=%d\n", ncleared, ncleared_rows, ncleared_cols);
  
  // Compute val_score and cnt_score.
  mscore.val_score = mscore.cnt_score = 0;
  
  char rmin = r, rmax = r + 2;
  if (ncleared_cols >= 1) {
    rmin = 0;
    rmax = N - 1;
  }
  
  for (int i = rmin; i <= rmax && i < N; ++i) {
    if (i < 0) continue;
    //int new_cnt_row = cleared_row[i] ? 0 : (cnt_row_total[i] + (i >= r && i - r <= 2 ? cnt_row_total_dif[i] : 0) - ncleared_cols);
    //DBG(debug, "    i=%d: cnt_row_total=%d cleared=%d cnt_row_total_dif=%d nccols=%d new_cnt_row=%d val_sc_base_row=%d\n", i, cnt_row_total[i], cleared_row[i], (i >= r && i - r <= 2 ? cnt_row_total_dif[i] : 0), ncleared_cols, new_cnt_row, val_score_base_row[i]);
    //mscore.cnt_score -= vcoef_cnt_score[cnt_row_total[i]];
    //mscore.cnt_score += vcoef_cnt_score[new_cnt_row];
    mscore.val_score -= val_score_base_row[i];  
    int cnt_max = 0;
    if (!cleared_row[i]) {
      memset(&tmp_cnt_val_dif[1], 0, C * sizeof(char));
      for (char idx = 0; idx < ncleared_cols; ++idx) {
        const auto& j = vcleared_col[idx];
        const auto& gboard_i_j = gboard[i][j];
        const auto& tmp_gboard_i_j = tmp_gboard[i][j];
        if (gboard_i_j >= 1) --tmp_cnt_val_dif[gboard_i_j];
        else {
          assert(covered[i][j] == covered_idx);
          --tmp_cnt_val_dif[tmp_gboard_i_j];
        }
      }
      const auto& cnt_row_val_i = cnt_row_val[i];
      const auto& cnt_row_val_dif_i = cnt_row_val_dif[i];
      for (char c = 1; c <= C; ++c) {
        int cnt_c = cnt_row_val_i[c] + tmp_cnt_val_dif[c];
        if (r <= i && i - r <= 2) cnt_c += cnt_row_val_dif_i[c];
        if (cnt_c > cnt_max) cnt_max = cnt_c;
      }
    }
    mscore.val_score += vcoef_val_score[cnt_max];    
  }
  
  char cmin = c, cmax = c + 2;
  if (ncleared_rows >= 1) {
    cmin = 0;
    cmax = N - 1;
  }
  
  for (int j = cmin; j <= cmax && j < N; ++j) {
    if (j < 0) continue;
    //int new_cnt_col = cleared_col[j] ? 0 : (cnt_col_total[j] + (j >= c && j - c <= 2 ? cnt_col_total_dif[j] : 0) - ncleared_rows);
    //DBG(debug, "    j=%d: cnt_col_total=%d cleared=%d cnt_col_total_dif=%d ncrows=%d new_cnt_col=%d val_score_base_col=%d\n", j, cnt_col_total[j], cleared_col[j], (j >= c && j - c <= 2 ? cnt_col_total_dif[j] : 0), ncleared_rows, new_cnt_col, val_score_base_col[j]);
    //mscore.cnt_score -= vcoef_cnt_score[cnt_col_total[j]];
    //mscore.cnt_score += vcoef_cnt_score[new_cnt_col];
    mscore.val_score -= val_score_base_col[j];
    int cnt_max = 0;
    if (!cleared_col[j]) {
      memset(&tmp_cnt_val_dif[1], 0, C * sizeof(char));
      for (char idx = 0; idx < ncleared_rows; ++idx) {
        const auto& i = vcleared_row[idx];
        const auto& gboard_i_j = gboard[i][j];
        const auto& tmp_gboard_i_j = tmp_gboard[i][j];
        if (gboard_i_j >= 1) --tmp_cnt_val_dif[gboard_i_j];
        else {
          assert(covered[i][j] == covered_idx);
          --tmp_cnt_val_dif[tmp_gboard_i_j];
        }
      }
      const auto& cnt_col_val_j = cnt_col_val[j];
      const auto& cnt_col_val_dif_j = cnt_col_val_dif[j];
      for (char c = 1; c <= C; ++c) {
        int cnt_c = cnt_col_val_j[c] + tmp_cnt_val_dif[c];
        if (c <= j && j - c <= 2) cnt_c += cnt_col_val_dif_j[c];
        if (cnt_c > cnt_max) cnt_max = cnt_c;
      }
    }
    mscore.val_score += vcoef_val_score[cnt_max];
  }
  
  // Compute cov_score.
  mscore.cov_score = 0.0;

  if (enable_cov_score) {
    for (char i = 0; i < N; ++i) {
      auto& new_cov_base_i = new_cov_base[i];
      auto& new_cov_all_tiles_i = new_cov_all_tiles[i];  
      const auto& gboard_i = gboard[i];
      auto& tmp_gboard_i = tmp_gboard[i];
      const auto& covered_i = covered[i];
      auto& maybe_changed_i = maybe_changed[i];
      for (char j = 0; j < N; ++j) {
        if (covered_i[j] != covered_idx) {
          tmp_gboard_i[j] = gboard_i[j];
        }
        new_cov_base_i[j] = 0;
        new_cov_all_tiles_i[j] = 0.0;
        maybe_changed_i[j] = 0;
      }
    }
  
    for (char idx = 0; idx < ncleared_rows; ++idx) {
      const auto& i = vcleared_row[idx];
      auto& tmp_gboard_i = tmp_gboard[i];
      for (char j = 0; j < N; ++j) {
        tmp_gboard_i[j] = 0;
      }
    }

    for (char idx = 0; idx < ncleared_cols; ++idx) {
      const auto& j = vcleared_col[idx];
      for (char i = 0; i < N; ++i) {
        tmp_gboard[i][j] = 0;
      }
    }
    
    if (ncleared >= 1) {
      rmin = cmin = 0;
      rmax = cmax = N - 1;
    } else {
      rmin = r - 2;
      cmin = c - 2;
      rmax = r + 2;
      cmax = c + 2;
    }
  
    for (char i = rmin; i <= rmax; ++i) {
      if (i < 0 || i >= N) continue;
      for (char j = cmin; j <= cmax; ++j) {
        if (j < 0 || j >= N) continue;
        maybe_changed[i][j] = 1;
      }
    }
  
    //rmin = cmin = -2;
    //rmax = cmax = N - 1;
    ComputeBaseTileCoverage(tmp_gboard, gtile, rmin - 2, rmax, cmin - 2, cmax, new_cov_base, 0, tid);
    ComputeAllTilesCoverage(tmp_gboard, rmin - 2, rmax, cmin - 2, cmax, new_cov_all_tiles);  
  
    for (char i = 0; i < N; ++i) {
      const auto& new_cov_base1_i = new_cov_base1[i];
      const auto& cov_all_tiles_i = cov_all_tiles[i];
      const auto& new_cov_base_i = new_cov_base[i];
      const auto& new_cov_all_tiles_i = new_cov_all_tiles[i];
      const auto& tmp_gboard_i = tmp_gboard[i];
      const auto& maybe_changed_i = maybe_changed[i];
      for (char j = 0; j < N; ++j) {
        const auto& new_cov_base1_i_j = new_cov_base1_i[j];
        const auto& cov_all_tiles_i_j = cov_all_tiles_i[j];
        const auto& new_cov_base_i_j = new_cov_base_i[j];
        const auto& new_cov_all_tiles_i_j = new_cov_all_tiles_i[j];
        double v_base, v_all_tiles;
        if (maybe_changed_i[j]) {
          v_base = new_cov_base_i_j;
          v_all_tiles = new_cov_all_tiles_i_j;
        } else {
          v_base = new_cov_base1_i_j;
          v_all_tiles = cov_all_tiles_i_j;
        }        
        const auto& tmp_gboard_i_j = tmp_gboard_i[j];
        if (tmp_gboard_i_j == 0) {
          const double x = (T - v_base - v_all_tiles) / T;
          assert(x >= -1e-9);
          mscore.cov_score += ComputeCovScore(x, cov_score_pow);
        }
      }
    }
  }

  DBG(debug, "    realsc=%d valsc=%d cntsc=%d covsc=%.3lf\n", mscore.real_score, mscore.val_score, mscore.cnt_score, mscore.cov_score);

  //if (mscore.real_score != 0) exit(1);
}

void Greedy(const char gboard[NMAX][NMAX], const Tile gtile[TMAX], const struct GreedyParams& params, char blocked_tid, struct Move& move) {
  int debug = 11;//10;

  move.tid = move.row = move.col = -100;
  move.rscore1 = 0;

  covered_idx = 0;
  for (char i = 0; i < N; ++i) {
    memset(&covered[i][0], 0, N * sizeof(char));
  }
  
  const auto& vcoef_val_score = rpow[params.val_score_pow];
  const auto& vcoef_cnt_score = rpow[params.cnt_score_pow];

  for (char i = 0; i < N; ++i) {
    const auto& cnt_row_val_i = cnt_row_val[i];
    int cnt_max = 0;
    for (char c = 1; c <= C; ++c) {
      const auto& cnt_c = cnt_row_val_i[c];
      if (cnt_c > cnt_max) cnt_max = cnt_c;
    }
    val_score_base_row[i] = vcoef_val_score[cnt_max];
  }

  for (char j = 0; j < N; ++j) {
    const auto& cnt_col_val_j = cnt_col_val[j];
    int cnt_max = 0;
    for (char c = 1; c <= C; ++c) {
      const auto& cnt_c = cnt_col_val_j[c];
      if (cnt_c > cnt_max) cnt_max = cnt_c;
    }
    val_score_base_col[j] = vcoef_val_score[cnt_max];
  }

  struct MoveScore best_move_score;  
  best_move_score.real_score = -1;
  best_move_score.val_score = -INF;
  best_move_score.cnt_score = -INF;
  best_move_score.cov_score = N2;
  
  const char enable_cov_score = params.w_cov_score >= 1e-6;

  for (char tid = 0; tid < T && GetTime() < TEND; ++tid) {
    if (tid == blocked_tid) continue;
    if (enable_cov_score) {
      for (char i = 0; i < N; ++i) {
        memcpy(&new_cov_base1[i][0], &cov_base[i][0], N * sizeof(double));
      }
      const auto& cov_cells_tid = cov_cells[tid];
      const auto& num_cov_cells_tid = num_cov_cells[tid];
      for (int idx = 0; idx < num_cov_cells_tid; ++idx) {
        const auto& ccell = cov_cells_tid[idx];
        new_cov_base1[ccell.row][ccell.col] -= 1.0;
      }
    }

    for (char r = -2; r < N && GetTime() < TEND; ++r) {
      for (char c = -2; c < N && GetTime() < TEND; ++c) {
        const auto& curr_tile = gtile[tid];
        if (TileFits(curr_tile, gboard, r, c)) {
          struct MoveScore mscore;          
          EvalMove(gboard, gtile, tid, r, c, vcoef_val_score, vcoef_cnt_score, params.cov_score_pow, enable_cov_score, mscore);
          if (mscore.IsBetter(best_move_score, params)) {
            best_move_score.Copy(mscore);
            move.tid = tid;
            move.row = r;
            move.col = c;
            move.rscore1 = best_move_score.real_score;
          }
        }
      }
    }
  }
  
  if (move.tid < 0) {
    // We need to drop a tile.
    char cnt_max = 0;
    for (int tid = 0; tid < T; ++tid) {
      char cnt = 0;
      const auto& gtile_tid_val = gtile[tid].val;
      for (char i = 0; i < 3; ++i) {
        const auto& gtile_tid_val_i = gtile_tid_val[i];
        for (char j = 0; j < 3; ++j) {
          const auto& gtile_tid_val_i_j = gtile_tid_val_i[j];
          if (gtile_tid_val_i_j >= 1) ++cnt;
        }
      }
      if (cnt > cnt_max) {
        cnt_max = cnt;
        move.tid = tid;
      }
    }
  }
  
  DBG(debug, " Greedy: best_move_score=(real_sc=%d val_sc=%d cnt_sc=%d cov_sc=%.3lf) tid=%d row=%d col=%d\n", best_move_score.real_score, best_move_score.val_score, best_move_score.cnt_score, best_move_score.cov_score, move.tid, move.row, move.col);
}

char gsim[NMAX][NMAX];
struct Tile tilesim[TMAX];
int total_score, ndrops, total_ncleared, total_ncleared2, elapsed;
char cnt_val[CMAX];
char touched_row[NMAX], touched_col[NMAX];

void ApplyMove(char g[NMAX][NMAX], const struct Tile tile[TMAX], const struct Move& move, char is_real_move, char do_not_clear) {
  const int debug = 11;

  assert(0 <= move.tid && move.tid < T);

  if (move.row < -2 || move.col < -2) {
    // Drop.
    if (is_real_move) {
      ++ndrops;
      printf("%d\n", move.tid); fflush(stdout);
    }
  } else {
    // Place.      
    memset(&touched_row[0], 0, N * sizeof(char));
    memset(&touched_col[0], 0, N * sizeof(char));
    const auto& best_tile = tile[move.tid];
    for (int i = 0; i < 3; ++i) {
      const auto& best_tile_i = best_tile.val[i];
      const int real_row = move.row + i;
      for (int j = 0; j < 3; ++j) {
        const auto& best_tile_i_j = best_tile_i[j];
        const int real_col = move.col + j;
        if (best_tile_i_j == 0) continue;
        //assert(0 <= real_row && real_row < N && 0 <= real_col && real_col < N && g[real_row][real_col] == 0);
        g[real_row][real_col] = best_tile_i_j;
        touched_row[real_row] = 1;
        touched_col[real_col] = 1;
      }
    }

    /*DBG(debug, " Board1:\n");
    for (int i = 0; i < N; ++i) {
      DBG(debug, "  ");
      const auto& g_i = g[i];
      for (int j = 0; j < N; ++j) {
        const auto& g_i_j = g_i[j];
        DBG(debug, "%d", g_i_j);
      }
      DBG(debug, "\n");
    }*/
    
    if (!do_not_clear) {
      memset(&cleared_row[0], 0, N * sizeof(char));
      memset(&cleared_col[0], 0, N * sizeof(char));
      int ncleared = 0, msum = 0;
 
      for (int i = 0; i < N; ++i) {
        if (!touched_row[i]) continue;
        const auto& g_i = g[i];
        char is_full_row = 1;
        memset(&cnt_val[1], 0, C * sizeof(char));
        for (int j = 0; j < N; ++j) {
          const auto& g_i_j = g_i[j];
          if (g_i_j == 0) {
            is_full_row = 0;
            break;
          }
          ++cnt_val[g_i_j];
        }
        if (is_full_row) {
          cleared_row[i] = 1;
          DBG(debug, "   Cleared row %d\n", i);
          ++ncleared;
          int cnt_max = 0;
          for (int f = 1; f <= C; ++f) {
            const auto& cnt_val_f = cnt_val[f];
            if (cnt_val_f > cnt_max) {
              cnt_max = cnt_val_f;
            }
          }
          msum += cnt_max * cnt_max;
        }
      }
        
      for (int j = 0; j < N; ++j) {
        if (!touched_col[j]) continue;
        char is_full_col = 1;
        memset(&cnt_val[1], 0, C * sizeof(char));
        for (int i = 0; i < N; ++i) {
          const auto& g_i_j = g[i][j];
          if (g_i_j == 0) {
            is_full_col = 0;
            break;
          }
          ++cnt_val[g_i_j];
        }
        if (is_full_col) {
          cleared_col[j] = 1;
          DBG(debug, "   Cleared col %d\n", j);
          ++ncleared;
          int cnt_max = 0;
          for (int f = 1; f <= C; ++f) {
            const auto& cnt_val_f = cnt_val[f];
            if (cnt_val_f > cnt_max) {
              cnt_max = cnt_val_f;
            }
          }
          msum += cnt_max * cnt_max;
        }          
      }
        
      for (int i = 0; i < N; ++i) {
        if (cleared_row[i]) {
          memset(&g[i][0], 0, N * sizeof(char));
        }
      }
        
      for (int j = 0; j < N; ++j) {
        if (cleared_col[j]) {
          for (int i = 0; i < N; ++i) g[i][j] = 0;
        }
      }
        
      const int rscore_turn = ncleared * msum;
      //DBG(debug, " rscore_turn=%d (expected=%d)\n", rscore_turn, best_rscore_turn);
      //assert(rscore_turn == move.rscore1);
    
      if (is_real_move) {
        total_score += rscore_turn;
        total_ncleared += ncleared;
        total_ncleared2 += ncleared * ncleared;  
        printf("%d %d %d\n", move.tid, move.row, move.col); fflush(stdout);
      }
    }
  }
}

double Simulate(int tstart, int nsims, int nturns, const struct GreedyParams& gparams) {
  int debug = 11;
  DBG(debug, "  Simulate: tstart=%d nsims=%d nturns=%d\n", tstart, nsims, nturns);
  double total_rscore = 0.0;
  int num_complete_sims = 0;
  for (int sid = 0; sid < nsims; ++sid) {
    if (GetTime() >= TEND) return -1.0;
    for (char i = 0; i < N; ++i) {
      memcpy(&gsim[i][0], &g[i][0], N * sizeof(char));      
    }
    memcpy(&tilesim[0], &tile[0], T * sizeof(struct Tile));
    const auto& sim_tile_sid = sim_tile[sid];
    for (int turn = tstart; turn < MAX_TURNS && turn < tstart + nturns; ++turn) {
      if (GetTime() >= TEND) return -1.0;
      FillGreedyInfo(gsim, tilesim);
      struct Move move;
      Greedy(gsim, tilesim, gparams, -1, move);
      ApplyMove(gsim, tilesim, move, 0, 0);
      total_rscore += move.rscore1;
      memcpy(&tilesim[move.tid], &sim_tile_sid[turn], sizeof(Tile));
    }
  }
  return total_rscore / nsims;  
}

#define MAX_STATES 1000

struct State {
  struct Move move[TMAX];
  struct MoveScore mscore;
} st[TMAX + 1][MAX_STATES];

set<pair<double, int>> hset[TMAX + 1];
int nst[TMAX + 1];
char tused[TMAX];

void BeamSearch(const char gboard[NMAX][NMAX], const Tile gtile[TMAX], const struct GreedyParams& params, char blocked_tid, struct Move& move) {
  int debug = 11; //10;

  const auto& vcoef_val_score = rpow[params.val_score_pow];
  const auto& vcoef_cnt_score = rpow[params.cnt_score_pow];
  const char enable_cov_score = params.w_cov_score >= 1e-6;

  for (char t = 1; t < TMAX; ++t) {
    nst[t] = 0;
    hset[t].clear();
  }

  auto& init_state = st[0][0];
  init_state.mscore.real_score = init_state.mscore.val_score = init_state.mscore.cnt_score = 0;
  init_state.mscore.cov_score = 0.0;
  nst[0] = 1;

  move.tid = move.row = move.col = -100;
  move.rscore1 = 0;
 
  struct MoveScore best_move_score;  
  best_move_score.real_score = -1;
  best_move_score.val_score = -INF;
  best_move_score.cnt_score = -INF;
  best_move_score.cov_score = N2;
  int max_states = N <= 10 ? 100 : (N <= 12 ? 50 : (N <= 17 ? 25 : 12));
  if (elapsed >= 7500) {
    max_states >>= 1;
  }
  if (elapsed >= 9000) {
    max_states >>= 1;
  }
  if (max_states < 1) max_states = 1;
  
  for (char level = 0; level < T && GetTime() < TEND; ++level) {
    const auto& st_level = st[level];
    const auto& nst_level = nst[level];
    DBG(debug, " [BeamSearch] level=%d nst=%d\n", level, nst_level);
    if (nst_level == 0) break;

    auto& st_levelp1 = st[level + 1];
    auto& nst_levelp1 = nst[level + 1];
    auto& hset_levelp1 = hset[level + 1];
    nst_levelp1 = 0;
    hset_levelp1.clear();
    
    for (int sidx = 0; sidx < nst_level && GetTime() < TEND; ++sidx) {
      const auto& cstate = st_level[sidx];
      DBG(debug, "  level=%d sidx=%d/%d: rsc=%d valsc=%d cntsc=%d covsc=%.3lf\n", level, sidx, nst_level, cstate.mscore.real_score, cstate.mscore.val_score, cstate.mscore.cnt_score, cstate.mscore.cov_score);
      
      for (char i = 0; i < N; ++i) {
        memcpy(&gsim[i][0], &gboard[i][0], N * sizeof(char));
      }

      memset(&tused[0], 0, T * sizeof(char));
      for (char midx = 0; midx < level; ++midx) {
        const auto& move = cstate.move[midx];
        ApplyMove(gsim, gtile, move, 0, 0);
        tused[move.tid] = 1;
      }
      
      FillGreedyInfo(gsim, gtile);

      covered_idx = 0;
      for (char i = 0; i < N; ++i) {
        memset(&covered[i][0], 0, N * sizeof(char));
      }
  
      for (char i = 0; i < N; ++i) {
        const auto& cnt_row_val_i = cnt_row_val[i];
        int cnt_max = 0;
        for (char c = 1; c <= C; ++c) {
          const auto& cnt_c = cnt_row_val_i[c];
          if (cnt_c > cnt_max) cnt_max = cnt_c;
        }
        val_score_base_row[i] = vcoef_val_score[cnt_max];
      }

      for (char j = 0; j < N; ++j) {
        const auto& cnt_col_val_j = cnt_col_val[j];
        int cnt_max = 0;
        for (char c = 1; c <= C; ++c) {
          const auto& cnt_c = cnt_col_val_j[c];
          if (cnt_c > cnt_max) cnt_max = cnt_c;
        }
        val_score_base_col[j] = vcoef_val_score[cnt_max];
      }
  
      for (char tid = 0; tid < T && GetTime() < TEND; ++tid) {
        if (tused[tid]) continue;
        if (enable_cov_score) {
          for (char i = 0; i < N; ++i) {
            memcpy(&new_cov_base1[i][0], &cov_base[i][0], N * sizeof(double));
          }
          const auto& cov_cells_tid = cov_cells[tid];
          const auto& num_cov_cells_tid = num_cov_cells[tid];
          for (int idx = 0; idx < num_cov_cells_tid; ++idx) {
            const auto& ccell = cov_cells_tid[idx];
            new_cov_base1[ccell.row][ccell.col] -= 1.0;
          }
        }

        for (char r = -2; r < N && GetTime() < TEND; ++r) {
          for (char c = -2; c < N && GetTime() < TEND; ++c) {
            const auto& curr_tile = gtile[tid];
            if (TileFits(curr_tile, gsim, r, c)) {
              struct MoveScore mscore;          
              EvalMove(gsim, gtile, tid, r, c, vcoef_val_score, vcoef_cnt_score, params.cov_score_pow, enable_cov_score, mscore);
              mscore.real_score += cstate.mscore.real_score;
              mscore.val_score += cstate.mscore.val_score;
              mscore.cnt_score += cstate.mscore.cnt_score;
              const double score = mscore.NormalizedScore(params);
              int next_sidx = -1;
              if (nst_levelp1 < max_states) {
                next_sidx = nst_levelp1++;
              } else {
                const auto& top = hset_levelp1.begin();
                if (score > top->first) {
                  next_sidx = top->second;
                  hset_levelp1.erase(top);
                }
              }
              if (next_sidx < 0) continue;
              auto& nstate = st_levelp1[next_sidx];
              nstate.mscore.Copy(mscore);
              memcpy(&nstate.move[0], &cstate.move[0], level * sizeof(Move));
              auto& new_move = nstate.move[level];
              new_move.tid = tid;
              new_move.row = r;
              new_move.col = c;
              new_move.rscore1 = mscore.real_score;    
              hset_levelp1.insert({score, next_sidx});
              
              if (mscore.IsBetter(best_move_score, params)) {
                best_move_score.Copy(mscore);
                if (level == 0) {
                  move.tid = tid;
                  move.row = r;
                  move.col = c;
                  move.rscore1 = best_move_score.real_score;
                } else {
                  move = cstate.move[0];
                }
              }                     
            }
          }
        }
      }      
    }
  }

  if (move.tid < 0) {
    // We need to drop a tile.
    char cnt_max = 0;
    for (int tid = 0; tid < T; ++tid) {
      char cnt = 0;
      const auto& gtile_tid_val = gtile[tid].val;
      for (char i = 0; i < 3; ++i) {
        const auto& gtile_tid_val_i = gtile_tid_val[i];
        for (char j = 0; j < 3; ++j) {
          const auto& gtile_tid_val_i_j = gtile_tid_val_i[j];
          if (gtile_tid_val_i_j >= 1) ++cnt;
        }
      }
      if (cnt > cnt_max) {
        cnt_max = cnt;
        move.tid = tid;
      }
    }
  }
  
  DBG(debug, " BeamSearch: best_move_score=(real_sc=%d val_sc=%d cnt_sc=%d cov_sc=%.3lf) tid=%d row=%d col=%d\n", best_move_score.real_score, best_move_score.val_score, best_move_score.cnt_score, best_move_score.cov_score, move.tid, move.row, move.col);
  
//  exit(1);
}

#define MAX_CAND 100
struct GreedyParams cand_params[MAX_CAND];
int num_cand_params;

void AddGreedyParamsCandidates(int val_score_pow, int cnt_score_pow, int cov_score_pow, double w_val_score, double w_cnt_score, double w_cov_score) {
  auto& new_param = cand_params[num_cand_params++];
  new_param.val_score_pow = val_score_pow;
  new_param.cnt_score_pow = cnt_score_pow;
  new_param.cov_score_pow = cov_score_pow;
  new_param.w_val_score = w_val_score;
  new_param.w_cnt_score = w_cnt_score;
  new_param.w_cov_score = w_cov_score;
}

void Solve() {
  const int debug = 11;//10;
  int last_sim_turn = -1;
  total_score = ndrops = total_ncleared = 0, total_ncleared2 = elapsed = 0;

  GreedyParams gparams;

  num_cand_params = 0;

  if (C == 1 && (T == 1 || N >= 15)) {
    AddGreedyParamsCandidates(2, 2, 2, 0.0, 0.0, 1e9);
    AddGreedyParamsCandidates(2, 2, 2, 1.0, 0.0, 1e9);
    //AddGreedyParamsCandidates(2, 2, 2, 10.0, 0.0, 1e9);
    AddGreedyParamsCandidates(2, 2, 3, 0.0, 0.0, 1e9);
    AddGreedyParamsCandidates(2, 2, 3, 1.0, 0.0, 1e9);
    //AddGreedyParamsCandidates(2, 2, 3, 10.0, 0.0, 1e9);
  } else {
    /*AddGreedyParamsCandidates(2, 2, 2, 1.0, 0.0, 0.0); 
    AddGreedyParamsCandidates(2, 2, 2, 10.0, 0.0, 0.0);
    AddGreedyParamsCandidates(2, 2, 2, 100.0, 0.0, 0.0);
    AddGreedyParamsCandidates(2, 2, 2, 1000.0, 0.0, 0.0);
    AddGreedyParamsCandidates(2, 2, 2, 10000.0, 0.0, 0.0);
    AddGreedyParamsCandidates(2, 2, 2, 1e5, 0.0, 0.0);
    AddGreedyParamsCandidates(2, 2, 2, 1e6, 0.0, 0.0);
    AddGreedyParamsCandidates(2, 2, 2, 1e7, 0.0, 0.0);
    AddGreedyParamsCandidates(2, 2, 2, 1e8, 0.0, 0.0);*/

    AddGreedyParamsCandidates(3, 2, 2, 1.0, 0.0, 0.0); 
    AddGreedyParamsCandidates(3, 2, 2, 10.0, 0.0, 0.0);
    AddGreedyParamsCandidates(3, 2, 2, 100.0, 0.0, 0.0);
    AddGreedyParamsCandidates(3, 2, 2, 1000.0, 0.0, 0.0);
    AddGreedyParamsCandidates(3, 2, 2, 10000.0, 0.0, 0.0);
    AddGreedyParamsCandidates(3, 2, 2, 1e5, 0.0, 0.0);
    AddGreedyParamsCandidates(3, 2, 2, 1e6, 0.0, 0.0);
    AddGreedyParamsCandidates(3, 2, 2, 1e7, 0.0, 0.0);
    AddGreedyParamsCandidates(3, 2, 2, 1e8, 0.0, 0.0);
  }

  gparams = cand_params[0];

  struct Move saved_move;
  saved_move.tid = -1;

  for (int turn = 0; turn < MAX_TURNS; ++turn) {
    int nfilled = 0;
    for (int i = 0; i < N; ++i) {
      const auto& g_i = g[i];
      for (int j = 0; j < N; ++j) {
        if (g_i[j] >= 1) ++nfilled;
      }
    }
    DBG(debug, "[turn=%d tsc=%d tnc=%d tnc2=%d ndr=%d ela=%d rfill=%.3lf lsimt=%d]\n", turn, total_score, total_ncleared, total_ncleared2, ndrops, elapsed, 1.0 * nfilled / N2, last_sim_turn);
    DBG(debug, " Board:\n");
    for (int i = 0; i < N; ++i) {
      DBG(debug, "  ");
      const auto& g_i = g[i];
      for (int j = 0; j < N; ++j) {
        const auto& g_i_j = g_i[j];
        DBG(debug, "%d", g_i_j);
      }
      DBG(debug, "\n");
    }
    for (int tid = 0; 0&&tid < T; ++tid) {
      DBG(debug, " Tile %d:\n", tid);
      const auto& tile_tid_val = tile[tid].val;
      for (int i = 0; i < 3; ++i) {
        DBG(debug, "  ");
        const auto& tile_tid_val_i = tile_tid_val[i];
        for (int j = 0; j < 3; ++j) {
          DBG(debug, "%d", tile_tid_val_i[j]);
        }
        DBG(debug, "\n");
      }
    }
    
    if (C == 1 && elapsed > ELAPSED_THRESHOLD) {
      gparams.w_cov_score = 0.0;
      gparams.w_cnt_score = 1.0;
    }
    
    char enable_simulation = elapsed < ELAPSED_THRESHOLD && C >= 2;
    int MAX_TURNS_WITHOUT_SIM = 100;
    
    if (enable_simulation && (turn == 0 || turn - last_sim_turn >= MAX_TURNS_WITHOUT_SIM)) {
      DBG(debug, " Simulating multiple turns\n");
      last_sim_turn = turn;
      const int NSIMS = C >= 2 ? 5 : (T >= 3 ? 2 : 3);
      const int NTURNS = C >= 2 ? /*200*/ 100 : 50;
      double max_avg_rscore = -1.0;
      for (int cid = 0; cid < num_cand_params && GetTime() < TEND; ++cid) {
        const double avg_rscore = Simulate(turn, NSIMS, NTURNS, cand_params[cid]);
        DBG(debug, "  cid=%d: avgrsc=%.3lf\n", cid, avg_rscore);
        if (avg_rscore > max_avg_rscore) {
          max_avg_rscore = avg_rscore;
          gparams = cand_params[cid];
        }
      }
      //exit(1);
    }
    
    FillGreedyInfo(g, tile);
    struct Move move;
    if (gparams.w_cov_score >= 1e-6 || elapsed >= 9000) {
      Greedy(g, tile, gparams, saved_move.tid, move);
    } else {
      BeamSearch(g, tile, gparams, saved_move.tid, move);
    }

    DBG(debug, "(saved_move: tid=%d row=%d col=%d)\n", saved_move.tid, saved_move.row, saved_move.col);

    if (move.rscore1 == 0 && move.row >= -2 && move.col >= -2) {
      ApplyMove(g, tile, move, 1, 0);
    } else {      
      if (0&&move.rscore1 >= 1 && saved_move.tid < 0) {
        saved_move = move;
        ApplyMove(g, tile, move, 1, 1);
        --turn;
        continue;
      } else {
        if (saved_move.tid >= 0) move = saved_move;
        ApplyMove(g, tile, move, 1, 0);
        saved_move.tid = -1;
      }
    }
        
    //if (turn >= 10) exit(1);

    if (turn + 1 >= MAX_TURNS) {
      const double duration = GetTime() - TSTART;
      DBG(0, "### SC=%d TNC=%d TNC2=%d NDRP=%d N=%d T=%d C=%d F=%.3lf P=%.3lf TIME=%.3lf%s\n", total_score, total_ncleared, total_ncleared2, ndrops, N, T, C, F, P, duration, duration > TIME_LIMIT ? "(*)" : "");
      //DBG(0, "tclock=%.3lf\n", 1.0 * (clock() - tstart) / CLOCKS_PER_SEC);
    }

    // Read a new tile.
    scanf("%s", stile);
    auto& tile_move_tid = tile[move.tid];
    tile_move_tid.prob = 1.0;
    StringToTile(stile, tile_move_tid);

    // Read the elapsed time.    
    scanf("%d", &elapsed);
  }
}

int main() {
  //tstart = clock();
  TSTART = GetTime();
  TEND = TSTART + TIME_LIMIT;
  ReadInput();
  if (C == 1) {
    //ReadCprob();
    ConvertCprob();
  }
  GenerateTilesForSimulations();
  InitPozCosts();
  GenerateAllTilesWithProbabilities();
  //PrecomputeCoverageProbabilities();
  Solve();
  return 0;
}

