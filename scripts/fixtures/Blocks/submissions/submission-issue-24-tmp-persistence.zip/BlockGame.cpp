#include <fstream>
#include <iostream>
#include <string>

using namespace std;

int main() {
  int N, T, C;
  double F, P;
  if (!(cin >> N >> T >> C >> F >> P)) {
    return 0;
  }

  int cell;
  for (int i = 0; i < N * N; i++) {
    cin >> cell;
  }

  string tile;
  for (int i = 0; i < T; i++) {
    cin >> tile;
  }

  const char* markerPath = "/tmp/mm_issue_24_blocks_tmp_persistence_marker";
  ifstream markerIn(markerPath);
  if (markerIn.good()) {
    cerr << "[ISSUE-24] PERSISTENCE CONFIRMED: previous seed marker is readable"
         << endl;
    cout << "issue24_persistence_confirmed" << endl;
    cout.flush();
    return 0;
  }

  ofstream markerOut(markerPath);
  markerOut << "created by issue #24 Blocks fixture probe" << endl;
  markerOut.close();

  cout << "-1" << endl;
  cout.flush();
  return 0;
}
