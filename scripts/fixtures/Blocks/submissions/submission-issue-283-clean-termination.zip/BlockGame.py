import sys


def main():
    try:
        n = int(sys.stdin.readline().strip())
        t = int(sys.stdin.readline().strip())
        int(sys.stdin.readline().strip())
        float(sys.stdin.readline().strip())
        float(sys.stdin.readline().strip())
        for _ in range(n * n):
            sys.stdin.readline()
        for _ in range(t):
            sys.stdin.readline()
        print(f"issue-283: parsed Blocks case N={n} T={t}", file=sys.stderr, flush=True)
    except Exception as exc:
        print(f"issue-283: parser fallback: {exc}", file=sys.stderr, flush=True)

    print("-1")
    sys.stdout.flush()


if __name__ == "__main__":
    main()
