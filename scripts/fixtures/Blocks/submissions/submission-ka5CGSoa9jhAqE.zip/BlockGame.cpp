const double TL = 1.0;
#include <bits/stdc++.h>
//#define TIME_BASED
int STANDARD = 1;
using namespace std;
#define F0(i,n) for (int i=0; i<n; i++)
#define FR(i,n) for (int i=n-1; i>=0; i--)
#define F1(i,n) for (int i=1; i<=n; i++)
#define CL(a,x) memset(x, a, sizeof(x));
#define SZ(x) ((int)x.size())

//#pragma GCC optimize("O3")
//#pragma GCC optimize("unroll-loops")
//#pragma GCC target ("avx2")

const int inf = 1000009;
const double pi = acos(-1.0);
typedef pair<int, int> pii;
typedef long long ll;
typedef unsigned long long ull;
const double EPS = 1e-9;
#define PR(x) cerr << #x << "=" << (x) << endl
template<class A, class B>
ostream& operator<<(ostream& os, const pair<A, B>& p) { os << "(" << p.first << "," << p.second << ")"; return os; }
istream& operator>>(istream& is, pii& p) { is>>p.first>>p.second; return is; }
template<class T>
ostream& operator<<(ostream& os, const vector<T>& v) {
    os << "["; for (int i=0;i<v.size();i++) { if (i>0) os << ","; os << v[i]; } os << "]"; return os;
}
template<class T>
ostream& operator<<(ostream& os, const set<T>& v) {
    os << "{"; int f=1; for(auto i:v) { if(f)f=0;else os << ","; os << i; } os << "}"; return os;
}

#ifndef FAST_TIMER
#include <sys/time.h>
double GetSeconds() {
    timeval tv;
    gettimeofday(&tv, 0);
    return tv.tv_sec + tv.tv_usec * 1e-6;
}
#else
inline ll GetTSC() {
    ll lo, hi;
    asm volatile ("rdtsc": "=a"(lo), "=d"(hi));
    return lo + (hi << 32);
}
inline double GetSeconds() {
    return GetTSC() / 2.8e9;
}
#endif

const int MAX_RAND = 1 << 30;
struct Rand {
    ll x, y, z, w, o;
    Rand() {}
    Rand(ll seed) { reseed(seed); o = 0; }
    inline void reseed(ll seed) { x = 0x498b3bc5 ^ seed; y = 0; z = 0; w = 0;  F0(i, 20) mix(); }
    inline void mix() { ll t = x ^ (x << 11); x = y; y = z; z = w; w = w ^ (w >> 19) ^ t ^ (t >> 8); }
    inline ll rand() { mix(); return x & (MAX_RAND - 1); }
    inline int nextInt(int n) { return rand() % n; }
    inline int nextInt(int L, int R) { return rand()%(R - L + 1) + L; }
    inline int nextBool() { if (o < 4) o = rand(); o >>= 2; return o & 1; }
    double nextDouble() { return rand() * 1.0 / MAX_RAND; }
};
Rand my(2020);
double saveTime;
const int _SZ = 32;
double t_o[_SZ];
ll c_o[_SZ];
void Init() {
    saveTime = GetSeconds();
    F0(i, _SZ) t_o[i] = 0.0;
    F0(i, _SZ) c_o[i] = 0;
}
double Elapsed() { return GetSeconds() - saveTime; }
void Report() {
    double tmp = Elapsed();
    cerr << "-------------------------------------" << endl;
    cerr << "Elapsed time: " << tmp << " sec" << endl;
    double total = 0.0; F0(i, _SZ) { if (t_o[i] > 0) cerr << "t_o[" << i << "] = " << t_o[i] << endl; total += t_o[i]; } cerr << endl; //if (total > 0) cerr << "Total spent: " << total << endl;
    F0(i, _SZ) if (c_o[i] > 0) cerr << "c_o[" << i << "] = " << c_o[i] << endl;
    cerr << "-------------------------------------" << endl;
}
struct AutoTimer {
    int x;
    double t;
    AutoTimer(int x) : x(x) {
        t = Elapsed();
    }
    ~AutoTimer() {
        t_o[x] += Elapsed() - t;
    }
};
#define AT(i) AutoTimer a##i(i)
//#define AT(i)

const int N = 32;
const int LOGN = 1 << 16;
double logs[LOGN];
enum {
    Left, Up, Right, Down
};
const int DX[]={0,-1,0,1};
const int DY[]={-1,0,1,0};
const string DS="LURD";
int n, T, OC, C, turn, TURNS = 1000, elapsedTime;
bool sim;
int thec;
double F, P;
const int SD = 10;
int gent[SD][1000][3][3], sd;
int grid[N][N], g[N][N], tiles[5][3][3], tcolor[5], tcount[5], rc[N], cc[N];
int remr[N], remc[N];
int lx = 1, ly = 1, allow = 1, expand = 0;
vector<int> ys, ts;
vector<int> xrange[8];
pii rows[8];
int lb[6], rb[6], cb[6], lens[6];
int nk[N*N][N*N], nx[N*N][4];
vector<int> nei[N*N];
int score, bscore;

#define ID(x, y) ((x)*n+(y))
#define PID(p) ID((p).first, (p).second)
#define X(z) ((z)/n)
#define Y(z) ((z)%n)
#define XY(z) pii((z)/n,(z)%n)

int d1(int x, int y) { return abs(x-y); }
int dbord(int x) { return min(x, n-1-x); }
int d1(pii p1, pii p2) { return d1(p1.first,p2.first)+d1(p1.second,p2.second); }
pii Move(pii p, int k) { return pii(p.first + DX[k], p.second + DY[k]); }
bool In(pii p) { return p.first >= 0 && p.first < n && p.second >= 0 && p.second < n; }
//int GetDir(pii p1, pii p2) { F0(k, 4) if (d1(p1, p2) > d1(Move(p1, k), p2)) return k; return -1; }
int GetDir(pii p1, pii p2) { F0(k, 4) if (Move(p1, k) == p2) return k; throw; return 4; }
int GetDir(int a1, int a2) { return GetDir(XY(a1), XY(a2)); }
int sqr(int x) { return x*x; }
inline int f(int x) { return (x + n) % n; }
template<class T>
void RS(vector<T>& v) { F1(i, SZ(v)-1) { int j = my.nextInt(0, i); swap(v[i], v[j]); } }

int in_range[6][N+2];
void Prepare() {
    bscore = inf;
    F0(i, LOGN) logs[i] = -log((i+0.5)/LOGN);

    F0(i, n) F0(j, n) if (grid[i][j]) {
        rc[i]++;
        cc[j]++;
    }

    CL(-1, nk);
    F0(i, n) F0(j, n) {
        int id = ID(i, j);
        F0(k, 4) {
            pii p = Move(pii(i, j), k);
            nx[id][k] = -1;

            if (In(p)) {
                int np = PID(p);
                nei[id].push_back(np);
                nx[id][k] = np;
                nk[id][np] = k;
            }
        }
    }

    F0(i, T) ts.push_back(i);
}


void Targets() {
    ys.clear();
    for (int i = -2; i < n; i++) {
        ys.push_back(i);
    }
    sort(ys.begin(), ys.end(), [&](int x, int y) {
        return min(x,n-1-x) < min(y,n-1-y);
    });

    int len = (n-1) / C;
    F0(i, C) lens[i] = len;
    for (int j = 1; j <= (n-1) % C; j++) lens[j]++;

    int last = -1;
    F1(i, C) {
        lb[i] = last + 1; rb[i] = last + lens[i - 1];
        cb[i] = (lb[i] + rb[i]) / 2;
        if (C == 1) cb[i] = n-3;
        last = rb[i];
        PR(lb[i]);
    }

    F1(c, C) {
        if (c == 1) lb[c] = -2;
        if (c == C) rb[c] = n-1;
    }

    CL(0, in_range);
    F1(c, C) {
        xrange[c].clear();
        F0(x, expand) {
            if (x%2==0) {
                if (lb[c] !=-2) lb[c]--; else rb[c]=min(rb[c]+1, n-1);
            } else {
                if (rb[c] != n-1) rb[c]++; else lb[c]=max(lb[c]-1, -2);
            }
        }

        cerr << pii(lb[c], rb[c]) << endl;
        for (int x = lb[c]; x <= rb[c]; x++) {
            in_range[c][x+2] = 1;
            xrange[c].push_back(x);
        }

        sort(xrange[c].begin(), xrange[c].end(), [&](int x, int y) {
            int dx = abs(x - cb[c]), dy = abs(y - cb[c]);
            return dx < dy;
        });
        PR(xrange[c]);
    }
}

vector<pii> xyrange;
void Targets1() {
    int tx = 2, ty = 2;

    vector<pair<int, pii>> pq;
    for (int x = -2; x < n; x++) {
        for (int y = -2; y < n; y++) {
            int v = abs(abs(tx - x) - abs(ty - y));
            pq.push_back(make_pair(v, pii(x, y)));
        }
    }
    sort(pq.begin(), pq.end());
    xyrange.clear();
    for (auto p : pq) xyrange.push_back(p.second);
}

void ReadTile(int t) {
    if (sim) {
        tcount[t] = 0;
        F0(i, 3) F0(j, 3) {
            tiles[t][i][j] = gent[sd][turn][i][j];
            if (tiles[t][i][j]) {
                tcolor[t] = tiles[t][i][j];
                tcount[t]++;
            }
        }
    } else {
        string line;
        cin >> line;
        tcount[t] = 0;
        F0(i, 3) F0(j, 3) {
            tiles[t][i][j] = line[i*3+j]-'0';
            if (tiles[t][i][j]) {
                tcolor[t] = tiles[t][i][j];
                tcount[t]++;
            }
        }
    }
}

void UpdateBest() {
    if (score < bscore) {
        bscore = score;
    }
}

bool CanPut(int t, int x, int y) {
    F0(i, 3) F0(j, 3) if (tiles[t][i][j]) {
        int x2 = x + i, y2 = y + j;
        if (In(pii(x2, y2)) && grid[x2][y2] == 0) continue;
        else return false;
    }
    return true;
}

void Discard(int t) {
    c_o[1]++;
    if (!sim) {
        cout << t << endl;
    }
    ReadTile(t);
}

void Put(int t, int x, int y) {
    F0(i, 3) F0(j, 3) if (tiles[t][i][j]) {
        int x2 = x + i, y2 = y + j;
        if (In(pii(x2, y2)) && grid[x2][y2] == 0) {
            rc[x2]++;
            cc[y2]++;
            grid[x2][y2] = tiles[t][i][j];
        }
        else throw;
    }
}

void Remove(int t, int x, int y) {
    F0(i, 3) F0(j, 3) if (tiles[t][i][j]) {
        int x2 = x + i, y2 = y + j;
        if (In(pii(x2, y2)) && grid[x2][y2]) {
            rc[x2]--;
            cc[y2]--;
            grid[x2][y2] = 0;
        }
        else throw;
    }
}

int freq[5], lines;
int Calc() {
    lines = 0;
    int ksum = 0;
    F0(i, n) if (rc[i] == n) {
        lines++;
        CL(0, freq);
        F0(j, n) freq[grid[i][j]-1]++;
        int k = *max_element(freq, freq+5);
        ksum += k*k;
    }
    F0(j, n) if (cc[j] == n) {
        lines++;
        CL(0, freq);
        F0(i, n) freq[grid[i][j]-1]++;
        int k = *max_element(freq, freq+5);
        ksum += k*k;
    }
    return lines * ksum;
}

void ClearLines() {
    vector<int> rows, cols;
    int ksum = 0;
    F0(i, n) {
        CL(0, freq);
        int cnt = 0;
        F0(j, n) if (grid[i][j]) {
            cnt++;
            freq[grid[i][j]-1]++;
        }
        if (cnt == n) {
            rows.push_back(i);
            int k = *max_element(freq, freq+5);
            ksum += k*k;
        }
    }
    F0(j, n) {
        CL(0, freq);
        int cnt = 0;
        F0(i, n) if (grid[i][j]) {
            cnt++;
            freq[grid[i][j]-1]++;
        }
        if (cnt == n) {
            cols.push_back(j);
            int k = *max_element(freq, freq+5);
            ksum += k*k;
        }
    }

    for (int i : rows) F0(j, n) if (grid[i][j]) {
        grid[i][j] = 0;
        rc[i]--;
        cc[j]--;
    }
    for (int j : cols) F0(i, n) if (grid[i][j]) {
        grid[i][j] = 0;
        rc[i]--;
        cc[j]--;
    }

    score += (SZ(rows) + SZ(cols)) * ksum;
}

int TileFreq(int t, int c) {
    int ret = 0;
    F0(i, 3) F0(j, 3) if (tiles[t][i][j] == c) ret++;
    return ret;
}
bool IsBest(int t, int c) {
    F1(c2, C) if (TileFreq(t, c2) > TileFreq(t, c)) return false;
    return true;
}

bool TryPut() {
    int bt = -1, bx = -1, by = -1;
    double bv = -1;
    for (int t : ts) {
        int c = tcolor[t];
        /*
        if (C >= 2) {
            if (IsBest(t, 1)) sort(xs.begin(), xs.end());
            else if (IsBest(t, 2)) sort(xs.rbegin(), xs.rend());
            else sort(xs.begin(), xs.end(), [&](int x, int y) {
                return min(x,n-1-x) > min(y,n-1-y);
            });
        }
        */

        for (int x : xrange[c]) for (int y : ys) {
            if (CanPut(t, x, y)) {
                Put(t, x, y);
                int add = Calc();
                double av = add;
                if (av > bv) {
                    bv = av;
                    bt = t;
                    bx = x;
                    by = y;
                }

                if (add == 0 && elapsedTime < 8000 && !sim) {
                    for (int t2 : ts) if (t2 != t) {
                        for (int x2 = x - 2; x2 <= x + 2; x2++) if (x2 >= -2 && x2 < n && in_range[c][x2+2])
                            for (int y2 = -2; y2 < n; y2++) if (y2 >= -2 && y2 < n) {
                                if (CanPut(t2, x2, y2)) {
                                    Put(t2, x2, y2);
                                    int add2 = Calc();
                                    double av = add2 / 2.0;
                                    if (add2 && av > bv) {
                                        bv = av;
                                        bt = t;
                                        bx = x;
                                        by = y;
                                    }
                                    Remove(t2, x2, y2);
                                }
                            }
                        for (int x2 = -2; x2 < n; x2++) if (x2 >= -2 && x2 < n && in_range[c][x2+2])
                            for (int y2 = y - 2; y2 <= y + 2; y2++) if (y2 >= -2 && y2 < n) {
                                if (CanPut(t2, x2, y2)) {
                                    Put(t2, x2, y2);
                                    int add2 = Calc();
                                    double av = add2 / 2.0;
                                    if (add2 && av > bv) {
                                        bv = av;
                                        bt = t;
                                        bx = x;
                                        by = y;
                                    }
                                    Remove(t2, x2, y2);
                                }
                            }
                    }
                }

                Remove(t, x, y);
            }
        }
    }

    if (bv >= 0) {
        if (bv == 0) c_o[2]++; else c_o[3]++;
        int t = bt, x = bx, y = by;
        Put(t, x, y);
        ClearLines();
        if (!sim) cout << t << " " << x << " " << y << endl;
        ReadTile(t);
        return true;
    }

    return false;
}

bool TryPut1() {
    int bt = -1, bx = -1, by = -1;

    int tx = 2, ty = 2;

    bool both = false;
    if (allow > 1) {
        double bv = -10.0;
        int d = 2;
        for (int i = d; i + lx <= n-d; i++)
        for (int j = d; j + ly <= n-d; j++) {

            bool can = true;
            for (int x = i; x < i + lx; x++) remr[x] = 0;
            for (int x = j; x < j + ly; x++) remc[x] = 0;
            for (int x = i; x < i + lx; x++) {
                for (int y = j; y < j + ly; y++) if (grid[x][y]) {
                    if (++remr[x] == ly) can = false;
                    if (++remc[y] == lx) can = false;
                }
            }
            if (!can) continue;

            double av = 0;
            for (int k = i; k < i + lx; k++) av += rc[k];
            for (int k = j; k < j + ly; k++) av += cc[k];
            av -= (rc[i-1] + rc[i+lx] + cc[j-1] + cc[j+ly]) * 0.1;
            if (av > bv) {
                bv = av;
                both = true;
                tx = i;
                ty = j;
            }
        }
    }

    double bv = -1;
F0(fb, 1) {
    if (fb == 1) both = 0;
    if (!both) {
        for (int i = 2; i < n-2; i++) if (rc[i] > rc[tx]) tx = i;
        for (int j = 2; j < n-2; j++) if (cc[j] > cc[ty]) ty = j;
        if (rc[tx] > cc[ty]) ty = -5; else tx = -5;
        lx = 1;
        ly = 1;
    }
    for (int t : ts) {
        int c = tcolor[t];
        //assert(c == 1);
        for (pii xy : xyrange) {
            int x = xy.first, y = xy.second;
            if (CanPut(t, x, y)) {
                Put(t, x, y);
                int add = Calc();

                double av = add + tcount[t] * 0.01;
                if (both && lines > 0 && lines < allow) {
                    Remove(t, x, y);
                    continue;
                }

                if (!add) {
                    if (both) {
                        for (int x = tx; x < tx + lx; x++) remr[x] = 0;
                        for (int x = ty; x < ty + ly; x++) remc[x] = 0;
                        for (int x = tx; x < tx + lx; x++) {
                            for (int y = ty; y < ty + ly; y++) if (grid[x][y]) {
                                if (++remr[x] == ly) av -= 100;
                                if (++remc[y] == lx) av -= 100;
                            }
                        }
                    }

                    F0(i, 3) F0(j, 3) if (tiles[t][i][j]) {
                        int x2 = x + i, y2 = y + j;
                        if (x2 >= tx && x2 < tx + lx) av += 0.1;
                        if (y2 >= ty && y2 < ty + ly) av += 0.1;
                        if (x2 == tx - 1 || x2 == tx + lx) av -= 0.0009;
                        if (y2 == ty - 1 || y2 == ty + ly) av -= 0.0009;
                        if (x2 == tx - 2 || x2 == tx + lx + 1) av -= 0.0003;
                        if (y2 == ty - 2 || y2 == ty + ly + 1) av -= 0.0003;
                        if (x2 == tx - 3 || x2 == tx + lx + 2) av -= 0.0001;
                        if (y2 == ty - 3 || y2 == ty + ly + 2) av -= 0.0001;
                    }
                }

                if (av > bv) {
                    bv = av;
                    bt = t;
                    bx = x;
                    by = y;
                }

                if (add == 0 && elapsedTime < 8000 && !sim) {
                    for (int t2 : ts) if (t2 != t) {
                        for (int x2 = x - 2; x2 <= x + 2; x2++) if (x2 >= -2 && x2 < n)
                            for (int y2 = -2; y2 < n; y2++) if (y2 >= -2 && y2 < n) {
                                if (CanPut(t2, x2, y2)) {
                                    Put(t2, x2, y2);
                                    int add2 = Calc();
                                    if (both && lines < allow) add2 = -1;
                                    double av = add2 / 2.0 + tcount[t] * 0.01;
                                    if (add2 && av > bv) {
                                        bv = av;
                                        bt = t;
                                        bx = x;
                                        by = y;
                                    }
                                    Remove(t2, x2, y2);
                                }
                            }
                        for (int x2 = -2; x2 < n; x2++) if (x2 >= -2 && x2 < n)
                            for (int y2 = y - 2; y2 <= y + 2; y2++) if (y2 >= -2 && y2 < n) {
                                if (CanPut(t2, x2, y2)) {
                                    Put(t2, x2, y2);
                                    int add2 = Calc();
                                    if (both && lines < allow) add2 = -1;
                                    double av = add2 / 2.0 + tcount[t] * 0.01;
                                    if (add2 && av > bv) {
                                        bv = av;
                                        bt = t;
                                        bx = x;
                                        by = y;
                                    }
                                    Remove(t2, x2, y2);
                                }
                            }
                    }
                }

                Remove(t, x, y);
            }
        }
    }
    if (bv >= 0 || !both) break;
}
    if (bv >= 0) {
        if (bv == 0) c_o[2]++; else c_o[3]++;
        int t = bt, x = bx, y = by;
        Put(t, x, y);
        ClearLines();
        if (!sim) cout << t << " " << x << " " << y << endl;
        ReadTile(t);
        return true;
    }

    return false;
}

int stiles[5][3][3], sturn, sscore, sgrid[N][N], src[N], scc[N], stcount[5], stcolor[5];

int Simulation() {
    sim = true;
    F0(t, T) F0(i, 3) F0(j, 3) stiles[t][i][j] = tiles[t][i][j];
    F0(t, T) { stcount[t] = tcount[t]; stcolor[t] = tcolor[t]; }
    sscore = score;
    sturn = turn;
    F0(i, n) F0(j, n) sgrid[i][j] = grid[i][j];
    F0(i, n) { src[i] = rc[i]; scc[i] = cc[i]; }

    for (; turn < TURNS; turn++) {
        sort(ts.begin(), ts.end(), [&](int x, int y) {
            if (tcount[x] != tcount[y]) return tcount[x] > tcount[y];
            return x < y;
        });

        bool done = false;
        F0(t, T) if (C == 1 && tcolor[t] != thec) {
            Discard(t);
            done = true;
            break;
        }
        if (done) continue;

        bool put = false;
        if (C == 1) put = TryPut1(); else put = TryPut();
        if (!put) {
            Discard(ts[my.nextInt(T)]);
        }
    }
    int ret = score;

    F0(i, n) { rc[i] = src[i]; cc[i] = scc[i]; }
    F0(i, n) F0(j, n) grid[i][j] = sgrid[i][j];
    score = sscore;
    turn = sturn;
    F0(t, T) F0(i, 3) F0(j, 3) tiles[t][i][j] = stiles[t][i][j];
    F0(t, T) { tcount[t] = stcount[t]; tcolor[t] = stcolor[t]; }
    sim = false;

    return ret;
}

int b1 = 0, b2 = 0, b3 = 0, b4 = 0;
void Eval(int a1, int a2, int a3, int a4) {
    lx = a1; ly = a2; allow = a3; expand = a4;
    if (expand) C = OC; else C = 1;
    if (C == 1) Targets1(); else Targets();
    int nscore = 0;
    for (sd = 0; sd < SD; sd++) nscore += Simulation();
    PR(nscore);
    if (nscore > bscore) {
        bscore = nscore;
        b1 = a1; b2 = a2; b3 = a3; b4 = a4;
    }
}

void Solve() {
    Init();
    Prepare();

    //if (C != 1) throw;
    OC = C;

    //if (C <= 3) C = 1;

    thec = 1;

    int cc = -1;
    F1(c, OC) {
        int cnt = 0;
        F0(i, n) F0(j, n) {
            if (grid[i][j] == c) cnt++;
        }
        if (cnt > cc) { thec = c; cc = cnt; }
    }

    for (sd = 0; sd < SD; sd++) F0(turn, TURNS) {
        int x = my.nextInt(1, C);
        F0(i, 3) F0(j, 3) if (my.nextDouble() < P) gent[sd][turn][i][j] = x; else gent[sd][turn][i][j] = 0;
    }
    score = 0;
    bscore = -1;
    Eval(1, 1, 1, 0);
    Eval(1, 1, 2, 0);
    Eval(2, 2, 2, 0);
    Eval(2, 2, 3, 0);
    Eval(0, 0, 0, 0);
    Eval(2, 2, 4, 0);
    if (OC != 1) {
        Eval(0, 0, 0, 1);
        Eval(0, 0, 0, n);
    }
    lx = b1; ly = b2; allow = b3; expand = b4;
    if (!expand) C = 1;

    /*
    if (P > 0.45) {
        lx = ly = 1; allow = 1;
    }
    else if (P > 0.35) {
        lx = ly = 1; allow = 2;
    }
    else if (P > 0.32) {
        lx = ly = 2; allow = 2;
    } else {
        lx = ly = 2; allow = 3;
    }*/

    if (C == 1) Targets1(); else Targets();
    for (turn = 0; turn < TURNS; turn++) {
        if (turn > 0) cin >> elapsedTime;
        sort(ts.begin(), ts.end(), [&](int x, int y) {
            if (tcount[x] != tcount[y]) return tcount[x] > tcount[y];
            return x < y;
        });

        bool done = false;
        F0(t, T) if (C == 1 && tcolor[t] != thec) {
            Discard(t);
            done = true;
            break;
        }
        if (done) continue;

        bool put = false;
        if (C == 1) put = TryPut1(); else put = TryPut();
        if (!put) {
            Discard(ts[0]);
        }

        if (0 && turn == 500 && C == 1 && elapsedTime < 5000) {
            bscore = -1;
            Eval(1, 1, 1, 0);
            Eval(1, 1, 2, 0);
            Eval(2, 2, 2, 0);
            Eval(2, 2, 3, 0);
            Eval(0, 0, 0, 0);
            Eval(2, 2, 4, 0);
            lx = b1; ly = b2; allow = b3; expand = b4;
        }
    }
    PR(c_o[1]);
    PR(c_o[2]);
    PR(c_o[3]);
    PR(score);
    //Report();
}

void RunVis() {
    cin >> n >> T >> C >> F >> P;
    F0(i, n) F0(j, n) {
        cin >> grid[i][j];
    }
    F0(i, T) ReadTile(i);
    Solve();
}

void RunFromSave() {
    ignore = freopen("1.txt", "r", stdin);
    RunVis();
}

void RunVisSave() {
    ignore = freopen("1.txt", "w", stdout);
    cin >> n;
    F0(i, n) F0(j, n) {
        cin >> grid[i][j];
    }
    cout << n << endl;
    F0(i, n) F0(j, n) {
        cout << grid[i][j] << endl;
    }
}

int main(int argc, char* argv[]) {
#ifdef RED
    ignore = freopen("log.txt", "w", stderr);
#endif
    (void)argv; if (argc > 1) {
        STANDARD = 0;
        RunFromSave(); exit(0);
    }
    //RunVisSave(); exit(0);

    RunVis();

    return 0;
}

