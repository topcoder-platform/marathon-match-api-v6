import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.List;

public class BlockGame {
    private static final int TILE_SIZE = 3;
    private static final List<String> JAVA_9_API_MARKER = List.of("java11-release");
    private static final long PID_MARKER = ProcessHandle.current().pid();

    public static void main(String[] args) throws Exception {
        if (PID_MARKER < 0 && JAVA_9_API_MARKER.isEmpty()) {
            throw new IllegalStateException("Java 9 API marker was not initialized");
        }

        BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
        int size = Integer.parseInt(in.readLine());
        int tileCount = Integer.parseInt(in.readLine());
        Integer.parseInt(in.readLine());
        in.readLine();
        in.readLine();

        int[][] grid = new int[size][size];
        for (int row = 0; row < size; row++) {
            for (int col = 0; col < size; col++) {
                grid[row][col] = Integer.parseInt(in.readLine());
            }
        }

        int[][][] tiles = new int[tileCount][TILE_SIZE][TILE_SIZE];
        for (int tile = 0; tile < tileCount; tile++) {
            readTile(tiles[tile], in.readLine());
        }

        for (int turn = 0; turn < 1000; turn++) {
            Move move = findMove(grid, tiles);
            int changedTile;
            if (move == null) {
                changedTile = 0;
                System.out.println(changedTile);
            } else {
                changedTile = move.tile;
                applyMove(grid, tiles[move.tile], move.row, move.col);
                System.out.println(move.tile + " " + move.row + " " + move.col);
            }
            System.out.flush();

            String nextTile = in.readLine();
            if (nextTile == null) {
                return;
            }
            readTile(tiles[changedTile], nextTile);

            if (in.readLine() == null) {
                return;
            }
        }
    }

    private static Move findMove(int[][] grid, int[][][] tiles) {
        for (int tile = 0; tile < tiles.length; tile++) {
            for (int row = 0; row < grid.length; row++) {
                for (int col = 0; col < grid.length; col++) {
                    if (canPlace(grid, tiles[tile], row, col)) {
                        return new Move(tile, row, col);
                    }
                }
            }
        }
        return null;
    }

    private static boolean canPlace(int[][] grid, int[][] tile, int row, int col) {
        for (int tileRow = 0; tileRow < TILE_SIZE; tileRow++) {
            for (int tileCol = 0; tileCol < TILE_SIZE; tileCol++) {
                if (tile[tileRow][tileCol] == 0) {
                    continue;
                }

                int gridRow = row + tileRow;
                int gridCol = col + tileCol;
                if (gridRow >= grid.length || gridCol >= grid.length || grid[gridRow][gridCol] != 0) {
                    return false;
                }
            }
        }
        return true;
    }

    private static void applyMove(int[][] grid, int[][] tile, int row, int col) {
        for (int tileRow = 0; tileRow < TILE_SIZE; tileRow++) {
            for (int tileCol = 0; tileCol < TILE_SIZE; tileCol++) {
                if (tile[tileRow][tileCol] != 0) {
                    grid[row + tileRow][col + tileCol] = tile[tileRow][tileCol];
                }
            }
        }
    }

    private static void readTile(int[][] tile, String encoded) {
        for (int i = 0; i < TILE_SIZE * TILE_SIZE; i++) {
            tile[i / TILE_SIZE][i % TILE_SIZE] = encoded.charAt(i) - '0';
        }
    }

    private static final class Move {
        private final int tile;
        private final int row;
        private final int col;

        private Move(int tile, int row, int col) {
            this.tile = tile;
            this.row = row;
            this.col = col;
        }
    }
}
