import errno
import sys

SENSITIVE_PATHS = [
    "/etc/hostname",
    "/etc/resolv.conf",
    "/proc/self/cgroup",
    "/proc/self/mounts",
    "/proc/net/tcp",
    "/proc/net/tcp6",
]


def can_read(path):
    try:
        with open(path, "rb") as handle:
            handle.read(1)
        return True
    except (FileNotFoundError, IsADirectoryError, NotADirectoryError, PermissionError):
        return False
    except OSError as error:
        return error.errno not in (errno.EACCES, errno.EPERM, errno.ENOENT, errno.ENOTDIR)


leaked_paths = [path for path in SENSITIVE_PATHS if can_read(path)]
if leaked_paths:
    print("ISSUE21_LEAK " + " ".join(leaked_paths), flush=True)
    sys.exit(0)

N = int(input())
T = int(input())
C = int(input())
F = float(input())
P = float(input())

grid = [[0 for _ in range(N)] for _ in range(N)]
for r in range(N):
    for c in range(N):
        grid[r][c] = int(input())

S = 3
tiles = [[[0 for _ in range(S)] for _ in range(S)] for _ in range(T)]
for i in range(T):
    line = input()
    for r in range(S):
        for c in range(S):
            tiles[i][r][c] = ord(line[r * S + c]) - ord("0")

q = N // S

for i in range(1000):
    tile_id = i % T
    row = ((i // q) * S) % (N - 2)
    col = ((i % q) * S) % (N - 2)

    valid = True
    for r in range(S):
        for c in range(S):
            if tiles[tile_id][r][c] > 0 and grid[row + r][col + c] > 0:
                valid = False
    if not valid:
        continue

    for r in range(S):
        for c in range(S):
            if tiles[tile_id][r][c] > 0:
                grid[row + r][col + c] = tiles[tile_id][r][c]

    print(f"{tile_id} {row} {col}")
    sys.stdout.flush()

    line = input()
    for r in range(S):
        for c in range(S):
            tiles[tile_id][r][c] = ord(line[r * S + c]) - ord("0")

    elapsed_time = int(input())

print("-1")
sys.stdout.flush()
