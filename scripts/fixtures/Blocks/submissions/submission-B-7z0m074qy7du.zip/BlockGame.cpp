//~ while (clock()<=69*CLOCKS_PER_SEC)
//~ #pragma comment(linker, "/stack:200000000")
#pragma GCC optimize("O3")
//~ #pragma GCC target ("avx2")
//~ #pragma GCC optimize("Ofast")
//~ #pragma GCC target("sse,sse2,sse3,ssse3,sse4,popcnt,abm,mmx,avx,tune=native")
//~ #pragma GCC optimize("unroll-loops")
#include <bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>

using namespace __gnu_pbds;
using namespace std;

template <typename T>
using ordered_set =
    tree<T, null_type, less<T>, rb_tree_tag, tree_order_statistics_node_update>;

#define sim template < class c
#define ris return * this
#define dor > debug & operator <<
#define eni(x) sim > typename \
  enable_if<sizeof dud<c>(0) x 1, debug&>::type operator<<(c i) {
sim > struct rge { c b, e; };
sim > rge<c> range(c i, c j) { return rge<c>{i, j}; }
sim > auto dud(c* x) -> decltype(cerr << *x, 0);
sim > char dud(...);
struct debug {
#ifdef LOCAL
~debug() { cerr << endl; }
eni(!=) cerr << boolalpha << i; ris; }
eni(==) ris << range(begin(i), end(i)); }
sim, class b dor(pair < b, c > d) {
  ris << "(" << d.first << ", " << d.second << ")";
}
sim dor(rge<c> d) {
  *this << "[";
  for (auto it = d.b; it != d.e; ++it)
    *this << ", " + 2 * (it == d.b) << *it;
  ris << "]";
}
#else
sim dor(const c&) { ris; }
#endif
};
#define imie(...) " [" << #__VA_ARGS__ ": " << (__VA_ARGS__) << "] "

#define shandom_ruffle random_shuffle

using ll=long long;
using pii=pair<int,int>;
using pll=pair<ll,ll>;
using vi=vector<int>;
using vll=vector<ll>;
const int nax=23;
using ld=long double;
const int inf=1000*100;

//start of time
chrono::time_point<chrono::high_resolution_clock> remembered_time;

void init_time()
{
	remembered_time=chrono::high_resolution_clock::now();
}

ld get_time()
{
	auto now=chrono::high_resolution_clock::now();
	chrono::duration<ld> elapsed=now-remembered_time;
	return elapsed.count();
}
//end of time

struct timer
{
	ld suma=0;
	void start()
	{
		suma-=get_time();
	}
	void stop()
	{
		suma+=get_time();
	}
	void print()
	{
		debug() << imie(suma);
	}
} timers[7];

mt19937 rng(chrono::steady_clock::now().time_since_epoch().count());
//~ mt19937 rng(691);

template <typename T>void szafluj(vector<T> &wek)
{
	shuffle(wek.begin(), wek.end(), rng);
}

template <typename T>T &wylosuj(vector<T> &wek)
{
	return wek[rng()%wek.size()];
}

template <typename T>vector<T> operator +(vector<T> &a, vector<T> &b)
{
	vector<T> ret;
	for (T i : a)
		ret.push_back(i);
	for (T i : b)
		ret.push_back(i);
	return ret;
}

int losuj(int a, int b)
{
	auto gener=uniform_int_distribution<>(a, b);
	return gener(rng);
}

int losuj()
{
	return rng();
}

ld losuj_ld()
{
	static const int lim=1e8;
	return losuj(0, lim)/(ld)lim;
}

void ff()
{
	fflush(stdout);
}

int n, t, c;
ld grid_fill, tile_fill;

int tab[nax][nax];

char wcz[nax];
int tiles[nax][3][3];

int bylo_rund;
ld elapsed_time;

map<int,int> combos;

int fake_tile[nax];

int tab_copies[nax][nax][nax];
int tiles_copies[nax][nax][3][3];
int fake_tile_copies[nax][nax];

vi free_states;

int get_free_state()
{
	assert(!free_states.empty());
	int ret=free_states.back();
	free_states.pop_back();
	return ret;
}

void return_save(int v)
{
	free_states.push_back(v);
}

int save_state()
{
	int v=get_free_state();
	for (int i=0; i<n; i++)
		for (int j=0; j<n; j++)
			tab_copies[v][i][j]=tab[i][j];
	for (int i=0; i<t; i++)
		for (int a=0; a<3; a++)
			for (int b=0; b<3; b++)
				tiles_copies[v][i][a][b]=tiles[i][a][b];
	for (int i=0; i<t; i++)
		fake_tile_copies[v][i]=fake_tile[i];
	return v;
}

void load_state(int v)
{
	for (int i=0; i<n; i++)
		for (int j=0; j<n; j++)
			tab[i][j]=tab_copies[v][i][j];
	for (int i=0; i<t; i++)
		for (int a=0; a<3; a++)
			for (int b=0; b<3; b++)
				tiles[i][a][b]=tiles_copies[v][i][a][b];
	for (int i=0; i<t; i++)
		fake_tile[i]=fake_tile_copies[v][i];
}

int ist(pii v)
{
	return v.first>=0 && v.second>=0 && v.first<n && v.second<n;
}

int ist(int a, int b)
{
	return a>=0 && b>=0 && a<n && b<n;
}

void read_tile(int v)
{
	scanf("%s", wcz);
	for (int i=0; i<3; i++)
		for (int j=0; j<3; j++)
			tiles[v][i][j]=wcz[3*i+j]-'0';
	fake_tile[v]=0;
}

void read_new_tile(int v)
{
	read_tile(v);
	double x;
	scanf("%lf", &x);
	elapsed_time=x;
	bylo_rund++;
	//~ assert(elapsed_time<9900);
	//~ debug() << num << " " << x;
}

void set_random_tile(int v)
{
	int x=losuj(1, c);
	while(1)
	{
		int ok=0;
		for (int i=0; i<3; i++)
		{
			for (int j=0; j<3; j++)
			{
				if (losuj_ld()<tile_fill)
				{
					ok=1;
					tiles[v][i][j]=x;
				}
				else
				{
					tiles[v][i][j]=0;
				}
			}
		}
		if (ok)
			break;
	}
	fake_tile[v]=1;
}

vi branch_limit{3, 2, 1, 1, 1};
int rep_bt=1;
int rep_glo=5;
int branch_glo=7;

void read_and_init()
{
	scanf("%d%d%d", &n, &t, &c);
	double tmp;
	scanf("%lf", &tmp);
	grid_fill=tmp;
	scanf("%lf", &tmp);
	tile_fill=tmp;
	for (int i=0; i<n; i++)
		for (int j=0; j<n; j++)
			scanf("%d", &tab[i][j]);
	
	for (int i=0; i<t; i++)
		read_tile(i);
	for (int i=0; i<nax; i++)
		free_states.push_back(i);
	//~ branch_glo=vi{7, 7, 7, 7, 7}[t-1];
}

int can_be_placed(int v, int a, int b)
{
	for (int i=0; i<3; i++)
		for (int j=0; j<3; j++)
			if (tiles[v][i][j] && (!ist(a+i, b+j) || tab[a+i][b+j]))
				return 0;
	return 1;
}

void just_place(int v, int a, int b)
{
	for (int i=0; i<3; i++)
		for (int j=0; j<3; j++)
			if (tiles[v][i][j])
				tab[a+i][b+j]=tiles[v][i][j];
}

void just_remove(int v, int a, int b)
{
	for (int i=0; i<3; i++)
		for (int j=0; j<3; j++)
			if (tiles[v][i][j])
				tab[a+i][b+j]=0;
}

int in_row[nax];
int in_col[nax];
int det_row[nax][nax];
int det_col[nax][nax];
int cons_row[nax];
int cons_col[nax];

int removed_lines;

int remove_full_lines()
{
	for (int i=0; i<n; i++)
		in_row[i]=in_col[i]=0;
	for (int i=0; i<n; i++)
		for (int j=0; j<n; j++)
			if (tab[i][j])
				in_row[i]++, in_col[j]++;
	vi ile(c+1);
	int pel=0;
	int sk=0;
	for (int i=0; i<n; i++)
	{
		if (in_row[i]==n)
		{
			for (int j=1; j<=c; j++)
				ile[j]=0;
			for (int j=0; j<n; j++)
				ile[tab[i][j]]++;
			int naj=0;
			for (int j=1; j<=c; j++)
				naj=max(naj, ile[j]);
			pel++;
			sk+=naj*naj;
		}
	}
	for (int i=0; i<n; i++)
	{
		if (in_col[i]==n)
		{
			for (int j=1; j<=c; j++)
				ile[j]=0;
			for (int j=0; j<n; j++)
				ile[tab[j][i]]++;
			int naj=0;
			for (int j=1; j<=c; j++)
				naj=max(naj, ile[j]);
			pel++;
			sk+=naj*naj;
		}
	}
	for (int i=0; i<n; i++)
		for (int j=0; j<n; j++)
			if (in_row[i]==n || in_col[j]==n)
				tab[i][j]=0;
	removed_lines=pel;
	return pel*sk;
}

int fast_mask[nax][nax];

vector<pair<ld,vi>> prepare_evals()
{
	//~ timers[3].start();
	for (int i=0; i<n; i++)
	{
		in_row[i]=in_col[i]=cons_row[i]=cons_col[i]=0;
		for (int j=1; j<=c; j++)
			det_row[i][j]=det_col[i][j]=0;
	}
	for (int i=0; i<n; i++)
	{
		for (int j=0; j<n; j++)
		{
			if (tab[i][j])
			{
				in_row[i]++;
				in_col[j]++;
				det_row[i][tab[i][j]]++;
				det_col[j][tab[i][j]]++;
			}
		}
	}
	for (int i=0; i<n; i++)
	{
		int naj=0;
		for (int j=1; j<=c; j++)
			naj=max(naj, det_row[i][j]);
		cons_row[i]=naj*naj;
	}
	for (int i=0; i<n; i++)
	{
		int naj=0;
		for (int j=1; j<=c; j++)
			naj=max(naj, det_col[i][j]);
		cons_col[i]=naj*naj;
	}
	for (int i=0; i<n+2; i++)
		for (int j=0; j<n+2; j++)
			fast_mask[i][j]=(i>=2 && j>=2 && !tab[i-2][j-2]);
	for (int i=n+1; i>=0; i--)
		for (int j=n; j>=0; j--)
			fast_mask[i][j]^=((fast_mask[i][j+1]<<1)&7);
	for (int i=n; i>=0; i--)
		for (int j=n+1; j>=0; j--)
			fast_mask[i][j]^=((fast_mask[i+1][j]<<3)&511);
	vector<pair<ld,vi>> ret;
	int som_real=0;
	for (int i=0; i<t; i++)
		if (!fake_tile[i])
			som_real=1;
	//~ timers[3].stop();
	//~ timers[5].start();
	
	int sta_wsz=0;
	int sta_dob=0;
	int sta_zle=0;
	int sta_sum=0;
	for (int i=0; i<n; i++)
		sta_sum+=cons_row[i]+cons_col[i];
	
	for (int i=0; i<n; i++)
	{
		sta_wsz+=4*in_row[i];
		for (int j=0; j<n; j++)
		{
			if (j+1<n && tab[i][j] && tab[i][j+1])
			{
				if (tab[i][j]==tab[i][j+1])
					sta_dob+=2;
				else
					sta_zle+=2;
			}
			if (i+1<n && tab[i][j] && tab[i+1][j])
			{
				if (tab[i][j]==tab[i+1][j])
					sta_dob+=2;
				else
					sta_zle+=2;
			}
		}
	}
	for (int i=0; i<n; i++)
		sta_dob+=(tab[0][i]>0)+(tab[n-1][i]>0)+(tab[i][0]>0)+(tab[i][n-1]>0);
	
	for (int v=0; v<t; v++)
	{
		if (fake_tile[v] && som_real)
			continue;
		int mas=0;
		for (int a=0; a<3; a++)
			for (int b=0; b<3; b++)
				if (tiles[v][a][b])
					mas|=(1<<(3*a+b));
		for (int i=-2; i<n; i++)
		{
			for (int j=-2; j<n; j++)
			{
				if ((mas&fast_mask[i+2][j+2])!=mas)
					continue;
				
				//~ timers[0].start();
				
				int tu_wsz=sta_wsz;
				int tu_dob=sta_dob;
				int tu_zle=sta_zle;
				
				for (int a=0; a<3; a++)
				{
					for (int b=0; b<3; b++)
					{
						int x=tiles[v][a][b];
						if (!x)
							continue;
						tab[i+a][j+b]=x;
						in_row[i+a]++;
						in_col[j+b]++;
						det_row[i+a][x]++;
						det_col[j+b][x]++;
						
						tu_wsz+=4;
						if (i+a==0)
						{
							tu_dob++;
						}
						else if (tab[i+a-1][j+b])
						{
							if (tab[i+a-1][j+b]==x)
								tu_dob+=2;
							else
								tu_zle+=2;
						}
						if (j+b==0)
						{
							tu_dob++;
						}
						else if (tab[i+a][j+b-1])
						{
							if (tab[i+a][j+b-1]==x)
								tu_dob+=2;
							else
								tu_zle+=2;
						}
						if (i+a==n-1)
						{
							tu_dob++;
						}
						else if (tab[i+a+1][j+b])
						{
							if (tab[i+a+1][j+b]==x)
								tu_dob+=2;
							else
								tu_zle+=2;
						}
						if (j+b==n-1)
						{
							tu_dob++;
						}
						else if (tab[i+a][j+b+1])
						{
							if (tab[i+a][j+b+1]==x)
								tu_dob+=2;
							else
								tu_zle+=2;
						}
					}
				}
				int pel=0;
				int sk=0;
				int sum=sta_sum;
				vi usu_row, usu_col;
				for (int a=max(i, 0); a<=min(i+2, n-1); a++)
				{
					int tu=0;
					for (int l=1; l<=c; l++)
						tu=max(tu, det_row[a][l]);
					if (in_row[a]==n)
					{
						pel++;
						sk+=tu*tu;
						usu_row.push_back(a);
					}
					else
					{
						sum+=tu*tu;
					}
					sum-=cons_row[a];
				}
				for (int b=max(j, 0); b<=min(j+2, n-1); b++)
				{
					int tu=0;
					for (int l=1; l<=c; l++)
						tu=max(tu, det_col[b][l]);
					if (in_col[b]==n)
					{
						pel++;
						sk+=tu*tu;
						usu_col.push_back(b);
					}
					else
					{
						sum+=tu*tu;
					}
					sum-=cons_col[b];
				}
				//~ timers[0].stop();
				
				//~ timers[1].start();
				if (!usu_row.empty())
				{
					for (int b=0; b<n; b++)
					{
						if (b>=j && b<=j+2 && in_col[b]==n)
							continue;
						int tu=0;
						for (int l=1; l<=c; l++)
							tu=max(tu, det_col[b][l]);
						sum-=tu*tu;
						for (int a : usu_row)
						{
							det_col[b][tab[a][b]]--;
							in_col[b]--;
						}
						tu=0;
						for (int l=1; l<=c; l++)
							tu=max(tu, det_col[b][l]);
						sum+=tu*tu;
						for (int a : usu_row)
						{
							det_col[b][tab[a][b]]++;
							in_col[b]++;
						}
					}
					
					
					for (int a : usu_row)
					{
						for (int b=0; b<n; b++)
						{
							tu_wsz-=4;
							int x=tab[a][b];
							if (a==0)
							{
								tu_dob--;
							}
							else if (tab[a-1][b])
							{
								int y=1+(in_row[a-1]!=n && in_col[b]!=n);
								if (tab[a-1][b]==x)
									tu_dob-=y;
								else
									tu_zle-=y;
							}
							if (b==0)
							{
								tu_dob--;
							}
							else if (tab[a][b-1])
							{
								int y=1+(in_row[a]!=n && in_col[b-1]!=n);
								if (tab[a][b-1]==x)
									tu_dob-=y;
								else
									tu_zle-=y;
							}
							if (a==n-1)
							{
								tu_dob--;
							}
							else if (tab[a+1][b])
							{
								int y=1+(in_row[a+1]!=n && in_col[b]!=n);
								if (tab[a+1][b]==x)
									tu_dob-=y;
								else
									tu_zle-=y;
							}
							if (b==n-1)
							{
								tu_dob--;
							}
							else if (tab[a][b+1])
							{
								int y=1+(in_row[a]!=n && in_col[b+1]!=n);
								if (tab[a][b+1]==x)
									tu_dob-=y;
								else
									tu_zle-=y;
							}
						}
					}
				}
				if (!usu_col.empty())
				{
					for (int a=0; a<n; a++)
					{
						if (a>=i && a<=i+2 && in_row[a]==n)
							continue;
						int tu=0;
						for (int l=1; l<=c; l++)
							tu=max(tu, det_row[a][l]);
						sum-=tu*tu;
						for (int b : usu_col)
						{
							det_row[a][tab[a][b]]--;
							in_row[a]--;
						}
						tu=0;
						for (int l=1; l<=c; l++)
							tu=max(tu, det_row[a][l]);
						sum+=tu*tu;
						for (int b : usu_col)
						{
							det_row[a][tab[a][b]]++;
							in_row[a]++;
						}
					}
					
					
					for (int b : usu_col)
					{
						for (int a=0; a<n; a++)
						{
							if (in_row[a]==n)
								continue;
							tu_wsz-=4;
							int x=tab[a][b];
							if (a==0)
							{
								tu_dob--;
							}
							else if (tab[a-1][b])
							{
								int y=1+(in_row[a-1]!=n && in_col[b]!=n);
								if (tab[a-1][b]==x)
									tu_dob-=y;
								else
									tu_zle-=y;
							}
							if (b==0)
							{
								tu_dob--;
							}
							else if (tab[a][b-1])
							{
								int y=1+(in_row[a]!=n && in_col[b-1]!=n);
								if (tab[a][b-1]==x)
									tu_dob-=y;
								else
									tu_zle-=y;
							}
							if (a==n-1)
							{
								tu_dob--;
							}
							else if (tab[a+1][b])
							{
								int y=1+(in_row[a+1]!=n && in_col[b]!=n);
								if (tab[a+1][b]==x)
									tu_dob-=y;
								else
									tu_zle-=y;
							}
							if (b==n-1)
							{
								tu_dob--;
							}
							else if (tab[a][b+1])
							{
								int y=1+(in_row[a]!=n && in_col[b+1]!=n);
								if (tab[a][b+1]==x)
									tu_dob-=y;
								else
									tu_zle-=y;
							}
						}
					}
				}
				//~ timers[1].stop();
				
				for (int a=0; a<3; a++)
				{
					for (int b=0; b<3; b++)
					{
						int x=tiles[v][a][b];
						if (!x)
							continue;
						tab[i+a][j+b]=0;
						in_row[i+a]--;
						in_col[j+b]--;
						det_row[i+a][x]--;
						det_col[j+b][x]--;
					}
				}
				ld ula=1;
				if (tu_wsz>0)
					ula=(tu_dob+0.4*tu_zle)/(ld)tu_wsz;
				ret.push_back({pel*sk+sum*ula, {v, i, j}});
				//~ ret.push_back({pel*sk+sum, {v, i, j}});
			}
		}
	}
	//~ timers[5].stop();
	//~ timers[4].start();
	sort(ret.begin(), ret.end());
	reverse(ret.begin(), ret.end());
	//~ timers[4].stop();
	return ret;
}

int make_move(int v, int a, int b)
{
	just_place(v, a, b);
	int ret=remove_full_lines();
	set_random_tile(v);
	return ret;
}

int make_move(vi wek)
{
	if ((int)wek.size()==3)
		return make_move(wek[0], wek[1], wek[2]);
	set_random_tile(wek[0]);
	return 0;
}

ld curr_value()
{
	//~ timers[2].start();
	for (int i=0; i<n; i++)
	{
		in_row[i]=in_col[i]=0;
		for (int j=1; j<=c; j++)
			det_row[i][j]=det_col[i][j]=0;
	}
	for (int i=0; i<n; i++)
	{
		for (int j=0; j<n; j++)
		{
			if (tab[i][j])
			{
				in_row[i]++;
				in_col[i]++;
				det_row[i][tab[i][j]]++;
				det_col[j][tab[i][j]]++;
			}
		}
	}
	int ret=0;
	for (int i=0; i<n; i++)
	{
		int naj=0;
		for (int j=1; j<=c; j++)
			naj=max(naj, det_row[i][j]);
		ret+=naj*naj;
	}
	for (int i=0; i<n; i++)
	{
		int naj=0;
		for (int j=1; j<=c; j++)
			naj=max(naj, det_col[i][j]);
		ret+=naj*naj;
	}
	//~ timers[2].stop();
	int wsz=0;
	int pary_dobre=0;
	int pary_zle=0;
	for (int i=0; i<n; i++)
	{
		wsz+=4*in_row[i];
		for (int j=0; j<n; j++)
		{
			if (j+1<n && tab[i][j] && tab[i][j+1])
			{
				if (tab[i][j]==tab[i][j+1])
					pary_dobre+=2;
				else
					pary_zle+=2;
			}
			if (i+1<n && tab[i][j] && tab[i+1][j])
			{
				if (tab[i][j]==tab[i+1][j])
					pary_dobre+=2;
				else
					pary_zle+=2;
			}
		}
	}
	for (int i=0; i<n; i++)
		pary_dobre+=(tab[0][i]>0)+(tab[n-1][i]>0)+(tab[i][0]>0)+(tab[i][n-1]>0);
	ld ula=1;
	if (wsz>0)
		ula=(pary_dobre+0.4*pary_zle)/(ld)wsz;
	return ret*ula;
}

//~ template <typename T> void ustaw(vector<T> &wek, int kt)
//~ {
	//~ nth_element(wek.begin(), wek.end()-kt, wek.end());
	//~ reverse(wek.begin(), wek.end());
//~ }

ld bt(int v)
{
	if (v==(int)branch_limit.size())
		return curr_value();
	
	int zapis=save_state();
		
	auto wez=prepare_evals();
	if (wez.empty())
	{
		int g=0;
		while(g<t && !fake_tile[g])
			g++;
		if (g==t)
			g=losuj(0, t-1);
		wez.push_back({0, {g}});
	}
	else
	{
		if ((int)wez.size()>branch_limit[v] && v+1!=(int)branch_limit.size())
		{
			//~ ustaw(wez, branch_limit[v]);
			wez.resize(branch_limit[v]);
		}
	}
	
	ld ret=-inf;
	for (auto i : wez)
	{
		ld tu=0;
		for (int h=0; h<rep_bt; h++)
		{
			if ((int)i.second.size()>1 && v+1==(int)branch_limit.size())
			{
				tu+=i.first;
			}
			else
			{
				tu+=make_move(i.second);
				tu+=bt(v+1);
				load_state(zapis);
			}
		}
		tu/=rep_bt;
		ret=max(ret, tu);
	}
	return_save(zapis);
	return ret;
}

vi run_monte_carlo_tree_search()
{
	auto wez=prepare_evals();
	
	if (t==1 && 0)
	{
		if (wez.empty())
			return vi{losuj(0, t-1)};
		int zapis=save_state();
		
		if ((int)wez.size()>branch_glo)
			wez.resize(branch_glo);
		
		for (int i=0; i<(int)wez.size(); i++)
			wez[i].first=0;
		
		while((int)wez.size()>1)
		{
			for (auto &i : wez)
			{
				for (int h=0; h<rep_glo; h++)
				{
					i.first+=make_move(i.second);
					i.first+=bt(0);
					load_state(zapis);
				}
			}
			sort(wez.begin(), wez.end());
			reverse(wez.begin(), wez.end());
			int r=wez.size();
			wez.resize((r+1)/2);
		}
		
		return_save(zapis);
		return wez[0].second;
	}
	else
	{
		if (t>2)
		{
			if (wez.empty())
				return vi{losuj(0, t-1)};
			int zapis=save_state();
			
			int mno=5;
			if ((int)branch_limit.size()<=3)
				mno=4;
			
			if ((int)wez.size()>branch_glo*mno)
			{
				//~ ustaw(wez, branch_glo*5);
				wez.resize(branch_glo*mno);
			}
			
			auto pam=branch_limit;
			for (int &i : branch_limit)
				i--;
			while(!branch_limit.empty() && !branch_limit.back())
				branch_limit.pop_back();
		
			for (auto &i : wez)
			{
				ld tu=0;
				for (int h=0; h<rep_glo; h++)
				{
					if (branch_limit.empty())
					{
						tu+=i.first;
					}
					else
					{
						tu+=make_move(i.second);
						tu+=bt(0);
						load_state(zapis);
					}
				}
				tu/=rep_glo;
				i.first=tu;
			}
			
			branch_limit=pam;
			
			sort(wez.begin(), wez.end());
			reverse(wez.begin(), wez.end());
			
			if ((int)wez.size()>branch_glo)
				wez.resize(branch_glo);
			
			ld bestocen=-inf;
			vi best;
			for (auto i : wez)
			{
				ld tu=0;
				for (int h=0; h<rep_glo; h++)
				{
					tu+=make_move(i.second);
					tu+=bt(0);
					load_state(zapis);
				}
				tu/=rep_glo;
				if (tu>bestocen)
				{
					bestocen=tu;
					best=i.second;
				}
			}
			return_save(zapis);
			return best;
		}
		else
		{
			int zapis=save_state();
			
			if (t==2)
			{
				if ((int)wez.size()>branch_glo*3)
				{
					//~ ustaw(wez, branch_glo*3);
					wez.resize(branch_glo*3);
				}
				
				auto pam=branch_limit;
				if (!branch_limit.empty())
					branch_limit.pop_back();
				if (!branch_limit.empty())
					branch_limit.pop_back();
			
				for (auto &i : wez)
				{
					ld tu=0;
					for (int h=0; h<rep_glo; h++)
					{
						if (branch_limit.empty())
						{
							tu+=i.first;
						}
						else
						{
							tu+=make_move(i.second);
							tu+=bt(0);
							load_state(zapis);
						}
					}
					tu/=rep_glo;
					i.first=tu;
				}
				
				branch_limit=pam;
				
				sort(wez.begin(), wez.end());
				reverse(wez.begin(), wez.end());
			}
			
			if ((int)wez.size()>branch_glo)
			{
				//~ ustaw(wez, branch_glo);
				wez.resize(branch_glo);
			}
			
			wez.push_back({0, vi{losuj(0, t-1)}});
			
			ld bestocen=-inf;
			vi best;
			for (auto i : wez)
			{
				ld tu=0;
				for (int h=0; h<rep_glo; h++)
				{
					tu+=make_move(i.second);
					tu+=bt(0);
					load_state(zapis);
				}
				tu/=rep_glo;
				if (tu>bestocen)
				{
					bestocen=tu;
					best=i.second;
				}
			}
			return_save(zapis);
			return best;
			
			
			//~ if ((int)wez.size()>branch_glo)
				//~ wez.resize(branch_glo);
			//~ wez.push_back({0, vi{losuj(0, t-1)}});
			//~ int zapis=save_state();
			
			//~ ld bestocen=-inf;
			//~ vi best;
			//~ for (auto i : wez)
			//~ {
				//~ ld tu=0;
				//~ for (int h=0; h<rep_glo; h++)
				//~ {
					//~ tu+=make_move(i.second);
					//~ tu+=bt(0);
					//~ load_state(zapis);
				//~ }
				//~ tu/=rep_glo;
				//~ if (tu>bestocen)
				//~ {
					//~ bestocen=tu;
					//~ best=i.second;
				//~ }
			//~ }
			//~ return_save(zapis);
			//~ return best;
		}
	}
}

int wtry[5];

//~ vector<vi> predykcje;

vi try_to_improve(vi wek)
{
	if (t==1 || bylo_rund>=999)
		return wek;
	int zapis=save_state();
	vi best=wek;
	pair<int,ld> best_val={make_move(wek), (ld)inf};
	load_state(zapis);
	if (!removed_lines)
	{
		return_save(zapis);
		return wek;
	}
	
	pair<int,ld> ori=best_val;
	
	
	vector<vector<pii>> pos(t);
	
	int ile_chce=0;
	
	for (int v=0; v<t; v++)
	{
		if (v==wek[0])
			continue;
		for (int i=-2; i<n; i++)
		{
			for (int j=-2; j<n; j++)
			{
				if (abs(i-wek[1])>2 && abs(j-wek[2])>2)
					continue;
				if (!can_be_placed(v, i, j))
					continue;
				make_move(v, i, j);
				if (removed_lines || !can_be_placed(wek[0], wek[1], wek[2]))
				{
					load_state(zapis);
					continue;
				}
				pos[v].push_back({i, j});
				int wez=make_move(wek);
				ld dru=curr_value();
				if (pair<int,ld>{wez, dru}>best_val)
				{
					best_val={wez, dru};
					best={v, i, j};
					ile_chce=1;
					//~ predykcje={wek};
				}
				load_state(zapis);
			}
		}
	}
	if (t<=2 || bylo_rund>=998)
	{
		//~ if (best_val.first>ori.first)
			//~ debug() << "poprawilem z " << ori << " na " << best_val << " " << imie(ile_chce);
		return_save(zapis);
		return best;
	}
	
	best_val.second=inf;
	
	for (int v1=0; v1<t; v1++)
	{
		if (v1==wek[0])
			continue;
		for (pii p1 : pos[v1])
		{
			make_move(v1, p1.first, p1.second);
			int zapis2=save_state();
			for (int v2=v1+1; v2<t; v2++)
			{
				if (v2==wek[0] || v2==v1)
					continue;
				for (pii p2 : pos[v2])
				{
					if (!can_be_placed(v2, p2.first, p2.second))
						continue;
					make_move(v2, p2.first, p2.second);
					if (removed_lines || !can_be_placed(wek[0], wek[1], wek[2]))
					{
						load_state(zapis2);
						continue;
					}
					int wez=make_move(wek);
					ld dru=curr_value();
					if (pair<int,ld>{wez, dru}>best_val)
					{
						best_val={wez, dru};
						best={v1, p1.first, p1.second};
						ile_chce=2;
						//~ predykcje={wek, {v2, p2.first, p2.second}};
					}
					load_state(zapis2);
				}
			}
			return_save(zapis2);
			load_state(zapis);
		}
	}
	
	
	//~ if (best_val.first>ori.first)
		//~ debug() << "poprawilem z " << ori << " na " << best_val << " " << imie(ile_chce);
	return_save(zapis);
	return best;
}

void plan_move()
{
	if (elapsed_time>9930)
	{
		//~ assert(0);
		printf("-1\n");
		ff();
		exit(0);
	}
	vi best=run_monte_carlo_tree_search();
	//~ vi best;
	//~ if (!predykcje.empty())
	//~ {
		//~ best=predykcje.back();
		//~ predykcje.pop_back();
	//~ }
	//~ else
	//~ {
		//~ best=run_monte_carlo_tree_search();
	//~ }
	
	int v;
	if ((int)best.size()==3)
	{
		//~ if (predykcje.empty())
			//~ best=try_to_improve(best);
		
		best=try_to_improve(best);
		v=best[0];
		int a=best[1];
		int b=best[2];
		printf("%d %d %d\n", v, a, b);
		ff();
		just_place(v, a, b);
		remove_full_lines();
	}
	else
	{
		v=best[0];
		printf("%d\n", v);
		ff();
	}
	read_new_tile(v);
	
	if (t<=2)
	{
		if (t==2)
		{
			if (elapsed_time<bylo_rund*9.75)
			{
				if (elapsed_time<bylo_rund*8)
				{
					rep_bt=2;
					rep_glo=4;
					branch_limit={3, 2, 1, 1, 1, 1};
					wtry[0]++;
				}
				else
				{
					rep_bt=2;
					rep_glo=4;
					branch_limit={2, 1, 1, 1};
					wtry[1]++;
				}
			}
			else
			{
				rep_bt=2;
				rep_glo=4;
				branch_limit={1, 1};
				wtry[2]++;
			}
		}
		if (t==1)
		{
			//~ branch_glo=15;
			//~ rep_bt=5;
			//~ branch_limit={1};
			//~ rep_glo=10;
			
			if (elapsed_time<bylo_rund*9.75)   //znacznik
			{
				if (elapsed_time<bylo_rund*9)
				{
					if (elapsed_time<bylo_rund*8)
					{
						if (elapsed_time<bylo_rund*6)
						{
							//~ branch_glo=50;
							//~ branch_limit={1};
							//~ rep_bt=1;
							//~ rep_glo=70;
							//~ wtry[0]++;
							branch_glo=25;
							branch_limit={2, 1};
							rep_bt=10;
							rep_glo=70;
							wtry[0]++;
						}
						else
						{
							//~ branch_glo=25;
							//~ branch_limit={3, 1};
							//~ rep_bt=7;
							//~ rep_glo=40;
							//~ wtry[0]++;
							
							
							branch_glo=25;
							branch_limit={1};
							rep_bt=1;
							rep_glo=70;
							wtry[1]++;
						}
					}
					else
					{
						branch_glo=20;
						branch_limit={1};
						rep_bt=1;
						rep_glo=40;
						wtry[2]++;
					}					
				}
				else
				{
					branch_glo=10;
					branch_limit={1};
					rep_bt=1;
					rep_glo=25;
					wtry[3]++;
				}
			}
			else
			{
				branch_glo=7;
				branch_limit={1};
				rep_bt=1;
				rep_glo=15;
				wtry[4]++;
			}
		}
	}
	else
	{
		//~ if (elapsed_time<bylo_rund*9.75)
		//~ {
			//~ if (elapsed_time<bylo_rund*8)
			//~ {
				//~ branch_limit={5, 4, 3, 2, 1, 1, 1};
				//~ wtry[0]++;
			//~ }
			//~ else
			//~ {
				//~ branch_limit={3, 3, 2, 1, 1, 1};
				//~ wtry[1]++;
			//~ }
		//~ }
		//~ else
		//~ {
			//~ branch_limit={2, 1, 1};
			//~ wtry[2]++;
		//~ }
		if (elapsed_time<bylo_rund*9.8)
		{
			if (elapsed_time<bylo_rund*9.6)
			{
				if (elapsed_time<bylo_rund*9)
				{
					if (elapsed_time<bylo_rund*8)
					{
						branch_limit={5, 4, 3, 2, 1, 1, 1};
						wtry[0]++;
					}
					else
					{
						branch_limit={3, 3, 2, 1, 1, 1};
						wtry[1]++;
					}
				}
				else
				{
					branch_limit={3, 2, 1, 1, 1};
					wtry[2]++;
				}
			}
			else
			{
				branch_limit={2, 1, 1};
				wtry[3]++;
			}
		}
		else
		{
			branch_limit={1};
			wtry[4]++;
		}
	}
	
	if (bylo_rund!=1000 && 1000-bylo_rund-1<(int)branch_limit.size())
		branch_limit.resize(1000-bylo_rund-1);
}

int main()
{
	init_time();
	read_and_init();
	for (int h=0; h<1000; h++)
		plan_move();
	debug() << "Time: " << get_time();
	debug() << imie(n) << " " << imie(c) << " " << imie(t) << imie(tile_fill);
	debug() << range(wtry, wtry+5);
	//~ for (int i=0; i<7; i++)
		//~ timers[i].print();
	return 0;
}

//~ Average: 18202.005000
//~ Average: 24558.667000
//~ Average: 26184.721000
//~ Average: 26440.211000
//~ Average: 30207.428000
//~ Average: 30234.845000
//~ Average: 31206.416000
//~ Average: 31474.596000
//~ Average: 31583.242000
//~ Average: 31710.274000
//~ Average: 31903.727000
//~ Average: 32634.300000
//~ Average: 33260.394000
//~ Average: 33391.215000
//~ Average: 33809.696000
//~ Average: 33883.500000
//~ Average: 34789.722000 - 1.0 (final guide search)
//~ Average: 35504.720000 - 0.7 (final guide search)
//~ Average: 35707.182000 - 0.5 (final guide search)
//~ Average: 35749.559000 - 0.3 (final guide search)
//~ Average: 36220.595000 - 0.7 (total guide search)
//~ Average: 36560.577000 - 0.5 (total guide search)
//~ Average: 36506.440000 - 0.5 (total guide search) with fix on eval sums and bt speedups
//~ Average: 36247.606000 - 0.7 (total guide search) with fix on eval sums and bt speedups
//~ Average: 36631.259000 - 0.4 (total guide search) with fix on eval sums and bt speedups
//~ Average: 36764.389000 - single improvement
//~ Average: 37006.831000 - double improvement
//~ Average: 37215.454000 - double improvement faster
//~ Average: 36941.760000 - meh
//~ Average: 37764.409000 - wincyj rzarzniec



//~ Average: 25282.944000 - sony 7 branch_glo
//~ Average: 27149.042000 - saved
//~ Average: 28732.270000
//~ Average: 28718.862000 - without current 0 mode
//~ Average: 28752.332000 - chyba aktualne

//~ Average: 37766.348000 - bez ratowania
//~ Average: 37941.215000 - najnowsze
//~ Average: 37952.827000 - najnowsze
//~ Average: 38167.434000
