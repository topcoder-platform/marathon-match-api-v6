import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.TimeUnit;

public class BlockGame
{
  public static void main(String[] args) throws Exception
  {
    verifyChildProcessCannotCreateInetSocket();

    BufferedReader in = new BufferedReader(new InputStreamReader(System.in));

    int N=Integer.parseInt(in.readLine());
    int T=Integer.parseInt(in.readLine());
    int C=Integer.parseInt(in.readLine());
    double F=Double.parseDouble(in.readLine());
    double P=Double.parseDouble(in.readLine());

    //read grid
    int[][] grid=new int[N][N];
    for (int r=0; r<N; r++)
      for (int c=0; c<N; c++)
        grid[r][c]=Integer.parseInt(in.readLine());

    //read tiles
    int S=3;
    int[][][] tiles=new int[T][S][S];
    for (int i=0; i<T; i++)
    {
      String line=in.readLine();
      for (int r=0; r<S; r++)
        for (int c=0; c<S; c++)
          tiles[i][r][c]=(int)(line.charAt(r*S+c)-'0');
    }


    int q=N/S;

    for (int i=0; i<1000; i++)
    {
      int id=i%T;
      int r=((i/q)*S)%(N-2);
      int c=((i%q)*S)%(N-2);

      // check for a valid move
      boolean valid = true;
      for (int r2=0; r2<S; r2++)
        for (int c2=0; c2<S; c2++)
          if (tiles[id][r2][c2]>0 && grid[r+r2][c+c2]>0) valid = false;
      if (!valid) continue;

      // place tile
      for (int r2=0; r2<S; r2++)
        for (int c2=0; c2<S; c2++)
          if (tiles[id][r2][c2]>0)
            grid[r+r2][c+c2] = tiles[id][r2][c2];

      //print move
      System.out.println(id+" "+r+" "+c);
      System.out.flush();

      //read tile
      String line=in.readLine();
      for (int r2=0; r2<S; r2++)
        for (int c2=0; c2<S; c2++)
          tiles[id][r2][c2]=(int)(line.charAt(r2*S+c2)-'0');

      int elapsedTime=Integer.parseInt(in.readLine());
    }
    //terminate
    System.out.println("-1");
    System.out.flush();
  }

  private static void verifyChildProcessCannotCreateInetSocket() throws Exception
  {
    String probe = "import errno,socket,sys\n"
      + "try:\n"
      + "    s=socket.socket(socket.AF_INET,socket.SOCK_STREAM)\n"
      + "except PermissionError as e:\n"
      + "    sys.exit(0 if e.errno==errno.EPERM else 3)\n"
      + "except OSError:\n"
      + "    sys.exit(2)\n"
      + "else:\n"
      + "    s.close()\n"
      + "    print('AF_INET socket allowed after LD_PRELOAD removal', file=sys.stderr)\n"
      + "    sys.exit(82)\n";

    ProcessBuilder builder = new ProcessBuilder("python3", "-c", probe);
    builder.environment().remove("LD_PRELOAD");
    builder.redirectErrorStream(true);

    Process process = builder.start();
    String output = readAll(process.getInputStream());
    if (!process.waitFor(3, TimeUnit.SECONDS)) {
      process.destroyForcibly();
      throw new SecurityException("Issue #82 regression probe timed out.");
    }

    if (process.exitValue() != 0) {
      throw new SecurityException(
        "Issue #82 regression probe failed; child process network socket was not blocked. Output: "
          + output
      );
    }
  }

  private static String readAll(InputStream stream) throws IOException
  {
    ByteArrayOutputStream buffer = new ByteArrayOutputStream();
    byte[] chunk = new byte[1024];
    int count;
    while ((count = stream.read(chunk)) != -1) {
      buffer.write(chunk, 0, count);
    }
    return new String(buffer.toByteArray(), StandardCharsets.UTF_8);
  }
}
