#include <atomic>
#include <csignal>

std::atomic<unsigned long long> spin_counter{0};

int main() {
  std::signal(SIGTERM, SIG_IGN);

  while (true) {
    spin_counter.fetch_add(1, std::memory_order_relaxed);
  }

  return 0;
}
