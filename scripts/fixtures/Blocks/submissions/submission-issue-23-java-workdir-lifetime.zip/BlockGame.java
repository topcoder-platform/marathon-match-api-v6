import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;

public class BlockGame {
    private static final int TILE_SIZE = 3;

    public static void main(String[] args) throws Exception {
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        PrintWriter output = new PrintWriter(System.out, true);

        int n = Integer.parseInt(input.readLine().trim());
        int tileCount = Integer.parseInt(input.readLine().trim());
        input.readLine();
        input.readLine();
        input.readLine();

        int[][] grid = new int[n][n];
        for (int row = 0; row < n; row++) {
            for (int col = 0; col < n; col++) {
                grid[row][col] = Integer.parseInt(input.readLine().trim());
            }
        }

        int[][][] tiles = new int[tileCount][TILE_SIZE][TILE_SIZE];
        for (int tile = 0; tile < tileCount; tile++) {
            tiles[tile] = readTile(input.readLine());
        }

        int placementsPerRow = Math.max(1, n / TILE_SIZE);
        for (int turn = 0; turn < 1000; turn++) {
            int tileId = turn % tileCount;
            int row = ((turn / placementsPerRow) * TILE_SIZE) % (n - 2);
            int col = ((turn % placementsPerRow) * TILE_SIZE) % (n - 2);

            if (!canPlace(grid, tiles[tileId], row, col)) {
                continue;
            }

            place(grid, tiles[tileId], row, col);
            output.println(tileId + " " + row + " " + col);
            output.flush();

            tiles[tileId] = readTile(input.readLine());
            input.readLine();
        }

        output.println("-1");
        output.flush();
    }

    private static int[][] readTile(String rawTile) {
        int[][] tile = new int[TILE_SIZE][TILE_SIZE];
        for (int row = 0; row < TILE_SIZE; row++) {
            for (int col = 0; col < TILE_SIZE; col++) {
                tile[row][col] = rawTile.charAt(row * TILE_SIZE + col) - '0';
            }
        }
        return tile;
    }

    private static boolean canPlace(int[][] grid, int[][] tile, int row, int col) {
        for (int tileRow = 0; tileRow < TILE_SIZE; tileRow++) {
            for (int tileCol = 0; tileCol < TILE_SIZE; tileCol++) {
                if (tile[tileRow][tileCol] > 0 && grid[row + tileRow][col + tileCol] > 0) {
                    return false;
                }
            }
        }
        return true;
    }

    private static void place(int[][] grid, int[][] tile, int row, int col) {
        for (int tileRow = 0; tileRow < TILE_SIZE; tileRow++) {
            for (int tileCol = 0; tileCol < TILE_SIZE; tileCol++) {
                if (tile[tileRow][tileCol] > 0) {
                    grid[row + tileRow][col + tileCol] = tile[tileRow][tileCol];
                }
            }
        }
    }
}
