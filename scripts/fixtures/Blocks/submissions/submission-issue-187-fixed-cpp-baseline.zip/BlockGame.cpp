#if defined(__AVX__) || defined(__AVX2__) || defined(__AVX512F__) || \
    defined(__BMI__) || defined(__BMI2__) || defined(__FMA__) || \
    defined(__F16C__) || defined(__AES__) || defined(__PCLMUL__) || \
    defined(__POPCNT__) || defined(__SSE3__) || defined(__SSSE3__) || \
    defined(__SSE4_1__) || defined(__SSE4_2__)
#error "C++ submissions must be compiled with the fixed x86-64 baseline target, not native host ISA extensions."
#endif

#include <iostream>
#include <string>

int main() {
    std::ios::sync_with_stdio(false);
    std::cin.tie(nullptr);

    int n = 0;
    int t = 0;
    int c = 0;
    double f = 0.0;
    double p = 0.0;

    if (!(std::cin >> n >> t >> c >> f >> p)) {
        return 0;
    }

    int cell = 0;
    for (int i = 0; i < n * n; ++i) {
        std::cin >> cell;
    }

    std::string tile;
    for (int i = 0; i < t; ++i) {
        std::cin >> tile;
    }

    std::cout << -1 << std::endl;
    return 0;
}
