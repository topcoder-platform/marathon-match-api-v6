public class BlockGame {
    static {
        try {
            Thread.sleep(Long.MAX_VALUE);
        } catch (InterruptedException ignored) {
            Thread.currentThread().interrupt();
        }
    }

    public static void main(String[] args) {
    }
}
