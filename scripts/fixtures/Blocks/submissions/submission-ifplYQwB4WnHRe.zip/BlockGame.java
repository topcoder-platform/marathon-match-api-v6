import java.io.*;
import java.util.*;

public class BlockGame {
    private static int n, numTiles, numFruits, rowsPerFruit, tileFillRatio, maxCellVal, turn;
    private static boolean[] canMemo;
    private static int[] cellVal, allTilesWeight, aux = new int[9], bonus;
    private static int[] grid, tileFruit, colCount, rowCount, tileXMin, tileXMax, tileYMin, tileYMax;
    private static int[][] tiles, allTiles, tileOffsets;
    private static BufferedReader in;
    private static final long timeLimit1 = 9000, timeLimit2 = 9500;
    private static final int[] xrem = new int[32], yrem = new int[32];
    private static final SplittableRandom rnd = new SplittableRandom(999);
    private static int[] countPerFruit;

    public static void main(String[] args) throws Exception {
        init();
        play();
    }

    private static int evalPlace(int x0, int y0, int[] ti, int idx, boolean fast, boolean full, boolean mid) {
        if (!canPlace(x0, y0, ti, idx)) return -1;
        return eval(x0, y0, ti, idx, fast, full, mid);
    }

    private static boolean canPlace(int x0, int y0, int[] ti, int idx) {
        if (idx >= 0 && !canMemo[key(x0, y0, idx)]) return false;
        int x1 = x0 + 2;
        int y1 = y0 + 2;
        int pos = 0;
        for (int y = y0; y <= y1; y++) {
            int p = pos(x0, y);
            for (int x = x0; x <= x1; x++, pos++, p++) {
                if (ti[pos] == 0) continue;
                if (y < 0 || y >= n || x < 0 || x >= n) return false;
                if (grid[p] != 0) return false;
            }
        }
        return true;
    }

    private static boolean canPlace(int x0, int y0, int idx) {
        if (idx >= 0 && !canMemo[key(x0, y0, idx)]) return false;
        int[] t = tileOffsets[idx];
        int p = pos(x0, y0);
        for (int d : t) {
            if (grid[p + d] != 0) return false;
        }
        return true;
    }

    private static void add(int x0, int y0, int[] ti, int w) {
        int x1 = x0 + 2;
        int y1 = y0 + 2;
        int pos = 0;
        for (int y = y0; y <= y1; y++) {
            int p = pos(x0, y);
            for (int x = x0; x <= x1; x++, pos++, p++) {
                if (ti[pos] == 0) continue;
                cellVal[p] += w;
            }
        }
    }

    private static int eval(int x0, int y0, int[] ti, int idx, boolean fast, boolean full, boolean mid) {
        int x1 = x0 + 2;
        int y1 = y0 + 2;
        int pos = 0;
        int ret = 0;
        int type = tileFruit[idx];
        int clear = 0;
        for (int y = y0; y <= y1; y++) {
            int cnt = 0;
            if (y >= 0 && y < n && bonus[y] == type) {
                for (int x = 0; x < n; x++) {
                    if (grid[pos(x, y)] == type) cnt++;
                }
            }
            int hit = 0;
            for (int x = x0; x <= x1; x++, pos++) {
                if (ti[pos] == 0) continue;
                int p = pos(x, y);
                grid[p] = type;
                if (++colCount[x] == n) clear++;
                if (++rowCount[y] == n) clear++;
                ret += maxCellVal - cellVal[p];
                if (numFruits > 1 && bonus[y] == type) {
                    cnt++;
                    hit++;
                }
                ret += Math.max(n - 1 - x, x);
            }
            ret += 20000 * cnt * hit;
        }
        for (int y = y0; y <= y1; y++) {
            if (y < 0 || y >= n) continue;
            int miss = n - rowCount[y];
            ret += n - miss;
            if (miss == 0) {
                Arrays.fill(countPerFruit, 0);
                int m = 0;
                for (int x = 0; x < n; x++) {
                    int v = ++countPerFruit[grid[pos(x, y)]];
                    if (v > m) m = v;
                }
                if (clear == 1) m = 1;
                ret += 20000 * m * m * clear;
            }
        }
        for (int x = x0; x <= x1; x++) {
            if (x < 0 || x >= n) continue;
            int miss = n - colCount[x];
            ret += n - miss;
            if (miss == 0) {
                Arrays.fill(countPerFruit, 0);
                int m = 0;
                for (int y = 0; y < n; y++) {
                    int v = ++countPerFruit[grid[pos(x, y)]];
                    if (v > m) m = v;
                }
                if (clear == 1) m = 1;
                ret += 10000 * m * m * clear;
            }
        }

        if (clear == 0 && numTiles <= 3 && ((mid && n <= 12) || full) && !fast) {
            for (int i = 0; i < allTiles.length; i++) {
                int w = allTilesWeight[i];
                if (w < 50) continue;
                int ii = i + numTiles;
                int[] ato = tileOffsets[ii];
                int ymin = tileYMin[ii];
                int ymax = tileYMax[ii];
                int xmin = tileXMin[ii];
                int xmax = tileXMax[ii];
                int mc = 0;
                for (int y = ymin; y <= ymax; y++) {
                    for (int x = xmin; x <= xmax; x++) {
                        if (canPlace(x, y, ii)) {
                            int pp = pos(x, y);
                            int clear2 = 0;
                            for (int d : ato) {
                                int pd = pp + d;
                                if (++colCount[x(pd)] == n) clear2++;
                                if (++rowCount[y(pd)] == n) clear2++;
                            }
                            if (clear2 > mc) mc = clear2;
                            for (int d : ato) {
                                int pd = pp + d;
                                colCount[x(pd)]--;
                                rowCount[y(pd)]--;
                            }

                        }
                    }
                }
                if (mc > 1) ret += mc * mc * w * 10;
            }
        }

        if (tileFillRatio <= 30 - numFruits) {
            if (clear >= 3) ret += clear * 100000000;
            else if (clear >= 1) {
                if (clear == 2) ret -= 1;
                else if (turn <= 1000 - n) ret -= 100000000 * clear;
                else ret += 100000000 * clear;
            }
        } else {
            if (clear >= 2) ret += clear * 100000000;
            else if (clear >= 1) {
                if (tileFillRatio > 45 || turn > 1000 - n) ret += 100000000;
                else if (tileFillRatio <= 40) ret -= 100000000;
            }
        }
        if (!fast && mid && turn < 999) {
            if (clear == 0 && numTiles > 1 && (full || tileFillRatio - n > 10)) {
                int mc = 0;
                int mc2 = 0;
                boolean ho = false;
                for (int i = 0; i < numTiles; i++) {
                    if (i == idx) continue;
                    int[] to = tileOffsets[i];
                    if (to.length == 1) {
                        if (ho) continue;
                        ho = true;
                    }
                    boolean ok = false;
                    int ymin = tileYMin[i];
                    int ymax = tileYMax[i];
                    int xmin = tileXMin[i];
                    int xmax = tileXMax[i];
                    for (int y = ymin; y <= ymax; y++) {
                        for (int x = xmin; x <= xmax; x++) {
                            if (canPlace(x, y, i)) {
                                int pp = pos(x, y);
                                clear = 0;
                                for (int d : to) {
                                    int pd = pp + d;
                                    grid[pd] = 1;
                                    if (++colCount[x(pd)] == n) clear++;
                                    if (++rowCount[y(pd)] == n) clear++;
                                }
                                if (clear > mc) mc = clear;
                                if (n <= 15 && clear == 0 && (full || n <= 10)) {
                                    boolean ho2 = false;
                                    for (int j = 0; j < numTiles; j++) {
                                        if (j == idx || j == i) continue;
                                        int ymin2 = tileYMin[j];
                                        int ymax2 = tileYMax[j];
                                        int xmin2 = tileXMin[j];
                                        int xmax2 = tileXMax[j];
                                        int[] to2 = tileOffsets[j];
                                        if (to2.length == 1) {
                                            if (ho2) continue;
                                            ho2 = true;
                                        }
                                        for (int y2 = ymin2; y2 <= ymax2; y2++) {
                                            for (int x2 = xmin2; x2 <= xmax2; x2++) {
                                                if (canPlace(x2, y2, j)) {
                                                    int pp2 = pos(x2, y2);
                                                    clear = 0;
                                                    for (int d : to2) {
                                                        int pd = pp2 + d;
                                                        if (++colCount[x(pd)] == n) clear++;
                                                        if (++rowCount[y(pd)] == n) clear++;
                                                    }
                                                    if (clear > mc2) mc2 = clear;
                                                    for (int d : to2) {
                                                        int pd = pp2 + d;
                                                        colCount[x(pd)]--;
                                                        rowCount[y(pd)]--;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                                for (int d : to) {
                                    int pd = pp + d;
                                    grid[pd] = 0;
                                    colCount[x(pd)]--;
                                    rowCount[y(pd)]--;
                                }
                                ok = true;
                            }
                        }
                    }
                    if (ok) ret += 100000;
                }
                if (mc2 > mc && turn < 998) {
                    if (mc2 >= 2) ret += mc2 * 80000000;
                    else if (mc2 > 0) ret += 800000;
                } else {
                    if (mc >= 2) ret += mc * 90000000;
                    else if (mc > 0) ret += 900000;
                }
            } else if (clear == 0 && tileFillRatio > 40 && numTiles > 1) {
                for (int i = 0; i < numTiles; i++) {
                    if (i == idx) continue;
                    boolean ok = false;
                    for (int y = -2; y < n; y++) {
                        for (int x = -2; x < n; x++) {
                            if (canPlace(x, y, i)) {
                                ok = true;
                                ret += 1000;
                            }
                        }
                    }
                    if (ok) ret += 100000;
                }
            }
        }
        pos = 0;
        for (int y = y0; y <= y1; y++) {
            for (int x = x0; x <= x1; x++, pos++) {
                if (y < 0 || y >= n || x < 0 || x >= n) continue;
                if (ti[pos] == 0) continue;
                grid[pos(x, y)] = 0;
                colCount[x]--;
                rowCount[y]--;
            }
        }
        return ret;
    }

    private static void place(int x0, int y0, int[] ti, int tileIdx) {
        System.out.println(tileIdx + " " + y0 + " " + x0);
        System.out.flush();
        int x1 = x0 + 2;
        int y1 = y0 + 2;
        int idx = 0;
        for (int y = y0; y <= y1; y++) {
            for (int x = x0; x <= x1; x++, idx++) {
                if (y < 0 || y >= n || x < 0 || x >= n) continue;
                if (ti[idx] == 0) continue;
                grid[pos(x, y)] = ti[idx];
                colCount[x]++;
                rowCount[y]++;
            }
        }

        int ny = 0;
        NEXT: for (int y = y0; y <= y1; y++) {
            if (y < 0 || y >= n) continue;
            for (int x = 0; x < n; x++) {
                if (grid[pos(x, y)] == 0) continue NEXT;
            }
            yrem[ny++] = y;
        }
        int nx = 0;
        NEXT: for (int x = x0; x <= x1; x++) {
            if (x < 0 || x >= n) continue;
            for (int y = 0; y < n; y++) {
                if (grid[pos(x, y)] == 0) continue NEXT;
            }
            xrem[nx++] = x;
        }
        for (int i = 0; i < ny; i++) {
            int y = yrem[i];
            for (int x = 0; x < n; x++) {
                grid[pos(x, y)] = 0;
                colCount[x]--;
                rowCount[y]--;
            }
        }
        for (int i = 0; i < nx; i++) {
            int x = xrem[i];
            for (int y = 0; y < n; y++) {
                int p = pos(x, y);
                if (grid[p] != 0) {
                    grid[p] = 0;
                    colCount[x]--;
                    rowCount[y]--;
                }
            }
        }
    }

    private static void play() throws Exception {
        Integer[] ord = new Integer[numTiles];
        for (int i = 0; i < numTiles; i++) {
            ord[i] = i;
        }
        boolean fast = false;
        int[][] cc = new int[n][numFruits + 1];
        int[] sa = new int[numFruits];
        int fail = 0;
        for (turn = 0; turn < 1000; turn++) {
            Arrays.sort(ord, new Comparator<Integer>() {
                public int compare(Integer a, Integer b) {
                    return tileOffsets[b].length - tileOffsets[a].length;
                }
            });
            boolean full = false;
            boolean mid = false;
            Arrays.fill(canMemo, true);
            Arrays.fill(cellVal, 0);
            int idx = 0;
            for (int[] ti : tiles) {
                for (int y = -2; y < n; y++) {
                    for (int x = -2; x < n; x++) {
                        if (canPlace(x, y, ti, -1)) add(x, y, ti, 4000);
                        else canMemo[key(x, y, idx)] = false;
                    }
                }
                idx++;
            }

            if (numFruits > 1) {
                int max = -1;
                int[] setup = new int[n];
                int rem = n - rowsPerFruit * numFruits;
                for (int y = 0; y < n; y++) {
                    int[] cy = cc[y];
                    Arrays.fill(cy, 0);
                    for (int x = 0; x < n; x++) {
                        cy[grid[pos(x, y)]]++;
                    }
                }
                for (int mask = 0; mask < 1 << numFruits; mask++) {
                    if (Integer.bitCount(mask) != rem) continue;
                    for (int i = 0; i < sa.length; i++) {
                        sa[i] = i + 1;
                    }
                    int q = 0;
                    int bin = -1;
                    int target = 0;
                    for (int y = 0; y < n; y++) {
                        if (q == target) {
                            bin++;
                            target = rowsPerFruit;
                            if ((mask & (1 << bin)) != 0) target++;
                            q = 0;
                        }
                        setup[y] = bin;
                        q++;
                    }
                    do {
                        int curr = 0;
                        for (int y = 0; y < n; y++) {
                            int k = cc[y][sa[setup[y]]];
                            curr += k * k;
                        }
                        if (curr > max) {
                            max = curr;
                            for (int y = 0; y < n; y++) {
                                bonus[y] = sa[setup[y]];
                            }
                        }
                    } while (nextPermutation(sa));
                }
            }
            if (!fast) {
                int k = 0;
                for (int[] ti : allTiles) {
                    int w = allTilesWeight[k];
                    if (w > 0) {
                        for (int y = -2; y < n; y++) {
                            for (int x = -2; x < n; x++) {
                                if (canPlace(x, y, ti, -1)) add(x, y, ti, w);
                                else canMemo[key(x, y, k + numTiles)] = false;
                            }
                        }
                    }
                    k++;
                }
                maxCellVal = 0;
                for (int i : cellVal) {
                    if (i > maxCellVal) maxCellVal = i;
                }
                int cnt = 0;
                for (int i : grid) {
                    if (i > 0) cnt++;
                }
                full = cnt > n * n * 4 / 5 - 20;
                mid = cnt > n * n * 2 / 3 - 20;
            }
            int bi = -1;
            int bx = -1;
            int by = -1;
            int max = fail > 4 ? 0 : 10000;
            for (int i : ord) {
                int[] ti = tiles[i];
                for (int y = -2; y < n; y++) {
                    for (int x = -2; x < n; x++) {
                        int curr = evalPlace(x, y, ti, i, fast, full, mid);
                        if (curr > max) {
                            max = curr;
                            bx = x;
                            by = y;
                            bi = i;
                        }
                    }
                }
            }
            if (bi == -1) {
                fail++;
                bi = ord[0];
                System.out.println(bi);
                System.out.flush();
            } else {
                int[] ti = tiles[bi];
                place(bx, by, ti, bi);
                fail = 0;
            }
            int[] ti = tiles[bi];
            String line = in.readLine();
            for (int j = 0; j < 9; j++) {
                int tij = ti[j] = line.charAt(j) - '0';
                if (tij != 0) tileFruit[bi] = tij;
            }
            updateTile(bi);
            int elapsedTime = Integer.parseInt(in.readLine());
            if (elapsedTime > timeLimit1) fast = true;
            if (elapsedTime > timeLimit2) break;
        }
        System.out.println("-1");
        System.out.flush();
        in.close();
    }

    private static int x(int p) {
        return (p & 31) - 2;
    }

    private static int y(int p) {
        return (p >>> 5) - 2;
    }

    private static int pos(int x, int y) {
        return ((y + 2) << 5) | (x + 2);
    }

    private static int key(int x, int y, int idx) {
        return (pos(x, y) << 10) | idx;
    }

    private static void init() throws Exception {
        in = new BufferedReader(new InputStreamReader(System.in));
        n = Integer.parseInt(in.readLine());
        numTiles = Integer.parseInt(in.readLine());
        numFruits = Integer.parseInt(in.readLine());
        Double.parseDouble(in.readLine());
        double tfr = Double.parseDouble(in.readLine());
        tileFillRatio = (int) Math.round(100 * tfr);
        grid = new int[(n + 2) << 5];
        colCount = new int[n];
        rowCount = new int[n];
        for (int y = 0; y < n; y++) {
            for (int x = 0; x < n; x++) {
                int g = grid[pos(x, y)] = Integer.parseInt(in.readLine());
                if (g != 0) {
                    colCount[x]++;
                    rowCount[y]++;
                }
            }
        }
        tileFruit = new int[numTiles];
        tiles = new int[numTiles][9];
        for (int i = 0; i < numTiles; i++) {
            String line = in.readLine();
            int[] ti = tiles[i];
            for (int j = 0; j < 9; j++) {
                int tij = ti[j] = line.charAt(j) - '0';
                if (tij != 0) tileFruit[i] = tij;
            }
        }
        allTiles = new int[511][9];
        for (int i = 0; i < allTiles.length; i++) {
            int mask = i + 1;
            int[] ti = allTiles[i];
            for (int j = 0; j < 9; j++) {
                if (((1 << j) & mask) != 0) ti[j] = 1;
            }
        }
        allTilesWeight = new int[511];
        for (int i = 0; i < 40000; i++) {
            int mask = 0;
            for (int j = 0; j < 9; j++) {
                if (rnd.nextDouble() < tfr) mask |= 1 << j;
            }
            if (mask != 0) allTilesWeight[mask - 1]++;
        }
        rowsPerFruit = n / numFruits;
        cellVal = new int[grid.length];
        countPerFruit = new int[numFruits + 1];
        canMemo = new boolean[grid.length << 10];
        tileXMin = new int[numTiles + allTiles.length];
        tileXMax = new int[numTiles + allTiles.length];
        tileYMin = new int[numTiles + allTiles.length];
        tileYMax = new int[numTiles + allTiles.length];
        tileOffsets = new int[numTiles + allTiles.length][];
        for (int i = 0; i < numTiles + allTiles.length; i++) {
            updateTile(i);
        }
        for (int i = 0; i < allTiles.length; i++) {
            int x = tileXMin[i + numTiles];
            int[] ti = tileOffsets[i + numTiles];
            if (x == -2) {
                for (int j = 0; j < ti.length; j++) {
                    ti[j] -= 2;
                }
            } else if (x == -1) {
                for (int j = 0; j < ti.length; j++) {
                    ti[j] -= 1;
                }
            }
            int y = tileYMin[i + numTiles];
            if (y == -2) {
                for (int j = 0; j < ti.length; j++) {
                    ti[j] -= 64;
                }
            } else if (y == -1) {
                for (int j = 0; j < ti.length; j++) {
                    ti[j] -= 32;
                }
            }
            if (x != 0 || y != 0) {
                NEXT: for (int j = 0; j < allTiles.length; j++) {
                    if (i == j) continue;
                    int[] tj = tileOffsets[j + numTiles];
                    if (tj.length == ti.length) {
                        for (int k = 0; k < tj.length; k++) {
                            if (ti[k] != tj[k]) continue NEXT;
                        }
                        allTilesWeight[j] += allTilesWeight[i];
                        allTilesWeight[i] = 0;
                        break;
                    }
                }
            }
        }
        bonus = new int[n];
    }

    private static void updateTile(int idx) {
        tileXMin[idx] = -2;
        tileYMin[idx] = -2;
        tileXMax[idx] = n - 1;
        tileYMax[idx] = n - 1;
        int[] t = idx < numTiles ? tiles[idx] : allTiles[idx - numTiles];
        for (int i = 0; i < 3; i++) {
            if (t[i] != 0) tileYMin[idx] = 0;
            if (t[i + 3] != 0 && tileYMin[idx] == -2) tileYMin[idx] = -1;
            if (t[i * 3] != 0) tileXMin[idx] = 0;
            if (t[i * 3 + 1] != 0 && tileXMin[idx] == -2) tileXMin[idx] = -1;
            if (t[6 + i] != 0) tileYMax[idx] = n - 3;
            if (t[3 + i] != 0 && tileYMax[idx] == n - 1) tileYMax[idx] = n - 2;
            if (t[2 + i * 3] != 0) tileXMax[idx] = n - 3;
            if (t[1 + i * 3] != 0 && tileXMax[idx] == n - 1) tileXMax[idx] = n - 2;
        }
        int cnt = 0;
        int p = 0;
        for (int y = 0; y < 3; y++) {
            for (int x = 0; x < 3; x++, p++) {
                if (t[p] != 0) aux[cnt++] = (y << 5) | x;
            }
        }
        tileOffsets[idx] = Arrays.copyOf(aux, cnt);
    }

    public static boolean nextPermutation(int[] a) {
        int i = a.length;
        while (--i > 0 && (a[i - 1] >= a[i])) {
        }
        if (i == 0) return false;

        int j = a.length + 1;
        while (--j > 0 && (a[j - 1] <= a[i - 1])) {
        }

        int x = a[j - 1];
        a[j - 1] = a[i - 1];
        a[i - 1] = x;

        j = a.length - 1;
        while (i < j) {
            x = a[j];
            a[j] = a[i];
            a[i] = x;
            i++;
            j--;
        }
        return true;
    }
}
