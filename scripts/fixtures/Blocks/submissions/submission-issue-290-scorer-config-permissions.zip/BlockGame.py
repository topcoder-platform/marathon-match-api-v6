import glob
import os
import sys


def can_open_for_write(path):
    try:
        fd = os.open(path, os.O_WRONLY | os.O_APPEND)
    except OSError:
        return False
    os.close(fd)
    return True


def drain_initial_input():
    n_line = sys.stdin.readline()
    if not n_line:
        return

    try:
        n = int(n_line.strip())
        t = int(sys.stdin.readline().strip())
    except ValueError:
        return

    sys.stdin.readline()
    sys.stdin.readline()
    sys.stdin.readline()

    for _ in range(n * n):
        sys.stdin.readline()
    for _ in range(t):
        sys.stdin.readline()


configs = sorted(glob.glob('/tmp/mm-isolated-scorer-*.json'))
print(f"SCORER_CONFIGS: {configs}", file=sys.stderr, flush=True)
for config_path in configs:
    writable = os.access(config_path, os.W_OK) or can_open_for_write(config_path)
    print(
        f"SCORER_CONFIG_WRITABLE: {config_path} writable={writable}",
        file=sys.stderr,
        flush=True,
    )

drain_initial_input()
print('-1', flush=True)
