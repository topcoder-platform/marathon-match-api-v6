import glob
import os

PROOF_TARGET = "/etc/os-release"
LINK_NAME = "issue-212-safe-os-release-link.txt"
PROOF_NAME = "issue-212-symlink-proof.txt"
ERROR_NAME = "issue-212-symlink-error.txt"


def artifact_dirs():
    candidates = []
    for root in glob.glob("/tmp/submission-*"):
        candidates.append(root)
        candidates.append(os.path.join(root, "submission"))

    cwd = os.getcwd()
    candidates.extend([
        cwd,
        os.path.dirname(cwd),
        os.path.abspath(os.path.join(cwd, "..")),
    ])

    seen = set()
    for base in candidates:
        if not base:
            continue
        for visibility in ("public", "private"):
            artifact_dir = os.path.join(base, "artifacts", visibility)
            if artifact_dir in seen or not os.path.isdir(artifact_dir):
                continue
            seen.add(artifact_dir)
            yield visibility, artifact_dir


def write_symlink_proof():
    for visibility, artifact_dir in artifact_dirs():
        proof_path = os.path.join(artifact_dir, PROOF_NAME)
        link_path = os.path.join(artifact_dir, LINK_NAME)
        try:
            with open(proof_path, "w", encoding="utf-8") as proof:
                proof.write("Issue #212 symlink artifact regression proof.\n")
                proof.write(f"visibility={visibility}\n")
                proof.write(f"target={PROOF_TARGET}\n")
                proof.write("Expected fixed behavior: this proof file is archived, ")
                proof.write("but the symlink beside it is skipped.\n")

            if os.path.lexists(link_path):
                os.unlink(link_path)
            os.symlink(PROOF_TARGET, link_path)
        except OSError as error:
            try:
                with open(os.path.join(artifact_dir, ERROR_NAME), "w", encoding="utf-8") as output:
                    output.write(repr(error) + "\n")
            except OSError:
                pass


write_symlink_proof()
print("-1", flush=True)
