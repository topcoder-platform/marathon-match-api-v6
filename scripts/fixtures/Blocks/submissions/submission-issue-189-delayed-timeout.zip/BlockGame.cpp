#include <chrono>
#include <iostream>
#include <string>
#include <thread>

int main() {
    int n = 0;
    int t = 0;
    int c = 0;
    double f = 0.0;
    double p = 0.0;

    if (!(std::cin >> n >> t >> c >> f >> p)) {
        return 0;
    }

    std::string token;
    for (int index = 0; index < n * n; ++index) {
        if (!(std::cin >> token)) {
            return 0;
        }
    }
    for (int index = 0; index < t; ++index) {
        if (!(std::cin >> token)) {
            return 0;
        }
    }

    std::this_thread::sleep_for(std::chrono::milliseconds(25));
    std::cout << "-1" << std::endl;
    return 0;
}
