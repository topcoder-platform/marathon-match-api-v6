#pragma GCC optimize "O3,omit-frame-pointer,inline,unroll-loops"
#pragma GCC target "sse,sse2,sse3,ssse3,sse4,abm,mmx"
#include <algorithm>
#include <cstdlib>
#include <iostream>
#include <fstream>
#include <vector>
#include <cmath>
#include "bits/stdc++.h"
#include <sys/time.h>
#include <emmintrin.h>
#include <string>
#include <bitset>
#include <unistd.h>

using namespace std;

#ifdef LOCAL
inline double GetSeconds() {
  return static_cast<double>(chrono::duration_cast<chrono::nanoseconds>(
        chrono::steady_clock::now().time_since_epoch()).count())/1000000000;
}
#else
inline long long GetTSC() {
  long long lo, hi;
  asm volatile ("rdtsc": "=a"(lo), "=d"(hi));
  return lo + (hi << 32);
}
inline double GetSeconds() {
  return GetTSC() / 2.8e9;
}
#endif

struct XorShift {
  uint64_t x = 88172645463325252ULL;
  double nl[65536];
  XorShift() {}

  void init(){
    double n2 = 1.0 / 65536*2;
    for(int i=0; i<65536; i++) nl[i] = log(i / 65536.0 + n2);
  }

  void setSeed(uint64_t seed) { x = seed; init(); }

  uint64_t next() {
    x ^= x << 13; x ^= x >> 7; x ^= x << 17;
    return x;
  }

  int nextInt(int n) {
    uint64_t upper = 0xFFFFFFFFFFFFFFFFULL / n * n;
    uint64_t v = next();
    while (v >= upper) v = next();
    return v % n;
  }

  double nextDouble() {
    uint64_t v = next() >> 11; // 53bit
    return (double)v / (1ULL << 53);
  }

  double nextLog() {
    return nl[nextInt(65536)];
  }
};


XorShift xs;
#ifdef LOCAL
const double TO = 9.8 * 1e-0;
#else
const double TO = 9.8 * 1e-0;
#endif

double starttime, gt;
int att,btt,ctt,dtt,ett,ftt,gtt,htt;

const int MAX_N = 24;
const int MAX_NN = MAX_N * MAX_N;
const int MAX_T = 5;
const int MAX_C = 5;
const int EMPTY = 0;
const int OUT = 9;

int N, T, C;
double F, P;
int B[MAX_N][MAX_N];
int K[MAX_T][3][3];
int KC[MAX_T], KF[MAX_T];
double KMI[MAX_C+1], KMA[MAX_C+1], KMM[MAX_C+1];
int etime;

int KH[MAX_T][MAX_NN][2];
int KHI[MAX_T];
int KH2[MAX_NN*MAX_T][3];
int KH2V[MAX_NN*MAX_T][6][2];
int KH2VI[MAX_NN*MAX_T];
int KH2I;

void init(){
  cin >> N >> T >> C >> F >> P;

  for(int i=0; i<MAX_N; i++) for(int j=0; j<MAX_N; j++){
    B[i][j] = OUT;
  }

  for(int i=0; i<N; i++) for(int j=0; j<N; j++){
    cin >> B[i+2][j+2];
  }

  for(int i=0; i<T; i++){
    string s;
    cin >> s;
    KC[i] = 0;
    for(int j=0; j<3; j++) for(int k=0; k<3; k++){
      K[i][j][k] = s[j*3+k] - '0';
      if(K[i][j][k] != EMPTY){
        KC[i]++;
        KF[i] = K[i][j][k];
      }
    }
  }

  double p = 2 + P*P/N/N * 1000;
  cerr << "p: " << p << endl;
  for(int c=1; c<=C; c++){
    KMI[c] = max(2.0, (c-1.1) / C * N + 2);
    KMA[c] = min(N+2.0, (c+0.1) / C * N + 2);
    while(min(N+2.0, KMA[c]) - max(2.0, KMI[c])
        < min(N-0.1, p + (c == 1 || c == C) + (C == 2))){
      KMI[c] -= 0.1;
      KMA[c] += 0.1;
    }
    KMM[c] = (c-0.5) / C * N + 2;
    // cerr << c << ": " << KMI[c] << " " << KMA[c] << " ";
    // cerr << c << ": " << int(KMI[c]) << " " << int(KMA[c]) << endl;
  }

  /*
  cerr << "B" << endl;
  for(int i=0; i<N; i++){
    for(int j=0; j<N; j++) cerr << B[i][j];
    cerr << " : " << i << endl;
  }
  for(int i=0; i<T; i++){
    cerr << "T" << i << endl;
    for(int j=0; j<3; j++){
      for(int k=0; k<3; k++) cerr << K[i][j][k];
      cerr << endl;
    }
  }
  */
}

double ss(int i, int j, int k, int turn){
  for(int l=0; l<3; l++) for(int m=0; m<3; m++){
    if(K[i][l][m] == EMPTY) continue;
    if(B[j+l][k+m] != EMPTY) return -1e5;
  }

  double sc = KC[i] * 1024 + 1e9;
  int lo = 0, ln = 0;
  for(int l=0; l<3; l++) for(int m=0; m<3; m++){
    if(K[i][l][m] == EMPTY) continue;
    B[j+l][k+m] = K[i][l][m];
    if(C < 2){
      sc += -pow(j+l - KMM[KF[i]], 2);
      sc += -pow(k+m - KMM[KF[i]], 2);
    }
    if((1 && KMI[KF[i]] <= j+l && j+l <= KMA[KF[i]])
        || (0 && KMI[KF[i]] <= k+m && k+m <= KMA[KF[i]])) lo++;
    else ln++;
  }
  bool lok = lo > ln;

  int c1 = 0, c2 = 0, cmc = 0;
  double mcc = 0;
  for(int i=2; i<N+2; i++){
    {
      int bc[MAX_C] = {};
      int ne = 1, bb = -1;
      for(int j=2; j<N+2; j++){
        bc[B[i][j]]++;
        if(B[i][j] == EMPTY && bb != EMPTY) ne++;
        bb = B[i][j];
      }
      int mc = 0;
      for(int c=1; c<=C; c++) mc = max(mc, bc[c]);
      mcc += mc * mc * 2048 / (ne * ne * (bc[EMPTY] + 1)) * pow(1.0 * mc / N, 2);
      if(bc[EMPTY] == 0) c1++;
      if(bc[EMPTY] == 0 && mc > N/1.95) cmc++;
    }

    {
      int bc[MAX_C] = {};
      int ne = 1, bb = -1;
      for(int j=2; j<N+2; j++){
        bc[B[j][i]]++;
        if(B[j][i] == EMPTY && bb != EMPTY) ne++;
        bb = B[j][i];
      }
      int mc = 0;
      for(int c=1; c<=C; c++) mc = max(mc, bc[c]);
      mcc += mc * mc * 2048 / (ne * ne * (bc[EMPTY] + 1)) * pow(1.0 * mc / N, 2);
      if(bc[EMPTY] == 0) c2++;
      if(bc[EMPTY] == 0 && mc > N/1.95) cmc++;
    }
  }
  sc += 1024 * (c1+1) * (c2+1) * mcc;
  int c = c1 + c2;
  if(((P < 0.37 - C/50.0 || (P < 0.45 && C < 2) || cmc < 1) && c == 1 && turn < 990)
      || ((cmc < 1 || c < 2) && !lok)) sc = -1e5;

  if(lok) sc *= pow(1.0 * lo / (lo + ln), 3);

  if(sc > 0 && c < 1){
    bool ong = 0;
    for(int ki=0; ki<KH2I; ki++){
      auto kh = KH2[ki];
      if(kh[0] == i){
        ong = 1;
        // if(c < 1) sc = -1e5;
      }else{
        bool ng = 0;
        for(int l=0; l<3 && !ng; l++) for(int m=0; m<3 && !ng; m++){
          if(K[kh[0]][l][m] == EMPTY) continue;
          if(B[kh[1]+l][kh[2]+m] != EMPTY) ng = 1;
        }
        ong |= ng;
        if(ng) sc *= 0.5;
      }
    }

    if(!ong) sc *= 1.75;
  }

  for(int l=0; l<3; l++) for(int m=0; m<3; m++){
    if(K[i][l][m] == EMPTY) continue;
    B[j+l][k+m] = EMPTY;
  }
  return sc;
}

bool kss(int i, int j, int k){
  for(int l=0; l<3; l++) for(int m=0; m<3; m++){
    if(K[i][l][m] == EMPTY) continue;
    if(B[j+l][k+m] != EMPTY) return 0;
  }
  return 1;
}

void ks2(int i, int j, int k){
  for(int l=0; l<3; l++) for(int m=0; m<3; m++){
    if(K[i][l][m] == EMPTY) continue;
    B[j+l][k+m] = KF[i];
  }

  KH2VI[KH2I] = 0;
  for(int l=j; l<j+3; l++){
    if(B[l][2] == OUT) continue;
    bool ok = 1;
    for(int m=2; m<N+2 && ok; m++) if(B[l][m] == EMPTY) ok = 0;
    if(ok){
      KH2V[KH2I][KH2VI[KH2I]][0] = 0;
      KH2V[KH2I][KH2VI[KH2I]][1] = l;
      KH2VI[KH2I]++;
    }
  }
  for(int m=k; m<k+3; m++){
    if(B[2][m] == OUT) continue;
    bool ok = 1;
    for(int l=2; l<N+2 && ok; l++) if(B[l][m] == EMPTY) ok = 0;
    if(ok){
      KH2V[KH2I][KH2VI[KH2I]][0] = 1;
      KH2V[KH2I][KH2VI[KH2I]][1] = m;
      KH2VI[KH2I]++;
    }
  }
  if(KH2VI[KH2I] > 0){
    KH2VI[KH2I]++;
    KH2[KH2I][0] = i;
    KH2[KH2I][1] = j;
    KH2[KH2I][2] = k;
    KH2I++;
  }

  for(int l=0; l<3; l++) for(int m=0; m<3; m++){
    if(K[i][l][m] == EMPTY) continue;
    B[j+l][k+m] = EMPTY;
  }
}

void solve_(int turn){
  for(int i=0; i<T; i++){
    KHI[i] = 0;
    for(int j=0; j<N+2; j++) for(int k=0; k<N+2; k++) if(kss(i,j,k)){
      KH[i][KHI[i]][0] = j;
      KH[i][KHI[i]][1] = k;
      KHI[i]++;
    }
  }

  KH2I = 0;
  for(int i=0; i<T; i++){
    for(int hi=0; hi<KHI[i]; hi++){
      int j = KH[i][hi][0];
      int k = KH[i][hi][1];
      ks2(i,j,k);
    }
  }
  if(turn < 10 && 0){
    cerr << "turn: " << turn << " " << KH2I << endl;
    for(int i=0; i<KH2I; i++){
      cerr << KH2[i][0] << " " << KH2[i][1] << " " << KH2[i][2] << endl;
    }
  }

  double mm = -1024;
  int mi,mj,mk,mc = 1;
  for(int i=0; i<T; i++){
    if(mm <= KC[i] - 100){
      mc = 1;
      mm = KC[i] - 100;
      mi = i;
    }
    for(int hi=0; hi<KHI[i]; hi++){
      int j = KH[i][hi][0];
      int k = KH[i][hi][1];
      double s = ss(i,j,k,turn);
      // if(turn < 2) cerr << i << " " << j << " " << k << ": " << s << endl;
      if(mm < s || (mm == s && xs.nextInt(mc+1) == 0)){
        if(mm < s) mc = 1;
        else mc++;
        mm = s;
        mi = i; mj = j; mk = k;
      }
    }
  }

  if(mm < 0){
    cout << mi << endl;
    att++;
  }else{
    cout << mi << ' ' << mj-2 << ' ' << mk-2 << endl;
    // cerr << mi << ' ' << mj-2 << ' ' << mk-2 << endl;
    for(int l=0; l<3; l++) for(int m=0; m<3; m++){
      if(K[mi][l][m] == EMPTY) continue;
      B[mj+l][mk+m] = K[mi][l][m];
    }
  }

  string s;
  cin >> s >> etime;
  KC[mi] = 0;
  for(int j=0; j<3; j++) for(int k=0; k<3; k++){
    K[mi][j][k] = s[j*3+k] - '0';
    if(K[mi][j][k] != EMPTY){
      KF[mi] = K[mi][j][k];
      KC[mi]++;
    }
  }

  vector<tuple<int, int>> v;
  for(int i=2; i<N+2; i++){
    bool ok = 1;
    for(int j=2; j<N+2 && ok; j++) if(B[i][j] == EMPTY) ok = 0;
    if(ok) v.emplace_back(0, i);

    ok = 1;
    for(int j=2; j<N+2 && ok; j++) if(B[j][i] == EMPTY) ok = 0;
    if(ok) v.emplace_back(1, i);
  }
  for(auto t : v){
    int u = get<0>(t);
    int i = get<1>(t);
    if(u == 0) for(int j=2; j<N+2; j++) B[i][j] = EMPTY;
    else for(int j=2; j<N+2; j++) B[j][i] = EMPTY;
  }
}

void solve(){
  int ms = 0;

  for(int t=0; t<1000; t++){
    solve_(t);

#ifdef DEBUG
    if(t == 998){
      cerr << " att: " << att << " btt: " << btt;
      cerr << " ctt: " << ctt << " dtt: " << dtt << " ett: " << ett;
      cerr << " ftt: " << ftt << " gtt: " << gtt << " htt: " << htt << endl;
    }
#endif
  }

  cerr << "ms: " << ms;
  cerr << " time: " << (GetSeconds() - starttime) << endl;
}

int main() {
  starttime = GetSeconds();
  srand((unsigned) time(NULL));
  ios::sync_with_stdio(false);
  cin.tie(nullptr);
  xs.setSeed(rand() % 65536 + 65537);
  cerr << "x: " << xs.x << endl;

  init();
  solve();

  return 0;
}
