//g++ --std=c++0x -W -Wall -Wno-sign-compare -O2 -pipe -DLOCAL % -o %:r
#include <algorithm>
#include <cassert>
#include <climits>
#include <complex>
#include <cstdlib>
#include <deque>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <map>
#include <queue>
#include <set>
#include <stack>
#include <sstream>
#include <sys/time.h>
#include <unordered_map>
#include <unordered_set>
#include <vector>
#include <unistd.h>
using namespace std;
// }}}
#ifdef LOCAL
  #define FACTOR (1.0)
#else
  #define FACTOR (1.0)
#endif
#define PROFILING 
//#define STOPWATCH
// {{{
#define NOOP() ((void) 0)
#define INLINE inline __attribute__ ((always_inline))
#define NOINLINE __attribute__ ((noinline))
#define LIKELY(x) __builtin_expect(!!(x), 1)
#define UNLIKELY(x) __builtin_expect(!!(x), 0)
#define ALIGNED __attribute__ ((aligned(16)))
// }}}
// {{{ output operators
template<class T1, class T2> ostream& operator<<(ostream &, const pair<T1, T2> &);
template<class T> ostream& operator<<(ostream&, const vector<T> &);
template<class T> ostream& operator<<(ostream&, const set<T> &);
template<class V, class K> ostream& operator<<(ostream &, const map<V, K> &);
template<class... Args> ostream &operator<<(ostream &, const tuple<Args...> &);
template<class T> void dumpContainer(const T &c, ostream &out) { for (auto it = c.begin(); it != c.end(); ++it) { if (it != c.begin()) { out << ", "; } out << *it; } }
template<class T1, class T2> ostream& operator<<(ostream &out, const pair<T1, T2> &p) { out << "(" << p.first << ", " << p.second << ")"; return out; }
template<class T> ostream& operator<<(ostream &out, const vector<T> &v) { out << "["; dumpContainer(v, out); out << "]"; return out; }
template<class T> ostream& operator<<(ostream &out, const set<T> &s) { out << "{"; dumpContainer(s, out); out << "}"; return out; }
template<class K, class V> ostream& operator<<(ostream &out, const map<K, V> &m) { out << "{"; dumpContainer(m, out); out << "}"; return out; }
template<size_t> struct sizeT {}; 
template<class T> void dumpTuple(const T &, sizeT<0>, ostream &) {} 
template<class T> void dumpTuple(const T &t, sizeT<1>, ostream &out) { out << get<tuple_size<T>::value - 1>(t); }
template<class T, size_t numRemaining> void dumpTuple(const T &t, sizeT<numRemaining>, ostream &out) { out << get<tuple_size<T>::value - numRemaining>(t) << ", "; dumpTuple(t, sizeT<numRemaining - 1>(), out); }
template<class... Args> ostream &operator<<(ostream &out, const tuple<Args...> &t) { out << "("; dumpTuple(t, sizeT<sizeof...(Args)>(), out); out << ")"; return out; }
// }}}
// {{{ debug
#define COMPOSE_MACRO(_1, _2, _3, _4, _5, _6, _7, _8, MACRO_NAME, ...) MACRO_NAME
#define STREAM1(x, ...) #x << " = " << (x)
#define STREAM2(x, ...) STREAM1(x) << ", " << STREAM1(__VA_ARGS__)
#define STREAM3(x, ...) STREAM1(x) << ", " << STREAM2(__VA_ARGS__)
#define STREAM4(x, ...) STREAM1(x) << ", " << STREAM3(__VA_ARGS__)
#define STREAM5(x, ...) STREAM1(x) << ", " << STREAM4(__VA_ARGS__)
#define STREAM6(x, ...) STREAM1(x) << ", " << STREAM5(__VA_ARGS__)
#define STREAM7(x, ...) STREAM1(x) << ", " << STREAM6(__VA_ARGS__)
#define STREAM8(x, ...) STREAM1(x) << ", " << STREAM7(__VA_ARGS__)
#define STREAM_VARARGS(...) COMPOSE_MACRO(__VA_ARGS__, STREAM8, STREAM7, STREAM6, STREAM5, STREAM4, STREAM3, STREAM2, STREAM1)(__VA_ARGS__)
#ifdef NODBG 
ofstream devNull("/dev/null");
#define DBG_DEST devNull
#else
#define DBG_DEST cerr
#endif
#define DBG(...) DBG_DEST << STREAM_VARARGS(__VA_ARGS__) << endl
#define DBG_WITH_LINE(...) DBG_DEST << "line " << __LINE__ << ": " << STREAM_VARARGS(__VA_ARGS__) << endl
#define DBG_NZ(x) if (x) { DBG(x); }
#define WARNING DBG_DEST << "WARNING "
// }}}
// {{{ assert
struct Equals { template<class T1, class T2> bool operator()(const T1 &lhs, const T2 &rhs) const { return lhs == rhs; } };
template<class T1, class T2, class OP> void verboseAssert(const T1 &lhs, const T2 &rhs, const OP &op, const char *lhsExp, const char *rhsExp, const char *opStr, const char *file, const char *function, int line) { if (!op(lhs, rhs)) { cerr << "Assertion failed: not true that " << lhsExp << " " << opStr << " " << rhsExp << ", function " << function << ", file " << file << ", line " << line << "." << endl; cerr << "    " << lhsExp << " = " << lhs << endl; cerr << "    " << rhsExp << " = " << rhs << endl; abort(); } }
#ifdef NDEBUG
#define assertEquals(x, y) NOOP();
#else
#define assertEquals(x, y) verboseAssert(x, y, Equals(), #x, #y, "equals", __FUNCTION__, __FILE__, __LINE__);
#endif
// }}}
// {{{ timing / profiling
#ifdef PROFILING
  long long numMeasureTime = 0;
  #define INC(x) ++x
  #define DBG_PROFILING() DBG(numMeasureTime);
#else
  #define INC(x) NOOP()
  #define DBG_PROFILING() NOOP()
#endif
INLINE static double measureTime() {
  INC(numMeasureTime);
  timeval t; 
  gettimeofday(&t, 0); 
  return (t.tv_sec * 1000000LL + t.tv_usec) * 1e-6 * FACTOR;
}
struct StopWatch {
#ifdef STOPWATCH
  string name;
  double lastTic;
  double totalElapsed;
  int numTics;
  bool isRunning;
  StopWatch(const string &name) : name(name), totalElapsed(0.0), numTics(0), isRunning(false){}
  INLINE void tic() {
    assert(!isRunning);
    isRunning = true;
    numTics++;
    lastTic = measureTime();
  }
  INLINE double toc() {
    assert(isRunning);
    isRunning = false;
    double delta = measureTime() - lastTic;
    totalElapsed += delta;
    return delta;
  }
  INLINE double getTotalElapsed() {
    return totalElapsed + (isRunning ? measureTime() - lastTic : 0.0);
  }
  void print() {
    double t = getTotalElapsed();
    DBG_DEST << name << ": total=" << t << "s, count=" << numTics;
    if (numTics) {
      DBG_DEST << " avg=" << t / numTics << "s";
    }
    if (isRunning) {
      DBG_DEST << " [isRunning=true]";
    }
    DBG_DEST << endl;
  }
#else
  StopWatch(string) {}
  void tic() {}
  double toc() { return 0.0; }
  double getTotalElapsed() { return 0.0; }
  void print() {}
#endif
#define SW(x) StopWatch stopWatch##x(#x); stopWatch##x.tic();
#define SW_END(x) stopWatch##x.toc(); stopWatch##x.print();
};
// }}}
// {{{ PRNG 
class MersenneTwister {
 public:
  MersenneTwister() { init(); }
  MersenneTwister(unsigned seed) { init(seed); }
  void init(unsigned seed=0) {
    ix = 0;
    MT[0] = seed;
    for (unsigned i = 1; i < 624; i++) {
      MT[i] = 1812433253u * (MT[i-1] ^ (MT[i-1] >> 30)) + i;
    }
  }
  INLINE unsigned next() {
    if (ix == 0) {
      generate();
    }
    unsigned y = MT[ix];
    y ^= y >> 11;
    y ^= (y << 7) & 2636928640u;
    y ^= (y << 15) & 4022730752u;
    y ^= y >> 18;
    if (++ix >= 624) {
      ix = 0;
    }
    return y;
  }
  INLINE int next(int m) { return next() % m; }
  INLINE int next(int a, int b) { return a + next() % (b - a); }
  INLINE double nextDouble() { return next() * .00000000023283064365; }
  INLINE float nextFloat() { return next() * .00000000023283064365f; }
  template<class T> void randomShuffle(T begin, T end) {
    for (int i = 1, n = end - begin; i < n; i++) {
      swap(begin[i], begin[next() % (i + 1)]);
    }
  }
  template<class T> void randomShuffle(T &v) {
    randomShuffle(v.begin(), v.end());
  }
 private:
  unsigned MT[624];
  int ix;
  double v;
  bool precalc = false;
  INLINE void generate() {
    for (int i = 0; i < 624; i++) {
      unsigned y = (MT[i] & (1u << 31)) + (MT[i == 623 ? 0 : i + 1] & ((1u << 31) - 1));
      MT[i] = MT[i + 397 >= 624 ? i + 397 - 624 : i + 397] ^ (y >> 1);
      if (y & 1) {
        MT[i] ^= 2567483615u;
      }
    }
  }
 public:
  double gaussian() {
    if (precalc) {
      precalc = false;
      return v;
    }
    double x, y, r2;
    do {
      x = 2 * nextDouble() - 1.0;
      y = 2 * nextDouble() - 1.0;
      r2 = x*x + y*y;
    } while (r2 > 1 || r2 == 0);
    double s = sqrt(-2.0 * log(r2) / r2);
    double u = s * x;
    v = s * y;
    precalc = true;
    return u;
  }
} mt;
// mt(time(0));
// }}}
// {{{
typedef vector<int> VI;
typedef vector<VI> VVI;
typedef vector<signed char> Board;
typedef vector<string> VS;
typedef pair<int, int> PII;
typedef long long LL;
typedef unsigned long long ULL;
// }}}

double startTime;
int lastTime;

struct Tile {
  int color;
  vector<PII> offsets;
};

struct Move {
  int k;
  int x;
  int y;

  bool operator<(const Move &move) const {
    return k < move.k;
  }
};

int n;
int t;
int c;
double f;
double p;

int grid[32][32];

double ps[32][32];
double es[32][32];
double rowEs[32];
double colEs[32];

Tile tiles[5];

int rowCount[32][8];
int colCount[32][8];

float psTab[1 << 25];
double qs[32];

void print() {
  for (int i = 0; i < n + 4; i++) {
    for (int j = 0; j < n + 4; j++) {
      if (grid[i][j] == -1) {
        cerr << '#';
      } else if (grid[i][j] == 0) {
        cerr << ' ';
      } else {
        char ch = grid[i][j] + 'A';
        cerr << ch;
      }
    }
    cerr << endl;
  }
  cerr << endl;
}

VI toVI(const Move &move) {
  return VI{move.k, move.x, move.y};
}

void initCounts() {
  for (int i = 0; i < n; i++) {
    for (int j = 0; j < n; j++) {
      int x = i + 2;
      int y = j + 2;
      if (grid[x][y] == 0) {
        continue;
      }
      int color = grid[x][y];

      rowCount[x][0]++;
      rowCount[x][color]++;

      colCount[y][0]++;
      colCount[y][color]++;
    }
  }
}

void initPsTab() {
  qs[0] = 1.0;
  for (int i = 1; i < 32; i++) {
    qs[i] = qs[i - 1] * (1.0 - p);
  }

  for (int k = 0; k < (1 << 25); k++) {
    if (k & ((1 << (2 * 5 + 2)))) {
      continue;
    }
    double sum = 0.0;
    for (int dx = 0; dx <= 2; dx++) {
      for (int dy = 0; dy <= 2; dy++) {
        //      int x0 = x + dx;
        //      int y0 = y + dy;
        //      int nzCnt =
        //        (grid[x0 + 0][y0 + 0] != 0) + 
        //        (grid[x0 + 0][y0 + 1] != 0) + 
        //        (grid[x0 + 0][y0 + 2] != 0) + 
        //        (grid[x0 + 1][y0 + 0] != 0) + 
        //        (grid[x0 + 1][y0 + 1] != 0) + 
        //        (grid[x0 + 1][y0 + 2] != 0) + 
        //        (grid[x0 + 2][y0 + 0] != 0) + 
        //        (grid[x0 + 2][y0 + 1] != 0) + 
        //        (grid[x0 + 2][y0 + 2] != 0);
        int mask2 = (0
            | (1 << ((dx + 0) * 5 + dy + 0))
            | (1 << ((dx + 0) * 5 + dy + 1))
            | (1 << ((dx + 0) * 5 + dy + 2))
            | (1 << ((dx + 1) * 5 + dy + 0))
            | (1 << ((dx + 1) * 5 + dy + 1))
            | (1 << ((dx + 1) * 5 + dy + 2))
            | (1 << ((dx + 2) * 5 + dy + 0))
            | (1 << ((dx + 2) * 5 + dy + 1))
            | (1 << ((dx + 2) * 5 + dy + 2))

            );
        int mask = k & mask2;
//        if (mask != mask2) {
//          continue;
//        }
        int nzCnt = __builtin_popcount(mask);
        sum += p * qs[nzCnt];
  //      sum += p * pow(1.0 - p, nzCnt);
      }
    }
    psTab[k] = sum;
  }
}

void updatePs(int x, int y) {

#define MASK(xx, yy) ((grid[x + (xx) - 2][y + (yy) - 2] != 0) << ((xx) * 5 + (yy)))
#define MASK2(xx, yy) ((grid[x + (xx) - 2][y + (yy) - 2] != 0) << ((yy) * 5 + (xx)))
  int mask =
    MASK(0, 0)
  | MASK(0, 1)
  | MASK(0, 2)
  | MASK(0, 3)
  | MASK(0, 4)
  | MASK(1, 0)
  | MASK(1, 1)
  | MASK(1, 2)
  | MASK(1, 3)
  | MASK(1, 4)
  | MASK(2, 0)
  | MASK(2, 1)
  | MASK(2, 2)
  | MASK(2, 3)
  | MASK(2, 4)
  | MASK(3, 0)
  | MASK(3, 1)
  | MASK(3, 2)
  | MASK(3, 3)
  | MASK(3, 4)
  | MASK(4, 0)
  | MASK(4, 1)
  | MASK(4, 2)
  | MASK(4, 3)
  | MASK(4, 4);
  ps[x][y] = psTab[mask];
  return;
  if (grid[x][y]) {
    return;
  }

  double sum = 0.0;

  for (int dx = -2; dx <= 0; dx++) {
    for (int dy = -2; dy <= 0; dy++) {
      int x0 = x + dx;
      int y0 = y + dy;
      int nzCnt =
        (grid[x0 + 0][y0 + 0] != 0) + 
        (grid[x0 + 0][y0 + 1] != 0) + 
        (grid[x0 + 0][y0 + 2] != 0) + 
        (grid[x0 + 1][y0 + 0] != 0) + 
        (grid[x0 + 1][y0 + 1] != 0) + 
        (grid[x0 + 1][y0 + 2] != 0) + 
        (grid[x0 + 2][y0 + 0] != 0) + 
        (grid[x0 + 2][y0 + 1] != 0) + 
        (grid[x0 + 2][y0 + 2] != 0);
      sum += p * pow(1.0 - p, nzCnt);
    }
  }
  assert(abs(sum - psTab[mask]) < 1e-6);
  ps[x][y] = sum;
  ps[x][y] = psTab[mask];
}

void initPs() {
  for (int i = 0; i < n; i++) {
    for (int j = 0; j < n; j++) {
      int x = i + 2;
      int y = j + 2;
      updatePs(x, y);
    }
  }
}

void updateEs(int x, int y) {
  double oldEs = es[x][y];
  double newEs;
  if (grid[x][y]) {
    newEs = 0.0;
  } else {
    newEs = 1.0 / min(1.0, ps[x][y]);
  }

  es[x][y] = newEs;

  rowEs[x] += newEs - oldEs;
  colEs[y] += newEs - oldEs;
}

void initEs() {
  for (int i = 0; i < n; i++) {
    for (int j = 0; j < n; j++) {
      int x = i + 2;
      int y = j + 2;
      updateEs(x, y);
    }
  }
}

void clearEsAndPs() {
  for (int i = 0; i < 32; i++) {
    for (int j = 0; j < 32; j++) {
      es[i][j] = 0;
      ps[i][j] = 0;
    }
    rowEs[i] = 0;
    colEs[i] = 0;
  }
}
void printPs() {
  cerr << "ps" << endl;
  for (int i = 0; i < n + 4; i++) {
    for (int j = 0; j < n + 4; j++) {
      cerr << ps[i][j] << " ";
    }
    cerr << endl;
  }
  cerr << endl;
}

void printEs() {
  cerr << "es" << endl;
  for (int i = 0; i < n + 4; i++) {
    for (int j = 0; j < n + 4; j++) {
      cerr << es[i][j] << " ";
    }
    cerr << endl;
  }
  cerr << endl;

  for (int i = 0; i < n; i++) {
    cerr << rowEs[i + 2] << " ";
  }
  cerr << endl;
  for (int i = 0; i < n; i++) {
    cerr << colEs[i + 2] << " ";
  }
  cerr << endl;
}

void updateNearbyPsAndEs(const Move &move) {
  set<int> xs;
  set<int> ys;
  for (const PII &offsets : tiles[move.k].offsets) {
    int x = move.x + offsets.first;
    int y = move.y + offsets.second;
    xs.insert(x);
    ys.insert(y);
  }

  int x0 = *xs.begin() - 2;
  int x1 = *xs.rbegin() + 2;
  int y0 = *ys.begin() - 2;
  int y1 = *ys.rbegin() + 2;

  x0 = max(x0, 2);
  x1 = min(x1, n + 1);
  y0 = max(y0, 2);
  y1 = min(y1, n + 1);

  for (int x = x0; x <= x1; x++) {
    for (int y = y0; y <= y1; y++) {
      updatePs(x, y);
      updateEs(x, y);
    }
  }
}

Tile readTile(istream &in) {
  int color = -1;
  vector<PII> offsets;

  string tmp;
  in >> tmp;

  for (int i = 0; i < 3; i++) {
    for (int j = 0; j < 3; j++) {
      char ch = tmp[3 * i + j];
      assert(isdigit(ch));
      if (ch == '0') {
        continue;
      }

      assert(color == -1 || color == ch - '0');
      color = ch - '0';

      offsets.push_back(PII(i, j));
    }
  }

  assert(color != -1);

  return Tile{color, offsets};
}

void readTime(istream &in) {
  in >> lastTime;
}

bool check(const Move &move) {
  for (const PII &offsets : tiles[move.k].offsets) {
    int x = move.x + offsets.first;
    int y = move.y + offsets.second;

    if (grid[x][y]) {
      return false;
    }
  }

  return true;
}

void put(const Move &move) {
  const int &color = tiles[move.k].color;
  assert(color != 0);

  for (const PII &offsets : tiles[move.k].offsets) {
    int x = move.x + offsets.first;
    int y = move.y + offsets.second;

    assert(!grid[x][y]);

    grid[x][y] = color;

    rowCount[x][0]++;
    rowCount[x][color]++;

    colCount[y][0]++;
    colCount[y][color]++;
  }
}

void remove(const Move &move) {
  const int &color = tiles[move.k].color;

  for (const PII &offsets : tiles[move.k].offsets) {
    int x = move.x + offsets.first;
    int y = move.y + offsets.second;

    assert(grid[x][y] == color);

    grid[x][y] = 0;

    rowCount[x][0]--;
    rowCount[x][color]--;

    colCount[y][0]--;
    colCount[y][color]--;
  }
}

vector<Move> validMoves() {
  vector<Move> moves;
  for (int i = 0; i < n + 2; i++) {
    for (int j = 0; j < n + 2; j++) {
      for (int k = 0; k < t; k++) {
        Move move{k, i, j};
        if (check(move)) {
          moves.push_back(move);
        }
      }
    }
  }

  return moves;
}

set<int> rows(const Move &move) {
  set<int> xs;
  for (const PII &offsets : tiles[move.k].offsets) {
    int x = move.x + offsets.first;
    xs.insert(x);
  }
  return xs;
}

set<int> columns(const Move &move) {
  set<int> ys;
  for (const PII &offsets : tiles[move.k].offsets) {
    int y = move.y + offsets.second;
    ys.insert(y);
  }
  return ys;
}

set<int> fullRows(const Move &move) {
  set<int> xs;
  for (const PII &offsets : tiles[move.k].offsets) {
    int x = move.x + offsets.first;
    if (rowCount[x][0] == n) {
      xs.insert(x);
    }
  }
  return xs;
}

set<int> fullColumns(const Move &move) {
  set<int> ys;
  for (const PII &offsets : tiles[move.k].offsets) {
    int y = move.y + offsets.second;
    if (colCount[y][0] == n) {
      ys.insert(y);
    }
  }
  return ys;
}

int fullLines(const Move &move) {
  int cnt = 0;
  for (int x : rows(move)) {
    if (rowCount[x][0] == n) {
      cnt++;
    }
  }

  for (int y : columns(move)) {
    if (colCount[y][0] == n) { 
      cnt++;
    }
  }

  return cnt;
}

// Call after move already applied.
int clearAndGetScoreDelta(const Move &move) {
  set<int> xs = fullRows(move);
  set<int> ys = fullColumns(move);

  if (xs.empty() && ys.empty()) {
    return 0;
  }

  int cnt = xs.size() + ys.size();
  int delta = 0;

  for (int x : xs) {
    int m = 0;
    for (int i = 1; i <= c; i++) {
      m = max(rowCount[x][i], m);
    }
    delta += m * m * cnt;
  }

  for (int y : ys) {
    int m = 0;
    for (int i = 1; i <= c; i++) {
      m = max(colCount[y][i], m);
    }
    delta += m * m * cnt;
  }

  for (int x : xs) {
    for (int j = 0; j < n; j++) {
      int y = j + 2;
      if (grid[x][y]) {
        int color = grid[x][y];
        rowCount[x][0]--;
        rowCount[x][color]--;
        colCount[y][0]--;
        colCount[y][color]--;
        grid[x][y] = 0;
      }
    }
  }

  for (int y : ys) {
    for (int i = 0; i < n; i++) {
      int x = i + 2;
      if (grid[x][y]) {
        int color = grid[x][y];
        rowCount[x][0]--;
        rowCount[x][color]--;
        colCount[y][0]--;
        colCount[y][color]--;
        grid[x][y] = 0;
      }
    }
  }

  return delta;
}

double sumEs(const set<int> &xs, const set<int> &ys) {
  double sumEs = 0;
  for (int x : xs) {
    sumEs += rowEs[x];
  }
  for (int y : ys) {
    sumEs += colEs[y];
  }
  for (int x : xs) {
    for (int y : ys) {
      if (grid[x][y] == 0) {
        sumEs -= es[x][y];
      }
    }
  }
  return sumEs;
}

double sumEs2() {
  double ret = 1e9;

  for (int i = 0; i + 1 < n; i++) {
    double sum = 0.0;
    int x = i + 2;
    for (int j = 0; j < 2; j++) {
      int xx = x + j;
      sum += rowEs[xx];
    }

    ret = min(ret, sum);
  }
  
  for (int i = 0; i + 1 < n; i++) {
    double sum = 0.0;
    int y = i + 2;
    for (int j = 0; j < 2; j++) {
      int yy = y + j;
      sum += colEs[yy];
    }

    ret = min(ret, sum);
  }

  return ret;
}

void solve3(istream &in) {
//  if (t != 1) {
//    cout << -1 << endl;
//    return;
//  }
  cerr << "start" << endl;
  initPsTab();
  cerr << "done" << endl;

  initCounts();
  initPs();
  initEs();


  int score = 0;
  for (int i = 0; i < 1000; i++) {
    vector<Move> moves = validMoves();
    int ix;

//    DBG(i);
//    printPs();
//    printEs();

    if (moves.empty()) {
      ix = mt.next(t);
      cout << ix << endl;
    } else {

      vector<pair<double, VI>> nextMoves;
      vector<pair<double, Move>> firstMoves;
      for (const Move &move : moves) {
        set<int> xs = rows(move);
        set<int> ys = columns(move);

        put(move);
        updateNearbyPsAndEs(move);

        int impact = xs.size() + ys.size();
        int fullLines = ::fullLines(move);

        if ((impact >= 5 && fullLines == (int) (xs.size() + ys.size())) || (t == 1 && fullLines >= 2)) {
          nextMoves.push_back(make_pair(impact * 1e9, toVI(move)));
        }

        int sumSqM = 0;
        for (int x : xs) {
          int m = 0;
          for (int i = 1; i <= c; i++) {
            m = max(m, rowCount[x][i]);
          }
          sumSqM += m * m;
        }
        for (int y : ys) {
          int m = 0;
          for (int i = 1; i <= c; i++) {
            m = max(m, colCount[y][i]);
          }
          sumSqM += m * m;
        }

        // TODO
        nextMoves.push_back(make_pair(-impact * 1e9 + sumSqM - sumEs2() * 1.0, toVI(move)));

        // XXX: discard
        double p0 = 0.35;
        if (tiles[move.k].color != 1 && !(n < 14 && (p < p0 || c != 2)) && i < 900 && (tiles[move.k].offsets.size() > 2 || t == 1 || p < p0)) {
          nextMoves.push_back(make_pair(impact * 1e9, VI{move.k}));
        }

        double sumEs = ::sumEs(xs, ys);
        double weight = impact * (n * n - sumEs);
//        DBG(impact, sumEs, n * n - sumEs, weight, xs, ys);
        firstMoves.push_back(make_pair(weight, move));

        remove(move);
        updateNearbyPsAndEs(move);
      }
      sort(firstMoves.rbegin(), firstMoves.rend());

      int S = 300 / firstMoves.size() + (c <= 2 && lastTime <= 4000 ? 3 : 1);
      if (i == 999) {
        S += 5;
      }
      S = min(S, 20);
      if (firstMoves.size() > S) {
        firstMoves.resize(S);
      }

      if (i != 999)
      for (const auto &firstMove : firstMoves) {
        const Move &move = firstMove.second;
        
        set<int> xs = rows(move);
        set<int> ys = columns(move);
        int impact = xs.size() * ys.size();

        put(move);
        updateNearbyPsAndEs(move);

        for (const Move &move2 : moves) {
          if (move2.k == move.k) {
            continue;
          }

//          if (abs(move2.x - move.x) > 2 && abs(move2.y - move2.y) > 2) {
//            continue;
//          }


          if (check(move2)) {
            put(move2);
            updateNearbyPsAndEs(move2);
            double sumEs = ::sumEs(xs, ys);



//            double sumEs2 = 0.0;
//            for (auto p : empty) {
//              sumEs2 += es[p.first][p.second];
//            }
//            DBG(sumEs, sumEs2);
//            for (int i = 0; i < n; i++) {
//              double rs = 0.0;
//              for (int j = 0; j < n; j++) {
//                if (!grid[i + 2][j + 2]) {
//                  rs += es[i + 2][j + 2];
//                }
//              }
//              DBG(rowEs[i + 2], rs, i + 2);
//              assert(abs(rowEs[i + 2] - rs) < 1e-6);
//            }
//

            int sumSqM = 0;
            for (int x : xs) {
              int m = 0;
              for (int i = 1; i <= c; i++) {
                m = max(m, rowCount[x][i]);
              }
              sumSqM += m * m;
            }
            for (int y : ys) {
              int m = 0;
              for (int i = 1; i <= c; i++) {
                m = max(m, colCount[y][i]);
              }
              sumSqM += m * m;
            }

            double weight = impact * (n * n - sumEs) + sumSqM * 0.5;
            nextMoves.push_back(make_pair(weight, toVI(move2)));

            remove(move2);
            updateNearbyPsAndEs(move2);
          }
        }

        remove(move);
        updateNearbyPsAndEs(move);
      }

      sort(nextMoves.begin(), nextMoves.end());

      VI v = nextMoves.rbegin()->second;

      if (v.size() == 3) {
        cout << v[0] << " " << (v[1] - 2) << " " << (v[2] - 2) << endl;
        Move move{v[0], v[1], v[2]};
        put(move);
        updateNearbyPsAndEs(move);
        int delta = clearAndGetScoreDelta(move);
        score += delta;

        clearEsAndPs();
        initPs();
        initEs();
      } else {
        cout << v[0] << endl;
      }

      ix = v[0];


//      Move nextMove = moves[mt.next(moves.size())];
//      ix = nextMove.k;
//
//      put(nextMove);
//
//      int delta = clearAndGetScoreDelta(nextMove);
//      score += delta;
//
//      cout << nextMove.k << " " << (nextMove.x - 2) << " " << (nextMove.y - 2) << endl;
    }
    assert(ix != -1);

    tiles[ix] = readTile(in);
    readTime(in);
  }

  DBG(lastTime, score);
}

void solve2(istream &in) {
  initCounts();
  initPs();
  initEs();

  cerr << "start" << endl;
  initPsTab();
  cerr << "done" << endl;

  int score = 0;
  for (int i = 0; i < 1000; i++) {
    vector<Move> moves = validMoves();
    int ix;

    if (moves.empty()) {
      ix = mt.next(t);
      cout << ix << endl;
    } else {
      Move nextMove = moves[mt.next(moves.size())];
      ix = nextMove.k;

      put(nextMove);

      int delta = clearAndGetScoreDelta(nextMove);
      score += delta;

      cout << nextMove.k << " " << (nextMove.x - 2) << " " << (nextMove.y - 2) << endl;
    }

    tiles[ix] = readTile(in);
    readTime(in);
  }
}

void solve(const VVI &grid, const vector<Tile> &tiles, int n, int t, int c, double f, double p, istream &in) {
  for (int i = 0; i < 32; i++) {
    for (int j = 0; j < 32; j++) {
      ::grid[i][j] = -1;
    }
  }

  for (int i = 0; i < n; i++) {
    for (int j = 0; j < n; j++) {
      ::grid[i + 2][j + 2] = grid[i][j];
    }
  }
  for (int i = 0; i < t; i++) {
    ::tiles[i] = tiles[i];
  }
  ::n = n;
  ::t = t;
  ::c = c;
  ::f = f;
  ::p = p;

  solve3(in);
}

void run(int seed, istream &in) {
  if (0) {
    DBG(seed);
  }
  startTime = measureTime();
  
  int n;
  int t;
  int c;
  double f;
  double p;

  in >> n >> t >> c >> f >> p;

  DBG(n, t, c, f, p);

  VVI grid(n, VI(n, 0));
  for (int i = 0; i < n; i++) {
    for (int j = 0; j < n; j++) {
      in >> grid[i][j];
    }
  }

  DBG(grid);

  vector<Tile> tiles(t);
  for (int i = 0; i < t; i++) {
    tiles[i] = readTile(in);
  }

  solve(grid, tiles, n, t, c, f, p, in);
}

int main(int argc, char **argv) {
  int seed = -1;
  run(seed, cin);
  if (0) {
    if (argc >= 2) {
      seed = atoi(argv[1]);
    }
  }
  //#ifdef LOCAL
  //  if (argc >= 2) {
  //    seed = atoi(argv[1]);
  //    cerr << "processing seed " << seed << endl;
  //  }
  //#endif
  //#if EC2
  //  DBG(argc);
  //  if (argc >= 2) {
  //    seed = atoi(argv[1]);
  //  }
  //  assert(seed != -1);
  //  char filename[64];
  //  //sprintf(filename, "input/%d.in", seed);
  //  sprintf(filename, "/home/ubuntu/input-tco2020-mm116/%d.in", seed);
  //  DBG(filename);
  //  ifstream in(filename);
  //  run(seed, in);
  //#else
  //  run(seed, cin);
  //#endif
  return 0;
}

//static_assert(__LINE__ <= 3000, "More than 3000 lines - consider coming up with a shorter solution!");

