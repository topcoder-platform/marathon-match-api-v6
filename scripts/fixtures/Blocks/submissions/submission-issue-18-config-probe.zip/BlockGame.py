import glob
import os
import sys


def report_scorer_config_visibility():
    matches = sorted(glob.glob("/tmp/mm-isolated-scorer-*.json"))
    if not matches:
        print("ISSUE_18_CONFIG_NOT_FOUND", file=sys.stderr, flush=True)
        return

    for path in matches:
        name = os.path.basename(path)
        try:
            with open(path, "rb") as config_file:
                config_file.read(1)
            print(f"ISSUE_18_CONFIG_READABLE: {name}", file=sys.stderr, flush=True)
        except PermissionError:
            print(f"ISSUE_18_CONFIG_UNREADABLE: {name}", file=sys.stderr, flush=True)
        except FileNotFoundError:
            print(f"ISSUE_18_CONFIG_NOT_FOUND: {name}", file=sys.stderr, flush=True)
        except OSError as error:
            print(
                f"ISSUE_18_CONFIG_ERROR: {name}: {error.__class__.__name__}",
                file=sys.stderr,
                flush=True,
            )


def read_line():
    line = sys.stdin.readline()
    if line == "":
        raise EOFError("unexpected end of tester input")
    return line


def main():
    report_scorer_config_visibility()

    n = int(read_line())
    t = int(read_line())
    read_line()
    read_line()
    read_line()
    for _ in range(n * n):
        read_line()
    for _ in range(t):
        read_line()

    print("-1", flush=True)


if __name__ == "__main__":
    main()
