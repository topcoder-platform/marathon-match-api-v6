#include <chrono>
#include <iostream>
#include <thread>

int main() {
  // Keep each testcase below the runner timeout while making 5,000 SYSTEM tests
  // exceed a typical one-hour M2M token lifetime.
  std::this_thread::sleep_for(std::chrono::milliseconds(800));
  std::cout << -1 << std::endl;
  return 0;
}
