This ZIP has no source file on purpose.
