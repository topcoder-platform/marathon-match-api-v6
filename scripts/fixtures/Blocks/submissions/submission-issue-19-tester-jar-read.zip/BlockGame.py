import glob
import sys


def probe_tester_jar_read_access():
    readable = []
    checked = 0

    for jar_path in sorted(glob.glob("/tmp/tester-*.jar")):
        checked += 1
        try:
            with open(jar_path, "rb") as handle:
                readable.append((jar_path, handle.read(4).hex()))
        except (FileNotFoundError, IsADirectoryError, PermissionError):
            continue
        except OSError as error:
            print(
                f"ISSUE19_TESTER_JAR_PROBE {jar_path} unreadable error={error}",
                file=sys.stderr,
            )

    if readable:
        for jar_path, magic in readable:
            print(f"ISSUE19_TESTER_JAR_READABLE {jar_path} magic={magic}", flush=True)
        sys.exit(0)

    print(f"ISSUE19_TESTER_JAR_UNREADABLE checked={checked}", file=sys.stderr)


probe_tester_jar_read_access()

N = int(input())
T = int(input())
C = int(input())
F = float(input())
P = float(input())

grid = [[0 for _ in range(N)] for _ in range(N)]
for r in range(N):
    for c in range(N):
        grid[r][c] = int(input())

S = 3
tiles = [[[0 for _ in range(S)] for _ in range(S)] for _ in range(T)]
for i in range(T):
    line = input()
    for r in range(S):
        for c in range(S):
            tiles[i][r][c] = ord(line[r * S + c]) - ord("0")

q = N // S

for i in range(1000):
    tile_id = i % T
    row = ((i // q) * S) % (N - 2)
    col = ((i % q) * S) % (N - 2)

    valid = True
    for r in range(S):
        for c in range(S):
            if tiles[tile_id][r][c] > 0 and grid[row + r][col + c] > 0:
                valid = False
    if not valid:
        continue

    for r in range(S):
        for c in range(S):
            if tiles[tile_id][r][c] > 0:
                grid[row + r][col + c] = tiles[tile_id][r][c]

    print(f"{tile_id} {row} {col}")
    sys.stdout.flush()

    line = input()
    for r in range(S):
        for c in range(S):
            tiles[tile_id][r][c] = ord(line[r * S + c]) - ord("0")

    elapsed_time = int(input())

print("-1")
sys.stdout.flush()
