#include <array>
#include <cerrno>
#include <cstring>
#include <iostream>
#include <string>
#include <sys/syscall.h>
#include <unistd.h>
#include <vector>

#include <linux/io_uring.h>

#ifndef SYS_io_uring_setup
#if defined(__x86_64__) || defined(__aarch64__)
#define SYS_io_uring_setup 425
#endif
#endif

namespace {
constexpr int kTileSize = 3;
using Tile = std::array<std::array<int, kTileSize>, kTileSize>;

bool verifyIoUringBlocked() {
#ifdef SYS_io_uring_setup
    io_uring_params params;
    std::memset(&params, 0, sizeof(params));

    errno = 0;
    long fd = syscall(SYS_io_uring_setup, 1U, &params);
    if (fd >= 0) {
        close(static_cast<int>(fd));
        return false;
    }
#endif

    return true;
}

Tile readTile() {
    std::string raw;
    std::cin >> raw;

    Tile tile{};
    for (int row = 0; row < kTileSize; row++) {
        for (int col = 0; col < kTileSize; col++) {
            tile[row][col] = raw[row * kTileSize + col] - '0';
        }
    }
    return tile;
}

bool canPlace(const std::vector<std::vector<int>>& grid, const Tile& tile, int row, int col) {
    for (int tileRow = 0; tileRow < kTileSize; tileRow++) {
        for (int tileCol = 0; tileCol < kTileSize; tileCol++) {
            if (tile[tileRow][tileCol] > 0 && grid[row + tileRow][col + tileCol] > 0) {
                return false;
            }
        }
    }
    return true;
}

void placeTile(std::vector<std::vector<int>>& grid, const Tile& tile, int row, int col) {
    for (int tileRow = 0; tileRow < kTileSize; tileRow++) {
        for (int tileCol = 0; tileCol < kTileSize; tileCol++) {
            if (tile[tileRow][tileCol] > 0) {
                grid[row + tileRow][col + tileCol] = tile[tileRow][tileCol];
            }
        }
    }
}
} // namespace

int main() {
    if (!verifyIoUringBlocked()) {
        std::cerr << "io_uring_setup succeeded; runner isolation is vulnerable" << std::endl;
        return 77;
    }

    int size = 0;
    int tileCount = 0;
    int fruitCount = 0;
    double gridFillRatio = 0.0;
    double tileFillRatio = 0.0;
    std::cin >> size >> tileCount >> fruitCount >> gridFillRatio >> tileFillRatio;

    std::vector<std::vector<int>> grid(size, std::vector<int>(size, 0));
    for (int row = 0; row < size; row++) {
        for (int col = 0; col < size; col++) {
            std::cin >> grid[row][col];
        }
    }

    std::vector<Tile> tiles(tileCount);
    for (int index = 0; index < tileCount; index++) {
        tiles[index] = readTile();
    }

    for (int turn = 0; turn < 1000; turn++) {
        int tileId = turn % tileCount;
        bool moved = false;

        for (int row = 0; row <= size - kTileSize && !moved; row++) {
            for (int col = 0; col <= size - kTileSize && !moved; col++) {
                if (canPlace(grid, tiles[tileId], row, col)) {
                    placeTile(grid, tiles[tileId], row, col);
                    std::cout << tileId << ' ' << row << ' ' << col << std::endl;
                    moved = true;
                }
            }
        }

        if (!moved) {
            std::cout << tileId << std::endl;
        }
        std::cout.flush();

        tiles[tileId] = readTile();
        int elapsedTime = 0;
        std::cin >> elapsedTime;
    }

    std::cout << -1 << std::endl;
    return 0;
}
