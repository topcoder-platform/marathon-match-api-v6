import sys

sys.stdin.readline()
print("NaN")
sys.stdout.flush()
